/* Generated from eval.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:27
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: eval.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file ueval.c
   unit: eval
*/

#include "chicken.h"


#ifndef C_INSTALL_EGG_HOME
# define C_INSTALL_EGG_HOME    "."
#endif

#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif


#define C_store_result(x, ptr)   (*((C_word *)C_block_item(ptr, 0)) = (x), C_SCHEME_TRUE)


#define C_copy_result_string(str, buf, n)  (C_memcpy((char *)C_block_item(buf, 0), C_c_string(str), C_unfix(n)), ((char *)C_block_item(buf, 0))[ C_unfix(n) ] = '\0', C_SCHEME_TRUE)


C_externexport  void  CHICKEN_get_error_message(char *t0,int t1);

C_externexport  int  CHICKEN_load(char * t0);

C_externexport  int  CHICKEN_read(char * t0,C_word *t1);

C_externexport  int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3);

C_externexport  int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2);

C_externexport  int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_string(char * t0,C_word *t1);

C_externexport  int  CHICKEN_eval(C_word t0,C_word *t1);

C_externexport  int  CHICKEN_yield();

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_expand_toplevel)
C_externimport void C_ccall C_expand_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[402];
static double C_possibly_force_alignment;


/* from ##sys#clear-trace-buffer in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static C_word C_fcall stub2782(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2782(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_clear_trace_buffer();
return C_r;}

C_noret_decl(C_eval_toplevel)
C_externexport void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3372)
static void C_ccall f_3372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10242)
static void C_ccall f_10242(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_10242)
static void C_ccall f_10242r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_10246)
static void C_fcall f_10246(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10271)
static void C_ccall f_10271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10261)
static void C_ccall f_10261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10269)
static void C_ccall f_10269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10254)
static void C_ccall f_10254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10252)
static void C_ccall f_10252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6610)
static void C_ccall f_6610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6705)
static void C_ccall f_6705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6786)
static void C_ccall f_6786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10236)
static void C_ccall f_10236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10232)
static void C_ccall f_10232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10228)
static void C_ccall f_10228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10224)
static void C_ccall f_10224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10214)
static void C_fcall f_10214(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7314)
static void C_fcall f_7314(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7319)
static void C_ccall f_7319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10192)
static void C_ccall f_10192(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10184)
static void C_ccall f_10184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10186)
static void C_ccall f_10186(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7326)
static void C_ccall f_7326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10153)
static void C_ccall f_10153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10173)
static void C_ccall f_10173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10169)
static void C_ccall f_10169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10159)
static void C_ccall f_10159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10156)
static void C_ccall f_10156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7679)
static void C_ccall f_7679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10099)
static void C_ccall f_10099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10113)
static void C_fcall f_10113(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10149)
static void C_ccall f_10149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10145)
static void C_ccall f_10145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10133)
static void C_ccall f_10133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10137)
static void C_ccall f_10137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10107)
static void C_ccall f_10107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8531)
static void C_ccall f_8531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10002)
static void C_ccall f_10002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10039)
static void C_fcall f_10039(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10042)
static void C_ccall f_10042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10065)
static void C_ccall f_10065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10069)
static void C_ccall f_10069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10051)
static void C_ccall f_10051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10048)
static void C_ccall f_10048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10005)
static void C_fcall f_10005(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8534)
static void C_ccall f_8534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8592)
static void C_ccall f_8592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10000)
static void C_ccall f_10000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8943)
static void C_ccall f_8943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8947)
static void C_ccall f_8947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9996)
static void C_ccall f_9996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8950)
static void C_ccall f_8950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8954)
static void C_ccall f_8954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9221)
static void C_ccall f_9221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9988)
static void C_ccall f_9988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9243)
static void C_ccall f_9243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9606)
static void C_ccall f_9606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9979)
static void C_ccall f_9979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9986)
static void C_ccall f_9986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9969)
static void C_ccall f_9969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9954)
static void C_ccall f_9954(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9958)
static void C_ccall f_9958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9963)
static void C_ccall f_9963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9967)
static void C_ccall f_9967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9932)
static void C_ccall f_9932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9936)
static void C_ccall f_9936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9941)
static void C_ccall f_9941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9945)
static void C_ccall f_9945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9952)
static void C_ccall f_9952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9906)
static void C_ccall f_9906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9912)
static void C_ccall f_9912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9916)
static void C_ccall f_9916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9930)
static void C_ccall f_9930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9919)
static void C_ccall f_9919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9926)
static void C_ccall f_9926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9890)
static void C_ccall f_9890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9896)
static void C_ccall f_9896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9904)
static void C_ccall f_9904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9853)
static void C_ccall f_9853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9857)
static void C_ccall f_9857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9862)
static void C_ccall f_9862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9866)
static void C_ccall f_9866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9888)
static void C_ccall f_9888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9884)
static void C_ccall f_9884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9880)
static void C_ccall f_9880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9869)
static void C_ccall f_9869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9876)
static void C_ccall f_9876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9827)
static void C_ccall f_9827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9833)
static void C_ccall f_9833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9837)
static void C_ccall f_9837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9851)
static void C_ccall f_9851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9840)
static void C_ccall f_9840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9847)
static void C_ccall f_9847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9814)
static C_word C_fcall f_9814(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9788)
static void C_ccall f_9788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9792)
static void C_ccall f_9792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9797)
static void C_ccall f_9797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9801)
static void C_ccall f_9801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9812)
static void C_ccall f_9812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9808)
static void C_ccall f_9808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9772)
static void C_ccall f_9772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9778)
static void C_ccall f_9778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9786)
static void C_ccall f_9786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9760)
static void C_ccall f_9760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9766)
static void C_ccall f_9766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9770)
static void C_ccall f_9770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9751)
static void C_fcall f_9751(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9755)
static void C_ccall f_9755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9692)
static void C_fcall f_9692(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9702)
static void C_ccall f_9702(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9727)
static void C_ccall f_9727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9739)
static void C_ccall f_9739(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9739)
static void C_ccall f_9739r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9745)
static void C_ccall f_9745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9733)
static void C_ccall f_9733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9708)
static void C_ccall f_9708(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9714)
static void C_ccall f_9714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9718)
static void C_ccall f_9718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9721)
static void C_ccall f_9721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9725)
static void C_ccall f_9725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9700)
static void C_ccall f_9700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9617)
static void C_ccall f_9617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9627)
static void C_ccall f_9627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9630)
static void C_ccall f_9630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9644)
static void C_fcall f_9644(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9662)
static void C_ccall f_9662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9631)
static void C_fcall f_9631(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9608)
static void C_ccall f_9608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9264)
static void C_ccall f_9264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9308)
static void C_ccall f_9308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9311)
static void C_ccall f_9311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9591)
static void C_ccall f_9591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9595)
static void C_ccall f_9595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9599)
static void C_ccall f_9599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9393)
static void C_ccall f_9393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9399)
static void C_fcall f_9399(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9574)
static void C_ccall f_9574(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9580)
static void C_ccall f_9580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9406)
static void C_ccall f_9406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9409)
static void C_ccall f_9409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9412)
static void C_ccall f_9412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9569)
static void C_ccall f_9569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9421)
static void C_ccall f_9421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9424)
static void C_ccall f_9424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9439)
static void C_ccall f_9439(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9439)
static void C_ccall f_9439r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9457)
static void C_fcall f_9457(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9523)
static void C_ccall f_9523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9473)
static void C_ccall f_9473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9481)
static void C_ccall f_9481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9485)
static void C_ccall f_9485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9488)
static void C_ccall f_9488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9500)
static void C_ccall f_9500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9503)
static void C_ccall f_9503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9491)
static void C_ccall f_9491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9476)
static void C_ccall f_9476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9461)
static void C_ccall f_9461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9443)
static void C_ccall f_9443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9289)
static void C_fcall f_9289(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9294)
static void C_ccall f_9294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9446)
static void C_ccall f_9446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9430)
static void C_ccall f_9430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9328)
static void C_ccall f_9328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9333)
static void C_ccall f_9333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9336)
static void C_ccall f_9336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9341)
static void C_ccall f_9341(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9341)
static void C_ccall f_9341r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9348)
static void C_ccall f_9348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9388)
static void C_ccall f_9388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9351)
static void C_ccall f_9351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9363)
static void C_fcall f_9363(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9372)
static void C_ccall f_9372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9366)
static void C_ccall f_9366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9354)
static void C_ccall f_9354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9357)
static void C_ccall f_9357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9319)
static C_word C_fcall f_9319(C_word t0);
C_noret_decl(f_9313)
static C_word C_fcall f_9313(C_word t0);
C_noret_decl(f_9267)
static void C_fcall f_9267(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9273)
static void C_ccall f_9273(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9261)
static void C_ccall f_9261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9245)
static void C_ccall f_9245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9259)
static void C_ccall f_9259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9256)
static void C_ccall f_9256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9249)
static void C_ccall f_9249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9226)
static void C_ccall f_9226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9235)
static void C_ccall f_9235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9230)
static void C_ccall f_9230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9166)
static void C_ccall f_9166(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9170)
static void C_ccall f_9170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9173)
static void C_ccall f_9173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9176)
static void C_ccall f_9176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9179)
static void C_ccall f_9179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9182)
static void C_ccall f_9182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9185)
static void C_ccall f_9185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9188)
static void C_ccall f_9188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9191)
static void C_ccall f_9191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9194)
static void C_ccall f_9194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9145)
static void C_fcall f_9145(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9149)
static void C_ccall f_9149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9152)
static void C_ccall f_9152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9121)
static void C_fcall f_9121(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9127)
static void C_fcall f_9127(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9137)
static void C_ccall f_9137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8979)
static void C_ccall f_8979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8979)
static void C_ccall f_8979r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9050)
static void C_ccall f_9050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9097)
static void C_ccall f_9097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9107)
static void C_ccall f_9107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9100)
static void C_fcall f_9100(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9060)
static void C_ccall f_9060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9062)
static void C_fcall f_9062(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9086)
static void C_ccall f_9086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9072)
static void C_ccall f_9072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9020)
static void C_fcall f_9020(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8985)
static void C_fcall f_8985(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9001)
static void C_ccall f_9001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9007)
static void C_ccall f_9007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8998)
static void C_ccall f_8998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8960)
static void C_fcall f_8960(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8964)
static void C_ccall f_8964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8927)
static void C_fcall f_8927(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8929)
static void C_ccall f_8929(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8933)
static void C_ccall f_8933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8889)
static void C_ccall f_8889(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8889)
static void C_ccall f_8889r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8896)
static void C_ccall f_8896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8903)
static void C_ccall f_8903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8845)
static void C_ccall f_8845(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8845)
static void C_ccall f_8845r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8878)
static void C_ccall f_8878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8865)
static void C_ccall f_8865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8842)
static void C_ccall f_8842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8723)
static void C_ccall f_8723(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8723)
static void C_ccall f_8723r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8817)
static void C_ccall f_8817(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8827)
static void C_ccall f_8827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8815)
static void C_ccall f_8815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8744)
static void C_fcall f_8744(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8768)
static void C_fcall f_8768(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8787)
static void C_ccall f_8787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8762)
static void C_ccall f_8762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8615)
static void C_ccall f_8615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_8615)
static void C_ccall f_8615r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_8625)
static void C_ccall f_8625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8630)
static void C_fcall f_8630(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8657)
static void C_fcall f_8657(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8690)
static void C_ccall f_8690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8651)
static void C_ccall f_8651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8599)
static void C_ccall f_8599(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8536)
static void C_ccall f_8536(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8540)
static void C_ccall f_8540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8548)
static void C_fcall f_8548(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8568)
static void C_fcall f_8568(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8492)
static void C_ccall f_8492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8524)
static void C_ccall f_8524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8510)
static void C_ccall f_8510(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7985)
static void C_ccall f_7985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8360)
static void C_fcall f_8360(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8369)
static void C_ccall f_8369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8399)
static void C_ccall f_8399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8401)
static void C_fcall f_8401(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8438)
static void C_ccall f_8438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8428)
static void C_ccall f_8428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8423)
static void C_ccall f_8423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8419)
static void C_ccall f_8419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8054)
static void C_fcall f_8054(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8064)
static void C_ccall f_8064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8217)
static void C_ccall f_8217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8322)
static void C_ccall f_8322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8329)
static void C_ccall f_8329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8229)
static void C_ccall f_8229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8248)
static void C_fcall f_8248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8276)
static void C_ccall f_8276(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8274)
static void C_ccall f_8274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8270)
static void C_ccall f_8270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8256)
static void C_fcall f_8256(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8252)
static void C_ccall f_8252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8244)
static void C_ccall f_8244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8236)
static void C_ccall f_8236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8131)
static void C_ccall f_8131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8149)
static void C_fcall f_8149(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8161)
static void C_fcall f_8161(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8157)
static void C_ccall f_8157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8145)
static void C_ccall f_8145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8088)
static void C_fcall f_8088(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8084)
static void C_ccall f_8084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8071)
static void C_ccall f_8071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8013)
static void C_fcall f_8013(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8032)
static void C_ccall f_8032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8029)
static void C_fcall f_8029(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8025)
static void C_ccall f_8025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7988)
static void C_fcall f_7988(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8007)
static void C_ccall f_8007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8001)
static void C_ccall f_8001(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7936)
static void C_ccall f_7936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7942)
static void C_fcall f_7942(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7956)
static void C_ccall f_7956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7959)
static void C_fcall f_7959(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7966)
static void C_ccall f_7966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7930)
static void C_ccall f_7930(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7897)
static void C_ccall f_7897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7901)
static void C_ccall f_7901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7910)
static void C_ccall f_7910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7928)
static void C_ccall f_7928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7913)
static void C_ccall f_7913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7920)
static void C_ccall f_7920(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7884)
static void C_ccall f_7884(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7884)
static void C_ccall f_7884r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7890)
static void C_ccall f_7890(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7870)
static void C_ccall f_7870(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7850)
static void C_ccall f_7850(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7850)
static void C_ccall f_7850r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7856)
static void C_ccall f_7856(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7863)
static void C_ccall f_7863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7782)
static void C_ccall f_7782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7782)
static void C_ccall f_7782r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7845)
static void C_ccall f_7845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7786)
static void C_fcall f_7786(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7789)
static void C_ccall f_7789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7807)
static void C_ccall f_7807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7813)
static void C_ccall f_7813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7683)
static void C_ccall f_7683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7687)
static void C_ccall f_7687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7735)
static void C_ccall f_7735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7737)
static void C_fcall f_7737(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7750)
static void C_ccall f_7750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7689)
static void C_fcall f_7689(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7693)
static void C_ccall f_7693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7728)
static void C_ccall f_7728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7699)
static void C_ccall f_7699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7709)
static void C_ccall f_7709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7702)
static void C_ccall f_7702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7519)
static void C_ccall f_7519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7624)
static void C_fcall f_7624(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7641)
static void C_ccall f_7641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7649)
static void C_ccall f_7649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7541)
static void C_ccall f_7541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7546)
static void C_fcall f_7546(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7585)
static void C_ccall f_7585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7572)
static void C_ccall f_7572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7528)
static C_word C_fcall f_7528(C_word t0);
C_noret_decl(f_7522)
static void C_fcall f_7522(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7434)
static void C_ccall f_7434(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7434)
static void C_ccall f_7434r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7441)
static void C_ccall f_7441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7451)
static void C_ccall f_7451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7328)
static void C_ccall f_7328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7332)
static void C_ccall f_7332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7424)
static void C_ccall f_7424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7428)
static void C_ccall f_7428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7341)
static void C_fcall f_7341(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7410)
static void C_ccall f_7410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7406)
static void C_ccall f_7406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7344)
static void C_ccall f_7344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7393)
static void C_ccall f_7393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7396)
static void C_ccall f_7396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7399)
static void C_ccall f_7399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7347)
static void C_ccall f_7347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7352)
static void C_fcall f_7352(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7386)
static void C_ccall f_7386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7365)
static void C_ccall f_7365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7368)
static void C_fcall f_7368(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7288)
static void C_ccall f_7288(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7288)
static void C_ccall f_7288r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7309)
static void C_ccall f_7309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7292)
static void C_ccall f_7292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7306)
static void C_ccall f_7306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7295)
static void C_ccall f_7295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7303)
static void C_ccall f_7303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7298)
static void C_ccall f_7298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7252)
static void C_ccall f_7252(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7252)
static void C_ccall f_7252r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7260)
static void C_ccall f_7260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7230)
static void C_ccall f_7230(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7230)
static void C_ccall f_7230r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6834)
static void C_ccall f_6834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6834)
static void C_ccall f_6834r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_7185)
static void C_fcall f_7185(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7180)
static void C_fcall f_7180(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6836)
static void C_fcall f_6836(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7179)
static void C_ccall f_7179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6840)
static void C_fcall f_6840(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7101)
static void C_ccall f_7101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7119)
static void C_fcall f_7119(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7122)
static void C_ccall f_7122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7128)
static void C_ccall f_7128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7131)
static void C_ccall f_7131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7137)
static void C_ccall f_7137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6843)
static void C_ccall f_6843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7092)
static void C_ccall f_7092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7080)
static void C_ccall f_7080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7083)
static void C_ccall f_7083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7086)
static void C_ccall f_7086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6849)
static void C_ccall f_6849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7065)
static void C_ccall f_7065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7037)
static void C_ccall f_7037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7061)
static void C_ccall f_7061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7057)
static void C_ccall f_7057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7053)
static void C_ccall f_7053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6852)
static void C_ccall f_6852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6860)
static void C_ccall f_6860(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7024)
static void C_ccall f_7024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6864)
static void C_ccall f_6864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7012)
static void C_ccall f_7012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6885)
static void C_ccall f_6885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6889)
static void C_ccall f_6889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7003)
static void C_ccall f_7003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6897)
static void C_ccall f_6897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6901)
static void C_ccall f_6901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6997)
static void C_ccall f_6997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6904)
static void C_ccall f_6904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6907)
static void C_ccall f_6907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6912)
static void C_fcall f_6912(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6922)
static void C_ccall f_6922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6968)
static void C_ccall f_6968(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6968)
static void C_ccall f_6968r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6977)
static void C_ccall f_6977(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6981)
static void C_ccall f_6981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6934)
static void C_ccall f_6934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6941)
static void C_ccall f_6941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6952)
static void C_ccall f_6952(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6952)
static void C_ccall f_6952r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6963)
static void C_ccall f_6963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6956)
static void C_ccall f_6956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6946)
static void C_ccall f_6946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6925)
static void C_ccall f_6925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6932)
static void C_ccall f_6932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6894)
static void C_ccall f_6894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6874)
static void C_ccall f_6874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6855)
static void C_ccall f_6855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6788)
static void C_fcall f_6788(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6798)
static C_word C_fcall f_6798(C_word t0,C_word t1);
C_noret_decl(f_6713)
static void C_ccall f_6713(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6725)
static void C_fcall f_6725(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6738)
static void C_ccall f_6738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6720)
static void C_ccall f_6720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6707)
static void C_ccall f_6707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6623)
static void C_ccall f_6623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6636)
static void C_fcall f_6636(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6669)
static void C_ccall f_6669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6650)
static void C_ccall f_6650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6626)
static void C_fcall f_6626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6613)
static void C_ccall f_6613(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6613)
static void C_ccall f_6613r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6621)
static void C_ccall f_6621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6362)
static void C_fcall f_6362(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6366)
static void C_ccall f_6366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6579)
static void C_ccall f_6579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6555)
static void C_ccall f_6555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6556)
static void C_ccall f_6556(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6567)
static void C_ccall f_6567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6573)
static void C_ccall f_6573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6512)
static void C_ccall f_6512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6515)
static void C_ccall f_6515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6518)
static void C_ccall f_6518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6521)
static void C_ccall f_6521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6522)
static void C_ccall f_6522(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6533)
static void C_ccall f_6533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6537)
static void C_ccall f_6537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6541)
static void C_ccall f_6541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6545)
static void C_ccall f_6545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6548)
static void C_ccall f_6548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6470)
static void C_ccall f_6470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6473)
static void C_ccall f_6473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6476)
static void C_ccall f_6476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6477)
static void C_ccall f_6477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6488)
static void C_ccall f_6488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6492)
static void C_ccall f_6492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6496)
static void C_ccall f_6496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6499)
static void C_ccall f_6499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6435)
static void C_ccall f_6435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6438)
static void C_ccall f_6438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6439)
static void C_ccall f_6439(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6450)
static void C_ccall f_6450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6454)
static void C_ccall f_6454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6407)
static void C_ccall f_6407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6408)
static void C_ccall f_6408(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6419)
static void C_ccall f_6419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6388)
static void C_ccall f_6388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6398)
static void C_ccall f_6398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6336)
static C_word C_fcall f_6336(C_word t0,C_word t1);
C_noret_decl(f_3928)
static void C_fcall f_3928(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_3935)
static void C_ccall f_3935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4111)
static void C_fcall f_4111(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4134)
static void C_ccall f_4134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4149)
static void C_ccall f_4149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6133)
static void C_fcall f_6133(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6120)
static void C_ccall f_6120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6085)
static void C_ccall f_6085(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6074)
static void C_ccall f_6074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6033)
static void C_ccall f_6033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5979)
static void C_fcall f_5979(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6001)
static void C_ccall f_6001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6017)
static void C_ccall f_6017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5991)
static void C_ccall f_5991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5973)
static void C_ccall f_5973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5949)
static void C_ccall f_5949(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5910)
static void C_ccall f_5910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5913)
static void C_ccall f_5913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5916)
static void C_ccall f_5916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5939)
static void C_ccall f_5939(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5937)
static void C_ccall f_5937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5933)
static void C_ccall f_5933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5923)
static void C_fcall f_5923(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5893)
static void C_ccall f_5893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5897)
static void C_ccall f_5897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5864)
static void C_ccall f_5864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5868)
static void C_ccall f_5868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5835)
static void C_ccall f_5835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5807)
static C_word C_fcall f_5807(C_word t0);
C_noret_decl(f_5796)
static void C_fcall f_5796(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5647)
static void C_ccall f_5647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5775)
static void C_ccall f_5775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5650)
static void C_ccall f_5650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5653)
static void C_ccall f_5653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5691)
static void C_fcall f_5691(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5772)
static void C_ccall f_5772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5764)
static void C_ccall f_5764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5701)
static void C_ccall f_5701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5749)
static void C_ccall f_5749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5705)
static void C_ccall f_5705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5711)
static void C_fcall f_5711(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5654)
static void C_ccall f_5654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5658)
static void C_ccall f_5658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5661)
static void C_ccall f_5661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5665)
static void C_ccall f_5665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5672)
static void C_ccall f_5672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5675)
static void C_ccall f_5675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5592)
static void C_fcall f_5592(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5505)
static void C_ccall f_5505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5508)
static void C_ccall f_5508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5549)
static void C_ccall f_5549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5561)
static void C_ccall f_5561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5511)
static void C_fcall f_5511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5514)
static void C_ccall f_5514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5539)
static void C_ccall f_5539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_ccall f_5517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5531)
static void C_ccall f_5531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5520)
static void C_ccall f_5520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5469)
static void C_ccall f_5469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5485)
static void C_ccall f_5485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5481)
static void C_ccall f_5481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5443)
static void C_ccall f_5443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5459)
static void C_ccall f_5459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5446)
static void C_ccall f_5446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5384)
static void C_ccall f_5384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5404)
static void C_ccall f_5404(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5402)
static void C_ccall f_5402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5387)
static void C_ccall f_5387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5394)
static void C_ccall f_5394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5020)
static void C_ccall f_5020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5357)
static void C_ccall f_5357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5368)
static void C_ccall f_5368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5362)
static void C_ccall f_5362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5037)
static void C_ccall f_5037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5041)
static void C_ccall f_5041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5308)
static void C_ccall f_5308(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5314)
static void C_ccall f_5314(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5314)
static void C_ccall f_5314r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5285)
static void C_ccall f_5285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5291)
static void C_ccall f_5291(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5291)
static void C_ccall f_5291r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6290)
static void C_fcall f_6290(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6319)
static void C_ccall f_6319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5307)
static void C_ccall f_5307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5263)
static void C_ccall f_5263(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5269)
static void C_ccall f_5269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5281)
static void C_ccall f_5281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_5216)
static void C_ccall f_5216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5197)
static void C_ccall f_5197(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5169)
static void C_ccall f_5169(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5175)
static void C_ccall f_5175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5150)
static void C_ccall f_5150(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5103)
static void C_ccall f_5103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5109)
static void C_ccall f_5109(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5109)
static void C_ccall f_5109r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5085)
static void C_ccall f_5085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5060)
static void C_ccall f_5060(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4952)
static void C_ccall f_4952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4960)
static void C_ccall f_4960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4956)
static void C_ccall f_4956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4915)
static void C_ccall f_4915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4905)
static void C_ccall f_4905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4889)
static void C_ccall f_4889(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4843)
static void C_ccall f_4843(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4859)
static void C_fcall f_4859(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4884)
static void C_ccall f_4884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4850)
static void C_ccall f_4850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4769)
static void C_ccall f_4769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4775)
static void C_ccall f_4775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4778)
static void C_ccall f_4778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4795)
static void C_ccall f_4795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4807)
static void C_ccall f_4807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4699)
static void C_ccall f_4699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4709)
static void C_ccall f_4709(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4725)
static void C_ccall f_4725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4733)
static void C_ccall f_4733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4650)
static void C_ccall f_4650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4474)
static void C_ccall f_4474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4488)
static void C_ccall f_4488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4492)
static void C_ccall f_4492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4501)
static void C_ccall f_4501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4542)
static void C_ccall f_4542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4507)
static void C_ccall f_4507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4510)
static void C_ccall f_4510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4526)
static void C_ccall f_4526(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4562)
static void C_ccall f_4562(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4570)
static void C_ccall f_4570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4549)
static void C_ccall f_4549(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4561)
static void C_ccall f_4561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4482)
static void C_ccall f_4482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4362)
static void C_ccall f_4362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4427)
static void C_ccall f_4427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4435)
static void C_ccall f_4435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4402)
static void C_ccall f_4402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4407)
static void C_ccall f_4407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4302)
static void C_ccall f_4302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4305)
static void C_ccall f_4305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4308)
static void C_ccall f_4308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4292)
static void C_ccall f_4292(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4258)
static void C_ccall f_4258(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4236)
static void C_ccall f_4236(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4208)
static void C_ccall f_4208(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4200)
static void C_ccall f_4200(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4192)
static void C_ccall f_4192(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4112)
static void C_ccall f_4112(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4078)
static void C_ccall f_4078(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3964)
static void C_ccall f_3964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3998)
static void C_fcall f_3998(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_fcall f_3993(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3970)
static void C_ccall f_3970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3973)
static void C_ccall f_3973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3877)
static void C_fcall f_3877(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3913)
static void C_ccall f_3913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3893)
static void C_ccall f_3893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3896)
static void C_ccall f_3896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3871)
static void C_fcall f_3871(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3865)
static C_word C_fcall f_3865(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3859)
static C_word C_fcall f_3859(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3775)
static void C_fcall f_3775(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3779)
static void C_ccall f_3779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3787)
static void C_fcall f_3787(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3829)
static C_word C_fcall f_3829(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3760)
static void C_fcall f_3760(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_fcall f_3721(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3734)
static void C_fcall f_3734(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3690)
static void C_ccall f_3690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3705)
static void C_ccall f_3705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3698)
static void C_ccall f_3698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3611)
static void C_ccall f_3611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3615)
static void C_ccall f_3615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3623)
static void C_fcall f_3623(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3571)
static void C_fcall f_3571(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3545)
static void C_ccall f_3545(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3489)
static void C_ccall f_3489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3497)
static void C_fcall f_3497(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3483)
static void C_ccall f_3483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3440)
static C_word C_fcall f_3440(C_word t0,C_word t1);
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3403)
static void C_ccall f_3403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3407)
static void C_ccall f_3407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;

/* from CHICKEN_get_error_message */
 void  CHICKEN_get_error_message(char *t0,int t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer_or_false(&a,(void*)t0);
C_save(x);
x=C_fix((C_word)t1);
C_save(x);C_callback_wrapper((void *)f_9969,2);}

/* from CHICKEN_load */
 int  CHICKEN_load(char * t0){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0))),*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9954,1));}

/* from CHICKEN_read */
 int  CHICKEN_read(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9932,2));}

/* from CHICKEN_apply_to_string */
 int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
x=C_fix((C_word)t3);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9906,4));}

/* from CHICKEN_apply */
 int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9890,3));}

/* from CHICKEN_eval_string_to_string */
 int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9853,3));}

/* from CHICKEN_eval_to_string */
 int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9827,3));}

/* from CHICKEN_eval_string */
 int  CHICKEN_eval_string(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9788,2));}

/* from CHICKEN_eval */
 int  CHICKEN_eval(C_word t0,C_word *t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9772,2));}

/* from CHICKEN_yield */
 int  CHICKEN_yield(){
C_word x,s=0,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
return C_truep(C_callback_wrapper((void *)f_9760,0));}

C_noret_decl(trf_10246)
static void C_fcall trf_10246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10246(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10246(t0,t1);}

C_noret_decl(trf_10214)
static void C_fcall trf_10214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10214(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10214(t0,t1);}

C_noret_decl(trf_7314)
static void C_fcall trf_7314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7314(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7314(t0,t1);}

C_noret_decl(trf_10113)
static void C_fcall trf_10113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10113(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10113(t0,t1,t2);}

C_noret_decl(trf_10039)
static void C_fcall trf_10039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10039(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10039(t0,t1);}

C_noret_decl(trf_10005)
static void C_fcall trf_10005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10005(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10005(t0,t1);}

C_noret_decl(trf_9751)
static void C_fcall trf_9751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9751(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9751(t0,t1,t2);}

C_noret_decl(trf_9692)
static void C_fcall trf_9692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9692(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9692(t0,t1);}

C_noret_decl(trf_9644)
static void C_fcall trf_9644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9644(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9644(t0,t1);}

C_noret_decl(trf_9631)
static void C_fcall trf_9631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9631(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9631(t0,t1);}

C_noret_decl(trf_9399)
static void C_fcall trf_9399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9399(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9399(t0,t1);}

C_noret_decl(trf_9457)
static void C_fcall trf_9457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9457(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9457(t0,t1,t2,t3);}

C_noret_decl(trf_9289)
static void C_fcall trf_9289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9289(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9289(t0,t1);}

C_noret_decl(trf_9363)
static void C_fcall trf_9363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9363(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9363(t0,t1);}

C_noret_decl(trf_9267)
static void C_fcall trf_9267(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9267(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9267(t0,t1);}

C_noret_decl(trf_9145)
static void C_fcall trf_9145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9145(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9145(t0,t1,t2,t3);}

C_noret_decl(trf_9121)
static void C_fcall trf_9121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9121(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9121(t0,t1,t2);}

C_noret_decl(trf_9127)
static void C_fcall trf_9127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9127(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9127(t0,t1,t2);}

C_noret_decl(trf_9100)
static void C_fcall trf_9100(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9100(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9100(t0,t1);}

C_noret_decl(trf_9062)
static void C_fcall trf_9062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9062(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9062(t0,t1,t2);}

C_noret_decl(trf_9020)
static void C_fcall trf_9020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9020(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9020(t0,t1,t2);}

C_noret_decl(trf_8985)
static void C_fcall trf_8985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8985(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8985(t0,t1,t2,t3);}

C_noret_decl(trf_8960)
static void C_fcall trf_8960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8960(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8960(t0,t1);}

C_noret_decl(trf_8927)
static void C_fcall trf_8927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8927(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8927(t0,t1);}

C_noret_decl(trf_8744)
static void C_fcall trf_8744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8744(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8744(t0,t1,t2,t3);}

C_noret_decl(trf_8768)
static void C_fcall trf_8768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8768(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8768(t0,t1,t2,t3);}

C_noret_decl(trf_8630)
static void C_fcall trf_8630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8630(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8630(t0,t1,t2);}

C_noret_decl(trf_8657)
static void C_fcall trf_8657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8657(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8657(t0,t1,t2);}

C_noret_decl(trf_8548)
static void C_fcall trf_8548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8548(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8548(t0,t1,t2);}

C_noret_decl(trf_8568)
static void C_fcall trf_8568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8568(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8568(t0,t1);}

C_noret_decl(trf_8360)
static void C_fcall trf_8360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8360(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8360(t0,t1);}

C_noret_decl(trf_8401)
static void C_fcall trf_8401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8401(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8401(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8054)
static void C_fcall trf_8054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8054(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8054(t0,t1,t2);}

C_noret_decl(trf_8248)
static void C_fcall trf_8248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8248(t0,t1);}

C_noret_decl(trf_8256)
static void C_fcall trf_8256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8256(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8256(t0,t1);}

C_noret_decl(trf_8149)
static void C_fcall trf_8149(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8149(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8149(t0,t1);}

C_noret_decl(trf_8161)
static void C_fcall trf_8161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8161(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8161(t0,t1);}

C_noret_decl(trf_8088)
static void C_fcall trf_8088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8088(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8088(t0,t1);}

C_noret_decl(trf_8013)
static void C_fcall trf_8013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8013(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8013(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8029)
static void C_fcall trf_8029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8029(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8029(t0,t1);}

C_noret_decl(trf_7988)
static void C_fcall trf_7988(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7988(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7988(t0,t1,t2,t3);}

C_noret_decl(trf_7942)
static void C_fcall trf_7942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7942(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7942(t0,t1,t2);}

C_noret_decl(trf_7959)
static void C_fcall trf_7959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7959(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7959(t0,t1);}

C_noret_decl(trf_7786)
static void C_fcall trf_7786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7786(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7786(t0,t1);}

C_noret_decl(trf_7737)
static void C_fcall trf_7737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7737(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7737(t0,t1,t2);}

C_noret_decl(trf_7689)
static void C_fcall trf_7689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7689(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7689(t0,t1,t2);}

C_noret_decl(trf_7624)
static void C_fcall trf_7624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7624(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7624(t0,t1,t2);}

C_noret_decl(trf_7546)
static void C_fcall trf_7546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7546(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7546(t0,t1,t2);}

C_noret_decl(trf_7522)
static void C_fcall trf_7522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7522(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7522(t0,t1);}

C_noret_decl(trf_7341)
static void C_fcall trf_7341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7341(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7341(t0,t1);}

C_noret_decl(trf_7352)
static void C_fcall trf_7352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7352(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7352(t0,t1,t2);}

C_noret_decl(trf_7368)
static void C_fcall trf_7368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7368(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7368(t0,t1);}

C_noret_decl(trf_7185)
static void C_fcall trf_7185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7185(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7185(t0,t1);}

C_noret_decl(trf_7180)
static void C_fcall trf_7180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7180(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7180(t0,t1,t2);}

C_noret_decl(trf_6836)
static void C_fcall trf_6836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6836(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6836(t0,t1,t2,t3);}

C_noret_decl(trf_6840)
static void C_fcall trf_6840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6840(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6840(t0,t1);}

C_noret_decl(trf_7119)
static void C_fcall trf_7119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7119(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7119(t0,t1);}

C_noret_decl(trf_6912)
static void C_fcall trf_6912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6912(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6912(t0,t1,t2);}

C_noret_decl(trf_6788)
static void C_fcall trf_6788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6788(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6788(t0,t1);}

C_noret_decl(trf_6725)
static void C_fcall trf_6725(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6725(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6725(t0,t1,t2);}

C_noret_decl(trf_6636)
static void C_fcall trf_6636(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6636(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6636(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6626)
static void C_fcall trf_6626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6626(t0,t1);}

C_noret_decl(trf_6362)
static void C_fcall trf_6362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6362(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6362(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3928)
static void C_fcall trf_3928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3928(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_3928(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_4111)
static void C_fcall trf_4111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4111(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4111(t0,t1);}

C_noret_decl(trf_6133)
static void C_fcall trf_6133(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6133(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6133(t0,t1);}

C_noret_decl(trf_5979)
static void C_fcall trf_5979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5979(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5979(t0,t1,t2);}

C_noret_decl(trf_5923)
static void C_fcall trf_5923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5923(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5923(t0,t1);}

C_noret_decl(trf_5796)
static void C_fcall trf_5796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5796(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5796(t0,t1);}

C_noret_decl(trf_5691)
static void C_fcall trf_5691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5691(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5691(t0,t1,t2,t3);}

C_noret_decl(trf_5711)
static void C_fcall trf_5711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5711(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5711(t0,t1,t2);}

C_noret_decl(trf_5592)
static void C_fcall trf_5592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5592(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5592(t0,t1);}

C_noret_decl(trf_5511)
static void C_fcall trf_5511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5511(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5511(t0,t1);}

C_noret_decl(trf_6290)
static void C_fcall trf_6290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6290(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6290(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4859)
static void C_fcall trf_4859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4859(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4859(t0,t1,t2,t3);}

C_noret_decl(trf_3998)
static void C_fcall trf_3998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3998(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3998(t0,t1);}

C_noret_decl(trf_3993)
static void C_fcall trf_3993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3993(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3993(t0,t1);}

C_noret_decl(trf_3877)
static void C_fcall trf_3877(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3877(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3877(t0,t1);}

C_noret_decl(trf_3871)
static void C_fcall trf_3871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3871(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3871(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3775)
static void C_fcall trf_3775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3775(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3775(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3787)
static void C_fcall trf_3787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3787(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3787(t0,t1,t2,t3);}

C_noret_decl(trf_3760)
static void C_fcall trf_3760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3760(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3760(t0,t1,t2,t3);}

C_noret_decl(trf_3721)
static void C_fcall trf_3721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3721(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3721(t0,t1,t2,t3);}

C_noret_decl(trf_3734)
static void C_fcall trf_3734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3734(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3734(t0,t1);}

C_noret_decl(trf_3623)
static void C_fcall trf_3623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3623(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3623(t0,t1,t2);}

C_noret_decl(trf_3571)
static void C_fcall trf_3571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3571(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3571(t0,t1,t2);}

C_noret_decl(trf_3497)
static void C_fcall trf_3497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3497(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3497(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_eval_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("eval_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(6548)){
C_save(t1);
C_rereclaim2(6548*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,402);
lf[0]=C_h_intern(&lf[0],1,"d");
lf[1]=C_h_intern(&lf[1],2,"pp");
lf[2]=C_h_intern(&lf[2],5,"print");
lf[3]=C_h_intern(&lf[3],24,"\003syscore-library-modules");
lf[4]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006extras\376\003\000\000\002\376\001\000\000\007lolevel\376\003\000\000\002\376\001\000\000\005utils\376\003\000\000\002\376\001\000\000\005files\376\003\000\000\002\376\001\000\000\003tcp\376\003\000\000"
"\002\376\001\000\000\005regex\376\003\000\000\002\376\001\000\000\014regex-extras\376\003\000\000\002\376\001\000\000\005posix\376\003\000\000\002\376\001\000\000\006srfi-1\376\003\000\000\002\376\001\000\000\006srfi-4"
"\376\003\000\000\002\376\001\000\000\007srfi-13\376\003\000\000\002\376\001\000\000\007srfi-14\376\003\000\000\002\376\001\000\000\007srfi-18\376\003\000\000\002\376\001\000\000\017data-structures\376\003\000\000"
"\002\376\001\000\000\005ports\376\003\000\000\002\376\001\000\000\016chicken-syntax\376\377\016");
lf[5]=C_h_intern(&lf[5],28,"\003sysexplicit-library-modules");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\003.so");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[10]=C_h_intern(&lf[10],18,"\003syschicken-prefix");
lf[11]=C_h_intern(&lf[11],17,"\003sysstring-append");
lf[12]=C_h_intern(&lf[12],12,"chicken-home");
lf[13]=C_h_intern(&lf[13],17,"\003syspeek-c-string");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\015share/chicken");
lf[15]=C_h_intern(&lf[15],15,"\003syshash-symbol");
lf[16]=C_h_intern(&lf[16],18,"\003syshash-table-ref");
lf[17]=C_h_intern(&lf[17],19,"\003syshash-table-set!");
lf[18]=C_h_intern(&lf[18],22,"\003syshash-table-update!");
lf[19]=C_h_intern(&lf[19],23,"\003syshash-table-for-each");
lf[20]=C_h_intern(&lf[20],12,"\003sysfor-each");
lf[21]=C_h_intern(&lf[21],28,"\003sysarbitrary-unbound-symbol");
lf[22]=C_h_intern(&lf[22],23,"\003syshash-table-location");
lf[23]=C_h_intern(&lf[23],20,"\003syseval-environment");
lf[24]=C_h_intern(&lf[24],26,"\003sysenvironment-is-mutable");
lf[25]=C_h_intern(&lf[25],18,"\003syseval-decorator");
lf[26]=C_h_intern(&lf[26],20,"\003sysmake-lambda-info");
lf[27]=C_h_intern(&lf[27],17,"get-output-string");
lf[28]=C_h_intern(&lf[28],5,"write");
lf[29]=C_h_intern(&lf[29],18,"open-output-string");
lf[30]=C_h_intern(&lf[30],19,"\003sysdecorate-lambda");
lf[31]=C_h_intern(&lf[31],19,"\003sysunbound-in-eval");
lf[32]=C_h_intern(&lf[32],20,"\003syseval-debug-level");
lf[33]=C_h_intern(&lf[33],7,"reverse");
lf[34]=C_h_intern(&lf[34],20,"with-input-from-file");
lf[35]=C_h_intern(&lf[35],7,"display");
lf[36]=C_h_intern(&lf[36],22,"\003syscompile-to-closure");
lf[37]=C_h_intern(&lf[37],7,"\003sysget");
lf[38]=C_h_intern(&lf[38],16,"\004coremacro-alias");
lf[39]=C_h_intern(&lf[39],19,"\003sysundefined-value");
lf[40]=C_h_intern(&lf[40],18,"\003syscurrent-thread");
lf[41]=C_h_intern(&lf[41],18,"\003syscurrent-module");
lf[42]=C_h_intern(&lf[42],21,"\003sysmacro-environment");
lf[43]=C_h_intern(&lf[43],28,"\003syscurrent-meta-environment");
lf[44]=C_h_intern(&lf[44],16,"\003sysdynamic-wind");
lf[45]=C_h_intern(&lf[45],26,"\003sysmeta-macro-environment");
lf[46]=C_h_intern(&lf[46],9,"\003syserror");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\020unbound variable");
lf[48]=C_h_intern(&lf[48],21,"\003syssyntax-error-hook");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000!reference to undefined identifier");
lf[50]=C_h_intern(&lf[50],32,"\003syssymbol-has-toplevel-binding\077");
lf[51]=C_h_intern(&lf[51],14,"\004coreprimitive");
lf[52]=C_h_intern(&lf[52],21,"\003sysalias-global-hook");
lf[53]=C_h_intern(&lf[53],5,"quote");
lf[54]=C_h_intern(&lf[54],16,"\003sysstrip-syntax");
lf[55]=C_h_intern(&lf[55],16,"\003syscheck-syntax");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[57]=C_h_intern(&lf[57],6,"syntax");
lf[58]=C_h_intern(&lf[58],11,"\004coresyntax");
lf[59]=C_h_intern(&lf[59],15,"\004coreglobal-ref");
lf[60]=C_h_intern(&lf[60],10,"\004corecheck");
lf[61]=C_h_intern(&lf[61],14,"\004coreimmutable");
lf[62]=C_h_intern(&lf[62],14,"\004coreundefined");
lf[63]=C_h_intern(&lf[63],2,"if");
lf[64]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[66]=C_h_intern(&lf[66],5,"begin");
lf[67]=C_h_intern(&lf[67],10,"\004corebegin");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[69]=C_h_intern(&lf[69],10,"\003sysappend");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[71]=C_h_intern(&lf[71],4,"set!");
lf[72]=C_h_intern(&lf[72],9,"\004coreset!");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000 assignment to immutable variable");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\042assignment of undefined identifier");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[76]=C_h_intern(&lf[76],3,"let");
lf[77]=C_h_intern(&lf[77],8,"\004corelet");
lf[78]=C_h_intern(&lf[78],15,"\003sysmake-vector");
lf[79]=C_h_intern(&lf[79],7,"\003sysmap");
lf[80]=C_h_intern(&lf[80],21,"\003syscanonicalize-body");
lf[81]=C_h_intern(&lf[81],6,"append");
lf[82]=C_h_intern(&lf[82],3,"map");
lf[83]=C_h_intern(&lf[83],4,"cons");
lf[84]=C_h_intern(&lf[84],6,"gensym");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[86]=C_h_intern(&lf[86],6,"letrec");
lf[87]=C_h_intern(&lf[87],11,"\004coreletrec");
lf[88]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[89]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[90]=C_h_intern(&lf[90],6,"lambda");
lf[91]=C_h_intern(&lf[91],11,"\004corelambda");
lf[92]=C_h_intern(&lf[92],1,"\077");
lf[93]=C_h_intern(&lf[93],10,"\003sysvector");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[96]=C_h_intern(&lf[96],25,"\003sysdecompose-lambda-list");
lf[97]=C_h_intern(&lf[97],31,"\003sysexpand-extended-lambda-list");
lf[98]=C_h_intern(&lf[98],25,"\003sysextended-lambda-list\077");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[100]=C_h_intern(&lf[100],10,"let-syntax");
lf[101]=C_h_intern(&lf[101],18,"\003syser-transformer");
lf[102]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012let-syntax\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_"
"\376\377\001\000\000\000\001");
lf[103]=C_h_intern(&lf[103],13,"letrec-syntax");
lf[104]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015letrec-syntax\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000"
"\000\001_\376\377\001\000\000\000\001");
lf[105]=C_h_intern(&lf[105],13,"define-syntax");
lf[106]=C_h_intern(&lf[106],22,"define-compiled-syntax");
lf[107]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[108]=C_h_intern(&lf[108],28,"\003sysextend-macro-environment");
lf[109]=C_h_intern(&lf[109],23,"\003syscurrent-environment");
lf[110]=C_h_intern(&lf[110],26,"\003sysregister-syntax-export");
lf[111]=C_h_intern(&lf[111],5,"caadr");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[113]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[114]=C_h_intern(&lf[114],27,"\004coredefine-compiler-syntax");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[116]=C_h_intern(&lf[116],24,"\004corelet-compiler-syntax");
lf[117]=C_h_intern(&lf[117],11,"\004coremodule");
lf[118]=C_h_intern(&lf[118],29,"\003sysinitial-macro-environment");
lf[119]=C_h_intern(&lf[119],19,"\003sysfinalize-module");
lf[120]=C_h_intern(&lf[120],19,"\003sysregister-module");
lf[121]=C_h_intern(&lf[121],6,"module");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\031modules may not be nested");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid export syntax");
lf[124]=C_h_intern(&lf[124],16,"\004coreloop-lambda");
lf[125]=C_h_intern(&lf[125],17,"\004corenamed-lambda");
lf[126]=C_h_intern(&lf[126],23,"\004corerequire-for-syntax");
lf[127]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[128]=C_h_intern(&lf[128],11,"\003sysrequire");
lf[129]=C_h_intern(&lf[129],31,"\003syslookup-runtime-requirements");
lf[130]=C_h_intern(&lf[130],22,"\004corerequire-extension");
lf[131]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[132]=C_h_intern(&lf[132],22,"\003sysdo-the-right-thing");
lf[133]=C_h_intern(&lf[133],24,"\004coreelaborationtimeonly");
lf[134]=C_h_intern(&lf[134],23,"\004coreelaborationtimetoo");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[136]=C_h_intern(&lf[136],19,"\004corecompiletimetoo");
lf[137]=C_h_intern(&lf[137],20,"\004corecompiletimeonly");
lf[138]=C_h_intern(&lf[138],13,"\004corecallunit");
lf[139]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[140]=C_h_intern(&lf[140],12,"\004coredeclare");
lf[141]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[142]=C_h_intern(&lf[142],10,"\000compiling");
lf[143]=C_h_intern(&lf[143],12,"\003sysfeatures");
lf[144]=C_h_intern(&lf[144],28,"\010compilerprocess-declaration");
lf[145]=C_h_intern(&lf[145],8,"\003syswarn");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000,declarations are ignored in interpreted code");
lf[147]=C_h_intern(&lf[147],13,"define-inline");
lf[148]=C_h_intern(&lf[148],15,"define-constant");
lf[149]=C_h_intern(&lf[149],6,"define");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000%cannot evaluate compiler-special-form");
lf[151]=C_h_intern(&lf[151],8,"\004coreapp");
lf[152]=C_h_intern(&lf[152],8,"location");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000%cannot evaluate compiler-special-form");
lf[154]=C_h_intern(&lf[154],11,"\004coreinline");
lf[155]=C_h_intern(&lf[155],20,"\004coreinline_allocate");
lf[156]=C_h_intern(&lf[156],19,"\004coreforeign-lambda");
lf[157]=C_h_intern(&lf[157],28,"\004coredefine-foreign-variable");
lf[158]=C_h_intern(&lf[158],29,"\004coredefine-external-variable");
lf[159]=C_h_intern(&lf[159],17,"\004corelet-location");
lf[160]=C_h_intern(&lf[160],22,"\004coreforeign-primitive");
lf[161]=C_h_intern(&lf[161],20,"\004coreforeign-lambda*");
lf[162]=C_h_intern(&lf[162],24,"\004coredefine-foreign-type");
lf[163]=C_h_intern(&lf[163],10,"\003sysexpand");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal non-atomic object");
lf[165]=C_h_intern(&lf[165],11,"\003sysnumber\077");
lf[166]=C_h_intern(&lf[166],8,"keyword\077");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[168]=C_h_intern(&lf[168],16,"\003syseval-handler");
lf[169]=C_h_intern(&lf[169],12,"eval-handler");
lf[170]=C_h_intern(&lf[170],4,"eval");
lf[171]=C_h_intern(&lf[171],24,"\003syssyntax-error-culprit");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\032illegal lambda-list syntax");
lf[173]=C_h_intern(&lf[173],12,"load-verbose");
lf[174]=C_h_intern(&lf[174],14,"\003sysabort-load");
lf[175]=C_h_intern(&lf[175],27,"\003syscurrent-source-filename");
lf[176]=C_h_intern(&lf[176],21,"\003syscurrent-load-path");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[178]=C_h_intern(&lf[178],18,"\003sysdload-disabled");
lf[179]=C_h_intern(&lf[179],22,"set-dynamic-load-mode!");
lf[180]=C_h_intern(&lf[180],21,"\003sysset-dlopen-flags!");
lf[181]=C_h_intern(&lf[181],6,"global");
lf[182]=C_h_intern(&lf[182],5,"local");
lf[183]=C_h_intern(&lf[183],4,"lazy");
lf[184]=C_h_intern(&lf[184],3,"now");
lf[185]=C_h_intern(&lf[185],15,"\003syssignal-hook");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid dynamic-load mode");
lf[187]=C_h_intern(&lf[187],4,"read");
lf[188]=C_h_intern(&lf[188],7,"newline");
lf[189]=C_h_intern(&lf[189],12,"flush-output");
lf[190]=C_h_intern(&lf[190],15,"open-input-file");
lf[191]=C_h_intern(&lf[191],16,"close-input-port");
lf[192]=C_h_intern(&lf[192],13,"string-append");
lf[193]=C_h_intern(&lf[193],8,"\003sysload");
lf[194]=C_h_intern(&lf[194],31,"\003sysread-error-with-line-number");
lf[195]=C_h_intern(&lf[195],17,"\003sysdisplay-times");
lf[196]=C_h_intern(&lf[196],14,"\003sysstop-timer");
lf[197]=C_h_intern(&lf[197],15,"\003sysstart-timer");
lf[198]=C_h_intern(&lf[198],4,"load");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\036unable to load compiled module");
lf[200]=C_h_intern(&lf[200],9,"peek-char");
lf[201]=C_h_intern(&lf[201],13,"\003syssubstring");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[203]=C_h_intern(&lf[203],30,"call-with-current-continuation");
lf[204]=C_h_intern(&lf[204],9,"\003sysdload");
lf[205]=C_h_intern(&lf[205],17,"\003sysmake-c-string");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[207]=C_h_intern(&lf[207],11,"\000file-error");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\012; loading ");
lf[211]=C_h_intern(&lf[211],13,"\003sysfile-info");
lf[212]=C_h_intern(&lf[212],26,"\003sysload-dynamic-extension");
lf[213]=C_h_intern(&lf[213],11,"\000type-error");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a port or string");
lf[215]=C_h_intern(&lf[215],5,"port\077");
lf[216]=C_h_intern(&lf[216],20,"\003sysexpand-home-path");
lf[217]=C_h_intern(&lf[217],13,"load-relative");
lf[218]=C_h_intern(&lf[218],12,"load-noisily");
lf[219]=C_h_intern(&lf[219],15,"\003sysget-keyword");
lf[220]=C_h_intern(&lf[220],8,"\000printer");
lf[221]=C_h_intern(&lf[221],5,"\000time");
lf[222]=C_h_intern(&lf[222],10,"\000evaluator");
lf[223]=C_h_intern(&lf[223],26,"\003sysload-library-extension");
lf[224]=C_h_intern(&lf[224],6,"cygwin");
lf[225]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014cygchicken-0\376\377\016");
lf[226]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012libchicken\376\377\016");
lf[227]=C_h_intern(&lf[227],34,"\003sysdefault-dynamic-load-libraries");
lf[228]=C_h_intern(&lf[228],22,"dynamic-load-libraries");
lf[229]=C_h_intern(&lf[229],16,"\003sysload-library");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\022; loading library ");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[234]=C_h_intern(&lf[234],24,"\003sysstring->c-identifier");
lf[235]=C_h_intern(&lf[235],16,"\003sys->feature-id");
lf[236]=C_h_intern(&lf[236],12,"load-library");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\026unable to load library");
lf[238]=C_h_intern(&lf[238],31,"\003syscanonicalize-extension-path");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid extension path");
lf[240]=C_h_intern(&lf[240],18,"\003syssymbol->string");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[244]=C_h_intern(&lf[244],19,"\003sysrepository-path");
lf[245]=C_h_intern(&lf[245],15,"repository-path");
lf[246]=C_h_intern(&lf[246],14,"\003syssetup-mode");
lf[247]=C_h_intern(&lf[247],12,"file-exists\077");
lf[248]=C_h_intern(&lf[248],18,"\003sysfind-extension");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[250]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001.\376\377\016");
lf[251]=C_h_intern(&lf[251],21,"\003sysinclude-pathnames");
lf[252]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001.\376\377\016");
lf[253]=C_h_intern(&lf[253],21,"\003sysloaded-extensions");
lf[254]=C_h_intern(&lf[254],14,"string->symbol");
lf[255]=C_h_intern(&lf[255],18,"\003sysload-extension");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot load extension");
lf[257]=C_h_intern(&lf[257],11,"\003sysprovide");
lf[258]=C_h_intern(&lf[258],7,"provide");
lf[259]=C_h_intern(&lf[259],13,"\003sysprovided\077");
lf[260]=C_h_intern(&lf[260],9,"provided\077");
lf[261]=C_h_intern(&lf[261],7,"require");
lf[262]=C_h_intern(&lf[262],25,"\003sysextension-information");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[266]=C_h_intern(&lf[266],21,"extension-information");
lf[267]=C_h_intern(&lf[267],18,"require-at-runtime");
lf[268]=C_h_intern(&lf[268],12,"vector->list");
lf[269]=C_h_intern(&lf[269],14,"dynamic/syntax");
lf[270]=C_h_intern(&lf[270],7,"dynamic");
lf[271]=C_h_intern(&lf[271],11,"lset-adjoin");
lf[272]=C_h_intern(&lf[272],3,"eq\077");
lf[273]=C_h_intern(&lf[273],26,"\010compilerfile-requirements");
lf[274]=C_h_intern(&lf[274],6,"import");
lf[275]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007chicken\376\003\000\000\002\376\001\000\000\006srfi-2\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\007srfi-10\376\003\000\000\002\376\001\000\000\007srfi"
"-12\376\003\000\000\002\376\001\000\000\007srfi-23\376\003\000\000\002\376\001\000\000\007srfi-28\376\003\000\000\002\376\001\000\000\007srfi-30\376\003\000\000\002\376\001\000\000\007srfi-31\376\003\000\000\002\376\001\000\000"
"\007srfi-39\376\003\000\000\002\376\001\000\000\007srfi-69\376\003\000\000\002\376\001\000\000\007srfi-98\376\377\016");
lf[276]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[277]=C_h_intern(&lf[277],4,"uses");
lf[278]=C_h_intern(&lf[278],17,"require-extension");
lf[279]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\006srfi-8\376\003\000\000\002\376\001\000\000\006srfi-9\376\003\000\000\002\376\001\000\000\007srfi-11\376\003\000\000\002\376\001\000\000\007srfi-"
"15\376\003\000\000\002\376\001\000\000\007srfi-16\376\003\000\000\002\376\001\000\000\007srfi-17\376\003\000\000\002\376\001\000\000\007srfi-26\376\003\000\000\002\376\001\000\000\007srfi-55\376\377\016");
lf[280]=C_h_intern(&lf[280],12,"\003sysfeature\077");
lf[281]=C_h_intern(&lf[281],24,"\003sysextension-specifiers");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\035undefined extension specifier");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid extension specifier");
lf[284]=C_h_intern(&lf[284],24,"set-extension-specifier!");
lf[285]=C_h_intern(&lf[285],11,"string-copy");
lf[288]=C_h_intern(&lf[288],11,"environment");
lf[290]=C_h_intern(&lf[290],16,"\003sysenvironment\077");
lf[291]=C_h_intern(&lf[291],18,"\003syscopy-env-table");
lf[292]=C_h_intern(&lf[292],23,"\003sysenvironment-symbols");
lf[293]=C_h_intern(&lf[293],18,"\003syswalk-namespace");
lf[294]=C_h_intern(&lf[294],23,"interaction-environment");
lf[295]=C_h_intern(&lf[295],25,"scheme-report-environment");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[297]=C_h_intern(&lf[297],11,"make-vector");
lf[298]=C_h_intern(&lf[298],16,"null-environment");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[300]=C_h_intern(&lf[300],28,"\003sysresolve-include-filename");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\013 major GCs\012");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\013 minor GCs\012");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\013 mutations\012");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\027 seconds in (major) GC\012");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\021 seconds elapsed\012");
lf[308]=C_h_intern(&lf[308],18,"\003sysrepl-eval-hook");
lf[309]=C_h_intern(&lf[309],27,"\003sysrepl-print-length-limit");
lf[310]=C_h_intern(&lf[310],18,"\003sysrepl-read-hook");
lf[311]=C_h_intern(&lf[311],19,"\003sysrepl-print-hook");
lf[312]=C_h_intern(&lf[312],16,"\003syswrite-char-0");
lf[313]=C_h_intern(&lf[313],9,"\003sysprint");
lf[314]=C_h_intern(&lf[314],27,"\003syswith-print-length-limit");
lf[315]=C_h_intern(&lf[315],11,"repl-prompt");
lf[316]=C_h_intern(&lf[316],20,"\003sysread-prompt-hook");
lf[317]=C_h_intern(&lf[317],16,"\003sysflush-output");
lf[318]=C_h_intern(&lf[318],19,"\003sysstandard-output");
lf[319]=C_h_intern(&lf[319],22,"\003sysclear-trace-buffer");
lf[320]=C_h_intern(&lf[320],16,"print-call-chain");
lf[321]=C_h_intern(&lf[321],5,"reset");
lf[322]=C_h_intern(&lf[322],4,"repl");
lf[323]=C_h_intern(&lf[323],18,"\003sysstandard-error");
lf[324]=C_h_intern(&lf[324],18,"\003sysstandard-input");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\006\012Error");
lf[328]=C_h_intern(&lf[328],17,"\003syserror-handler");
lf[329]=C_h_intern(&lf[329],20,"\003syswarnings-enabled");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\005 (in ");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000FWarning: the following toplevel variables are referenced but unbound:\012");
lf[333]=C_h_intern(&lf[333],15,"\003sysread-char-0");
lf[334]=C_h_intern(&lf[334],15,"\003syspeek-char-0");
lf[335]=C_h_intern(&lf[335],21,"\003sysenable-qualifiers");
lf[336]=C_h_intern(&lf[336],17,"\003sysreset-handler");
lf[337]=C_h_intern(&lf[337],28,"\003syssharp-comma-reader-ctors");
lf[338]=C_h_intern(&lf[338],18,"define-reader-ctor");
lf[339]=C_h_intern(&lf[339],18,"\003sysuser-read-hook");
lf[340]=C_h_intern(&lf[340],9,"read-char");
lf[341]=C_h_intern(&lf[341],14,"\003sysread-error");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000!invalid sharp-comma external form");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000!undefined sharp-comma constructor");
lf[346]=C_h_intern(&lf[346],19,"print-error-message");
lf[347]=C_h_intern(&lf[347],22,"with-exception-handler");
lf[349]=C_h_intern(&lf[349],6,"\003sysgc");
lf[351]=C_h_intern(&lf[351],13,"thread-yield!");
lf[354]=C_h_intern(&lf[354],17,"open-input-string");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000(Error: not enough room for result string");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\010No error");
lf[365]=C_h_intern(&lf[365],15,"\003sysmake-string");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\004#;> ");
lf[367]=C_h_intern(&lf[367],14,"make-parameter");
lf[368]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007\000srfi-8\376\003\000\000\002\376\001\000\000\007\000srfi-6\376\003\000\000\002\376\001\000\000\007\000srfi-2\376\003\000\000\002\376\001\000\000\007\000srfi-0\376\003\000\000\002\376\001\000\000\010\000s"
"rfi-10\376\003\000\000\002\376\001\000\000\007\000srfi-9\376\003\000\000\002\376\001\000\000\010\000srfi-55\376\003\000\000\002\376\001\000\000\010\000srfi-61\376\377\016");
lf[369]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\014dynamic-wind\376\003\000\000\002\376\001\000\000\006values\376\003\000\000\002\376\001\000\000\020call-with-values\376\003\000\000\002\376\001\000\000\004eval\376\003"
"\000\000\002\376\001\000\000\031scheme-report-environment\376\003\000\000\002\376\001\000\000\020null-environment\376\003\000\000\002\376\001\000\000\027interaction"
"-environment\376\377\016");
lf[370]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003not\376\003\000\000\002\376\001\000\000\010boolean\077\376\003\000\000\002\376\001\000\000\003eq\077\376\003\000\000\002\376\001\000\000\004eqv\077\376\003\000\000\002\376\001\000\000\006equal\077\376\003\000\000\002\376"
"\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\004cons\376\003\000\000\002\376\001\000\000\003car\376\003\000\000\002\376\001\000\000\003cdr\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\004cadr\376\003\000"
"\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\004cddr\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\005caadr\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\005"
"caddr\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\005cddar\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376\001\000\000\006caaaa"
"r\376\003\000\000\002\376\001\000\000\006caaadr\376\003\000\000\002\376\001\000\000\006caadar\376\003\000\000\002\376\001\000\000\006caaddr\376\003\000\000\002\376\001\000\000\006cadaar\376\003\000\000\002\376\001\000\000\006cadad"
"r\376\003\000\000\002\376\001\000\000\006cadddr\376\003\000\000\002\376\001\000\000\006cdaaar\376\003\000\000\002\376\001\000\000\006cdaadr\376\003\000\000\002\376\001\000\000\006cdadar\376\003\000\000\002\376\001\000\000\006cdadd"
"r\376\003\000\000\002\376\001\000\000\006cddaar\376\003\000\000\002\376\001\000\000\006cddadr\376\003\000\000\002\376\001\000\000\006cdddar\376\003\000\000\002\376\001\000\000\006cddddr\376\003\000\000\002\376\001\000\000\010set-c"
"ar!\376\003\000\000\002\376\001\000\000\010set-cdr!\376\003\000\000\002\376\001\000\000\005null\077\376\003\000\000\002\376\001\000\000\005list\077\376\003\000\000\002\376\001\000\000\004list\376\003\000\000\002\376\001\000\000\006lengt"
"h\376\003\000\000\002\376\001\000\000\011list-tail\376\003\000\000\002\376\001\000\000\010list-ref\376\003\000\000\002\376\001\000\000\006append\376\003\000\000\002\376\001\000\000\007reverse\376\003\000\000\002\376\001\000\000"
"\004memq\376\003\000\000\002\376\001\000\000\004memv\376\003\000\000\002\376\001\000\000\006member\376\003\000\000\002\376\001\000\000\004assq\376\003\000\000\002\376\001\000\000\004assv\376\003\000\000\002\376\001\000\000\005assoc\376\003"
"\000\000\002\376\001\000\000\007symbol\077\376\003\000\000\002\376\001\000\000\016symbol->string\376\003\000\000\002\376\001\000\000\016string->symbol\376\003\000\000\002\376\001\000\000\007number\077"
"\376\003\000\000\002\376\001\000\000\010integer\077\376\003\000\000\002\376\001\000\000\006exact\077\376\003\000\000\002\376\001\000\000\005real\077\376\003\000\000\002\376\001\000\000\010complex\077\376\003\000\000\002\376\001\000\000\010ine"
"xact\077\376\003\000\000\002\376\001\000\000\011rational\077\376\003\000\000\002\376\001\000\000\005zero\077\376\003\000\000\002\376\001\000\000\004odd\077\376\003\000\000\002\376\001\000\000\005even\077\376\003\000\000\002\376\001\000\000\011po"
"sitive\077\376\003\000\000\002\376\001\000\000\011negative\077\376\003\000\000\002\376\001\000\000\003max\376\003\000\000\002\376\001\000\000\003min\376\003\000\000\002\376\001\000\000\001+\376\003\000\000\002\376\001\000\000\001-\376\003\000\000\002\376"
"\001\000\000\001*\376\003\000\000\002\376\001\000\000\001/\376\003\000\000\002\376\001\000\000\001=\376\003\000\000\002\376\001\000\000\001>\376\003\000\000\002\376\001\000\000\001<\376\003\000\000\002\376\001\000\000\002>=\376\003\000\000\002\376\001\000\000\002<=\376\003\000\000\002\376\001"
"\000\000\010quotient\376\003\000\000\002\376\001\000\000\011remainder\376\003\000\000\002\376\001\000\000\006modulo\376\003\000\000\002\376\001\000\000\003gcd\376\003\000\000\002\376\001\000\000\003lcm\376\003\000\000\002\376\001\000"
"\000\003abs\376\003\000\000\002\376\001\000\000\005floor\376\003\000\000\002\376\001\000\000\007ceiling\376\003\000\000\002\376\001\000\000\010truncate\376\003\000\000\002\376\001\000\000\005round\376\003\000\000\002\376\001\000\000\016"
"exact->inexact\376\003\000\000\002\376\001\000\000\016inexact->exact\376\003\000\000\002\376\001\000\000\003exp\376\003\000\000\002\376\001\000\000\003log\376\003\000\000\002\376\001\000\000\004expt\376\003"
"\000\000\002\376\001\000\000\004sqrt\376\003\000\000\002\376\001\000\000\003sin\376\003\000\000\002\376\001\000\000\003cos\376\003\000\000\002\376\001\000\000\003tan\376\003\000\000\002\376\001\000\000\004asin\376\003\000\000\002\376\001\000\000\004acos\376"
"\003\000\000\002\376\001\000\000\004atan\376\003\000\000\002\376\001\000\000\016number->string\376\003\000\000\002\376\001\000\000\016string->number\376\003\000\000\002\376\001\000\000\005char\077\376\003\000\000"
"\002\376\001\000\000\006char=\077\376\003\000\000\002\376\001\000\000\006char>\077\376\003\000\000\002\376\001\000\000\006char<\077\376\003\000\000\002\376\001\000\000\007char>=\077\376\003\000\000\002\376\001\000\000\007char<=\077\376\003"
"\000\000\002\376\001\000\000\011char-ci=\077\376\003\000\000\002\376\001\000\000\011char-ci<\077\376\003\000\000\002\376\001\000\000\011char-ci>\077\376\003\000\000\002\376\001\000\000\012char-ci>=\077\376\003\000\000\002"
"\376\001\000\000\012char-ci<=\077\376\003\000\000\002\376\001\000\000\020char-alphabetic\077\376\003\000\000\002\376\001\000\000\020char-whitespace\077\376\003\000\000\002\376\001\000\000\015cha"
"r-numeric\077\376\003\000\000\002\376\001\000\000\020char-upper-case\077\376\003\000\000\002\376\001\000\000\020char-lower-case\077\376\003\000\000\002\376\001\000\000\013char-upc"
"ase\376\003\000\000\002\376\001\000\000\015char-downcase\376\003\000\000\002\376\001\000\000\015char->integer\376\003\000\000\002\376\001\000\000\015integer->char\376\003\000\000\002\376\001\000"
"\000\007string\077\376\003\000\000\002\376\001\000\000\010string=\077\376\003\000\000\002\376\001\000\000\010string>\077\376\003\000\000\002\376\001\000\000\010string<\077\376\003\000\000\002\376\001\000\000\011string>"
"=\077\376\003\000\000\002\376\001\000\000\011string<=\077\376\003\000\000\002\376\001\000\000\013string-ci=\077\376\003\000\000\002\376\001\000\000\013string-ci<\077\376\003\000\000\002\376\001\000\000\013string-"
"ci>\077\376\003\000\000\002\376\001\000\000\014string-ci>=\077\376\003\000\000\002\376\001\000\000\014string-ci<=\077\376\003\000\000\002\376\001\000\000\013make-string\376\003\000\000\002\376\001\000\000\015s"
"tring-length\376\003\000\000\002\376\001\000\000\012string-ref\376\003\000\000\002\376\001\000\000\013string-set!\376\003\000\000\002\376\001\000\000\015string-append\376\003\000\000"
"\002\376\001\000\000\013string-copy\376\003\000\000\002\376\001\000\000\014string->list\376\003\000\000\002\376\001\000\000\014list->string\376\003\000\000\002\376\001\000\000\011substring"
"\376\003\000\000\002\376\001\000\000\014string-fill!\376\003\000\000\002\376\001\000\000\007vector\077\376\003\000\000\002\376\001\000\000\013make-vector\376\003\000\000\002\376\001\000\000\012vector-ref"
"\376\003\000\000\002\376\001\000\000\013vector-set!\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\006vector\376\003\000\000\002\376\001\000\000\015vector-length\376\003\000\000"
"\002\376\001\000\000\014vector->list\376\003\000\000\002\376\001\000\000\014list->vector\376\003\000\000\002\376\001\000\000\014vector-fill!\376\003\000\000\002\376\001\000\000\012procedur"
"e\077\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\005apply\376\003\000\000\002\376\001\000\000\005force\376\003\000\000\002\376\001\000\000\036call-wi"
"th-current-continuation\376\003\000\000\002\376\001\000\000\013input-port\077\376\003\000\000\002\376\001\000\000\014output-port\077\376\003\000\000\002\376\001\000\000\022curr"
"ent-input-port\376\003\000\000\002\376\001\000\000\023current-output-port\376\003\000\000\002\376\001\000\000\024call-with-input-file\376\003\000\000\002\376\001"
"\000\000\025call-with-output-file\376\003\000\000\002\376\001\000\000\017open-input-file\376\003\000\000\002\376\001\000\000\020open-output-file\376\003\000\000\002"
"\376\001\000\000\020close-input-port\376\003\000\000\002\376\001\000\000\021close-output-port\376\003\000\000\002\376\001\000\000\004load\376\003\000\000\002\376\001\000\000\004read\376\003\000\000"
"\002\376\001\000\000\013eof-object\077\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000\002\376\001\000\000\011peek-char\376\003\000\000\002\376\001\000\000\005write\376\003\000\000\002\376\001\000\000\007"
"display\376\003\000\000\002\376\001\000\000\012write-char\376\003\000\000\002\376\001\000\000\007newline\376\003\000\000\002\376\001\000\000\024with-input-from-file\376\003\000\000\002\376"
"\001\000\000\023with-output-to-file\376\003\000\000\002\376\001\000\000\024\003syscall-with-values\376\003\000\000\002\376\001\000\000\012\003sysvalues\376\003\000\000\002\376\001"
"\000\000\020\003sysdynamic-wind\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\003\000\000\002\376\001\000\000\020\003syslist->vector\376\003\000\000\002\376\001\000\000\010\003syslis"
"t\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\020\003sysmake-promise\376\377\016");
lf[371]=C_h_intern(&lf[371],18,"\003sysnumber->string");
lf[372]=C_h_intern(&lf[372],5,"error");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid extension version");
lf[374]=C_h_intern(&lf[374],7,"version");
lf[375]=C_h_intern(&lf[375],2,"id");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\0003installed extension does not match required version");
lf[377]=C_h_intern(&lf[377],9,"string>=\077");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\035invalid version specification");
lf[379]=C_h_intern(&lf[379],12,"list->vector");
lf[380]=C_h_intern(&lf[380],18,"\003sysstring->symbol");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\005srfi-");
lf[382]=C_h_intern(&lf[382],4,"srfi");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\014lib/chicken/");
lf[384]=C_h_intern(&lf[384],24,"get-environment-variable");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\022CHICKEN_REPOSITORY");
lf[386]=C_h_intern(&lf[386],14,"build-platform");
lf[387]=C_h_intern(&lf[387],7,"windows");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\004.dll");
lf[389]=C_h_intern(&lf[389],6,"macosx");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\006.dylib");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\003.sl");
lf[392]=C_h_intern(&lf[392],4,"hpux");
lf[393]=C_h_intern(&lf[393],4,"hppa");
lf[394]=C_h_intern(&lf[394],12,"machine-type");
lf[395]=C_h_intern(&lf[395],16,"software-version");
lf[396]=C_h_intern(&lf[396],13,"software-type");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\012C_toplevel");
lf[398]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
C_register_lf2(lf,402,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3339,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_expand_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3337 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3339,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! d ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3341,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! core-library-modules ...) */,lf[4]);
t4=C_set_block_item(lf[5] /* explicit-library-modules */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate(&lf[6] /* (set! constant103 ...) */,lf[7]);
t6=C_mutate(&lf[8] /* (set! constant115 ...) */,lf[9]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3372,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 129  get-environment-variable */
t8=*((C_word*)lf[384]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[401]);}

/* k3370 in k3337 */
static void C_ccall f_3372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3375,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(C_word)C_block_size(t1);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_subchar(t1,t4);
t6=(C_word)C_u_i_memq(t5,lf[398]);
t7=(C_truep(t6)?lf[399]:lf[400]);
/* eval.scm: 130  ##sys#string-append */
t8=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t2,t1,t7);}
else{
t3=t2;
f_3375(2,t3,C_SCHEME_FALSE);}}

/* k3373 in k3370 in k3337 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3375,2,t0,t1);}
t2=C_mutate((C_word*)lf[10]+1 /* (set! chicken-prefix ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3376,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[12]+1 /* (set! chicken-home ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3403,tmp=(C_word)a,a+=2,tmp));
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_mutate((C_word*)lf[15]+1 /* (set! hash-symbol ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3415,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=C_mutate((C_word*)lf[16]+1 /* (set! hash-table-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3430,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[17]+1 /* (set! hash-table-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3485,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[18]+1 /* (set! hash-table-update! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3545,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[19]+1 /* (set! hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3565,tmp=(C_word)a,a+=2,tmp));
t13=(C_word)C_slot(lf[21],C_fix(0));
t14=C_mutate((C_word*)lf[22]+1 /* (set! hash-table-location ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3611,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=C_set_block_item(lf[23] /* eval-environment */,0,C_SCHEME_FALSE);
t16=C_set_block_item(lf[24] /* environment-is-mutable */,0,C_SCHEME_FALSE);
t17=C_mutate((C_word*)lf[25]+1 /* (set! eval-decorator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3671,tmp=(C_word)a,a+=2,tmp));
t18=C_set_block_item(lf[31] /* unbound-in-eval */,0,C_SCHEME_FALSE);
t19=C_set_block_item(lf[32] /* eval-debug-level */,0,C_fix(1));
t20=*((C_word*)lf[28]+1);
t21=*((C_word*)lf[33]+1);
t22=*((C_word*)lf[29]+1);
t23=*((C_word*)lf[27]+1);
t24=*((C_word*)lf[34]+1);
t25=(C_word)C_slot(lf[21],C_fix(0));
t26=*((C_word*)lf[35]+1);
t27=C_mutate((C_word*)lf[36]+1 /* (set! compile-to-closure ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3715,a[2]=t21,a[3]=t25,tmp=(C_word)a,a+=4,tmp));
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6610,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10242,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 816  make-parameter */
t30=*((C_word*)lf[367]+1);
((C_proc3)(void*)(*((C_word*)t30+1)))(3,t30,t28,t29);}

/* a10241 in k3373 in k3370 in k3337 */
static void C_ccall f_10242(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_10242r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_10242r(t0,t1,t2,t3);}}

static void C_ccall f_10242r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(10);
t4=*((C_word*)lf[24]+1);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10246,a[2]=t2,a[3]=t1,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t9=(C_word)C_slot(t3,C_fix(0));
if(C_truep(t9)){
t10=(C_word)C_i_check_structure(t9,lf[288]);
t11=(C_word)C_slot(t9,C_fix(1));
t12=C_set_block_item(t7,0,t11);
t13=(C_word)C_slot(t9,C_fix(2));
t14=C_set_block_item(t5,0,t13);
t15=t8;
f_10246(t15,t14);}
else{
t10=t8;
f_10246(t10,C_SCHEME_UNDEFINED);}}
else{
t9=t8;
f_10246(t9,C_SCHEME_UNDEFINED);}}

/* k10244 in a10241 in k3373 in k3370 in k3337 */
static void C_fcall f_10246(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10246,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10252,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10254,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10261,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10271,a[2]=t9,a[3]=t7,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* ##sys#dynamic-wind */
t14=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t10,t11,t12,t13);}

/* a10270 in k10244 in a10241 in k3373 in k3370 in k3337 */
static void C_ccall f_10271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10271,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[24]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[23]+1));
t4=C_mutate((C_word*)lf[24]+1 /* (set! environment-is-mutable ...) */,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[23]+1 /* (set! eval-environment ...) */,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* a10260 in k10244 in a10241 in k3373 in k3370 in k3337 */
static void C_ccall f_10261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10269,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 828  ##sys#current-environment */
t3=*((C_word*)lf[109]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10267 in a10260 in k10244 in a10241 in k3373 in k3370 in k3337 */
static void C_ccall f_10269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 828  ##sys#compile-to-closure */
t2=*((C_word*)lf[36]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* a10253 in k10244 in a10241 in k3373 in k3370 in k3337 */
static void C_ccall f_10254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10254,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[24]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[23]+1));
t4=C_mutate((C_word*)lf[24]+1 /* (set! environment-is-mutable ...) */,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[23]+1 /* (set! eval-environment ...) */,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* k10250 in k10244 in a10241 in k3373 in k3370 in k3337 */
static void C_ccall f_10252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6610,2,t0,t1);}
t2=C_mutate((C_word*)lf[168]+1 /* (set! eval-handler ...) */,t1);
t3=C_mutate((C_word*)lf[169]+1 /* (set! eval-handler ...) */,*((C_word*)lf[168]+1));
t4=C_mutate((C_word*)lf[170]+1 /* (set! eval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6613,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[33]+1);
t6=C_mutate((C_word*)lf[96]+1 /* (set! decompose-lambda-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6623,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6705,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fudge(C_fix(13));
/* eval.scm: 860  make-parameter */
t9=*((C_word*)lf[367]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6705,2,t0,t1);}
t2=C_mutate((C_word*)lf[173]+1 /* (set! load-verbose ...) */,t1);
t3=C_mutate((C_word*)lf[174]+1 /* (set! abort-load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6707,tmp=(C_word)a,a+=2,tmp));
t4=C_set_block_item(lf[175] /* current-source-filename */,0,C_SCHEME_FALSE);
t5=C_mutate((C_word*)lf[176]+1 /* (set! current-load-path ...) */,lf[177]);
t6=C_set_block_item(lf[178] /* dload-disabled */,0,C_SCHEME_FALSE);
t7=C_mutate((C_word*)lf[179]+1 /* (set! set-dynamic-load-mode! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6713,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[187]+1);
t9=*((C_word*)lf[28]+1);
t10=*((C_word*)lf[35]+1);
t11=*((C_word*)lf[188]+1);
t12=*((C_word*)lf[189]+1);
t13=*((C_word*)lf[170]+1);
t14=*((C_word*)lf[190]+1);
t15=*((C_word*)lf[191]+1);
t16=*((C_word*)lf[192]+1);
t17=*((C_word*)lf[173]+1);
t18=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6786,a[2]=((C_word*)t0)[2],a[3]=t17,a[4]=t10,a[5]=t12,a[6]=t14,a[7]=t15,a[8]=t9,a[9]=t11,a[10]=t8,a[11]=t13,tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 894  ##sys#make-c-string */
t19=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t18,lf[397]);}

/* k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6788,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[193]+1 /* (set! load ...) */,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp));
t4=C_mutate((C_word*)lf[198]+1 /* (set! load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7230,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[217]+1 /* (set! load-relative ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7252,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[218]+1 /* (set! load-noisily ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7288,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7314,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10236,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 987  software-type */
t9=*((C_word*)lf[396]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}

/* k10234 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10236,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[387]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_7314(t3,lf[388]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10232,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 988  software-version */
t4=*((C_word*)lf[395]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10230 in k10234 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10232,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[389]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_7314(t3,lf[390]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10214,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10228,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 989  software-version */
t5=*((C_word*)lf[395]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k10226 in k10230 in k10234 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10228,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[392]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10224,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 990  machine-type */
t4=*((C_word*)lf[394]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_10214(t3,C_SCHEME_FALSE);}}

/* k10222 in k10226 in k10230 in k10234 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10214(t2,(C_word)C_eqp(t1,lf[393]));}

/* k10212 in k10230 in k10234 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_10214(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7314(t2,(C_truep(t1)?lf[391]:lf[6]));}

/* k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_7314(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7314,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[223]+1 /* (set! load-library-extension ...) */,t1);
t3=C_mutate((C_word*)lf[212]+1 /* (set! load-dynamic-extension ...) */,lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7319,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 996  build-platform */
t5=*((C_word*)lf[386]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7319,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[224]);
t3=(C_truep(t2)?lf[225]:lf[226]);
t4=C_mutate((C_word*)lf[227]+1 /* (set! default-dynamic-load-libraries ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7326,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10184,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10192,tmp=(C_word)a,a+=2,tmp);
/* map */
t8=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,*((C_word*)lf[227]+1));}

/* a10191 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10192(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10192,3,t0,t1,t2);}
/* ##sys#string-append */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[223]+1));}

/* k10182 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10186,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1001 make-parameter */
t3=*((C_word*)lf[367]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a10185 in k10182 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10186(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10186,3,t0,t1,t2);}
t3=(C_word)C_i_check_list(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7326,2,t0,t1);}
t2=C_mutate((C_word*)lf[228]+1 /* (set! dynamic-load-libraries ...) */,t1);
t3=*((C_word*)lf[173]+1);
t4=*((C_word*)lf[192]+1);
t5=*((C_word*)lf[228]+1);
t6=*((C_word*)lf[35]+1);
t7=C_mutate((C_word*)lf[229]+1 /* (set! load-library ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7328,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[236]+1 /* (set! load-library ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7434,tmp=(C_word)a,a+=2,tmp));
t9=*((C_word*)lf[33]+1);
t10=*((C_word*)lf[192]+1);
t11=C_mutate((C_word*)lf[238]+1 /* (set! canonicalize-extension-path ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7519,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7679,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10153,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1089 get-environment-variable */
t14=*((C_word*)lf[384]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,lf[385]);}

/* k10151 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10156,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_10156(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10159,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10169,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10173,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_fudge(C_fix(42));
t7=(C_truep(t6)?t6:C_fix(4));
/* eval.scm: 1093 ##sys#number->string */
t8=*((C_word*)lf[371]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t5,t7);}}

/* k10171 in k10151 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1091 ##sys#string-append */
t2=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[383],t1);}

/* k10167 in k10151 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1090 ##sys#chicken-prefix */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10157 in k10151 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10159,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_10156(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_EGG_HOME),C_fix(0));}}

/* k10154 in k10151 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1088 make-parameter */
t2=*((C_word*)lf[367]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7679,2,t0,t1);}
t2=C_mutate((C_word*)lf[244]+1 /* (set! repository-path ...) */,t1);
t3=C_mutate((C_word*)lf[245]+1 /* (set! repository-path ...) */,*((C_word*)lf[244]+1));
t4=C_set_block_item(lf[246] /* setup-mode */,0,C_SCHEME_FALSE);
t5=*((C_word*)lf[247]+1);
t6=*((C_word*)lf[192]+1);
t7=C_mutate((C_word*)lf[248]+1 /* (set! find-extension ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7683,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t8=C_set_block_item(lf[253] /* loaded-extensions */,0,C_SCHEME_END_OF_LIST);
t9=*((C_word*)lf[254]+1);
t10=C_mutate((C_word*)lf[255]+1 /* (set! load-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7782,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[257]+1 /* (set! provide ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7850,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[258]+1 /* (set! provide ...) */,*((C_word*)lf[257]+1));
t13=C_mutate((C_word*)lf[259]+1 /* (set! provided? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7870,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[260]+1 /* (set! provided? ...) */,*((C_word*)lf[259]+1));
t15=C_mutate((C_word*)lf[128]+1 /* (set! require ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7884,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[261]+1 /* (set! require ...) */,*((C_word*)lf[128]+1));
t17=*((C_word*)lf[34]+1);
t18=*((C_word*)lf[247]+1);
t19=*((C_word*)lf[192]+1);
t20=*((C_word*)lf[187]+1);
t21=C_mutate((C_word*)lf[262]+1 /* (set! extension-information ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7897,a[2]=t19,a[3]=t18,a[4]=t20,a[5]=t17,tmp=(C_word)a,a+=6,tmp));
t22=C_mutate((C_word*)lf[266]+1 /* (set! extension-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7930,tmp=(C_word)a,a+=2,tmp));
t23=*((C_word*)lf[34]+1);
t24=*((C_word*)lf[187]+1);
t25=C_mutate((C_word*)lf[129]+1 /* (set! lookup-runtime-requirements ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7936,tmp=(C_word)a,a+=2,tmp));
t26=*((C_word*)lf[268]+1);
t27=C_mutate((C_word*)lf[132]+1 /* (set! do-the-right-thing ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7985,a[2]=t26,tmp=(C_word)a,a+=3,tmp));
t28=C_set_block_item(lf[281] /* extension-specifiers */,0,C_SCHEME_END_OF_LIST);
t29=C_mutate((C_word*)lf[284]+1 /* (set! set-extension-specifier! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8492,tmp=(C_word)a,a+=2,tmp));
t30=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8531,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t31=*((C_word*)lf[379]+1);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10099,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1300 set-extension-specifier! */
t33=*((C_word*)lf[284]+1);
((C_proc4)(void*)(*((C_word*)t33+1)))(4,t33,t30,lf[382],t32);}

/* a10098 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10099,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10107,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10113,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_10113(t9,t4,t5);}

/* loop in a10098 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_10113(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10113,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_check_exact_2(t3,lf[278]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10133,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10145,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10149,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1310 number->string */
C_number_to_string(3,0,t7,t3);}}

/* k10147 in loop in a10098 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1310 ##sys#string-append */
t2=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[381],t1);}

/* k10143 in loop in a10098 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1310 ##sys#string->symbol */
t2=*((C_word*)lf[380]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10131 in loop in a10098 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10137,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1311 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10113(t4,t2,t3);}

/* k10135 in k10131 in loop in a10098 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10137,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10105 in a10098 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1304 list->vector */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8534,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10002,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1316 set-extension-specifier! */
t4=*((C_word*)lf[284]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[374],t3);}

/* a10001 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10002,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10005,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10039,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t6=(C_word)C_i_length(t2);
t7=t5;
f_10039(t7,(C_word)C_eqp(C_fix(3),t6));}
else{
t6=t5;
f_10039(t6,C_SCHEME_FALSE);}}

/* k10037 in a10001 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_10039(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10039,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10042,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
/* eval.scm: 1325 extension-information */
t4=*((C_word*)lf[266]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
/* eval.scm: 1330 ##sys#syntax-error-hook */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],lf[378],((C_word*)t0)[3]);}}

/* k10040 in k10037 in a10001 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10042,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_assq(lf[374],t1):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10048,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10051,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* eval.scm: 1327 ->string */
f_10005(t5,t6);}
else{
t5=t4;
f_10051(2,t5,C_SCHEME_FALSE);}}

/* k10063 in k10040 in k10037 in a10001 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10069,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
/* eval.scm: 1327 ->string */
f_10005(t2,t3);}

/* k10067 in k10063 in k10040 in k10037 in a10001 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1327 string>=? */
t2=*((C_word*)lf[377]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10049 in k10040 in k10037 in a10001 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10048(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
/* eval.scm: 1328 error */
t3=*((C_word*)lf[372]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[376],*((C_word*)lf[375]+1),((C_word*)t0)[2],t2);}}

/* k10046 in k10040 in k10037 in a10001 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[375]+1));}

/* ->string in a10001 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_10005(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10005,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* eval.scm: 1322 ##sys#number->string */
t3=*((C_word*)lf[371]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
/* eval.scm: 1323 error */
t3=*((C_word*)lf[372]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[373],t2);}}}}

/* k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8534,2,t0,t1);}
t2=*((C_word*)lf[285]+1);
t3=C_mutate((C_word*)lf[234]+1 /* (set! string->c-identifier ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8536,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8592,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1349 make-vector */
t5=*((C_word*)lf[297]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8592,2,t0,t1);}
t2=C_mutate(&lf[286] /* (set! r4rs-environment ...) */,t1);
t3=lf[287] /* r5rs-environment */ =C_SCHEME_FALSE;;
t4=(C_word)C_a_i_record(&a,3,lf[288],C_SCHEME_FALSE,C_SCHEME_TRUE);
t5=C_mutate(&lf[289] /* (set! interaction-environment ...) */,t4);
t6=C_mutate((C_word*)lf[290]+1 /* (set! environment? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8599,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[291]+1 /* (set! copy-env-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8615,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[292]+1 /* (set! environment-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8723,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[294]+1 /* (set! interaction-environment ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8842,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[295]+1 /* (set! scheme-report-environment ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8845,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[297]+1);
t12=C_mutate((C_word*)lf[298]+1 /* (set! null-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8889,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8927,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8943,a[2]=t13,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10000,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1433 initb */
f_8927(t15,lf[286]);}

/* k9998 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_10000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[370]);}

/* k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1454 ##sys#copy-env-table */
t3=*((C_word*)lf[291]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[286],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8947,2,t0,t1);}
t2=C_mutate(&lf[287] /* (set! r5rs-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8950,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9996,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1456 initb */
f_8927(t4,lf[287]);}

/* k9994 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[369]);}

/* k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8954,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1463 chicken-home */
t3=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8954,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_list(&a,1,t1):C_SCHEME_END_OF_LIST);
t3=C_mutate((C_word*)lf[251]+1 /* (set! include-pathnames ...) */,t2);
t4=*((C_word*)lf[192]+1);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8960,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[300]+1 /* (set! resolve-include-filename ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8979,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[35]+1);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9121,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9145,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=C_mutate((C_word*)lf[195]+1 /* (set! display-times ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9166,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9221,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1532 append */
t12=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,lf[368],*((C_word*)lf[143]+1));}

/* k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9221,2,t0,t1);}
t2=C_mutate((C_word*)lf[143]+1 /* (set! features ...) */,t1);
t3=C_set_block_item(lf[308] /* repl-eval-hook */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[309] /* repl-print-length-limit */,0,C_SCHEME_FALSE);
t5=C_set_block_item(lf[310] /* repl-read-hook */,0,C_SCHEME_FALSE);
t6=C_mutate((C_word*)lf[311]+1 /* (set! repl-print-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9226,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9243,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9988,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1546 make-parameter */
t9=*((C_word*)lf[367]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* a9987 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9988,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[366]);}

/* k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9243,2,t0,t1);}
t2=C_mutate((C_word*)lf[315]+1 /* (set! repl-prompt ...) */,t1);
t3=*((C_word*)lf[315]+1);
t4=C_mutate((C_word*)lf[316]+1 /* (set! read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9245,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[319]+1 /* (set! clear-trace-buffer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9261,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[170]+1);
t7=*((C_word*)lf[187]+1);
t8=*((C_word*)lf[203]+1);
t9=*((C_word*)lf[320]+1);
t10=*((C_word*)lf[189]+1);
t11=*((C_word*)lf[173]+1);
t12=*((C_word*)lf[321]+1);
t13=C_mutate((C_word*)lf[322]+1 /* (set! repl ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9264,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t11,a[6]=t9,a[7]=t10,tmp=(C_word)a,a+=8,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9606,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1663 make-vector */
t15=*((C_word*)lf[297]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9606,2,t0,t1);}
t2=C_mutate((C_word*)lf[337]+1 /* (set! sharp-comma-reader-ctors ...) */,t1);
t3=C_mutate((C_word*)lf[338]+1 /* (set! define-reader-ctor ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9608,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[339]+1);
t5=*((C_word*)lf[340]+1);
t6=*((C_word*)lf[187]+1);
t7=C_mutate((C_word*)lf[339]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9617,a[2]=t4,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=lf[344] /* last-error */ =C_SCHEME_FALSE;;
t9=C_mutate(&lf[345] /* (set! run-safe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9692,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[348] /* (set! store-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9751,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[350] /* (set! CHICKEN_yield ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9760,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[352] /* (set! CHICKEN_eval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9772,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[353] /* (set! CHICKEN_eval_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9788,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[355] /* (set! store-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9814,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[357] /* (set! CHICKEN_eval_to_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9827,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[358] /* (set! CHICKEN_eval_string_to_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9853,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[359] /* (set! CHICKEN_apply ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9890,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[360] /* (set! CHICKEN_apply_to_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9906,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[361] /* (set! CHICKEN_read ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9932,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[362] /* (set! CHICKEN_load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9954,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate(&lf[363] /* (set! CHICKEN_get_error_message ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9969,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[26]+1 /* (set! make-lambda-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9979,tmp=(C_word)a,a+=2,tmp));
t23=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_UNDEFINED);}

/* ##sys#make-lambda-info in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9979,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9986,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1794 ##sys#make-string */
t5=*((C_word*)lf[365]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k9984 in ##sys#make-lambda-info in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_string_to_lambdainfo(t1);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* CHICKEN_get_error_message in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9969,4,t0,t1,t2,t3);}
t4=lf[344];
t5=(C_truep(t4)?t4:lf[364]);
/* eval.scm: 1787 store-string */
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_9814(t5,t3,t2));}

/* CHICKEN_load in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9954(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9954,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9958,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k9956 in CHICKEN_load in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9963,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1784 run-safe */
f_9692(((C_word*)t0)[2],t2);}

/* a9962 in k9956 in CHICKEN_load in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9967,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1784 load */
t3=*((C_word*)lf[198]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9965 in a9962 in k9956 in CHICKEN_load in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* CHICKEN_read in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9932,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9936,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9934 in CHICKEN_read in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9936,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9941,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1778 run-safe */
f_9692(((C_word*)t0)[2],t3);}

/* a9940 in k9934 in CHICKEN_read in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9945,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1780 open-input-string */
t3=*((C_word*)lf[354]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9943 in a9940 in k9934 in CHICKEN_read in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1781 read */
t3=*((C_word*)lf[187]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k9950 in k9943 in a9940 in k9934 in CHICKEN_read in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1781 store-result */
f_9751(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_apply_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9906,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9912,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1771 run-safe */
f_9692(t1,t6);}

/* a9911 in CHICKEN_apply_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1773 open-output-string */
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9914 in a9911 in CHICKEN_apply_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9919,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9930,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9928 in k9914 in a9911 in CHICKEN_apply_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1774 write */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9917 in k9914 in a9911 in CHICKEN_apply_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9926,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1775 get-output-string */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9924 in k9917 in k9914 in a9911 in CHICKEN_apply_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1775 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9814(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_apply in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9890,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9896,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1766 run-safe */
f_9692(t1,t5);}

/* a9895 in CHICKEN_apply in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9904,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9902 in a9895 in CHICKEN_apply in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1766 store-result */
f_9751(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval_string_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9853,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9857,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,C_fix(0));}

/* k9855 in CHICKEN_eval_string_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9857,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9862,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1757 run-safe */
f_9692(((C_word*)t0)[2],t4);}

/* a9861 in k9855 in CHICKEN_eval_string_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1759 open-output-string */
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9864 in a9861 in k9855 in CHICKEN_eval_string_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9869,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9880,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9884,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9888,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1760 open-input-string */
t6=*((C_word*)lf[354]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k9886 in k9864 in a9861 in k9855 in CHICKEN_eval_string_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1760 read */
t2=*((C_word*)lf[187]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9882 in k9864 in a9861 in k9855 in CHICKEN_eval_string_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1760 eval */
t2=*((C_word*)lf[170]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9878 in k9864 in a9861 in k9855 in CHICKEN_eval_string_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1760 write */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9867 in k9864 in a9861 in k9855 in CHICKEN_eval_string_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9876,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1761 get-output-string */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9874 in k9867 in k9864 in a9861 in k9855 in CHICKEN_eval_string_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1761 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9814(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_eval_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9827,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9833,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1748 run-safe */
f_9692(t1,t5);}

/* a9832 in CHICKEN_eval_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1750 open-output-string */
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9835 in a9832 in CHICKEN_eval_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9840,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9851,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1751 eval */
t4=*((C_word*)lf[170]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9849 in k9835 in a9832 in CHICKEN_eval_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1751 write */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9838 in k9835 in a9832 in CHICKEN_eval_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9847,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1752 get-output-string */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9845 in k9838 in k9835 in a9832 in CHICKEN_eval_to_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1752 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9814(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* store-string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static C_word C_fcall f_9814(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t2))){
t5=C_mutate(&lf[344] /* (set! last-error ...) */,lf[356]);
return(C_SCHEME_FALSE);}
else{
return((C_word)C_copy_result_string(t1,t3,t4));}}

/* CHICKEN_eval_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9788,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9792,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9790 in CHICKEN_eval_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9792,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9797,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1729 run-safe */
f_9692(((C_word*)t0)[2],t3);}

/* a9796 in k9790 in CHICKEN_eval_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9801,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1731 open-input-string */
t3=*((C_word*)lf[354]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9799 in a9796 in k9790 in CHICKEN_eval_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9812,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1732 read */
t4=*((C_word*)lf[187]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k9810 in k9799 in a9796 in k9790 in CHICKEN_eval_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1732 eval */
t2=*((C_word*)lf[170]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9806 in k9799 in a9796 in k9790 in CHICKEN_eval_string in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1732 store-result */
f_9751(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9772,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9778,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1724 run-safe */
f_9692(t1,t4);}

/* a9777 in CHICKEN_eval in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9786,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1726 eval */
t3=*((C_word*)lf[170]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9784 in a9777 in CHICKEN_eval in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1726 store-result */
f_9751(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_yield in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9766,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1721 run-safe */
f_9692(t1,t2);}

/* a9765 in CHICKEN_yield in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9770,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1721 thread-yield! */
t3=*((C_word*)lf[351]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9768 in a9765 in CHICKEN_yield in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* store-result in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_9751(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9751,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9755,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1715 ##sys#gc */
t5=*((C_word*)lf[349]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_SCHEME_FALSE);}

/* k9753 in store-result in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_store_result(((C_word*)t0)[3],((C_word*)t0)[4]):C_SCHEME_UNDEFINED);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* run-safe in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_9692(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9692,NULL,2,t1,t2);}
t3=lf[344] /* last-error */ =C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9700,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9702,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t6=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a9701 in run-safe in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9702(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9702,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9708,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9727,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[347]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a9726 in a9701 in run-safe in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9733,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9739,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a9738 in a9726 in a9701 in run-safe in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9739(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_9739r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9739r(t0,t1,t2);}}

static void C_ccall f_9739r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9745,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k29973002 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9744 in a9738 in a9726 in a9701 in run-safe in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9745,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a9732 in a9726 in a9701 in run-safe in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9733,2,t0,t1);}
/* eval.scm: 1708 thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a9707 in a9701 in run-safe in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9708(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9708,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9714,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k29973002 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9713 in a9707 in a9701 in run-safe in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9718,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1704 open-output-string */
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9716 in a9713 in a9707 in a9701 in run-safe in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9721,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1705 print-error-message */
t3=*((C_word*)lf[346]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k9719 in k9716 in a9713 in a9707 in a9701 in run-safe in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9725,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1706 get-output-string */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9723 in k9719 in k9716 in a9713 in a9707 in a9701 in run-safe in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[344] /* (set! last-error ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k9698 in run-safe in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9617,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_make_character(44));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9627,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1675 read-char */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* eval.scm: 1687 old */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k9625 in ##sys#user-read-hook in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1676 read */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k9628 in k9625 in ##sys#user-read-hook in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9631,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_nullp(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9644,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_9644(t5,t3);}
else{
t5=(C_word)C_i_listp(t1);
t6=t4;
f_9644(t6,(C_word)C_i_not(t5));}}

/* k9642 in k9628 in k9625 in ##sys#user-read-hook in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_9644(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9644,NULL,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 1679 err */
t2=((C_word*)t0)[5];
f_9631(t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9662,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1683 ##sys#hash-table-ref */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[337]+1),t2);}
else{
/* eval.scm: 1682 err */
t3=((C_word*)t0)[5];
f_9631(t3,((C_word*)t0)[4]);}}}

/* k9660 in k9642 in k9628 in k9625 in ##sys#user-read-hook in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_apply(4,0,((C_word*)t0)[4],t1,t2);}
else{
/* eval.scm: 1686 ##sys#read-error */
t2=*((C_word*)lf[341]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[343],((C_word*)t0)[2]);}}

/* err in k9628 in k9625 in ##sys#user-read-hook in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_9631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9631,NULL,2,t0,t1);}
/* eval.scm: 1677 ##sys#read-error */
t2=*((C_word*)lf[341]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[342],((C_word*)t0)[2]);}

/* define-reader-ctor in k9604 in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9608,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[338]);
/* eval.scm: 1667 ##sys#hash-table-set! */
t5=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[337]+1),t2,t3);}

/* repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9267,tmp=(C_word)a,a+=2,tmp);
t3=*((C_word*)lf[324]+1);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[318]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[323]+1);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9308,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t8,a[11]=t6,a[12]=t4,tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 1576 ##sys#error-handler */
t10=*((C_word*)lf[328]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}

/* k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9311,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 1577 ##sys#reset-handler */
t3=*((C_word*)lf[336]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9311,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[31]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9313,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9319,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9328,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t6,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9393,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9591,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1591 ##sys#dynamic-wind */
t10=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[2],t7,t8,t9);}

/* a9590 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9595,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1655 load-verbose */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k9593 in a9590 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9595,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1 /* (set! unbound-in-eval ...) */,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9599,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1657 ##sys#error-handler */
t4=*((C_word*)lf[328]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9597 in k9593 in a9590 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1658 ##sys#reset-handler */
t2=*((C_word*)lf[336]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9393,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_9399(t5,t1);}

/* loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_9399(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9399,NULL,2,t0,t1);}
t2=f_9313(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9406,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9574,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1614 call-with-current-continuation */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9573 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9574(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9574,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9580,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1616 ##sys#reset-handler */
t4=*((C_word*)lf[336]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9579 in a9573 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9580,2,t0,t1);}
t2=C_set_block_item(lf[194] /* read-error-with-line-number */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[335] /* enable-qualifiers */,0,C_SCHEME_TRUE);
t4=f_9319(((C_word*)t0)[3]);
/* eval.scm: 1621 c */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,C_SCHEME_FALSE);}

/* k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1622 ##sys#read-prompt-hook */
t3=*((C_word*)lf[316]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9412,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[310]+1);
t4=(C_truep(t3)?t3:((C_word*)t0)[2]);
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9412,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9421,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9569,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1625 ##sys#peek-char-0 */
t4=*((C_word*)lf[334]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[324]+1));}}

/* k9567 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(10),t1);
if(C_truep(t2)){
/* eval.scm: 1626 ##sys#read-char-0 */
t3=*((C_word*)lf[333]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],*((C_word*)lf[324]+1));}
else{
t3=((C_word*)t0)[2];
f_9421(2,t3,C_SCHEME_UNDEFINED);}}

/* k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1627 ##sys#clear-trace-buffer */
t3=*((C_word*)lf[319]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9424,2,t0,t1);}
t2=C_set_block_item(lf[31] /* unbound-in-eval */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9430,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9439,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a9438 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9439(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_9439r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9439r(t0,t1,t2);}}

static void C_ccall f_9439r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9443,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(*((C_word*)lf[329]+1))?(C_word)C_i_pairp(*((C_word*)lf[31]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9457,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_9457(t8,t3,*((C_word*)lf[31]+1),C_SCHEME_END_OF_LIST);}
else{
t5=t3;
f_9443(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a9438 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_9457(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9457,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9461,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9473,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1634 ##sys#print */
t6=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[332],C_SCHEME_FALSE,*((C_word*)lf[323]+1));}
else{
t5=t4;
f_9461(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_u_i_caar(t2);
t6=(C_word)C_u_i_memq(t5,t3);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9523,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_9523(2,t8,t6);}
else{
t8=(C_word)C_u_i_caar(t2);
/* eval.scm: 1649 ##sys#symbol-has-toplevel-binding? */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}}

/* k9521 in loop in a9438 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9523,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1650 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9457(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* eval.scm: 1651 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_9457(t5,((C_word*)t0)[3],t2,t4);}}

/* k9471 in loop in a9438 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9476,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9481,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9480 in k9471 in loop in a9438 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9481,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9485,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1639 ##sys#print */
t4=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[331],C_SCHEME_FALSE,*((C_word*)lf[323]+1));}

/* k9483 in a9480 in k9471 in loop in a9438 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* eval.scm: 1640 ##sys#print */
t4=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[323]+1));}

/* k9486 in k9483 in a9480 in k9471 in loop in a9438 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9491,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[2],C_fix(1)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9500,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1642 ##sys#print */
t4=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[330],C_SCHEME_FALSE,*((C_word*)lf[323]+1));}
else{
t3=t2;
f_9491(2,t3,C_SCHEME_UNDEFINED);}}

/* k9498 in k9486 in k9483 in a9480 in k9471 in loop in a9438 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9503,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 1643 ##sys#print */
t4=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[323]+1));}

/* k9501 in k9498 in k9486 in k9483 in a9480 in k9471 in loop in a9438 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1644 ##sys#write-char-0 */
t2=*((C_word*)lf[312]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(41),*((C_word*)lf[323]+1));}

/* k9489 in k9486 in k9483 in a9480 in k9471 in loop in a9438 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1645 ##sys#write-char-0 */
t2=*((C_word*)lf[312]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[323]+1));}

/* k9474 in k9471 in loop in a9438 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1647 ##sys#flush-output */
t2=*((C_word*)lf[317]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[323]+1));}

/* k9459 in loop in a9438 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(9));}

/* k9441 in a9438 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9446,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_i_nullp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9289,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_9289(t6,t4);}
else{
t6=(C_word)C_u_i_car(t3);
t7=t5;
f_9289(t7,(C_word)C_eqp(C_SCHEME_UNDEFINED,t6));}}

/* k9287 in k9441 in a9438 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_9289(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9289,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_9446(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9294,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* a9293 in k9287 in k9441 in a9438 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9294,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[311]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[318]+1));}

/* k9444 in k9441 in a9438 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1653 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9399(t2,((C_word*)t0)[2]);}

/* a9429 in k9422 in k9419 in k9410 in k9407 in k9404 in loop in a9392 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9430,2,t0,t1);}
t2=*((C_word*)lf[308]+1);
t3=(C_truep(t2)?t2:((C_word*)t0)[3]);
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,((C_word*)t0)[2]);}

/* a9327 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9333,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1593 load-verbose */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9331 in a9327 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9333,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1594 load-verbose */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}

/* k9334 in k9331 in a9327 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9341,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1595 ##sys#error-handler */
t3=*((C_word*)lf[328]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* a9340 in k9334 in k9331 in a9327 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9341(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_9341r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9341r(t0,t1,t2,t3);}}

static void C_ccall f_9341r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=f_9319(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9348,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1598 ##sys#print */
t6=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[327],C_SCHEME_FALSE,*((C_word*)lf[323]+1));}

/* k9346 in a9340 in k9334 in k9331 in a9327 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9351,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9388,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1600 ##sys#print */
t4=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[326],C_SCHEME_FALSE,*((C_word*)lf[323]+1));}
else{
t3=t2;
f_9351(2,t3,C_SCHEME_UNDEFINED);}}

/* k9386 in k9346 in a9340 in k9334 in k9331 in a9327 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1601 ##sys#print */
t2=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[323]+1));}

/* k9349 in k9346 in a9340 in k9334 in k9331 in a9327 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9354,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9363,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=t3;
f_9363(t5,(C_word)C_i_nullp(t4));}
else{
t4=t3;
f_9363(t4,C_SCHEME_FALSE);}}

/* k9361 in k9349 in k9346 in a9340 in k9334 in k9331 in a9327 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_9363(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9363,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1604 ##sys#print */
t3=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[325],C_SCHEME_FALSE,*((C_word*)lf[323]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1607 ##sys#write-char-0 */
t3=*((C_word*)lf[312]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),*((C_word*)lf[323]+1));}}

/* k9370 in k9361 in k9349 in k9346 in a9340 in k9334 in k9331 in a9327 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1608 write-err */
f_9267(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9364 in k9361 in k9349 in k9346 in a9340 in k9334 in k9331 in a9327 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1605 write-err */
f_9267(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9352 in k9349 in k9346 in a9340 in k9334 in k9331 in a9327 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9357,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1609 print-call-chain */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[323]+1));}

/* k9355 in k9352 in k9349 in k9346 in a9340 in k9334 in k9331 in a9327 in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1610 flush-output */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[323]+1));}

/* resetports in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static C_word C_fcall f_9319(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate((C_word*)lf[324]+1 /* (set! standard-input ...) */,((C_word*)((C_word*)t0)[4])[1]);
t2=C_mutate((C_word*)lf[318]+1 /* (set! standard-output ...) */,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate((C_word*)lf[323]+1 /* (set! standard-error ...) */,((C_word*)((C_word*)t0)[2])[1]);
return(t3);}

/* saveports in k9309 in k9306 in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static C_word C_fcall f_9313(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[324]+1));
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[318]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[323]+1));
return(t3);}

/* write-err in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_9267(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9267,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9273,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a9272 in write-err in repl in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9273(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9273,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[311]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[323]+1));}

/* ##sys#clear-trace-buffer in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9261,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2782(C_SCHEME_UNDEFINED));}

/* ##sys#read-prompt-hook in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9249,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9256,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9259,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1551 repl-prompt */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k9257 in ##sys#read-prompt-hook in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k9254 in ##sys#read-prompt-hook in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1551 ##sys#print */
t2=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,*((C_word*)lf[318]+1));}

/* k9247 in ##sys#read-prompt-hook in k9241 in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1552 ##sys#flush-output */
t2=*((C_word*)lf[317]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[318]+1));}

/* ##sys#repl-print-hook in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9226,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9230,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9235,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1543 ##sys#with-print-length-limit */
t6=*((C_word*)lf[314]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[309]+1),t5);}

/* a9234 in ##sys#repl-print-hook in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9235,2,t0,t1);}
/* ##sys#print */
t2=*((C_word*)lf[313]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* k9228 in ##sys#repl-print-hook in k9219 in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1544 ##sys#write-char-0 */
t2=*((C_word*)lf[312]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##sys#display-times in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9166(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9166,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9170,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1517 display-rj */
t5=((C_word*)t0)[2];
f_9145(t5,t3,t4,C_fix(8));}

/* k9168 in ##sys#display-times in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1518 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[307]);}

/* k9171 in k9168 in ##sys#display-times in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1519 display-rj */
t4=((C_word*)t0)[2];
f_9145(t4,t2,t3,C_fix(8));}

/* k9174 in k9171 in k9168 in ##sys#display-times in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1520 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[306]);}

/* k9177 in k9174 in k9171 in k9168 in ##sys#display-times in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
/* eval.scm: 1521 display-rj */
t4=((C_word*)t0)[2];
f_9145(t4,t2,t3,C_fix(8));}

/* k9180 in k9177 in k9174 in k9171 in k9168 in ##sys#display-times in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1522 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[305]);}

/* k9183 in k9180 in k9177 in k9174 in k9171 in k9168 in ##sys#display-times in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
/* eval.scm: 1523 display-rj */
t4=((C_word*)t0)[2];
f_9145(t4,t2,t3,C_fix(8));}

/* k9186 in k9183 in k9180 in k9177 in k9174 in k9171 in k9168 in ##sys#display-times in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1524 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[304]);}

/* k9189 in k9186 in k9183 in k9180 in k9177 in k9174 in k9171 in k9168 in ##sys#display-times in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9194,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* eval.scm: 1525 display-rj */
t4=((C_word*)t0)[2];
f_9145(t4,t2,t3,C_fix(8));}

/* k9192 in k9189 in k9186 in k9183 in k9180 in k9177 in k9174 in k9171 in k9168 in ##sys#display-times in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1526 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[303]);}

/* display-rj in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_9145(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9145,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9149,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_zerop(t2))){
t5=t4;
f_9149(2,t5,lf[302]);}
else{
/* eval.scm: 1512 number->string */
C_number_to_string(3,0,t4,t2);}}

/* k9147 in display-rj in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9149,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9152,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],t2);
/* eval.scm: 1514 spaces */
t5=((C_word*)t0)[2];
f_9121(t5,t3,t4);}

/* k9150 in k9147 in display-rj in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1515 display */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* spaces in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_9121(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9121,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9127,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9127(t6,t1,t2);}

/* doloop2720 in spaces in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_9127(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9127,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9137,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1509 display */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k9135 in doloop2720 in spaces in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9127(t3,((C_word*)t0)[2],t2);}

/* ##sys#resolve-include-filename in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4rv,(void*)f_8979r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_8979r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8979r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t4,C_fix(0)));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8985,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9020,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9050,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1485 test */
t12=t10;
f_9020(t12,t11,t2);}

/* k9048 in ##sys#resolve-include-filename in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9050,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9060,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9097,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1489 ##sys#repository-path */
t4=*((C_word*)lf[244]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_9060(2,t3,*((C_word*)lf[251]+1));}}}

/* k9095 in k9048 in ##sys#resolve-include-filename in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9100,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9107,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1491 ##sys#repository-path */
t4=*((C_word*)lf[244]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_9100(t3,C_SCHEME_END_OF_LIST);}}

/* k9105 in k9095 in k9048 in ##sys#resolve-include-filename in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9107,2,t0,t1);}
t2=((C_word*)t0)[2];
f_9100(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k9098 in k9095 in k9048 in ##sys#resolve-include-filename in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_9100(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1487 ##sys#append */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[251]+1),t1);}

/* k9058 in k9048 in ##sys#resolve-include-filename in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9060,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9062,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_9062(t5,((C_word*)t0)[2],t1);}

/* loop in k9058 in k9048 in ##sys#resolve-include-filename in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_9062(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9062,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9072,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9086,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1495 string-append */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,lf[301],((C_word*)t0)[5]);}}

/* k9084 in loop in k9058 in k9048 in ##sys#resolve-include-filename in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1495 test */
t2=((C_word*)t0)[3];
f_9020(t2,((C_word*)t0)[2],t1);}

/* k9070 in loop in k9058 in k9048 in ##sys#resolve-include-filename in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1498 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9062(t3,((C_word*)t0)[4],t2);}}

/* test in ##sys#resolve-include-filename in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_9020(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9020,NULL,3,t0,t1,t2);}
t3=(C_word)C_fudge(C_fix(24));
t4=(C_truep(t3)?(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_list(&a,2,lf[8],*((C_word*)lf[212]+1)):(C_word)C_a_i_list(&a,2,*((C_word*)lf[212]+1),lf[8])):(C_word)C_a_i_list(&a,1,lf[8]));
/* eval.scm: 1480 test2 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_8985(t5,t1,t2,t4);}

/* test2 in ##sys#resolve-include-filename in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8985(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8985,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8998,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1474 exists? */
f_8960(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9001,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_i_car(t3);
/* eval.scm: 1475 ##sys#string-append */
t6=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}}

/* k8999 in test2 in ##sys#resolve-include-filename in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9007,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1476 exists? */
f_8960(t2,t1);}

/* k9005 in k8999 in test2 in ##sys#resolve-include-filename in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_9007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1478 test2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8985(t3,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k8996 in test2 in ##sys#resolve-include-filename in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* exists? in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8960(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8960,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8964,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1469 ##sys#file-info */
t4=*((C_word*)lf[211]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8962 in exists? in k8952 in k8948 in k8945 in k8941 in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=(C_word)C_eqp(C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* initb in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8927(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8927,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8929,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_8929 in initb in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8929(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8929,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8933,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1430 ##sys#hash-table-location */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k8931 */
static void C_ccall f_8933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t1,C_fix(1),t2));}

/* null-environment in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8889(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8889r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8889r(t0,t1,t2,t3);}}

static void C_ccall f_8889r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[298]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8896,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t2,C_fix(4));
t7=(C_truep(t6)?t6:(C_word)C_fixnum_greaterp(t2,C_fix(5)));
if(C_truep(t7)){
/* eval.scm: 1421 ##sys#error */
t8=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[298],lf[299],t2);}
else{
t8=t5;
f_8896(2,t8,C_SCHEME_UNDEFINED);}}

/* k8894 in null-environment in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8903,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1424 make-vector */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8901 in k8894 in null-environment in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8903,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(0)):C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,3,lf[288],t1,t3));}

/* scheme-report-environment in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8845(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8845r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8845r(t0,t1,t2,t3);}}

static void C_ccall f_8845r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,lf[295]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=t2;
switch(t7){
case C_fix(4):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8865,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1412 ##sys#copy-env-table */
t9=*((C_word*)lf[291]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[286],C_SCHEME_TRUE,t6);
case C_fix(5):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8878,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1413 ##sys#copy-env-table */
t9=*((C_word*)lf[291]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[287],C_SCHEME_TRUE,t6);
default:
/* eval.scm: 1414 ##sys#error */
t8=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[295],lf[296],t2);}}

/* k8876 in scheme-report-environment in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8878,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[288],t1,((C_word*)t0)[2]));}

/* k8863 in scheme-report-environment in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8865,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[288],t1,((C_word*)t0)[2]));}

/* interaction-environment in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8842,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[289]);}

/* ##sys#environment-symbols in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8723(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8723r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8723r(t0,t1,t2,t3);}}

static void C_ccall f_8723r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(10);
t4=(C_word)C_i_check_structure(t2,lf[288]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep(t7)){
t8=(C_word)C_fix((C_word)C_header_size(t7));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8744,a[2]=t6,a[3]=t7,a[4]=t10,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8744(t12,t1,C_fix(0),C_SCHEME_END_OF_LIST);}
else{
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8815,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8817,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1399 ##sys#walk-namespace */
t12=*((C_word*)lf[293]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}

/* a8816 in ##sys#environment-symbols in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8817(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8817,3,t0,t1,t2);}
t3=(C_word)C_i_not(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8827,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_8827(2,t5,t3);}
else{
/* eval.scm: 1401 pred */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k8825 in a8816 in ##sys#environment-symbols in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8827,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8813 in ##sys#environment-symbols in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* doloop2543 in ##sys#environment-symbols in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8744(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8744,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8762,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_slot(((C_word*)t0)[3],t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8768,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_8768(t10,t5,t6,t3);}}

/* loop in doloop2543 in ##sys#environment-symbols in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8768(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8768,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_i_not(((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8787,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_8787(2,t8,t6);}
else{
/* eval.scm: 1393 pred */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t5);}}}

/* k8785 in loop in doloop2543 in ##sys#environment-symbols in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8787,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* eval.scm: 1394 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8768(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1395 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8768(t3,((C_word*)t0)[2],t2,((C_word*)t0)[4]);}}

/* k8760 in doloop2543 in ##sys#environment-symbols in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_8744(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#copy-env-table in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5rv,(void*)f_8615r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_8615r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_8615r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):C_SCHEME_FALSE);
t8=(C_word)C_block_size(t2);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8625,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t2,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1360 ##sys#make-vector */
t10=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t8,C_SCHEME_END_OF_LIST);}

/* k8623 in ##sys#copy-env-table in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8625,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_8630(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop2503 in k8623 in ##sys#copy-env-table in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8630(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8630,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[7]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8651,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8657,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_8657(t8,t3,t4);}}

/* copy in doloop2503 in k8623 in ##sys#copy-env-table in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8657(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8657,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_i_not(((C_word*)t0)[5]);
t6=(C_truep(t5)?t5:(C_word)C_u_i_memq(t4,((C_word*)t0)[5]));
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:(C_word)C_slot(t3,C_fix(2)));
t9=(C_word)C_a_i_vector(&a,3,t4,t7,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8690,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1375 copy */
t14=t10;
t15=t11;
t1=t14;
t2=t15;
goto loop;}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1376 copy */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k8688 in copy in doloop2503 in k8623 in ##sys#copy-env-table in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8690,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8649 in doloop2503 in k8623 in ##sys#copy-env-table in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8630(t4,((C_word*)t0)[2],t3);}

/* ##sys#environment? in k8590 in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8599(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8599,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[288]))){
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(C_fix(3),t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##sys#string->c-identifier in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8536(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8536,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8540,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1338 string-copy */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8538 in ##sys#string->c-identifier in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8540,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8548,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8548(t6,((C_word*)t0)[2],C_fix(0));}

/* doloop2454 in k8538 in ##sys#string->c-identifier in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8548(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8548,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8568,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_alphabeticp(t3))){
t5=t4;
f_8568(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_u_i_char_numericp(t3);
t6=(C_word)C_i_not(t5);
t7=t4;
f_8568(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,C_fix(0))));}}}

/* k8566 in doloop2454 in k8538 in ##sys#string->c-identifier in k8532 in k8529 in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8568(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],C_make_character(95)):C_SCHEME_UNDEFINED);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8548(t4,((C_word*)t0)[2],t3);}

/* set-extension-specifier! in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8492,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[284]);
t5=(C_word)C_u_i_assq(t2,*((C_word*)lf[281]+1));
if(C_truep(t5)){
t6=(C_word)C_slot(t5,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8510,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t5,C_fix(1),t7));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8524,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,*((C_word*)lf[281]+1));
t9=C_mutate((C_word*)lf[281]+1 /* (set! extension-specifiers ...) */,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* a8523 in set-extension-specifier! in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8524,3,t0,t1,t2);}
/* eval.scm: 1294 proc */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* a8509 in set-extension-specifier! in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8510(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8510,3,t0,t1,t2);}
/* eval.scm: 1292 proc */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7985,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7988,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8013,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8054,a[2]=t5,a[3]=t3,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8360,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_u_i_car(t2);
t10=t8;
f_8360(t10,(C_word)C_i_symbolp(t9));}
else{
t9=t8;
f_8360(t9,C_SCHEME_FALSE);}}

/* k8358 in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8360,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
t3=(C_word)C_u_i_assq(t2,*((C_word*)lf[281]+1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8369,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[7]);}
else{
/* eval.scm: 1280 ##sys#error */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[6],lf[282],((C_word*)t0)[7]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[7]))){
/* eval.scm: 1282 doit */
t2=((C_word*)t0)[2];
f_8054(t2,((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
/* eval.scm: 1283 ##sys#error */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],lf[283],((C_word*)t0)[7]);}}}

/* k8367 in k8358 in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8369,2,t0,t1);}
if(C_truep((C_word)C_i_stringp(t1))){
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[198],t2);
/* eval.scm: 1268 values */
C_values(4,0,((C_word*)t0)[5],t3,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8399,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1270 vector->list */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
/* eval.scm: 1279 ##sys#do-the-right-thing */
t2=*((C_word*)lf[132]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k8397 in k8367 in k8358 in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8399,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8401,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8401(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k8397 in k8367 in k8358 in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8401(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8401,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8419,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8423,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1274 reverse */
t7=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8428,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8438,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}}

/* a8437 in loop in k8397 in k8367 in k8358 in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8438,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t6=(C_truep(t3)?t3:((C_word*)t0)[3]);
/* eval.scm: 1276 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8401(t7,t1,t4,t5,t6);}

/* a8427 in loop in k8397 in k8367 in k8358 in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8428,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* eval.scm: 1275 ##sys#do-the-right-thing */
t3=*((C_word*)lf[132]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8421 in loop in k8397 in k8367 in k8358 in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8417 in loop in k8397 in k8367 in k8358 in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8419,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[67],t1);
/* eval.scm: 1274 values */
C_values(4,0,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8054(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8054,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_memq(t2,lf[275]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8064,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_8064(2,t5,t3);}
else{
if(C_truep(((C_word*)t0)[3])){
t5=t4;
f_8064(2,t5,(C_word)C_u_i_memq(t2,lf[279]));}
else{
/* eval.scm: 1217 ##sys#feature? */
t5=*((C_word*)lf[280]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}}

/* k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8064,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8071,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1218 impform */
t3=((C_word*)t0)[5];
f_8013(t3,t2,lf[276],((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[3]+1)))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8084,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8088,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[277],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t3;
f_8088(t7,(C_word)C_a_i_cons(&a,2,lf[140],t6));}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[53],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t3;
f_8088(t8,(C_word)C_a_i_cons(&a,2,lf[229],t7));}}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[5]+1)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8131,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1228 ##sys#extension-information */
t3=*((C_word*)lf[262]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[278]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1240 ##sys#extension-information */
t3=*((C_word*)lf[262]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[278]);}}}}

/* k8215 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8217,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[57],t1);
t3=(C_word)C_u_i_assq(lf[267],t1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8229,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
/* eval.scm: 1244 add-req */
t5=((C_word*)t0)[2];
f_7988(t5,t4,((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t5=t4;
f_8229(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8322,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1258 add-req */
t3=((C_word*)t0)[2];
f_7988(t3,t2,((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* k8320 in k8215 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8329,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[53],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[128],t5);
/* eval.scm: 1260 impform */
t7=((C_word*)t0)[2];
f_8013(t7,t2,t6,((C_word*)t0)[3],C_SCHEME_FALSE);}

/* k8327 in k8320 in k8215 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1259 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k8227 in k8215 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8236,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8244,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8248,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[53],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[126],t7);
t9=t4;
f_8248(t9,(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST));}
else{
t5=t4;
f_8248(t5,C_SCHEME_END_OF_LIST);}}

/* k8246 in k8227 in k8215 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8248,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8252,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8256,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(((C_word*)t0)[4])?C_SCHEME_FALSE:((C_word*)t0)[3]);
if(C_truep(t4)){
t5=t3;
f_8256(t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8270,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8274,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8276,tmp=(C_word)a,a+=2,tmp);
t8=(C_truep(((C_word*)t0)[4])?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* map */
t9=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}}

/* a8275 in k8246 in k8227 in k8215 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8276(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8276,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[53],t3));}

/* k8272 in k8246 in k8227 in k8215 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8268 in k8246 in k8227 in k8215 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8270,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[128],t1);
t3=((C_word*)t0)[2];
f_8256(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k8254 in k8246 in k8227 in k8215 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8256(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8250 in k8246 in k8227 in k8215 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8242 in k8227 in k8215 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8244,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[67],t1);
/* eval.scm: 1246 impform */
t3=((C_word*)t0)[4];
f_8013(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k8234 in k8227 in k8215 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1245 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k8129 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8131,2,t0,t1);}
t2=(C_word)C_u_i_assq(lf[57],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8145,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[53],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[126],t7);
t9=t4;
f_8149(t9,(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST));}
else{
t5=t4;
f_8149(t5,C_SCHEME_END_OF_LIST);}}

/* k8147 in k8129 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8149(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8149,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8157,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8161,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[277],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t3;
f_8161(t7,(C_word)C_a_i_cons(&a,2,lf[140],t6));}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[53],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t3;
f_8161(t8,(C_word)C_a_i_cons(&a,2,lf[229],t7));}}

/* k8159 in k8147 in k8129 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8161(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1233 impform */
t2=((C_word*)t0)[4];
f_8013(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k8155 in k8147 in k8129 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8157,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t3=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8143 in k8129 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8145,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[67],t1);
/* eval.scm: 1230 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k8086 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8088(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1221 impform */
t2=((C_word*)t0)[4];
f_8013(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k8082 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1220 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k8069 in k8062 in doit in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1218 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* impform in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8013(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8013,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8025,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8029,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8032,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t8=(C_word)C_i_not(t4);
if(C_truep(t8)){
t9=t7;
f_8032(2,t9,t8);}
else{
/* eval.scm: 1210 ##sys#current-module */
t9=*((C_word*)lf[41]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t7);}}
else{
t8=t7;
f_8032(2,t8,C_SCHEME_FALSE);}}

/* k8030 in impform in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8032,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[274],t2);
t4=((C_word*)t0)[2];
f_8029(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}
else{
t2=((C_word*)t0)[2];
f_8029(t2,C_SCHEME_END_OF_LIST);}}

/* k8027 in impform in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_8029(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8023 in impform in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8025,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[67],t2));}

/* add-req in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_7988(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7988,NULL,4,t0,t1,t2,t3);}
if(C_truep(((C_word*)t0)[2])){
t4=(C_truep(t3)?lf[269]:lf[270]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8001,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8007,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1202 ##sys#hash-table-update! */
t7=*((C_word*)lf[18]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,*((C_word*)lf[273]+1),t4,t5,t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* a8006 in add-req in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8007,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* a8000 in add-req in ##sys#do-the-right-thing in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_8001(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8001,3,t0,t1,t2);}
/* lset-adjoin */
t3=*((C_word*)lf[271]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[272]+1),t2,((C_word*)t0)[2]);}

/* ##sys#lookup-runtime-requirements in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7936,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7942,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7942(t6,t1,t2);}

/* loop1 in ##sys#lookup-runtime-requirements in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_7942(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7942,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7956,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 1191 ##sys#extension-information */
t5=*((C_word*)lf[262]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_FALSE);}}

/* k7954 in loop1 in ##sys#lookup-runtime-requirements in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_assq(lf[267],t1);
t4=t2;
f_7959(t4,(C_truep(t3)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE));}
else{
t3=t2;
f_7959(t3,C_SCHEME_FALSE);}}

/* k7957 in k7954 in loop1 in ##sys#lookup-runtime-requirements in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_7959(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7959,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7966,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1195 loop1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7942(t5,t3,t4);}

/* k7964 in k7957 in k7954 in loop1 in ##sys#lookup-runtime-requirements in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1190 append */
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extension-information in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7930(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7930,3,t0,t1,t2);}
/* eval.scm: 1181 ##sys#extension-information */
t3=*((C_word*)lf[262]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[266]);}

/* ##sys#extension-information in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7897,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7901,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1173 ##sys#repository-path */
t5=*((C_word*)lf[244]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7899 in ##sys#extension-information in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7901,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7907,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1174 ##sys#canonicalize-extension-path */
t3=*((C_word*)lf[238]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7905 in k7899 in ##sys#extension-information in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7910,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1175 string-append */
t3=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],lf[264],t1,lf[265]);}

/* k7908 in k7905 in k7899 in ##sys#extension-information in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7913,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7928,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1176 string-append */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[263]);}

/* k7926 in k7908 in k7905 in k7899 in ##sys#extension-information in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1176 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7911 in k7908 in k7905 in k7899 in ##sys#extension-information in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7913,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7920,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7920 in k7911 in k7908 in k7905 in k7899 in ##sys#extension-information in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7920(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7920,3,t0,t1,t2);}
/* with-input-from-file2129 */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#require in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7884(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_7884r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7884r(t0,t1,t2);}}

static void C_ccall f_7884r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7890,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7889 in ##sys#require in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7890(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7890,3,t0,t1,t2);}
/* ##sys#load-extension */
t3=*((C_word*)lf[255]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[261]);}

/* ##sys#provided? in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7870(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7870,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7881,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1154 ##sys#canonicalize-extension-path */
t4=*((C_word*)lf[238]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[260]);}

/* k7879 in ##sys#provided? in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_member(t1,*((C_word*)lf[253]+1));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#provide in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7850(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_7850r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7850r(t0,t1,t2);}}

static void C_ccall f_7850r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7856,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7855 in ##sys#provide in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7856(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7856,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[258]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7863,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1147 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[238]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[258]);}

/* k7861 in a7855 in ##sys#provide in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7863,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,*((C_word*)lf[253]+1));
t3=C_mutate((C_word*)lf[253]+1 /* (set! loaded-extensions ...) */,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#load-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_7782r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7782r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7782r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7786,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t5)[1]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7845,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1128 string->symbol */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t5)[1]);}
else{
t7=t6;
f_7786(t7,(C_word)C_i_check_symbol_2(((C_word*)t5)[1],t3));}}

/* k7843 in ##sys#load-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7786(t3,t2);}

/* k7784 in ##sys#load-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_7786(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7786,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1130 ##sys#canonicalize-extension-path */
t3=*((C_word*)lf[238]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]);}

/* k7787 in k7784 in ##sys#load-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7789,2,t0,t1);}
t2=(C_word)C_i_member(t1,*((C_word*)lf[253]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[3]+1)))){
/* eval.scm: 1133 ##sys#load-library */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7807,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1135 ##sys#find-extension */
t4=*((C_word*)lf[248]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_TRUE);}}}

/* k7805 in k7787 in k7784 in ##sys#load-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7807,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7813,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1137 ##sys#load */
t3=*((C_word*)lf[193]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[4];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_u_i_car(t2));
if(C_truep(t4)){
/* eval.scm: 1140 ##sys#error */
t5=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[3],lf[256],((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}

/* k7811 in k7805 in k7787 in k7784 in ##sys#load-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7813,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[253]+1));
t3=C_mutate((C_word*)lf[253]+1 /* (set! loaded-extensions ...) */,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}

/* ##sys#find-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7683,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7687,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1104 ##sys#repository-path */
t5=*((C_word*)lf[244]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7685 in ##sys#find-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7689,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7735,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(*((C_word*)lf[246]+1))?lf[250]:C_SCHEME_END_OF_LIST);
t5=(C_truep(t1)?(C_word)C_a_i_list(&a,1,t1):C_SCHEME_END_OF_LIST);
t6=(C_truep(((C_word*)t0)[2])?*((C_word*)lf[251]+1):C_SCHEME_END_OF_LIST);
t7=(C_truep(*((C_word*)lf[246]+1))?C_SCHEME_END_OF_LIST:lf[252]);
/* eval.scm: 1113 ##sys#append */
t8=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t3,t4,t5,t6,t7);}

/* k7733 in k7685 in ##sys#find-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7735,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7737,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7737(t5,((C_word*)t0)[2],t1);}

/* loop in k7733 in k7685 in ##sys#find-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_7737(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7737,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7750,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1120 check */
t5=((C_word*)t0)[2];
f_7689(t5,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7748 in loop in k7733 in k7685 in ##sys#find-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1121 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7737(t3,((C_word*)t0)[4],t2);}}

/* check in k7685 in ##sys#find-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_7689(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7689,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7693,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1106 string-append */
t4=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[249],((C_word*)t0)[2]);}

/* k7691 in check in k7685 in ##sys#find-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7699,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=*((C_word*)lf[178]+1);
if(C_truep(t3)){
t4=t2;
f_7699(2,t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_fudge(C_fix(24)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7728,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1110 ##sys#string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t1,*((C_word*)lf[212]+1));}
else{
t4=t2;
f_7699(2,t4,C_SCHEME_FALSE);}}}
else{
t3=t2;
f_7699(2,t3,C_SCHEME_FALSE);}}

/* k7726 in k7691 in check in k7685 in ##sys#find-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1110 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7697 in k7691 in check in k7685 in ##sys#find-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7702,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_7702(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7709,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1111 ##sys#string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],lf[8]);}}

/* k7707 in k7697 in k7691 in check in k7685 in ##sys#find-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1111 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7700 in k7697 in k7691 in check in k7685 in ##sys#find-extension in k7677 in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##sys#canonicalize-extension-path in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7519,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7522,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7528,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7541,a[2]=t1,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t7=t6;
f_7541(2,t7,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 1064 ##sys#symbol->string */
t7=*((C_word*)lf[240]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7624,a[2]=t4,a[3]=t8,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_7624(t10,t6,t2);}
else{
t7=t6;
f_7541(2,t7,C_SCHEME_UNDEFINED);}}}}

/* loop in ##sys#canonicalize-extension-path in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_7624(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7624,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[241]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7641,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
/* eval.scm: 1071 ##sys#symbol->string */
t5=*((C_word*)lf[240]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_stringp(t3))){
t5=t4;
f_7641(2,t5,t3);}
else{
/* eval.scm: 1073 err */
t5=((C_word*)t0)[2];
f_7522(t5,t4);}}}}

/* k7639 in loop in ##sys#canonicalize-extension-path in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7641,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?lf[242]:lf[243]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7649,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1077 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7624(t7,t5,t6);}

/* k7647 in k7639 in loop in ##sys#canonicalize-extension-path in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1069 string-append */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7539 in ##sys#canonicalize-extension-path in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7541,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7546,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7546(t5,((C_word*)t0)[2],t1);}

/* check in k7539 in ##sys#canonicalize-extension-path in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_7546(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7546,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
/* eval.scm: 1080 err */
t5=((C_word*)t0)[4];
f_7522(t5,t1);}
else{
t5=(C_word)C_subchar(t2,C_fix(0));
t6=f_7528(t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7572,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1082 ##sys#substring */
t8=*((C_word*)lf[201]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(1),t3);}
else{
t7=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t8=(C_word)C_subchar(t2,t7);
t9=f_7528(t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7585,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1084 ##sys#substring */
t12=*((C_word*)lf[201]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t10,t2,C_fix(0),t11);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t2);}}}}

/* k7583 in check in k7539 in ##sys#canonicalize-extension-path in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1084 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7546(t2,((C_word*)t0)[2],t1);}

/* k7570 in check in k7539 in ##sys#canonicalize-extension-path in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1082 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7546(t2,((C_word*)t0)[2],t1);}

/* sep? in ##sys#canonicalize-extension-path in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static C_word C_fcall f_7528(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_eqp(C_make_character(92),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(47),t1)));}

/* err in ##sys#canonicalize-extension-path in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_7522(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7522,NULL,2,t0,t1);}
/* eval.scm: 1061 ##sys#error */
t2=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[239],((C_word*)t0)[2]);}

/* load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7434(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7434r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7434r(t0,t1,t2,t3);}}

static void C_ccall f_7434r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_symbol_2(t2,lf[236]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7441,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
/* eval.scm: 1040 ##sys#load-library */
t8=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t2,t7);}

/* k7439 in load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7441,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}}

/* k7449 in k7439 in load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1041 ##sys#error */
t2=*((C_word*)lf[46]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[236],lf[237],((C_word*)t0)[2],t1);}

/* ##sys#load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7328,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7332,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1013 ##sys#->feature-id */
t5=*((C_word*)lf[235]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7330 in ##sys#load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7332,2,t0,t1);}
t2=(C_word)C_u_i_memq(t1,*((C_word*)lf[143]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7341,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_7341(t4,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7424,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1018 ##sys#string-append */
t6=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[223]+1));}}}

/* k7422 in k7330 in ##sys#load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7428,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1019 dynamic-load-libraries */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7426 in k7422 in k7330 in ##sys#load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7428,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7341(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7339 in k7330 in ##sys#load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_7341(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7341,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7344,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7406,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7410,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1024 ##sys#string->c-identifier */
t6=*((C_word*)lf[234]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k7408 in k7339 in k7330 in ##sys#load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1022 string-append */
t2=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[232],t1,lf[233]);}

/* k7404 in k7339 in k7330 in ##sys#load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1021 ##sys#make-c-string */
t2=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7342 in k7339 in k7330 in ##sys#load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7347,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7393,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1026 load-verbose */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7391 in k7342 in k7339 in k7330 in ##sys#load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7393,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1027 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[231]);}
else{
t2=((C_word*)t0)[3];
f_7347(2,t2,C_SCHEME_UNDEFINED);}}

/* k7394 in k7391 in k7342 in k7339 in k7330 in ##sys#load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1028 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7397 in k7394 in k7391 in k7342 in k7339 in k7330 in ##sys#load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1029 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[230]);}

/* k7345 in k7342 in k7339 in k7330 in ##sys#load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7347,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7352,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7352(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k7345 in k7342 in k7339 in k7330 in ##sys#load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_7352(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7352,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7365,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7386,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1032 ##sys#make-c-string */
t6=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k7384 in loop in k7345 in k7342 in k7339 in k7330 in ##sys#load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1032 ##sys#dload */
t2=*((C_word*)lf[204]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7363 in loop in k7345 in k7342 in k7339 in k7330 in ##sys#load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7365,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7368,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[143]+1)))){
t3=t2;
f_7368(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],*((C_word*)lf[143]+1));
t4=C_mutate((C_word*)lf[143]+1 /* (set! features ...) */,t3);
t5=t2;
f_7368(t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1035 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7352(t3,((C_word*)t0)[5],t2);}}

/* k7366 in k7363 in loop in k7345 in k7342 in k7339 in k7330 in ##sys#load-library in k7324 in k7317 in k7312 in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_7368(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* load-noisily in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7288(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_7288r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7288r(t0,t1,t2,t3);}}

static void C_ccall f_7288r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7292,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7309,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t6=*((C_word*)lf[219]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[222],t3,t5);}

/* a7308 in load-noisily in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7309,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k7290 in load-noisily in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7295,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7306,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[219]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[221],((C_word*)t0)[2],t3);}

/* a7305 in k7290 in load-noisily in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7306,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k7293 in k7290 in load-noisily in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7298,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7303,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[219]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[220],((C_word*)t0)[2],t3);}

/* a7302 in k7293 in k7290 in load-noisily in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7303,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k7296 in k7293 in k7290 in load-noisily in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 984  ##sys#load */
t2=*((C_word*)lf[193]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1);}

/* load-relative in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7252(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7252r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7252r(t0,t1,t2,t3);}}

static void C_ccall f_7252r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7260,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_subchar(t2,C_fix(0));
if(C_truep((C_truep((C_word)C_eqp(t5,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t6=t4;
f_7260(2,t6,t2);}
else{
/* eval.scm: 980  ##sys#string-append */
t6=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[176]+1),t2);}}

/* k7258 in load-relative in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_car(t2));
/* eval.scm: 977  ##sys#load */
t5=*((C_word*)lf[193]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t1,t4,C_SCHEME_FALSE);}

/* load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7230(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7230r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7230r(t0,t1,t2,t3);}}

static void C_ccall f_7230r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
/* eval.scm: 974  ##sys#load */
t6=*((C_word*)lf[193]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t5,C_SCHEME_FALSE);}

/* ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5r,(void*)f_6834r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6834r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6834r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(24);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t4,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7180,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7185,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-timer15701756 */
t10=t9;
f_7185(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-printer15711752 */
t12=t8;
f_7180(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body15681577 */
t14=t7;
f_6836(t14,t1,t10,t12);}}}

/* def-timer1570 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_7185(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7185,NULL,2,t0,t1);}
/* def-printer15711752 */
t2=((C_word*)t0)[2];
f_7180(t2,t1,C_SCHEME_FALSE);}

/* def-printer1571 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_7180(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7180,NULL,3,t0,t1,t2);}
/* body15681577 */
t3=((C_word*)t0)[2];
f_6836(t3,t1,t2,C_SCHEME_FALSE);}

/* body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_6836(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6836,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_6840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=((C_word*)t0)[13],a[16]=t1,a[17]=((C_word*)t0)[14],a[18]=((C_word*)t0)[15],tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[7])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7179,a[2]=t4,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 906  ##sys#expand-home-path */
t6=*((C_word*)lf[216]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[7])[1]);}
else{
t5=t4;
f_6840(t5,C_SCHEME_UNDEFINED);}}

/* k7177 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6840(t3,t2);}

/* k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_6840(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6840,NULL,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_6843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7101,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 909  port? */
t6=*((C_word*)lf[215]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[7])[1]);}

/* k7099 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7101,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6843(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 911  ##sys#file-info */
t3=*((C_word*)lf[211]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
/* eval.scm: 902  ##sys#signal-hook */
t3=*((C_word*)lf[185]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[213],lf[198],lf[214],t2);}}}

/* k7114 in k7099 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(4));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t2;
f_7119(t6,(C_word)C_i_not(t3));}
else{
t4=t2;
f_7119(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7119(t3,C_SCHEME_FALSE);}}

/* k7117 in k7114 in k7099 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_7119(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7119,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6843(2,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7122,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 917  ##sys#string-append */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[212]+1));}}

/* k7120 in k7117 in k7114 in k7099 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[178]+1);
if(C_truep(t3)){
t4=t2;
f_7128(2,t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_fudge(C_fix(24)))){
/* eval.scm: 920  ##sys#file-info */
t4=*((C_word*)lf[211]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t1);}
else{
t4=t2;
f_7128(2,t4,C_SCHEME_FALSE);}}}

/* k7126 in k7120 in k7117 in k7114 in k7099 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7128,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6843(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 922  ##sys#string-append */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[8]);}}

/* k7129 in k7126 in k7120 in k7117 in k7114 in k7099 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 923  ##sys#file-info */
t3=*((C_word*)lf[211]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k7135 in k7129 in k7126 in k7120 in k7117 in k7114 in k7099 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6843(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[5];
f_6843(2,t3,(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[2])[1]));}}

/* k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6843,2,t0,t1);}
t2=((C_word*)t0)[18];
t3=(C_truep(t2)?t2:((C_word*)t0)[17]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6849,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=t3,a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=t1,a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_i_stringp(((C_word*)((C_word*)t0)[7])[1]);
t6=(C_truep(t5)?(C_word)C_i_not(t1):C_SCHEME_FALSE);
if(C_truep(t6)){
/* eval.scm: 928  ##sys#signal-hook */
t7=*((C_word*)lf[185]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,lf[207],lf[198],lf[208],((C_word*)((C_word*)t0)[7])[1]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7092,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 929  load-verbose */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k7090 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7092,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[5]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7080,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 930  display */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[210]);}
else{
t3=((C_word*)t0)[3];
f_6849(2,t3,C_SCHEME_UNDEFINED);}}

/* k7078 in k7090 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7083,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 931  display */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7081 in k7078 in k7090 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 932  display */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[209]);}

/* k7084 in k7081 in k7078 in k7090 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 933  flush-output */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6852,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[14])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7037,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7065,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 935  ##sys#make-c-string */
t5=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[14]);}
else{
t3=t2;
f_6852(2,t3,C_SCHEME_FALSE);}}

/* k7063 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 935  ##sys#dload */
t2=*((C_word*)lf[204]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k7035 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7037,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6852(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 936  has-sep? */
f_6788(t2,((C_word*)t0)[3]);}}

/* k7059 in k7035 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7061,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6852(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7053,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7057,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 937  ##sys#string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[206],((C_word*)t0)[2]);}}

/* k7055 in k7059 in k7035 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 937  ##sys#make-c-string */
t2=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7051 in k7059 in k7035 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 937  ##sys#dload */
t2=*((C_word*)lf[204]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6855,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_6855(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 938  call-with-current-continuation */
t4=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6860(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6860,3,t0,t1,t2);}
t3=C_SCHEME_TRUE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[13];
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6864,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t6,a[15]=t4,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[13])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7024,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 944  has-sep? */
f_6788(t8,((C_word*)t0)[13]);}
else{
t8=t7;
f_6864(2,t8,C_SCHEME_FALSE);}}

/* k7022 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(t1,C_fix(1));
/* eval.scm: 945  ##sys#substring */
t3=*((C_word*)lf[201]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
f_6864(2,t2,lf[202]);}}

/* k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[48],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6864,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6865,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6874,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t13,a[7]=t11,a[8]=t9,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t15=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6885,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7012,a[2]=t13,a[3]=t11,a[4]=t9,a[5]=t7,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
/* ##sys#dynamic-wind */
t17=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,((C_word*)t0)[2],t14,t15,t16);}

/* a7011 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7012,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[194]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[175]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[176]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[174]+1));
t6=C_mutate((C_word*)lf[194]+1 /* (set! read-error-with-line-number ...) */,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[175]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[176]+1 /* (set! current-load-path ...) */,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[174]+1 /* (set! abort-load ...) */,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}

/* a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6889,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[5])){
/* eval.scm: 947  open-input-file */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_6889(2,t3,((C_word*)((C_word*)t0)[2])[1]);}}

/* k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6894,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6897,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7003,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 948  ##sys#dynamic-wind */
t5=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t2,t3,t4);}

/* a7002 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_7003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7003,2,t0,t1);}
/* eval.scm: 970  close-input-port */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6901,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 951  peek-char */
t3=*((C_word*)lf[200]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6904,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(t1,C_make_character(127));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6997,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}
else{
t4=t2;
f_6904(2,t4,C_SCHEME_UNDEFINED);}}

/* k6995 in k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 953  ##sys#error */
t2=*((C_word*)lf[46]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[198],lf[199],((C_word*)t0)[2],t1);}

/* k6902 in k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 954  read */
t3=((C_word*)t0)[10];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6905 in k6902 in k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6907,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6912(t5,((C_word*)t0)[2],t1);}

/* doloop1705 in k6905 in k6902 in k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_6912(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6912,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6922,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 957  printer */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_6922(2,t4,C_SCHEME_UNDEFINED);}}}

/* k6920 in doloop1705 in k6905 in k6902 in k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6925,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6934,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 958  ##sys#call-with-values */
C_u_call_with_values(4,0,t2,t3,t4);}

/* a6967 in k6920 in doloop1705 in k6905 in k6902 in k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6968(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_6968r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6968r(t0,t1,t2);}}

static void C_ccall f_6968r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a6976 in a6967 in k6920 in doloop1705 in k6905 in k6902 in k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6977(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6977,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6981,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 967  write */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k6979 in a6976 in a6967 in k6920 in doloop1705 in k6905 in k6902 in k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 968  newline */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6933 in k6920 in doloop1705 in k6905 in k6902 in k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6934,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6941,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[197]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* eval.scm: 962  evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}}

/* k6939 in a6933 in k6920 in doloop1705 in k6905 in k6902 in k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6946,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6952,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6951 in k6939 in a6933 in k6920 in doloop1705 in k6905 in k6902 in k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6952(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_6952r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6952r(t0,t1,t2);}}

static void C_ccall f_6952r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6956,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6963,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[196]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6961 in a6951 in k6939 in a6933 in k6920 in doloop1705 in k6905 in k6902 in k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
t2=*((C_word*)lf[195]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6954 in a6951 in k6939 in a6933 in k6920 in doloop1705 in k6905 in k6902 in k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6945 in k6939 in a6933 in k6920 in doloop1705 in k6905 in k6902 in k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6946,2,t0,t1);}
/* eval.scm: 961  evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k6923 in k6920 in doloop1705 in k6905 in k6902 in k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6932,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 955  read */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6930 in k6923 in k6920 in doloop1705 in k6905 in k6902 in k6899 in a6896 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_6912(t2,((C_word*)t0)[2],t1);}

/* a6893 in k6887 in a6884 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6894,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* a6873 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6874,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[194]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[175]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[176]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[174]+1));
t6=C_mutate((C_word*)lf[194]+1 /* (set! read-error-with-line-number ...) */,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[175]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[176]+1 /* (set! current-load-path ...) */,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[174]+1 /* (set! abort-load ...) */,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}

/* f_6865 in k6862 in a6859 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6865,2,t0,t1);}
/* eval.scm: 946  abrt */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* k6853 in k6850 in k6847 in k6841 in k6838 in body1568 in ##sys#load in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* has-sep? in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_6788(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6788,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6798,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6798(t5,t4));}

/* loop in has-sep? in k6784 in k6703 in k6608 in k3373 in k3370 in k3337 */
static C_word C_fcall f_6798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_i_zerop(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
if(C_truep((C_truep((C_word)C_eqp(t2,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
return(t1);}
else{
t3=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* set-dynamic-load-mode! in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6713(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6713,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?t2:(C_word)C_a_i_list(&a,1,t2));
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6720,a[2]=t8,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6725,a[2]=t6,a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_6725(t13,t9,t4);}

/* loop in set-dynamic-load-mode! in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_6725(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6725,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6738,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[181]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t7=t4;
f_6738(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[182]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t8=t4;
f_6738(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[183]);
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t9=t4;
f_6738(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[184]);
if(C_truep(t8)){
t9=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t10=t4;
f_6738(2,t10,t9);}
else{
t9=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 880  ##sys#signal-hook */
t10=*((C_word*)lf[185]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t4,lf[179],lf[186],t9);}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6736 in loop in set-dynamic-load-mode! in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 881  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6725(t3,((C_word*)t0)[2],t2);}

/* k6718 in set-dynamic-load-mode! in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 882  ##sys#set-dlopen-flags! */
t2=*((C_word*)lf[180]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* f_6707 in k6703 in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6707,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* ##sys#decompose-lambda-list in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6623,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6626,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6636,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_6636(t8,t1,t2,C_SCHEME_END_OF_LIST,C_fix(0));}

/* loop in ##sys#decompose-lambda-list in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_6636(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6636,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6650,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 849  reverse */
t7=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6669,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
/* eval.scm: 851  reverse */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
if(C_truep((C_word)C_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=(C_word)C_u_fixnum_plus(t4,C_fix(1));
/* eval.scm: 853  loop */
t14=t1;
t15=t6;
t16=t8;
t17=t9;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}
else{
/* eval.scm: 852  err */
t6=((C_word*)t0)[2];
f_6626(t6,t1);}}}
else{
/* eval.scm: 850  err */
t6=((C_word*)t0)[2];
f_6626(t6,t1);}}}

/* k6667 in loop in ##sys#decompose-lambda-list in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 851  k */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6648 in loop in ##sys#decompose-lambda-list in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 849  k */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* err in ##sys#decompose-lambda-list in k6608 in k3373 in k3370 in k3337 */
static void C_fcall f_6626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6626,NULL,2,t0,t1);}
t2=C_set_block_item(lf[171] /* syntax-error-culprit */,0,C_SCHEME_FALSE);
/* eval.scm: 846  ##sys#syntax-error-hook */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[172],((C_word*)t0)[2]);}

/* eval in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6613(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6613r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6613r(t0,t1,t2,t3);}}

static void C_ccall f_6613r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6621,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 834  ##sys#eval-handler */
t5=*((C_word*)lf[168]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6619 in eval in k6608 in k3373 in k3370 in k3337 */
static void C_ccall f_6621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+38)){
C_save_and_reclaim((void*)tr5rv,(void*)f_3715r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_3715r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3715r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a=C_alloc(38);
t6=(C_word)C_vemptyp(t5);
t7=(C_truep(t6)?C_SCHEME_FALSE:(C_word)C_slot(t5,C_fix(0)));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3721,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3760,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3775,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3859,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3865,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3871,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3877,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3928,a[2]=t20,a[3]=((C_word*)t0)[2],a[4]=t11,a[5]=t16,a[6]=t15,a[7]=t18,a[8]=t14,a[9]=((C_word*)t0)[3],a[10]=t12,tmp=(C_word)a,a+=11,tmp));
t22=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6362,a[2]=t18,a[3]=t13,tmp=(C_word)a,a+=4,tmp));
t23=(C_word)C_fixnum_greaterp(*((C_word*)lf[32]+1),C_fix(0));
/* eval.scm: 813  compile */
t24=((C_word*)t18)[1];
f_3928(t24,t1,t2,t3,C_SCHEME_FALSE,t23,t7,t4);}

/* compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_6362(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6362,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6366,a[2]=t6,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[3],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 777  compile */
t9=((C_word*)((C_word*)t0)[2])[1];
f_3928(t9,t7,t8,t3,C_SCHEME_FALSE,t4,t5,t6);}

/* k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6366,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6336,tmp=(C_word)a,a+=2,tmp);
t4=f_6336(t2,C_fix(0));
t5=((C_word*)t0)[9];
switch(t4){
case C_SCHEME_FALSE:
/* eval.scm: 782  ##sys#syntax-error-hook */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[8],lf[167],((C_word*)t0)[9]);
case C_fix(0):
t6=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6388,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
case C_fix(1):
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6407,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 786  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3928(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
case C_fix(2):
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 790  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3928(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
case C_fix(3):
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 795  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3928(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
case C_fix(4):
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 801  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3928(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
default:
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6555,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 808  ##sys#map */
t8=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}}

/* a6578 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6579,3,t0,t1,t2);}
/* eval.scm: 808  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3928(t3,t1,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6553 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6555,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6556,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_6556 in k6553 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6556(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6556,3,t0,t1,t2);}
t3=f_3859(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6567,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6565 */
static void C_ccall f_6567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6571,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6573,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 811  ##sys#map */
t4=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6572 in k6565 */
static void C_ccall f_6573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6573,3,t0,t1,t2);}
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[2]);}

/* k6569 in k6565 */
static void C_ccall f_6571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6510 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 802  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3928(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k6513 in k6510 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 803  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3928(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(2)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[10],((C_word*)t0)[8],((C_word*)t0)[2]);}

/* k6516 in k6513 in k6510 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6521,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 804  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3928(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(3)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[11],((C_word*)t0)[9],((C_word*)t0)[2]);}

/* k6519 in k6516 in k6513 in k6510 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6521,2,t0,t1);}
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp));}

/* f_6522 in k6519 in k6516 in k6513 in k6510 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6522(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6522,3,t0,t1,t2);}
t3=f_3859(((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6533,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6531 */
static void C_ccall f_6533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6537,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k6535 in k6531 */
static void C_ccall f_6537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6541,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k6539 in k6535 in k6531 */
static void C_ccall f_6541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6545,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6543 in k6539 in k6535 in k6531 */
static void C_ccall f_6545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6548,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6546 in k6543 in k6539 in k6535 in k6531 */
static void C_ccall f_6548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6468 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 796  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3928(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k6471 in k6468 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6476,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 797  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3928(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(2)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[10],((C_word*)t0)[8],((C_word*)t0)[2]);}

/* k6474 in k6471 in k6468 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6476,2,t0,t1);}
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));}

/* f_6477 in k6474 in k6471 in k6468 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6477,3,t0,t1,t2);}
t3=f_3859(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6488,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6486 */
static void C_ccall f_6488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6492,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k6490 in k6486 */
static void C_ccall f_6492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6496,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6494 in k6490 in k6486 */
static void C_ccall f_6496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6499,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6497 in k6494 in k6490 in k6486 */
static void C_ccall f_6499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6433 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6438,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 791  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3928(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k6436 in k6433 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6438,2,t0,t1);}
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6439,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));}

/* f_6439 in k6436 in k6433 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6439(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6439,3,t0,t1,t2);}
t3=f_3859(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6450,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6448 */
static void C_ccall f_6450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6452 in k6448 */
static void C_ccall f_6454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6457,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6455 in k6452 in k6448 */
static void C_ccall f_6457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6405 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6407,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6408,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_6408 in k6405 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6408(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6408,3,t0,t1,t2);}
t3=f_3859(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6419,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6417 */
static void C_ccall f_6419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6422,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6420 in k6417 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_6388 in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6388,3,t0,t1,t2);}
t3=f_3859(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6398,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 785  fn */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6396 */
static void C_ccall f_6398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in k6364 in compile-call in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static C_word C_fcall f_6336(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_3928(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3928,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=((C_word*)t0)[8],a[11]=t6,a[12]=((C_word*)t0)[9],a[13]=t7,a[14]=t3,a[15]=((C_word*)t0)[10],a[16]=t2,a[17]=t1,tmp=(C_word)a,a+=18,tmp);
/* eval.scm: 285  keyword? */
t9=*((C_word*)lf[166]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}

/* k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3935,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[17];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3936,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[16]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3948,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[15],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3954,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[17],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* eval.scm: 311  ##sys#number? */
t3=*((C_word*)lf[165]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[16]);}}}

/* k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4055,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4062,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4070,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4078,tmp=(C_word)a,a+=2,tmp));
default:
t3=(C_word)C_eqp(t2,C_fix(2));
t4=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4086,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4088,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp)));}}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[16]))){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[16])?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4099,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4101,tmp=(C_word)a,a+=2,tmp)));}
else{
t2=(C_word)C_charp(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=t3;
f_4111(t4,t2);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[16]);
t5=t3;
f_4111(t5,(C_truep(t4)?t4:(C_word)C_i_stringp(((C_word*)t0)[16])));}}}}

/* k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_4111(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4111,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4112,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_3865(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* eval.scm: 329  ##sys#expand */
t5=*((C_word*)lf[163]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[15],((C_word*)t0)[11],C_SCHEME_FALSE);}
else{
t3=f_3865(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
/* eval.scm: 754  compile-call */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6362(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[9],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11]);}}
else{
/* eval.scm: 326  ##sys#syntax-error-hook */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[16],lf[164],((C_word*)t0)[15]);}}}

/* k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4134,2,t0,t1);}
t2=*((C_word*)lf[39]+1);
t3=(C_word)C_eqp(t1,((C_word*)t0)[15]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
/* eval.scm: 333  rename */
t6=((C_word*)t0)[4];
f_3760(t6,t4,t5,((C_word*)t0)[13]);}
else{
/* eval.scm: 332  compile */
t4=((C_word*)((C_word*)t0)[12])[1];
f_3928(t4,((C_word*)t0)[14],t1,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}}

/* k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4149,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[53]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4158,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 339  ##sys#check-syntax */
t4=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t3,lf[53],((C_word*)t0)[14],lf[56],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t3=(C_word)C_eqp(t1,lf[57]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t1,lf[58]));
if(C_truep(t4)){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
t6=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4236,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t5=(C_word)C_eqp(t1,lf[59]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
if(C_truep(*((C_word*)lf[23]+1))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4252,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 358  ##sys#hash-table-location */
t8=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,*((C_word*)lf[23]+1),t6,C_SCHEME_TRUE);}
else{
t7=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4258,a[2]=t6,tmp=(C_word)a,a+=3,tmp));}}
else{
t6=(C_word)C_eqp(t1,lf[60]);
if(C_truep(t6)){
t7=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 363  compile */
t8=((C_word*)((C_word*)t0)[12])[1];
f_3928(t8,((C_word*)t0)[15],t7,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t7=(C_word)C_eqp(t1,lf[61]);
if(C_truep(t7)){
t8=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 366  compile */
t9=((C_word*)((C_word*)t0)[12])[1];
f_3928(t9,((C_word*)t0)[15],t8,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t8=(C_word)C_eqp(t1,lf[62]);
if(C_truep(t8)){
t9=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4292,tmp=(C_word)a,a+=2,tmp));}
else{
t9=(C_word)C_eqp(t1,lf[63]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4302,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 371  ##sys#check-syntax */
t11=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t11+1)))(7,t11,t10,lf[63],((C_word*)t0)[14],lf[65],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t10=(C_word)C_eqp(t1,lf[66]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t1,lf[67]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4362,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 380  ##sys#check-syntax */
t13=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t13+1)))(7,t13,t12,lf[66],((C_word*)t0)[14],lf[70],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t12=(C_word)C_eqp(t1,lf[71]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t1,lf[72]));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4474,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[14],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 396  ##sys#check-syntax */
t15=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t15+1)))(7,t15,t14,lf[71],((C_word*)t0)[14],lf[75],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t14=(C_word)C_eqp(t1,lf[76]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t1,lf[77]));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4586,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 420  ##sys#check-syntax */
t17=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t17+1)))(7,t17,t16,lf[76],((C_word*)t0)[14],lf[85],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t16=(C_word)C_eqp(t1,lf[86]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t1,lf[87]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4931,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[14],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 472  ##sys#check-syntax */
t19=*((C_word*)lf[55]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t18,lf[86],((C_word*)t0)[14],lf[89]);}
else{
t18=(C_word)C_eqp(t1,lf[90]);
t19=(C_truep(t18)?t18:(C_word)C_eqp(t1,lf[91]));
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5020,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 487  ##sys#check-syntax */
t21=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t21+1)))(7,t21,t20,lf[90],((C_word*)t0)[14],lf[99],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t20=(C_word)C_eqp(t1,lf[100]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5384,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 582  ##sys#check-syntax */
t22=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t22+1)))(7,t22,t21,lf[100],((C_word*)t0)[14],lf[102],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t21=(C_word)C_eqp(t1,lf[103]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5437,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 597  ##sys#check-syntax */
t23=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t23+1)))(7,t23,t22,lf[103],((C_word*)t0)[14],lf[104],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t22=(C_word)C_eqp(t1,lf[105]);
t23=(C_truep(t22)?t22:(C_word)C_eqp(t1,lf[106]));
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5505,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t25=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5592,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=t24,tmp=(C_word)a,a+=5,tmp);
t26=(C_word)C_slot(((C_word*)t0)[14],C_fix(1));
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
t28=t25;
f_5592(t28,(C_word)C_i_pairp(t27));}
else{
t27=t25;
f_5592(t27,C_SCHEME_FALSE);}}
else{
t24=(C_word)C_eqp(t1,lf[114]);
if(C_truep(t24)){
/* eval.scm: 636  compile */
t25=((C_word*)((C_word*)t0)[12])[1];
f_3928(t25,((C_word*)t0)[15],lf[115],((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t25=(C_word)C_eqp(t1,lf[116]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5628,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t27=(C_word)C_u_i_cddr(((C_word*)t0)[14]);
/* eval.scm: 640  ##sys#canonicalize-body */
t28=*((C_word*)lf[80]+1);
((C_proc5)(void*)(*((C_word*)t28+1)))(5,t28,t26,t27,((C_word*)t0)[13],C_SCHEME_FALSE);}
else{
t26=(C_word)C_eqp(t1,lf[117]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5641,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
t28=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 644  rename */
t29=((C_word*)t0)[4];
f_3760(t29,t27,t28,((C_word*)t0)[13]);}
else{
t27=(C_word)C_eqp(t1,lf[124]);
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5864,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 689  rename */
t29=((C_word*)t0)[4];
f_3760(t29,t28,lf[90],((C_word*)t0)[13]);}
else{
t28=(C_word)C_eqp(t1,lf[125]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5893,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 692  rename */
t30=((C_word*)t0)[4];
f_3760(t30,t29,lf[90],((C_word*)t0)[13]);}
else{
t29=(C_word)C_eqp(t1,lf[126]);
if(C_truep(t29)){
t30=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5910,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5949,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t32=(C_word)C_slot(((C_word*)t0)[14],C_fix(1));
/* map */
t33=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t33+1)))(4,t33,t30,t31,t32);}
else{
t30=(C_word)C_eqp(t1,lf[130]);
if(C_truep(t30)){
t31=(C_word)C_u_i_caddr(((C_word*)t0)[14]);
t32=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5973,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t33=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
t34=C_SCHEME_UNDEFINED;
t35=(*a=C_VECTOR_TYPE|1,a[1]=t34,tmp=(C_word)a,a+=2,tmp);
t36=C_set_block_item(t35,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5979,a[2]=t35,a[3]=t31,tmp=(C_word)a,a+=4,tmp));
t37=((C_word*)t35)[1];
f_5979(t37,t32,t33);}
else{
t31=(C_word)C_eqp(t1,lf[133]);
t32=(C_truep(t31)?t31:(C_word)C_eqp(t1,lf[134]));
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6033,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t34=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 718  eval/meta */
f_3877(t33,t34);}
else{
t33=(C_word)C_eqp(t1,lf[136]);
if(C_truep(t33)){
t34=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 722  compile */
t35=((C_word*)((C_word*)t0)[12])[1];
f_3928(t35,((C_word*)t0)[15],t34,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t34=(C_word)C_eqp(t1,lf[137]);
t35=(C_truep(t34)?t34:(C_word)C_eqp(t1,lf[138]));
if(C_truep(t35)){
/* eval.scm: 725  compile */
t36=((C_word*)((C_word*)t0)[12])[1];
f_3928(t36,((C_word*)t0)[15],lf[139],((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t36=(C_word)C_eqp(t1,lf[140]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6074,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_u_i_memq(lf[142],*((C_word*)lf[143]+1)))){
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6085,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t39=(C_word)C_slot(((C_word*)t0)[14],C_fix(1));
/* for-each */
t40=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t40+1)))(4,t40,t37,t38,t39);}
else{
/* eval.scm: 730  ##sys#warn */
t38=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t38+1)))(4,t38,t37,lf[146],((C_word*)t0)[14]);}}
else{
t37=(C_word)C_eqp(t1,lf[147]);
t38=(C_truep(t37)?t37:(C_word)C_eqp(t1,lf[148]));
if(C_truep(t38)){
t39=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6116,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 734  rename */
t40=((C_word*)t0)[4];
f_3760(t40,t39,lf[149],((C_word*)t0)[13]);}
else{
t39=(C_word)C_eqp(t1,lf[51]);
t40=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6133,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[2],a[7]=t1,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t39)){
t41=t40;
f_6133(t41,t39);}
else{
t41=(C_word)C_eqp(t1,lf[154]);
if(C_truep(t41)){
t42=t40;
f_6133(t42,t41);}
else{
t42=(C_word)C_eqp(t1,lf[155]);
if(C_truep(t42)){
t43=t40;
f_6133(t43,t42);}
else{
t43=(C_word)C_eqp(t1,lf[156]);
if(C_truep(t43)){
t44=t40;
f_6133(t44,t43);}
else{
t44=(C_word)C_eqp(t1,lf[157]);
if(C_truep(t44)){
t45=t40;
f_6133(t45,t44);}
else{
t45=(C_word)C_eqp(t1,lf[158]);
if(C_truep(t45)){
t46=t40;
f_6133(t46,t45);}
else{
t46=(C_word)C_eqp(t1,lf[159]);
if(C_truep(t46)){
t47=t40;
f_6133(t47,t46);}
else{
t47=(C_word)C_eqp(t1,lf[160]);
if(C_truep(t47)){
t48=t40;
f_6133(t48,t47);}
else{
t48=(C_word)C_eqp(t1,lf[161]);
t49=t40;
f_6133(t49,(C_truep(t48)?t48:(C_word)C_eqp(t1,lf[162])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k6131 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_6133(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 741  ##sys#syntax-error-hook */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[9],lf[150],((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[151]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* eval.scm: 744  compile-call */
t4=((C_word*)((C_word*)t0)[6])[1];
f_6362(t4,((C_word*)t0)[9],t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[152]);
if(C_truep(t3)){
/* eval.scm: 748  ##sys#syntax-error-hook */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[9],lf[153],((C_word*)t0)[8]);}
else{
/* eval.scm: 750  compile-call */
t4=((C_word*)((C_word*)t0)[6])[1];
f_6362(t4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}}}

/* k6114 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* ##sys#append */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6118 in k6114 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6120,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* eval.scm: 734  compile */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3928(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6084 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6085(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6085,3,t0,t1,t2);}
/* eval.scm: 729  ##compiler#process-declaration */
t3=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k6072 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 731  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3928(t2,((C_word*)t0)[6],lf[141],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6031 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 719  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3928(t2,((C_word*)t0)[6],lf[135],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_5979(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5979,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[131]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5991,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6001,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}}

/* a6000 in loop in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6001,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6017,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 714  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5979(t6,t4,t5);}

/* k6015 in a6000 in loop in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_6017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6017,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[67],t3));}

/* a5990 in loop in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5991,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* eval.scm: 713  ##sys#do-the-right-thing */
t3=*((C_word*)lf[132]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5971 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 708  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3928(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5948 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5949(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5949,3,t0,t1,t2);}
/* eval.scm: 696  eval/meta */
f_3877(t1,t2);}

/* k5908 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5913,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,*((C_word*)lf[128]+1),t1);}

/* k5911 in k5908 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 699  ##sys#lookup-runtime-requirements */
t3=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5914 in k5911 in k5908 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
f_5923(t3,lf[127]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5933,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5937,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5939,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t1);}}

/* a5938 in k5914 in k5911 in k5908 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5939(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5939,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[53],t3));}

/* k5935 in k5914 in k5911 in k5908 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5931 in k5914 in k5911 in k5908 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5933,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5923(t2,(C_word)C_a_i_cons(&a,2,lf[128],t1));}

/* k5921 in k5914 in k5911 in k5908 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_5923(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 700  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3928(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5891 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
/* ##sys#append */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5895 in k5891 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5897,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* eval.scm: 692  compile */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3928(t4,((C_word*)t0)[6],t2,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5862 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5868,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* ##sys#append */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5866 in k5862 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5868,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* eval.scm: 689  compile */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3928(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5641,2,t0,t1);}
t2=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5647,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_5647(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5783,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5835,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 659  ##sys#strip-syntax */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}}

/* k5833 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5782 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5783,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5796,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5807,tmp=(C_word)a,a+=2,tmp);
t5=t3;
f_5796(t5,f_5807(t2));}
else{
t4=t3;
f_5796(t4,C_SCHEME_FALSE);}}}

/* loop in a5782 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static C_word C_fcall f_5807(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_u_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* k5794 in a5782 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_5796(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
/* eval.scm: 656  ##sys#syntax-error-hook */
t2=*((C_word*)lf[48]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[121],lf[123],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5650,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5775,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 660  ##sys#current-module */
t4=*((C_word*)lf[41]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5773 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 661  ##sys#syntax-error-hook */
t2=*((C_word*)lf[48]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[121],lf[122],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5650(2,t2,C_SCHEME_UNDEFINED);}}

/* k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5650,2,t0,t1);}
t2=*((C_word*)lf[41]+1);
t3=*((C_word*)lf[109]+1);
t4=*((C_word*)lf[42]+1);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5653,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=t3,a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 663  ##sys#register-module */
t6=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5651 in k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5653,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[118]+1);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5654,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=t7,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5681,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[2],t8,t9,t8);}

/* a5680 in k5651 in k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5681,2,t0,t1);}
t2=(C_word)C_u_i_cdddr(((C_word*)t0)[6]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5691(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in a5680 in k5651 in k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_5691(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5691,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5701,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 668  reverse */
t5=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5764,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 685  ##sys#current-environment */
t8=*((C_word*)lf[109]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k5770 in loop in a5680 in k5651 in k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 682  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3928(t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5762 in loop in a5680 in k5651 in k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5764,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* eval.scm: 680  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5691(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5699 in loop in a5680 in k5651 in k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5704,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5749,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 669  ##sys#current-module */
t4=*((C_word*)lf[41]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5747 in k5699 in loop in a5680 in k5651 in k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 669  ##sys#finalize-module */
t2=*((C_word*)lf[119]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5702 in k5699 in loop in a5680 in k5651 in k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5704,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5705,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));}

/* f_5705 in k5702 in k5699 in loop in a5680 in k5651 in k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5705,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5711,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5711(t6,t1,((C_word*)t0)[2]);}

/* loop2 */
static void C_fcall f_5711(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5711,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[39]+1));}
else{
t3=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5733,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=t4;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,((C_word*)t0)[2]);}}}

/* k5731 in loop2 */
static void C_ccall f_5733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 677  loop2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5711(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* swap1092 in k5651 in k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* g109510961107 */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5656 in swap1092 in k5651 in k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5661,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g109510961107 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[8])[1]);}

/* k5659 in k5656 in swap1092 in k5651 in k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5661,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g109710981108 */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5663 in k5659 in k5656 in swap1092 in k5651 in k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5668,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g109710981108 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k5666 in k5663 in k5659 in k5656 in swap1092 in k5651 in k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5668,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g109911001109 */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5670 in k5666 in k5663 in k5659 in k5656 in swap1092 in k5651 in k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5675,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g109911001109 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k5673 in k5670 in k5666 in k5663 in k5659 in k5656 in swap1092 in k5651 in k5648 in k5645 in k5639 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5626 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 639  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3928(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5590 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_5592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[112]:lf[113]);
/* eval.scm: 615  ##sys#check-syntax */
t3=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,((C_word*)t0)[4],lf[105],((C_word*)t0)[3],t2,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5503 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t3))){
/* eval.scm: 621  caadr */
t4=*((C_word*)lf[111]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,((C_word*)t0)[2]);}
else{
t4=t2;
f_5508(2,t4,(C_word)C_u_i_cadr(((C_word*)t0)[2]));}}

/* k5506 in k5503 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5511,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5549,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 623  rename */
t5=((C_word*)t0)[3];
f_3760(t5,t4,lf[90],((C_word*)t0)[5]);}
else{
t4=t2;
f_5511(t4,(C_word)C_u_i_caddr(((C_word*)t0)[2]));}}

/* k5547 in k5506 in k5503 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5549,2,t0,t1);}
t2=(C_word)C_u_i_cdadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5561,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k5559 in k5547 in k5506 in k5503 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5561,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_5511(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5509 in k5506 in k5503 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_5511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5511,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5514,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 625  rename */
t3=((C_word*)t0)[3];
f_3760(t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k5512 in k5509 in k5506 in k5503 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5539,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 627  ##sys#current-module */
t4=*((C_word*)lf[41]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5537 in k5512 in k5509 in k5506 in k5503 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 626  ##sys#register-syntax-export */
t2=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5515 in k5512 in k5509 in k5506 in k5503 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5520,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 631  ##sys#current-environment */
t4=*((C_word*)lf[109]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5525 in k5515 in k5512 in k5509 in k5506 in k5503 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5531,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5535,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 632  eval/meta */
f_3877(t3,((C_word*)t0)[2]);}

/* k5533 in k5525 in k5515 in k5512 in k5509 in k5506 in k5503 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 632  ##sys#er-transformer */
t2=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5529 in k5525 in k5515 in k5512 in k5509 in k5506 in k5503 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 629  ##sys#extend-macro-environment */
t2=*((C_word*)lf[108]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5518 in k5515 in k5512 in k5509 in k5506 in k5503 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 633  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3928(t2,((C_word*)t0)[6],lf[107],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5435 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5440,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5469,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* map */
t5=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5468 in k5435 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5469,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5481,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5485,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cadr(t2);
/* eval.scm: 603  eval/meta */
f_3877(t5,t6);}

/* k5483 in a5468 in k5435 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 602  ##sys#er-transformer */
t2=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5479 in a5468 in k5435 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5481,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k5438 in k5435 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5443,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 605  append */
t3=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k5441 in k5438 in k5435 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5446,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5459,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5458 in k5441 in k5438 in k5435 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5459,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(t3,C_fix(0),((C_word*)t0)[2]));}

/* k5444 in k5441 in k5438 in k5435 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5453,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 611  ##sys#canonicalize-body */
t4=*((C_word*)lf[80]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,((C_word*)t0)[3],C_SCHEME_FALSE);}

/* k5451 in k5444 in k5441 in k5438 in k5435 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 610  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3928(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5382 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5387,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5402,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* map */
t6=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a5403 in k5382 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5404(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5404,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5416,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5420,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cadr(t2);
/* eval.scm: 589  eval/meta */
f_3877(t5,t6);}

/* k5418 in a5403 in k5382 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 588  ##sys#er-transformer */
t2=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5414 in a5403 in k5382 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5416,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5400 in k5382 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 583  append */
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5385 in k5382 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5394,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 593  ##sys#canonicalize-body */
t4=*((C_word*)lf[80]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,t1,C_SCHEME_FALSE);}

/* k5392 in k5385 in k5382 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 592  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3928(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5020,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[7];
t9=(C_truep(t8)?t8:lf[92]);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t4)[1]);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5032,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],a[8]=t10,a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5357,a[2]=t11,a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 491  ##sys#extended-lambda-list? */
t13=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t4)[1]);}

/* k5355 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5357,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5362,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5368,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_5032(2,t2,C_SCHEME_UNDEFINED);}}

/* a5367 in k5355 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5368,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a5361 in k5355 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5362,2,t0,t1);}
/* eval.scm: 494  ##sys#expand-extended-lambda-list */
t2=*((C_word*)lf[97]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[48]+1),((C_word*)t0)[2]);}

/* k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5037,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 496  ##sys#decompose-lambda-list */
t3=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5037,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5041,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=t1,a[11]=t3,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* map */
t6=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[84]+1),t2);}

/* k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5044,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5354,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 500  map */
t4=*((C_word*)lf[82]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[83]+1),((C_word*)t0)[2],t1);}

/* k5352 in k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 500  append */
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5042 in k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5044,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5050,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5346,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 504  ##sys#canonicalize-body */
t5=*((C_word*)lf[80]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)((C_word*)t0)[2])[1],t1,C_SCHEME_FALSE);}

/* k5344 in k5042 in k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[6];
t3=(C_truep(t2)?t2:((C_word*)t0)[5]);
/* eval.scm: 503  ##sys#compile-to-closure */
t4=*((C_word*)lf[36]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k5048 in k5042 in k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5050,2,t0,t1);}
t2=((C_word*)t0)[8];
switch(t2){
case C_fix(0):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(1):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(2):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5169,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(3):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
default:
t3=(C_word)C_eqp(t2,C_fix(4));
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)):(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp):(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp))));}}

/* f_5308 in k5048 in k5042 in k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5308(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5308,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5314,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 573  decorate */
f_3871(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5313 */
static void C_ccall f_5314(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5314r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5314r(t0,t1,t2);}}

static void C_ccall f_5314r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(t3,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5338,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,*((C_word*)lf[93]+1),t2);}
else{
/* eval.scm: 577  ##sys#error */
t5=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[95],((C_word*)t0)[4],t3);}}

/* k5336 in a5313 */
static void C_ccall f_5338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5338,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5285 in k5048 in k5042 in k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5285,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5291,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 566  decorate */
f_3871(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5290 */
static void C_ccall f_5291(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr2r,(void*)f_5291r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5291r(t0,t1,t2);}}

static void C_ccall f_5291r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(14);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5303,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5307,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t2))){
t6=t4;
f_5307(2,t6,(C_word)C_a_i_list(&a,1,t2));}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6290,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_6290(t9,t4,t5,C_fix(0),t2,C_SCHEME_FALSE);}}

/* doloop1301 in a5290 */
static void C_fcall f_6290(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6290,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t6)){
t7=(C_word)C_a_i_list(&a,1,t4);
t8=(C_word)C_i_setslot(t5,C_fix(1),t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6319,a[2]=t4,a[3]=t8,a[4]=t7,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t10=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t10)){
/* eval.scm: 763  ##sys#error */
t11=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t9,lf[94],t2,t3);}
else{
t11=t9;
f_6319(2,t11,(C_word)C_slot(t4,C_fix(1)));}}}

/* k6317 in doloop1301 in a5290 */
static void C_ccall f_6319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[6])[1];
f_6290(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5305 in a5290 */
static void C_ccall f_5307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[93]+1),t1);}

/* k5301 in a5290 */
static void C_ccall f_5303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5303,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5263 in k5048 in k5042 in k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5263(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5263,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5269,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 559  decorate */
f_3871(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5268 */
static void C_ccall f_5269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5269,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5281,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 561  ##sys#vector */
t7=*((C_word*)lf[93]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k5279 in a5268 */
static void C_ccall f_5281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5281,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5244 in k5048 in k5042 in k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5244(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5244,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5250,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 554  decorate */
f_3871(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5249 */
static void C_ccall f_5250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr6r,(void*)f_5250r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_5250r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_5250r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t7=(C_word)C_a_i_vector(&a,5,t2,t3,t4,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t8);}

/* f_5216 in k5048 in k5042 in k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5216,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5222,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 548  decorate */
f_3871(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5221 */
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5222,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_5197 in k5048 in k5042 in k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5197(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5197,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5203,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 543  decorate */
f_3871(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5202 */
static void C_ccall f_5203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_5203r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5203r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5203r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_a_i_vector(&a,4,t2,t3,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,t7);}

/* f_5169 in k5048 in k5042 in k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5169(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5169,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5175,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 537  decorate */
f_3871(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5174 */
static void C_ccall f_5175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5175,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_5150 in k5048 in k5042 in k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5150(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5150,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5156,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 532  decorate */
f_3871(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5155 */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_5156r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5156r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5156r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_5122 in k5048 in k5042 in k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5122,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5128,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 526  decorate */
f_3871(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5127 */
static void C_ccall f_5128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5128,3,t0,t1,t2);}
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* f_5103 in k5048 in k5042 in k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5103,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5109,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 521  decorate */
f_3871(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5108 */
static void C_ccall f_5109(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5109r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5109r(t0,t1,t2,t3);}}

static void C_ccall f_5109r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_5079 in k5048 in k5042 in k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5079(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5079,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5085,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 516  decorate */
f_3871(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5084 */
static void C_ccall f_5085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5085,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f_5060 in k5048 in k5042 in k5039 in a5036 in k5030 in k5018 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5060(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5060,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5066,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 511  decorate */
f_3871(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5065 */
static void C_ccall f_5066(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5066r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5066r(t0,t1,t2);}}

static void C_ccall f_5066r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* k4929 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4931,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4952,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5000,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 477  ##sys#map */
t6=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a4999 in k4929 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_5000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5000,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t3,lf[88]));}

/* k4950 in k4929 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4956,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4960,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4978,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 480  ##sys#map */
t5=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4977 in k4950 in k4929 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4978,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[72],t6));}

/* k4958 in k4950 in k4929 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4976,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4974 in k4958 in k4950 in k4929 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4976,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[77],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k4954 in k4950 in k4929 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4956,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[77],t2);
/* eval.scm: 475  compile */
t4=((C_word*)((C_word*)t0)[8])[1];
f_3928(t4,((C_word*)t0)[7],t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4586,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4595,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4915,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a4914 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4915,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* map */
t3=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[84]+1),t1);}

/* k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4598,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4604,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4913,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 426  map */
t5=*((C_word*)lf[82]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,*((C_word*)lf[83]+1),((C_word*)t0)[7],t1);}

/* k4911 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 426  append */
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4607,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4905,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 428  ##sys#canonicalize-body */
t5=*((C_word*)lf[80]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,t1,C_SCHEME_FALSE);}

/* k4903 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 427  ##sys#compile-to-closure */
t2=*((C_word*)lf[36]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4607,2,t0,t1);}
switch(((C_word*)t0)[10]){
case C_fix(1):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4616,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 433  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3928(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(2):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 436  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3928(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(3):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 440  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3928(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(4):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 448  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3928(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4842,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* map */
t4=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}}

/* a4888 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4889(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4889,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 462  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3928(t5,t1,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4840 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4842,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4843,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4843 in k4840 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4843(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4843,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 464  ##sys#make-vector */
t4=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k4845 */
static void C_ccall f_4847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4850,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4859,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4859(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* doloop851 in k4845 */
static void C_fcall f_4859(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4859,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4884,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}

/* k4882 in doloop851 in k4845 */
static void C_ccall f_4884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_4859(t5,((C_word*)t0)[2],t3,t4);}

/* k4848 in k4845 */
static void C_ccall f_4850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4850,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k4764 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[10]);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 449  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3928(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4767 in k4764 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4769,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 451  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3928(t6,t3,t4,((C_word*)t0)[5],t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4773 in k4767 in k4764 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4778,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[8]);
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[7]);
/* eval.scm: 452  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3928(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4776 in k4773 in k4767 in k4764 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4778,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));}

/* f_4779 in k4776 in k4773 in k4767 in k4764 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4779,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4793 */
static void C_ccall f_4795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4799,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* k4797 in k4793 */
static void C_ccall f_4799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4803,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4801 in k4797 in k4793 */
static void C_ccall f_4803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4807,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4805 in k4801 in k4797 in k4793 */
static void C_ccall f_4807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4807,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4697 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[10]);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 441  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3928(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4700 in k4697 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4702,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4708,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 443  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3928(t6,t3,t4,((C_word*)t0)[5],t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4706 in k4700 in k4697 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4708,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));}

/* f_4709 in k4706 in k4700 in k4697 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4709(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4709,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4725,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4723 */
static void C_ccall f_4725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4729,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4727 in k4723 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4733,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4731 in k4727 in k4723 */
static void C_ccall f_4733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4733,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4648 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4653,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[8]);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 437  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3928(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4651 in k4648 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4653,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4654,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4654 in k4651 in k4648 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4654,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4670,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4668 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4674,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4672 in k4668 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4674,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4614 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4616,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4617,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_4617 in k4614 in k4605 in k4602 in k4596 in k4593 in k4584 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4617(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4617,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4633,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4631 */
static void C_ccall f_4633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4633,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,1,t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4472 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4474,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4482,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4488,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4487 in k4472 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4488,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4492,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[8]);
/* eval.scm: 399  compile */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3928(t6,t4,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4490 in a4487 in k4472 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4492,2,t0,t1);}
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=(C_word)C_i_zerop(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4549,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4562,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp)));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4501,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 401  ##sys#alias-global-hook */
t4=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_TRUE);}}

/* k4499 in k4490 in a4487 in k4472 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4501,2,t0,t1);}
if(C_truep(*((C_word*)lf[23]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4507,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 403  ##sys#hash-table-location */
t3=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[23]+1),t1,*((C_word*)lf[24]+1));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4534,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}}

/* f_4534 in k4499 in k4490 in a4487 in k4472 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4534,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4542,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4540 */
static void C_ccall f_4542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k4505 in k4499 in k4490 in a4487 in k4472 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4510(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 407  ##sys#error */
t3=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[74],((C_word*)t0)[2]);}}

/* k4508 in k4505 in k4499 in k4490 in a4487 in k4472 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4510,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4517,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4526,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}

/* f_4526 in k4508 in k4505 in k4499 in k4490 in a4487 in k4472 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4526(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4526,2,t0,t1);}
/* eval.scm: 410  ##sys#error */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[73],((C_word*)t0)[2]);}

/* f_4517 in k4508 in k4505 in k4499 in k4490 in a4487 in k4472 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4517,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4525,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4523 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* f_4562 in k4490 in a4487 in k4472 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4562(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4562,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4568 */
static void C_ccall f_4570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot((C_word)C_u_i_list_ref(((C_word*)t0)[4],((C_word*)t0)[3]),((C_word*)t0)[2],t1));}

/* f_4549 in k4490 in a4487 in k4472 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4549(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4549,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4561,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4559 */
static void C_ccall f_4561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4481 in k4472 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4482,2,t0,t1);}
/* eval.scm: 398  lookup */
t2=((C_word*)t0)[5];
f_3775(t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4360 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4362,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(0):
/* eval.scm: 384  compile */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3928(t4,((C_word*)t0)[6],lf[68],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(1):
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 385  compile */
t5=((C_word*)((C_word*)t0)[7])[1];
f_3928(t5,((C_word*)t0)[6],t4,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 386  compile */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3928(t6,t4,t5,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
default:
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4421,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 390  compile */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3928(t6,t4,t5,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4419 in k4360 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* eval.scm: 391  compile */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3928(t4,t2,t3,((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k4422 in k4419 in k4360 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4427,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4446,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(C_word)C_slot(t4,C_fix(1));
/* ##sys#append */
t6=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,C_SCHEME_END_OF_LIST);}

/* k4444 in k4422 in k4419 in k4360 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[67],t1);
/* eval.scm: 392  compile */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3928(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4425 in k4422 in k4419 in k4360 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4427,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp));}

/* f_4428 in k4425 in k4422 in k4419 in k4360 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4428,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4432,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4430 */
static void C_ccall f_4432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4435,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4433 in k4430 */
static void C_ccall f_4435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4397 in k4360 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4402,a[2]=t1,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 387  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3928(t4,t2,t3,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4400 in k4397 in k4360 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4402,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_4403 in k4400 in k4397 in k4360 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4403,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4407,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4405 */
static void C_ccall f_4407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4300 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 372  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3928(t4,t2,t3,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4303 in k4300 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 373  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3928(t4,t2,t3,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4306 in k4303 in k4300 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4311,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cdddr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[7]);
/* eval.scm: 375  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3928(t5,t2,t4,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* eval.scm: 376  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3928(t4,t2,lf[64],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4309 in k4306 in k4303 in k4300 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4311,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4312,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4312 in k4309 in k4306 in k4303 in k4300 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4312,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4319,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4317 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* f_4292 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4292(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4292,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* f_4258 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4258(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4258,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* k4250 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4252,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4253,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_4253 in k4250 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4253(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4253,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* f_4236 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4236(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4236,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4156 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4161,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* eval.scm: 340  ##sys#strip-syntax */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k4159 in k4156 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4161,2,t0,t1);}
switch(t1){
case C_fix(-1):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4168,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4176,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4184,tmp=(C_word)a,a+=2,tmp));
case C_fix(2):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4192,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_TRUE:
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4200,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_FALSE:
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4208,tmp=(C_word)a,a+=2,tmp));
default:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4216,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4218,a[2]=t1,tmp=(C_word)a,a+=3,tmp)));}}

/* f_4218 in k4159 in k4156 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4218,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4216 in k4159 in k4156 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4216(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4216,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* f_4208 in k4159 in k4156 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4208(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4208,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4200 in k4159 in k4156 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4200(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4200,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4192 in k4159 in k4156 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4192(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4192,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4184 in k4159 in k4156 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4184,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4176 in k4159 in k4156 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4176,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4168 in k4159 in k4156 in k4147 in k4132 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4168,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* f_4112 in k4109 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4112(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4112,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4101 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4101(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4101,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4099 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4099,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4088 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4088,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4086 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4086,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4078 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4078(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4078,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4070 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4062 in k4053 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4062,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* a3953 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3954,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(t4)){
t5=(C_word)C_i_zerop(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4036,a[2]=t3,tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4045,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp)));}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3964,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_u_i_assq(((C_word*)t0)[3],((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4022,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 291  ##sys#get */
t7=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[51]);}
else{
/* eval.scm: 290  ##sys#alias-global-hook */
t6=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,C_SCHEME_FALSE);}}}

/* k4020 in a3953 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3964(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k3962 in a3953 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3964,2,t0,t1);}
if(C_truep(*((C_word*)lf[23]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3970,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 293  ##sys#hash-table-location */
t3=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[23]+1),t1,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3993,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3998,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[31]+1))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4013,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 306  ##sys#symbol-has-toplevel-binding? */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}
else{
t4=t3;
f_3998(t4,C_SCHEME_FALSE);}}}

/* k4011 in k3962 in a3953 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3998(t2,(C_word)C_i_not(t1));}

/* k3996 in k3962 in a3953 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_3998(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3998,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,*((C_word*)lf[31]+1));
t4=C_mutate((C_word*)lf[31]+1 /* (set! unbound-in-eval ...) */,t3);
t5=((C_word*)t0)[2];
f_3993(t5,t4);}
else{
t2=((C_word*)t0)[2];
f_3993(t2,C_SCHEME_UNDEFINED);}}

/* k3991 in k3962 in a3953 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_3993(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3993,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3994,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));}

/* f_3994 in k3991 in k3962 in a3953 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3994,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_retrieve(((C_word*)t0)[2]));}

/* k3968 in k3962 in a3953 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_3973(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 294  ##sys#syntax-error-hook */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[49],((C_word*)t0)[2]);}}

/* k3971 in k3968 in k3962 in a3953 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3973,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));}

/* f_3974 in k3971 in k3968 in k3962 in a3953 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3974,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
if(C_truep(t3)){
/* eval.scm: 301  ##sys#error */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[47],((C_word*)t0)[2]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* f_4045 in a3953 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4045(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4045,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot((C_word)C_u_i_list_ref(t2,((C_word*)t0)[3]),((C_word*)t0)[2]));}

/* f_4036 in a3953 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_4036(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4036,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t3,((C_word*)t0)[2]));}

/* a3947 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3948,2,t0,t1);}
/* eval.scm: 287  lookup */
t2=((C_word*)t0)[5];
f_3775(t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_3936 in k3933 in compile in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3936(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3936,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* eval/meta in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_3877(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3877,NULL,2,t1,t2);}
t3=*((C_word*)lf[41]+1);
t4=*((C_word*)lf[42]+1);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3881,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 270  ##sys#meta-macro-environment */
t8=*((C_word*)lf[45]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}

/* k3879 in eval/meta in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3881,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3882,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3902,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#dynamic-wind */
t6=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,((C_word*)t0)[2],t4,t5,t4);}

/* a3901 in k3879 in eval/meta in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3909,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3913,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 274  ##sys#current-meta-environment */
t4=*((C_word*)lf[43]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3911 in a3901 in k3879 in eval/meta in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 271  ##sys#compile-to-closure */
t2=*((C_word*)lf[36]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* k3907 in a3901 in k3879 in eval/meta in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* swap489 in k3879 in eval/meta in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* g492493501 */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3884 in swap489 in k3879 in eval/meta in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g492493501 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k3887 in k3884 in swap489 in k3879 in eval/meta in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3889,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g494495502 */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3891 in k3887 in k3884 in swap489 in k3879 in eval/meta in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3896,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g494495502 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k3894 in k3891 in k3887 in k3884 in swap489 in k3879 in eval/meta in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* decorate in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_3871(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3871,NULL,5,t1,t2,t3,t4,t5);}
/* eval.scm: 266  ##sys#eval-decorator */
t6=*((C_word*)lf[25]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t3,t4,t5);}

/* emit-syntax-trace-info in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static C_word C_fcall f_3865(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_truep(t1)?(C_word)C_emit_syntax_trace_info(t2,t3,*((C_word*)lf[40]+1)):C_SCHEME_UNDEFINED));}

/* emit-trace-info in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static C_word C_fcall f_3859(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_truep(t1)?(C_word)C_emit_eval_trace_info(t2,t3,*((C_word*)lf[40]+1)):C_SCHEME_UNDEFINED));}

/* lookup in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_3775(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3775,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3779,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 244  rename */
t6=((C_word*)t0)[2];
f_3760(t6,t5,t2,t4);}

/* k3777 in lookup in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3779,2,t0,t1);}
t2=*((C_word*)lf[39]+1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3787,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3787(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* loop in k3777 in lookup in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_3787(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3787,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* eval.scm: 247  values */
C_values(4,0,t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3829,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=f_3829(t6,t4,C_fix(0));
if(C_truep(t7)){
/* eval.scm: 248  values */
C_values(4,0,t1,t3,t7);}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 249  loop */
t11=t1;
t12=t8;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* loop in loop in k3777 in lookup in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static C_word C_fcall f_3829(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* rename in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_3760(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3760,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3764,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 239  find-id */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3721(t5,t4,t2,t3);}

/* k3762 in rename in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3764,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 240  ##sys#get */
t3=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[38]);}}

/* k3768 in k3762 in rename in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_ccall f_3770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* find-id in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_3721(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3721,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3734,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_caar(t3);
t6=(C_word)C_eqp(t2,t5);
if(C_truep(t6)){
t7=(C_word)C_u_i_cdar(t3);
t8=t4;
f_3734(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t4;
f_3734(t7,C_SCHEME_FALSE);}}}

/* k3732 in find-id in ##sys#compile-to-closure in k3373 in k3370 in k3337 */
static void C_fcall f_3734(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_cdar(((C_word*)t0)[4]));}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 236  find-id */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3721(t3,((C_word*)t0)[5],((C_word*)t0)[2],t2);}}

/* ##sys#eval-decorator in k3373 in k3370 in k3337 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3671,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3677,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3690,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 208  ##sys#decorate-lambda */
t8=*((C_word*)lf[30]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,t6,t7);}

/* a3689 in ##sys#eval-decorator in k3373 in k3370 in k3337 */
static void C_ccall f_3690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3690,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3698,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3702,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 215  open-output-string */
t6=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3700 in a3689 in ##sys#eval-decorator in k3373 in k3370 in k3337 */
static void C_ccall f_3702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3705,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 216  write */
t3=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3703 in k3700 in a3689 in ##sys#eval-decorator in k3373 in k3370 in k3337 */
static void C_ccall f_3705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3708,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 217  get-output-string */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3706 in k3703 in k3700 in a3689 in ##sys#eval-decorator in k3373 in k3370 in k3337 */
static void C_ccall f_3708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 214  ##sys#make-lambda-info */
t2=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3696 in a3689 in ##sys#eval-decorator in k3373 in k3370 in k3337 */
static void C_ccall f_3698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}

/* a3676 in ##sys#eval-decorator in k3373 in k3370 in k3337 */
static void C_ccall f_3677(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3677,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_lambdainfop(t2)));}

/* ##sys#hash-table-location in k3373 in k3370 in k3337 */
static void C_ccall f_3611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3611,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3615,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_block_size(t2);
/* eval.scm: 188  ##sys#hash-symbol */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t3,t6);}

/* k3613 in ##sys#hash-table-location in k3373 in k3370 in k3337 */
static void C_ccall f_3615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3615,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3623,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3623(t6,((C_word*)t0)[2],t2);}

/* loop in k3613 in ##sys#hash-table-location in k3373 in k3370 in k3337 */
static void C_fcall f_3623(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3623,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[8])){
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[7],((C_word*)t0)[6],C_SCHEME_TRUE);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[7],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 199  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-for-each in k3373 in k3370 in k3337 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3565,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3571,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3571(t8,t1,C_fix(0));}

/* doloop286 in ##sys#hash-table-for-each in k3373 in k3370 in k3337 */
static void C_fcall f_3571(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3571,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3581,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3590,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* eval.scm: 182  ##sys#for-each */
t6=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a3589 in doloop286 in ##sys#hash-table-for-each in k3373 in k3370 in k3337 */
static void C_ccall f_3590(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3590,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 182  p */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k3579 in doloop286 in ##sys#hash-table-for-each in k3373 in k3370 in k3337 */
static void C_ccall f_3581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3571(t3,((C_word*)t0)[2],t2);}

/* ##sys#hash-table-update! in k3373 in k3370 in k3337 */
static void C_ccall f_3545(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3545,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3553,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3557,a[2]=t5,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 176  ##sys#hash-table-ref */
t8=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t2,t3);}

/* k3555 in ##sys#hash-table-update! in k3373 in k3370 in k3337 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3560,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_3560(2,t3,t1);}
else{
/* eval.scm: 176  valufunc */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3558 in k3555 in ##sys#hash-table-update! in k3373 in k3370 in k3337 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 176  updtfunc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3551 in ##sys#hash-table-update! in k3373 in k3370 in k3337 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 176  ##sys#hash-table-set! */
t2=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#hash-table-set! in k3373 in k3370 in k3337 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3485,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3489,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 166  ##sys#hash-symbol */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,(C_word)C_block_size(t2));}

/* k3487 in ##sys#hash-table-set! in k3373 in k3370 in k3337 */
static void C_ccall f_3489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3489,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3497,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3497(t6,((C_word*)t0)[2],t2);}

/* loop in k3487 in ##sys#hash-table-set! in k3373 in k3370 in k3337 */
static void C_fcall f_3497(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3497,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t5));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[7],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t2,C_fix(0));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t7,C_fix(1),((C_word*)t0)[6]));}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 173  loop */
t12=t1;
t13=t7;
t1=t12;
t2=t13;
goto loop;}}}

/* ##sys#hash-table-ref in k3373 in k3370 in k3337 */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3430,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3483,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 159  ##sys#hash-symbol */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,(C_word)C_block_size(t2));}

/* k3481 in ##sys#hash-table-ref in k3373 in k3370 in k3337 */
static void C_ccall f_3483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3483,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3440,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_3440(t3,t2));}

/* loop in k3481 in ##sys#hash-table-ref in k3373 in k3370 in k3337 */
static C_word C_fcall f_3440(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
t2=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t1);
if(C_truep(t2)){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t1,C_fix(0));
return((C_word)C_slot(t6,C_fix(1)));}
else{
t6=(C_word)C_slot(t1,C_fix(1));
t9=t6;
t1=t9;
goto loop;}}}

/* ##sys#hash-symbol in k3373 in k3370 in k3337 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3415,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3));}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_hash_string(t6));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3));}}

/* chicken-home in k3373 in k3370 in k3337 */
static void C_ccall f_3403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3407,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 141  ##sys#chicken-prefix */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[14]);}

/* k3405 in chicken-home in k3373 in k3370 in k3337 */
static void C_ccall f_3407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3407,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}}

/* ##sys#chicken-prefix in k3373 in k3370 in k3337 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3376r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3376r(t0,t1,t2);}}

static void C_ccall f_3376r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t4)){
/* eval.scm: 135  ##sys#string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[2]);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* d in k3337 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3341r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3341r(t0,t1,t2,t3);}}

static void C_ccall f_3341r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
if(C_truep((C_word)C_i_nullp(t3))){
/* eval.scm: 38   pp */
t4=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
C_apply(5,0,t1,*((C_word*)lf[2]+1),t2,t3);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[767] = {
{"toplevel:eval_scm",(void*)C_eval_toplevel},
{"f_3339:eval_scm",(void*)f_3339},
{"f_3372:eval_scm",(void*)f_3372},
{"f_3375:eval_scm",(void*)f_3375},
{"f_10242:eval_scm",(void*)f_10242},
{"f_10246:eval_scm",(void*)f_10246},
{"f_10271:eval_scm",(void*)f_10271},
{"f_10261:eval_scm",(void*)f_10261},
{"f_10269:eval_scm",(void*)f_10269},
{"f_10254:eval_scm",(void*)f_10254},
{"f_10252:eval_scm",(void*)f_10252},
{"f_6610:eval_scm",(void*)f_6610},
{"f_6705:eval_scm",(void*)f_6705},
{"f_6786:eval_scm",(void*)f_6786},
{"f_10236:eval_scm",(void*)f_10236},
{"f_10232:eval_scm",(void*)f_10232},
{"f_10228:eval_scm",(void*)f_10228},
{"f_10224:eval_scm",(void*)f_10224},
{"f_10214:eval_scm",(void*)f_10214},
{"f_7314:eval_scm",(void*)f_7314},
{"f_7319:eval_scm",(void*)f_7319},
{"f_10192:eval_scm",(void*)f_10192},
{"f_10184:eval_scm",(void*)f_10184},
{"f_10186:eval_scm",(void*)f_10186},
{"f_7326:eval_scm",(void*)f_7326},
{"f_10153:eval_scm",(void*)f_10153},
{"f_10173:eval_scm",(void*)f_10173},
{"f_10169:eval_scm",(void*)f_10169},
{"f_10159:eval_scm",(void*)f_10159},
{"f_10156:eval_scm",(void*)f_10156},
{"f_7679:eval_scm",(void*)f_7679},
{"f_10099:eval_scm",(void*)f_10099},
{"f_10113:eval_scm",(void*)f_10113},
{"f_10149:eval_scm",(void*)f_10149},
{"f_10145:eval_scm",(void*)f_10145},
{"f_10133:eval_scm",(void*)f_10133},
{"f_10137:eval_scm",(void*)f_10137},
{"f_10107:eval_scm",(void*)f_10107},
{"f_8531:eval_scm",(void*)f_8531},
{"f_10002:eval_scm",(void*)f_10002},
{"f_10039:eval_scm",(void*)f_10039},
{"f_10042:eval_scm",(void*)f_10042},
{"f_10065:eval_scm",(void*)f_10065},
{"f_10069:eval_scm",(void*)f_10069},
{"f_10051:eval_scm",(void*)f_10051},
{"f_10048:eval_scm",(void*)f_10048},
{"f_10005:eval_scm",(void*)f_10005},
{"f_8534:eval_scm",(void*)f_8534},
{"f_8592:eval_scm",(void*)f_8592},
{"f_10000:eval_scm",(void*)f_10000},
{"f_8943:eval_scm",(void*)f_8943},
{"f_8947:eval_scm",(void*)f_8947},
{"f_9996:eval_scm",(void*)f_9996},
{"f_8950:eval_scm",(void*)f_8950},
{"f_8954:eval_scm",(void*)f_8954},
{"f_9221:eval_scm",(void*)f_9221},
{"f_9988:eval_scm",(void*)f_9988},
{"f_9243:eval_scm",(void*)f_9243},
{"f_9606:eval_scm",(void*)f_9606},
{"f_9979:eval_scm",(void*)f_9979},
{"f_9986:eval_scm",(void*)f_9986},
{"f_9969:eval_scm",(void*)f_9969},
{"f_9954:eval_scm",(void*)f_9954},
{"f_9958:eval_scm",(void*)f_9958},
{"f_9963:eval_scm",(void*)f_9963},
{"f_9967:eval_scm",(void*)f_9967},
{"f_9932:eval_scm",(void*)f_9932},
{"f_9936:eval_scm",(void*)f_9936},
{"f_9941:eval_scm",(void*)f_9941},
{"f_9945:eval_scm",(void*)f_9945},
{"f_9952:eval_scm",(void*)f_9952},
{"f_9906:eval_scm",(void*)f_9906},
{"f_9912:eval_scm",(void*)f_9912},
{"f_9916:eval_scm",(void*)f_9916},
{"f_9930:eval_scm",(void*)f_9930},
{"f_9919:eval_scm",(void*)f_9919},
{"f_9926:eval_scm",(void*)f_9926},
{"f_9890:eval_scm",(void*)f_9890},
{"f_9896:eval_scm",(void*)f_9896},
{"f_9904:eval_scm",(void*)f_9904},
{"f_9853:eval_scm",(void*)f_9853},
{"f_9857:eval_scm",(void*)f_9857},
{"f_9862:eval_scm",(void*)f_9862},
{"f_9866:eval_scm",(void*)f_9866},
{"f_9888:eval_scm",(void*)f_9888},
{"f_9884:eval_scm",(void*)f_9884},
{"f_9880:eval_scm",(void*)f_9880},
{"f_9869:eval_scm",(void*)f_9869},
{"f_9876:eval_scm",(void*)f_9876},
{"f_9827:eval_scm",(void*)f_9827},
{"f_9833:eval_scm",(void*)f_9833},
{"f_9837:eval_scm",(void*)f_9837},
{"f_9851:eval_scm",(void*)f_9851},
{"f_9840:eval_scm",(void*)f_9840},
{"f_9847:eval_scm",(void*)f_9847},
{"f_9814:eval_scm",(void*)f_9814},
{"f_9788:eval_scm",(void*)f_9788},
{"f_9792:eval_scm",(void*)f_9792},
{"f_9797:eval_scm",(void*)f_9797},
{"f_9801:eval_scm",(void*)f_9801},
{"f_9812:eval_scm",(void*)f_9812},
{"f_9808:eval_scm",(void*)f_9808},
{"f_9772:eval_scm",(void*)f_9772},
{"f_9778:eval_scm",(void*)f_9778},
{"f_9786:eval_scm",(void*)f_9786},
{"f_9760:eval_scm",(void*)f_9760},
{"f_9766:eval_scm",(void*)f_9766},
{"f_9770:eval_scm",(void*)f_9770},
{"f_9751:eval_scm",(void*)f_9751},
{"f_9755:eval_scm",(void*)f_9755},
{"f_9692:eval_scm",(void*)f_9692},
{"f_9702:eval_scm",(void*)f_9702},
{"f_9727:eval_scm",(void*)f_9727},
{"f_9739:eval_scm",(void*)f_9739},
{"f_9745:eval_scm",(void*)f_9745},
{"f_9733:eval_scm",(void*)f_9733},
{"f_9708:eval_scm",(void*)f_9708},
{"f_9714:eval_scm",(void*)f_9714},
{"f_9718:eval_scm",(void*)f_9718},
{"f_9721:eval_scm",(void*)f_9721},
{"f_9725:eval_scm",(void*)f_9725},
{"f_9700:eval_scm",(void*)f_9700},
{"f_9617:eval_scm",(void*)f_9617},
{"f_9627:eval_scm",(void*)f_9627},
{"f_9630:eval_scm",(void*)f_9630},
{"f_9644:eval_scm",(void*)f_9644},
{"f_9662:eval_scm",(void*)f_9662},
{"f_9631:eval_scm",(void*)f_9631},
{"f_9608:eval_scm",(void*)f_9608},
{"f_9264:eval_scm",(void*)f_9264},
{"f_9308:eval_scm",(void*)f_9308},
{"f_9311:eval_scm",(void*)f_9311},
{"f_9591:eval_scm",(void*)f_9591},
{"f_9595:eval_scm",(void*)f_9595},
{"f_9599:eval_scm",(void*)f_9599},
{"f_9393:eval_scm",(void*)f_9393},
{"f_9399:eval_scm",(void*)f_9399},
{"f_9574:eval_scm",(void*)f_9574},
{"f_9580:eval_scm",(void*)f_9580},
{"f_9406:eval_scm",(void*)f_9406},
{"f_9409:eval_scm",(void*)f_9409},
{"f_9412:eval_scm",(void*)f_9412},
{"f_9569:eval_scm",(void*)f_9569},
{"f_9421:eval_scm",(void*)f_9421},
{"f_9424:eval_scm",(void*)f_9424},
{"f_9439:eval_scm",(void*)f_9439},
{"f_9457:eval_scm",(void*)f_9457},
{"f_9523:eval_scm",(void*)f_9523},
{"f_9473:eval_scm",(void*)f_9473},
{"f_9481:eval_scm",(void*)f_9481},
{"f_9485:eval_scm",(void*)f_9485},
{"f_9488:eval_scm",(void*)f_9488},
{"f_9500:eval_scm",(void*)f_9500},
{"f_9503:eval_scm",(void*)f_9503},
{"f_9491:eval_scm",(void*)f_9491},
{"f_9476:eval_scm",(void*)f_9476},
{"f_9461:eval_scm",(void*)f_9461},
{"f_9443:eval_scm",(void*)f_9443},
{"f_9289:eval_scm",(void*)f_9289},
{"f_9294:eval_scm",(void*)f_9294},
{"f_9446:eval_scm",(void*)f_9446},
{"f_9430:eval_scm",(void*)f_9430},
{"f_9328:eval_scm",(void*)f_9328},
{"f_9333:eval_scm",(void*)f_9333},
{"f_9336:eval_scm",(void*)f_9336},
{"f_9341:eval_scm",(void*)f_9341},
{"f_9348:eval_scm",(void*)f_9348},
{"f_9388:eval_scm",(void*)f_9388},
{"f_9351:eval_scm",(void*)f_9351},
{"f_9363:eval_scm",(void*)f_9363},
{"f_9372:eval_scm",(void*)f_9372},
{"f_9366:eval_scm",(void*)f_9366},
{"f_9354:eval_scm",(void*)f_9354},
{"f_9357:eval_scm",(void*)f_9357},
{"f_9319:eval_scm",(void*)f_9319},
{"f_9313:eval_scm",(void*)f_9313},
{"f_9267:eval_scm",(void*)f_9267},
{"f_9273:eval_scm",(void*)f_9273},
{"f_9261:eval_scm",(void*)f_9261},
{"f_9245:eval_scm",(void*)f_9245},
{"f_9259:eval_scm",(void*)f_9259},
{"f_9256:eval_scm",(void*)f_9256},
{"f_9249:eval_scm",(void*)f_9249},
{"f_9226:eval_scm",(void*)f_9226},
{"f_9235:eval_scm",(void*)f_9235},
{"f_9230:eval_scm",(void*)f_9230},
{"f_9166:eval_scm",(void*)f_9166},
{"f_9170:eval_scm",(void*)f_9170},
{"f_9173:eval_scm",(void*)f_9173},
{"f_9176:eval_scm",(void*)f_9176},
{"f_9179:eval_scm",(void*)f_9179},
{"f_9182:eval_scm",(void*)f_9182},
{"f_9185:eval_scm",(void*)f_9185},
{"f_9188:eval_scm",(void*)f_9188},
{"f_9191:eval_scm",(void*)f_9191},
{"f_9194:eval_scm",(void*)f_9194},
{"f_9145:eval_scm",(void*)f_9145},
{"f_9149:eval_scm",(void*)f_9149},
{"f_9152:eval_scm",(void*)f_9152},
{"f_9121:eval_scm",(void*)f_9121},
{"f_9127:eval_scm",(void*)f_9127},
{"f_9137:eval_scm",(void*)f_9137},
{"f_8979:eval_scm",(void*)f_8979},
{"f_9050:eval_scm",(void*)f_9050},
{"f_9097:eval_scm",(void*)f_9097},
{"f_9107:eval_scm",(void*)f_9107},
{"f_9100:eval_scm",(void*)f_9100},
{"f_9060:eval_scm",(void*)f_9060},
{"f_9062:eval_scm",(void*)f_9062},
{"f_9086:eval_scm",(void*)f_9086},
{"f_9072:eval_scm",(void*)f_9072},
{"f_9020:eval_scm",(void*)f_9020},
{"f_8985:eval_scm",(void*)f_8985},
{"f_9001:eval_scm",(void*)f_9001},
{"f_9007:eval_scm",(void*)f_9007},
{"f_8998:eval_scm",(void*)f_8998},
{"f_8960:eval_scm",(void*)f_8960},
{"f_8964:eval_scm",(void*)f_8964},
{"f_8927:eval_scm",(void*)f_8927},
{"f_8929:eval_scm",(void*)f_8929},
{"f_8933:eval_scm",(void*)f_8933},
{"f_8889:eval_scm",(void*)f_8889},
{"f_8896:eval_scm",(void*)f_8896},
{"f_8903:eval_scm",(void*)f_8903},
{"f_8845:eval_scm",(void*)f_8845},
{"f_8878:eval_scm",(void*)f_8878},
{"f_8865:eval_scm",(void*)f_8865},
{"f_8842:eval_scm",(void*)f_8842},
{"f_8723:eval_scm",(void*)f_8723},
{"f_8817:eval_scm",(void*)f_8817},
{"f_8827:eval_scm",(void*)f_8827},
{"f_8815:eval_scm",(void*)f_8815},
{"f_8744:eval_scm",(void*)f_8744},
{"f_8768:eval_scm",(void*)f_8768},
{"f_8787:eval_scm",(void*)f_8787},
{"f_8762:eval_scm",(void*)f_8762},
{"f_8615:eval_scm",(void*)f_8615},
{"f_8625:eval_scm",(void*)f_8625},
{"f_8630:eval_scm",(void*)f_8630},
{"f_8657:eval_scm",(void*)f_8657},
{"f_8690:eval_scm",(void*)f_8690},
{"f_8651:eval_scm",(void*)f_8651},
{"f_8599:eval_scm",(void*)f_8599},
{"f_8536:eval_scm",(void*)f_8536},
{"f_8540:eval_scm",(void*)f_8540},
{"f_8548:eval_scm",(void*)f_8548},
{"f_8568:eval_scm",(void*)f_8568},
{"f_8492:eval_scm",(void*)f_8492},
{"f_8524:eval_scm",(void*)f_8524},
{"f_8510:eval_scm",(void*)f_8510},
{"f_7985:eval_scm",(void*)f_7985},
{"f_8360:eval_scm",(void*)f_8360},
{"f_8369:eval_scm",(void*)f_8369},
{"f_8399:eval_scm",(void*)f_8399},
{"f_8401:eval_scm",(void*)f_8401},
{"f_8438:eval_scm",(void*)f_8438},
{"f_8428:eval_scm",(void*)f_8428},
{"f_8423:eval_scm",(void*)f_8423},
{"f_8419:eval_scm",(void*)f_8419},
{"f_8054:eval_scm",(void*)f_8054},
{"f_8064:eval_scm",(void*)f_8064},
{"f_8217:eval_scm",(void*)f_8217},
{"f_8322:eval_scm",(void*)f_8322},
{"f_8329:eval_scm",(void*)f_8329},
{"f_8229:eval_scm",(void*)f_8229},
{"f_8248:eval_scm",(void*)f_8248},
{"f_8276:eval_scm",(void*)f_8276},
{"f_8274:eval_scm",(void*)f_8274},
{"f_8270:eval_scm",(void*)f_8270},
{"f_8256:eval_scm",(void*)f_8256},
{"f_8252:eval_scm",(void*)f_8252},
{"f_8244:eval_scm",(void*)f_8244},
{"f_8236:eval_scm",(void*)f_8236},
{"f_8131:eval_scm",(void*)f_8131},
{"f_8149:eval_scm",(void*)f_8149},
{"f_8161:eval_scm",(void*)f_8161},
{"f_8157:eval_scm",(void*)f_8157},
{"f_8145:eval_scm",(void*)f_8145},
{"f_8088:eval_scm",(void*)f_8088},
{"f_8084:eval_scm",(void*)f_8084},
{"f_8071:eval_scm",(void*)f_8071},
{"f_8013:eval_scm",(void*)f_8013},
{"f_8032:eval_scm",(void*)f_8032},
{"f_8029:eval_scm",(void*)f_8029},
{"f_8025:eval_scm",(void*)f_8025},
{"f_7988:eval_scm",(void*)f_7988},
{"f_8007:eval_scm",(void*)f_8007},
{"f_8001:eval_scm",(void*)f_8001},
{"f_7936:eval_scm",(void*)f_7936},
{"f_7942:eval_scm",(void*)f_7942},
{"f_7956:eval_scm",(void*)f_7956},
{"f_7959:eval_scm",(void*)f_7959},
{"f_7966:eval_scm",(void*)f_7966},
{"f_7930:eval_scm",(void*)f_7930},
{"f_7897:eval_scm",(void*)f_7897},
{"f_7901:eval_scm",(void*)f_7901},
{"f_7907:eval_scm",(void*)f_7907},
{"f_7910:eval_scm",(void*)f_7910},
{"f_7928:eval_scm",(void*)f_7928},
{"f_7913:eval_scm",(void*)f_7913},
{"f_7920:eval_scm",(void*)f_7920},
{"f_7884:eval_scm",(void*)f_7884},
{"f_7890:eval_scm",(void*)f_7890},
{"f_7870:eval_scm",(void*)f_7870},
{"f_7881:eval_scm",(void*)f_7881},
{"f_7850:eval_scm",(void*)f_7850},
{"f_7856:eval_scm",(void*)f_7856},
{"f_7863:eval_scm",(void*)f_7863},
{"f_7782:eval_scm",(void*)f_7782},
{"f_7845:eval_scm",(void*)f_7845},
{"f_7786:eval_scm",(void*)f_7786},
{"f_7789:eval_scm",(void*)f_7789},
{"f_7807:eval_scm",(void*)f_7807},
{"f_7813:eval_scm",(void*)f_7813},
{"f_7683:eval_scm",(void*)f_7683},
{"f_7687:eval_scm",(void*)f_7687},
{"f_7735:eval_scm",(void*)f_7735},
{"f_7737:eval_scm",(void*)f_7737},
{"f_7750:eval_scm",(void*)f_7750},
{"f_7689:eval_scm",(void*)f_7689},
{"f_7693:eval_scm",(void*)f_7693},
{"f_7728:eval_scm",(void*)f_7728},
{"f_7699:eval_scm",(void*)f_7699},
{"f_7709:eval_scm",(void*)f_7709},
{"f_7702:eval_scm",(void*)f_7702},
{"f_7519:eval_scm",(void*)f_7519},
{"f_7624:eval_scm",(void*)f_7624},
{"f_7641:eval_scm",(void*)f_7641},
{"f_7649:eval_scm",(void*)f_7649},
{"f_7541:eval_scm",(void*)f_7541},
{"f_7546:eval_scm",(void*)f_7546},
{"f_7585:eval_scm",(void*)f_7585},
{"f_7572:eval_scm",(void*)f_7572},
{"f_7528:eval_scm",(void*)f_7528},
{"f_7522:eval_scm",(void*)f_7522},
{"f_7434:eval_scm",(void*)f_7434},
{"f_7441:eval_scm",(void*)f_7441},
{"f_7451:eval_scm",(void*)f_7451},
{"f_7328:eval_scm",(void*)f_7328},
{"f_7332:eval_scm",(void*)f_7332},
{"f_7424:eval_scm",(void*)f_7424},
{"f_7428:eval_scm",(void*)f_7428},
{"f_7341:eval_scm",(void*)f_7341},
{"f_7410:eval_scm",(void*)f_7410},
{"f_7406:eval_scm",(void*)f_7406},
{"f_7344:eval_scm",(void*)f_7344},
{"f_7393:eval_scm",(void*)f_7393},
{"f_7396:eval_scm",(void*)f_7396},
{"f_7399:eval_scm",(void*)f_7399},
{"f_7347:eval_scm",(void*)f_7347},
{"f_7352:eval_scm",(void*)f_7352},
{"f_7386:eval_scm",(void*)f_7386},
{"f_7365:eval_scm",(void*)f_7365},
{"f_7368:eval_scm",(void*)f_7368},
{"f_7288:eval_scm",(void*)f_7288},
{"f_7309:eval_scm",(void*)f_7309},
{"f_7292:eval_scm",(void*)f_7292},
{"f_7306:eval_scm",(void*)f_7306},
{"f_7295:eval_scm",(void*)f_7295},
{"f_7303:eval_scm",(void*)f_7303},
{"f_7298:eval_scm",(void*)f_7298},
{"f_7252:eval_scm",(void*)f_7252},
{"f_7260:eval_scm",(void*)f_7260},
{"f_7230:eval_scm",(void*)f_7230},
{"f_6834:eval_scm",(void*)f_6834},
{"f_7185:eval_scm",(void*)f_7185},
{"f_7180:eval_scm",(void*)f_7180},
{"f_6836:eval_scm",(void*)f_6836},
{"f_7179:eval_scm",(void*)f_7179},
{"f_6840:eval_scm",(void*)f_6840},
{"f_7101:eval_scm",(void*)f_7101},
{"f_7116:eval_scm",(void*)f_7116},
{"f_7119:eval_scm",(void*)f_7119},
{"f_7122:eval_scm",(void*)f_7122},
{"f_7128:eval_scm",(void*)f_7128},
{"f_7131:eval_scm",(void*)f_7131},
{"f_7137:eval_scm",(void*)f_7137},
{"f_6843:eval_scm",(void*)f_6843},
{"f_7092:eval_scm",(void*)f_7092},
{"f_7080:eval_scm",(void*)f_7080},
{"f_7083:eval_scm",(void*)f_7083},
{"f_7086:eval_scm",(void*)f_7086},
{"f_6849:eval_scm",(void*)f_6849},
{"f_7065:eval_scm",(void*)f_7065},
{"f_7037:eval_scm",(void*)f_7037},
{"f_7061:eval_scm",(void*)f_7061},
{"f_7057:eval_scm",(void*)f_7057},
{"f_7053:eval_scm",(void*)f_7053},
{"f_6852:eval_scm",(void*)f_6852},
{"f_6860:eval_scm",(void*)f_6860},
{"f_7024:eval_scm",(void*)f_7024},
{"f_6864:eval_scm",(void*)f_6864},
{"f_7012:eval_scm",(void*)f_7012},
{"f_6885:eval_scm",(void*)f_6885},
{"f_6889:eval_scm",(void*)f_6889},
{"f_7003:eval_scm",(void*)f_7003},
{"f_6897:eval_scm",(void*)f_6897},
{"f_6901:eval_scm",(void*)f_6901},
{"f_6997:eval_scm",(void*)f_6997},
{"f_6904:eval_scm",(void*)f_6904},
{"f_6907:eval_scm",(void*)f_6907},
{"f_6912:eval_scm",(void*)f_6912},
{"f_6922:eval_scm",(void*)f_6922},
{"f_6968:eval_scm",(void*)f_6968},
{"f_6977:eval_scm",(void*)f_6977},
{"f_6981:eval_scm",(void*)f_6981},
{"f_6934:eval_scm",(void*)f_6934},
{"f_6941:eval_scm",(void*)f_6941},
{"f_6952:eval_scm",(void*)f_6952},
{"f_6963:eval_scm",(void*)f_6963},
{"f_6956:eval_scm",(void*)f_6956},
{"f_6946:eval_scm",(void*)f_6946},
{"f_6925:eval_scm",(void*)f_6925},
{"f_6932:eval_scm",(void*)f_6932},
{"f_6894:eval_scm",(void*)f_6894},
{"f_6874:eval_scm",(void*)f_6874},
{"f_6865:eval_scm",(void*)f_6865},
{"f_6855:eval_scm",(void*)f_6855},
{"f_6788:eval_scm",(void*)f_6788},
{"f_6798:eval_scm",(void*)f_6798},
{"f_6713:eval_scm",(void*)f_6713},
{"f_6725:eval_scm",(void*)f_6725},
{"f_6738:eval_scm",(void*)f_6738},
{"f_6720:eval_scm",(void*)f_6720},
{"f_6707:eval_scm",(void*)f_6707},
{"f_6623:eval_scm",(void*)f_6623},
{"f_6636:eval_scm",(void*)f_6636},
{"f_6669:eval_scm",(void*)f_6669},
{"f_6650:eval_scm",(void*)f_6650},
{"f_6626:eval_scm",(void*)f_6626},
{"f_6613:eval_scm",(void*)f_6613},
{"f_6621:eval_scm",(void*)f_6621},
{"f_3715:eval_scm",(void*)f_3715},
{"f_6362:eval_scm",(void*)f_6362},
{"f_6366:eval_scm",(void*)f_6366},
{"f_6579:eval_scm",(void*)f_6579},
{"f_6555:eval_scm",(void*)f_6555},
{"f_6556:eval_scm",(void*)f_6556},
{"f_6567:eval_scm",(void*)f_6567},
{"f_6573:eval_scm",(void*)f_6573},
{"f_6571:eval_scm",(void*)f_6571},
{"f_6512:eval_scm",(void*)f_6512},
{"f_6515:eval_scm",(void*)f_6515},
{"f_6518:eval_scm",(void*)f_6518},
{"f_6521:eval_scm",(void*)f_6521},
{"f_6522:eval_scm",(void*)f_6522},
{"f_6533:eval_scm",(void*)f_6533},
{"f_6537:eval_scm",(void*)f_6537},
{"f_6541:eval_scm",(void*)f_6541},
{"f_6545:eval_scm",(void*)f_6545},
{"f_6548:eval_scm",(void*)f_6548},
{"f_6470:eval_scm",(void*)f_6470},
{"f_6473:eval_scm",(void*)f_6473},
{"f_6476:eval_scm",(void*)f_6476},
{"f_6477:eval_scm",(void*)f_6477},
{"f_6488:eval_scm",(void*)f_6488},
{"f_6492:eval_scm",(void*)f_6492},
{"f_6496:eval_scm",(void*)f_6496},
{"f_6499:eval_scm",(void*)f_6499},
{"f_6435:eval_scm",(void*)f_6435},
{"f_6438:eval_scm",(void*)f_6438},
{"f_6439:eval_scm",(void*)f_6439},
{"f_6450:eval_scm",(void*)f_6450},
{"f_6454:eval_scm",(void*)f_6454},
{"f_6457:eval_scm",(void*)f_6457},
{"f_6407:eval_scm",(void*)f_6407},
{"f_6408:eval_scm",(void*)f_6408},
{"f_6419:eval_scm",(void*)f_6419},
{"f_6422:eval_scm",(void*)f_6422},
{"f_6388:eval_scm",(void*)f_6388},
{"f_6398:eval_scm",(void*)f_6398},
{"f_6336:eval_scm",(void*)f_6336},
{"f_3928:eval_scm",(void*)f_3928},
{"f_3935:eval_scm",(void*)f_3935},
{"f_4055:eval_scm",(void*)f_4055},
{"f_4111:eval_scm",(void*)f_4111},
{"f_4134:eval_scm",(void*)f_4134},
{"f_4149:eval_scm",(void*)f_4149},
{"f_6133:eval_scm",(void*)f_6133},
{"f_6116:eval_scm",(void*)f_6116},
{"f_6120:eval_scm",(void*)f_6120},
{"f_6085:eval_scm",(void*)f_6085},
{"f_6074:eval_scm",(void*)f_6074},
{"f_6033:eval_scm",(void*)f_6033},
{"f_5979:eval_scm",(void*)f_5979},
{"f_6001:eval_scm",(void*)f_6001},
{"f_6017:eval_scm",(void*)f_6017},
{"f_5991:eval_scm",(void*)f_5991},
{"f_5973:eval_scm",(void*)f_5973},
{"f_5949:eval_scm",(void*)f_5949},
{"f_5910:eval_scm",(void*)f_5910},
{"f_5913:eval_scm",(void*)f_5913},
{"f_5916:eval_scm",(void*)f_5916},
{"f_5939:eval_scm",(void*)f_5939},
{"f_5937:eval_scm",(void*)f_5937},
{"f_5933:eval_scm",(void*)f_5933},
{"f_5923:eval_scm",(void*)f_5923},
{"f_5893:eval_scm",(void*)f_5893},
{"f_5897:eval_scm",(void*)f_5897},
{"f_5864:eval_scm",(void*)f_5864},
{"f_5868:eval_scm",(void*)f_5868},
{"f_5641:eval_scm",(void*)f_5641},
{"f_5835:eval_scm",(void*)f_5835},
{"f_5783:eval_scm",(void*)f_5783},
{"f_5807:eval_scm",(void*)f_5807},
{"f_5796:eval_scm",(void*)f_5796},
{"f_5647:eval_scm",(void*)f_5647},
{"f_5775:eval_scm",(void*)f_5775},
{"f_5650:eval_scm",(void*)f_5650},
{"f_5653:eval_scm",(void*)f_5653},
{"f_5681:eval_scm",(void*)f_5681},
{"f_5691:eval_scm",(void*)f_5691},
{"f_5772:eval_scm",(void*)f_5772},
{"f_5764:eval_scm",(void*)f_5764},
{"f_5701:eval_scm",(void*)f_5701},
{"f_5749:eval_scm",(void*)f_5749},
{"f_5704:eval_scm",(void*)f_5704},
{"f_5705:eval_scm",(void*)f_5705},
{"f_5711:eval_scm",(void*)f_5711},
{"f_5733:eval_scm",(void*)f_5733},
{"f_5654:eval_scm",(void*)f_5654},
{"f_5658:eval_scm",(void*)f_5658},
{"f_5661:eval_scm",(void*)f_5661},
{"f_5665:eval_scm",(void*)f_5665},
{"f_5668:eval_scm",(void*)f_5668},
{"f_5672:eval_scm",(void*)f_5672},
{"f_5675:eval_scm",(void*)f_5675},
{"f_5628:eval_scm",(void*)f_5628},
{"f_5592:eval_scm",(void*)f_5592},
{"f_5505:eval_scm",(void*)f_5505},
{"f_5508:eval_scm",(void*)f_5508},
{"f_5549:eval_scm",(void*)f_5549},
{"f_5561:eval_scm",(void*)f_5561},
{"f_5511:eval_scm",(void*)f_5511},
{"f_5514:eval_scm",(void*)f_5514},
{"f_5539:eval_scm",(void*)f_5539},
{"f_5517:eval_scm",(void*)f_5517},
{"f_5527:eval_scm",(void*)f_5527},
{"f_5535:eval_scm",(void*)f_5535},
{"f_5531:eval_scm",(void*)f_5531},
{"f_5520:eval_scm",(void*)f_5520},
{"f_5437:eval_scm",(void*)f_5437},
{"f_5469:eval_scm",(void*)f_5469},
{"f_5485:eval_scm",(void*)f_5485},
{"f_5481:eval_scm",(void*)f_5481},
{"f_5440:eval_scm",(void*)f_5440},
{"f_5443:eval_scm",(void*)f_5443},
{"f_5459:eval_scm",(void*)f_5459},
{"f_5446:eval_scm",(void*)f_5446},
{"f_5453:eval_scm",(void*)f_5453},
{"f_5384:eval_scm",(void*)f_5384},
{"f_5404:eval_scm",(void*)f_5404},
{"f_5420:eval_scm",(void*)f_5420},
{"f_5416:eval_scm",(void*)f_5416},
{"f_5402:eval_scm",(void*)f_5402},
{"f_5387:eval_scm",(void*)f_5387},
{"f_5394:eval_scm",(void*)f_5394},
{"f_5020:eval_scm",(void*)f_5020},
{"f_5357:eval_scm",(void*)f_5357},
{"f_5368:eval_scm",(void*)f_5368},
{"f_5362:eval_scm",(void*)f_5362},
{"f_5032:eval_scm",(void*)f_5032},
{"f_5037:eval_scm",(void*)f_5037},
{"f_5041:eval_scm",(void*)f_5041},
{"f_5354:eval_scm",(void*)f_5354},
{"f_5044:eval_scm",(void*)f_5044},
{"f_5346:eval_scm",(void*)f_5346},
{"f_5050:eval_scm",(void*)f_5050},
{"f_5308:eval_scm",(void*)f_5308},
{"f_5314:eval_scm",(void*)f_5314},
{"f_5338:eval_scm",(void*)f_5338},
{"f_5285:eval_scm",(void*)f_5285},
{"f_5291:eval_scm",(void*)f_5291},
{"f_6290:eval_scm",(void*)f_6290},
{"f_6319:eval_scm",(void*)f_6319},
{"f_5307:eval_scm",(void*)f_5307},
{"f_5303:eval_scm",(void*)f_5303},
{"f_5263:eval_scm",(void*)f_5263},
{"f_5269:eval_scm",(void*)f_5269},
{"f_5281:eval_scm",(void*)f_5281},
{"f_5244:eval_scm",(void*)f_5244},
{"f_5250:eval_scm",(void*)f_5250},
{"f_5216:eval_scm",(void*)f_5216},
{"f_5222:eval_scm",(void*)f_5222},
{"f_5197:eval_scm",(void*)f_5197},
{"f_5203:eval_scm",(void*)f_5203},
{"f_5169:eval_scm",(void*)f_5169},
{"f_5175:eval_scm",(void*)f_5175},
{"f_5150:eval_scm",(void*)f_5150},
{"f_5156:eval_scm",(void*)f_5156},
{"f_5122:eval_scm",(void*)f_5122},
{"f_5128:eval_scm",(void*)f_5128},
{"f_5103:eval_scm",(void*)f_5103},
{"f_5109:eval_scm",(void*)f_5109},
{"f_5079:eval_scm",(void*)f_5079},
{"f_5085:eval_scm",(void*)f_5085},
{"f_5060:eval_scm",(void*)f_5060},
{"f_5066:eval_scm",(void*)f_5066},
{"f_4931:eval_scm",(void*)f_4931},
{"f_5000:eval_scm",(void*)f_5000},
{"f_4952:eval_scm",(void*)f_4952},
{"f_4978:eval_scm",(void*)f_4978},
{"f_4960:eval_scm",(void*)f_4960},
{"f_4976:eval_scm",(void*)f_4976},
{"f_4956:eval_scm",(void*)f_4956},
{"f_4586:eval_scm",(void*)f_4586},
{"f_4915:eval_scm",(void*)f_4915},
{"f_4595:eval_scm",(void*)f_4595},
{"f_4598:eval_scm",(void*)f_4598},
{"f_4913:eval_scm",(void*)f_4913},
{"f_4604:eval_scm",(void*)f_4604},
{"f_4905:eval_scm",(void*)f_4905},
{"f_4607:eval_scm",(void*)f_4607},
{"f_4889:eval_scm",(void*)f_4889},
{"f_4842:eval_scm",(void*)f_4842},
{"f_4843:eval_scm",(void*)f_4843},
{"f_4847:eval_scm",(void*)f_4847},
{"f_4859:eval_scm",(void*)f_4859},
{"f_4884:eval_scm",(void*)f_4884},
{"f_4850:eval_scm",(void*)f_4850},
{"f_4766:eval_scm",(void*)f_4766},
{"f_4769:eval_scm",(void*)f_4769},
{"f_4775:eval_scm",(void*)f_4775},
{"f_4778:eval_scm",(void*)f_4778},
{"f_4779:eval_scm",(void*)f_4779},
{"f_4795:eval_scm",(void*)f_4795},
{"f_4799:eval_scm",(void*)f_4799},
{"f_4803:eval_scm",(void*)f_4803},
{"f_4807:eval_scm",(void*)f_4807},
{"f_4699:eval_scm",(void*)f_4699},
{"f_4702:eval_scm",(void*)f_4702},
{"f_4708:eval_scm",(void*)f_4708},
{"f_4709:eval_scm",(void*)f_4709},
{"f_4725:eval_scm",(void*)f_4725},
{"f_4729:eval_scm",(void*)f_4729},
{"f_4733:eval_scm",(void*)f_4733},
{"f_4650:eval_scm",(void*)f_4650},
{"f_4653:eval_scm",(void*)f_4653},
{"f_4654:eval_scm",(void*)f_4654},
{"f_4670:eval_scm",(void*)f_4670},
{"f_4674:eval_scm",(void*)f_4674},
{"f_4616:eval_scm",(void*)f_4616},
{"f_4617:eval_scm",(void*)f_4617},
{"f_4633:eval_scm",(void*)f_4633},
{"f_4474:eval_scm",(void*)f_4474},
{"f_4488:eval_scm",(void*)f_4488},
{"f_4492:eval_scm",(void*)f_4492},
{"f_4501:eval_scm",(void*)f_4501},
{"f_4534:eval_scm",(void*)f_4534},
{"f_4542:eval_scm",(void*)f_4542},
{"f_4507:eval_scm",(void*)f_4507},
{"f_4510:eval_scm",(void*)f_4510},
{"f_4526:eval_scm",(void*)f_4526},
{"f_4517:eval_scm",(void*)f_4517},
{"f_4525:eval_scm",(void*)f_4525},
{"f_4562:eval_scm",(void*)f_4562},
{"f_4570:eval_scm",(void*)f_4570},
{"f_4549:eval_scm",(void*)f_4549},
{"f_4561:eval_scm",(void*)f_4561},
{"f_4482:eval_scm",(void*)f_4482},
{"f_4362:eval_scm",(void*)f_4362},
{"f_4421:eval_scm",(void*)f_4421},
{"f_4424:eval_scm",(void*)f_4424},
{"f_4446:eval_scm",(void*)f_4446},
{"f_4427:eval_scm",(void*)f_4427},
{"f_4428:eval_scm",(void*)f_4428},
{"f_4432:eval_scm",(void*)f_4432},
{"f_4435:eval_scm",(void*)f_4435},
{"f_4399:eval_scm",(void*)f_4399},
{"f_4402:eval_scm",(void*)f_4402},
{"f_4403:eval_scm",(void*)f_4403},
{"f_4407:eval_scm",(void*)f_4407},
{"f_4302:eval_scm",(void*)f_4302},
{"f_4305:eval_scm",(void*)f_4305},
{"f_4308:eval_scm",(void*)f_4308},
{"f_4311:eval_scm",(void*)f_4311},
{"f_4312:eval_scm",(void*)f_4312},
{"f_4319:eval_scm",(void*)f_4319},
{"f_4292:eval_scm",(void*)f_4292},
{"f_4258:eval_scm",(void*)f_4258},
{"f_4252:eval_scm",(void*)f_4252},
{"f_4253:eval_scm",(void*)f_4253},
{"f_4236:eval_scm",(void*)f_4236},
{"f_4158:eval_scm",(void*)f_4158},
{"f_4161:eval_scm",(void*)f_4161},
{"f_4218:eval_scm",(void*)f_4218},
{"f_4216:eval_scm",(void*)f_4216},
{"f_4208:eval_scm",(void*)f_4208},
{"f_4200:eval_scm",(void*)f_4200},
{"f_4192:eval_scm",(void*)f_4192},
{"f_4184:eval_scm",(void*)f_4184},
{"f_4176:eval_scm",(void*)f_4176},
{"f_4168:eval_scm",(void*)f_4168},
{"f_4112:eval_scm",(void*)f_4112},
{"f_4101:eval_scm",(void*)f_4101},
{"f_4099:eval_scm",(void*)f_4099},
{"f_4088:eval_scm",(void*)f_4088},
{"f_4086:eval_scm",(void*)f_4086},
{"f_4078:eval_scm",(void*)f_4078},
{"f_4070:eval_scm",(void*)f_4070},
{"f_4062:eval_scm",(void*)f_4062},
{"f_3954:eval_scm",(void*)f_3954},
{"f_4022:eval_scm",(void*)f_4022},
{"f_3964:eval_scm",(void*)f_3964},
{"f_4013:eval_scm",(void*)f_4013},
{"f_3998:eval_scm",(void*)f_3998},
{"f_3993:eval_scm",(void*)f_3993},
{"f_3994:eval_scm",(void*)f_3994},
{"f_3970:eval_scm",(void*)f_3970},
{"f_3973:eval_scm",(void*)f_3973},
{"f_3974:eval_scm",(void*)f_3974},
{"f_4045:eval_scm",(void*)f_4045},
{"f_4036:eval_scm",(void*)f_4036},
{"f_3948:eval_scm",(void*)f_3948},
{"f_3936:eval_scm",(void*)f_3936},
{"f_3877:eval_scm",(void*)f_3877},
{"f_3881:eval_scm",(void*)f_3881},
{"f_3902:eval_scm",(void*)f_3902},
{"f_3913:eval_scm",(void*)f_3913},
{"f_3909:eval_scm",(void*)f_3909},
{"f_3882:eval_scm",(void*)f_3882},
{"f_3886:eval_scm",(void*)f_3886},
{"f_3889:eval_scm",(void*)f_3889},
{"f_3893:eval_scm",(void*)f_3893},
{"f_3896:eval_scm",(void*)f_3896},
{"f_3871:eval_scm",(void*)f_3871},
{"f_3865:eval_scm",(void*)f_3865},
{"f_3859:eval_scm",(void*)f_3859},
{"f_3775:eval_scm",(void*)f_3775},
{"f_3779:eval_scm",(void*)f_3779},
{"f_3787:eval_scm",(void*)f_3787},
{"f_3829:eval_scm",(void*)f_3829},
{"f_3760:eval_scm",(void*)f_3760},
{"f_3764:eval_scm",(void*)f_3764},
{"f_3770:eval_scm",(void*)f_3770},
{"f_3721:eval_scm",(void*)f_3721},
{"f_3734:eval_scm",(void*)f_3734},
{"f_3671:eval_scm",(void*)f_3671},
{"f_3690:eval_scm",(void*)f_3690},
{"f_3702:eval_scm",(void*)f_3702},
{"f_3705:eval_scm",(void*)f_3705},
{"f_3708:eval_scm",(void*)f_3708},
{"f_3698:eval_scm",(void*)f_3698},
{"f_3677:eval_scm",(void*)f_3677},
{"f_3611:eval_scm",(void*)f_3611},
{"f_3615:eval_scm",(void*)f_3615},
{"f_3623:eval_scm",(void*)f_3623},
{"f_3565:eval_scm",(void*)f_3565},
{"f_3571:eval_scm",(void*)f_3571},
{"f_3590:eval_scm",(void*)f_3590},
{"f_3581:eval_scm",(void*)f_3581},
{"f_3545:eval_scm",(void*)f_3545},
{"f_3557:eval_scm",(void*)f_3557},
{"f_3560:eval_scm",(void*)f_3560},
{"f_3553:eval_scm",(void*)f_3553},
{"f_3485:eval_scm",(void*)f_3485},
{"f_3489:eval_scm",(void*)f_3489},
{"f_3497:eval_scm",(void*)f_3497},
{"f_3430:eval_scm",(void*)f_3430},
{"f_3483:eval_scm",(void*)f_3483},
{"f_3440:eval_scm",(void*)f_3440},
{"f_3415:eval_scm",(void*)f_3415},
{"f_3403:eval_scm",(void*)f_3403},
{"f_3407:eval_scm",(void*)f_3407},
{"f_3376:eval_scm",(void*)f_3376},
{"f_3341:eval_scm",(void*)f_3341},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
