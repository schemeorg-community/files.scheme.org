/* Generated from srfi-4.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:26
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: srfi-4.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -output-file srfi-4.c
   unit: srfi_4
*/

#include "chicken.h"

#define C_u8peek(b, i)         C_fix(((unsigned char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s8peek(b, i)         C_fix(((char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_u16peek(b, i)        C_fix(((unsigned short *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s16peek(b, i)        C_fix(((short *)C_data_pointer(b))[ C_unfix(i) ])
#ifdef C_SIXTY_FOUR
# define C_a_u32peek(ptr, d, b, i) C_fix(((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_fix(((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#else
# define C_a_u32peek(ptr, d, b, i) C_unsigned_int_to_num(ptr, ((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_int_to_num(ptr, ((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#endif
#define C_f32peek(b, i)        (C_temporary_flonum = ((float *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_f64peek(b, i)        (C_temporary_flonum = ((double *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_u8poke(b, i, x)      ((((unsigned char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s8poke(b, i, x)      ((((char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u16poke(b, i, x)     ((((unsigned short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s16poke(b, i, x)     ((((short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u32poke(b, i, x)     ((((C_u32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_unsigned_int(x)), C_SCHEME_UNDEFINED)
#define C_s32poke(b, i, x)     ((((C_s32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_int(x)), C_SCHEME_UNDEFINED)
#define C_f32poke(b, i, x)     ((((float *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_f64poke(b, i, x)     ((((double *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_copy_subvector(to, from, start_to, start_from, bytes)   \
  (C_memcpy((C_char *)C_data_pointer(to) + C_unfix(start_to), (C_char *)C_data_pointer(from) + C_unfix(start_from), C_unfix(bytes)), \
    C_SCHEME_UNDEFINED)

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[176];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,50),40,35,35,115,121,115,35,99,104,101,99,107,45,101,120,97,99,116,45,105,110,116,101,114,118,97,108,32,110,49,57,32,102,114,111,109,50,48,32,116,111,50,49,32,108,111,99,50,50,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,52),40,35,35,115,121,115,35,99,104,101,99,107,45,105,110,101,120,97,99,116,45,105,110,116,101,114,118,97,108,32,110,51,50,32,102,114,111,109,51,51,32,116,111,51,52,32,108,111,99,51,53,41,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,117,56,118,101,99,116,111,114,45,114,101,102,32,118,52,54,32,105,52,55,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,115,56,118,101,99,116,111,114,45,114,101,102,32,118,53,49,32,105,53,50,41,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,117,49,54,118,101,99,116,111,114,45,114,101,102,32,118,53,54,32,105,53,55,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,115,49,54,118,101,99,116,111,114,45,114,101,102,32,118,54,49,32,105,54,50,41,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,117,51,50,118,101,99,116,111,114,45,114,101,102,32,118,54,54,32,105,54,55,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,115,51,50,118,101,99,116,111,114,45,114,101,102,32,118,55,49,32,105,55,50,41,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,51,50,118,101,99,116,111,114,45,114,101,102,32,118,55,54,32,105,55,55,41,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,54,52,118,101,99,116,111,114,45,114,101,102,32,118,56,50,32,105,56,51,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,117,56,118,101,99,116,111,114,45,115,101,116,33,32,118,56,56,32,105,56,57,32,120,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,115,56,118,101,99,116,111,114,45,115,101,116,33,32,118,57,52,32,105,57,53,32,120,57,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,117,49,54,118,101,99,116,111,114,45,115,101,116,33,32,118,49,48,48,32,105,49,48,49,32,120,49,48,50,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,115,49,54,118,101,99,116,111,114,45,115,101,116,33,32,118,49,48,54,32,105,49,48,55,32,120,49,48,56,41,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,117,51,50,118,101,99,116,111,114,45,115,101,116,33,32,105,49,49,51,32,120,49,49,52,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,115,51,50,118,101,99,116,111,114,45,115,101,116,33,32,105,49,49,57,32,120,49,50,48,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,102,51,50,118,101,99,116,111,114,45,115,101,116,33,32,118,49,50,52,32,105,49,50,53,32,120,49,50,54,41,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,102,54,52,118,101,99,116,111,114,45,115,101,116,33,32,118,49,51,48,32,105,49,51,49,32,120,49,51,50,41,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,13),40,102,95,49,54,54,49,32,118,49,52,49,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,28),40,108,101,110,32,116,97,103,49,51,55,32,115,104,105,102,116,49,51,56,32,108,111,99,49,51,57,41,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,18),40,102,95,49,55,48,52,32,118,49,54,54,32,105,49,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,29),40,103,101,116,32,108,101,110,103,116,104,49,54,50,32,97,99,99,49,54,51,32,108,111,99,49,54,52,41,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,23),40,102,95,49,55,49,56,32,118,49,55,54,32,105,49,55,55,32,120,49,55,56,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,29),40,115,101,116,32,108,101,110,103,116,104,49,55,50,32,117,112,100,49,55,51,32,108,111,99,49,55,52,41,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,23),40,102,95,49,55,51,53,32,118,49,56,56,32,105,49,56,57,32,120,49,57,48,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,32,108,101,110,103,116,104,49,56,52,32,117,112,100,49,56,53,32,108,111,99,49,56,54,41,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,23),40,102,95,49,56,50,52,32,118,50,51,50,32,105,50,51,51,32,120,50,51,52,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,30),40,115,101,116,102,32,108,101,110,103,116,104,50,50,56,32,117,112,100,50,50,57,32,108,111,99,50,51,48,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,23),40,102,95,49,55,56,56,32,118,50,49,51,32,105,50,49,52,32,120,50,49,53,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,23),40,102,95,49,55,54,49,32,118,50,48,49,32,105,50,48,50,32,120,50,48,51,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,18),40,101,120,116,45,102,114,101,101,32,97,50,55,49,50,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,29),40,97,108,108,111,99,32,108,111,99,50,56,48,32,108,101,110,50,56,49,32,101,120,116,63,50,56,50,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,28),40,114,101,108,101,97,115,101,45,110,117,109,98,101,114,45,118,101,99,116,111,114,32,118,50,57,55,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,51,51,57,32,105,51,52,53,41};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,33),40,98,111,100,121,51,49,56,32,105,110,105,116,51,50,57,32,101,120,116,63,51,51,48,32,102,105,110,63,51,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,37),40,100,101,102,45,102,105,110,63,51,50,50,32,37,105,110,105,116,51,49,53,51,53,54,32,37,101,120,116,63,51,49,54,51,53,55,41,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,51,50,49,32,37,105,110,105,116,51,49,53,51,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,51,50,48,41,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,34),40,109,97,107,101,45,117,56,118,101,99,116,111,114,32,108,101,110,51,48,55,32,46,32,116,109,112,51,48,54,51,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,52,49,54,32,105,52,50,50,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,51,57,53,32,105,110,105,116,52,48,54,32,101,120,116,63,52,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,51,57,57,32,37,105,110,105,116,51,57,50,52,51,51,32,37,101,120,116,63,51,57,51,52,51,52,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,51,57,56,32,37,105,110,105,116,51,57,50,52,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,51,57,55,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,34),40,109,97,107,101,45,115,56,118,101,99,116,111,114,32,108,101,110,51,56,52,32,46,32,116,109,112,51,56,51,51,56,53,41,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,52,57,50,32,105,52,57,56,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,52,55,49,32,105,110,105,116,52,56,50,32,101,120,116,63,52,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,52,55,53,32,37,105,110,105,116,52,54,56,53,48,57,32,37,101,120,116,63,52,54,57,53,49,48,41,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,52,55,52,32,37,105,110,105,116,52,54,56,53,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,52,55,51,41,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,117,49,54,118,101,99,116,111,114,32,108,101,110,52,54,48,32,46,32,116,109,112,52,53,57,52,54,49,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,53,54,56,32,105,53,55,52,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,53,52,55,32,105,110,105,116,53,53,56,32,101,120,116,63,53,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,53,53,49,32,37,105,110,105,116,53,52,52,53,56,53,32,37,101,120,116,63,53,52,53,53,56,54,41,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,53,53,48,32,37,105,110,105,116,53,52,52,53,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,53,52,57,41,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,115,49,54,118,101,99,116,111,114,32,108,101,110,53,51,54,32,46,32,116,109,112,53,51,53,53,51,55,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,54,52,52,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,54,50,51,32,105,110,105,116,54,51,52,32,101,120,116,63,54,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,54,50,55,32,37,105,110,105,116,54,50,48,54,54,49,32,37,101,120,116,63,54,50,49,54,54,50,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,54,50,54,32,37,105,110,105,116,54,50,48,54,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,54,50,53,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,117,51,50,118,101,99,116,111,114,32,108,101,110,54,49,50,32,46,32,116,109,112,54,49,49,54,49,51,41,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,55,50,48,41,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,54,57,57,32,105,110,105,116,55,49,48,32,101,120,116,63,55,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,55,48,51,32,37,105,110,105,116,54,57,54,55,51,55,32,37,101,120,116,63,54,57,55,55,51,56,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,55,48,50,32,37,105,110,105,116,54,57,54,55,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,55,48,49,41,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,115,51,50,118,101,99,116,111,114,32,108,101,110,54,56,56,32,46,32,116,109,112,54,56,55,54,56,57,41,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,55,57,56,32,105,56,48,52,41};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,55,55,53,32,105,110,105,116,55,56,54,32,101,120,116,63,55,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,55,55,57,32,37,105,110,105,116,55,55,50,56,49,54,32,37,101,120,116,63,55,55,51,56,49,55,41,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,55,55,56,32,37,105,110,105,116,55,55,50,56,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,55,55,55,41,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,102,51,50,118,101,99,116,111,114,32,108,101,110,55,54,52,32,46,32,116,109,112,55,54,51,55,54,53,41,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,56,55,55,32,105,56,56,51,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,56,53,52,32,105,110,105,116,56,54,53,32,101,120,116,63,56,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,56,53,56,32,37,105,110,105,116,56,53,49,56,57,53,32,37,101,120,116,63,56,53,50,56,57,54,41,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,56,53,55,32,37,105,110,105,116,56,53,49,57,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,56,53,54,41,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,102,54,52,118,101,99,116,111,114,32,108,101,110,56,52,51,32,46,32,116,109,112,56,52,50,56,52,52,41,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,57,51,56,32,112,57,52,53,32,105,57,52,54,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,15),40,102,95,50,57,51,54,32,108,115,116,57,51,49,41,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,28),40,105,110,105,116,32,109,97,107,101,57,50,55,32,115,101,116,57,50,56,32,108,111,99,57,50,57,41,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,18),40,117,56,118,101,99,116,111,114,32,46,32,120,115,57,54,54,41,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,18),40,115,56,118,101,99,116,111,114,32,46,32,120,115,57,55,49,41,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,19),40,117,49,54,118,101,99,116,111,114,32,46,32,120,115,57,55,54,41,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,19),40,115,49,54,118,101,99,116,111,114,32,46,32,120,115,57,56,49,41,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,19),40,117,51,50,118,101,99,116,111,114,32,46,32,120,115,57,56,54,41,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,19),40,115,51,50,118,101,99,116,111,114,32,46,32,120,115,57,57,49,41,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,19),40,102,51,50,118,101,99,116,111,114,32,46,32,120,115,57,57,54,41,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,20),40,102,54,52,118,101,99,116,111,114,32,46,32,120,115,49,48,48,49,41,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,48,49,54,41,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,14),40,102,95,51,48,53,52,32,118,49,48,49,48,41,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,25),40,105,110,105,116,32,108,101,110,103,116,104,49,48,48,55,32,114,101,102,49,48,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,17),40,117,56,118,101,99,116,111,114,63,32,120,49,48,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,17),40,115,56,118,101,99,116,111,114,63,32,120,49,48,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,18),40,117,49,54,118,101,99,116,111,114,63,32,120,49,48,51,56,41,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,18),40,115,49,54,118,101,99,116,111,114,63,32,120,49,48,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,18),40,117,51,50,118,101,99,116,111,114,63,32,120,49,48,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,18),40,115,51,50,118,101,99,116,111,114,63,32,120,49,48,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,18),40,102,51,50,118,101,99,116,111,114,63,32,120,49,48,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,18),40,102,54,52,118,101,99,116,111,114,63,32,120,49,48,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,14),40,102,95,51,49,54,57,32,118,49,48,54,57,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,22),40,112,97,99,107,32,116,97,103,49,48,54,54,32,108,111,99,49,48,54,55,41,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,14),40,102,95,51,49,56,48,32,118,49,48,55,53,41,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,27),40,112,97,99,107,45,99,111,112,121,32,116,97,103,49,48,55,50,32,108,111,99,49,48,55,51,41,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,16),40,102,95,51,49,57,56,32,115,116,114,49,48,56,56,41};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,31),40,117,110,112,97,99,107,32,116,97,103,49,48,56,52,32,115,122,49,48,56,53,32,108,111,99,49,48,56,54,41,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,16),40,102,95,51,50,50,55,32,115,116,114,49,49,48,51,41};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,36),40,117,110,112,97,99,107,45,99,111,112,121,32,116,97,103,49,48,57,57,32,115,122,49,49,48,48,32,108,111,99,49,49,48,49,41,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,117,115,101,114,45,114,101,97,100,45,104,111,111,107,32,99,104,97,114,49,49,53,56,32,112,111,114,116,49,49,53,57,41};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,51),40,35,35,115,121,115,35,117,115,101,114,45,112,114,105,110,116,45,104,111,111,107,32,120,49,49,57,49,32,114,101,97,100,97,98,108,101,49,49,57,50,32,112,111,114,116,49,49,57,51,41,0,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,54),40,115,117,98,118,101,99,116,111,114,32,118,49,50,49,50,32,116,49,50,49,51,32,101,115,49,50,49,52,32,102,114,111,109,49,50,49,53,32,116,111,49,50,49,54,32,108,111,99,49,50,49,55,41,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,35),40,115,117,98,117,56,118,101,99,116,111,114,32,118,49,50,52,50,32,102,114,111,109,49,50,52,51,32,116,111,49,50,52,52,41,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,36),40,115,117,98,117,49,54,118,101,99,116,111,114,32,118,49,50,52,56,32,102,114,111,109,49,50,52,57,32,116,111,49,50,53,48,41,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,36),40,115,117,98,117,51,50,118,101,99,116,111,114,32,118,49,50,53,52,32,102,114,111,109,49,50,53,53,32,116,111,49,50,53,54,41,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,35),40,115,117,98,115,56,118,101,99,116,111,114,32,118,49,50,54,48,32,102,114,111,109,49,50,54,49,32,116,111,49,50,54,50,41,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,36),40,115,117,98,115,49,54,118,101,99,116,111,114,32,118,49,50,54,54,32,102,114,111,109,49,50,54,55,32,116,111,49,50,54,56,41,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,36),40,115,117,98,115,51,50,118,101,99,116,111,114,32,118,49,50,55,50,32,102,114,111,109,49,50,55,51,32,116,111,49,50,55,52,41,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,36),40,115,117,98,102,51,50,118,101,99,116,111,114,32,118,49,50,55,56,32,102,114,111,109,49,50,55,57,32,116,111,49,50,56,48,41,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,36),40,115,117,98,102,54,52,118,101,99,116,111,114,32,118,49,50,56,52,32,102,114,111,109,49,50,56,53,32,116,111,49,50,56,54,41,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,51,50,51,32,105,49,51,51,48,41,0,0,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,49,51,48,55,32,112,111,114,116,49,51,49,56,32,102,114,111,109,49,51,49,57,32,116,111,49,51,50,48,41,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,40),40,100,101,102,45,116,111,49,51,49,49,32,37,112,111,114,116,49,51,48,52,49,51,52,48,32,37,102,114,111,109,49,51,48,53,49,51,52,49,41};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,102,114,111,109,49,51,49,48,32,37,112,111,114,116,49,51,48,52,49,51,52,53,41,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,112,111,114,116,49,51,48,57,41,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,36),40,119,114,105,116,101,45,117,56,118,101,99,116,111,114,32,118,49,50,57,54,32,46,32,116,109,112,49,50,57,53,49,50,57,55,41,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,29),40,98,111,100,121,49,51,56,48,32,112,111,114,116,49,51,57,48,32,115,116,97,114,116,49,51,57,49,41,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,115,116,97,114,116,49,51,56,51,32,37,112,111,114,116,49,51,55,56,49,52,48,54,41,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,112,111,114,116,49,51,56,50,41,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,45),40,114,101,97,100,45,117,56,118,101,99,116,111,114,33,32,110,49,51,54,57,32,100,101,115,116,49,51,55,48,32,46,32,116,109,112,49,51,54,56,49,51,55,49,41,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,20),40,119,114,97,112,32,115,116,114,49,52,50,52,32,110,49,52,50,53,41,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,49,52,52,54,32,110,49,52,53,54,32,112,49,52,53,55,41,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,112,49,52,52,57,32,37,110,49,52,52,52,49,52,57,51,41,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,11),40,100,101,102,45,110,49,52,52,56,41,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,29),40,114,101,97,100,45,117,56,118,101,99,116,111,114,32,46,32,116,109,112,49,52,51,54,49,52,51,55,41,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from ext-free in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub272(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub272(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word bv=(C_word )(C_a0);
C_free((void *)C_block_item(bv, 1));
C_ret:
#undef return

return C_r;}

/* from k1912 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub265(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub265(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int bytes=(int )C_unfix(C_a0);
C_word *buf = (C_word *)C_malloc(bytes + sizeof(C_header));if(buf == NULL) return(C_SCHEME_FALSE);C_block_header(buf) = C_make_header(C_BYTEVECTOR_TYPE, bytes);return(buf);
C_ret:
#undef return

return C_r;}

C_noret_decl(C_srfi_4_toplevel)
C_externexport void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1680)
static void C_ccall f_1680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1688)
static void C_ccall f_1688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1848)
static void C_ccall f_1848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1860)
static void C_ccall f_1860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4051)
static void C_ccall f_4051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3002)
static void C_ccall f_3002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3089)
static void C_ccall f_3089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3097)
static void C_ccall f_3097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3113)
static void C_ccall f_3113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3259)
static void C_ccall f_3259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3267)
static void C_ccall f_3267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3275)
static void C_ccall f_3275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3279)
static void C_ccall f_3279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3283)
static void C_ccall f_3283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3351)
static void C_ccall f_3351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3367)
static void C_ccall f_3367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3371)
static void C_ccall f_3371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3990)
static void C_fcall f_3990(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_fcall f_3985(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3923)
static void C_fcall f_3923(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3959)
static void C_fcall f_3959(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3963)
static void C_ccall f_3963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_fcall f_3912(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3863)
static void C_fcall f_3863(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3858)
static void C_fcall f_3858(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3813)
static void C_fcall f_3813(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3829)
static void C_fcall f_3829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3695)
static void C_ccall f_3695(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3695)
static void C_ccall f_3695r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3748)
static void C_fcall f_3748(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3743)
static void C_fcall f_3743(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3734)
static void C_fcall f_3734(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3697)
static void C_fcall f_3697(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3704)
static void C_ccall f_3704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3712)
static void C_fcall f_3712(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3689)
static void C_ccall f_3689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3647)
static void C_ccall f_3647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3604)
static void C_fcall f_3604(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3617)
static void C_ccall f_3617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3620)
static void C_ccall f_3620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3626)
static void C_ccall f_3626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static void C_ccall f_3444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3398)
static void C_ccall f_3398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3225)
static void C_fcall f_3225(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3196)
static void C_fcall f_3196(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3178)
static void C_fcall f_3178(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3167)
static void C_fcall f_3167(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3052)
static void C_fcall f_3052(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3054)
static void C_ccall f_3054(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_fcall f_3063(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3081)
static void C_ccall f_3081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3010)
static void C_ccall f_3010(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3010)
static void C_ccall f_3010r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2934)
static void C_fcall f_2934(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_fcall f_2951(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2871)
static void C_fcall f_2871(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static void C_fcall f_2866(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2861)
static void C_fcall f_2861(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2809)
static void C_fcall f_2809(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_fcall f_2831(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2836)
static void C_fcall f_2836(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2744)
static void C_fcall f_2744(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_fcall f_2739(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2734)
static void C_fcall f_2734(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2682)
static void C_fcall f_2682(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2692)
static void C_ccall f_2692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2704)
static void C_fcall f_2704(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2709)
static void C_fcall f_2709(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2560)
static void C_ccall f_2560(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2560)
static void C_ccall f_2560r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2617)
static void C_fcall f_2617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2612)
static void C_fcall f_2612(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2607)
static void C_fcall f_2607(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2562)
static void C_fcall f_2562(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2586)
static C_word C_fcall f_2586(C_word t0,C_word t1);
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2497)
static void C_fcall f_2497(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2492)
static void C_fcall f_2492(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2487)
static void C_fcall f_2487(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2442)
static void C_fcall f_2442(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2466)
static C_word C_fcall f_2466(C_word t0,C_word t1);
C_noret_decl(f_2320)
static void C_ccall f_2320(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2320)
static void C_ccall f_2320r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2377)
static void C_fcall f_2377(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2372)
static void C_fcall f_2372(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2367)
static void C_fcall f_2367(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2322)
static void C_fcall f_2322(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static void C_fcall f_2346(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2257)
static void C_fcall f_2257(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_fcall f_2252(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2247)
static void C_fcall f_2247(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2202)
static void C_fcall f_2202(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_fcall f_2226(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2137)
static void C_fcall f_2137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_fcall f_2132(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2127)
static void C_fcall f_2127(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2082)
static void C_fcall f_2082(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2101)
static void C_ccall f_2101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2106)
static void C_fcall f_2106(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2017)
static void C_fcall f_2017(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_fcall f_2012(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2007)
static void C_fcall f_2007(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1962)
static void C_fcall f_1962(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1972)
static void C_ccall f_1972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_fcall f_1986(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1942)
static void C_fcall f_1942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1917)
static void C_fcall f_1917(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_fcall f_1822(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1733)
static void C_fcall f_1733(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1748)
static void C_ccall f_1748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_fcall f_1716(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1702)
static void C_fcall f_1702(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1704)
static void C_ccall f_1704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_fcall f_1659(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1653)
static void C_ccall f_1653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1650)
static C_word C_fcall f_1650(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_1647)
static C_word C_fcall f_1647(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1608)
static void C_ccall f_1608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1584)
static void C_ccall f_1584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;

C_noret_decl(trf_3990)
static void C_fcall trf_3990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3990(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3990(t0,t1);}

C_noret_decl(trf_3985)
static void C_fcall trf_3985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3985(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3985(t0,t1,t2);}

C_noret_decl(trf_3923)
static void C_fcall trf_3923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3923(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3923(t0,t1,t2,t3);}

C_noret_decl(trf_3959)
static void C_fcall trf_3959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3959(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3959(t0,t1);}

C_noret_decl(trf_3912)
static void C_fcall trf_3912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3912(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3912(t0,t1,t2);}

C_noret_decl(trf_3863)
static void C_fcall trf_3863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3863(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3863(t0,t1);}

C_noret_decl(trf_3858)
static void C_fcall trf_3858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3858(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3858(t0,t1,t2);}

C_noret_decl(trf_3813)
static void C_fcall trf_3813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3813(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3813(t0,t1,t2,t3);}

C_noret_decl(trf_3829)
static void C_fcall trf_3829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3829(t0,t1);}

C_noret_decl(trf_3748)
static void C_fcall trf_3748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3748(t0,t1);}

C_noret_decl(trf_3743)
static void C_fcall trf_3743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3743(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3743(t0,t1,t2);}

C_noret_decl(trf_3734)
static void C_fcall trf_3734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3734(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3734(t0,t1,t2,t3);}

C_noret_decl(trf_3697)
static void C_fcall trf_3697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3697(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3697(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3712)
static void C_fcall trf_3712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3712(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3712(t0,t1,t2);}

C_noret_decl(trf_3604)
static void C_fcall trf_3604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3604(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3604(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3225)
static void C_fcall trf_3225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3225(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3225(t0,t1,t2,t3);}

C_noret_decl(trf_3196)
static void C_fcall trf_3196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3196(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3196(t0,t1,t2,t3);}

C_noret_decl(trf_3178)
static void C_fcall trf_3178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3178(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3178(t0,t1,t2);}

C_noret_decl(trf_3167)
static void C_fcall trf_3167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3167(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3167(t0,t1,t2);}

C_noret_decl(trf_3052)
static void C_fcall trf_3052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3052(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3052(t0,t1,t2);}

C_noret_decl(trf_3063)
static void C_fcall trf_3063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3063(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3063(t0,t1,t2);}

C_noret_decl(trf_2934)
static void C_fcall trf_2934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2934(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2934(t0,t1,t2,t3);}

C_noret_decl(trf_2951)
static void C_fcall trf_2951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2951(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2951(t0,t1,t2,t3);}

C_noret_decl(trf_2871)
static void C_fcall trf_2871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2871(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2871(t0,t1);}

C_noret_decl(trf_2866)
static void C_fcall trf_2866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2866(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2866(t0,t1,t2);}

C_noret_decl(trf_2861)
static void C_fcall trf_2861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2861(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2861(t0,t1,t2,t3);}

C_noret_decl(trf_2809)
static void C_fcall trf_2809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2809(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2809(t0,t1,t2,t3);}

C_noret_decl(trf_2831)
static void C_fcall trf_2831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2831(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2831(t0,t1);}

C_noret_decl(trf_2836)
static void C_fcall trf_2836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2836(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2836(t0,t1,t2);}

C_noret_decl(trf_2744)
static void C_fcall trf_2744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2744(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2744(t0,t1);}

C_noret_decl(trf_2739)
static void C_fcall trf_2739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2739(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2739(t0,t1,t2);}

C_noret_decl(trf_2734)
static void C_fcall trf_2734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2734(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2734(t0,t1,t2,t3);}

C_noret_decl(trf_2682)
static void C_fcall trf_2682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2682(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2682(t0,t1,t2,t3);}

C_noret_decl(trf_2704)
static void C_fcall trf_2704(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2704(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2704(t0,t1);}

C_noret_decl(trf_2709)
static void C_fcall trf_2709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2709(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2709(t0,t1,t2);}

C_noret_decl(trf_2617)
static void C_fcall trf_2617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2617(t0,t1);}

C_noret_decl(trf_2612)
static void C_fcall trf_2612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2612(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2612(t0,t1,t2);}

C_noret_decl(trf_2607)
static void C_fcall trf_2607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2607(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2607(t0,t1,t2,t3);}

C_noret_decl(trf_2562)
static void C_fcall trf_2562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2562(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2562(t0,t1,t2,t3);}

C_noret_decl(trf_2497)
static void C_fcall trf_2497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2497(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2497(t0,t1);}

C_noret_decl(trf_2492)
static void C_fcall trf_2492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2492(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2492(t0,t1,t2);}

C_noret_decl(trf_2487)
static void C_fcall trf_2487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2487(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2487(t0,t1,t2,t3);}

C_noret_decl(trf_2442)
static void C_fcall trf_2442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2442(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2442(t0,t1,t2,t3);}

C_noret_decl(trf_2377)
static void C_fcall trf_2377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2377(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2377(t0,t1);}

C_noret_decl(trf_2372)
static void C_fcall trf_2372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2372(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2372(t0,t1,t2);}

C_noret_decl(trf_2367)
static void C_fcall trf_2367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2367(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2367(t0,t1,t2,t3);}

C_noret_decl(trf_2322)
static void C_fcall trf_2322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2322(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2322(t0,t1,t2,t3);}

C_noret_decl(trf_2346)
static void C_fcall trf_2346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2346(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2346(t0,t1,t2);}

C_noret_decl(trf_2257)
static void C_fcall trf_2257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2257(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2257(t0,t1);}

C_noret_decl(trf_2252)
static void C_fcall trf_2252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2252(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2252(t0,t1,t2);}

C_noret_decl(trf_2247)
static void C_fcall trf_2247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2247(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2247(t0,t1,t2,t3);}

C_noret_decl(trf_2202)
static void C_fcall trf_2202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2202(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2202(t0,t1,t2,t3);}

C_noret_decl(trf_2226)
static void C_fcall trf_2226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2226(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2226(t0,t1,t2);}

C_noret_decl(trf_2137)
static void C_fcall trf_2137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2137(t0,t1);}

C_noret_decl(trf_2132)
static void C_fcall trf_2132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2132(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2132(t0,t1,t2);}

C_noret_decl(trf_2127)
static void C_fcall trf_2127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2127(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2127(t0,t1,t2,t3);}

C_noret_decl(trf_2082)
static void C_fcall trf_2082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2082(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2082(t0,t1,t2,t3);}

C_noret_decl(trf_2106)
static void C_fcall trf_2106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2106(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2106(t0,t1,t2);}

C_noret_decl(trf_2017)
static void C_fcall trf_2017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2017(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2017(t0,t1);}

C_noret_decl(trf_2012)
static void C_fcall trf_2012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2012(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2012(t0,t1,t2);}

C_noret_decl(trf_2007)
static void C_fcall trf_2007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2007(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2007(t0,t1,t2,t3);}

C_noret_decl(trf_1962)
static void C_fcall trf_1962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1962(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1962(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1986)
static void C_fcall trf_1986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1986(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1986(t0,t1,t2);}

C_noret_decl(trf_1942)
static void C_fcall trf_1942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1942(t0,t1);}

C_noret_decl(trf_1917)
static void C_fcall trf_1917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1917(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1917(t0,t1,t2,t3);}

C_noret_decl(trf_1822)
static void C_fcall trf_1822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1822(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1822(t0,t1,t2,t3);}

C_noret_decl(trf_1733)
static void C_fcall trf_1733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1733(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1733(t0,t1,t2,t3);}

C_noret_decl(trf_1716)
static void C_fcall trf_1716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1716(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1716(t0,t1,t2,t3);}

C_noret_decl(trf_1702)
static void C_fcall trf_1702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1702(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1702(t0,t1,t2,t3);}

C_noret_decl(trf_1659)
static void C_fcall trf_1659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1659(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1659(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_4_toplevel"));
C_check_nursery_minimum(61);
if(!C_demand(61)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1554)){
C_save(t1);
C_rereclaim2(1554*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(61);
C_initialize_lf(lf,176);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],24,"\003syscheck-exact-interval");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[5]=C_h_intern(&lf[5],26,"\003syscheck-inexact-interval");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[14]=C_h_intern(&lf[14],15,"\003syscons-flonum");
lf[24]=C_h_intern(&lf[24],15,"u8vector-length");
lf[25]=C_h_intern(&lf[25],15,"s8vector-length");
lf[26]=C_h_intern(&lf[26],16,"u16vector-length");
lf[27]=C_h_intern(&lf[27],16,"s16vector-length");
lf[28]=C_h_intern(&lf[28],16,"u32vector-length");
lf[29]=C_h_intern(&lf[29],16,"s32vector-length");
lf[30]=C_h_intern(&lf[30],16,"f32vector-length");
lf[31]=C_h_intern(&lf[31],16,"f64vector-length");
lf[32]=C_h_intern(&lf[32],15,"\003syscheck-range");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[34]=C_h_intern(&lf[34],13,"u8vector-set!");
lf[35]=C_h_intern(&lf[35],13,"s8vector-set!");
lf[36]=C_h_intern(&lf[36],14,"u16vector-set!");
lf[37]=C_h_intern(&lf[37],14,"s16vector-set!");
lf[38]=C_h_intern(&lf[38],14,"u32vector-set!");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[41]=C_h_intern(&lf[41],14,"s32vector-set!");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[43]=C_h_intern(&lf[43],14,"f32vector-set!");
lf[44]=C_h_intern(&lf[44],14,"f64vector-set!");
lf[45]=C_h_intern(&lf[45],12,"u8vector-ref");
lf[46]=C_h_intern(&lf[46],12,"s8vector-ref");
lf[47]=C_h_intern(&lf[47],13,"u16vector-ref");
lf[48]=C_h_intern(&lf[48],13,"s16vector-ref");
lf[49]=C_h_intern(&lf[49],13,"u32vector-ref");
lf[50]=C_h_intern(&lf[50],13,"s32vector-ref");
lf[51]=C_h_intern(&lf[51],13,"f32vector-ref");
lf[52]=C_h_intern(&lf[52],13,"f64vector-ref");
lf[53]=C_h_intern(&lf[53],14,"set-finalizer!");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000:not enough memory - cannot allocate external number vector");
lf[55]=C_h_intern(&lf[55],19,"\003sysallocate-vector");
lf[56]=C_h_intern(&lf[56],21,"release-number-vector");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\047bad argument type - not a number vector");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376"
"\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64vector\376\377\016");
lf[59]=C_h_intern(&lf[59],13,"make-u8vector");
lf[60]=C_h_intern(&lf[60],8,"u8vector");
lf[61]=C_h_intern(&lf[61],13,"make-s8vector");
lf[62]=C_h_intern(&lf[62],8,"s8vector");
lf[63]=C_h_intern(&lf[63],4,"fin\077");
lf[64]=C_h_intern(&lf[64],14,"make-u16vector");
lf[65]=C_h_intern(&lf[65],9,"u16vector");
lf[66]=C_h_intern(&lf[66],14,"make-s16vector");
lf[67]=C_h_intern(&lf[67],9,"s16vector");
lf[68]=C_h_intern(&lf[68],14,"make-u32vector");
lf[69]=C_h_intern(&lf[69],9,"u32vector");
lf[70]=C_h_intern(&lf[70],14,"make-s32vector");
lf[71]=C_h_intern(&lf[71],9,"s32vector");
lf[72]=C_h_intern(&lf[72],14,"make-f32vector");
lf[73]=C_h_intern(&lf[73],9,"f32vector");
lf[74]=C_h_intern(&lf[74],14,"make-f64vector");
lf[75]=C_h_intern(&lf[75],9,"f64vector");
lf[76]=C_h_intern(&lf[76],27,"\003syserror-not-a-proper-list");
lf[77]=C_h_intern(&lf[77],14,"list->u8vector");
lf[78]=C_h_intern(&lf[78],14,"list->s8vector");
lf[79]=C_h_intern(&lf[79],15,"list->u16vector");
lf[80]=C_h_intern(&lf[80],15,"list->s16vector");
lf[81]=C_h_intern(&lf[81],15,"list->u32vector");
lf[82]=C_h_intern(&lf[82],15,"list->s32vector");
lf[83]=C_h_intern(&lf[83],15,"list->f32vector");
lf[84]=C_h_intern(&lf[84],15,"list->f64vector");
lf[85]=C_h_intern(&lf[85],14,"u8vector->list");
lf[86]=C_h_intern(&lf[86],14,"s8vector->list");
lf[87]=C_h_intern(&lf[87],15,"u16vector->list");
lf[88]=C_h_intern(&lf[88],15,"s16vector->list");
lf[89]=C_h_intern(&lf[89],15,"u32vector->list");
lf[90]=C_h_intern(&lf[90],15,"s32vector->list");
lf[91]=C_h_intern(&lf[91],15,"f32vector->list");
lf[92]=C_h_intern(&lf[92],15,"f64vector->list");
lf[93]=C_h_intern(&lf[93],9,"u8vector\077");
lf[94]=C_h_intern(&lf[94],9,"s8vector\077");
lf[95]=C_h_intern(&lf[95],10,"u16vector\077");
lf[96]=C_h_intern(&lf[96],10,"s16vector\077");
lf[97]=C_h_intern(&lf[97],10,"u32vector\077");
lf[98]=C_h_intern(&lf[98],10,"s32vector\077");
lf[99]=C_h_intern(&lf[99],10,"f32vector\077");
lf[100]=C_h_intern(&lf[100],10,"f64vector\077");
lf[101]=C_h_intern(&lf[101],13,"\003sysmake-blob");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[104]=C_h_intern(&lf[104],21,"u8vector->blob/shared");
lf[105]=C_h_intern(&lf[105],21,"s8vector->blob/shared");
lf[106]=C_h_intern(&lf[106],22,"u16vector->blob/shared");
lf[107]=C_h_intern(&lf[107],22,"s16vector->blob/shared");
lf[108]=C_h_intern(&lf[108],22,"u32vector->blob/shared");
lf[109]=C_h_intern(&lf[109],22,"s32vector->blob/shared");
lf[110]=C_h_intern(&lf[110],22,"f32vector->blob/shared");
lf[111]=C_h_intern(&lf[111],22,"f64vector->blob/shared");
lf[112]=C_h_intern(&lf[112],14,"u8vector->blob");
lf[113]=C_h_intern(&lf[113],14,"s8vector->blob");
lf[114]=C_h_intern(&lf[114],15,"u16vector->blob");
lf[115]=C_h_intern(&lf[115],15,"s16vector->blob");
lf[116]=C_h_intern(&lf[116],15,"u32vector->blob");
lf[117]=C_h_intern(&lf[117],15,"s32vector->blob");
lf[118]=C_h_intern(&lf[118],15,"f32vector->blob");
lf[119]=C_h_intern(&lf[119],15,"f64vector->blob");
lf[120]=C_h_intern(&lf[120],21,"blob->u8vector/shared");
lf[121]=C_h_intern(&lf[121],21,"blob->s8vector/shared");
lf[122]=C_h_intern(&lf[122],22,"blob->u16vector/shared");
lf[123]=C_h_intern(&lf[123],22,"blob->s16vector/shared");
lf[124]=C_h_intern(&lf[124],22,"blob->u32vector/shared");
lf[125]=C_h_intern(&lf[125],22,"blob->s32vector/shared");
lf[126]=C_h_intern(&lf[126],22,"blob->f32vector/shared");
lf[127]=C_h_intern(&lf[127],22,"blob->f64vector/shared");
lf[128]=C_h_intern(&lf[128],14,"blob->u8vector");
lf[129]=C_h_intern(&lf[129],14,"blob->s8vector");
lf[130]=C_h_intern(&lf[130],15,"blob->u16vector");
lf[131]=C_h_intern(&lf[131],15,"blob->s16vector");
lf[132]=C_h_intern(&lf[132],15,"blob->u32vector");
lf[133]=C_h_intern(&lf[133],15,"blob->s32vector");
lf[134]=C_h_intern(&lf[134],15,"blob->f32vector");
lf[135]=C_h_intern(&lf[135],15,"blob->f64vector");
lf[136]=C_h_intern(&lf[136],18,"\003sysuser-read-hook");
lf[137]=C_h_intern(&lf[137],4,"read");
lf[138]=C_h_intern(&lf[138],2,"u8");
lf[139]=C_h_intern(&lf[139],2,"s8");
lf[140]=C_h_intern(&lf[140],3,"u16");
lf[141]=C_h_intern(&lf[141],3,"s16");
lf[142]=C_h_intern(&lf[142],3,"u32");
lf[143]=C_h_intern(&lf[143],3,"s32");
lf[144]=C_h_intern(&lf[144],3,"f32");
lf[145]=C_h_intern(&lf[145],3,"f64");
lf[146]=C_h_intern(&lf[146],1,"f");
lf[147]=C_h_intern(&lf[147],1,"F");
lf[148]=C_h_intern(&lf[148],14,"\003sysread-error");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal bytevector syntax");
lf[150]=C_h_intern(&lf[150],19,"\003sysuser-print-hook");
lf[151]=C_h_intern(&lf[151],9,"\003sysprint");
lf[153]=C_h_intern(&lf[153],11,"subu8vector");
lf[154]=C_h_intern(&lf[154],12,"subu16vector");
lf[155]=C_h_intern(&lf[155],12,"subu32vector");
lf[156]=C_h_intern(&lf[156],11,"subs8vector");
lf[157]=C_h_intern(&lf[157],12,"subs16vector");
lf[158]=C_h_intern(&lf[158],12,"subs32vector");
lf[159]=C_h_intern(&lf[159],12,"subf32vector");
lf[160]=C_h_intern(&lf[160],12,"subf64vector");
lf[161]=C_h_intern(&lf[161],14,"write-u8vector");
lf[162]=C_h_intern(&lf[162],16,"\003syswrite-char-0");
lf[163]=C_h_intern(&lf[163],14,"\003syscheck-port");
lf[164]=C_h_intern(&lf[164],19,"\003sysstandard-output");
lf[165]=C_h_intern(&lf[165],14,"read-u8vector!");
lf[166]=C_h_intern(&lf[166],16,"\003sysread-string!");
lf[167]=C_h_intern(&lf[167],18,"\003sysstandard-input");
lf[168]=C_h_intern(&lf[168],18,"open-output-string");
lf[169]=C_h_intern(&lf[169],17,"get-output-string");
lf[170]=C_h_intern(&lf[170],13,"read-u8vector");
lf[171]=C_h_intern(&lf[171],19,"\003syswrite-char/port");
lf[172]=C_h_intern(&lf[172],15,"\003sysread-char-0");
lf[173]=C_h_intern(&lf[173],17,"register-feature!");
lf[174]=C_h_intern(&lf[174],6,"srfi-4");
lf[175]=C_h_intern(&lf[175],18,"getter-with-setter");
C_register_lf2(lf,176,create_ptable());
t2=C_mutate(&lf[0] /* (set! c377 ...) */,lf[1]);
t3=C_mutate((C_word*)lf[2]+1 /* (set! check-exact-interval ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1569,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[5]+1 /* (set! check-inexact-interval ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1584,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[7] /* (set! u8vector-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1605,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[8] /* (set! s8vector-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1608,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[9] /* (set! u16vector-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1611,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[10] /* (set! s16vector-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1614,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[11] /* (set! u32vector-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1617,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[12] /* (set! s32vector-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1620,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[13] /* (set! f32vector-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1623,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[15] /* (set! f64vector-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1629,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[16] /* (set! u8vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1635,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[17] /* (set! s8vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1638,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[18] /* (set! u16vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1641,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[19] /* (set! s16vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1644,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[20] /* (set! u32vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1647,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate(&lf[21] /* (set! s32vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1650,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[22] /* (set! f32vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1653,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[23] /* (set! f64vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1656,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1659,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1672,a[2]=t21,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 140  len */
f_1659(t22,lf[60],C_SCHEME_FALSE,lf[24]);}

/* k1670 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1 /* (set! u8vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 141  len */
f_1659(t3,lf[62],C_SCHEME_FALSE,lf[25]);}

/* k1674 in k1670 */
static void C_ccall f_1676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1676,2,t0,t1);}
t2=C_mutate((C_word*)lf[25]+1 /* (set! s8vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 142  len */
f_1659(t3,lf[65],C_fix(1),lf[26]);}

/* k1678 in k1674 in k1670 */
static void C_ccall f_1680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1680,2,t0,t1);}
t2=C_mutate((C_word*)lf[26]+1 /* (set! u16vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 143  len */
f_1659(t3,lf[67],C_fix(1),lf[27]);}

/* k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1684,2,t0,t1);}
t2=C_mutate((C_word*)lf[27]+1 /* (set! s16vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 144  len */
f_1659(t3,lf[69],C_fix(2),lf[28]);}

/* k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1688,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1 /* (set! u32vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1692,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 145  len */
f_1659(t3,lf[71],C_fix(2),lf[29]);}

/* k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1692,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1 /* (set! s32vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 146  len */
f_1659(t3,lf[73],C_fix(2),lf[30]);}

/* k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1696,2,t0,t1);}
t2=C_mutate((C_word*)lf[30]+1 /* (set! f32vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1700,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 147  len */
f_1659(t3,lf[75],C_fix(3),lf[31]);}

/* k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1700,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1 /* (set! f64vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1702,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1716,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1733,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1822,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1848,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 203  setu */
f_1733(t7,*((C_word*)lf[24]+1),lf[16],lf[34]);}

/* k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1848,2,t0,t1);}
t2=C_mutate((C_word*)lf[34]+1 /* (set! u8vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 204  set */
f_1716(t3,*((C_word*)lf[25]+1),lf[17],lf[35]);}

/* k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1852,2,t0,t1);}
t2=C_mutate((C_word*)lf[35]+1 /* (set! s8vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1856,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 205  setu */
f_1733(t3,*((C_word*)lf[26]+1),lf[18],lf[36]);}

/* k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1856,2,t0,t1);}
t2=C_mutate((C_word*)lf[36]+1 /* (set! u16vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 206  set */
f_1716(t3,*((C_word*)lf[27]+1),lf[19],lf[37]);}

/* k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1860,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1 /* (set! s16vector-set! ...) */,t1);
t3=*((C_word*)lf[28]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1788,a[2]=t3,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
t5=C_mutate((C_word*)lf[38]+1 /* (set! u32vector-set! ...) */,t4);
t6=*((C_word*)lf[29]+1);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1761,a[2]=t6,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t8=C_mutate((C_word*)lf[41]+1 /* (set! s32vector-set! ...) */,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 209  setf */
f_1822(t9,*((C_word*)lf[30]+1),lf[22],lf[43]);}

/* k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1872,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1 /* (set! f32vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 210  setf */
f_1822(t3,*((C_word*)lf[31]+1),lf[23],lf[44]);}

/* k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1876,2,t0,t1);}
t2=C_mutate((C_word*)lf[44]+1 /* (set! f64vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4071,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 213  get */
f_1702(t4,*((C_word*)lf[24]+1),lf[7],lf[45]);}

/* k4069 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 213  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[175]+1)))(4,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1,*((C_word*)lf[34]+1));}

/* k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1880,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1 /* (set! u8vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4067,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 216  get */
f_1702(t4,*((C_word*)lf[25]+1),lf[8],lf[46]);}

/* k4065 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 216  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[175]+1)))(4,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1,*((C_word*)lf[35]+1));}

/* k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1 /* (set! s8vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4063,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 219  get */
f_1702(t4,*((C_word*)lf[26]+1),lf[9],lf[47]);}

/* k4061 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 219  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[175]+1)))(4,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1,*((C_word*)lf[36]+1));}

/* k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1 /* (set! u16vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4059,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 222  get */
f_1702(t4,*((C_word*)lf[27]+1),lf[10],lf[48]);}

/* k4057 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 222  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[175]+1)))(4,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1,*((C_word*)lf[37]+1));}

/* k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1892,2,t0,t1);}
t2=C_mutate((C_word*)lf[48]+1 /* (set! s16vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4055,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 226  get */
f_1702(t4,*((C_word*)lf[28]+1),lf[11],lf[49]);}

/* k4053 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 225  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[175]+1)))(4,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1,*((C_word*)lf[38]+1));}

/* k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
t2=C_mutate((C_word*)lf[49]+1 /* (set! u32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4051,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 230  get */
f_1702(t4,*((C_word*)lf[29]+1),lf[12],lf[50]);}

/* k4049 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 229  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[175]+1)))(4,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1,*((C_word*)lf[41]+1));}

/* k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=C_mutate((C_word*)lf[50]+1 /* (set! s32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4047,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 234  get */
f_1702(t4,*((C_word*)lf[30]+1),lf[13],lf[51]);}

/* k4045 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 233  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[175]+1)))(4,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1,*((C_word*)lf[43]+1));}

/* k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1904,2,t0,t1);}
t2=C_mutate((C_word*)lf[51]+1 /* (set! f32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4043,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 238  get */
f_1702(t4,*((C_word*)lf[31]+1),lf[15],lf[52]);}

/* k4041 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 237  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[175]+1)))(4,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1,*((C_word*)lf[44]+1));}

/* k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[65],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=C_mutate((C_word*)lf[52]+1 /* (set! f64vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1915,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[53]+1);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1917,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
t6=C_mutate((C_word*)lf[56]+1 /* (set! release-number-vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1935,a[2]=t3,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[59]+1 /* (set! make-u8vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1960,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li38),tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[61]+1 /* (set! make-s8vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2080,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li44),tmp=(C_word)a,a+=6,tmp));
t9=C_mutate((C_word*)lf[64]+1 /* (set! make-u16vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2200,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp));
t10=C_mutate((C_word*)lf[66]+1 /* (set! make-s16vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2320,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li56),tmp=(C_word)a,a+=6,tmp));
t11=C_mutate((C_word*)lf[68]+1 /* (set! make-u32vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2440,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp));
t12=C_mutate((C_word*)lf[70]+1 /* (set! make-s32vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2560,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t13=C_mutate((C_word*)lf[72]+1 /* (set! make-f32vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2680,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li74),tmp=(C_word)a,a+=6,tmp));
t14=C_mutate((C_word*)lf[74]+1 /* (set! make-f64vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2807,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li80),tmp=(C_word)a,a+=6,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2934,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2974,a[2]=t15,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 397  init */
f_2934(t16,*((C_word*)lf[59]+1),*((C_word*)lf[34]+1),lf[77]);}

/* k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2974,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1 /* (set! list->u8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 398  init */
f_2934(t3,*((C_word*)lf[61]+1),*((C_word*)lf[35]+1),lf[78]);}

/* k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2978,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* (set! list->s8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 399  init */
f_2934(t3,*((C_word*)lf[64]+1),*((C_word*)lf[36]+1),lf[79]);}

/* k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2982,2,t0,t1);}
t2=C_mutate((C_word*)lf[79]+1 /* (set! list->u16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 400  init */
f_2934(t3,*((C_word*)lf[66]+1),*((C_word*)lf[37]+1),lf[80]);}

/* k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2986,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1 /* (set! list->s16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 401  init */
f_2934(t3,*((C_word*)lf[68]+1),*((C_word*)lf[38]+1),lf[81]);}

/* k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2990,2,t0,t1);}
t2=C_mutate((C_word*)lf[81]+1 /* (set! list->u32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 402  init */
f_2934(t3,*((C_word*)lf[70]+1),*((C_word*)lf[41]+1),lf[82]);}

/* k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2994,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1 /* (set! list->s32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 403  init */
f_2934(t3,*((C_word*)lf[72]+1),*((C_word*)lf[43]+1),lf[83]);}

/* k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2998,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1 /* (set! list->f32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3002,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 404  init */
f_2934(t3,*((C_word*)lf[74]+1),*((C_word*)lf[44]+1),lf[84]);}

/* k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3002,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1 /* (set! list->f64vector ...) */,t1);
t3=*((C_word*)lf[77]+1);
t4=C_mutate((C_word*)lf[60]+1 /* (set! u8vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3004,a[2]=t3,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp));
t5=*((C_word*)lf[78]+1);
t6=C_mutate((C_word*)lf[62]+1 /* (set! s8vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3010,a[2]=t5,a[3]=((C_word)li85),tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[79]+1);
t8=C_mutate((C_word*)lf[65]+1 /* (set! u16vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3016,a[2]=t7,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp));
t9=*((C_word*)lf[80]+1);
t10=C_mutate((C_word*)lf[67]+1 /* (set! s16vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3022,a[2]=t9,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp));
t11=*((C_word*)lf[81]+1);
t12=C_mutate((C_word*)lf[69]+1 /* (set! u32vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3028,a[2]=t11,a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp));
t13=*((C_word*)lf[82]+1);
t14=C_mutate((C_word*)lf[71]+1 /* (set! s32vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3034,a[2]=t13,a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp));
t15=*((C_word*)lf[83]+1);
t16=C_mutate((C_word*)lf[73]+1 /* (set! f32vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3040,a[2]=t15,a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp));
t17=*((C_word*)lf[84]+1);
t18=C_mutate((C_word*)lf[75]+1 /* (set! f64vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3046,a[2]=t17,a[3]=((C_word)li91),tmp=(C_word)a,a+=4,tmp));
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3052,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3089,a[2]=t19,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 455  init */
f_3052(t20,*((C_word*)lf[24]+1),lf[7]);}

/* k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3089,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1 /* (set! u8vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 456  init */
f_3052(t3,*((C_word*)lf[25]+1),lf[8]);}

/* k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3093,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1 /* (set! s8vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3097,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 457  init */
f_3052(t3,*((C_word*)lf[26]+1),lf[9]);}

/* k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3097,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! u16vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 458  init */
f_3052(t3,*((C_word*)lf[27]+1),lf[10]);}

/* k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3101,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1 /* (set! s16vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 459  init */
f_3052(t3,*((C_word*)lf[28]+1),lf[11]);}

/* k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3105,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1 /* (set! u32vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 460  init */
f_3052(t3,*((C_word*)lf[29]+1),lf[12]);}

/* k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3109,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1 /* (set! s32vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 461  init */
f_3052(t3,*((C_word*)lf[30]+1),lf[13]);}

/* k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3113,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1 /* (set! f32vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3117,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 462  init */
f_3052(t3,*((C_word*)lf[31]+1),lf[15]);}

/* k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3117,2,t0,t1);}
t2=C_mutate((C_word*)lf[92]+1 /* (set! f64vector->list ...) */,t1);
t3=C_mutate((C_word*)lf[93]+1 /* (set! u8vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3119,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[94]+1 /* (set! s8vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3125,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[95]+1 /* (set! u16vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3131,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[96]+1 /* (set! s16vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3137,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[97]+1 /* (set! u32vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3143,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[98]+1 /* (set! s32vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3149,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[99]+1 /* (set! f32vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3155,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[100]+1 /* (set! f64vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3161,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3167,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3178,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3196,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3225,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3259,a[2]=t11,a[3]=t12,a[4]=t13,a[5]=t14,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 514  pack */
f_3167(t15,lf[60],lf[104]);}

/* k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3259,2,t0,t1);}
t2=C_mutate((C_word*)lf[104]+1 /* (set! u8vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 515  pack */
f_3167(t3,lf[62],lf[105]);}

/* k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3263,2,t0,t1);}
t2=C_mutate((C_word*)lf[105]+1 /* (set! s8vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 516  pack */
f_3167(t3,lf[65],lf[106]);}

/* k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3267,2,t0,t1);}
t2=C_mutate((C_word*)lf[106]+1 /* (set! u16vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 517  pack */
f_3167(t3,lf[67],lf[107]);}

/* k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3271,2,t0,t1);}
t2=C_mutate((C_word*)lf[107]+1 /* (set! s16vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3275,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 518  pack */
f_3167(t3,lf[69],lf[108]);}

/* k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3275,2,t0,t1);}
t2=C_mutate((C_word*)lf[108]+1 /* (set! u32vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 519  pack */
f_3167(t3,lf[71],lf[109]);}

/* k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3279,2,t0,t1);}
t2=C_mutate((C_word*)lf[109]+1 /* (set! s32vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 520  pack */
f_3167(t3,lf[73],lf[110]);}

/* k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3283,2,t0,t1);}
t2=C_mutate((C_word*)lf[110]+1 /* (set! f32vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3287,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 521  pack */
f_3167(t3,lf[75],lf[111]);}

/* k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3287,2,t0,t1);}
t2=C_mutate((C_word*)lf[111]+1 /* (set! f64vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 523  pack-copy */
f_3178(t3,lf[60],lf[112]);}

/* k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3291,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1 /* (set! u8vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 524  pack-copy */
f_3178(t3,lf[62],lf[113]);}

/* k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3295,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1 /* (set! s8vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 525  pack-copy */
f_3178(t3,lf[65],lf[114]);}

/* k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3299,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1 /* (set! u16vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 526  pack-copy */
f_3178(t3,lf[67],lf[115]);}

/* k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3303,2,t0,t1);}
t2=C_mutate((C_word*)lf[115]+1 /* (set! s16vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 527  pack-copy */
f_3178(t3,lf[69],lf[116]);}

/* k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3307,2,t0,t1);}
t2=C_mutate((C_word*)lf[116]+1 /* (set! u32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 528  pack-copy */
f_3178(t3,lf[71],lf[117]);}

/* k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3311,2,t0,t1);}
t2=C_mutate((C_word*)lf[117]+1 /* (set! s32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 529  pack-copy */
f_3178(t3,lf[73],lf[118]);}

/* k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3315,2,t0,t1);}
t2=C_mutate((C_word*)lf[118]+1 /* (set! f32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3319,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 530  pack-copy */
f_3178(t3,lf[75],lf[119]);}

/* k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3319,2,t0,t1);}
t2=C_mutate((C_word*)lf[119]+1 /* (set! f64vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 532  unpack */
f_3196(t3,lf[60],C_SCHEME_TRUE,lf[120]);}

/* k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3323,2,t0,t1);}
t2=C_mutate((C_word*)lf[120]+1 /* (set! blob->u8vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 533  unpack */
f_3196(t3,lf[62],C_SCHEME_TRUE,lf[121]);}

/* k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
t2=C_mutate((C_word*)lf[121]+1 /* (set! blob->s8vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 534  unpack */
f_3196(t3,lf[65],C_fix(2),lf[122]);}

/* k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3331,2,t0,t1);}
t2=C_mutate((C_word*)lf[122]+1 /* (set! blob->u16vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 535  unpack */
f_3196(t3,lf[67],C_fix(2),lf[123]);}

/* k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3335,2,t0,t1);}
t2=C_mutate((C_word*)lf[123]+1 /* (set! blob->s16vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 536  unpack */
f_3196(t3,lf[69],C_fix(4),lf[124]);}

/* k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3339,2,t0,t1);}
t2=C_mutate((C_word*)lf[124]+1 /* (set! blob->u32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 537  unpack */
f_3196(t3,lf[71],C_fix(4),lf[125]);}

/* k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3343,2,t0,t1);}
t2=C_mutate((C_word*)lf[125]+1 /* (set! blob->s32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 538  unpack */
f_3196(t3,lf[73],C_fix(4),lf[126]);}

/* k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3347,2,t0,t1);}
t2=C_mutate((C_word*)lf[126]+1 /* (set! blob->f32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3351,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 539  unpack */
f_3196(t3,lf[75],C_fix(8),lf[127]);}

/* k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3351,2,t0,t1);}
t2=C_mutate((C_word*)lf[127]+1 /* (set! blob->f64vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 541  unpack-copy */
f_3225(t3,lf[60],C_SCHEME_TRUE,lf[128]);}

/* k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3355,2,t0,t1);}
t2=C_mutate((C_word*)lf[128]+1 /* (set! blob->u8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 542  unpack-copy */
f_3225(t3,lf[62],C_SCHEME_TRUE,lf[129]);}

/* k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3359,2,t0,t1);}
t2=C_mutate((C_word*)lf[129]+1 /* (set! blob->s8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 543  unpack-copy */
f_3225(t3,lf[65],C_fix(2),lf[130]);}

/* k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3363,2,t0,t1);}
t2=C_mutate((C_word*)lf[130]+1 /* (set! blob->u16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 544  unpack-copy */
f_3225(t3,lf[67],C_fix(2),lf[131]);}

/* k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3367,2,t0,t1);}
t2=C_mutate((C_word*)lf[131]+1 /* (set! blob->s16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 545  unpack-copy */
f_3225(t3,lf[69],C_fix(4),lf[132]);}

/* k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3371,2,t0,t1);}
t2=C_mutate((C_word*)lf[132]+1 /* (set! blob->u32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 546  unpack-copy */
f_3225(t3,lf[71],C_fix(4),lf[133]);}

/* k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3375,2,t0,t1);}
t2=C_mutate((C_word*)lf[133]+1 /* (set! blob->s32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 547  unpack-copy */
f_3225(t3,lf[73],C_fix(4),lf[134]);}

/* k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3379,2,t0,t1);}
t2=C_mutate((C_word*)lf[134]+1 /* (set! blob->f32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3383,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 548  unpack-copy */
f_3225(t3,lf[75],C_fix(8),lf[135]);}

/* k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[103],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3383,2,t0,t1);}
t2=C_mutate((C_word*)lf[135]+1 /* (set! blob->f64vector ...) */,t1);
t3=*((C_word*)lf[136]+1);
t4=*((C_word*)lf[137]+1);
t5=(C_word)C_a_i_list(&a,16,lf[138],*((C_word*)lf[77]+1),lf[139],*((C_word*)lf[78]+1),lf[140],*((C_word*)lf[79]+1),lf[141],*((C_word*)lf[80]+1),lf[142],*((C_word*)lf[81]+1),lf[143],*((C_word*)lf[82]+1),lf[144],*((C_word*)lf[83]+1),lf[145],*((C_word*)lf[84]+1));
t6=C_mutate((C_word*)lf[136]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3388,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word)li111),tmp=(C_word)a,a+=6,tmp));
t7=*((C_word*)lf[150]+1);
t8=C_mutate((C_word*)lf[150]+1 /* (set! user-print-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3444,a[2]=t7,a[3]=((C_word)li112),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate(&lf[152] /* (set! subvector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3604,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[153]+1 /* (set! subu8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3647,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[154]+1 /* (set! subu16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3653,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[155]+1 /* (set! subu32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3659,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[156]+1 /* (set! subs8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3665,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[157]+1 /* (set! subs16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3671,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[158]+1 /* (set! subs32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3677,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[159]+1 /* (set! subf32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3683,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[160]+1 /* (set! subf64vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3689,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[161]+1 /* (set! write-u8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3695,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[165]+1 /* (set! read-u8vector! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3811,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t20=*((C_word*)lf[168]+1);
t21=*((C_word*)lf[169]+1);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3912,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp);
t23=C_mutate((C_word*)lf[170]+1 /* (set! read-u8vector ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3921,a[2]=t20,a[3]=t21,a[4]=t22,a[5]=((C_word)li137),tmp=(C_word)a,a+=6,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4039,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 670  register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[173]+1)))(3,*((C_word*)lf[173]+1),t24,lf[174]);}

/* k4037 in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* read-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr2r,(void*)f_3921r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3921r(t0,t1,t2);}}

static void C_ccall f_3921r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(14);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li134),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3985,a[2]=t3,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3990,a[2]=t4,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-n14481496 */
t6=t5;
f_3990(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-p14491492 */
t8=t4;
f_3985(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body14461455 */
t10=t3;
f_3923(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-n1448 in read-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3990(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3990,NULL,2,t0,t1);}
/* def-p14491492 */
t2=((C_word*)t0)[2];
f_3985(t2,t1,C_SCHEME_FALSE);}

/* def-p1449 in read-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3985(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3985,NULL,3,t0,t1,t2);}
/* body14461455 */
t3=((C_word*)t0)[2];
f_3923(t3,t1,t2,*((C_word*)lf[167]+1));}

/* body1446 in read-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3923(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3923,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 650  ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[163]+1)))(4,*((C_word*)lf[163]+1),t4,t3,lf[170]);}

/* k3925 in body1446 in read-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3927,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],lf[170]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3936,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 652  ##sys#allocate-vector */
t4=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[7],C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3954,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 659  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k3952 in k3925 in body1446 in read-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3954,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3959,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li133),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3959(t5,((C_word*)t0)[2]);}

/* loop in k3952 in k3925 in body1446 in read-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3959(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3959,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 661  ##sys#read-char-0 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[172]+1)))(3,*((C_word*)lf[172]+1),t2,((C_word*)t0)[2]);}

/* k3961 in loop in k3952 in k3925 in body1446 in read-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3963,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 663  get-output-string */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3981,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 667  ##sys#write-char/port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[171]+1)))(4,*((C_word*)lf[171]+1),t2,t1,((C_word*)t0)[3]);}}

/* k3979 in k3961 in loop in k3952 in k3925 in body1446 in read-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 668  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3959(t2,((C_word*)t0)[2]);}

/* k3970 in k3961 in loop in k3952 in k3925 in body1446 in read-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(t1);
/* srfi-4.scm: 665  wrap */
f_3912(((C_word*)t0)[2],t1,t2);}

/* k3934 in k3925 in body1446 in read-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3939,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 653  ##sys#read-string! */
((C_proc6)C_retrieve_proc(*((C_word*)lf[166]+1)))(6,*((C_word*)lf[166]+1),t2,((C_word*)t0)[5],t1,((C_word*)t0)[2],C_fix(0));}

/* k3937 in k3934 in k3925 in body1446 in read-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3939,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(((C_word*)t0)[5]);
t3=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,lf[60],((C_word*)t0)[5]));}
else{
/* srfi-4.scm: 657  wrap */
f_3912(((C_word*)t0)[3],((C_word*)t0)[5],t1);}}

/* wrap in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3912(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3912,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3920,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 645  ##sys#allocate-vector */
t5=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k3918 in wrap in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3920,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_substring_copy(((C_word*)t0)[4],t1,C_fix(0),((C_word*)t0)[3],C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,lf[60],t1));}

/* read-u8vector! in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_3811r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3811r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3811r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(15);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3813,a[2]=t5,a[3]=t3,a[4]=((C_word)li128),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3858,a[2]=t6,a[3]=((C_word)li129),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3863,a[2]=t7,a[3]=((C_word)li130),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-port13821409 */
t9=t8;
f_3863(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start13831405 */
t11=t7;
f_3858(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body13801389 */
t13=t6;
f_3813(t13,t1,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-port1382 in read-u8vector! in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3863(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3863,NULL,2,t0,t1);}
/* def-start13831405 */
t2=((C_word*)t0)[2];
f_3858(t2,t1,*((C_word*)lf[167]+1));}

/* def-start1383 in read-u8vector! in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3858(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3858,NULL,3,t0,t1,t2);}
/* body13801389 */
t3=((C_word*)t0)[2];
f_3813(t3,t1,t2,C_fix(0));}

/* body1380 in read-u8vector! in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3813(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3813,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3817,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 629  ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[163]+1)))(4,*((C_word*)lf[163]+1),t4,t2,lf[165]);}

/* k3815 in body1380 in read-u8vector! in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3817,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[165]);
t3=(C_word)C_i_check_structure_2(((C_word*)t0)[5],lf[60],lf[165]);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3829,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t6=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[3])[1],lf[165]);
t7=(C_word)C_fixnum_plus(((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1]);
t8=(C_word)C_block_size(t4);
if(C_truep((C_word)C_fixnum_greaterp(t7,t8))){
t9=(C_word)C_block_size(t4);
t10=(C_word)C_fixnum_difference(t9,((C_word*)t0)[6]);
t11=C_mutate(((C_word *)((C_word*)t0)[3])+1,t10);
t12=t5;
f_3829(t12,t11);}
else{
t9=t5;
f_3829(t9,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_3829(t6,C_SCHEME_UNDEFINED);}}

/* k3827 in k3815 in body1380 in read-u8vector! in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 637  ##sys#read-string! */
((C_proc6)C_retrieve_proc(*((C_word*)lf[166]+1)))(6,*((C_word*)lf[166]+1),((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* write-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3695(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_3695r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3695r(t0,t1,t2,t3);}}

static void C_ccall f_3695r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3697,a[2]=t2,a[3]=((C_word)li123),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3734,a[2]=t2,a[3]=t4,a[4]=((C_word)li124),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3743,a[2]=t5,a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3748,a[2]=t6,a[3]=((C_word)li126),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-port13091348 */
t8=t7;
f_3748(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-from13101344 */
t10=t6;
f_3743(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-to13111339 */
t12=t5;
f_3734(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body13071317 */
t14=t4;
f_3697(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-port1309 in write-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3748(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3748,NULL,2,t0,t1);}
/* def-from13101344 */
t2=((C_word*)t0)[2];
f_3743(t2,t1,*((C_word*)lf[164]+1));}

/* def-from1310 in write-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3743(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3743,NULL,3,t0,t1,t2);}
/* def-to13111339 */
t3=((C_word*)t0)[2];
f_3734(t3,t1,t2,C_fix(0));}

/* def-to1311 in write-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3734(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3734,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3742,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 620  u8vector-length */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k3740 in def-to1311 in write-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* body13071317 */
t2=((C_word*)t0)[5];
f_3697(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body1307 in write-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3697(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3697,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(((C_word*)t0)[2],lf[60],lf[161]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3704,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 622  ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[163]+1)))(4,*((C_word*)lf[163]+1),t6,t2,lf[161]);}

/* k3702 in body1307 in write-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3704,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3712,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word)li122),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_3712(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop1323 in k3702 in body1307 in write-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3712(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3712,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3722,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_make_character((C_word)C_unfix((C_word)C_u8peek(((C_word*)t0)[3],t2)));
/* srfi-4.scm: 626  ##sys#write-char-0 */
((C_proc4)C_retrieve_proc(*((C_word*)lf[162]+1)))(4,*((C_word*)lf[162]+1),t3,t4,((C_word*)t0)[2]);}}

/* k3720 in doloop1323 in k3702 in body1307 in write-u8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3712(t3,((C_word*)t0)[2],t2);}

/* subf64vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3689,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 618  subvector */
f_3604(t1,t2,lf[75],C_fix(8),t3,t4,lf[160]);}

/* subf32vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3683,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 617  subvector */
f_3604(t1,t2,lf[73],C_fix(4),t3,t4,lf[159]);}

/* subs32vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3677,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 616  subvector */
f_3604(t1,t2,lf[71],C_fix(4),t3,t4,lf[158]);}

/* subs16vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3671,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 615  subvector */
f_3604(t1,t2,lf[67],C_fix(2),t3,t4,lf[157]);}

/* subs8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3665,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 614  subvector */
f_3604(t1,t2,lf[62],C_fix(1),t3,t4,lf[156]);}

/* subu32vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3659,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 613  subvector */
f_3604(t1,t2,lf[69],C_fix(4),t3,t4,lf[155]);}

/* subu16vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3653,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 612  subvector */
f_3604(t1,t2,lf[65],C_fix(2),t3,t4,lf[154]);}

/* subu8vector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3647,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 611  subvector */
f_3604(t1,t2,lf[60],C_fix(1),t3,t4,lf[153]);}

/* subvector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3604(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3604,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(C_word)C_i_check_structure_2(t2,t3,t7);
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_block_size(t9);
t11=(C_word)C_fixnum_divide(t10,t4);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3617,a[2]=t7,a[3]=t11,a[4]=t1,a[5]=t9,a[6]=t3,a[7]=t4,a[8]=t5,a[9]=t6,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_fixnum_plus(t11,C_fix(1));
/* srfi-4.scm: 602  ##sys#check-range */
t14=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t12,t5,C_fix(0),t13,t7);}

/* k3615 in subvector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3620,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-4.scm: 603  ##sys#check-range */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[9],C_fix(0),t3,((C_word*)t0)[2]);}

/* k3618 in k3615 in subvector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3620,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_fixnum_times(((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3626,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 605  ##sys#allocate-vector */
t5=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k3624 in k3618 in k3615 in subvector in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3626,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_a_i_record(&a,2,((C_word*)t0)[7],t1);
t4=(C_word)C_fixnum_times(((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_copy_subvector(t1,((C_word*)t0)[4],C_fix(0),t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* ##sys#user-print-hook in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[102],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3444,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[85]+1),C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[138],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[60],t6);
t8=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[86]+1),C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[139],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[62],t9);
t11=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[87]+1),C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[140],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[65],t12);
t14=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[88]+1),C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[141],t14);
t16=(C_word)C_a_i_cons(&a,2,lf[67],t15);
t17=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[89]+1),C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,lf[142],t17);
t19=(C_word)C_a_i_cons(&a,2,lf[69],t18);
t20=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[90]+1),C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,lf[143],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[71],t21);
t23=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[91]+1),C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,lf[144],t23);
t25=(C_word)C_a_i_cons(&a,2,lf[73],t24);
t26=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[92]+1),C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[145],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[75],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,t25,t29);
t31=(C_word)C_a_i_cons(&a,2,t22,t30);
t32=(C_word)C_a_i_cons(&a,2,t19,t31);
t33=(C_word)C_a_i_cons(&a,2,t16,t32);
t34=(C_word)C_a_i_cons(&a,2,t13,t33);
t35=(C_word)C_a_i_cons(&a,2,t10,t34);
t36=(C_word)C_a_i_cons(&a,2,t7,t35);
t37=(C_word)C_i_assq((C_word)C_slot(t2,C_fix(0)),t36);
if(C_truep(t37)){
t38=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3454,a[2]=t2,a[3]=t37,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 589  ##sys#print */
t39=*((C_word*)lf[151]+1);
((C_proc5)(void*)(*((C_word*)t39+1)))(5,t39,t38,C_make_character(35),C_SCHEME_FALSE,t4);}
else{
/* srfi-4.scm: 592  old-hook */
t38=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t38))(5,t38,t1,t2,t3,t4);}}

/* k3452 in ##sys#user-print-hook in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* srfi-4.scm: 590  ##sys#print */
t4=*((C_word*)lf[151]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k3455 in k3452 in ##sys#user-print-hook in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3464,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
t4=t3;
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,((C_word*)t0)[2]);}

/* k3462 in k3455 in k3452 in ##sys#user-print-hook in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 591  ##sys#print */
t2=*((C_word*)lf[151]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3388(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3388,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_truep((C_word)C_eqp(t4,C_make_character(117)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(102)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(85)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(83)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(70)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3398,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 566  read */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
/* srfi-4.scm: 571  old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k3396 in ##sys#user-read-hook in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3398,2,t0,t1);}
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:C_SCHEME_FALSE);
t4=(C_word)C_eqp(t3,lf[146]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[147]));
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_memq(t3,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3423,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 569  read */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 570  ##sys#read-error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[148]+1)))(5,*((C_word*)lf[148]+1),((C_word*)t0)[5],((C_word*)t0)[2],lf[149],t3);}}}

/* k3421 in k3396 in ##sys#user-read-hook in k3381 in k3377 in k3373 in k3369 in k3365 in k3361 in k3357 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_slot(t2,C_fix(0));
t4=t3;
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t1);}

/* unpack-copy in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3225(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3225,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3227,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li109),tmp=(C_word)a,a+=6,tmp));}

/* f_3227 in unpack-copy in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3227,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3237,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 506  ##sys#make-blob */
((C_proc3)C_retrieve_proc(*((C_word*)lf[101]+1)))(3,*((C_word*)lf[101]+1),t5,t4);}

/* k3235 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3237,2,t0,t1);}
t2=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_fix(0),(C_word)C_fixnum_modulo(((C_word*)t0)[6],((C_word*)t0)[7])));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,((C_word*)t0)[4],(C_word)C_copy_block(((C_word*)t0)[3],t1)));}
else{
/* srfi-4.scm: 512  ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[5],((C_word*)t0)[2],lf[103],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* unpack in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3196(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3196,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3198,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li107),tmp=(C_word)a,a+=6,tmp));}

/* f_3198 in unpack in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3198,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(C_fix(0),(C_word)C_fixnum_modulo(t4,((C_word*)t0)[3])));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,2,((C_word*)t0)[2],t2));}
else{
/* srfi-4.scm: 500  ##sys#error */
t7=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t1,((C_word*)t0)[4],lf[102],((C_word*)t0)[2],t4,((C_word*)t0)[3]);}}

/* pack-copy in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3178(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3178,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3180,a[2]=t3,a[3]=t2,a[4]=((C_word)li105),tmp=(C_word)a,a+=5,tmp));}

/* f_3180 in pack-copy in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3180,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3190,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_block_size(t4);
/* srfi-4.scm: 490  ##sys#make-blob */
((C_proc3)C_retrieve_proc(*((C_word*)lf[101]+1)))(3,*((C_word*)lf[101]+1),t5,t6);}

/* k3188 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_copy_block(((C_word*)t0)[2],t1));}

/* pack in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3167(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3167,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3169,a[2]=t3,a[3]=t2,a[4]=((C_word)li103),tmp=(C_word)a,a+=5,tmp));}

/* f_3169 in pack in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3169,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* f64vector? in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3161,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[75]));}

/* f32vector? in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3155,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[73]));}

/* s32vector? in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3149(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3149,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[71]));}

/* u32vector? in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3143,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[69]));}

/* s16vector? in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3137,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[67]));}

/* u16vector? in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3131,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[65]));}

/* s8vector? in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3125,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[62]));}

/* u8vector? in k3115 in k3111 in k3107 in k3103 in k3099 in k3095 in k3091 in k3087 in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3119,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[60]));}

/* init in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3052(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3052,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3054,a[2]=t2,a[3]=t3,a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp));}

/* f_3054 in init in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3054(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3054,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3058,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 448  length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3056 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3058,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3063,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word)li92),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3063(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k3056 */
static void C_fcall f_3063(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3063,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3077,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 452  ref */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}}

/* k3075 in loop in k3056 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3081,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-4.scm: 453  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3063(t4,t2,t3);}

/* k3079 in k3075 in loop in k3056 */
static void C_ccall f_3081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3081,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* f64vector in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3046r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3046r(t0,t1,t2);}}

static void C_ccall f_3046r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 439  list->f64vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* f32vector in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3040r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3040r(t0,t1,t2);}}

static void C_ccall f_3040r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 435  list->f32vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* s32vector in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3034r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3034r(t0,t1,t2);}}

static void C_ccall f_3034r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 431  list->s32vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* u32vector in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3028r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3028r(t0,t1,t2);}}

static void C_ccall f_3028r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 427  list->u32vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* s16vector in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3022r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3022r(t0,t1,t2);}}

static void C_ccall f_3022r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 423  list->s16vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* u16vector in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3016r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3016r(t0,t1,t2);}}

static void C_ccall f_3016r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 419  list->u16vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* s8vector in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3010(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3010r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3010r(t0,t1,t2);}}

static void C_ccall f_3010r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 415  list->s8vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* u8vector in k3000 in k2996 in k2992 in k2988 in k2984 in k2980 in k2976 in k2972 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3004r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3004r(t0,t1,t2);}}

static void C_ccall f_3004r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 411  list->u8vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* init in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2934(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2934,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2936,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp));}

/* f_2936 in init in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2936,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2946,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 389  make */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2944 */
static void C_ccall f_2946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2946,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2951,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word)li81),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2951(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop938 in k2944 */
static void C_fcall f_2951(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2951,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2958,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
/* srfi-4.scm: 394  set */
t6=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[5],t3,(C_word)C_slot(t2,C_fix(0)));}
else{
/* srfi-4.scm: 395  ##sys#error-not-a-proper-list */
t6=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}}

/* k2956 in doloop938 in k2944 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2951(t2,((C_word*)t0)[4],(C_word)C_slot(((C_word*)t0)[3],C_fix(1)),(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2807(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_2807r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2807r(t0,t1,t2,t3);}}

static void C_ccall f_2807r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li76),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2861,a[2]=t4,a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2866,a[2]=t5,a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2871,a[2]=t6,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init856903 */
t8=t7;
f_2871(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?857899 */
t10=t6;
f_2866(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin858894 */
t12=t5;
f_2861(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body854864 */
t14=t4;
f_2809(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init856 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2871(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2871,NULL,2,t0,t1);}
/* def-ext?857899 */
t2=((C_word*)t0)[2];
f_2866(t2,t1,C_SCHEME_FALSE);}

/* def-ext?857 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2866(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2866,NULL,3,t0,t1,t2);}
/* def-fin858894 */
t3=((C_word*)t0)[2];
f_2861(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin858 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2861(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2861,NULL,4,t0,t1,t2,t3);}
/* body854864 */
t4=((C_word*)t0)[2];
f_2809(t4,t1,t2,t3);}

/* body854 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2809(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2809,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[74]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 368  alloc */
f_1917(t6,lf[74],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(3)),t3);}

/* k2858 in body854 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2860,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[75],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2819,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 369  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2819(2,t5,C_SCHEME_UNDEFINED);}}

/* k2817 in k2858 in body854 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2819,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[74]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_2831(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2850,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 375  exact->inexact */
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2848 in k2817 in k2858 in body854 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2831(t3,t2);}

/* k2829 in k2817 in k2858 in body854 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2831(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2831,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2836,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li75),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2836(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop877 in k2829 in k2817 in k2858 in body854 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2836(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2836,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2843,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 378  ##sys#f64vector-set! */
t4=lf[23];
f_1656(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)((C_word*)t0)[2])[1]);}}

/* k2841 in doloop877 in k2829 in k2817 in k2858 in body854 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2836(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_2680r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2680r(t0,t1,t2,t3);}}

static void C_ccall f_2680r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li70),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2734,a[2]=t4,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2739,a[2]=t5,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2744,a[2]=t6,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init777824 */
t8=t7;
f_2744(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?778820 */
t10=t6;
f_2739(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin779815 */
t12=t5;
f_2734(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body775785 */
t14=t4;
f_2682(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init777 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2744(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2744,NULL,2,t0,t1);}
/* def-ext?778820 */
t2=((C_word*)t0)[2];
f_2739(t2,t1,C_SCHEME_FALSE);}

/* def-ext?778 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2739(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2739,NULL,3,t0,t1,t2);}
/* def-fin779815 */
t3=((C_word*)t0)[2];
f_2734(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin779 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2734(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2734,NULL,4,t0,t1,t2,t3);}
/* body775785 */
t4=((C_word*)t0)[2];
f_2682(t4,t1,t2,t3);}

/* body775 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2682(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2682,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[72]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2733,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 353  alloc */
f_1917(t6,lf[72],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k2731 in body775 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[73],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2692,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 354  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2692(2,t5,C_SCHEME_UNDEFINED);}}

/* k2690 in k2731 in body775 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2692,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[72]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_2704(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2723,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 360  exact->inexact */
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2721 in k2690 in k2731 in body775 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2704(t3,t2);}

/* k2702 in k2690 in k2731 in body775 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2704(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2704,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2709,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li69),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2709(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop798 in k2702 in k2690 in k2731 in body775 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2709(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2709,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2716,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 363  ##sys#f32vector-set! */
t4=lf[22];
f_1653(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)((C_word*)t0)[2])[1]);}}

/* k2714 in doloop798 in k2702 in k2690 in k2731 in body775 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2709(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2560(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_2560r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2560r(t0,t1,t2,t3);}}

static void C_ccall f_2560r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li64),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2607,a[2]=t4,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2612,a[2]=t5,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2617,a[2]=t6,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init701745 */
t8=t7;
f_2617(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?702741 */
t10=t6;
f_2612(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin703736 */
t12=t5;
f_2607(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body699709 */
t14=t4;
f_2562(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init701 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2617,NULL,2,t0,t1);}
/* def-ext?702741 */
t2=((C_word*)t0)[2];
f_2612(t2,t1,C_SCHEME_FALSE);}

/* def-ext?702 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2612(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2612,NULL,3,t0,t1,t2);}
/* def-fin703736 */
t3=((C_word*)t0)[2];
f_2607(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin703 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2607(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2607,NULL,4,t0,t1,t2,t3);}
/* body699709 */
t4=((C_word*)t0)[2];
f_2562(t4,t1,t2,t3);}

/* body699 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2562(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2562,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[70]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 340  alloc */
f_1917(t5,lf[70],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k2604 in body699 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2606,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[71],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2572,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 341  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2572(2,t5,C_SCHEME_UNDEFINED);}}

/* k2570 in k2604 in body699 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2572,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[70]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2586,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li63),tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2586(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* doloop720 in k2570 in k2604 in body699 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static C_word C_fcall f_2586(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=f_1650(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_2440r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2440r(t0,t1,t2,t3);}}

static void C_ccall f_2440r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li58),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2487,a[2]=t4,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2492,a[2]=t5,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2497,a[2]=t6,a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init625669 */
t8=t7;
f_2497(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?626665 */
t10=t6;
f_2492(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin627660 */
t12=t5;
f_2487(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body623633 */
t14=t4;
f_2442(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init625 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2497(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2497,NULL,2,t0,t1);}
/* def-ext?626665 */
t2=((C_word*)t0)[2];
f_2492(t2,t1,C_SCHEME_FALSE);}

/* def-ext?626 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2492(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2492,NULL,3,t0,t1,t2);}
/* def-fin627660 */
t3=((C_word*)t0)[2];
f_2487(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin627 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2487(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2487,NULL,4,t0,t1,t2,t3);}
/* body623633 */
t4=((C_word*)t0)[2];
f_2442(t4,t1,t2,t3);}

/* body623 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2442(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2442,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[68]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2486,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 327  alloc */
f_1917(t5,lf[68],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k2484 in body623 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2486,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[69],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2452,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 328  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2452(2,t5,C_SCHEME_UNDEFINED);}}

/* k2450 in k2484 in body623 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[68]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2466,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li57),tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2466(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* doloop644 in k2450 in k2484 in body623 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static C_word C_fcall f_2466(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=f_1647(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2320(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_2320r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2320r(t0,t1,t2,t3);}}

static void C_ccall f_2320r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li52),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2367,a[2]=t4,a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2372,a[2]=t5,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2377,a[2]=t6,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init549593 */
t8=t7;
f_2377(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?550589 */
t10=t6;
f_2372(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin551584 */
t12=t5;
f_2367(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body547557 */
t14=t4;
f_2322(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init549 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2377(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2377,NULL,2,t0,t1);}
/* def-ext?550589 */
t2=((C_word*)t0)[2];
f_2372(t2,t1,C_SCHEME_FALSE);}

/* def-ext?550 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2372(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2372,NULL,3,t0,t1,t2);}
/* def-fin551584 */
t3=((C_word*)t0)[2];
f_2367(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin551 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2367(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2367,NULL,4,t0,t1,t2,t3);}
/* body547557 */
t4=((C_word*)t0)[2];
f_2322(t4,t1,t2,t3);}

/* body547 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2322(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2322,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[66]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2366,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 314  alloc */
f_1917(t5,lf[66],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k2364 in body547 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2366,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[67],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2332,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 315  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2332(2,t5,C_SCHEME_UNDEFINED);}}

/* k2330 in k2364 in body547 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2332,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 319  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-32768),C_fix(32767),lf[66]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2339 in k2330 in k2364 in body547 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2341,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li51),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2346(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop568 in k2339 in k2330 in k2364 in body547 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2346(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2346,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2353,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 322  ##sys#s16vector-set! */
t4=lf[19];
f_1644(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k2351 in doloop568 in k2339 in k2330 in k2364 in body547 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2346(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_2200r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2200r(t0,t1,t2,t3);}}

static void C_ccall f_2200r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li46),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2247,a[2]=t4,a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2252,a[2]=t5,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2257,a[2]=t6,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init473517 */
t8=t7;
f_2257(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?474513 */
t10=t6;
f_2252(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin475508 */
t12=t5;
f_2247(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body471481 */
t14=t4;
f_2202(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init473 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2257(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2257,NULL,2,t0,t1);}
/* def-ext?474513 */
t2=((C_word*)t0)[2];
f_2252(t2,t1,C_SCHEME_FALSE);}

/* def-ext?474 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2252(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2252,NULL,3,t0,t1,t2);}
/* def-fin475508 */
t3=((C_word*)t0)[2];
f_2247(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin475 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2247(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2247,NULL,4,t0,t1,t2,t3);}
/* body471481 */
t4=((C_word*)t0)[2];
f_2202(t4,t1,t2,t3);}

/* body471 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2202(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2202,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[64]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2246,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 301  alloc */
f_1917(t5,lf[64],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k2244 in body471 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2246,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[65],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2212,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 302  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2212(2,t5,C_SCHEME_UNDEFINED);}}

/* k2210 in k2244 in body471 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2212,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 306  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(65535),lf[64]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2219 in k2210 in k2244 in body471 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2221,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2226,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li45),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2226(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop492 in k2219 in k2210 in k2244 in body471 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2226(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2226,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2233,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 309  ##sys#u16vector-set! */
t4=lf[18];
f_1641(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k2231 in doloop492 in k2219 in k2210 in k2244 in body471 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2226(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2080(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_2080r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2080r(t0,t1,t2,t3);}}

static void C_ccall f_2080r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li40),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2127,a[2]=t4,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2132,a[2]=t5,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2137,a[2]=t6,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init397441 */
t8=t7;
f_2137(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?398437 */
t10=t6;
f_2132(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin399432 */
t12=t5;
f_2127(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body395405 */
t14=t4;
f_2082(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init397 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2137,NULL,2,t0,t1);}
/* def-ext?398437 */
t2=((C_word*)t0)[2];
f_2132(t2,t1,C_SCHEME_FALSE);}

/* def-ext?398 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2132(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2132,NULL,3,t0,t1,t2);}
/* def-fin399432 */
t3=((C_word*)t0)[2];
f_2127(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin399 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2127(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2127,NULL,4,t0,t1,t2,t3);}
/* body395405 */
t4=((C_word*)t0)[2];
f_2082(t4,t1,t2,t3);}

/* body395 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2082(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2082,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[61]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2126,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 288  alloc */
f_1917(t5,lf[61],((C_word*)t0)[5],t3);}

/* k2124 in body395 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2126,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[62],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2092,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 289  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2092(2,t5,C_SCHEME_UNDEFINED);}}

/* k2090 in k2124 in body395 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2092,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 293  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-128),C_fix(127),lf[61]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2099 in k2090 in k2124 in body395 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2101,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2106,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li39),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2106(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop416 in k2099 in k2090 in k2124 in body395 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2106(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2106,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2113,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 296  ##sys#s8vector-set! */
t4=lf[17];
f_1638(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k2111 in doloop416 in k2099 in k2090 in k2124 in body395 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2106(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1960(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1960r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1960r(t0,t1,t2,t3);}}

static void C_ccall f_1960r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li34),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2007,a[2]=t4,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2012,a[2]=t5,a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2017,a[2]=t6,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init320364 */
t8=t7;
f_2017(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?321360 */
t10=t6;
f_2012(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin?322355 */
t12=t5;
f_2007(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body318328 */
t14=t4;
f_1962(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init320 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2017(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2017,NULL,2,t0,t1);}
/* def-ext?321360 */
t2=((C_word*)t0)[2];
f_2012(t2,t1,C_SCHEME_FALSE);}

/* def-ext?321 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2012(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2012,NULL,3,t0,t1,t2);}
/* def-fin?322355 */
t3=((C_word*)t0)[2];
f_2007(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin?322 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2007(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2007,NULL,4,t0,t1,t2,t3);}
/* body318328 */
t4=((C_word*)t0)[2];
f_1962(t4,t1,t2,t3,C_SCHEME_TRUE);}

/* body318 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_1962(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1962,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[59]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2006,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* srfi-4.scm: 275  alloc */
f_1917(t6,lf[59],((C_word*)t0)[5],t3);}

/* k2004 in body318 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2006,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[60],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1972,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 276  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1972(2,t5,C_SCHEME_UNDEFINED);}}

/* k1970 in k2004 in body318 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1972,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 280  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(255),lf[59]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1979 in k1970 in k2004 in body318 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1981,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1986,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li33),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1986(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop339 in k1979 in k1970 in k2004 in body318 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_1986(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1986,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1993,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 283  ##sys#u8vector-set! */
t4=lf[16];
f_1635(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1991 in doloop339 in k1979 in k1970 in k2004 in body318 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1986(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* release-number-vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1935,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1942,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_1942(t5,(C_word)C_i_memq(t4,lf[58]));}
else{
t4=t3;
f_1942(t4,C_SCHEME_FALSE);}}

/* k1940 in release-number-vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_1942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-4.scm: 269  ext-free */
t2=((C_word*)t0)[4];
f_1915(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 270  ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[56],lf[57],((C_word*)t0)[2]);}}

/* alloc in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_1917(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1917,NULL,4,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=t3;
t6=(C_word)C_i_foreign_fixnum_argumentp(t5);
t7=(C_word)stub265(C_SCHEME_UNDEFINED,t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* srfi-4.scm: 260  ##sys#error */
t8=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,lf[54],t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1933,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 261  ##sys#allocate-vector */
t6=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}}

/* k1931 in alloc in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_string_to_bytevector(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* ext-free in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1915,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub272(C_SCHEME_UNDEFINED,t2));}

/* f_1761 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1761,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1765,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 178  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1763 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1768,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fits_in_int_p(((C_word*)t0)[2]))){
t3=t2;
f_1768(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm: 180  ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[41],lf[42],((C_word*)t0)[2]);}}

/* k1766 in k1763 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1771,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 181  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[41]);}

/* k1769 in k1766 in k1763 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 182  upd */
t2=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_1650(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* f_1788 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1788,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1792,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 186  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1790 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1795,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_negativep(((C_word*)t0)[2]))){
/* srfi-4.scm: 188  ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[38],lf[39],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_fits_in_unsigned_int_p(((C_word*)t0)[2]))){
t3=t2;
f_1795(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm: 190  ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[38],lf[40],((C_word*)t0)[2]);}}}

/* k1793 in k1790 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 191  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[38]);}

/* k1796 in k1793 in k1790 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 192  upd */
t2=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_1647(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* setf in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_1822(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1822,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1824,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li26),tmp=(C_word)a,a+=6,tmp));}

/* f_1824 in setf in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1824,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1828,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 196  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1826 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1828,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 198  ##sys#check-range */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k1832 in k1826 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)t0)[2]))){
t3=t2;
f_1841(2,t3,((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 201  exact->inexact */
C_exact_to_inexact(3,0,t2,((C_word*)t0)[2]);}}

/* k1839 in k1832 in k1826 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 199  upd */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setu in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_1733(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1733,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1735,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li24),tmp=(C_word)a,a+=6,tmp));}

/* f_1735 in setu in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1735,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1739,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 169  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1737 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1739,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1745,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[7],C_fix(0)))){
/* srfi-4.scm: 172  ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[6],lf[33],((C_word*)t0)[7]);}
else{
t4=t3;
f_1745(2,t4,C_SCHEME_UNDEFINED);}}

/* k1743 in k1737 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1748,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 173  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],C_fix(0),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1746 in k1743 in k1737 */
static void C_ccall f_1748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 174  upd */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_1716(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1716,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1718,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li22),tmp=(C_word)a,a+=6,tmp));}

/* f_1718 in set in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1718,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1722,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 162  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1720 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1722,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1728,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 164  ##sys#check-range */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k1726 in k1720 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 165  upd */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* get in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_1702(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1702,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1704,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=((C_word)li20),tmp=(C_word)a,a+=6,tmp));}

/* f_1704 in get in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1704,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1708,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 156  length */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1706 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1711,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 157  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),t1,((C_word*)t0)[2]);}

/* k1709 in k1706 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 158  acc */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* len */
static void C_fcall f_1659(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1659,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1661,a[2]=t3,a[3]=t4,a[4]=t2,a[5]=((C_word)li18),tmp=(C_word)a,a+=6,tmp));}

/* f_1661 in len */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1661,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_block_size((C_word)C_slot(t2,C_fix(1)));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_shift_right(t4,((C_word*)t0)[2]):t4));}

/* ##sys#f64vector-set! */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1656,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f64poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f32vector-set! */
static void C_ccall f_1653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1653,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f32poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s32vector-set! */
static C_word C_fcall f_1650(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_stack_check;
return((C_word)C_s32poke((C_word)C_slot(t1,C_fix(1)),t2,t3));}

/* ##sys#u32vector-set! */
static C_word C_fcall f_1647(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_stack_check;
return((C_word)C_u32poke((C_word)C_slot(t1,C_fix(1)),t2,t3));}

/* ##sys#s16vector-set! */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1644,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u16vector-set! */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1641,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s8vector-set! */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1638,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u8vector-set! */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1635,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f64vector-ref */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1629,4,t0,t1,t2,t3);}
t4=(C_word)C_f64peek((C_word)C_slot(t2,C_fix(1)),t3);
/* srfi-4.scm: 116  ##sys#cons-flonum */
t5=*((C_word*)lf[14]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#f32vector-ref */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1623,4,t0,t1,t2,t3);}
t4=(C_word)C_f32peek((C_word)C_slot(t2,C_fix(1)),t3);
/* srfi-4.scm: 112  ##sys#cons-flonum */
t5=*((C_word*)lf[14]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#s32vector-ref */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1620,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_s32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u32vector-ref */
static void C_ccall f_1617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1617,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_u32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s16vector-ref */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1614,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u16vector-ref */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1611,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s8vector-ref */
static void C_ccall f_1608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1608,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u8vector-ref */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1605,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#check-inexact-interval */
static void C_ccall f_1584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1584,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_number_2(t2,t5);
t7=(C_word)C_i_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_i_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm: 98   ##sys#error */
t9=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,lf[6],t2,t3,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* ##sys#check-exact-interval */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1569,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_exact_2(t2,t5);
t7=(C_word)C_fixnum_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm: 92   ##sys#error */
t9=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t9+1)))(7,t9,t1,t5,lf[4],t2,t3,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[295] = {
{"toplevel:srfi_4_scm",(void*)C_srfi_4_toplevel},
{"f_1672:srfi_4_scm",(void*)f_1672},
{"f_1676:srfi_4_scm",(void*)f_1676},
{"f_1680:srfi_4_scm",(void*)f_1680},
{"f_1684:srfi_4_scm",(void*)f_1684},
{"f_1688:srfi_4_scm",(void*)f_1688},
{"f_1692:srfi_4_scm",(void*)f_1692},
{"f_1696:srfi_4_scm",(void*)f_1696},
{"f_1700:srfi_4_scm",(void*)f_1700},
{"f_1848:srfi_4_scm",(void*)f_1848},
{"f_1852:srfi_4_scm",(void*)f_1852},
{"f_1856:srfi_4_scm",(void*)f_1856},
{"f_1860:srfi_4_scm",(void*)f_1860},
{"f_1872:srfi_4_scm",(void*)f_1872},
{"f_1876:srfi_4_scm",(void*)f_1876},
{"f_4071:srfi_4_scm",(void*)f_4071},
{"f_1880:srfi_4_scm",(void*)f_1880},
{"f_4067:srfi_4_scm",(void*)f_4067},
{"f_1884:srfi_4_scm",(void*)f_1884},
{"f_4063:srfi_4_scm",(void*)f_4063},
{"f_1888:srfi_4_scm",(void*)f_1888},
{"f_4059:srfi_4_scm",(void*)f_4059},
{"f_1892:srfi_4_scm",(void*)f_1892},
{"f_4055:srfi_4_scm",(void*)f_4055},
{"f_1896:srfi_4_scm",(void*)f_1896},
{"f_4051:srfi_4_scm",(void*)f_4051},
{"f_1900:srfi_4_scm",(void*)f_1900},
{"f_4047:srfi_4_scm",(void*)f_4047},
{"f_1904:srfi_4_scm",(void*)f_1904},
{"f_4043:srfi_4_scm",(void*)f_4043},
{"f_1908:srfi_4_scm",(void*)f_1908},
{"f_2974:srfi_4_scm",(void*)f_2974},
{"f_2978:srfi_4_scm",(void*)f_2978},
{"f_2982:srfi_4_scm",(void*)f_2982},
{"f_2986:srfi_4_scm",(void*)f_2986},
{"f_2990:srfi_4_scm",(void*)f_2990},
{"f_2994:srfi_4_scm",(void*)f_2994},
{"f_2998:srfi_4_scm",(void*)f_2998},
{"f_3002:srfi_4_scm",(void*)f_3002},
{"f_3089:srfi_4_scm",(void*)f_3089},
{"f_3093:srfi_4_scm",(void*)f_3093},
{"f_3097:srfi_4_scm",(void*)f_3097},
{"f_3101:srfi_4_scm",(void*)f_3101},
{"f_3105:srfi_4_scm",(void*)f_3105},
{"f_3109:srfi_4_scm",(void*)f_3109},
{"f_3113:srfi_4_scm",(void*)f_3113},
{"f_3117:srfi_4_scm",(void*)f_3117},
{"f_3259:srfi_4_scm",(void*)f_3259},
{"f_3263:srfi_4_scm",(void*)f_3263},
{"f_3267:srfi_4_scm",(void*)f_3267},
{"f_3271:srfi_4_scm",(void*)f_3271},
{"f_3275:srfi_4_scm",(void*)f_3275},
{"f_3279:srfi_4_scm",(void*)f_3279},
{"f_3283:srfi_4_scm",(void*)f_3283},
{"f_3287:srfi_4_scm",(void*)f_3287},
{"f_3291:srfi_4_scm",(void*)f_3291},
{"f_3295:srfi_4_scm",(void*)f_3295},
{"f_3299:srfi_4_scm",(void*)f_3299},
{"f_3303:srfi_4_scm",(void*)f_3303},
{"f_3307:srfi_4_scm",(void*)f_3307},
{"f_3311:srfi_4_scm",(void*)f_3311},
{"f_3315:srfi_4_scm",(void*)f_3315},
{"f_3319:srfi_4_scm",(void*)f_3319},
{"f_3323:srfi_4_scm",(void*)f_3323},
{"f_3327:srfi_4_scm",(void*)f_3327},
{"f_3331:srfi_4_scm",(void*)f_3331},
{"f_3335:srfi_4_scm",(void*)f_3335},
{"f_3339:srfi_4_scm",(void*)f_3339},
{"f_3343:srfi_4_scm",(void*)f_3343},
{"f_3347:srfi_4_scm",(void*)f_3347},
{"f_3351:srfi_4_scm",(void*)f_3351},
{"f_3355:srfi_4_scm",(void*)f_3355},
{"f_3359:srfi_4_scm",(void*)f_3359},
{"f_3363:srfi_4_scm",(void*)f_3363},
{"f_3367:srfi_4_scm",(void*)f_3367},
{"f_3371:srfi_4_scm",(void*)f_3371},
{"f_3375:srfi_4_scm",(void*)f_3375},
{"f_3379:srfi_4_scm",(void*)f_3379},
{"f_3383:srfi_4_scm",(void*)f_3383},
{"f_4039:srfi_4_scm",(void*)f_4039},
{"f_3921:srfi_4_scm",(void*)f_3921},
{"f_3990:srfi_4_scm",(void*)f_3990},
{"f_3985:srfi_4_scm",(void*)f_3985},
{"f_3923:srfi_4_scm",(void*)f_3923},
{"f_3927:srfi_4_scm",(void*)f_3927},
{"f_3954:srfi_4_scm",(void*)f_3954},
{"f_3959:srfi_4_scm",(void*)f_3959},
{"f_3963:srfi_4_scm",(void*)f_3963},
{"f_3981:srfi_4_scm",(void*)f_3981},
{"f_3972:srfi_4_scm",(void*)f_3972},
{"f_3936:srfi_4_scm",(void*)f_3936},
{"f_3939:srfi_4_scm",(void*)f_3939},
{"f_3912:srfi_4_scm",(void*)f_3912},
{"f_3920:srfi_4_scm",(void*)f_3920},
{"f_3811:srfi_4_scm",(void*)f_3811},
{"f_3863:srfi_4_scm",(void*)f_3863},
{"f_3858:srfi_4_scm",(void*)f_3858},
{"f_3813:srfi_4_scm",(void*)f_3813},
{"f_3817:srfi_4_scm",(void*)f_3817},
{"f_3829:srfi_4_scm",(void*)f_3829},
{"f_3695:srfi_4_scm",(void*)f_3695},
{"f_3748:srfi_4_scm",(void*)f_3748},
{"f_3743:srfi_4_scm",(void*)f_3743},
{"f_3734:srfi_4_scm",(void*)f_3734},
{"f_3742:srfi_4_scm",(void*)f_3742},
{"f_3697:srfi_4_scm",(void*)f_3697},
{"f_3704:srfi_4_scm",(void*)f_3704},
{"f_3712:srfi_4_scm",(void*)f_3712},
{"f_3722:srfi_4_scm",(void*)f_3722},
{"f_3689:srfi_4_scm",(void*)f_3689},
{"f_3683:srfi_4_scm",(void*)f_3683},
{"f_3677:srfi_4_scm",(void*)f_3677},
{"f_3671:srfi_4_scm",(void*)f_3671},
{"f_3665:srfi_4_scm",(void*)f_3665},
{"f_3659:srfi_4_scm",(void*)f_3659},
{"f_3653:srfi_4_scm",(void*)f_3653},
{"f_3647:srfi_4_scm",(void*)f_3647},
{"f_3604:srfi_4_scm",(void*)f_3604},
{"f_3617:srfi_4_scm",(void*)f_3617},
{"f_3620:srfi_4_scm",(void*)f_3620},
{"f_3626:srfi_4_scm",(void*)f_3626},
{"f_3444:srfi_4_scm",(void*)f_3444},
{"f_3454:srfi_4_scm",(void*)f_3454},
{"f_3457:srfi_4_scm",(void*)f_3457},
{"f_3464:srfi_4_scm",(void*)f_3464},
{"f_3388:srfi_4_scm",(void*)f_3388},
{"f_3398:srfi_4_scm",(void*)f_3398},
{"f_3423:srfi_4_scm",(void*)f_3423},
{"f_3225:srfi_4_scm",(void*)f_3225},
{"f_3227:srfi_4_scm",(void*)f_3227},
{"f_3237:srfi_4_scm",(void*)f_3237},
{"f_3196:srfi_4_scm",(void*)f_3196},
{"f_3198:srfi_4_scm",(void*)f_3198},
{"f_3178:srfi_4_scm",(void*)f_3178},
{"f_3180:srfi_4_scm",(void*)f_3180},
{"f_3190:srfi_4_scm",(void*)f_3190},
{"f_3167:srfi_4_scm",(void*)f_3167},
{"f_3169:srfi_4_scm",(void*)f_3169},
{"f_3161:srfi_4_scm",(void*)f_3161},
{"f_3155:srfi_4_scm",(void*)f_3155},
{"f_3149:srfi_4_scm",(void*)f_3149},
{"f_3143:srfi_4_scm",(void*)f_3143},
{"f_3137:srfi_4_scm",(void*)f_3137},
{"f_3131:srfi_4_scm",(void*)f_3131},
{"f_3125:srfi_4_scm",(void*)f_3125},
{"f_3119:srfi_4_scm",(void*)f_3119},
{"f_3052:srfi_4_scm",(void*)f_3052},
{"f_3054:srfi_4_scm",(void*)f_3054},
{"f_3058:srfi_4_scm",(void*)f_3058},
{"f_3063:srfi_4_scm",(void*)f_3063},
{"f_3077:srfi_4_scm",(void*)f_3077},
{"f_3081:srfi_4_scm",(void*)f_3081},
{"f_3046:srfi_4_scm",(void*)f_3046},
{"f_3040:srfi_4_scm",(void*)f_3040},
{"f_3034:srfi_4_scm",(void*)f_3034},
{"f_3028:srfi_4_scm",(void*)f_3028},
{"f_3022:srfi_4_scm",(void*)f_3022},
{"f_3016:srfi_4_scm",(void*)f_3016},
{"f_3010:srfi_4_scm",(void*)f_3010},
{"f_3004:srfi_4_scm",(void*)f_3004},
{"f_2934:srfi_4_scm",(void*)f_2934},
{"f_2936:srfi_4_scm",(void*)f_2936},
{"f_2946:srfi_4_scm",(void*)f_2946},
{"f_2951:srfi_4_scm",(void*)f_2951},
{"f_2958:srfi_4_scm",(void*)f_2958},
{"f_2807:srfi_4_scm",(void*)f_2807},
{"f_2871:srfi_4_scm",(void*)f_2871},
{"f_2866:srfi_4_scm",(void*)f_2866},
{"f_2861:srfi_4_scm",(void*)f_2861},
{"f_2809:srfi_4_scm",(void*)f_2809},
{"f_2860:srfi_4_scm",(void*)f_2860},
{"f_2819:srfi_4_scm",(void*)f_2819},
{"f_2850:srfi_4_scm",(void*)f_2850},
{"f_2831:srfi_4_scm",(void*)f_2831},
{"f_2836:srfi_4_scm",(void*)f_2836},
{"f_2843:srfi_4_scm",(void*)f_2843},
{"f_2680:srfi_4_scm",(void*)f_2680},
{"f_2744:srfi_4_scm",(void*)f_2744},
{"f_2739:srfi_4_scm",(void*)f_2739},
{"f_2734:srfi_4_scm",(void*)f_2734},
{"f_2682:srfi_4_scm",(void*)f_2682},
{"f_2733:srfi_4_scm",(void*)f_2733},
{"f_2692:srfi_4_scm",(void*)f_2692},
{"f_2723:srfi_4_scm",(void*)f_2723},
{"f_2704:srfi_4_scm",(void*)f_2704},
{"f_2709:srfi_4_scm",(void*)f_2709},
{"f_2716:srfi_4_scm",(void*)f_2716},
{"f_2560:srfi_4_scm",(void*)f_2560},
{"f_2617:srfi_4_scm",(void*)f_2617},
{"f_2612:srfi_4_scm",(void*)f_2612},
{"f_2607:srfi_4_scm",(void*)f_2607},
{"f_2562:srfi_4_scm",(void*)f_2562},
{"f_2606:srfi_4_scm",(void*)f_2606},
{"f_2572:srfi_4_scm",(void*)f_2572},
{"f_2586:srfi_4_scm",(void*)f_2586},
{"f_2440:srfi_4_scm",(void*)f_2440},
{"f_2497:srfi_4_scm",(void*)f_2497},
{"f_2492:srfi_4_scm",(void*)f_2492},
{"f_2487:srfi_4_scm",(void*)f_2487},
{"f_2442:srfi_4_scm",(void*)f_2442},
{"f_2486:srfi_4_scm",(void*)f_2486},
{"f_2452:srfi_4_scm",(void*)f_2452},
{"f_2466:srfi_4_scm",(void*)f_2466},
{"f_2320:srfi_4_scm",(void*)f_2320},
{"f_2377:srfi_4_scm",(void*)f_2377},
{"f_2372:srfi_4_scm",(void*)f_2372},
{"f_2367:srfi_4_scm",(void*)f_2367},
{"f_2322:srfi_4_scm",(void*)f_2322},
{"f_2366:srfi_4_scm",(void*)f_2366},
{"f_2332:srfi_4_scm",(void*)f_2332},
{"f_2341:srfi_4_scm",(void*)f_2341},
{"f_2346:srfi_4_scm",(void*)f_2346},
{"f_2353:srfi_4_scm",(void*)f_2353},
{"f_2200:srfi_4_scm",(void*)f_2200},
{"f_2257:srfi_4_scm",(void*)f_2257},
{"f_2252:srfi_4_scm",(void*)f_2252},
{"f_2247:srfi_4_scm",(void*)f_2247},
{"f_2202:srfi_4_scm",(void*)f_2202},
{"f_2246:srfi_4_scm",(void*)f_2246},
{"f_2212:srfi_4_scm",(void*)f_2212},
{"f_2221:srfi_4_scm",(void*)f_2221},
{"f_2226:srfi_4_scm",(void*)f_2226},
{"f_2233:srfi_4_scm",(void*)f_2233},
{"f_2080:srfi_4_scm",(void*)f_2080},
{"f_2137:srfi_4_scm",(void*)f_2137},
{"f_2132:srfi_4_scm",(void*)f_2132},
{"f_2127:srfi_4_scm",(void*)f_2127},
{"f_2082:srfi_4_scm",(void*)f_2082},
{"f_2126:srfi_4_scm",(void*)f_2126},
{"f_2092:srfi_4_scm",(void*)f_2092},
{"f_2101:srfi_4_scm",(void*)f_2101},
{"f_2106:srfi_4_scm",(void*)f_2106},
{"f_2113:srfi_4_scm",(void*)f_2113},
{"f_1960:srfi_4_scm",(void*)f_1960},
{"f_2017:srfi_4_scm",(void*)f_2017},
{"f_2012:srfi_4_scm",(void*)f_2012},
{"f_2007:srfi_4_scm",(void*)f_2007},
{"f_1962:srfi_4_scm",(void*)f_1962},
{"f_2006:srfi_4_scm",(void*)f_2006},
{"f_1972:srfi_4_scm",(void*)f_1972},
{"f_1981:srfi_4_scm",(void*)f_1981},
{"f_1986:srfi_4_scm",(void*)f_1986},
{"f_1993:srfi_4_scm",(void*)f_1993},
{"f_1935:srfi_4_scm",(void*)f_1935},
{"f_1942:srfi_4_scm",(void*)f_1942},
{"f_1917:srfi_4_scm",(void*)f_1917},
{"f_1933:srfi_4_scm",(void*)f_1933},
{"f_1915:srfi_4_scm",(void*)f_1915},
{"f_1761:srfi_4_scm",(void*)f_1761},
{"f_1765:srfi_4_scm",(void*)f_1765},
{"f_1768:srfi_4_scm",(void*)f_1768},
{"f_1771:srfi_4_scm",(void*)f_1771},
{"f_1788:srfi_4_scm",(void*)f_1788},
{"f_1792:srfi_4_scm",(void*)f_1792},
{"f_1795:srfi_4_scm",(void*)f_1795},
{"f_1798:srfi_4_scm",(void*)f_1798},
{"f_1822:srfi_4_scm",(void*)f_1822},
{"f_1824:srfi_4_scm",(void*)f_1824},
{"f_1828:srfi_4_scm",(void*)f_1828},
{"f_1834:srfi_4_scm",(void*)f_1834},
{"f_1841:srfi_4_scm",(void*)f_1841},
{"f_1733:srfi_4_scm",(void*)f_1733},
{"f_1735:srfi_4_scm",(void*)f_1735},
{"f_1739:srfi_4_scm",(void*)f_1739},
{"f_1745:srfi_4_scm",(void*)f_1745},
{"f_1748:srfi_4_scm",(void*)f_1748},
{"f_1716:srfi_4_scm",(void*)f_1716},
{"f_1718:srfi_4_scm",(void*)f_1718},
{"f_1722:srfi_4_scm",(void*)f_1722},
{"f_1728:srfi_4_scm",(void*)f_1728},
{"f_1702:srfi_4_scm",(void*)f_1702},
{"f_1704:srfi_4_scm",(void*)f_1704},
{"f_1708:srfi_4_scm",(void*)f_1708},
{"f_1711:srfi_4_scm",(void*)f_1711},
{"f_1659:srfi_4_scm",(void*)f_1659},
{"f_1661:srfi_4_scm",(void*)f_1661},
{"f_1656:srfi_4_scm",(void*)f_1656},
{"f_1653:srfi_4_scm",(void*)f_1653},
{"f_1650:srfi_4_scm",(void*)f_1650},
{"f_1647:srfi_4_scm",(void*)f_1647},
{"f_1644:srfi_4_scm",(void*)f_1644},
{"f_1641:srfi_4_scm",(void*)f_1641},
{"f_1638:srfi_4_scm",(void*)f_1638},
{"f_1635:srfi_4_scm",(void*)f_1635},
{"f_1629:srfi_4_scm",(void*)f_1629},
{"f_1623:srfi_4_scm",(void*)f_1623},
{"f_1620:srfi_4_scm",(void*)f_1620},
{"f_1617:srfi_4_scm",(void*)f_1617},
{"f_1614:srfi_4_scm",(void*)f_1614},
{"f_1611:srfi_4_scm",(void*)f_1611},
{"f_1608:srfi_4_scm",(void*)f_1608},
{"f_1605:srfi_4_scm",(void*)f_1605},
{"f_1584:srfi_4_scm",(void*)f_1584},
{"f_1569:srfi_4_scm",(void*)f_1569},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
