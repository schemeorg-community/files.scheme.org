/* Generated from scrutinizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:29
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: scrutinizer.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -extend private-namespace.scm -output-file scrutinizer.c
   unit: scrutinizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[162];
static double C_possibly_force_alignment;


C_noret_decl(C_scrutinizer_toplevel)
C_externexport void C_ccall C_scrutinizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1304)
static void C_ccall f_1304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1316)
static void C_ccall f_1316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1319)
static void C_ccall f_1319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4758)
static void C_ccall f_4758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4713)
static void C_ccall f_4713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4725)
static void C_ccall f_4725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4737)
static void C_fcall f_4737(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1333)
static void C_ccall f_1333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4154)
static void C_fcall f_4154(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4612)
static void C_ccall f_4612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4650)
static void C_ccall f_4650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4632)
static void C_ccall f_4632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4578)
static void C_ccall f_4578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4552)
static void C_fcall f_4552(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4539)
static void C_fcall f_4539(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4495)
static void C_ccall f_4495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4474)
static void C_ccall f_4474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4455)
static void C_ccall f_4455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_fcall f_4360(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4420)
static void C_ccall f_4420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4404)
static void C_ccall f_4404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4408)
static void C_ccall f_4408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4381)
static void C_ccall f_4381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4396)
static void C_ccall f_4396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4378)
static void C_ccall f_4378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4249)
static void C_fcall f_4249(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4276)
static void C_fcall f_4276(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4183)
static void C_fcall f_4183(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3579)
static void C_fcall f_3579(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3809)
static void C_ccall f_3809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3801)
static void C_ccall f_3801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3797)
static void C_ccall f_3797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3776)
static void C_fcall f_3776(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3787)
static void C_ccall f_3787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3638)
static void C_ccall f_3638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_fcall f_3683(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3667)
static void C_ccall f_3667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4046)
static void C_ccall f_4046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4093)
static void C_fcall f_4093(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4056)
static void C_fcall f_4056(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3582)
static void C_fcall f_3582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3597)
static void C_fcall f_3597(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3594)
static void C_ccall f_3594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3861)
static void C_fcall f_3861(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3993)
static void C_fcall f_3993(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3896)
static void C_fcall f_3896(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3957)
static void C_fcall f_3957(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3926)
static void C_fcall f_3926(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static void C_fcall f_3365(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3407)
static void C_ccall f_3407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3400)
static void C_ccall f_3400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3397)
static void C_ccall f_3397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_fcall f_2970(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_fcall f_2760(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2825)
static void C_fcall f_2825(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_fcall f_2766(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2798)
static void C_fcall f_2798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2488)
static void C_fcall f_2488(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2575)
static void C_fcall f_2575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2594)
static void C_fcall f_2594(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2631)
static void C_fcall f_2631(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2691)
static void C_ccall f_2691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2479)
static void C_fcall f_2479(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2413)
static void C_fcall f_2413(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2211)
static void C_fcall f_2211(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_fcall f_2307(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2326)
static void C_ccall f_2326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_fcall f_2246(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1751)
static void C_fcall f_1751(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1757)
static void C_ccall f_1757(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2144)
static void C_ccall f_2144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2112)
static void C_ccall f_2112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2048)
static void C_fcall f_2048(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_fcall f_1948(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_fcall f_2149(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_fcall f_2172(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static C_word C_fcall f_2189(C_word t0);
C_noret_decl(f_3025)
static void C_fcall f_3025(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3132)
static void C_fcall f_3132(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3267)
static void C_ccall f_3267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_fcall f_3148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_fcall f_3153(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3819)
static void C_ccall f_3819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1714)
static void C_fcall f_1714(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1692)
static void C_fcall f_1692(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1712)
static void C_ccall f_1712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_fcall f_1617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1551)
static void C_fcall f_1551(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_ccall f_1558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_fcall f_3559(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3505)
static void C_fcall f_3505(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3514)
static void C_fcall f_3514(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1526)
static void C_fcall f_1526(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1463)
static void C_fcall f_1463(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1470)
static void C_fcall f_1470(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1438)
static void C_fcall f_1438(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1442)
static void C_ccall f_1442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3413)
static void C_fcall f_3413(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3423)
static void C_fcall f_3423(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3465)
static void C_fcall f_3465(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_fcall f_3426(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;

C_noret_decl(trf_4737)
static void C_fcall trf_4737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4737(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4737(t0,t1);}

C_noret_decl(trf_4154)
static void C_fcall trf_4154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4154(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4154(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4552)
static void C_fcall trf_4552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4552(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4552(t0,t1);}

C_noret_decl(trf_4539)
static void C_fcall trf_4539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4539(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4539(t0,t1);}

C_noret_decl(trf_4360)
static void C_fcall trf_4360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4360(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4360(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4249)
static void C_fcall trf_4249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4249(t0,t1);}

C_noret_decl(trf_4276)
static void C_fcall trf_4276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4276(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4276(t0,t1);}

C_noret_decl(trf_4183)
static void C_fcall trf_4183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4183(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4183(t0,t1);}

C_noret_decl(trf_3579)
static void C_fcall trf_3579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3579(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3579(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3776)
static void C_fcall trf_3776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3776(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3776(t0,t1);}

C_noret_decl(trf_3683)
static void C_fcall trf_3683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3683(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3683(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4093)
static void C_fcall trf_4093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4093(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4093(t0,t1);}

C_noret_decl(trf_4056)
static void C_fcall trf_4056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4056(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4056(t0,t1,t2);}

C_noret_decl(trf_3582)
static void C_fcall trf_3582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3582(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3582(t0,t1);}

C_noret_decl(trf_3597)
static void C_fcall trf_3597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3597(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3597(t0,t1);}

C_noret_decl(trf_3861)
static void C_fcall trf_3861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3861(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3861(t0,t1,t2,t3);}

C_noret_decl(trf_3993)
static void C_fcall trf_3993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3993(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3993(t0,t1);}

C_noret_decl(trf_3896)
static void C_fcall trf_3896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3896(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3896(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3957)
static void C_fcall trf_3957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3957(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3957(t0,t1);}

C_noret_decl(trf_3926)
static void C_fcall trf_3926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3926(t0,t1);}

C_noret_decl(trf_3365)
static void C_fcall trf_3365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3365(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3365(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2970)
static void C_fcall trf_2970(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2970(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2970(t0,t1,t2,t3);}

C_noret_decl(trf_2760)
static void C_fcall trf_2760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2760(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2760(t0,t1,t2,t3);}

C_noret_decl(trf_2825)
static void C_fcall trf_2825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2825(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2825(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2766)
static void C_fcall trf_2766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2766(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2766(t0,t1,t2,t3);}

C_noret_decl(trf_2798)
static void C_fcall trf_2798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2798(t0,t1);}

C_noret_decl(trf_2488)
static void C_fcall trf_2488(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2488(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2488(t0,t1,t2,t3);}

C_noret_decl(trf_2575)
static void C_fcall trf_2575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2575(t0,t1);}

C_noret_decl(trf_2594)
static void C_fcall trf_2594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2594(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2594(t0,t1);}

C_noret_decl(trf_2631)
static void C_fcall trf_2631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2631(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2631(t0,t1);}

C_noret_decl(trf_2479)
static void C_fcall trf_2479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2479(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2479(t0,t1,t2,t3);}

C_noret_decl(trf_2413)
static void C_fcall trf_2413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2413(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2413(t0,t1,t2,t3);}

C_noret_decl(trf_2211)
static void C_fcall trf_2211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2211(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2211(t0,t1,t2,t3);}

C_noret_decl(trf_2307)
static void C_fcall trf_2307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2307(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2307(t0,t1);}

C_noret_decl(trf_2246)
static void C_fcall trf_2246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2246(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2246(t0,t1);}

C_noret_decl(trf_1751)
static void C_fcall trf_1751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1751(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1751(t0,t1,t2);}

C_noret_decl(trf_2048)
static void C_fcall trf_2048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2048(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2048(t0,t1);}

C_noret_decl(trf_1948)
static void C_fcall trf_1948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1948(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1948(t0,t1,t2,t3);}

C_noret_decl(trf_2149)
static void C_fcall trf_2149(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2149(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2149(t0,t1);}

C_noret_decl(trf_2172)
static void C_fcall trf_2172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2172(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2172(t0,t1);}

C_noret_decl(trf_3025)
static void C_fcall trf_3025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3025(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3025(t0,t1,t2,t3);}

C_noret_decl(trf_3132)
static void C_fcall trf_3132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3132(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3132(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3148)
static void C_fcall trf_3148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3148(t0,t1);}

C_noret_decl(trf_3153)
static void C_fcall trf_3153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3153(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3153(t0,t1,t2,t3);}

C_noret_decl(trf_1714)
static void C_fcall trf_1714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1714(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1714(t0,t1,t2);}

C_noret_decl(trf_1692)
static void C_fcall trf_1692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1692(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1692(t0,t1,t2);}

C_noret_decl(trf_1617)
static void C_fcall trf_1617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1617(t0,t1);}

C_noret_decl(trf_1551)
static void C_fcall trf_1551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1551(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1551(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3559)
static void C_fcall trf_3559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3559(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3559(t0,t1,t2);}

C_noret_decl(trf_3505)
static void C_fcall trf_3505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3505(t0,t1);}

C_noret_decl(trf_3514)
static void C_fcall trf_3514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3514(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3514(t0,t1,t2,t3);}

C_noret_decl(trf_1526)
static void C_fcall trf_1526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1526(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1526(t0,t1);}

C_noret_decl(trf_1463)
static void C_fcall trf_1463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1463(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1463(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1470)
static void C_fcall trf_1470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1470(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1470(t0,t1);}

C_noret_decl(trf_1438)
static void C_fcall trf_1438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1438(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1438(t0,t1,t2,t3);}

C_noret_decl(trf_3413)
static void C_fcall trf_3413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3413(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3413(t0,t1,t2,t3);}

C_noret_decl(trf_3423)
static void C_fcall trf_3423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3423(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3423(t0,t1,t2);}

C_noret_decl(trf_3465)
static void C_fcall trf_3465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3465(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3465(t0,t1,t2);}

C_noret_decl(trf_3426)
static void C_fcall trf_3426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3426(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3426(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_scrutinizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_scrutinizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("scrutinizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1443)){
C_save(t1);
C_rereclaim2(1443*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,162);
lf[0]=C_h_intern(&lf[0],1,"d");
lf[1]=C_h_intern(&lf[1],6,"printf");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\000\014[debug] ~\077~%");
lf[3]=C_h_intern(&lf[3],19,"\010compilerscrutinize");
lf[4]=C_h_intern(&lf[4],7,"sprintf");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\016procedure `~a\047");
lf[6]=C_h_intern(&lf[6],18,"\010compilerreal-name");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\021unknown procedure");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\017at toplevel:\012  ");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\022in toplevel ~a:\012  ");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\021in local ~a,\012  ~a");
lf[11]=C_h_intern(&lf[11],25,"\010compilercompiler-warning");
lf[12]=C_h_intern(&lf[12],8,"scrutiny");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[14]=C_h_intern(&lf[14],10,"deprecated");
lf[15]=C_h_intern(&lf[15],1,"*");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000*use of deprecated toplevel identifier `~a\047");
lf[17]=C_h_intern(&lf[17],7,"\003sysget");
lf[18]=C_h_intern(&lf[18],9,"\004coretype");
lf[19]=C_h_intern(&lf[19],9,"undefined");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\0004access to variable `~a\047 which has an undefined value");
lf[21]=C_h_intern(&lf[21],18,"\004coredeclared-type");
lf[22]=C_h_intern(&lf[22],12,"\010compilerget");
lf[23]=C_h_intern(&lf[23],8,"assigned");
lf[24]=C_h_intern(&lf[24],5,"every");
lf[25]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\011undefined\376\003\000\000\002\376\001\000\000\010noreturn\376\377\016");
lf[26]=C_h_intern(&lf[26],2,"or");
lf[27]=C_h_intern(&lf[27],3,"...");
lf[28]=C_h_intern(&lf[28],7,"\003sysmap");
lf[29]=C_h_intern(&lf[29],4,"take");
lf[30]=C_h_intern(&lf[30],3,"min");
lf[31]=C_h_intern(&lf[31],30,"\010compilerbuild-expression-tree");
lf[32]=C_h_intern(&lf[32],12,"string-chomp");
lf[33]=C_h_intern(&lf[33],2,"pp");
lf[34]=C_h_intern(&lf[34],21,"with-output-to-string");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000mexpected value of type boolean in conditional but were given a value of typ"
"e `~a\047 which is always true:~%~%~a");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\010anything");
lf[37]=C_h_intern(&lf[37],4,"char");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\011character");
lf[39]=C_h_intern(&lf[39],14,"symbol->string");
lf[40]=C_h_intern(&lf[40],9,"procedure");
lf[41]=C_h_intern(&lf[41],8,"->string");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000 a procedure with ~a returning ~a");
lf[43]=C_h_intern(&lf[43],18,"string-intersperse");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\004 OR ");
lf[45]=C_h_intern(&lf[45],6,"struct");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\026a structure of type ~a");
lf[47]=C_h_intern(&lf[47],13,"\010compilerbomb");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid type: ~a");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid type: ~a");
lf[50]=C_h_intern(&lf[50],3,"len");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\016zero arguments");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\032~a argument~a of type~a ~a");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\033an unknown number of values");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\013zero values");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\027~a value~a of type~a ~a");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\011undefined\376\377\016");
lf[59]=C_h_intern(&lf[59],4,"list");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004null\376\003\000\000\002\376\001\000\000\004pair\376\377\016");
lf[61]=C_h_intern(&lf[61],6,"number");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\005float\376\377\016");
lf[63]=C_h_intern(&lf[63],10,"#!optional");
lf[64]=C_h_intern(&lf[64],6,"#!rest");
lf[65]=C_h_intern(&lf[65],6,"values");
lf[66]=C_h_intern(&lf[66],19,"\003sysundefined-value");
lf[67]=C_h_intern(&lf[67],6,"append");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[69]=C_h_intern(&lf[69],6,"reduce");
lf[70]=C_h_intern(&lf[70],3,"any");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\377\016");
lf[72]=C_h_intern(&lf[72],10,"\003sysappend");
lf[73]=C_h_intern(&lf[73],7,"reverse");
lf[74]=C_h_intern(&lf[74],10,"append-map");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[76]=C_h_intern(&lf[76],7,"call/cc");
lf[77]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\003\000\000\002\376\001\000\000\012#!optional\376\377\016");
lf[78]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[79]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[80]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[81]=C_h_intern(&lf[81],8,"noreturn");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006number\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\005float\376\377\016");
lf[83]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006number\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\005float\376\377\016");
lf[84]=C_h_intern(&lf[84],4,"pair");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004pair\376\003\000\000\002\376\001\000\000\004list\376\377\016");
lf[86]=C_h_intern(&lf[86],4,"null");
lf[87]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004null\376\003\000\000\002\376\001\000\000\004list\376\377\016");
lf[88]=C_h_intern(&lf[88],5,"break");
lf[89]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\003\000\000\002\376\001\000\000\012#!optional\376\377\016");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\003\000\000\002\376\001\000\000\012#!optional\376\377\016");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\0008expected ~a a single result, but were given zero results");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\0007expected ~a a single result, but were given ~a result~a");
lf[93]=C_h_intern(&lf[93],4,"cons");
lf[94]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[95]=C_h_intern(&lf[95],9,"make-list");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\024not a procedure type");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\033in procedure call to `~s\047~a");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\012 (line ~a)");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[100]=C_h_intern(&lf[100],26,"\010compilersource-info->line");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[102]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\030not a procedure type: ~a");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000Oexpected argument #~a of type `~a\047 ~a, but where given an argument of type "
"`~a\047");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\0008expected ~a ~a argument~a, but where given ~a argument~a");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000Eexpected ~a a value of type `~a\047, but were given a value of type `~a\047");
lf[107]=C_h_intern(&lf[107],5,"quote");
lf[108]=C_h_intern(&lf[108],6,"string");
lf[109]=C_h_intern(&lf[109],6,"symbol");
lf[110]=C_h_intern(&lf[110],6,"fixnum");
lf[111]=C_h_intern(&lf[111],5,"float");
lf[112]=C_h_intern(&lf[112],7,"boolean");
lf[113]=C_h_intern(&lf[113],3,"eof");
lf[114]=C_h_intern(&lf[114],6,"vector");
lf[115]=C_h_intern(&lf[115],22,"\003sysgeneric-structure\077");
lf[116]=C_h_intern(&lf[116],14,"\004coreundefined");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\377\016");
lf[118]=C_h_intern(&lf[118],9,"\004coreproc");
lf[119]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[120]=C_h_intern(&lf[120],15,"\004coreglobal-ref");
lf[121]=C_h_intern(&lf[121],13,"\004corevariable");
lf[122]=C_h_intern(&lf[122],2,"if");
lf[123]=C_h_intern(&lf[123],3,"map");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000Ibranches in conditional expression differ in the number of results:~%~%~a");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\016in conditional");
lf[126]=C_h_intern(&lf[126],3,"let");
lf[127]=C_h_intern(&lf[127],10,"alist-cons");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\030in `let\047 binding of `~a\047");
lf[129]=C_h_intern(&lf[129],11,"\004corelambda");
lf[130]=C_h_intern(&lf[130],6,"lambda");
lf[131]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[132]=C_h_intern(&lf[132],7,"butlast");
lf[133]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[134]=C_h_intern(&lf[134],30,"\010compilerdecompose-lambda-list");
lf[135]=C_h_intern(&lf[135],4,"set!");
lf[136]=C_h_intern(&lf[136],9,"\004coreset!");
lf[137]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011undefined\376\377\016");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\134assignment of value of type `~a\047 to toplevel variable `~a\047 does not match d"
"eclared type `~a\047");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\025in assignment to `~a\047");
lf[140]=C_h_intern(&lf[140],14,"\004coreprimitive");
lf[141]=C_h_intern(&lf[141],15,"\004coreinline_ref");
lf[142]=C_h_intern(&lf[142],9,"\004corecall");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\034in ~a of procedure call `~s\047");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\021operator position");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\014argument #~a");
lf[146]=C_h_intern(&lf[146],4,"iota");
lf[147]=C_h_intern(&lf[147],11,"\004coreswitch");
lf[148]=C_h_intern(&lf[148],9,"\004corecond");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\031unexpected node class: ~a");
lf[150]=C_h_intern(&lf[150],12,"\003sysfor-each");
lf[151]=C_h_intern(&lf[151],27,"\010compilerload-type-database");
lf[152]=C_h_intern(&lf[152],8,"\003sysput!");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000Ytype-definition `~a\047 for toplevel binding `~a\047 conflicts with previously lo"
"aded type `~a\047");
lf[154]=C_h_intern(&lf[154],9,"read-file");
lf[155]=C_h_intern(&lf[155],21,"\010compilerverbose-mode");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\036loading type database ~a ...~%");
lf[157]=C_h_intern(&lf[157],12,"file-exists\077");
lf[158]=C_h_intern(&lf[158],13,"make-pathname");
lf[159]=C_h_intern(&lf[159],15,"repository-path");
lf[160]=C_h_intern(&lf[160],9,"\003syserror");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
C_register_lf2(lf,162,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1304,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1302 */
static void C_ccall f_1304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1307,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1305 in k1302 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1310,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1308 in k1305 in k1302 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1313,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1316,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1319,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1319,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! d ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1321,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! scrutinize ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1333,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[151]+1 /* (set! load-type-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4700,tmp=(C_word)a,a+=2,tmp));
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}

/* ##compiler#load-type-database in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4700(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4700r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4700r(t0,t1,t2,t3);}}

static void C_ccall f_4700r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4704,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* scrutinizer.scm: 613  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[159]))(2,*((C_word*)lf[159]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4704(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[161],t3);}}}

/* k4702 in ##compiler#load-type-database in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4707,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4758,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 614  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[158]))(4,*((C_word*)lf[158]+1),t3,t1,((C_word*)t0)[2]);}

/* k4756 in k4702 in ##compiler#load-type-database in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 614  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[157]))(3,*((C_word*)lf[157]+1),((C_word*)t0)[2],t1);}

/* k4705 in k4702 in ##compiler#load-type-database in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4707,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4713,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[155]))){
/* scrutinizer.scm: 616  printf */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,lf[156],t1);}
else{
t3=t2;
f_4713(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4711 in k4705 in k4702 in ##compiler#load-type-database in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4718,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4751,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 628  read-file */
((C_proc3)C_retrieve_symbol_proc(lf[154]))(3,*((C_word*)lf[154]+1),t3,((C_word*)t0)[2]);}

/* k4749 in k4711 in k4705 in k4702 in ##compiler#load-type-database in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4717 in k4711 in k4705 in k4702 in ##compiler#load-type-database in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4718,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4725,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 620  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[17]))(4,*((C_word*)lf[17]+1),t4,t3,lf[18]);}

/* k4723 in a4717 in k4711 in k4705 in k4702 in ##compiler#load-type-database in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4725,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4731,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4737,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t5=(C_word)C_i_equalp(t1,t2);
t6=t4;
f_4737(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_4737(t5,C_SCHEME_FALSE);}}

/* k4735 in k4723 in a4717 in k4711 in k4705 in k4702 in ##compiler#load-type-database in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_4737(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* scrutinizer.scm: 623  compiler-warning */
((C_proc7)C_retrieve_symbol_proc(lf[11]))(7,*((C_word*)lf[11]+1),((C_word*)t0)[5],lf[12],lf[153],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_4731(2,t2,C_SCHEME_UNDEFINED);}}

/* k4729 in k4723 in a4717 in k4711 in k4705 in k4702 in ##compiler#load-type-database in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 627  ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[152]))(5,*((C_word*)lf[152]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[18],((C_word*)t0)[2]);}

/* ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word ab[150],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1333,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3423,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3413,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1438,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1463,a[2]=t8,a[3]=t3,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1519,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3505,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3559,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1551,a[2]=t11,a[3]=t14,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1571,a[2]=t17,a[3]=t19,a[4]=t21,tmp=(C_word)a,a+=5,tmp));
t23=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1692,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t24=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1714,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3819,a[2]=t26,tmp=(C_word)a,a+=3,tmp));
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=t29,tmp=(C_word)a,a+=3,tmp));
t31=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2189,tmp=(C_word)a,a+=2,tmp);
t32=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2149,tmp=(C_word)a,a+=2,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_SCHEME_UNDEFINED;
t40=(*a=C_VECTOR_TYPE|1,a[1]=t39,tmp=(C_word)a,a+=2,tmp);
t41=C_set_block_item(t34,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1742,a[2]=t36,tmp=(C_word)a,a+=3,tmp));
t42=C_set_block_item(t36,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1751,a[2]=t26,a[3]=t29,a[4]=t32,a[5]=t38,a[6]=t40,a[7]=t34,tmp=(C_word)a,a+=8,tmp));
t43=C_set_block_item(t38,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2211,a[2]=t38,a[3]=t34,a[4]=t31,tmp=(C_word)a,a+=5,tmp));
t44=C_set_block_item(t40,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2413,a[2]=t34,a[3]=t40,tmp=(C_word)a,a+=4,tmp));
t45=C_SCHEME_UNDEFINED;
t46=(*a=C_VECTOR_TYPE|1,a[1]=t45,tmp=(C_word)a,a+=2,tmp);
t47=C_SCHEME_UNDEFINED;
t48=(*a=C_VECTOR_TYPE|1,a[1]=t47,tmp=(C_word)a,a+=2,tmp);
t49=C_SCHEME_UNDEFINED;
t50=(*a=C_VECTOR_TYPE|1,a[1]=t49,tmp=(C_word)a,a+=2,tmp);
t51=C_SCHEME_UNDEFINED;
t52=(*a=C_VECTOR_TYPE|1,a[1]=t51,tmp=(C_word)a,a+=2,tmp);
t53=C_set_block_item(t46,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2479,a[2]=t48,tmp=(C_word)a,a+=3,tmp));
t54=C_set_block_item(t48,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2488,a[2]=t32,a[3]=t50,a[4]=t52,a[5]=t46,tmp=(C_word)a,a+=6,tmp));
t55=C_set_block_item(t50,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2760,a[2]=t31,a[3]=t46,tmp=(C_word)a,a+=4,tmp));
t56=C_set_block_item(t52,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2970,a[2]=t46,a[3]=t52,tmp=(C_word)a,a+=4,tmp));
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3365,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t58=*((C_word*)lf[93]+1);
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3861,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
t60=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3579,a[2]=t26,a[3]=t46,a[4]=t7,a[5]=t59,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
t61=C_SCHEME_UNDEFINED;
t62=(*a=C_VECTOR_TYPE|1,a[1]=t61,tmp=(C_word)a,a+=2,tmp);
t63=C_set_block_item(t62,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4122,a[2]=t62,tmp=(C_word)a,a+=3,tmp));
t64=C_SCHEME_UNDEFINED;
t65=(*a=C_VECTOR_TYPE|1,a[1]=t64,tmp=(C_word)a,a+=2,tmp);
t66=C_set_block_item(t65,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4154,a[2]=t13,a[3]=t60,a[4]=t46,a[5]=t58,a[6]=t57,a[7]=t15,a[8]=t65,a[9]=t62,a[10]=t14,a[11]=t7,a[12]=t34,a[13]=t9,a[14]=t8,tmp=(C_word)a,a+=15,tmp));
t67=(C_word)C_slot(t2,C_fix(3));
t68=(C_word)C_i_car(t67);
/* scrutinizer.scm: 611  walk */
t69=((C_word*)t65)[1];
f_4154(t69,t1,t68,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_4154(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4154,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=C_retrieve(lf[66]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4170,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_eqp(t11,lf[107]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4183,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t16=(C_word)C_i_car(t9);
if(C_truep((C_word)C_i_stringp(t16))){
t17=t15;
f_4183(t17,lf[108]);}
else{
if(C_truep((C_word)C_i_symbolp(t16))){
t17=t15;
f_4183(t17,lf[109]);}
else{
if(C_truep((C_word)C_fixnump(t16))){
t17=t15;
f_4183(t17,lf[110]);}
else{
if(C_truep((C_word)C_i_flonump(t16))){
t17=t15;
f_4183(t17,lf[111]);}
else{
if(C_truep((C_word)C_i_numberp(t16))){
t17=t15;
f_4183(t17,lf[61]);}
else{
if(C_truep((C_word)C_booleanp(t16))){
t17=t15;
f_4183(t17,lf[112]);}
else{
if(C_truep((C_word)C_i_listp(t16))){
t17=t15;
f_4183(t17,lf[59]);}
else{
if(C_truep((C_word)C_i_pairp(t16))){
t17=t15;
f_4183(t17,lf[84]);}
else{
if(C_truep((C_word)C_eofp(t16))){
t17=t15;
f_4183(t17,lf[113]);}
else{
if(C_truep((C_word)C_i_vectorp(t16))){
t17=t15;
f_4183(t17,lf[114]);}
else{
t17=(C_word)C_immp(t16);
t18=(C_truep(t17)?C_SCHEME_FALSE:(C_truep(*((C_word*)lf[115]+1))?t16:C_SCHEME_FALSE));
if(C_truep(t18)){
t19=(C_word)C_slot(t16,C_fix(0));
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=t15;
f_4183(t21,(C_word)C_a_i_cons(&a,2,lf[45],t20));}
else{
if(C_truep((C_word)C_i_nullp(t16))){
t19=t15;
f_4183(t19,lf[86]);}
else{
t19=(C_word)C_charp(t16);
t20=t15;
f_4183(t20,(C_truep(t19)?lf[37]:lf[15]));}}}}}}}}}}}}}
else{
t15=(C_word)C_eqp(t11,lf[116]);
if(C_truep(t15)){
t16=t13;
f_4170(2,t16,lf[117]);}
else{
t16=(C_word)C_eqp(t11,lf[118]);
if(C_truep(t16)){
t17=t13;
f_4170(2,t17,lf[119]);}
else{
t17=(C_word)C_eqp(t11,lf[120]);
if(C_truep(t17)){
t18=(C_word)C_i_car(t9);
/* scrutinizer.scm: 525  global-result */
t19=((C_word*)t0)[14];
f_1438(t19,t13,t18,t4);}
else{
t18=(C_word)C_eqp(t11,lf[121]);
if(C_truep(t18)){
t19=(C_word)C_i_car(t9);
/* scrutinizer.scm: 526  variable-result */
t20=((C_word*)t0)[13];
f_1463(t20,t13,t19,t3,t4);}
else{
t19=(C_word)C_eqp(t11,lf[122]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4234,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=t3,a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=((C_word*)t0)[10],a[10]=t4,a[11]=((C_word*)t0)[11],a[12]=t13,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4345,a[2]=t4,a[3]=t20,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t22=(C_word)C_i_car(t7);
/* scrutinizer.scm: 527  walk */
t53=t21;
t54=t22;
t55=t3;
t56=t4;
t57=t5;
t1=t53;
t2=t54;
t3=t55;
t4=t56;
t5=t57;
goto loop;}
else{
t20=(C_word)C_eqp(t11,lf[126]);
if(C_truep(t20)){
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4360,a[2]=((C_word*)t0)[6],a[3]=t22,a[4]=t3,a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t24=((C_word*)t22)[1];
f_4360(t24,t13,t9,t7,C_SCHEME_END_OF_LIST);}
else{
t21=(C_word)C_eqp(t11,lf[129]);
t22=(C_truep(t21)?t21:(C_word)C_eqp(t11,lf[130]));
if(C_truep(t22)){
t23=(C_word)C_i_car(t9);
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4442,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm: 553  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t13,t23,t24);}
else{
t23=(C_word)C_eqp(t11,lf[135]);
t24=(C_truep(t23)?t23:(C_word)C_eqp(t11,lf[136]));
if(C_truep(t24)){
t25=(C_word)C_i_car(t9);
t26=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4524,a[2]=((C_word*)t0)[8],a[3]=t7,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[11],a[8]=t13,a[9]=t3,a[10]=t25,tmp=(C_word)a,a+=11,tmp);
/* scrutinizer.scm: 573  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[17]))(4,*((C_word*)lf[17]+1),t26,t25,lf[18]);}
else{
t25=(C_word)C_eqp(t11,lf[140]);
t26=(C_truep(t25)?t25:(C_word)C_eqp(t11,lf[141]));
if(C_truep(t26)){
t27=t13;
f_4170(2,t27,lf[15]);}
else{
t27=(C_word)C_eqp(t11,lf[142]);
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4612,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=t9,a[6]=t4,a[7]=t13,a[8]=((C_word*)t0)[3],a[9]=t7,tmp=(C_word)a,a+=10,tmp);
/* scrutinizer.scm: 592  fragment */
f_3505(t28,t2);}
else{
t28=(C_word)C_eqp(t11,lf[147]);
t29=(C_truep(t28)?t28:(C_word)C_eqp(t11,lf[148]));
if(C_truep(t29)){
/* scrutinizer.scm: 605  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t13,lf[149],t11);}
else{
t30=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4669,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t31=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4671,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t32=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t32+1)))(4,t32,t30,t31,t7);}}}}}}}}}}}}}

/* a4670 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4671,3,t0,t1,t2);}
/* scrutinizer.scm: 607  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4154(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4667 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4170(2,t2,lf[15]);}

/* k4610 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4615,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4624,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4650,a[2]=((C_word*)t0)[9],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[9]);
/* scrutinizer.scm: 602  iota */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),t4,t5);}

/* k4648 in k4610 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 593  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[123]+1)))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4623 in k4610 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4624,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4632,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4640,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t6)){
t7=t5;
f_4640(2,t7,lf[144]);}
else{
/* scrutinizer.scm: 599  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),t5,lf[145],t3);}}

/* k4638 in a4623 in k4610 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 595  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[3],lf[143],t1,((C_word*)t0)[2]);}

/* k4630 in a4623 in k4610 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4636,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 601  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4154(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k4634 in k4630 in a4623 in k4610 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 594  single */
t2=((C_word*)t0)[5];
f_3365(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4613 in k4610 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* scrutinizer.scm: 603  call-result */
t3=((C_word*)t0)[5];
f_3579(t3,((C_word*)t0)[4],t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k4522 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4527,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4586,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 575  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),t3,lf[139],((C_word*)t0)[10]);}

/* k4584 in k4522 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4590,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* scrutinizer.scm: 576  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4154(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k4588 in k4584 in k4522 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 574  single */
t2=((C_word*)t0)[5];
f_3365(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4525 in k4522 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4527,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4533,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4552,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(t2)){
t5=t4;
f_4552(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[3],lf[14]);
if(C_truep(t5)){
t6=t4;
f_4552(t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4578,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 581  match */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2479(t7,t6,((C_word*)t0)[3],t1);}}}
else{
t5=t4;
f_4552(t5,C_SCHEME_FALSE);}}

/* k4576 in k4525 in k4522 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4552(t2,(C_word)C_i_not(t1));}

/* k4550 in k4525 in k4522 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_4552(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4552,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 584  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[4]))(6,*((C_word*)lf[4]+1),t2,lf[138],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
f_4533(2,t2,C_SCHEME_UNDEFINED);}}

/* k4557 in k4550 in k4525 in k4522 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 582  report */
t2=((C_word*)t0)[4];
f_3413(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4531 in k4525 in k4522 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=t2;
f_4539(t4,(C_word)C_eqp(lf[19],t3));}
else{
t3=t2;
f_4539(t3,C_SCHEME_FALSE);}}

/* k4537 in k4531 in k4525 in k4522 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_4539(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_set_cdr(((C_word*)t0)[4],((C_word*)t0)[3]):C_SCHEME_UNDEFINED);
t3=((C_word*)t0)[2];
f_4170(2,t3,lf[137]);}

/* a4441 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4442,5,t0,t1,t2,t3,t4);}
t5=(C_truep(((C_word*)t0)[7])?(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]):C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4449,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t5,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4502,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 557  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t7,t3,lf[15]);}

/* k4500 in a4441 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[3])?lf[133]:C_SCHEME_END_OF_LIST);
/* scrutinizer.scm: 557  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[2],t1,t2);}

/* k4447 in a4441 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4452,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4485,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4487,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4495,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
/* scrutinizer.scm: 559  butlast */
((C_proc3)C_retrieve_symbol_proc(lf[132]))(3,*((C_word*)lf[132]+1),t5,((C_word*)t0)[2]);}
else{
t6=t5;
f_4495(2,t6,((C_word*)t0)[2]);}}

/* k4493 in k4447 in a4441 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4486 in k4447 in a4441 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4487,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,lf[15]));}

/* k4483 in k4447 in a4441 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 558  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4450 in k4447 in a4441 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4455,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4474,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* scrutinizer.scm: 562  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t4,((C_word*)t0)[2],lf[59],t1);}
else{
t5=t4;
f_4474(2,t5,t1);}}

/* k4472 in k4450 in k4447 in a4441 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4478,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 563  add-loc */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4476 in k4472 in k4450 in k4447 in a4441 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 561  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4154(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k4453 in k4450 in k4447 in a4441 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4462,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* scrutinizer.scm: 566  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[67]+1)))(6,*((C_word*)lf[67]+1),t2,lf[131],((C_word*)t0)[2],t3,t1);}

/* k4460 in k4453 in k4450 in k4447 in a4441 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4462,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* loop in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_4360(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4360,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4378,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* scrutinizer.scm: 547  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t6,t4,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4381,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4404,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t5,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4420,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_car(t2);
/* scrutinizer.scm: 549  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[6]))(3,*((C_word*)lf[6]+1),t7,t8);}}

/* k4418 in loop in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 549  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[128],t1);}

/* k4402 in loop in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4408,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
/* scrutinizer.scm: 550  walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4154(t5,t2,t3,((C_word*)t0)[2],((C_word*)t0)[6],t4);}

/* k4406 in k4402 in loop in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 548  single */
t2=((C_word*)t0)[5];
f_3365(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4379 in loop in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4381,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4396,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
/* scrutinizer.scm: 551  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t4,t5,t1,((C_word*)t0)[2]);}

/* k4394 in k4379 in loop in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 551  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4360(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4376 in loop in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 547  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4154(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4343 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 527  single */
t2=((C_word*)t0)[4];
f_3365(t2,((C_word*)t0)[3],lf[125],t1,((C_word*)t0)[2]);}

/* k4232 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4237,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* scrutinizer.scm: 528  always-true */
t3=((C_word*)t0)[2];
f_1551(t3,t2,t1,((C_word*)t0)[10],((C_word*)t0)[8]);}

/* k4235 in k4232 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* scrutinizer.scm: 529  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4154(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[9],((C_word*)t0)[2]);}

/* k4238 in k4235 in k4232 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4243,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t1,a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* scrutinizer.scm: 530  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4154(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[9],((C_word*)t0)[2]);}

/* k4241 in k4238 in k4235 in k4232 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[15]);
if(C_truep(t3)){
t4=t2;
f_4249(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(lf[15],t1);
t5=t2;
f_4249(t5,(C_word)C_i_not(t4));}}

/* k4247 in k4241 in k4238 in k4235 in k4232 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_4249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4249,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4252,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4276,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 533  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t4,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[8]);}
else{
t2=((C_word*)t0)[9];
f_4170(2,t2,lf[15]);}}

/* k4317 in k4247 in k4241 in k4238 in k4235 in k4232 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4319,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_4276(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4315,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 534  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t2,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k4313 in k4317 in k4247 in k4241 in k4238 in k4235 in k4232 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4276(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_eqp(t2,t3);
t5=((C_word*)t0)[4];
f_4276(t5,(C_word)C_i_not(t4));}}

/* k4274 in k4247 in k4241 in k4238 in k4235 in k4232 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_4276(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4276,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4283,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4287,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 540  pp-fragment */
t4=((C_word*)t0)[3];
f_3559(t4,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_4252(2,t2,C_SCHEME_UNDEFINED);}}

/* k4285 in k4274 in k4247 in k4241 in k4238 in k4235 in k4232 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 538  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[124],t1);}

/* k4281 in k4274 in k4247 in k4241 in k4238 in k4235 in k4232 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 536  report */
t2=((C_word*)t0)[4];
f_3413(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4250 in k4247 in k4241 in k4238 in k4235 in k4232 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4257,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 541  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[123]+1)))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4256 in k4250 in k4247 in k4241 in k4238 in k4235 in k4232 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4257,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=(C_word)C_a_i_cons(&a,2,lf[26],t5);
/* scrutinizer.scm: 541  simplify */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1742(3,t7,t1,t6);}

/* k4181 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_4183(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4183,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4170(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* k4168 in walk in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[66]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* noreturn-type? in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4122,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[81],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[26],t4);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 514  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t1,((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3579(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3579,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3582,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_retrieve(lf[66]);
t8=(C_word)C_i_car(t2);
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3809,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t10,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t8,a[10]=((C_word*)t0)[5],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
/* scrutinizer.scm: 434  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t11,t10,lf[15]);}

/* k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3809,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[15],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[40],t3);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3638,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3776,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=((C_word*)t0)[7],a[6]=t5,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3801,a[2]=((C_word*)t0)[9],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 435  procedure-type? */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3819(3,t8,t7,((C_word*)t0)[9]);}

/* k3799 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3801,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3776(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3797,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 436  match */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2479(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3795 in k3799 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3776(t2,(C_word)C_i_not(t1));}

/* k3774 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3776(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3776,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3783,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3787,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 441  pname */
t4=((C_word*)t0)[2];
f_3582(t4,t3);}
else{
t2=((C_word*)t0)[6];
f_3638(2,t2,C_SCHEME_UNDEFINED);}}

/* k3785 in k3774 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 439  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[4]))(6,*((C_word*)lf[4]+1),((C_word*)t0)[4],lf[106],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3781 in k3774 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 437  report */
t2=((C_word*)t0)[4];
f_3413(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3643,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3656 in k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3657,4,t0,t1,t2,t3);}
t4=C_retrieve(lf[66]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3664,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=((C_word*)t0)[8],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_i_length(t2);
t7=(C_word)C_eqp(t6,((C_word*)t0)[2]);
if(C_truep(t7)){
t8=t5;
f_3664(2,t8,C_SCHEME_UNDEFINED);}
else{
t8=(C_word)C_i_length(t2);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3757,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3761,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 452  pname */
t11=((C_word*)t0)[4];
f_3582(t11,t10);}}

/* k3759 in a3656 in k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(1));
t3=(C_truep(t2)?lf[51]:lf[52]);
t4=(C_word)C_eqp(((C_word*)t0)[3],C_fix(1));
t5=(C_truep(t4)?lf[51]:lf[52]);
/* scrutinizer.scm: 450  sprintf */
((C_proc8)C_retrieve_symbol_proc(lf[4]))(8,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[105],t1,((C_word*)t0)[4],t3,((C_word*)t0)[3],t5);}

/* k3755 in a3656 in k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 448  report */
t2=((C_word*)t0)[4];
f_3413(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3662 in a3656 in k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3667,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3683,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3683(t7,t2,t3,((C_word*)t0)[2],C_fix(1));}

/* doloop914 in k3662 in a3656 in k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3683(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3683,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?t5:(C_word)C_i_nullp(t3));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3696,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3714,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_i_car(t2);
/* scrutinizer.scm: 458  match */
t11=((C_word*)((C_word*)t0)[2])[1];
f_2479(t11,t8,t9,t10);}}

/* k3712 in doloop914 in k3662 in a3656 in k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3714,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
f_3696(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3729,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 463  pname */
t5=((C_word*)t0)[2];
f_3582(t5,t4);}}

/* k3727 in k3712 in doloop914 in k3662 in a3656 in k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* scrutinizer.scm: 461  sprintf */
((C_proc7)C_retrieve_symbol_proc(lf[4]))(7,*((C_word*)lf[4]+1),((C_word*)t0)[4],lf[104],((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k3719 in k3712 in doloop914 in k3662 in a3656 in k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 459  report */
t2=((C_word*)t0)[4];
f_3413(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3694 in doloop914 in k3662 in a3656 in k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_3683(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k3665 in k3662 in a3656 in k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3670,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
if(C_truep(t4)){
t5=t2;
f_3670(2,t5,t3);}
else{
t5=(C_word)C_i_memq(((C_word*)t0)[2],lf[102]);
t6=(C_truep(t5)?t5:(C_word)C_i_not_pair_p(((C_word*)t0)[2]));
if(C_truep(t6)){
t7=t2;
f_3670(2,t7,lf[15]);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[2]);
t8=(C_word)C_eqp(lf[40],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4046,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 501  call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[76]+1)))(3,*((C_word*)lf[76]+1),t2,t9);}
else{
/* scrutinizer.scm: 509  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[103],((C_word*)t0)[2]);}}}}

/* a4045 in k3665 in k3662 in a3656 in k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4046,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=(C_word)C_i_stringp(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4093,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4093(t6,t4);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[2]);
t7=t5;
f_4093(t7,(C_word)C_i_symbolp(t6));}}

/* k4091 in a4045 in k3665 in k3662 in a3656 in k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_4093(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4093,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cdddr(((C_word*)t0)[4]):(C_word)C_i_cddr(((C_word*)t0)[4]));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4056,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4056(t6,((C_word*)t0)[2],t2);}

/* loop in k4091 in a4045 in k3665 in k3662 in a3656 in k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_4056(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4056,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_eqp(lf[15],t2);
if(C_truep(t3)){
/* scrutinizer.scm: 507  return */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,lf[15]);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4083,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 508  loop */
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* k4081 in loop in k4091 in a4045 in k3665 in k3662 in a3656 in k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_4083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4083,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3668 in k3665 in k3662 in a3656 in k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[66]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a3642 in k3636 in k3807 in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3643,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(C_word)C_i_length(t2);
/* scrutinizer.scm: 444  procedure-argument-types */
t4=((C_word*)t0)[3];
f_3861(t4,t1,((C_word*)t0)[2],t3);}

/* pname in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3582(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3582,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3590,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 424  fragment */
f_3505(t2,((C_word*)t0)[2]);}

/* k3588 in pname in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3594,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3597,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
t5=t3;
f_3597(t5,(C_word)C_i_pairp(t4));}
else{
t4=t3;
f_3597(t4,C_SCHEME_FALSE);}}

/* k3595 in k3588 in pname in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3597(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3597,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3600,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* scrutinizer.scm: 426  source-info->line */
((C_proc3)C_retrieve_symbol_proc(lf[100]))(3,*((C_word*)lf[100]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
f_3594(2,t2,lf[101]);}}

/* k3598 in k3595 in k3588 in pname in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_numberp(t1))){
/* scrutinizer.scm: 428  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[98],t1);}
else{
t2=((C_word*)t0)[2];
f_3594(2,t2,lf[99]);}}

/* k3592 in k3588 in pname in call-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 422  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[3],lf[97],((C_word*)t0)[2],t1);}

/* procedure-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3861(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3861,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_memq(t2,lf[94]);
t5=(C_truep(t4)?t4:(C_word)C_i_not_pair_p(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3878,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 476  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t6,t3,lf[15]);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(lf[40],t6);
if(C_truep(t7)){
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3887,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_cadr(t2);
t12=(C_word)C_i_stringp(t11);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3993,a[2]=t3,a[3]=t10,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_3993(t14,t12);}
else{
t14=(C_word)C_i_cadr(t2);
t15=t13;
f_3993(t15,(C_word)C_i_symbolp(t14));}}
else{
/* scrutinizer.scm: 494  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t1,lf[96],t2);}}}

/* k3991 in procedure-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3993(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3993,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3896,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_3896(t6,((C_word*)t0)[3],t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* loop in k3991 in procedure-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3896(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3896,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(lf[63],t5);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 487  loop */
t16=t1;
t17=t7;
t18=t3;
t19=C_SCHEME_TRUE;
t1=t16;
t2=t17;
t3=t18;
t4=t19;
goto loop;}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(lf[64],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3926,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t10=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cadr(t2);
t12=t9;
f_3926(t12,(C_word)C_eqp(lf[65],t11));}
else{
t11=t9;
f_3926(t11,C_SCHEME_FALSE);}}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3957,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t10=t3;
t11=t9;
f_3957(t11,(C_word)C_fixnum_less_or_equal_p(t10,C_fix(0)));}
else{
t10=t9;
f_3957(t10,C_SCHEME_FALSE);}}}}}

/* k3955 in loop in k3991 in procedure-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3957(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3957,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3968,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* scrutinizer.scm: 492  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_3896(t6,t3,t4,t5,((C_word*)t0)[2]);}}

/* k3966 in k3955 in loop in k3991 in procedure-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3968,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3924 in loop in k3991 in procedure-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=f_2189(t3);
/* scrutinizer.scm: 490  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k3885 in procedure-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 493  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3876 in procedure-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 476  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* single in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3365(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3365,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(lf[15],t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[15]);}
else{
t6=(C_word)C_i_length(t3);
t7=(C_word)C_eqp(C_fix(1),t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_car(t3));}
else{
t8=(C_word)C_eqp(t6,C_fix(0));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3393,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3397,a[2]=t4,a[3]=t9,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 380  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),t10,lf[91],t2);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3400,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3407,a[2]=t4,a[3]=t9,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_eqp(t6,C_fix(1));
t12=(C_truep(t11)?lf[51]:lf[52]);
/* scrutinizer.scm: 385  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[4]))(6,*((C_word*)lf[4]+1),t10,lf[92],t2,t6,t12);}}}}

/* k3405 in single in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 383  report */
t2=((C_word*)t0)[4];
f_3413(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3398 in single in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(((C_word*)t0)[2]));}

/* k3395 in single in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 378  report */
t2=((C_word*)t0)[4];
f_3413(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3391 in single in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[19]);}

/* match-results in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2970(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2970,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not_pair_p(t3));}
else{
t4=(C_word)C_eqp(lf[15],t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eqp(lf[15],t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3004,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_car(t3);
/* scrutinizer.scm: 326  match */
t9=((C_word*)((C_word*)t0)[2])[1];
f_2479(t9,t6,t7,t8);}}}}}

/* k3002 in match-results in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* scrutinizer.scm: 327  match-results */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2970(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match-args in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2760(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2760,NULL,4,t0,t1,t2,t3);}
t4=C_retrieve(lf[66]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2825,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2825(t9,t1,t2,t3,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* loop in match-args in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2825(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2825,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_retrieve(lf[66]);
if(C_truep((C_word)C_i_nullp(t2))){
t7=t5;
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(C_word)C_i_nullp(t3);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=(C_word)C_i_car(t3);
t10=t1;
t11=t10;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_i_memq(t9,lf[89]));}}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t7=t4;
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(C_word)C_i_car(t2);
t9=t1;
t10=t9;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_i_memq(t8,lf[90]));}}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(lf[63],t7);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 312  loop */
t32=t1;
t33=t9;
t34=t3;
t35=C_SCHEME_TRUE;
t36=t5;
t1=t32;
t2=t33;
t3=t34;
t4=t35;
t5=t36;
goto loop;}
else{
t9=(C_word)C_i_car(t3);
t10=(C_word)C_eqp(lf[63],t9);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t3);
/* scrutinizer.scm: 314  loop */
t32=t1;
t33=t2;
t34=t11;
t35=t4;
t36=C_SCHEME_TRUE;
t1=t32;
t2=t33;
t3=t34;
t4=t35;
t5=t36;
goto loop;}
else{
t11=(C_word)C_i_car(t2);
t12=(C_word)C_eqp(lf[64],t11);
if(C_truep(t12)){
t13=(C_word)C_i_cdr(t2);
t14=f_2189(t13);
/* scrutinizer.scm: 316  match-rest */
t15=((C_word*)t0)[3];
f_2766(t15,t1,t14,t3);}
else{
t13=(C_word)C_i_car(t3);
t14=(C_word)C_eqp(lf[64],t13);
if(C_truep(t14)){
t15=(C_word)C_i_cdr(t3);
t16=f_2189(t15);
/* scrutinizer.scm: 318  match-rest */
t17=((C_word*)t0)[3];
f_2766(t17,t1,t16,t2);}
else{
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2933,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t16=(C_word)C_i_car(t2);
t17=(C_word)C_i_car(t3);
/* scrutinizer.scm: 319  match */
t18=((C_word*)((C_word*)t0)[2])[1];
f_2479(t18,t15,t16,t17);}}}}}}}

/* k2931 in loop in match-args in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 319  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2825(t4,((C_word*)t0)[4],t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match-rest in match-args in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2766(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2766,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2772,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a2783 in match-rest in match-args in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2784,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2791,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 298  every */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t4,t5,t2);}

/* a2809 in a2783 in match-rest in match-args in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2810,3,t0,t1,t2);}
/* match109 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2479(t3,t1,((C_word*)t0)[2],t2);}

/* k2789 in a2783 in match-rest in match-args in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2791,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2798,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm: 299  rest-type */
t4=t2;
f_2798(t4,f_2189(t3));}
else{
t3=t2;
f_2798(t3,lf[15]);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2796 in k2789 in a2783 in match-rest in match-args in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 299  match */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2479(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2771 in match-rest in match-args in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2778,tmp=(C_word)a,a+=2,tmp);
/* scrutinizer.scm: 297  break */
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),t1,t2,((C_word*)t0)[2]);}

/* a2777 in a2771 in match-rest in match-args in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2778,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(lf[64],t2));}

/* match1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2488(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2488,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eqp(t2,lf[15]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_eqp(t3,lf[15]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[81]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[81]);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[61]);
t10=(C_truep(t9)?(C_word)C_i_memq(t3,lf[82]):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[61]);
t12=(C_truep(t11)?(C_word)C_i_memq(t2,lf[83]):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t13=(C_word)C_eqp(lf[40],t2);
if(C_truep(t13)){
if(C_truep((C_word)C_i_pairp(t3))){
t14=(C_word)C_i_car(t3);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_eqp(lf[40],t14));}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_eqp(lf[40],t3);
if(C_truep(t14)){
if(C_truep((C_word)C_i_pairp(t2))){
t15=(C_word)C_i_car(t2);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_eqp(lf[40],t15));}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t16=(C_word)C_i_car(t2);
t17=t15;
f_2575(t17,(C_word)C_eqp(lf[26],t16));}
else{
t16=t15;
f_2575(t16,C_SCHEME_FALSE);}}}}}}}}}}}

/* k2573 in match1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2575,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2580,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 278  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),((C_word*)t0)[5],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=t2;
f_2594(t4,(C_word)C_eqp(lf[26],t3));}
else{
t3=t2;
f_2594(t3,C_SCHEME_FALSE);}}}

/* k2592 in k2573 in match1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2594(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2594,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2599,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 279  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),((C_word*)t0)[5],t2,t3);}
else{
t2=((C_word*)t0)[7];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[84]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[59]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_memq(((C_word*)t0)[6],lf[85]));}
else{
t3=((C_word*)t0)[7];
if(C_truep((C_truep((C_word)C_eqp(t3,lf[86]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[59]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_memq(((C_word*)t0)[6],lf[87]));}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
t7=t4;
f_2631(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t4;
f_2631(t5,C_SCHEME_FALSE);}}
else{
t5=t4;
f_2631(t5,C_SCHEME_FALSE);}}}}}

/* k2629 in k2592 in k2573 in match1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2631,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_eqp(t2,lf[40]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm: 285  named? */
f_2149(t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(t2,lf[45]);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?(C_word)C_i_equalp(((C_word*)t0)[7],((C_word*)t0)[6]):C_SCHEME_FALSE));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2689 in k2629 in k2592 in k2573 in match1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2691,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[7]):(C_word)C_i_cadr(((C_word*)t0)[7]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 286  named? */
f_2149(t3,((C_word*)t0)[6]);}

/* k2680 in k2689 in k2629 in k2592 in k2573 in match1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2682,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[8]):(C_word)C_i_cadr(((C_word*)t0)[8]));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* scrutinizer.scm: 287  named? */
f_2149(t3,((C_word*)t0)[7]);}

/* k2671 in k2680 in k2689 in k2629 in k2592 in k2573 in match1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2673,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cdddr(((C_word*)t0)[9]):(C_word)C_i_cddr(((C_word*)t0)[9]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2664,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 288  named? */
f_2149(t3,((C_word*)t0)[8]);}

/* k2662 in k2671 in k2680 in k2689 in k2629 in k2592 in k2573 in match1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2664,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cdddr(((C_word*)t0)[8]):(C_word)C_i_cddr(((C_word*)t0)[8]));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2658,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 289  match-args */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2760(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2656 in k2662 in k2671 in k2680 in k2689 in k2629 in k2592 in k2573 in match1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* scrutinizer.scm: 290  match-results */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2970(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a2598 in k2592 in k2573 in match1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2599,3,t0,t1,t2);}
/* match109 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2479(t3,t1,((C_word*)t0)[2],t2);}

/* a2579 in k2573 in match1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2580,3,t0,t1,t2);}
/* match109 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2479(t3,t1,t2,((C_word*)t0)[2]);}

/* match in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2479(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2479,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2483,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 265  match1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2488(t5,t4,t2,t3);}

/* k2481 in match in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[66]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* merge-result-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2413(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2413,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_not_pair_p(t2);
t5=(C_truep(t4)?t4:(C_word)C_i_not_pair_p(t3));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[15]);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2442,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_car(t3);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t7,t9);
t11=(C_word)C_a_i_cons(&a,2,lf[26],t10);
/* scrutinizer.scm: 262  simplify */
t12=((C_word*)((C_word*)t0)[2])[1];
f_1742(3,t12,t6,t11);}}}}

/* k2440 in merge-result-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2446,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm: 263  merge-result-types */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2413(t5,t2,t3,t4);}

/* k2444 in k2440 in merge-result-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2446,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* merge-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2211(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2211,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_memq(t4,lf[77]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t3:lf[78]));}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[64],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2246,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t7=(C_word)C_i_car(t3);
t8=t6;
f_2246(t8,(C_word)C_eqp(lf[64],t7));}
else{
t7=t6;
f_2246(t7,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(lf[63],t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2307,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t9=(C_word)C_i_car(t3);
t10=t8;
f_2307(t10,(C_word)C_eqp(lf[63],t9));}
else{
t9=t8;
f_2307(t9,C_SCHEME_FALSE);}}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2371,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_car(t3);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t9,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[26],t12);
/* scrutinizer.scm: 256  simplify */
t14=((C_word*)((C_word*)t0)[3])[1];
f_1742(3,t14,t8,t13);}}}}

/* k2369 in merge-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2375,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm: 257  merge-argument-types */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2211(t5,t2,t3,t4);}

/* k2373 in k2369 in merge-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2375,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2305 in merge-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2307(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2307,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2318,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[26],t6);
/* scrutinizer.scm: 253  simplify */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1742(3,t8,t2,t7);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[80]);}}

/* k2316 in k2305 in merge-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2322,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2326,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* scrutinizer.scm: 254  merge-argument-types */
t6=((C_word*)((C_word*)t0)[2])[1];
f_2211(t6,t3,t4,t5);}

/* k2324 in k2316 in k2305 in merge-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2320 in k2316 in k2305 in merge-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2322,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[63],t2));}

/* k2244 in merge-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2246(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2246,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2257,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=f_2189(t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=f_2189(t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[26],t8);
/* scrutinizer.scm: 246  simplify */
t10=((C_word*)((C_word*)t0)[2])[1];
f_1742(3,t10,t2,t9);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[79]);}}

/* k2255 in k2244 in merge-argument-types in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2257,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[64],t2));}

/* simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_1751(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1751,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 172  call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[76]+1)))(3,*((C_word*)lf[76]+1),t1,t3);}

/* a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1757(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1757,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[8]))){
t3=(C_word)C_i_car(((C_word*)t0)[8]);
t4=(C_word)C_eqp(t3,lf[26]);
if(C_truep(t4)){
t5=(C_word)C_i_length(((C_word*)t0)[8]);
t6=(C_word)C_eqp(C_fix(2),t5);
if(C_truep(t6)){
t7=(C_word)C_i_cadr(((C_word*)t0)[8]);
/* scrutinizer.scm: 177  simplify */
t8=((C_word*)((C_word*)t0)[7])[1];
f_1742(3,t8,t1,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1792,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* scrutinizer.scm: 178  every */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t7,((C_word*)((C_word*)t0)[2])[1],t8);}}
else{
t5=(C_word)C_eqp(t3,lf[40]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2144,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 219  named? */
f_2149(t6,((C_word*)t0)[8]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[8]);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[8]);}}

/* k2142 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2144,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[4]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_cdddr(((C_word*)t0)[4]):(C_word)C_i_cddr(((C_word*)t0)[4]));
t4=(C_truep(t2)?(C_word)C_a_i_list(&a,1,t2):C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2122,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(C_truep(t2)?(C_word)C_i_caddr(((C_word*)t0)[4]):(C_word)C_i_cadr(((C_word*)t0)[4]));
/* map */
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)((C_word*)t0)[2])[1],t6);}

/* k2120 in k2142 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2122,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2112,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[15],((C_word*)t0)[3]);
if(C_truep(t4)){
t5=t3;
f_2112(2,t5,lf[15]);}
else{
/* map */
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k2110 in k2120 in k2142 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 221  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[67]+1)))(6,*((C_word*)lf[67]+1),((C_word*)t0)[4],lf[75],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1895,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* scrutinizer.scm: 179  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t2,t3,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2038,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* scrutinizer.scm: 197  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),t2,t3,t4);}}

/* a2037 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2038,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2042,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 199  simplify */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1742(3,t4,t3,t2);}

/* k2040 in a2037 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2048,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_car(t1);
t4=t2;
f_2048(t4,(C_word)C_eqp(lf[26],t3));}
else{
t3=t2;
f_2048(t3,C_SCHEME_FALSE);}}

/* k2046 in k2040 in a2037 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2048(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2048,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[3]));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[19]);
if(C_truep(t2)){
/* scrutinizer.scm: 203  return */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[4],lf[19]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}}}

/* k1904 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1948(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k1904 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_1948(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1948,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* scrutinizer.scm: 207  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[73]+1)))(3,*((C_word*)lf[73]+1),t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[15],t4);
if(C_truep(t5)){
/* scrutinizer.scm: 208  return */
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,lf[15]);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 209  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t6,t7,t8);}}}

/* a2019 in loop in k1904 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2020,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* type<=?113 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3025(t4,t1,t3,t2);}

/* k1971 in loop in k1904 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 210  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1948(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1986,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 211  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t2,t3,((C_word*)t0)[3]);}}

/* a2009 in k1971 in loop in k1904 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_2010(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2010,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* type<=?113 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3025(t4,t1,t3,t2);}

/* k1984 in k1971 in loop in k1904 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1986,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* scrutinizer.scm: 212  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1948(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* scrutinizer.scm: 213  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_1948(t5,((C_word*)t0)[3],t2,t4);}}

/* k1907 in k1904 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_equalp(t1,t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=C_retrieve(lf[66]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1936,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1938,tmp=(C_word)a,a+=2,tmp);
/* scrutinizer.scm: 217  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t5,t6,t1);}}

/* a1937 in k1907 in k1904 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1938,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,lf[15]));}

/* k1934 in k1907 in k1904 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[71]:((C_word*)t0)[3]);
/* ##sys#append */
t3=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* k1927 in k1907 in k1904 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1929,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[26],t1);
/* scrutinizer.scm: 217  simplify */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1742(3,t3,((C_word*)t0)[2],t2);}

/* a1894 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1895,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(lf[40],t2));}

/* k1796 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1798,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[40]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1803,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* scrutinizer.scm: 181  reduce */
((C_proc5)C_retrieve_symbol_proc(lf[69]))(5,*((C_word*)lf[69]+1),((C_word*)t0)[6],t2,C_SCHEME_FALSE,t3);}}

/* a1802 in k1796 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1803,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm: 183  named? */
f_2149(t4,t2);}

/* k1884 in a1802 in k1796 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[7]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_caddr(((C_word*)t0)[7]):(C_word)C_i_cadr(((C_word*)t0)[7]));
t4=(C_truep(t2)?(C_word)C_i_cdddr(((C_word*)t0)[7]):(C_word)C_i_cddr(((C_word*)t0)[7]));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1868,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 186  named? */
f_2149(t5,((C_word*)t0)[6]);}

/* k1866 in k1884 in a1802 in k1796 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1868,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[8]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_caddr(((C_word*)t0)[8]):(C_word)C_i_cadr(((C_word*)t0)[8]));
t4=(C_truep(t2)?(C_word)C_i_cdddr(((C_word*)t0)[8]):(C_word)C_i_cddr(((C_word*)t0)[8]));
t5=(C_truep(((C_word*)t0)[7])?(C_truep(t2)?(C_word)C_eqp(((C_word*)t0)[7],t2):C_SCHEME_FALSE):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]):C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1841,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* scrutinizer.scm: 192  merge-argument-types */
t8=((C_word*)((C_word*)t0)[3])[1];
f_2211(t8,t7,((C_word*)t0)[2],t3);}

/* k1839 in k1866 in k1884 in a1802 in k1796 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1841,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1837,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 193  merge-result-types */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2413(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1835 in k1839 in k1866 in k1884 in a1802 in k1796 in k1790 in a1756 in simplify1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 189  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[67]+1)))(6,*((C_word*)lf[67]+1),((C_word*)t0)[4],lf[68],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* simplify in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1742,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1746,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 168  simplify1 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1751(t4,t3,t2);}

/* k1744 in simplify in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[66]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* named? in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2149(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2149,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(lf[40],t3);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_nullp(t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2172,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t6)){
t8=t7;
f_2172(t8,t6);}
else{
t8=(C_word)C_i_cadr(t2);
t9=t7;
f_2172(t9,(C_word)C_i_pairp(t8));}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2170 in named? in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_2172(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* rest-type in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static C_word C_fcall f_2189(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(lf[15]);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(lf[65],t2);
return((C_truep(t3)?lf[15]:(C_word)C_i_car(t1)));}}

/* type<=? in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3025(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3025,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_memq(t3,lf[58]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=t3;
t7=(C_word)C_eqp(t6,lf[59]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_memq(t2,lf[60]));}
else{
t8=(C_word)C_eqp(t6,lf[40]);
if(C_truep(t8)){
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_car(t2);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_eqp(lf[40],t9));}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t6,lf[61]);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_i_memq(t2,lf[62]));}
else{
if(C_truep((C_word)C_i_pairp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t10=(C_word)C_i_car(t2);
t11=(C_word)C_eqp(t10,lf[26]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3101,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 339  every */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t1,t12,t13);}
else{
t12=(C_word)C_eqp(t10,lf[40]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_i_pairp(t13);
t15=(C_truep(t14)?(C_word)C_i_cadr(t2):(C_word)C_i_caddr(t2));
t16=(C_word)C_i_cadr(t3);
t17=(C_word)C_i_pairp(t16);
t18=(C_truep(t17)?(C_word)C_i_cadr(t3):(C_word)C_i_caddr(t3));
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_i_pairp(t19);
t21=(C_truep(t20)?(C_word)C_i_cddr(t2):(C_word)C_i_cdddr(t2));
t22=(C_word)C_i_cadr(t3);
t23=(C_word)C_i_pairp(t22);
t24=(C_truep(t23)?(C_word)C_i_cddr(t3):(C_word)C_i_cdddr(t3));
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3132,a[2]=t26,a[3]=t24,a[4]=t21,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t28=((C_word*)t26)[1];
f_3132(t28,t1,t15,t18,C_fix(0),C_fix(0));}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}}}}}}

/* loop1 in type<=? in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3132(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3132,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(C_word)C_i_nullp(t3);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3148,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_3148(t8,t6);}
else{
t8=t5;
t9=t7;
f_3148(t9,(C_word)C_fixnum_greaterp(t8,C_fix(0)));}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[63]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 360  loop1 */
t25=t1;
t26=t8;
t27=t3;
t28=C_fix(1);
t29=t5;
t1=t25;
t2=t26;
t3=t27;
t4=t28;
t5=t29;
goto loop;}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_eqp(t8,lf[63]);
if(C_truep(t9)){
t10=(C_word)C_i_cdr(t3);
/* scrutinizer.scm: 362  loop1 */
t25=t1;
t26=t2;
t27=t10;
t28=t4;
t29=C_fix(1);
t1=t25;
t2=t26;
t3=t27;
t4=t28;
t5=t29;
goto loop;}
else{
t10=(C_word)C_i_car(t2);
t11=(C_word)C_eqp(t10,lf[64]);
if(C_truep(t11)){
t12=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 364  loop1 */
t25=t1;
t26=t12;
t27=t3;
t28=C_fix(2);
t29=t5;
t1=t25;
t2=t26;
t3=t27;
t4=t28;
t5=t29;
goto loop;}
else{
t12=(C_word)C_i_car(t3);
t13=(C_word)C_eqp(t12,lf[64]);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t3);
/* scrutinizer.scm: 366  loop1 */
t25=t1;
t26=t2;
t27=t14;
t28=t4;
t29=C_fix(2);
t1=t25;
t2=t26;
t3=t27;
t4=t28;
t5=t29;
goto loop;}
else{
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3267,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_car(t3);
/* scrutinizer.scm: 367  type<=? */
t17=((C_word*)((C_word*)t0)[5])[1];
f_3025(t17,t14,t15,t16);}}}}}}}

/* k3265 in loop1 in type<=? in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 368  loop1 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3132(t4,((C_word*)t0)[4],t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3146 in loop1 in type<=? in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3148,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3153,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3153(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k3146 in loop1 in type<=? in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3153(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3153,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(lf[15],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_nullp(t2));}
else{
t5=(C_word)C_eqp(lf[15],t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3181,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_car(t3);
/* scrutinizer.scm: 355  type<=? */
t9=((C_word*)((C_word*)t0)[2])[1];
f_3025(t9,t6,t7,t8);}}}}

/* k3179 in loop2 in k3146 in loop1 in type<=? in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* scrutinizer.scm: 356  loop2 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3153(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a3100 in type<=? in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3101,3,t0,t1,t2);}
/* type<=?113 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3025(t3,t1,t2,((C_word*)t0)[2]);}

/* procedure-type? in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3819,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[40],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[40],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(lf[26],t6);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 472  every */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t1,((C_word*)((C_word*)t0)[2])[1],t8);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* result-string in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_1714(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1714,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[15],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[55]);}
else{
t4=(C_word)C_i_length(t2);
t5=C_retrieve(lf[50]);
t6=(C_word)C_eqp(t5,C_fix(1));
t7=(C_truep(t6)?lf[51]:lf[52]);
t8=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[56]);}
else{
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1740,a[2]=t7,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* map */
t10=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,((C_word*)((C_word*)t0)[2])[1],t2);}}}

/* k1738 in result-string in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 163  sprintf */
((C_proc7)C_retrieve_symbol_proc(lf[4]))(7,*((C_word*)lf[4]+1),((C_word*)t0)[4],lf[57],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t1);}

/* argument-string in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_1692(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1692,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
t4=C_retrieve(lf[50]);
t5=(C_word)C_eqp(t4,C_fix(1));
t6=(C_truep(t5)?lf[51]:lf[52]);
t7=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[53]);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1712,a[2]=t6,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* map */
t9=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)((C_word*)t0)[2])[1],t2);}}

/* k1710 in argument-string in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 152  sprintf */
((C_proc7)C_retrieve_symbol_proc(lf[4]))(7,*((C_word*)lf[4]+1),((C_word*)t0)[4],lf[54],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t1);}

/* typename in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1571,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[15]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[36]);}
else{
t5=(C_word)C_eqp(t3,lf[37]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[38]);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* scrutinizer.scm: 130  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[39]+1)))(3,*((C_word*)lf[39]+1),t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[40]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_i_stringp(t8);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1617,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t9)){
t11=t10;
f_1617(t11,t9);}
else{
t11=(C_word)C_i_cadr(t2);
t12=t10;
f_1617(t12,(C_word)C_i_symbolp(t11));}}
else{
t8=(C_word)C_eqp(t6,lf[26]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1667,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[2])[1],t10);}
else{
t9=(C_word)C_eqp(t6,lf[45]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
/* scrutinizer.scm: 144  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),t1,lf[46],t10);}
else{
/* scrutinizer.scm: 145  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t1,lf[48],t2);}}}}
else{
/* scrutinizer.scm: 146  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t1,lf[49],t2);}}}}}

/* k1665 in typename in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 140  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),((C_word*)t0)[2],t1,lf[44]);}

/* k1615 in typename in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_1617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1617,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* scrutinizer.scm: 135  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),((C_word*)t0)[4],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* scrutinizer.scm: 137  argument-string */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1692(t4,t2,t3);}}

/* k1629 in k1615 in typename in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1635,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* scrutinizer.scm: 138  result-string */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1714(t4,t2,t3);}

/* k1633 in k1629 in k1615 in typename in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 136  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[3],lf[42],((C_word*)t0)[2],t1);}

/* always-true in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_1551(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1551,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1555,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm: 116  always-true1 */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1519(3,t6,t5,t2);}

/* k1553 in always-true in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1558,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1565,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1569,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 123  pp-fragment */
t5=((C_word*)t0)[3];
f_3559(t5,t4,((C_word*)t0)[2]);}
else{
t3=t2;
f_1558(2,t3,C_SCHEME_UNDEFINED);}}

/* k1567 in k1553 in always-true in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 120  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[3],lf[35],((C_word*)t0)[2],t1);}

/* k1563 in k1553 in always-true in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 118  report */
t2=((C_word*)t0)[4];
f_3413(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1556 in k1553 in always-true in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* pp-fragment in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3559(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3559,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3567,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3569,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 417  with-output-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[34]))(3,*((C_word*)lf[34]+1),t3,t4);}

/* a3568 in pp-fragment in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3577,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 419  fragment */
f_3505(t2,((C_word*)t0)[2]);}

/* k3575 in a3568 in pp-fragment in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 419  pp */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),((C_word*)t0)[2],t1);}

/* k3565 in pp-fragment in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 416  string-chomp */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),((C_word*)t0)[2],t1);}

/* fragment in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3505(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3505,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3509,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 408  build-expression-tree */
((C_proc3)C_retrieve_symbol_proc(lf[31]))(3,*((C_word*)lf[31]+1),t3,t2);}

/* k3507 in fragment in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3509,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3514,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3514(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* walk in k3507 in fragment in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3514(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3514,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=t3;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(3)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[27]);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t5=(C_word)C_fixnum_increase(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3541,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3549,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3553,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_length(t2);
/* scrutinizer.scm: 413  min */
((C_proc4)C_retrieve_proc(*((C_word*)lf[30]+1)))(4,*((C_word*)lf[30]+1),t8,C_fix(5),t9);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}}}

/* k3551 in walk in k3507 in fragment in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 413  take */
((C_proc4)C_retrieve_symbol_proc(lf[29]))(4,*((C_word*)lf[29]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3547 in walk in k3507 in fragment in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3537 in walk in k3507 in fragment in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3541,3,t0,t1,t2);}
/* g851852858 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3514(t3,t1,t2,((C_word*)t0)[2]);}

/* always-true1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1519,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1526,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_1526(t5,(C_word)C_eqp(lf[26],t4));}
else{
t4=t3;
f_1526(t4,C_SCHEME_FALSE);}}

/* k1524 in always-true1 in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_1526(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* scrutinizer.scm: 112  every */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}
else{
t2=(C_word)C_i_memq(((C_word*)t0)[4],lf[25]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:C_SCHEME_TRUE));}}

/* variable-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_1463(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1463,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1510,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 97   get */
((C_proc5)C_retrieve_symbol_proc(lf[22]))(5,*((C_word*)lf[22]+1),t6,((C_word*)t0)[3],t2,lf[23]);}

/* k1508 in variable-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1510,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1517,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 98   ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[17]))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],lf[21]);}
else{
t2=((C_word*)t0)[3];
f_1470(t2,C_SCHEME_FALSE);}}

/* k1515 in k1508 in variable-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1470(t2,(C_word)C_i_not(t1));}

/* k1468 in variable-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_1470(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1470,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_eqp(lf[19],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1485,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1489,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1493,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 106  real-name */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t7,((C_word*)t0)[7],((C_word*)t0)[3]);}
else{
t5=(C_word)C_i_cdr(t2);
t6=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,1,t5));}}
else{
/* scrutinizer.scm: 109  global-result */
t3=((C_word*)t0)[2];
f_1438(t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[4]);}}}

/* k1491 in k1468 in variable-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 105  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[20],t1);}

/* k1487 in k1468 in variable-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 103  report */
t2=((C_word*)t0)[4];
f_3413(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1483 in k1468 in variable-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}

/* global-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_1438(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1438,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1442,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 83   ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[17]))(4,*((C_word*)lf[17]+1),t4,t2,lf[18]);}

/* k1440 in global-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1442,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(t1,lf[14]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1454,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1458,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 92   sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),t4,lf[16],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,t1));}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}}

/* k1456 in k1440 in global-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 90   report */
t2=((C_word*)t0)[4];
f_3413(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1452 in k1440 in global-result in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}

/* report in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3413(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3413,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3421,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 392  location-name */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3423(t5,t4,t2);}

/* k3419 in report in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 389  compiler-warning */
((C_proc6)C_retrieve_symbol_proc(lf[11]))(6,*((C_word*)lf[11]+1),((C_word*)t0)[3],lf[12],lf[13],t1,((C_word*)t0)[2]);}

/* location-name in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3423(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3423,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3426,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[8]);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3456,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t2);
/* scrutinizer.scm: 400  lname */
f_3426(t5,t6);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3465,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3465(t8,t1,t2);}}}

/* rec in location-name in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3465(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3465,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
/* scrutinizer.scm: 404  location-name */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3423(t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3482,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
/* scrutinizer.scm: 405  lname */
f_3426(t4,t5);}}

/* k3480 in rec in location-name in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3486,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm: 405  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3465(t4,t2,t3);}

/* k3484 in k3480 in rec in location-name in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 405  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[3],lf[10],((C_word*)t0)[2],t1);}

/* k3454 in location-name in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 400  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[9],t1);}

/* lname in location-name in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_fcall f_3426(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3426,NULL,2,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3437,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 396  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[6]))(3,*((C_word*)lf[6]+1),t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[7]);}}

/* k3435 in lname in location-name in ##compiler#scrutinize in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 396  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[5],t1);}

/* d in k1317 in k1314 in k1311 in k1308 in k1305 in k1302 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_1321r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1321r(t0,t1,t2,t3);}}

static void C_ccall f_1321r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
if(C_truep((C_word)C_fudge(C_fix(13)))){
/* scrutinizer.scm: 36   printf */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[2],t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[237] = {
{"toplevel:scrutinizer_scm",(void*)C_scrutinizer_toplevel},
{"f_1304:scrutinizer_scm",(void*)f_1304},
{"f_1307:scrutinizer_scm",(void*)f_1307},
{"f_1310:scrutinizer_scm",(void*)f_1310},
{"f_1313:scrutinizer_scm",(void*)f_1313},
{"f_1316:scrutinizer_scm",(void*)f_1316},
{"f_1319:scrutinizer_scm",(void*)f_1319},
{"f_4700:scrutinizer_scm",(void*)f_4700},
{"f_4704:scrutinizer_scm",(void*)f_4704},
{"f_4758:scrutinizer_scm",(void*)f_4758},
{"f_4707:scrutinizer_scm",(void*)f_4707},
{"f_4713:scrutinizer_scm",(void*)f_4713},
{"f_4751:scrutinizer_scm",(void*)f_4751},
{"f_4718:scrutinizer_scm",(void*)f_4718},
{"f_4725:scrutinizer_scm",(void*)f_4725},
{"f_4737:scrutinizer_scm",(void*)f_4737},
{"f_4731:scrutinizer_scm",(void*)f_4731},
{"f_1333:scrutinizer_scm",(void*)f_1333},
{"f_4154:scrutinizer_scm",(void*)f_4154},
{"f_4671:scrutinizer_scm",(void*)f_4671},
{"f_4669:scrutinizer_scm",(void*)f_4669},
{"f_4612:scrutinizer_scm",(void*)f_4612},
{"f_4650:scrutinizer_scm",(void*)f_4650},
{"f_4624:scrutinizer_scm",(void*)f_4624},
{"f_4640:scrutinizer_scm",(void*)f_4640},
{"f_4632:scrutinizer_scm",(void*)f_4632},
{"f_4636:scrutinizer_scm",(void*)f_4636},
{"f_4615:scrutinizer_scm",(void*)f_4615},
{"f_4524:scrutinizer_scm",(void*)f_4524},
{"f_4586:scrutinizer_scm",(void*)f_4586},
{"f_4590:scrutinizer_scm",(void*)f_4590},
{"f_4527:scrutinizer_scm",(void*)f_4527},
{"f_4578:scrutinizer_scm",(void*)f_4578},
{"f_4552:scrutinizer_scm",(void*)f_4552},
{"f_4559:scrutinizer_scm",(void*)f_4559},
{"f_4533:scrutinizer_scm",(void*)f_4533},
{"f_4539:scrutinizer_scm",(void*)f_4539},
{"f_4442:scrutinizer_scm",(void*)f_4442},
{"f_4502:scrutinizer_scm",(void*)f_4502},
{"f_4449:scrutinizer_scm",(void*)f_4449},
{"f_4495:scrutinizer_scm",(void*)f_4495},
{"f_4487:scrutinizer_scm",(void*)f_4487},
{"f_4485:scrutinizer_scm",(void*)f_4485},
{"f_4452:scrutinizer_scm",(void*)f_4452},
{"f_4474:scrutinizer_scm",(void*)f_4474},
{"f_4478:scrutinizer_scm",(void*)f_4478},
{"f_4455:scrutinizer_scm",(void*)f_4455},
{"f_4462:scrutinizer_scm",(void*)f_4462},
{"f_4360:scrutinizer_scm",(void*)f_4360},
{"f_4420:scrutinizer_scm",(void*)f_4420},
{"f_4404:scrutinizer_scm",(void*)f_4404},
{"f_4408:scrutinizer_scm",(void*)f_4408},
{"f_4381:scrutinizer_scm",(void*)f_4381},
{"f_4396:scrutinizer_scm",(void*)f_4396},
{"f_4378:scrutinizer_scm",(void*)f_4378},
{"f_4345:scrutinizer_scm",(void*)f_4345},
{"f_4234:scrutinizer_scm",(void*)f_4234},
{"f_4237:scrutinizer_scm",(void*)f_4237},
{"f_4240:scrutinizer_scm",(void*)f_4240},
{"f_4243:scrutinizer_scm",(void*)f_4243},
{"f_4249:scrutinizer_scm",(void*)f_4249},
{"f_4319:scrutinizer_scm",(void*)f_4319},
{"f_4315:scrutinizer_scm",(void*)f_4315},
{"f_4276:scrutinizer_scm",(void*)f_4276},
{"f_4287:scrutinizer_scm",(void*)f_4287},
{"f_4283:scrutinizer_scm",(void*)f_4283},
{"f_4252:scrutinizer_scm",(void*)f_4252},
{"f_4257:scrutinizer_scm",(void*)f_4257},
{"f_4183:scrutinizer_scm",(void*)f_4183},
{"f_4170:scrutinizer_scm",(void*)f_4170},
{"f_4122:scrutinizer_scm",(void*)f_4122},
{"f_3579:scrutinizer_scm",(void*)f_3579},
{"f_3809:scrutinizer_scm",(void*)f_3809},
{"f_3801:scrutinizer_scm",(void*)f_3801},
{"f_3797:scrutinizer_scm",(void*)f_3797},
{"f_3776:scrutinizer_scm",(void*)f_3776},
{"f_3787:scrutinizer_scm",(void*)f_3787},
{"f_3783:scrutinizer_scm",(void*)f_3783},
{"f_3638:scrutinizer_scm",(void*)f_3638},
{"f_3657:scrutinizer_scm",(void*)f_3657},
{"f_3761:scrutinizer_scm",(void*)f_3761},
{"f_3757:scrutinizer_scm",(void*)f_3757},
{"f_3664:scrutinizer_scm",(void*)f_3664},
{"f_3683:scrutinizer_scm",(void*)f_3683},
{"f_3714:scrutinizer_scm",(void*)f_3714},
{"f_3729:scrutinizer_scm",(void*)f_3729},
{"f_3721:scrutinizer_scm",(void*)f_3721},
{"f_3696:scrutinizer_scm",(void*)f_3696},
{"f_3667:scrutinizer_scm",(void*)f_3667},
{"f_4046:scrutinizer_scm",(void*)f_4046},
{"f_4093:scrutinizer_scm",(void*)f_4093},
{"f_4056:scrutinizer_scm",(void*)f_4056},
{"f_4083:scrutinizer_scm",(void*)f_4083},
{"f_3670:scrutinizer_scm",(void*)f_3670},
{"f_3643:scrutinizer_scm",(void*)f_3643},
{"f_3582:scrutinizer_scm",(void*)f_3582},
{"f_3590:scrutinizer_scm",(void*)f_3590},
{"f_3597:scrutinizer_scm",(void*)f_3597},
{"f_3600:scrutinizer_scm",(void*)f_3600},
{"f_3594:scrutinizer_scm",(void*)f_3594},
{"f_3861:scrutinizer_scm",(void*)f_3861},
{"f_3993:scrutinizer_scm",(void*)f_3993},
{"f_3896:scrutinizer_scm",(void*)f_3896},
{"f_3957:scrutinizer_scm",(void*)f_3957},
{"f_3968:scrutinizer_scm",(void*)f_3968},
{"f_3926:scrutinizer_scm",(void*)f_3926},
{"f_3887:scrutinizer_scm",(void*)f_3887},
{"f_3878:scrutinizer_scm",(void*)f_3878},
{"f_3365:scrutinizer_scm",(void*)f_3365},
{"f_3407:scrutinizer_scm",(void*)f_3407},
{"f_3400:scrutinizer_scm",(void*)f_3400},
{"f_3397:scrutinizer_scm",(void*)f_3397},
{"f_3393:scrutinizer_scm",(void*)f_3393},
{"f_2970:scrutinizer_scm",(void*)f_2970},
{"f_3004:scrutinizer_scm",(void*)f_3004},
{"f_2760:scrutinizer_scm",(void*)f_2760},
{"f_2825:scrutinizer_scm",(void*)f_2825},
{"f_2933:scrutinizer_scm",(void*)f_2933},
{"f_2766:scrutinizer_scm",(void*)f_2766},
{"f_2784:scrutinizer_scm",(void*)f_2784},
{"f_2810:scrutinizer_scm",(void*)f_2810},
{"f_2791:scrutinizer_scm",(void*)f_2791},
{"f_2798:scrutinizer_scm",(void*)f_2798},
{"f_2772:scrutinizer_scm",(void*)f_2772},
{"f_2778:scrutinizer_scm",(void*)f_2778},
{"f_2488:scrutinizer_scm",(void*)f_2488},
{"f_2575:scrutinizer_scm",(void*)f_2575},
{"f_2594:scrutinizer_scm",(void*)f_2594},
{"f_2631:scrutinizer_scm",(void*)f_2631},
{"f_2691:scrutinizer_scm",(void*)f_2691},
{"f_2682:scrutinizer_scm",(void*)f_2682},
{"f_2673:scrutinizer_scm",(void*)f_2673},
{"f_2664:scrutinizer_scm",(void*)f_2664},
{"f_2658:scrutinizer_scm",(void*)f_2658},
{"f_2599:scrutinizer_scm",(void*)f_2599},
{"f_2580:scrutinizer_scm",(void*)f_2580},
{"f_2479:scrutinizer_scm",(void*)f_2479},
{"f_2483:scrutinizer_scm",(void*)f_2483},
{"f_2413:scrutinizer_scm",(void*)f_2413},
{"f_2442:scrutinizer_scm",(void*)f_2442},
{"f_2446:scrutinizer_scm",(void*)f_2446},
{"f_2211:scrutinizer_scm",(void*)f_2211},
{"f_2371:scrutinizer_scm",(void*)f_2371},
{"f_2375:scrutinizer_scm",(void*)f_2375},
{"f_2307:scrutinizer_scm",(void*)f_2307},
{"f_2318:scrutinizer_scm",(void*)f_2318},
{"f_2326:scrutinizer_scm",(void*)f_2326},
{"f_2322:scrutinizer_scm",(void*)f_2322},
{"f_2246:scrutinizer_scm",(void*)f_2246},
{"f_2257:scrutinizer_scm",(void*)f_2257},
{"f_1751:scrutinizer_scm",(void*)f_1751},
{"f_1757:scrutinizer_scm",(void*)f_1757},
{"f_2144:scrutinizer_scm",(void*)f_2144},
{"f_2122:scrutinizer_scm",(void*)f_2122},
{"f_2112:scrutinizer_scm",(void*)f_2112},
{"f_1792:scrutinizer_scm",(void*)f_1792},
{"f_2038:scrutinizer_scm",(void*)f_2038},
{"f_2042:scrutinizer_scm",(void*)f_2042},
{"f_2048:scrutinizer_scm",(void*)f_2048},
{"f_1906:scrutinizer_scm",(void*)f_1906},
{"f_1948:scrutinizer_scm",(void*)f_1948},
{"f_2020:scrutinizer_scm",(void*)f_2020},
{"f_1973:scrutinizer_scm",(void*)f_1973},
{"f_2010:scrutinizer_scm",(void*)f_2010},
{"f_1986:scrutinizer_scm",(void*)f_1986},
{"f_1909:scrutinizer_scm",(void*)f_1909},
{"f_1938:scrutinizer_scm",(void*)f_1938},
{"f_1936:scrutinizer_scm",(void*)f_1936},
{"f_1929:scrutinizer_scm",(void*)f_1929},
{"f_1895:scrutinizer_scm",(void*)f_1895},
{"f_1798:scrutinizer_scm",(void*)f_1798},
{"f_1803:scrutinizer_scm",(void*)f_1803},
{"f_1886:scrutinizer_scm",(void*)f_1886},
{"f_1868:scrutinizer_scm",(void*)f_1868},
{"f_1841:scrutinizer_scm",(void*)f_1841},
{"f_1837:scrutinizer_scm",(void*)f_1837},
{"f_1742:scrutinizer_scm",(void*)f_1742},
{"f_1746:scrutinizer_scm",(void*)f_1746},
{"f_2149:scrutinizer_scm",(void*)f_2149},
{"f_2172:scrutinizer_scm",(void*)f_2172},
{"f_2189:scrutinizer_scm",(void*)f_2189},
{"f_3025:scrutinizer_scm",(void*)f_3025},
{"f_3132:scrutinizer_scm",(void*)f_3132},
{"f_3267:scrutinizer_scm",(void*)f_3267},
{"f_3148:scrutinizer_scm",(void*)f_3148},
{"f_3153:scrutinizer_scm",(void*)f_3153},
{"f_3181:scrutinizer_scm",(void*)f_3181},
{"f_3101:scrutinizer_scm",(void*)f_3101},
{"f_3819:scrutinizer_scm",(void*)f_3819},
{"f_1714:scrutinizer_scm",(void*)f_1714},
{"f_1740:scrutinizer_scm",(void*)f_1740},
{"f_1692:scrutinizer_scm",(void*)f_1692},
{"f_1712:scrutinizer_scm",(void*)f_1712},
{"f_1571:scrutinizer_scm",(void*)f_1571},
{"f_1667:scrutinizer_scm",(void*)f_1667},
{"f_1617:scrutinizer_scm",(void*)f_1617},
{"f_1631:scrutinizer_scm",(void*)f_1631},
{"f_1635:scrutinizer_scm",(void*)f_1635},
{"f_1551:scrutinizer_scm",(void*)f_1551},
{"f_1555:scrutinizer_scm",(void*)f_1555},
{"f_1569:scrutinizer_scm",(void*)f_1569},
{"f_1565:scrutinizer_scm",(void*)f_1565},
{"f_1558:scrutinizer_scm",(void*)f_1558},
{"f_3559:scrutinizer_scm",(void*)f_3559},
{"f_3569:scrutinizer_scm",(void*)f_3569},
{"f_3577:scrutinizer_scm",(void*)f_3577},
{"f_3567:scrutinizer_scm",(void*)f_3567},
{"f_3505:scrutinizer_scm",(void*)f_3505},
{"f_3509:scrutinizer_scm",(void*)f_3509},
{"f_3514:scrutinizer_scm",(void*)f_3514},
{"f_3553:scrutinizer_scm",(void*)f_3553},
{"f_3549:scrutinizer_scm",(void*)f_3549},
{"f_3541:scrutinizer_scm",(void*)f_3541},
{"f_1519:scrutinizer_scm",(void*)f_1519},
{"f_1526:scrutinizer_scm",(void*)f_1526},
{"f_1463:scrutinizer_scm",(void*)f_1463},
{"f_1510:scrutinizer_scm",(void*)f_1510},
{"f_1517:scrutinizer_scm",(void*)f_1517},
{"f_1470:scrutinizer_scm",(void*)f_1470},
{"f_1493:scrutinizer_scm",(void*)f_1493},
{"f_1489:scrutinizer_scm",(void*)f_1489},
{"f_1485:scrutinizer_scm",(void*)f_1485},
{"f_1438:scrutinizer_scm",(void*)f_1438},
{"f_1442:scrutinizer_scm",(void*)f_1442},
{"f_1458:scrutinizer_scm",(void*)f_1458},
{"f_1454:scrutinizer_scm",(void*)f_1454},
{"f_3413:scrutinizer_scm",(void*)f_3413},
{"f_3421:scrutinizer_scm",(void*)f_3421},
{"f_3423:scrutinizer_scm",(void*)f_3423},
{"f_3465:scrutinizer_scm",(void*)f_3465},
{"f_3482:scrutinizer_scm",(void*)f_3482},
{"f_3486:scrutinizer_scm",(void*)f_3486},
{"f_3456:scrutinizer_scm",(void*)f_3456},
{"f_3426:scrutinizer_scm",(void*)f_3426},
{"f_3437:scrutinizer_scm",(void*)f_3437},
{"f_1321:scrutinizer_scm",(void*)f_1321},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
