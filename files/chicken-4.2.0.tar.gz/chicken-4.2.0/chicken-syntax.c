/* Generated from chicken-syntax.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:25
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: chicken-syntax.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -output-file chicken-syntax.c
   unit: chicken_syntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[246];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,28),40,97,49,55,53,53,32,102,111,114,109,49,53,54,57,32,114,49,53,55,48,32,99,49,53,55,49,41,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,32),40,97,49,56,48,49,32,110,97,109,101,49,53,54,54,32,116,114,97,110,115,102,111,114,109,101,114,49,53,54,55,41};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,20),40,97,49,56,49,49,32,116,101,109,112,49,53,48,57,49,53,54,48,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,20),40,97,49,56,50,53,32,116,101,109,112,49,53,48,57,49,53,53,54,41,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,53,48,52,32,108,49,52,57,57,49,53,51,50,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,52),40,97,49,55,54,53,32,105,110,112,117,116,49,52,57,56,49,53,49,49,32,114,101,110,97,109,101,49,53,48,55,49,53,49,50,32,99,111,109,112,97,114,101,49,52,57,53,49,53,49,51,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,52),40,97,49,57,49,50,32,105,110,112,117,116,49,52,51,55,49,52,53,48,32,114,101,110,97,109,101,49,52,52,54,49,52,53,49,32,99,111,109,112,97,114,101,49,52,51,52,49,52,53,50,41,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,25),40,97,50,48,52,52,32,120,49,52,50,51,32,114,49,52,50,52,32,99,49,52,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,28),40,97,50,48,54,57,32,102,111,114,109,49,52,49,52,32,114,49,52,49,53,32,99,49,52,49,54,41,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,28),40,97,50,49,48,54,32,102,111,114,109,49,51,57,56,32,114,49,51,57,57,32,99,49,52,48,48,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,37),40,108,111,111,112,32,115,49,51,52,55,32,100,49,51,52,56,32,99,115,49,51,52,57,32,101,120,112,111,114,116,115,49,51,53,48,41,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,28),40,97,50,50,49,48,32,102,111,114,109,49,51,51,53,32,114,49,51,51,54,32,99,49,51,51,55,41,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,47),40,108,111,111,112,32,120,115,49,51,48,51,32,118,97,114,115,49,51,48,52,32,98,115,49,51,48,53,32,118,97,108,115,49,51,48,54,32,114,101,115,116,49,51,48,55,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,28),40,97,50,52,57,49,32,102,111,114,109,49,50,57,49,32,114,49,50,57,50,32,99,49,50,57,51,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,40),40,108,111,111,112,32,120,115,49,50,53,56,32,118,97,114,115,49,50,53,57,32,118,97,108,115,49,50,54,48,32,114,101,115,116,49,50,54,49,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,28),40,97,50,55,50,50,32,102,111,114,109,49,50,52,54,32,114,49,50,52,55,32,99,49,50,52,56,41,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,115,108,111,116,115,49,50,48,56,32,105,49,50,48,57,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,17),40,97,51,50,56,51,32,115,110,97,109,101,49,50,48,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,28),40,97,50,57,50,50,32,102,111,114,109,49,49,54,56,32,114,49,49,54,57,32,99,49,49,55,48,41,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,13),40,97,51,52,55,53,32,107,49,49,52,56,41,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,20),40,112,97,114,115,101,45,99,108,97,117,115,101,32,99,49,49,50,48,41,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,28),40,97,51,51,50,52,32,102,111,114,109,49,49,48,51,32,114,49,49,48,52,32,99,49,49,48,53,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,28),40,97,51,54,55,56,32,102,111,114,109,49,48,56,54,32,114,49,48,56,55,32,99,49,48,56,56,41,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,28),40,97,51,56,57,50,32,102,111,114,109,49,48,53,55,32,114,49,48,53,56,32,99,49,48,53,57,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,57,53,52,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,14),40,103,101,110,118,97,114,115,32,110,57,53,48,41,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,7),40,97,52,49,52,55,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,27),40,98,117,105,108,100,32,118,97,114,115,50,49,48,50,50,32,118,114,101,115,116,49,48,50,51,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,27),40,97,52,49,53,55,32,118,97,114,115,49,49,48,49,54,32,118,97,114,115,50,49,48,49,55,41,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,31),40,97,52,49,49,53,32,118,97,114,115,57,57,53,32,97,114,103,99,57,57,54,32,114,101,115,116,57,57,55,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,20),40,97,52,49,48,53,32,99,57,57,50,32,98,111,100,121,57,57,51,41,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,31),40,97,52,52,48,48,32,118,97,114,115,57,54,50,32,97,114,103,99,57,54,51,32,114,101,115,116,57,54,52,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,12),40,97,52,51,57,48,32,99,57,54,48,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,25),40,97,51,57,57,52,32,102,111,114,109,57,52,52,32,114,57,52,53,32,99,57,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,97,114,103,115,57,49,56,32,118,97,114,100,101,102,115,57,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,25),40,97,52,52,53,57,32,102,111,114,109,56,57,55,32,114,56,57,56,32,99,56,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,25),40,97,52,55,55,51,32,102,111,114,109,56,55,50,32,114,56,55,51,32,99,56,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,54),40,114,101,99,117,114,32,118,97,114,115,55,57,53,32,100,101,102,97,117,108,116,101,114,45,110,97,109,101,115,55,57,54,32,100,101,102,115,55,57,55,32,110,101,120,116,45,103,117,121,55,57,56,41,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,68),40,109,97,107,101,45,100,101,102,97,117,108,116,45,112,114,111,99,115,32,118,97,114,115,55,56,55,32,98,111,100,121,45,112,114,111,99,55,56,56,32,100,101,102,97,117,108,116,101,114,45,110,97,109,101,115,55,56,57,32,100,101,102,115,55,57,48,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,45),40,114,101,99,117,114,32,118,97,114,115,56,49,54,32,100,101,102,97,117,108,116,101,114,115,56,49,55,32,110,111,110,45,100,101,102,97,117,108,116,115,56,49,56,41,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,57),40,109,97,107,101,45,105,102,45,116,114,101,101,32,118,97,114,115,56,48,56,32,100,101,102,97,117,108,116,101,114,115,56,48,57,32,98,111,100,121,45,112,114,111,99,56,49,48,32,114,101,115,116,56,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,29),40,112,114,101,102,105,120,45,115,121,109,32,112,114,101,102,105,120,56,51,54,32,115,121,109,56,51,55,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,14),40,97,53,52,48,57,32,118,97,114,56,53,49,41,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,12),40,97,53,52,49,57,32,118,56,52,49,41,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,25),40,97,52,57,57,56,32,102,111,114,109,55,55,52,32,114,55,55,53,32,99,55,55,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,12),40,97,53,53,56,49,32,120,55,54,48,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,19),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,55,52,55,41,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,25),40,97,53,52,53,51,32,102,111,114,109,55,50,57,32,114,55,51,48,32,99,55,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,12),40,102,111,108,100,32,98,115,54,57,54,41,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,25),40,97,53,54,49,57,32,102,111,114,109,54,56,53,32,114,54,56,54,32,99,54,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,26),40,113,117,111,116,105,102,121,45,112,114,111,99,32,120,115,54,53,52,32,105,100,54,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,25),40,97,53,55,56,50,32,102,111,114,109,54,52,54,32,114,54,52,55,32,99,54,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,25),40,97,53,56,56,55,32,102,111,114,109,54,51,52,32,114,54,51,53,32,99,54,51,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,13),40,108,111,111,107,117,112,32,118,54,48,55,41,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,12),40,97,54,48,54,52,32,118,54,50,51,41,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,13),40,97,54,48,50,54,32,118,98,54,49,55,41,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,12),40,97,54,49,48,50,32,118,54,49,53,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,12),40,97,54,49,48,56,32,118,54,48,51,41,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,12),40,97,54,49,50,54,32,120,53,57,57,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,25),40,97,53,57,55,48,32,102,111,114,109,53,56,56,32,114,53,56,57,32,99,53,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,19),40,102,111,108,100,32,118,98,105,110,100,105,110,103,115,53,55,53,41,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,25),40,97,54,49,51,54,32,102,111,114,109,53,54,52,32,114,53,54,53,32,99,53,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,97,112,112,101,110,100,42,32,105,108,52,53,56,32,108,52,53,57,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,19),40,109,97,112,42,32,112,114,111,99,52,54,49,32,108,52,54,50,41,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,13),40,108,111,111,107,117,112,32,118,53,48,50,41,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,12),40,97,54,51,53,48,32,118,53,52,53,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,35),40,102,111,108,100,32,108,108,105,115,116,115,53,51,48,32,101,120,112,115,53,51,49,32,108,108,105,115,116,115,50,53,51,50,41,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,12),40,97,54,52,56,54,32,120,53,53,57,41,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,53,48,56,32,97,99,99,53,48,57,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,12),40,97,54,53,51,56,32,118,52,57,56,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,52,55,56,32,97,99,99,52,55,57,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,25),40,97,54,50,48,56,32,102,111,114,109,52,52,54,32,114,52,52,55,32,99,52,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,18),40,97,54,54,50,48,32,103,52,51,54,52,51,55,52,51,56,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,25),40,97,54,53,57,54,32,102,111,114,109,52,50,55,32,114,52,50,56,32,99,52,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,17),40,97,54,55,53,51,32,118,52,49,57,32,97,52,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,25),40,97,54,54,51,56,32,102,111,114,109,51,57,48,32,114,51,57,49,32,99,51,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,25),40,97,54,55,56,51,32,102,111,114,109,51,56,49,32,114,51,56,50,32,99,51,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,25),40,97,54,56,51,54,32,102,111,114,109,51,55,50,32,114,51,55,51,32,99,51,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,18),40,97,54,57,57,55,32,97,51,54,52,32,97,50,51,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,12),40,97,55,48,53,57,32,122,51,53,54,41,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,12),40,97,55,48,54,57,32,122,51,53,50,41,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,25),40,97,54,56,56,49,32,102,111,114,109,51,51,50,32,114,51,51,51,32,99,51,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,115,115,50,57,57,41,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,25),40,97,55,48,56,51,32,102,111,114,109,50,54,57,32,114,50,55,48,32,99,50,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,19),40,97,55,51,48,50,32,105,100,50,54,49,32,111,116,50,54,50,41,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,19),40,97,55,51,49,54,32,110,116,50,53,52,32,105,100,50,53,53,41,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,19),40,97,55,51,54,54,32,105,100,50,52,55,32,110,116,50,52,56,41,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,19),40,97,55,51,56,48,32,111,116,50,52,48,32,105,100,50,52,49,41,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,110,50,51,54,41,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,12),40,97,55,52,51,56,32,120,50,50,50,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,12),40,97,55,52,52,56,32,120,50,49,56,41,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,25),40,97,55,50,48,52,32,102,111,114,109,50,48,54,32,114,50,48,55,32,99,50,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,25),40,97,55,52,54,50,32,102,111,114,109,49,56,54,32,114,49,56,55,32,99,49,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,25),40,97,55,53,57,57,32,102,111,114,109,49,54,49,32,114,49,54,50,32,99,49,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,7),40,97,55,55,52,50,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,22),40,100,111,108,111,111,112,49,52,52,32,120,49,53,49,32,120,115,49,53,50,41,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,7),40,97,55,55,52,55,41,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,7),40,97,55,55,56,48,41,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,7),40,97,55,55,51,54,41,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,25),40,97,55,55,49,48,32,102,111,114,109,49,49,56,32,114,49,49,57,32,99,49,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,25),40,97,55,55,57,57,32,102,111,114,109,49,49,48,32,114,49,49,49,32,99,49,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,23),40,97,55,56,49,55,32,102,111,114,109,57,56,32,114,57,57,32,99,49,48,48,41,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,22),40,97,55,57,49,54,32,102,111,114,109,54,52,32,114,54,53,32,99,54,54,41,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,22),40,109,97,112,115,108,111,116,115,32,115,108,111,116,115,51,56,32,105,51,57,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,17),40,97,56,48,53,57,32,120,56,32,114,57,32,99,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_chicken_syntax_toplevel)
C_externexport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1626)
static void C_ccall f_1626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8060)
static void C_ccall f_8060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8064)
static void C_ccall f_8064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8073)
static void C_ccall f_8073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8076)
static void C_ccall f_8076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8082)
static void C_ccall f_8082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8085)
static void C_ccall f_8085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8088)
static void C_ccall f_8088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8091)
static void C_ccall f_8091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8501)
static void C_ccall f_8501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8461)
static void C_ccall f_8461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8493)
static void C_ccall f_8493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8453)
static void C_ccall f_8453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8409)
static void C_ccall f_8409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8120)
static void C_fcall f_8120(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8130)
static void C_ccall f_8130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8397)
static void C_ccall f_8397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8393)
static void C_ccall f_8393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8136)
static void C_ccall f_8136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8183)
static void C_fcall f_8183(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8147)
static void C_ccall f_8147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8118)
static void C_ccall f_8118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8114)
static void C_ccall f_8114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8058)
static void C_ccall f_8058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1633)
static void C_ccall f_1633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7917)
static void C_ccall f_7917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7921)
static void C_ccall f_7921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7924)
static void C_ccall f_7924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7927)
static void C_ccall f_7927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7963)
static void C_ccall f_7963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7978)
static void C_fcall f_7978(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8032)
static void C_ccall f_8032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7993)
static void C_ccall f_7993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7956)
static void C_ccall f_7956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7915)
static void C_ccall f_7915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7818)
static void C_ccall f_7818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7822)
static void C_ccall f_7822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7825)
static void C_ccall f_7825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7828)
static void C_ccall f_7828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7816)
static void C_ccall f_7816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1639)
static void C_ccall f_1639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7800)
static void C_ccall f_7800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7808)
static void C_ccall f_7808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7798)
static void C_ccall f_7798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7711)
static void C_ccall f_7711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7715)
static void C_ccall f_7715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7718)
static void C_ccall f_7718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7721)
static void C_ccall f_7721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7787)
static void C_ccall f_7787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7724)
static void C_ccall f_7724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7737)
static void C_ccall f_7737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7781)
static void C_ccall f_7781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7748)
static void C_ccall f_7748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7756)
static void C_ccall f_7756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7758)
static void C_fcall f_7758(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7775)
static void C_ccall f_7775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7743)
static void C_ccall f_7743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7735)
static void C_ccall f_7735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7731)
static void C_ccall f_7731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7709)
static void C_ccall f_7709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7600)
static void C_ccall f_7600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7604)
static void C_ccall f_7604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7613)
static void C_ccall f_7613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7616)
static void C_ccall f_7616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7619)
static void C_fcall f_7619(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7662)
static void C_ccall f_7662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7598)
static void C_ccall f_7598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7463)
static void C_ccall f_7463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7467)
static void C_ccall f_7467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7479)
static void C_ccall f_7479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7482)
static void C_ccall f_7482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7485)
static void C_ccall f_7485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7536)
static void C_fcall f_7536(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7532)
static void C_ccall f_7532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7461)
static void C_ccall f_7461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1651)
static void C_ccall f_1651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7205)
static void C_ccall f_7205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7209)
static void C_ccall f_7209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7218)
static void C_ccall f_7218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7449)
static void C_ccall f_7449(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7457)
static void C_ccall f_7457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7221)
static void C_ccall f_7221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7439)
static void C_ccall f_7439(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7447)
static void C_ccall f_7447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7224)
static void C_ccall f_7224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7227)
static void C_ccall f_7227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7230)
static void C_ccall f_7230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7437)
static void C_ccall f_7437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7397)
static void C_ccall f_7397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7415)
static void C_fcall f_7415(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7429)
static void C_ccall f_7429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7409)
static void C_ccall f_7409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7405)
static void C_ccall f_7405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7401)
static void C_ccall f_7401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7241)
static void C_ccall f_7241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7381)
static void C_ccall f_7381(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7349)
static void C_ccall f_7349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7367)
static void C_ccall f_7367(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7357)
static void C_ccall f_7357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7353)
static void C_ccall f_7353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7345)
static void C_ccall f_7345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7337)
static void C_ccall f_7337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7317)
static void C_ccall f_7317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7285)
static void C_ccall f_7285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7303)
static void C_ccall f_7303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7293)
static void C_ccall f_7293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7289)
static void C_ccall f_7289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7281)
static void C_ccall f_7281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7203)
static void C_ccall f_7203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7084)
static void C_ccall f_7084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7088)
static void C_ccall f_7088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7094)
static void C_ccall f_7094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7195)
static void C_ccall f_7195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7100)
static void C_ccall f_7100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7103)
static void C_ccall f_7103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7106)
static void C_ccall f_7106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7146)
static void C_fcall f_7146(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7169)
static void C_ccall f_7169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7176)
static void C_ccall f_7176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7183)
static void C_ccall f_7183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7159)
static void C_ccall f_7159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7109)
static void C_ccall f_7109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7082)
static void C_ccall f_7082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6882)
static void C_ccall f_6882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6886)
static void C_ccall f_6886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6895)
static void C_ccall f_6895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6898)
static void C_ccall f_6898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6901)
static void C_ccall f_6901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6904)
static void C_ccall f_6904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6907)
static void C_ccall f_6907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7070)
static void C_ccall f_7070(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7078)
static void C_ccall f_7078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6910)
static void C_ccall f_6910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7060)
static void C_ccall f_7060(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7068)
static void C_ccall f_7068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6913)
static void C_ccall f_6913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7054)
static void C_ccall f_7054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6998)
static void C_ccall f_6998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6996)
static void C_ccall f_6996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6992)
static void C_ccall f_6992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6972)
static void C_ccall f_6972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6880)
static void C_ccall f_6880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6837)
static void C_ccall f_6837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6841)
static void C_ccall f_6841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6848)
static void C_ccall f_6848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6868)
static void C_ccall f_6868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6835)
static void C_ccall f_6835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1663)
static void C_ccall f_1663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6784)
static void C_ccall f_6784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6788)
static void C_ccall f_6788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6795)
static void C_ccall f_6795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6823)
static void C_ccall f_6823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6827)
static void C_ccall f_6827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6782)
static void C_ccall f_6782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6639)
static void C_ccall f_6639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6643)
static void C_ccall f_6643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6652)
static void C_ccall f_6652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6721)
static void C_ccall f_6721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6754)
static void C_ccall f_6754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6752)
static void C_ccall f_6752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6748)
static void C_ccall f_6748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6637)
static void C_ccall f_6637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6597)
static void C_ccall f_6597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6601)
static void C_ccall f_6601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6621)
static void C_ccall f_6621(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6629)
static void C_ccall f_6629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6604)
static void C_ccall f_6604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6611)
static void C_ccall f_6611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6615)
static void C_ccall f_6615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6595)
static void C_ccall f_6595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6209)
static void C_ccall f_6209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6213)
static void C_ccall f_6213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6222)
static void C_ccall f_6222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6300)
static void C_ccall f_6300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6553)
static void C_fcall f_6553(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6566)
static void C_ccall f_6566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6539)
static void C_ccall f_6539(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6551)
static void C_ccall f_6551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6306)
static void C_ccall f_6306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6493)
static void C_fcall f_6493(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6526)
static void C_ccall f_6526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6533)
static void C_ccall f_6533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6509)
static void C_fcall f_6509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6318)
static void C_ccall f_6318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6325)
static void C_ccall f_6325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6327)
static void C_fcall f_6327(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6481)
static void C_ccall f_6481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6365)
static void C_fcall f_6365(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6447)
static void C_ccall f_6447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6404)
static void C_ccall f_6404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6384)
static void C_ccall f_6384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6359)
static void C_ccall f_6359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6345)
static void C_ccall f_6345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6349)
static void C_ccall f_6349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6307)
static void C_ccall f_6307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6258)
static void C_fcall f_6258(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6281)
static void C_ccall f_6281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6227)
static void C_fcall f_6227(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6248)
static void C_ccall f_6248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6207)
static void C_ccall f_6207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6137)
static void C_ccall f_6137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6150)
static void C_ccall f_6150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6153)
static void C_ccall f_6153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6158)
static void C_fcall f_6158(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6195)
static void C_ccall f_6195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6176)
static void C_ccall f_6176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6135)
static void C_ccall f_6135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1678)
static void C_ccall f_1678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5971)
static void C_ccall f_5971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5975)
static void C_ccall f_5975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5984)
static void C_ccall f_5984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5987)
static void C_ccall f_5987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6127)
static void C_ccall f_6127(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5990)
static void C_ccall f_5990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6109)
static void C_ccall f_6109(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6121)
static void C_ccall f_6121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6117)
static void C_ccall f_6117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5993)
static void C_ccall f_5993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6103)
static void C_ccall f_6103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6013)
static void C_ccall f_6013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6027)
static void C_ccall f_6027(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6055)
static void C_ccall f_6055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6065)
static void C_ccall f_6065(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6081)
static void C_ccall f_6081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6063)
static void C_ccall f_6063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6059)
static void C_ccall f_6059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6021)
static void C_ccall f_6021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6025)
static void C_ccall f_6025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6017)
static void C_ccall f_6017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5994)
static void C_ccall f_5994(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5969)
static void C_ccall f_5969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5965)
static void C_ccall f_5965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5888)
static void C_ccall f_5888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5892)
static void C_ccall f_5892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5895)
static void C_ccall f_5895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5898)
static void C_ccall f_5898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5933)
static void C_ccall f_5933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5874)
static void C_ccall f_5874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5870)
static void C_ccall f_5870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5789)
static void C_fcall f_5789(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5793)
static void C_ccall f_5793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5850)
static void C_ccall f_5850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_fcall f_5802(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5814)
static void C_fcall f_5814(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5781)
static void C_ccall f_5781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5620)
static void C_ccall f_5620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5633)
static void C_ccall f_5633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5636)
static void C_ccall f_5636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5641)
static void C_fcall f_5641(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5753)
static void C_ccall f_5753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5715)
static void C_ccall f_5715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5655)
static void C_ccall f_5655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5659)
static void C_ccall f_5659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1690)
static void C_ccall f_1690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5454)
static void C_ccall f_5454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5473)
static void C_ccall f_5473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5476)
static void C_ccall f_5476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5479)
static void C_ccall f_5479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5486)
static void C_ccall f_5486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5504)
static void C_fcall f_5504(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5520)
static void C_ccall f_5520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5582)
static void C_ccall f_5582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5580)
static void C_ccall f_5580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5576)
static void C_ccall f_5576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5564)
static void C_ccall f_5564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5502)
static void C_ccall f_5502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5015)
static void C_ccall f_5015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5321)
static void C_ccall f_5321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5428)
static void C_ccall f_5428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5343)
static void C_ccall f_5343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5349)
static void C_ccall f_5349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5352)
static void C_ccall f_5352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5410)
static void C_ccall f_5410(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5358)
static void C_ccall f_5358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5361)
static void C_ccall f_5361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5368)
static void C_ccall f_5368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5328)
static void C_fcall f_5328(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5340)
static void C_ccall f_5340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5120)
static void C_fcall f_5120(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5126)
static void C_fcall f_5126(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5314)
static void C_ccall f_5314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5302)
static void C_ccall f_5302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5200)
static void C_ccall f_5200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5023)
static void C_fcall f_5023(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5031)
static void C_ccall f_5031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5035)
static void C_ccall f_5035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5041)
static void C_fcall f_5041(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5094)
static void C_ccall f_5094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5110)
static void C_ccall f_5110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4997)
static void C_ccall f_4997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4778)
static void C_ccall f_4778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4941)
static void C_ccall f_4941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4914)
static void C_ccall f_4914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4772)
static void C_ccall f_4772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1699)
static void C_ccall f_1699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4764)
static void C_ccall f_4764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4460)
static void C_ccall f_4460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4476)
static void C_ccall f_4476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4479)
static void C_ccall f_4479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4482)
static void C_ccall f_4482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4488)
static void C_ccall f_4488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4491)
static void C_ccall f_4491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4512)
static void C_fcall f_4512(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4740)
static void C_ccall f_4740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4621)
static void C_ccall f_4621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4578)
static void C_ccall f_4578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4510)
static void C_ccall f_4510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1702)
static void C_ccall f_1702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4450)
static void C_ccall f_4450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4438)
static void C_ccall f_4438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3999)
static void C_ccall f_3999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4401)
static void C_ccall f_4401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4389)
static void C_ccall f_4389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4051)
static void C_ccall f_4051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4069)
static void C_ccall f_4069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4116)
static void C_ccall f_4116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4120)
static void C_ccall f_4120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4134)
static void C_fcall f_4134(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4185)
static void C_fcall f_4185(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4333)
static void C_ccall f_4333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4272)
static void C_ccall f_4272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4210)
static void C_ccall f_4210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4162)
static void C_ccall f_4162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4001)
static void C_fcall f_4001(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4007)
static void C_fcall f_4007(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4021)
static void C_ccall f_4021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1705)
static void C_ccall f_1705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3893)
static void C_ccall f_3893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3935)
static void C_ccall f_3935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3891)
static void C_ccall f_3891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3689)
static void C_ccall f_3689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3823)
static void C_ccall f_3823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3669)
static void C_ccall f_3669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3350)
static void C_ccall f_3350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3525)
static void C_ccall f_3525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3573)
static void C_ccall f_3573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3352)
static void C_ccall f_3352(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3462)
static void C_ccall f_3462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3428)
static void C_fcall f_3428(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3413)
static void C_ccall f_3413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3394)
static void C_ccall f_3394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_fcall f_3379(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2942)
static void C_ccall f_2942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3282)
static void C_ccall f_3282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3278)
static void C_ccall f_3278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2995)
static void C_fcall f_2995(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3021)
static void C_fcall f_3021(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_fcall f_3061(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2921)
static void C_ccall f_2921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2736)
static void C_ccall f_2736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2748)
static void C_fcall f_2748(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2758)
static void C_ccall f_2758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_ccall f_2833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2492)
static void C_ccall f_2492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2517)
static void C_fcall f_2517(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2697)
static void C_ccall f_2697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2490)
static void C_ccall f_2490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_ccall f_1723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_fcall f_2239(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2385)
static void C_fcall f_2385(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2462)
static void C_ccall f_2462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_fcall f_2249(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2364)
static void C_ccall f_2364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2308)
static void C_ccall f_2308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1726)
static void C_ccall f_1726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2105)
static void C_ccall f_2105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_fcall f_1973(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1738)
static void C_ccall f_1738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1859)
static void C_fcall f_1859(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_fcall f_1881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1754)
static void C_ccall f_1754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8120)
static void C_fcall trf_8120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8120(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8120(t0,t1,t2,t3);}

C_noret_decl(trf_8183)
static void C_fcall trf_8183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8183(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8183(t0,t1);}

C_noret_decl(trf_7978)
static void C_fcall trf_7978(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7978(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7978(t0,t1);}

C_noret_decl(trf_7758)
static void C_fcall trf_7758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7758(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7758(t0,t1,t2,t3);}

C_noret_decl(trf_7619)
static void C_fcall trf_7619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7619(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7619(t0,t1);}

C_noret_decl(trf_7536)
static void C_fcall trf_7536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7536(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7536(t0,t1);}

C_noret_decl(trf_7415)
static void C_fcall trf_7415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7415(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7415(t0,t1,t2);}

C_noret_decl(trf_7146)
static void C_fcall trf_7146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7146(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7146(t0,t1,t2);}

C_noret_decl(trf_6553)
static void C_fcall trf_6553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6553(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6553(t0,t1,t2,t3);}

C_noret_decl(trf_6493)
static void C_fcall trf_6493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6493(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6493(t0,t1,t2,t3);}

C_noret_decl(trf_6509)
static void C_fcall trf_6509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6509(t0,t1);}

C_noret_decl(trf_6327)
static void C_fcall trf_6327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6327(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6327(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6365)
static void C_fcall trf_6365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6365(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6365(t0,t1);}

C_noret_decl(trf_6258)
static void C_fcall trf_6258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6258(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6258(t0,t1,t2,t3);}

C_noret_decl(trf_6227)
static void C_fcall trf_6227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6227(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6227(t0,t1,t2,t3);}

C_noret_decl(trf_6158)
static void C_fcall trf_6158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6158(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6158(t0,t1,t2);}

C_noret_decl(trf_5789)
static void C_fcall trf_5789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5789(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5789(t0,t1,t2,t3);}

C_noret_decl(trf_5802)
static void C_fcall trf_5802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5802(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5802(t0,t1);}

C_noret_decl(trf_5814)
static void C_fcall trf_5814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5814(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5814(t0,t1);}

C_noret_decl(trf_5641)
static void C_fcall trf_5641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5641(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5641(t0,t1,t2);}

C_noret_decl(trf_5504)
static void C_fcall trf_5504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5504(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5504(t0,t1,t2);}

C_noret_decl(trf_5328)
static void C_fcall trf_5328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5328(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5328(t0,t1,t2);}

C_noret_decl(trf_5120)
static void C_fcall trf_5120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5120(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5120(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5126)
static void C_fcall trf_5126(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5126(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5126(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5023)
static void C_fcall trf_5023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5023(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5023(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5041)
static void C_fcall trf_5041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5041(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5041(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4512)
static void C_fcall trf_4512(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4512(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4512(t0,t1,t2,t3);}

C_noret_decl(trf_4134)
static void C_fcall trf_4134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4134(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4134(t0,t1);}

C_noret_decl(trf_4185)
static void C_fcall trf_4185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4185(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4185(t0,t1,t2,t3);}

C_noret_decl(trf_4001)
static void C_fcall trf_4001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4001(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4001(t0,t1,t2);}

C_noret_decl(trf_4007)
static void C_fcall trf_4007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4007(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4007(t0,t1,t2);}

C_noret_decl(trf_3428)
static void C_fcall trf_3428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3428(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3428(t0,t1);}

C_noret_decl(trf_3379)
static void C_fcall trf_3379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3379(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3379(t0,t1);}

C_noret_decl(trf_2995)
static void C_fcall trf_2995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2995(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2995(t0,t1,t2,t3);}

C_noret_decl(trf_3021)
static void C_fcall trf_3021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3021(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3021(t0,t1);}

C_noret_decl(trf_3061)
static void C_fcall trf_3061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3061(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3061(t0,t1);}

C_noret_decl(trf_2748)
static void C_fcall trf_2748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2748(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2748(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2517)
static void C_fcall trf_2517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2517(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2517(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2239)
static void C_fcall trf_2239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2239(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2239(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2385)
static void C_fcall trf_2385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2385(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2385(t0,t1);}

C_noret_decl(trf_2249)
static void C_fcall trf_2249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2249(t0,t1);}

C_noret_decl(trf_1973)
static void C_fcall trf_1973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1973(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1973(t0,t1);}

C_noret_decl(trf_1859)
static void C_fcall trf_1859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1859(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1859(t0,t1,t2);}

C_noret_decl(trf_1881)
static void C_fcall trf_1881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1881(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_chicken_syntax_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("chicken_syntax_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3180)){
C_save(t1);
C_rereclaim2(3180*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,246);
lf[0]=C_h_intern(&lf[0],29,"\003syschicken-macro-environment");
lf[1]=C_h_intern(&lf[1],17,"register-feature!");
lf[2]=C_h_intern(&lf[2],6,"srfi-8");
lf[3]=C_h_intern(&lf[3],7,"srfi-16");
lf[4]=C_h_intern(&lf[4],7,"srfi-26");
lf[5]=C_h_intern(&lf[5],7,"srfi-31");
lf[6]=C_h_intern(&lf[6],7,"srfi-15");
lf[7]=C_h_intern(&lf[7],7,"srfi-11");
lf[8]=C_h_intern(&lf[8],16,"\003sysmacro-subset");
lf[9]=C_h_intern(&lf[9],29,"\003sysdefault-macro-environment");
lf[10]=C_h_intern(&lf[10],28,"\003sysextend-macro-environment");
lf[11]=C_h_intern(&lf[11],12,"define-macro");
lf[12]=C_h_intern(&lf[12],12,"syntax-error");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000<`define-macro\047 is not supported - please use `define-syntax\047");
lf[14]=C_h_intern(&lf[14],18,"\003syser-transformer");
lf[15]=C_h_intern(&lf[15],19,"let-compiler-syntax");
lf[16]=C_h_intern(&lf[16],9,"\003sysmap-n");
lf[17]=C_h_intern(&lf[17],24,"\004corelet-compiler-syntax");
lf[18]=C_h_intern(&lf[18],7,"\003sysmap");
lf[19]=C_h_intern(&lf[19],21,"\003syssyntax-error-hook");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\024no rule matches form");
lf[21]=C_h_intern(&lf[21],9,"\003syslist\077");
lf[22]=C_h_intern(&lf[22],9,"\003sysnull\077");
lf[23]=C_h_intern(&lf[23],22,"define-compiler-syntax");
lf[24]=C_h_intern(&lf[24],6,"lambda");
lf[25]=C_h_intern(&lf[25],27,"\004coredefine-compiler-syntax");
lf[26]=C_h_intern(&lf[26],3,"use");
lf[27]=C_h_intern(&lf[27],22,"\004corerequire-extension");
lf[28]=C_h_intern(&lf[28],16,"\003syscheck-syntax");
lf[29]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[30]=C_h_intern(&lf[30],17,"define-for-syntax");
lf[31]=C_h_intern(&lf[31],10,"\003sysappend");
lf[32]=C_h_intern(&lf[32],6,"define");
lf[33]=C_h_intern(&lf[33],16,"begin-for-syntax");
lf[34]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[35]=C_h_intern(&lf[35],3,"rec");
lf[36]=C_h_intern(&lf[36],6,"letrec");
lf[37]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[38]=C_h_intern(&lf[38],16,"define-extension");
lf[39]=C_h_intern(&lf[39],22,"chicken-compile-shared");
lf[40]=C_h_intern(&lf[40],9,"compiling");
lf[41]=C_h_intern(&lf[41],4,"name");
lf[42]=C_h_intern(&lf[42],4,"unit");
lf[43]=C_h_intern(&lf[43],5,"quote");
lf[44]=C_h_intern(&lf[44],7,"provide");
lf[45]=C_h_intern(&lf[45],4,"else");
lf[46]=C_h_intern(&lf[46],3,"not");
lf[47]=C_h_intern(&lf[47],11,"cond-expand");
lf[48]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007unquote\376\003\000\000\002\376\001\000\000\006%begin\376\377\016\376\377\016");
lf[49]=C_h_intern(&lf[49],4,"cdar");
lf[50]=C_h_intern(&lf[50],6,"append");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[52]=C_h_intern(&lf[52],4,"caar");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[54]=C_h_intern(&lf[54],6,"export");
lf[55]=C_h_intern(&lf[55],7,"dynamic");
lf[56]=C_h_intern(&lf[56],6,"static");
lf[57]=C_h_intern(&lf[57],5,"begin");
lf[58]=C_h_intern(&lf[58],7,"declare");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\001_");
lf[60]=C_h_intern(&lf[60],5,"apply");
lf[61]=C_h_intern(&lf[61],4,"cute");
lf[62]=C_h_intern(&lf[62],6,"gensym");
lf[63]=C_h_intern(&lf[63],7,"reverse");
lf[64]=C_h_intern(&lf[64],5,"<...>");
lf[65]=C_h_intern(&lf[65],2,"<>");
lf[66]=C_h_intern(&lf[66],3,"let");
lf[67]=C_h_intern(&lf[67],19,"\003sysprimitive-alias");
lf[68]=C_h_intern(&lf[68],3,"cut");
lf[69]=C_h_intern(&lf[69],18,"getter-with-setter");
lf[70]=C_h_intern(&lf[70],18,"define-record-type");
lf[71]=C_h_intern(&lf[71],18,"\003sysmake-structure");
lf[72]=C_h_intern(&lf[72],14,"\003sysstructure\077");
lf[73]=C_h_intern(&lf[73],15,"\000record-setters");
lf[74]=C_h_intern(&lf[74],12,"\003sysfeatures");
lf[75]=C_h_intern(&lf[75],19,"\003syscheck-structure");
lf[76]=C_h_intern(&lf[76],10,"\004corecheck");
lf[77]=C_h_intern(&lf[77],13,"\003sysblock-ref");
lf[78]=C_h_intern(&lf[78],14,"\003sysblock-set!");
lf[79]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[80]=C_h_intern(&lf[80],3,"car");
lf[81]=C_h_intern(&lf[81],1,"y");
lf[82]=C_h_intern(&lf[82],1,"x");
lf[83]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\010variable\376\001\000"
"\000\001_");
lf[84]=C_h_intern(&lf[84],4,"memv");
lf[85]=C_h_intern(&lf[85],14,"condition-case");
lf[86]=C_h_intern(&lf[86],9,"condition");
lf[87]=C_h_intern(&lf[87],8,"\003sysslot");
lf[88]=C_h_intern(&lf[88],10,"\003syssignal");
lf[89]=C_h_intern(&lf[89],4,"cond");
lf[90]=C_h_intern(&lf[90],17,"handle-exceptions");
lf[91]=C_h_intern(&lf[91],3,"and");
lf[92]=C_h_intern(&lf[92],4,"kvar");
lf[93]=C_h_intern(&lf[93],5,"exvar");
lf[94]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[95]=C_h_intern(&lf[95],30,"call-with-current-continuation");
lf[96]=C_h_intern(&lf[96],22,"with-exception-handler");
lf[97]=C_h_intern(&lf[97],10,"\003sysvalues");
lf[98]=C_h_intern(&lf[98],9,"\003sysapply");
lf[99]=C_h_intern(&lf[99],20,"\003syscall-with-values");
lf[100]=C_h_intern(&lf[100],4,"args");
lf[101]=C_h_intern(&lf[101],1,"k");
lf[102]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[103]=C_h_intern(&lf[103],21,"define-record-printer");
lf[104]=C_h_intern(&lf[104],27,"\003sysregister-record-printer");
lf[105]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[106]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[107]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[108]=C_h_intern(&lf[108],2,">=");
lf[109]=C_h_intern(&lf[109],3,"cdr");
lf[110]=C_h_intern(&lf[110],3,"eq\077");
lf[111]=C_h_intern(&lf[111],11,"case-lambda");
lf[112]=C_h_intern(&lf[112],6,"length");
lf[113]=C_h_intern(&lf[113],9,"split-at!");
lf[114]=C_h_intern(&lf[114],4,"take");
lf[115]=C_h_intern(&lf[115],3,"map");
lf[116]=C_h_intern(&lf[116],4,"list");
lf[117]=C_h_intern(&lf[117],11,"lambda-list");
lf[118]=C_h_intern(&lf[118],25,"\003sysdecompose-lambda-list");
lf[119]=C_h_intern(&lf[119],10,"fold-right");
lf[120]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[121]=C_h_intern(&lf[121],2,"if");
lf[122]=C_h_intern(&lf[122],4,"lvar");
lf[123]=C_h_intern(&lf[123],4,"rvar");
lf[124]=C_h_intern(&lf[124],3,"min");
lf[125]=C_h_intern(&lf[125],7,"require");
lf[126]=C_h_intern(&lf[126],6,"srfi-1");
lf[127]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[128]=C_h_intern(&lf[128],5,"null\077");
lf[129]=C_h_intern(&lf[129],14,"let-optionals*");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[131]=C_h_intern(&lf[131],14,"\004coreimmutable");
lf[132]=C_h_intern(&lf[132],9,"\003syserror");
lf[133]=C_h_intern(&lf[133],4,"tmp2");
lf[134]=C_h_intern(&lf[134],3,"tmp");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[136]=C_h_intern(&lf[136],8,"optional");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[139]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[140]=C_h_intern(&lf[140],13,"let-optionals");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[142]=C_h_intern(&lf[142],14,"string->symbol");
lf[143]=C_h_intern(&lf[143],13,"string-append");
lf[144]=C_h_intern(&lf[144],14,"symbol->string");
lf[145]=C_h_intern(&lf[145],4,"let*");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[147]=C_h_intern(&lf[147],5,"%rest");
lf[148]=C_h_intern(&lf[148],4,"body");
lf[149]=C_h_intern(&lf[149],4,"cadr");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[151]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[152]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[154]=C_h_intern(&lf[154],6,"select");
lf[155]=C_h_intern(&lf[155],8,"\003syseqv\077");
lf[156]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[157]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[158]=C_h_intern(&lf[158],2,"or");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[160]=C_h_intern(&lf[160],8,"and-let*");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[162]=C_h_intern(&lf[162],13,"define-inline");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[164]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[165]=C_h_intern(&lf[165],18,"\004coredefine-inline");
lf[166]=C_h_intern(&lf[166],8,"list-ref");
lf[167]=C_h_intern(&lf[167],9,"nth-value");
lf[168]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[169]=C_h_intern(&lf[169],13,"letrec-values");
lf[170]=C_h_intern(&lf[170],9,"\004coreset!");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[173]=C_h_intern(&lf[173],11,"let*-values");
lf[174]=C_h_intern(&lf[174],10,"let-values");
lf[175]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[176]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[177]=C_h_intern(&lf[177],13,"define-values");
lf[178]=C_h_intern(&lf[178],11,"set!-values");
lf[179]=C_h_intern(&lf[179],19,"\003sysregister-export");
lf[180]=C_h_intern(&lf[180],18,"\003syscurrent-module");
lf[181]=C_h_intern(&lf[181],12,"\003sysfor-each");
lf[182]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[183]=C_h_intern(&lf[183],14,"\004coreundefined");
lf[184]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[185]=C_h_intern(&lf[185],6,"unless");
lf[186]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[187]=C_h_intern(&lf[187],4,"when");
lf[188]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[189]=C_h_intern(&lf[189],12,"parameterize");
lf[190]=C_h_intern(&lf[190],16,"\003sysdynamic-wind");
lf[191]=C_h_intern(&lf[191],1,"t");
lf[192]=C_h_intern(&lf[192],8,"\003syslist");
lf[193]=C_h_intern(&lf[193],4,"swap");
lf[194]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[195]=C_h_intern(&lf[195],9,"eval-when");
lf[196]=C_h_intern(&lf[196],10,"\000compiling");
lf[197]=C_h_intern(&lf[197],19,"\004corecompiletimetoo");
lf[198]=C_h_intern(&lf[198],20,"\004corecompiletimeonly");
lf[199]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[200]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[202]=C_h_intern(&lf[202],4,"load");
lf[203]=C_h_intern(&lf[203],7,"compile");
lf[204]=C_h_intern(&lf[204],4,"eval");
lf[205]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[206]=C_h_intern(&lf[206],9,"fluid-let");
lf[207]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[208]=C_h_intern(&lf[208],6,"ensure");
lf[209]=C_h_intern(&lf[209],11,"\000type-error");
lf[210]=C_h_intern(&lf[210],15,"\003syssignal-hook");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[212]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\003");
lf[213]=C_h_intern(&lf[213],6,"assert");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[215]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[216]=C_h_intern(&lf[216],7,"include");
lf[217]=C_h_intern(&lf[217],27,"\003syscurrent-source-filename");
lf[218]=C_h_intern(&lf[218],4,"read");
lf[219]=C_h_intern(&lf[219],20,"with-input-from-file");
lf[220]=C_h_intern(&lf[220],5,"print");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[223]=C_h_intern(&lf[223],12,"load-verbose");
lf[224]=C_h_intern(&lf[224],28,"\003sysresolve-include-filename");
lf[225]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[226]=C_h_intern(&lf[226],12,"\004coredeclare");
lf[227]=C_h_intern(&lf[227],4,"time");
lf[228]=C_h_intern(&lf[228],15,"\003sysstart-timer");
lf[229]=C_h_intern(&lf[229],14,"\003sysstop-timer");
lf[230]=C_h_intern(&lf[230],17,"\003sysdisplay-times");
lf[231]=C_h_intern(&lf[231],7,"receive");
lf[232]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[233]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[234]=C_h_intern(&lf[234],13,"define-record");
lf[235]=C_h_intern(&lf[235],3,"val");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[241]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[242]=C_h_intern(&lf[242],21,"\003sysmacro-environment");
lf[243]=C_h_intern(&lf[243],11,"\003sysprovide");
lf[244]=C_h_intern(&lf[244],19,"chicken-more-macros");
lf[245]=C_h_intern(&lf[245],14,"chicken-syntax");
C_register_lf2(lf,246,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1626,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 35   ##sys#provide */
t3=*((C_word*)lf[243]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[244],lf[245]);}

/* k1624 */
static void C_ccall f_1626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1630,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 43   ##sys#macro-environment */
t3=*((C_word*)lf[242]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1628 in k1624 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1633,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8058,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8060,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 47   ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a8059 in k1628 in k1624 */
static void C_ccall f_8060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8060,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8064,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 49   ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[234],t2,lf[241]);}

/* k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8064,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 52   symbol->string */
t5=*((C_word*)lf[144]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8076,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 53   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[43]);}

/* k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8076,2,t0,t1);}
t2=(C_word)C_i_memq(lf[73],*((C_word*)lf[74]+1));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 55   r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[57]);}

/* k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 56   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[32]);}

/* k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 57   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[69]);}

/* k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8091,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 58   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k8089 in k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8461,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8501,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 61   string-append */
t4=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[240],((C_word*)t0)[2]);}

/* k8499 in k8089 in k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 61   string->symbol */
t2=*((C_word*)lf[142]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8459 in k8089 in k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8461,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t2);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[7],a[10]=t1,a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=t3,tmp=(C_word)a,a+=14,tmp);
/* ##sys#append */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);}

/* k8491 in k8459 in k8089 in k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8493,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[71],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t8);
t10=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8409,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t9,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8453,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 64   string-append */
t12=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)t0)[2],lf[239]);}

/* k8451 in k8491 in k8459 in k8089 in k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 64   string->symbol */
t2=*((C_word*)lf[142]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8407 in k8491 in k8459 in k8089 in k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[59],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8409,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[82],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[43],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[82],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[72],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t1,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8114,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8118,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t17,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[12],a[11]=((C_word)li103),tmp=(C_word)a,a+=12,tmp));
t19=((C_word*)t17)[1];
f_8120(t19,t15,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k8407 in k8491 in k8459 in k8089 in k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_fcall f_8120(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8120,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t3,a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* chicken-syntax.scm: 69   symbol->string */
t7=*((C_word*)lf[144]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}

/* k8128 in mapslots in k8407 in k8491 in k8459 in k8089 in k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8133,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8397,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 70   string-append */
t4=*((C_word*)lf[143]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],lf[237],t1,lf[238]);}

/* k8395 in k8128 in mapslots in k8407 in k8491 in k8459 in k8089 in k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 70   string->symbol */
t2=*((C_word*)lf[142]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8131 in k8128 in mapslots in k8407 in k8491 in k8459 in k8089 in k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8136,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8393,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 71   string-append */
t4=*((C_word*)lf[143]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],lf[236],((C_word*)t0)[2]);}

/* k8391 in k8131 in k8128 in mapslots in k8407 in k8491 in k8459 in k8089 in k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 71   string->symbol */
t2=*((C_word*)lf[142]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8134 in k8131 in k8128 in mapslots in k8407 in k8491 in k8459 in k8089 in k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word ab[124],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8136,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[235],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[82],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[82],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[75],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[76],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[235],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[82],t12);
t14=(C_word)C_a_i_cons(&a,2,lf[78],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t10,t15);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t19);
t21=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t20);
t22=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8183,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t21,a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[3])){
t23=(C_word)C_a_i_cons(&a,2,lf[82],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[82],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[75],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,lf[76],t29);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[82],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[77],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t30,t34);
t36=(C_word)C_a_i_cons(&a,2,t23,t35);
t37=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t36);
t38=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t39=(C_word)C_a_i_cons(&a,2,t37,t38);
t40=t22;
f_8183(t40,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t39));}
else{
t23=(C_word)C_a_i_cons(&a,2,lf[82],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[82],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[75],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,lf[76],t29);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[82],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[77],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t30,t34);
t36=(C_word)C_a_i_cons(&a,2,t23,t35);
t37=t22;
f_8183(t37,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t36));}}

/* k8181 in k8134 in k8131 in k8128 in mapslots in k8407 in k8491 in k8459 in k8089 in k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_fcall f_8183(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8183,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8147,a[2]=t7,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t10=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm: 90   mapslots */
t11=((C_word*)((C_word*)t0)[2])[1];
f_8120(t11,t8,t9,t10);}

/* k8145 in k8181 in k8134 in k8131 in k8128 in mapslots in k8407 in k8491 in k8459 in k8089 in k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8147,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8116 in k8407 in k8491 in k8459 in k8089 in k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8112 in k8407 in k8491 in k8459 in k8089 in k8086 in k8083 in k8080 in k8074 in k8071 in k8062 in a8059 in k1628 in k1624 */
static void C_ccall f_8114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8114,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k8056 in k1628 in k1624 */
static void C_ccall f_8058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 45   ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[234],C_SCHEME_END_OF_LIST,t1);}

/* k1631 in k1628 in k1624 */
static void C_ccall f_1633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7915,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7917,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 95   ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7916 in k1631 in k1628 in k1624 */
static void C_ccall f_7917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7917,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7921,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 97   r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[24]);}

/* k7919 in a7916 in k1631 in k1628 in k1624 */
static void C_ccall f_7921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7924,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 98   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[66]);}

/* k7922 in k7919 in a7916 in k1631 in k1628 in k1624 */
static void C_ccall f_7924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7927,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 99   ##sys#check-syntax */
t3=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[231],((C_word*)t0)[4],lf[233]);}

/* k7925 in k7922 in k7919 in a7916 in k1631 in k1628 in k1624 */
static void C_ccall f_7927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7927,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* ##sys#append */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7963,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 103  ##sys#check-syntax */
t4=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[231],((C_word*)t0)[5],lf[232]);}}

/* k7961 in k7925 in k7922 in k7919 in a7916 in k1631 in k1628 in k1624 */
static void C_ccall f_7963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7963,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7978,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=t5;
f_7978(t7,(C_word)C_i_nullp(t6));}
else{
t6=t5;
f_7978(t6,C_SCHEME_FALSE);}}

/* k7976 in k7961 in k7925 in k7922 in k7919 in a7916 in k1631 in k1628 in k1624 */
static void C_fcall f_7978(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7978,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7993,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t7=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8032,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t6=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}}

/* k8030 in k7976 in k7961 in k7925 in k7922 in k7919 in a7916 in k1631 in k1628 in k1624 */
static void C_ccall f_8032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8032,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[99],t5));}

/* k7991 in k7976 in k7961 in k7925 in k7922 in k7919 in a7916 in k1631 in k1628 in k1624 */
static void C_ccall f_7993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7993,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k7954 in k7925 in k7922 in k7919 in a7916 in k1631 in k1628 in k1624 */
static void C_ccall f_7956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7956,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[192],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[99],t5));}

/* k7913 in k1631 in k1628 in k1624 */
static void C_ccall f_7915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 92   ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[231],C_SCHEME_END_OF_LIST,t1);}

/* k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7816,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7818,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 115  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7817 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7818,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7822,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 117  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[191]);}

/* k7820 in a7817 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 118  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[57]);}

/* k7823 in k7820 in a7817 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7828,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 119  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k7826 in k7823 in k7820 in a7817 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7828,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[228],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7907,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k7905 in k7826 in k7823 in k7820 in a7817 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7907,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[229],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[230],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[97],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[98],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t6,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[99],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t17);
t19=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t18));}

/* k7814 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 113  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[227],C_SCHEME_END_OF_LIST,t1);}

/* k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7798,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7800,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 130  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7799 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7800,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7808,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t2);
/* ##sys#append */
t7=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k7806 in a7799 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7808,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[226],t1));}

/* k7796 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 128  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[58],C_SCHEME_END_OF_LIST,t1);}

/* k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7709,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7711,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 136  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7710 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7711,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7715,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 138  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[216],t2,lf[225]);}

/* k7713 in a7710 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7718,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-syntax.scm: 139  ##sys#resolve-include-filename */
t4=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k7716 in k7713 in a7710 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7721,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 140  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[57]);}

/* k7719 in k7716 in k7713 in a7710 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7724,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7787,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 141  load-verbose */
t4=*((C_word*)lf[223]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7785 in k7719 in k7716 in k7713 in a7710 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-syntax.scm: 141  print */
t2=*((C_word*)lf[220]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[221],((C_word*)t0)[2],lf[222]);}
else{
t2=((C_word*)t0)[3];
f_7724(2,t2,C_SCHEME_UNDEFINED);}}

/* k7722 in k7719 in k7716 in k7713 in a7710 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7731,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7735,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7737,a[2]=((C_word*)t0)[2],a[3]=((C_word)li98),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 143  with-input-from-file */
t5=*((C_word*)lf[219]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* a7736 in k7722 in k7719 in k7716 in k7713 in a7710 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7737,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7743,a[2]=t3,a[3]=t5,a[4]=((C_word)li94),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7748,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7781,a[2]=t5,a[3]=t3,a[4]=((C_word)li97),tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[190]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a7780 in a7736 in k7722 in k7719 in k7716 in k7713 in a7710 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7781,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[217]+1));
t3=C_mutate((C_word*)lf[217]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a7747 in a7736 in k7722 in k7719 in k7716 in k7713 in a7710 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7756,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 146  read */
t3=*((C_word*)lf[218]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7754 in a7747 in a7736 in k7722 in k7719 in k7716 in k7713 in a7710 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7756,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7758,a[2]=t3,a[3]=((C_word)li95),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7758(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* doloop144 in k7754 in a7747 in a7736 in k7722 in k7719 in k7716 in k7713 in a7710 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_7758(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7758,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* chicken-syntax.scm: 149  reverse */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7775,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 146  read */
t5=*((C_word*)lf[218]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k7773 in doloop144 in k7754 in a7747 in a7736 in k7722 in k7719 in k7716 in k7713 in a7710 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7775,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_7758(t3,((C_word*)t0)[2],t1,t2);}

/* a7742 in a7736 in k7722 in k7719 in k7716 in k7713 in a7710 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7743,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[217]+1));
t3=C_mutate((C_word*)lf[217]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k7733 in k7722 in k7719 in k7716 in k7713 in a7710 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7729 in k7722 in k7719 in k7716 in k7713 in a7710 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7731,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7707 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 134  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[216],C_SCHEME_END_OF_LIST,t1);}

/* k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7598,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7600,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 153  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7599 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7600,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7604,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 155  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[213],t2,lf[215]);}

/* k7602 in a7599 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7604,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7613,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 158  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[121]);}

/* k7611 in k7602 in a7599 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7616,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 159  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[43]);}

/* k7614 in k7611 in k7602 in a7599 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,lf[214],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[43],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t2;
f_7619(t7,(C_word)C_a_i_cons(&a,2,lf[131],t6));}
else{
t4=t2;
f_7619(t4,(C_word)C_i_car(((C_word*)t0)[2]));}}

/* k7617 in k7614 in k7611 in k7602 in a7599 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_7619(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7619,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[76],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[183],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7662,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,a[6]=t1,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_length(((C_word*)t0)[2]);
t9=(C_word)C_fixnum_greaterp(t8,C_fix(1));
t10=(C_truep(t9)?(C_word)C_i_cdr(((C_word*)t0)[2]):C_SCHEME_END_OF_LIST);
/* ##sys#append */
t11=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t7,t10,C_SCHEME_END_OF_LIST);}

/* k7660 in k7617 in k7614 in k7611 in k7602 in a7599 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7662,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[132],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k7596 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 151  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[213],C_SCHEME_END_OF_LIST,t1);}

/* k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7461,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7463,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 175  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7462 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7463,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7467,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 177  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[208],t2,lf[212]);}

/* k7465 in a7462 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7467,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7479,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 181  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[134]);}

/* k7477 in k7465 in a7462 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 182  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[66]);}

/* k7480 in k7477 in k7465 in a7462 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7485,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 183  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[121]);}

/* k7483 in k7480 in k7477 in k7465 in a7462 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[59],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7485,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[76],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t1,a[6]=t8,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7536,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t11=t10;
f_7536(t11,((C_word*)t0)[2]);}
else{
t11=(C_word)C_a_i_cons(&a,2,lf[211],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[43],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[131],t13);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[43],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t17);
t19=t10;
f_7536(t19,(C_word)C_a_i_cons(&a,2,t14,t18));}}

/* k7534 in k7483 in k7480 in k7477 in k7465 in a7462 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_7536(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7530 in k7483 in k7480 in k7477 in k7465 in a7462 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7532,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[209],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[210],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k7459 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 172  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[208],C_SCHEME_END_OF_LIST,t1);}

/* k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7203,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7205,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 196  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7205,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7209,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 198  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[206],t2,lf[207]);}

/* k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7209,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7218,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 201  ##sys#map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[80]+1),t2);}

/* k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7449,a[2]=((C_word*)t0)[2],a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 202  ##sys#map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a7448 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7449(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7449,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7457,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 202  gensym */
t4=*((C_word*)lf[62]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7455 in a7448 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 202  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7439,a[2]=((C_word*)t0)[2],a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 203  ##sys#map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a7438 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7439(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7439,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7447,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 203  gensym */
t4=*((C_word*)lf[62]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7445 in a7438 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 203  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 204  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[66]);}

/* k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7230,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 205  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7437,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 206  ##sys#map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[149]+1),((C_word*)t0)[2]);}

/* k7435 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 206  map */
t2=*((C_word*)lf[115]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[192]+1),((C_word*)t0)[2],t1);}

/* k7395 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7401,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7405,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7409,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7415,a[2]=t7,a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_7415(t9,t4,t5);}

/* loop in k7395 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_7415(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7415,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7429,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
/* chicken-syntax.scm: 211  loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k7427 in loop in k7395 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7429,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k7407 in k7395 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 207  map */
t2=*((C_word*)lf[115]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[192]+1),((C_word*)t0)[2],t1);}

/* k7403 in k7395 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7399 in k7395 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7239 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7349,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7381,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 214  map */
t5=*((C_word*)lf[115]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* a7380 in k7239 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7381(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7381,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[170],t5));}

/* k7347 in k7239 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7353,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7357,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7367,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 216  map */
t5=*((C_word*)lf[115]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7366 in k7347 in k7239 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7367(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7367,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[170],t5));}

/* k7355 in k7347 in k7239 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7357,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[183],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k7351 in k7347 in k7239 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7343 in k7239 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7345,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7337,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t3,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k7335 in k7343 in k7239 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7337,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7281,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7285,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7317,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 221  map */
t7=*((C_word*)lf[115]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a7316 in k7335 in k7343 in k7239 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7317,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[170],t5));}

/* k7283 in k7335 in k7343 in k7239 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7289,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7293,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7303,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 223  map */
t5=*((C_word*)lf[115]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7302 in k7283 in k7335 in k7343 in k7239 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7303,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[170],t5));}

/* k7291 in k7283 in k7335 in k7343 in k7239 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7293,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[183],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k7287 in k7283 in k7335 in k7343 in k7239 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7279 in k7335 in k7343 in k7239 in k7228 in k7225 in k7222 in k7219 in k7216 in k7207 in a7204 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7281,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[190],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k7201 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 194  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[206],C_SCHEME_END_OF_LIST,t1);}

/* k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7082,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7084,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 229  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7083 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7084,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7088,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 231  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[195],t2,lf[205]);}

/* k7086 in a7083 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7088,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7094,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 233  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[57]);}

/* k7092 in k7086 in a7083 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7195,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k7193 in k7092 in k7086 in a7083 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7195,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7100,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 235  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[204]);}

/* k7098 in k7193 in k7092 in k7086 in a7083 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 236  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[203]);}

/* k7101 in k7098 in k7193 in k7092 in k7086 in a7083 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7106,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 237  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[202]);}

/* k7104 in k7101 in k7098 in k7193 in k7092 in k7086 in a7083 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7106,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7109,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7146,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t7,a[8]=t3,a[9]=t10,a[10]=((C_word)li82),tmp=(C_word)a,a+=11,tmp));
t12=((C_word*)t10)[1];
f_7146(t12,t8,((C_word*)t0)[2]);}

/* loop in k7104 in k7101 in k7098 in k7193 in k7092 in k7086 in a7083 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_7146(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7146,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7159,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 244  c */
t6=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7167 in loop in k7104 in k7101 in k7098 in k7193 in k7092 in k7086 in a7083 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7169,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
f_7159(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7176,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 245  c */
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k7174 in k7167 in loop in k7104 in k7101 in k7098 in k7193 in k7092 in k7086 in a7083 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7176,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[7];
f_7159(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7183,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 246  c */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k7181 in k7174 in k7167 in loop in k7104 in k7101 in k7098 in k7193 in k7092 in k7086 in a7083 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[3];
f_7159(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-syntax.scm: 247  ##sys#error */
t3=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],lf[201],t2);}}

/* k7157 in loop in k7104 in k7101 in k7098 in k7193 in k7092 in k7086 in a7083 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* chicken-syntax.scm: 248  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7146(t3,((C_word*)t0)[2],t2);}

/* k7107 in k7104 in k7101 in k7098 in k7193 in k7092 in k7086 in a7083 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7109,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[196],*((C_word*)lf[74]+1)))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[197],t3));}
else{
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[198],t3));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[4]:lf[199]));}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[4]:lf[200]));}}

/* k7080 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 227  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[195],C_SCHEME_END_OF_LIST,t1);}

/* k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6880,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6882,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 260  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6882,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6886,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 262  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[189],t2,lf[194]);}

/* k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6886,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6895,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 265  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[193]);}

/* k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 266  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[66]);}

/* k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 267  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k6899 in k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 268  ##sys#map */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[80]+1),((C_word*)t0)[2]);}

/* k6902 in k6899 in k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6907,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 269  ##sys#map */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[149]+1),((C_word*)t0)[2]);}

/* k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7070,a[2]=((C_word*)t0)[2],a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 270  ##sys#map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a7069 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7070(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7070,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7078,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 270  gensym */
t4=*((C_word*)lf[62]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7076 in a7069 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 270  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7060,a[2]=((C_word*)t0)[2],a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 271  ##sys#map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a7059 in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7060(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7060,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7068,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 271  gensym */
t4=*((C_word*)lf[62]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7066 in a7059 in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 271  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6911 in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6924,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7054,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 272  map */
t4=*((C_word*)lf[115]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[192]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k7052 in k6911 in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7058,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 272  map */
t3=*((C_word*)lf[115]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[192]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7056 in k7052 in k6911 in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_7058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 272  ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6922 in k6911 in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6992,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6996,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6998,a[2]=((C_word*)t0)[6],a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 274  map */
t5=*((C_word*)lf[115]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6997 in k6922 in k6911 in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6998,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[191],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[191],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[170],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t9,t13);
t15=(C_word)C_a_i_cons(&a,2,t7,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t15));}

/* k6994 in k6922 in k6911 in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6990 in k6922 in k6911 in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6992,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6972,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t8=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6970 in k6990 in k6922 in k6911 in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in a6881 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6972,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[190],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t12));}

/* k6878 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 258  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[189],C_SCHEME_END_OF_LIST,t1);}

/* k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6835,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6837,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 285  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6836 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6837,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6841,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 287  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[187],t2,lf[188]);}

/* k6839 in a6836 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 288  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[121]);}

/* k6846 in k6839 in a6836 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6848,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6868,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 289  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[57]);}

/* k6866 in k6846 in k6839 in a6836 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6872,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6870 in k6866 in k6846 in k6839 in a6836 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6872,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k6833 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 283  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[187],C_SCHEME_END_OF_LIST,t1);}

/* k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6782,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6784,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 293  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6783 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6784,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6788,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 295  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[185],t2,lf[186]);}

/* k6786 in a6783 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 296  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[121]);}

/* k6793 in k6786 in a6783 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6795,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[183],C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6823,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 298  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[57]);}

/* k6821 in k6793 in k6786 in a6783 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6827,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6825 in k6821 in k6793 in k6786 in a6783 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6827,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k6780 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 291  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[185],C_SCHEME_END_OF_LIST,t1);}

/* k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6637,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6639,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 302  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6638 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6639,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6643,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 304  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[178],t2,lf[184]);}

/* k6641 in a6638 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6643,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6652,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 307  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[24]);}

/* k6650 in k6641 in a6638 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6652,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[183],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t6);
t8=(C_word)C_a_i_cons(&a,2,t1,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t4,t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[99],t10));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[170],t5));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6721,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[62]+1),((C_word*)t0)[4]);}}}

/* k6719 in k6650 in k6641 in a6638 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6721,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6748,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6752,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6754,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 320  map */
t8=*((C_word*)lf[115]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,t7,((C_word*)t0)[2],t1);}

/* a6753 in k6719 in k6650 in k6641 in a6638 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6754,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[170],t5));}

/* k6750 in k6719 in k6650 in k6641 in a6638 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6746 in k6719 in k6650 in k6641 in a6638 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6748,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[99],t5));}

/* k6635 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 300  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[178],C_SCHEME_END_OF_LIST,t1);}

/* k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6595,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6597,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 326  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6596 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6597,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6601,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 328  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[177],t2,lf[182]);}

/* k6599 in a6596 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6621,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[181]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a6620 in k6599 in a6596 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6621(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6621,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6629,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 329  ##sys#current-module */
t4=*((C_word*)lf[180]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6627 in a6620 in k6599 in a6596 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#register-export */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6602 in k6599 in a6596 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6611,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 330  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[178]);}

/* k6609 in k6602 in k6599 in a6596 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6615,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6613 in k6609 in k6602 in k6599 in a6596 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6615,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6593 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 324  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[177],C_SCHEME_END_OF_LIST,t1);}

/* k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6207,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6209,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 334  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6209,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6213,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 336  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[174],t2,lf[176]);}

/* k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6213,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6222,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 339  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[66]);}

/* k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 340  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6225,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6227,a[2]=t3,a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6258,a[2]=t5,a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6300,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t9=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,*((C_word*)lf[80]+1),((C_word*)t0)[3]);}

/* k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6303,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6553,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word)li70),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6553(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_6553(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6553,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6566,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
/* chicken-syntax.scm: 356  append */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
/* chicken-syntax.scm: 357  append* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_6227(t6,t5,t4,t3);}
else{
t6=t5;
f_6566(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k6564 in loop in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 359  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6553(t3,((C_word*)t0)[2],t2,t1);}

/* k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6306,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6539,a[2]=((C_word*)t0)[2],a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a6538 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6539(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6539,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6547,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6551,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 360  gensym */
t5=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6549 in a6538 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 360  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6545 in a6538 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6547,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6307,a[2]=t1,a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6318,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6493,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6493(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_6493(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6493,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* chicken-syntax.scm: 364  reverse */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6509,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6533,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 368  map* */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6258(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6526,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 367  lookup */
t7=((C_word*)t0)[2];
f_6307(3,t7,t6,t4);}}}

/* k6524 in loop in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6526,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6509(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k6531 in loop in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6533,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6509(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k6507 in loop in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_6509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 369  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6493(t3,((C_word*)t0)[2],t2,t1);}

/* k6316 in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6325,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6487,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6486 in k6316 in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6487,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k6323 in k6316 in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6325,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6327,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word)li66),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6327(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k6323 in k6316 in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_6327(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6327,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6345,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6351,a[2]=((C_word*)t0)[5],a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6481,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 375  cdar */
t8=*((C_word*)lf[49]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}
else{
t7=t5;
f_6365(t7,C_SCHEME_FALSE);}}}

/* k6479 in fold in k6323 in k6316 in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6365(t2,(C_word)C_i_nullp(t1));}

/* k6363 in fold in k6323 in k6316 in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_6365(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6365,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6404,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 376  caar */
t3=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6447,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
t9=(C_word)C_i_cdr(((C_word*)t0)[8]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 381  fold */
t11=((C_word*)((C_word*)t0)[3])[1];
f_6327(t11,t7,t8,t9,t10);}}

/* k6445 in k6363 in fold in k6323 in k6316 in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6447,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[99],t6));}

/* k6402 in k6363 in fold in k6323 in k6316 in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6404,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6384,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_cdr(((C_word*)t0)[7]);
t9=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-syntax.scm: 377  fold */
t10=((C_word*)((C_word*)t0)[2])[1];
f_6327(t10,t6,t7,t8,t9);}

/* k6382 in k6402 in k6363 in fold in k6323 in k6316 in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6384,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a6350 in fold in k6323 in k6316 in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6351,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6359,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 374  lookup */
t4=((C_word*)t0)[2];
f_6307(3,t4,t3,t2);}

/* k6357 in a6350 in fold in k6323 in k6316 in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6359,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k6343 in fold in k6323 in k6316 in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6349,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6347 in k6343 in fold in k6323 in k6316 in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6349,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* lookup in k6304 in k6301 in k6298 in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6307,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_6258(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6258,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6281,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* chicken-syntax.scm: 349  proc */
t6=t2;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
/* chicken-syntax.scm: 348  proc */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}}

/* k6279 in map* in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6285,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 349  map* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6258(t4,t2,((C_word*)t0)[2],t3);}

/* k6283 in k6279 in map* in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6285,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_6227(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6227,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6248,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken-syntax.scm: 345  append* */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k6246 in append* in k6223 in k6220 in k6211 in a6208 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6248,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6205 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 332  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[174],C_SCHEME_END_OF_LIST,t1);}

/* k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6135,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6137,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 385  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6136 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6137,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6141,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 387  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[173],t2,lf[175]);}

/* k6139 in a6136 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6141,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6150,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 390  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[66]);}

/* k6148 in k6139 in a6136 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6153,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 391  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[174]);}

/* k6151 in k6148 in k6139 in a6136 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6153,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6158,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li60),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_6158(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fold in k6151 in k6148 in k6139 in a6136 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_6158(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6158,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6176,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6195,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken-syntax.scm: 396  fold */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k6193 in fold in k6151 in k6148 in k6139 in a6136 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6195,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k6174 in fold in k6151 in k6148 in k6139 in a6136 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6176,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k6133 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 383  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[173],C_SCHEME_END_OF_LIST,t1);}

/* k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5969,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5971,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 400  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5971,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5975,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 402  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[169],t2,lf[172]);}

/* k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5975,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5984,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 405  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[66]);}

/* k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 406  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6125,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6127,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* a6126 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6127(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6127,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k6123 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[31]+1),t1);}

/* k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5993,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6109,a[2]=((C_word*)t0)[2],a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a6108 in k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6109(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6109,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6117,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6121,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 408  gensym */
t5=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6119 in a6108 in k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 408  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6115 in a6108 in k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6117,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5991 in k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5994,a[2]=t1,a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6013,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6103,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6102 in k5991 in k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6103,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[171]));}

/* k6011 in k5991 in k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6017,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6021,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6026 in k6011 in k5991 in k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6027(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6027,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6055,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t6,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_i_car(t2);
/* map */
t9=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}

/* k6053 in a6026 in k6011 in k5991 in k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6059,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6063,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6065,a[2]=((C_word*)t0)[3],a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a6064 in k6053 in a6026 in k6011 in k5991 in k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6065(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6065,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6081,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 415  lookup */
t4=((C_word*)t0)[2];
f_5994(3,t4,t3,t2);}

/* k6079 in a6064 in k6053 in a6026 in k6011 in k5991 in k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6081,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[170],t3));}

/* k6061 in k6053 in a6026 in k6011 in k5991 in k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6057 in k6053 in a6026 in k6011 in k5991 in k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6059,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[99],t5));}

/* k6019 in k6011 in k5991 in k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6025,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6023 in k6019 in k6011 in k5991 in k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6015 in k6011 in k5991 in k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_6017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6017,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* lookup in k5991 in k5988 in k5985 in k5982 in k5973 in a5970 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5994(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5994,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k5967 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 398  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[169],C_SCHEME_END_OF_LIST,t1);}

/* k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5965,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 421  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[166]);}

/* k5963 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5965,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[166],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5886,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5888,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 422  ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a5887 in k5963 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5888,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5892,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 424  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[167],t2,lf[168]);}

/* k5890 in a5887 in k5963 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 425  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[134]);}

/* k5893 in k5890 in a5887 in k5963 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 426  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k5896 in k5893 in k5890 in a5887 in k5963 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5898,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5933,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 429  r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[166]);}

/* k5931 in k5896 in k5893 in k5890 in a5887 in k5963 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5933,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[99],t10));}

/* k5884 in k5963 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 419  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[167],((C_word*)t0)[2],t1);}

/* k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5781,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5783,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 433  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5782 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5783,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5787,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 435  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[24]);}

/* k5785 in a5782 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5789,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li50),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5870,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5874,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm: 449  quotify-proc */
t6=t2;
f_5789(t6,t4,t5,lf[162]);}

/* k5872 in k5785 in a5782 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5868 in k5785 in a5782 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5870,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[165],t1));}

/* quotify-proc in k5785 in a5782 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_5789(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5789,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 438  ##sys#check-syntax */
t5=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t3,t2,lf[164]);}

/* k5791 in quotify-proc in k5785 in a5782 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5793,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5850,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* ##sys#append */
t9=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t6=t5;
f_5802(t6,(C_word)C_i_cadr(((C_word*)t0)[5]));}}

/* k5848 in k5791 in quotify-proc in k5785 in a5782 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5850,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_5802(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5800 in k5791 in quotify-proc in k5785 in a5782 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_5802(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5802,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5805,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5814,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_5814(t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5824,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_car(t1);
/* chicken-syntax.scm: 444  c */
t8=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k5822 in k5800 in k5791 in quotify-proc in k5785 in a5782 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5814(t2,(C_word)C_i_not(t1));}

/* k5812 in k5800 in k5791 in quotify-proc in k5785 in a5782 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_5814(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-syntax.scm: 445  syntax-error */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[162],lf[163],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5805(2,t2,C_SCHEME_UNDEFINED);}}

/* k5803 in k5800 in k5791 in quotify-proc in k5785 in a5782 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5805,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k5779 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 431  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[162],C_SCHEME_END_OF_LIST,t1);}

/* k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5618,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5620,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 453  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5619 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5620,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5624,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 455  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[160],t2,lf[161]);}

/* k5622 in a5619 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5624,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5633,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 458  r */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[121]);}

/* k5631 in k5622 in a5619 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 459  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[66]);}

/* k5634 in k5631 in k5622 in a5619 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5636,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5641,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li48),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_5641(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fold in k5634 in k5631 in k5622 in a5619 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_5641(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5641,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5655,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 462  r */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[57]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5715,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 466  fold */
t17=t7;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t6,t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5753,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t10,a[5]=((C_word*)t0)[4],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 470  fold */
t17=t11;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5686,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 465  fold */
t17=t5;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}}

/* k5684 in fold in k5634 in k5631 in k5622 in a5619 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5686,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k5751 in fold in k5634 in k5631 in k5622 in a5619 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5753,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k5713 in fold in k5634 in k5631 in k5622 in a5619 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5715,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k5653 in fold in k5634 in k5631 in k5622 in a5619 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5659,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5657 in k5653 in fold in k5634 in k5631 in k5622 in a5619 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5659,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5616 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 451  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[160],C_SCHEME_END_OF_LIST,t1);}

/* k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5452,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5454,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 474  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5454,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5458,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 476  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[154],t2,lf[159]);}

/* k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5458,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5467,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 479  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[134]);}

/* k5465 in k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 480  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[121]);}

/* k5468 in k5465 in k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 481  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[45]);}

/* k5471 in k5468 in k5465 in k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 482  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[158]);}

/* k5474 in k5471 in k5468 in k5465 in k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 483  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[57]);}

/* k5477 in k5474 in k5471 in k5468 in k5465 in k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5486,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 484  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[66]);}

/* k5484 in k5477 in k5474 in k5471 in k5468 in k5465 in k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5486,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5502,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5504,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=t7,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word)li46),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_5504(t9,t5,((C_word*)t0)[2]);}

/* expand in k5484 in k5477 in k5474 in k5471 in k5468 in k5465 in k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_5504(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5504,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 490  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[154],t3,lf[156]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[157]);}}

/* k5518 in expand in k5484 in k5477 in k5474 in k5471 in k5468 in k5465 in k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5526,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* chicken-syntax.scm: 491  c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k5524 in k5518 in expand in k5484 in k5477 in k5474 in k5471 in k5468 in k5465 in k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5526,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5533,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* ##sys#append */
t4=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5576,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5580,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5582,a[2]=((C_word*)t0)[2],a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
/* map */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a5581 in k5524 in k5518 in expand in k5484 in k5477 in k5474 in k5471 in k5468 in k5465 in k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5582,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[155],t4));}

/* k5578 in k5524 in k5518 in expand in k5484 in k5477 in k5474 in k5471 in k5468 in k5465 in k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5574 in k5524 in k5518 in expand in k5484 in k5477 in k5474 in k5471 in k5468 in k5465 in k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5576,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5568,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k5566 in k5574 in k5524 in k5518 in expand in k5484 in k5477 in k5474 in k5471 in k5468 in k5465 in k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5568,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5564,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 496  expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5504(t4,t3,((C_word*)t0)[2]);}

/* k5562 in k5566 in k5574 in k5524 in k5518 in expand in k5484 in k5477 in k5474 in k5471 in k5468 in k5465 in k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5564,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k5531 in k5524 in k5518 in expand in k5484 in k5477 in k5474 in k5471 in k5468 in k5465 in k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5533,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5500 in k5484 in k5477 in k5474 in k5471 in k5468 in k5465 in k5456 in a5453 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5502,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k5450 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 472  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[154],C_SCHEME_END_OF_LIST,t1);}

/* k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5448,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 577  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[80]);}

/* k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5448,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[80],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5444,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 578  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[109]);}

/* k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5444,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[109],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4997,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4999,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 579  ##sys#er-transformer */
t7=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4999,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5003,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 581  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[140],t2,lf[153]);}

/* k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5003,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5015,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 585  r */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[121]);}

/* k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 586  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[66]);}

/* k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 587  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5023,a[2]=t1,a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5120,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word)li40),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5321,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 625  ##sys#check-syntax */
t5=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[140],((C_word*)t0)[2],lf[152]);}

/* k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 626  ##sys#check-syntax */
t3=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[140],((C_word*)t0)[8],lf[151]);}

/* k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* map */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[80]+1),((C_word*)t0)[2]);}

/* k5325 in k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5328,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5343,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5420,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a5419 in k5325 in k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5420,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5428,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 634  prefix-sym */
f_5328(t3,lf[150],t2);}

/* k5426 in a5419 in k5325 in k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 634  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5341 in k5325 in k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5346,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* map */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[149]+1),((C_word*)t0)[2]);}

/* k5344 in k5341 in k5325 in k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5349,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 638  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[148]);}

/* k5347 in k5344 in k5341 in k5325 in k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 641  r */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[147]);}

/* k5350 in k5347 in k5344 in k5341 in k5325 in k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5355,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[12]);}

/* a5409 in k5350 in k5347 in k5344 in k5341 in k5325 in k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5410(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5410,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5418,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 643  prefix-sym */
f_5328(t3,lf[146],t2);}

/* k5416 in a5409 in k5350 in k5347 in k5344 in k5341 in k5325 in k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 643  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5353 in k5350 in k5347 in k5344 in k5341 in k5325 in k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5358,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 646  make-default-procs */
t3=((C_word*)t0)[3];
f_5023(t3,t2,((C_word*)t0)[4],((C_word*)t0)[8],t1,((C_word*)t0)[2]);}

/* k5356 in k5353 in k5350 in k5347 in k5344 in k5341 in k5325 in k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5361,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 648  make-if-tree */
t3=((C_word*)t0)[4];
f_5120(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],((C_word*)t0)[11]);}

/* k5359 in k5356 in k5353 in k5350 in k5347 in k5344 in k5341 in k5325 in k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5368,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 651  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[145]);}

/* k5366 in k5359 in k5356 in k5353 in k5350 in k5347 in k5344 in k5341 in k5325 in k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5368,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[4]);
t9=(C_word)C_a_i_cons(&a,2,t3,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,t1,t11));}

/* prefix-sym in k5325 in k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_5328(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5328,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5336,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5340,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 629  symbol->string */
t6=*((C_word*)lf[144]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k5338 in prefix-sym in k5325 in k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 629  string-append */
t2=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5334 in prefix-sym in k5325 in k5322 in k5319 in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 629  string->symbol */
t2=*((C_word*)lf[142]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* make-if-tree in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_5120(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5120,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5126,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t5,a[8]=((C_word)li39),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_5126(t9,t1,t2,t3,C_SCHEME_END_OF_LIST);}

/* recur in make-if-tree in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_5126(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5126,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5200,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 613  r */
t6=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[128]);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[128],t6);
t8=(C_word)C_i_car(t3);
t9=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5314,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=t7,a[10]=((C_word*)t0)[3],a[11]=t5,a[12]=((C_word*)t0)[7],a[13]=t8,tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 618  reverse */
t10=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}}

/* k5312 in recur in make-if-tree in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5314,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t1);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5302,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 619  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[80]);}

/* k5300 in k5312 in recur in make-if-tree in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5302,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t4);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5286,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t5,a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 620  r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[109]);}

/* k5284 in k5300 in k5312 in recur in make-if-tree in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5286,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5250,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[6]);
t10=(C_word)C_i_cdr(((C_word*)t0)[5]);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* chicken-syntax.scm: 621  recur */
t12=((C_word*)((C_word*)t0)[2])[1];
f_5126(t12,t8,t9,t10,t11);}

/* k5248 in k5284 in k5300 in k5312 in recur in make-if-tree in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5250,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k5198 in recur in make-if-tree in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5200,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[76],t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5188,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 614  reverse */
t7=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}

/* k5186 in k5198 in recur in make-if-tree in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5188,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[141],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[43],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[131],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[132],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t2,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t12));}

/* make-default-procs in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_5023(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5023,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5031,a[2]=t4,a[3]=t5,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 593  reverse */
t7=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k5029 in make-default-procs in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5035,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 594  reverse */
t3=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5033 in k5029 in make-default-procs in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5039,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 595  reverse */
t3=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5037 in k5033 in k5029 in make-default-procs in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5039,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5041,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word)li37),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5041(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k5037 in k5033 in k5029 in make-default-procs in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_5041(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5041,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5094,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=((C_word*)t0)[3],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 600  reverse */
t9=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}}

/* k5092 in recur in k5037 in k5033 in k5029 in make-default-procs in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5110,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 601  reverse */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5108 in k5092 in recur in k5037 in k5033 in k5029 in make-default-procs in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5110,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k5104 in k5092 in recur in k5037 in k5033 in k5029 in make-default-procs in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5106,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5062,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken-syntax.scm: 602  recur */
t12=((C_word*)((C_word*)t0)[3])[1];
f_5041(t12,t8,((C_word*)t0)[2],t9,t10,t11);}

/* k5060 in k5104 in k5092 in recur in k5037 in k5033 in k5029 in make-default-procs in k5019 in k5016 in k5013 in k5001 in a4998 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_5062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5062,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4995 in k5442 in k5446 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 575  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[140],((C_word*)t0)[2],t1);}

/* k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4989,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 671  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[128]);}

/* k4987 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4989,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[128],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4985,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 672  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[80]);}

/* k4983 in k4987 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4985,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[80],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 673  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[109]);}

/* k4979 in k4983 in k4987 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4981,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[109],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4772,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4774,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 674  ##sys#er-transformer */
t8=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* a4773 in k4979 in k4983 in k4987 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4774,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4778,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 676  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[136],t2,lf[139]);}

/* k4776 in a4773 in k4979 in k4983 in k4987 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 677  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[134]);}

/* k4779 in k4776 in a4773 in k4979 in k4983 in k4987 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 678  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[121]);}

/* k4782 in k4779 in k4776 in a4773 in k4979 in k4983 in k4987 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 679  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[66]);}

/* k4789 in k4782 in k4779 in k4776 in a4773 in k4979 in k4983 in k4987 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4791,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4941,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 680  r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[128]);}

/* k4939 in k4789 in k4782 in k4779 in k4776 in a4773 in k4979 in k4983 in k4987 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4941,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_4826(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_4826(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[138],t4);}}}

/* k4824 in k4939 in k4789 in k4782 in k4779 in k4776 in a4773 in k4979 in k4983 in k4987 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 682  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[128]);}

/* k4900 in k4824 in k4939 in k4789 in k4782 in k4779 in k4776 in a4773 in k4979 in k4983 in k4987 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 682  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[109]);}

/* k4912 in k4900 in k4824 in k4939 in k4789 in k4782 in k4779 in k4776 in a4773 in k4979 in k4983 in k4987 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4914,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[76],t6);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t7,a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 683  r */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,lf[80]);}

/* k4884 in k4912 in k4900 in k4824 in k4939 in k4789 in k4782 in k4779 in k4776 in a4773 in k4979 in k4983 in k4987 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4886,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[137],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[43],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[131],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[132],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t15);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t19);
t21=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t20));}

/* k4770 in k4979 in k4983 in k4987 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 669  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[136],((C_word*)t0)[2],t1);}

/* k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4764,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 706  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[128]);}

/* k4762 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4764,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[128],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4458,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4460,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 707  ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a4459 in k4762 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4460,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4464,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 709  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[129],t2,lf[135]);}

/* k4462 in a4459 in k4762 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4464,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4476,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 713  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[66]);}

/* k4474 in k4462 in a4459 in k4762 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 714  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[128]);}

/* k4477 in k4474 in k4462 in a4459 in k4762 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 715  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[80]);}

/* k4480 in k4477 in k4474 in k4462 in a4459 in k4762 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4485,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 716  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[109]);}

/* k4483 in k4480 in k4477 in k4474 in k4462 in a4459 in k4762 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 717  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[121]);}

/* k4486 in k4483 in k4480 in k4477 in k4474 in k4462 in a4459 in k4762 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 718  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[134]);}

/* k4489 in k4486 in k4483 in k4480 in k4477 in k4474 in k4462 in a4459 in k4762 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4491,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4510,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4512,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],a[10]=((C_word)li34),tmp=(C_word)a,a+=11,tmp));
t9=((C_word*)t7)[1];
f_4512(t9,t5,t1,((C_word*)t0)[2]);}

/* loop in k4489 in k4486 in k4483 in k4480 in k4477 in k4474 in k4462 in a4459 in k4762 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_4512(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4512,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[76],t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4578,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t9=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4602,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 729  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[133]);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4740,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}}}

/* k4738 in loop in k4489 in k4486 in k4483 in k4480 in k4477 in k4474 in k4462 in a4459 in k4762 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4740,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4600 in loop in k4489 in k4486 in k4483 in k4480 in k4477 in k4474 in k4462 in a4459 in k4762 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[77],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4602,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[11]);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=(C_word)C_a_i_cons(&a,2,t4,t9);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t2,t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t14);
t16=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,lf[43],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t18);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t17,t20);
t22=(C_word)C_a_i_cons(&a,2,t15,t21);
t23=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t22);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t1,t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t13,t26);
t28=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4621,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t29=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-syntax.scm: 736  loop */
t30=((C_word*)((C_word*)t0)[2])[1];
f_4512(t30,t28,t1,t29);}

/* k4619 in k4600 in loop in k4489 in k4486 in k4483 in k4480 in k4477 in k4474 in k4462 in a4459 in k4762 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4621,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k4576 in loop in k4489 in k4486 in k4483 in k4480 in k4477 in k4474 in k4462 in a4459 in k4762 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4578,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[130],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[43],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[131],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[132],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t12);
t14=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t13));}

/* k4508 in k4489 in k4486 in k4483 in k4480 in k4477 in k4474 in k4462 in a4459 in k4762 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4510,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k4456 in k4762 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 704  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[129],((C_word*)t0)[2],t1);}

/* k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4450,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 744  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[108]);}

/* k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4450,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[108],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4446,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 745  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[80]);}

/* k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[80],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 746  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[109]);}

/* k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4442,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[109],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 747  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[110]);}

/* k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4438,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[110],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3993,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3995,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 748  ##sys#er-transformer */
t9=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3995,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3999,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 750  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[111],t2,lf[127]);}

/* k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4001,a[2]=((C_word*)t0)[4],a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4036,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 756  require */
t4=*((C_word*)lf[125]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[126]);}

/* k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4389,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4391,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a4390 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4391(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4391,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4401,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 758  ##sys#decompose-lambda-list */
t5=*((C_word*)lf[118]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a4400 in a4390 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4401,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k4387 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[124]+1),t1);}

/* k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4042,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 762  genvars */
t3=((C_word*)t0)[2];
f_4001(t3,t2,t1);}

/* k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 763  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[123]);}

/* k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 764  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[122]);}

/* k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4051,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 765  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 766  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[66]);}

/* k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 767  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[108]);}

/* k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4060,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 768  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[110]);}

/* k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4063,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 769  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[80]);}

/* k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 770  r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[109]);}

/* k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* chicken-syntax.scm: 771  r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[121]);}

/* k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4080,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* chicken-syntax.scm: 772  append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[8],((C_word*)t0)[14]);}

/* k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4080,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[15],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[112],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4104,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=t1,a[5]=((C_word*)t0)[13],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4106,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word)li30),tmp=(C_word)a,a+=14,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm: 774  fold-right */
t10=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,t8,lf[120],t9);}

/* a4105 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4106,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t3,a[14]=((C_word*)t0)[12],a[15]=((C_word)li29),tmp=(C_word)a,a+=16,tmp);
/* chicken-syntax.scm: 776  ##sys#decompose-lambda-list */
t6=*((C_word*)lf[118]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t4,t5);}

/* a4115 in a4105 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4116,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_4120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t2,a[14]=((C_word*)t0)[12],a[15]=t1,a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[14],a[18]=t3,tmp=(C_word)a,a+=19,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[9]);
/* chicken-syntax.scm: 779  ##sys#check-syntax */
t7=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[111],t6,lf[117]);}

/* k4118 in a4115 in a4105 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4120,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[18],((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4134,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[10])){
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=t3;
f_4134(t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=t3;
f_4134(t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t6));}}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=t3;
f_4134(t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}}

/* k4132 in k4118 in a4115 in a4105 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_4134(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4134,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4142,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=t1,a[5]=((C_word*)t0)[15],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4148,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word)li26),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li28),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a4157 in k4132 in k4118 in a4115 in a4105 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4158,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4162,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4185,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=((C_word)li27),tmp=(C_word)a,a+=10,tmp));
t8=((C_word*)t6)[1];
f_4185(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a4157 in k4132 in k4118 in a4115 in a4105 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_4185(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4185,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[8])){
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4210,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* ##sys#append */
t9=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[6]));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4242,a[2]=((C_word*)t0)[7],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* ##sys#append */
t7=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4253,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4333,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 794  gensym */
t6=*((C_word*)lf[62]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k4331 in build in a4157 in k4132 in k4118 in a4115 in a4105 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 794  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4251 in build in a4157 in k4132 in k4118 in a4115 in a4105 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4253,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t2,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t1,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t6,t11);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4272,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t12,tmp=(C_word)a,a+=5,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* chicken-syntax.scm: 798  build */
t16=((C_word*)((C_word*)t0)[2])[1];
f_4185(t16,t13,t15,t1);}
else{
/* chicken-syntax.scm: 799  build */
t15=((C_word*)((C_word*)t0)[2])[1];
f_4185(t15,t13,C_SCHEME_END_OF_LIST,t1);}}

/* k4270 in k4251 in build in a4157 in k4132 in k4118 in a4115 in a4105 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4272,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k4240 in build in a4157 in k4132 in k4118 in a4115 in a4105 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4242,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4208 in build in a4157 in k4132 in k4118 in a4115 in a4105 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4210,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4160 in a4157 in k4132 in k4118 in a4115 in a4105 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4162,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4179,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 802  map */
t3=*((C_word*)lf[115]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[116]+1),((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k4177 in k4160 in a4157 in k4132 in k4118 in a4115 in a4105 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4179,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a4147 in k4132 in k4118 in a4115 in a4105 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4156,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 787  take */
t3=*((C_word*)lf[114]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4154 in a4147 in k4132 in k4118 in a4115 in a4105 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 787  split-at! */
t2=*((C_word*)lf[113]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4140 in k4132 in k4118 in a4115 in a4105 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4142,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k4102 in k4078 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4104,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* genvars in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_4001(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4001,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word)li24),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4007(t6,t1,C_fix(0));}

/* loop in genvars in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_4007(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4007,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4021,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4033,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 755  gensym */
t5=*((C_word*)lf[62]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4031 in loop in genvars in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 755  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4019 in loop in genvars in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4025,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm: 755  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4007(t4,t2,t3);}

/* k4023 in k4019 in loop in genvars in k3997 in a3994 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_4025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4025,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3991 in k4436 in k4440 in k4444 in k4448 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 742  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[111],((C_word*)t0)[2],t1);}

/* k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3891,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3893,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 812  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a3892 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3893,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3897,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 814  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[103],t2,lf[107]);}

/* k3895 in a3892 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3897,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3912,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken-syntax.scm: 818  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[103],t5,lf[105]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3962,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken-syntax.scm: 825  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[103],t5,lf[106]);}}

/* k3960 in k3895 in a3892 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3962,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[43],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3977,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3975 in k3960 in k3895 in a3892 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3977,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[104],t2));}

/* k3910 in k3895 in a3892 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3912,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(0));
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[43],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3935,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 823  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[24]);}

/* k3933 in k3910 in k3895 in a3892 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3935,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t4=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3945 in k3933 in k3910 in k3895 in a3892 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3947,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[104],t5));}

/* k3889 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 810  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[103],C_SCHEME_END_OF_LIST,t1);}

/* k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3887,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 833  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[95]);}

/* k3885 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3887,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[95],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3883,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 834  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[96]);}

/* k3881 in k3885 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3883,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[96],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3677,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3679,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 835  ##sys#er-transformer */
t7=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a3678 in k3881 in k3885 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3679,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3683,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 837  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[90],t2,lf[102]);}

/* k3681 in a3678 in k3881 in k3885 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 838  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[101]);}

/* k3684 in k3681 in a3678 in k3881 in k3885 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 839  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[100]);}

/* k3687 in k3684 in k3681 in a3678 in k3881 in k3885 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3692,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 840  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k3690 in k3687 in k3684 in k3681 in a3678 in k3881 in k3885 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 841  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[95]);}

/* k3701 in k3690 in k3687 in k3684 in k3681 in a3678 in k3881 in k3885 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3703,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3731,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 843  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[96]);}

/* k3729 in k3701 in k3690 in k3687 in k3684 in k3681 in a3678 in k3881 in k3885 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3731,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_i_caddr(((C_word*)t0)[8]);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t12,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t14=(C_word)C_i_cdddr(((C_word*)t0)[8]);
/* ##sys#append */
t15=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,C_SCHEME_END_OF_LIST);}

/* k3821 in k3729 in k3701 in k3690 in k3687 in k3684 in k3681 in a3678 in k3881 in k3885 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[84],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3823,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[97],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[98],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[24],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=(C_word)C_a_i_cons(&a,2,lf[99],t16);
t18=(C_word)C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t18);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t19);
t21=(C_word)C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t21);
t23=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t22);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t24);
t26=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t27);
t29=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST));}

/* k3675 in k3881 in k3885 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 831  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[90],((C_word*)t0)[2],t1);}

/* k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3669,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 854  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[45]);}

/* k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3669,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[45],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3665,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 855  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[84]);}

/* k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3665,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[84],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3323,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3325,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 856  ##sys#er-transformer */
t7=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3325,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3329,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 858  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[85],t2,lf[94]);}

/* k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 859  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[93]);}

/* k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 860  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[92]);}

/* k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 861  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[91]);}

/* k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 862  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[66]);}

/* k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 863  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[43]);}

/* k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 864  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[84]);}

/* k3345 in k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 865  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[45]);}

/* k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3352,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t1,a[9]=((C_word)li20),tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3525,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 879  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[90]);}

/* k3523 in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3525,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[86],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[72],t5);
t7=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[87],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t6,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3565,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t15,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 882  r */
t17=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,lf[89]);}

/* k3563 in k3523 in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3569,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3573,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k3571 in k3563 in k3523 in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3573,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[88],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t7=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t1,t6);}

/* k3567 in k3563 in k3523 in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3569,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t5,t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* parse-clause in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3352(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3352,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3379,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3394,a[2]=((C_word*)t0)[6],a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t13=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,t7,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3413,a[2]=((C_word*)t0)[6],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t10=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t7,C_SCHEME_END_OF_LIST);}}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3470,a[2]=t7,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3474,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word)li19),tmp=(C_word)a,a+=6,tmp);
/* map */
t11=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,t6);}}

/* a3475 in parse-clause in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3476,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* k3472 in parse-clause in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3468 in parse-clause in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3470,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3428,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3443,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3462,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t6=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k3460 in k3468 in parse-clause in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3462,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_3428(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3441 in k3468 in parse-clause in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3443,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_3428(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3426 in k3468 in parse-clause in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_3428(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3428,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3411 in parse-clause in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3413,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_3379(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3392 in parse-clause in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3394,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_3379(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3377 in parse-clause in k3348 in k3345 in k3342 in k3339 in k3336 in k3333 in k3330 in k3327 in a3324 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_3379(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3379,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3321 in k3663 in k3667 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 852  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[85],((C_word*)t0)[2],t1);}

/* k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[69],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[43],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[67],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[69],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2921,a[2]=t8,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2923,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 892  ##sys#er-transformer */
t11=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}

/* a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2923,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2927,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 894  ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[70],t2,lf[83]);}

/* k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cddddr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2942,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 899  r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[57]);}

/* k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 900  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 901  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[32]);}

/* k2946 in k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 902  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[43]);}

/* k2949 in k2946 in k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 903  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[69]);}

/* k2952 in k2949 in k2946 in k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2954,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2960,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 905  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[82]);}

/* k2958 in k2952 in k2949 in k2946 in k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 906  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[81]);}

/* k2961 in k2958 in k2952 in k2949 in k2946 in k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* map */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[80]+1),((C_word*)t0)[3]);}

/* k2964 in k2961 in k2958 in k2952 in k2949 in k2946 in k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2966,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t2);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3278,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3282,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3284,a[2]=((C_word*)t0)[2],a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}

/* a3283 in k2964 in k2961 in k2958 in k2952 in k2949 in k2946 in k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3284,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[79]));}

/* k3280 in k2964 in k2961 in k2958 in k2952 in k2949 in k2946 in k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3276 in k2964 in k2961 in k2958 in k2952 in k2949 in k2946 in k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[67],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3278,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[71],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[72],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t8,t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t15);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2989,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t6,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2993,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t20,a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[11],a[10]=((C_word)li16),tmp=(C_word)a,a+=11,tmp));
t22=((C_word*)t20)[1];
f_2995(t22,t18,((C_word*)t0)[2],C_fix(1));}

/* loop in k3276 in k2964 in k2961 in k2958 in k2952 in k2949 in k2946 in k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_2995(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2995,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[73],*((C_word*)lf[74]+1));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[75],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[76],t14);
t16=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[77],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,t15,t19);
t21=(C_word)C_a_i_cons(&a,2,t8,t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t21);
t23=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3021,a[2]=((C_word*)t0)[3],a[3]=t22,a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[5],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t7)){
t24=(C_word)C_i_caddr(t4);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t26=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t25);
t27=(C_word)C_a_i_cons(&a,2,t24,t26);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t29=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t30);
t32=(C_word)C_a_i_cons(&a,2,lf[75],t31);
t33=(C_word)C_a_i_cons(&a,2,t32,C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[76],t33);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t36=(C_word)C_a_i_cons(&a,2,t3,t35);
t37=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t36);
t38=(C_word)C_a_i_cons(&a,2,lf[78],t37);
t39=(C_word)C_a_i_cons(&a,2,t38,C_SCHEME_END_OF_LIST);
t40=(C_word)C_a_i_cons(&a,2,t34,t39);
t41=(C_word)C_a_i_cons(&a,2,t27,t40);
t42=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t41);
t43=t23;
f_3021(t43,(C_word)C_a_i_cons(&a,2,t42,C_SCHEME_END_OF_LIST));}
else{
t24=t23;
f_3021(t24,C_SCHEME_END_OF_LIST);}}}

/* k3019 in loop in k3276 in k2964 in k2961 in k2958 in k2952 in k2949 in k2946 in k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_3021(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3021,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3061,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=t3;
f_3061(t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}
else{
t5=t3;
f_3061(t5,((C_word*)t0)[3]);}}

/* k3059 in k3019 in loop in k3276 in k2964 in k2961 in k2958 in k2952 in k2949 in k2946 in k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_3061(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3061,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3033,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3037,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* chicken-syntax.scm: 936  loop */
t9=((C_word*)((C_word*)t0)[2])[1];
f_2995(t9,t6,t7,t8);}

/* k3035 in k3059 in k3019 in loop in k3276 in k2964 in k2961 in k2958 in k2952 in k2949 in k2946 in k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3031 in k3059 in k3019 in loop in k3276 in k2964 in k2961 in k2958 in k2952 in k2949 in k2946 in k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3033,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2991 in k3276 in k2964 in k2961 in k2958 in k2952 in k2949 in k2946 in k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2987 in k3276 in k2964 in k2961 in k2958 in k2952 in k2949 in k2946 in k2943 in k2940 in k2925 in a2922 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2989,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2919 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 889  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[70],((C_word*)t0)[2],t1);}

/* k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2913,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 943  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[60]);}

/* k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[60],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2721,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2723,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 944  ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2723,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2727,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 946  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[65]);}

/* k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2730,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 947  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[64]);}

/* k2728 in k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 948  r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[60]);}

/* k2731 in k2728 in k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 949  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[57]);}

/* k2734 in k2731 in k2728 in k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 950  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k2737 in k2734 in k2731 in k2728 in k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2739,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2748,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word)li14),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_2748(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k2737 in k2734 in k2731 in k2728 in k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_2748(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2748,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2758,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 953  reverse */
t7=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_i_car(t2);
/* chicken-syntax.scm: 960  c */
t8=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k2849 in loop in k2737 in k2734 in k2731 in k2728 in k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2851,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2873,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 961  gensym */
t4=*((C_word*)lf[62]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2879,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* chicken-syntax.scm: 963  c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k2877 in k2849 in loop in k2737 in k2734 in k2731 in k2728 in k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2879,2,t0,t1);}
if(C_truep(t1)){
/* chicken-syntax.scm: 963  loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2748(t2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* chicken-syntax.scm: 964  loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2748(t5,((C_word*)t0)[5],t2,((C_word*)t0)[4],t4,C_SCHEME_FALSE);}}

/* k2871 in k2849 in loop in k2737 in k2734 in k2731 in k2728 in k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 961  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2852 in k2849 in loop in k2737 in k2734 in k2731 in k2728 in k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2854,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken-syntax.scm: 962  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2748(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k2756 in loop in k2737 in k2734 in k2731 in k2728 in k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2761,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 954  reverse */
t3=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2759 in k2756 in loop in k2737 in k2734 in k2731 in k2728 in k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2761,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2767,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2810,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 956  gensym */
t4=*((C_word*)lf[62]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2833,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(t1);
/* ##sys#append */
t7=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}

/* k2831 in k2759 in k2756 in loop in k2737 in k2734 in k2731 in k2728 in k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2833,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k2808 in k2759 in k2756 in loop in k2737 in k2734 in k2731 in k2728 in k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 956  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2765 in k2759 in k2756 in loop in k2737 in k2734 in k2731 in k2728 in k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2778,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2776 in k2765 in k2759 in k2756 in loop in k2737 in k2734 in k2731 in k2728 in k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2778,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k2796 in k2776 in k2765 in k2759 in k2756 in loop in k2737 in k2734 in k2731 in k2728 in k2725 in a2722 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2798,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k2719 in k2911 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 941  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[68],((C_word*)t0)[2],t1);}

/* k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2713,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 968  ##sys#primitive-alias */
t4=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[60]);}

/* k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2713,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[60],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2490,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2492,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 969  ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2492,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2496,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 971  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[66]);}

/* k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 972  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 973  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[60]);}

/* k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 974  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[65]);}

/* k2503 in k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2508,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 975  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[64]);}

/* k2506 in k2503 in k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2508,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2517,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word)li12),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_2517(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k2506 in k2503 in k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_2517(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2517,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2527,a[2]=t5,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t6,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 978  reverse */
t8=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2636,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_i_car(t2);
/* chicken-syntax.scm: 988  c */
t9=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}}

/* k2634 in loop in k2506 in k2503 in k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2636,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2639,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2658,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 989  gensym */
t4=*((C_word*)lf[62]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2664,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* chicken-syntax.scm: 991  c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k2662 in k2634 in loop in k2506 in k2503 in k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2664,2,t0,t1);}
if(C_truep(t1)){
/* chicken-syntax.scm: 991  loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2517(t2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2697,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 993  gensym */
t4=*((C_word*)lf[62]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2695 in k2662 in k2634 in loop in k2506 in k2503 in k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 993  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2668 in k2662 in k2634 in loop in k2506 in k2503 in k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken-syntax.scm: 994  loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2517(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k2656 in k2634 in loop in k2506 in k2503 in k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 989  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2637 in k2634 in loop in k2506 in k2503 in k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2639,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken-syntax.scm: 990  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2517(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k2525 in loop in k2506 in k2503 in k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2530,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 979  reverse */
t3=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2528 in k2525 in loop in k2506 in k2503 in k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2530,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2536,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2591,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 981  gensym */
t4=*((C_word*)lf[62]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(t1);
/* ##sys#append */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k2624 in k2528 in k2525 in loop in k2506 in k2503 in k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2626,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k2589 in k2528 in k2525 in loop in k2506 in k2503 in k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 981  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2534 in k2528 in k2525 in loop in k2506 in k2503 in k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2559,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2557 in k2534 in k2528 in k2525 in loop in k2506 in k2503 in k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2559,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2579,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[8]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k2577 in k2557 in k2534 in k2528 in k2525 in loop in k2506 in k2503 in k2500 in k2497 in k2494 in a2491 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2579,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k2488 in k2711 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 966  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[61],((C_word*)t0)[2],t1);}

/* k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2209,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2211,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1004 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2211,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2215,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 1006 ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[38],t2,lf[59]);}

/* k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2218,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 1007 r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[58]);}

/* k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 1008 r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[57]);}

/* k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 1009 r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[56]);}

/* k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2227,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 1010 r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[55]);}

/* k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 1011 r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[54]);}

/* k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2230,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word)li10),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_2239(t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2,C_SCHEME_FALSE);}

/* loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_2239(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2239,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2249,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2379,a[2]=((C_word*)t0)[9],a[3]=t6,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t8=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t5,C_SCHEME_END_OF_LIST);}
else{
t7=t6;
f_2249(t7,lf[48]);}}
else{
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[5],a[10]=t2,a[11]=((C_word*)t0)[6],a[12]=t4,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_2385(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_2385(t7,C_SCHEME_FALSE);}}}

/* k2383 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_2385(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2385,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 1026 caar */
t3=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[12]);}
else{
/* chicken-syntax.scm: 1037 syntax-error */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[8],lf[38],lf[53],((C_word*)t0)[12]);}}

/* k2386 in k2383 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2388,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2397,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 1028 c */
t4=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t1);}

/* k2395 in k2386 in k2383 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2397,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2412,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2416,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1029 cdar */
t4=*((C_word*)lf[49]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2422,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 1030 c */
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k2420 in k2395 in k2386 in k2383 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2422,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2437,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2441,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1031 cdar */
t4=*((C_word*)lf[49]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2447,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 1032 c */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2445 in k2420 in k2395 in k2386 in k2383 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2447,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2454,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
t4=(C_truep(t3)?t3:C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2462,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 1033 cdar */
t6=*((C_word*)lf[49]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2469,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1035 caar */
t3=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k2467 in k2445 in k2420 in k2395 in k2386 in k2383 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1035 syntax-error */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[38],lf[51],t1);}

/* k2460 in k2445 in k2420 in k2395 in k2386 in k2383 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1033 append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2452 in k2445 in k2420 in k2395 in k2386 in k2383 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1033 loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2239(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2439 in k2420 in k2395 in k2386 in k2383 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2435 in k2420 in k2395 in k2386 in k2383 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2437,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken-syntax.scm: 1031 loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_2239(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2414 in k2395 in k2386 in k2383 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2410 in k2395 in k2386 in k2383 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2412,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken-syntax.scm: 1029 loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_2239(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2377 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2379,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
f_2249(t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2247 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_2249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2249,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2256,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 1017 r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[47]);}

/* k2254 in k2247 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k2362 in k2254 in k2247 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2364,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[39],t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 1019 r */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[46]);}

/* k2350 in k2362 in k2254 in k2247 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2352,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[40],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2348,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k2346 in k2350 in k2362 in k2254 in k2247 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2348,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 1020 r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[45]);}

/* k2282 in k2346 in k2350 in k2362 in k2254 in k2247 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2284,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[41]+1),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[42],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=t5,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 1023 r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[44]);}

/* k2310 in k2282 in k2346 in k2350 in k2362 in k2254 in k2247 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2324,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 1023 r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[43]);}

/* k2322 in k2310 in k2282 in k2346 in k2350 in k2362 in k2254 in k2247 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2324,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[41]+1),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2308,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t7=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k2306 in k2322 in k2310 in k2282 in k2346 in k2350 in k2362 in k2254 in k2247 in loop in k2228 in k2225 in k2222 in k2219 in k2216 in k2213 in a2210 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2308,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k2207 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1002 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[38],C_SCHEME_END_OF_LIST,t1);}

/* k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2105,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2107,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1046 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2106 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2107,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2111,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1048 ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[35],t2,lf[37]);}

/* k2109 in a2106 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2111,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 1050 r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[36]);}

/* k2115 in k2109 in a2106 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2117,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2162,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 1053 r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[24]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2201,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t4=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}}

/* k2199 in k2115 in k2109 in a2106 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2201,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k2160 in k2115 in k2109 in a2106 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2162,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2174,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k2172 in k2160 in k2115 in k2109 in a2106 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2174,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t6,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k2103 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1044 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[35],C_SCHEME_END_OF_LIST,t1);}

/* k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2068,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2070,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1063 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2069 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2070,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2074,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1065 ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[30],t2,lf[34]);}

/* k2072 in a2069 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1066 r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[33]);}

/* k2079 in k2072 in a2069 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1067 r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[32]);}

/* k2091 in k2079 in k2072 in a2069 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2097,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k2095 in k2091 in k2079 in k2072 in a2069 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2097,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2066 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1061 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[30],C_SCHEME_END_OF_LIST,t1);}

/* k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1735,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2043,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2045,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1074 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2044 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2045,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2049,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 1076 ##sys#check-syntax */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[26],t2,lf[29]);}

/* k2047 in a2044 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2049,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[27],t4));}

/* k2041 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1072 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[26],C_SCHEME_END_OF_LIST,t1);}

/* k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1911,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1913,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1084 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1912 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1913(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1913,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1923,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_cdr(t5);
/* ##sys#list? */
t9=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t6,t8);}
else{
t8=t6;
f_1923(2,t8,C_SCHEME_FALSE);}}
else{
t7=t6;
f_1923(2,t7,C_SCHEME_FALSE);}}

/* k1921 in a1912 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1939,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t6,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* rename14461451 */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[23]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cdr(t3);
t5=t2;
f_1973(t5,(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST));}
else{
t4=t2;
f_1973(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_1973(t3,C_SCHEME_FALSE);}}}

/* k1971 in k1921 in a1912 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_1973(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1973,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1986,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* rename14461451 */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[25]);}
else{
/* ##sys#syntax-error-hook */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],lf[20],((C_word*)t0)[2]);}}

/* k1984 in k1971 in k1921 in a1912 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1986,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t1,t3));}

/* k1937 in k1921 in a1912 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1955,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* rename14461451 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k1953 in k1937 in k1921 in a1912 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1955,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k1909 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1082 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[23],C_SCHEME_END_OF_LIST,t1);}

/* k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1764,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1766,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1093 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1765 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1766,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1776,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1846,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_car(t5);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1859,a[2]=t10,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_1859(t12,t7,t8);}
else{
t7=t6;
f_1776(2,t7,C_SCHEME_FALSE);}}

/* loop1504 in a1765 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_1859(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1859,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1863,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#null? */
t4=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1861 in loop1504 in a1765 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1863,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cdr(t4);
t6=t3;
f_1881(t6,(C_word)C_eqp(t5,C_SCHEME_END_OF_LIST));}
else{
t5=t3;
f_1881(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_1881(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k1879 in k1861 in loop1504 in a1765 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_fcall f_1881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* loop15041530 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1859(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1844 in a1765 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* ##sys#list? */
t3=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
f_1776(2,t2,C_SCHEME_FALSE);}}

/* k1774 in a1765 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1776,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1779,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1826,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* ##sys#map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
/* ##sys#syntax-error-hook */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],lf[20],((C_word*)t0)[2]);}}

/* a1825 in k1774 in a1765 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1826,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k1777 in k1774 in a1765 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1782,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1812,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
/* ##sys#map */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a1811 in k1777 in k1774 in a1765 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1812,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t3));}

/* k1780 in k1777 in k1774 in a1765 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1782,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1792,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* rename15071512 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[17]);}

/* k1790 in k1780 in k1777 in k1774 in a1765 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1800,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1802,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp);
/* ##sys#map-n */
t4=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1801 in k1790 in k1780 in k1777 in k1774 in a1765 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1802,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t2,t4));}

/* k1798 in k1790 in k1780 in k1777 in k1774 in a1765 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1800,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k1762 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1091 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[15],C_SCHEME_END_OF_LIST,t1);}

/* k1739 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1744,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1754,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1756,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1103 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1755 in k1739 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1756,5,t0,t1,t2,t3,t4);}
/* chicken-syntax.scm: 1105 syntax-error */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[11],lf[13]);}

/* k1752 in k1739 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1101 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[11],C_SCHEME_END_OF_LIST,t1);}

/* k1742 in k1739 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1747,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1108 ##sys#macro-subset */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],*((C_word*)lf[9]+1));}

/* k1745 in k1742 in k1739 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1747,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! chicken-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1750,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1113 register-feature! */
t4=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t4+1)))(8,t4,t3,lf[2],lf[3],lf[4],lf[5],lf[6],lf[7]);}

/* k1748 in k1745 in k1742 in k1739 in k1736 in k1733 in k1730 in k1727 in k1724 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1700 in k1697 in k1694 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 */
static void C_ccall f_1750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[627] = {
{"toplevel:chicken_syntax_scm",(void*)C_chicken_syntax_toplevel},
{"f_1626:chicken_syntax_scm",(void*)f_1626},
{"f_1630:chicken_syntax_scm",(void*)f_1630},
{"f_8060:chicken_syntax_scm",(void*)f_8060},
{"f_8064:chicken_syntax_scm",(void*)f_8064},
{"f_8073:chicken_syntax_scm",(void*)f_8073},
{"f_8076:chicken_syntax_scm",(void*)f_8076},
{"f_8082:chicken_syntax_scm",(void*)f_8082},
{"f_8085:chicken_syntax_scm",(void*)f_8085},
{"f_8088:chicken_syntax_scm",(void*)f_8088},
{"f_8091:chicken_syntax_scm",(void*)f_8091},
{"f_8501:chicken_syntax_scm",(void*)f_8501},
{"f_8461:chicken_syntax_scm",(void*)f_8461},
{"f_8493:chicken_syntax_scm",(void*)f_8493},
{"f_8453:chicken_syntax_scm",(void*)f_8453},
{"f_8409:chicken_syntax_scm",(void*)f_8409},
{"f_8120:chicken_syntax_scm",(void*)f_8120},
{"f_8130:chicken_syntax_scm",(void*)f_8130},
{"f_8397:chicken_syntax_scm",(void*)f_8397},
{"f_8133:chicken_syntax_scm",(void*)f_8133},
{"f_8393:chicken_syntax_scm",(void*)f_8393},
{"f_8136:chicken_syntax_scm",(void*)f_8136},
{"f_8183:chicken_syntax_scm",(void*)f_8183},
{"f_8147:chicken_syntax_scm",(void*)f_8147},
{"f_8118:chicken_syntax_scm",(void*)f_8118},
{"f_8114:chicken_syntax_scm",(void*)f_8114},
{"f_8058:chicken_syntax_scm",(void*)f_8058},
{"f_1633:chicken_syntax_scm",(void*)f_1633},
{"f_7917:chicken_syntax_scm",(void*)f_7917},
{"f_7921:chicken_syntax_scm",(void*)f_7921},
{"f_7924:chicken_syntax_scm",(void*)f_7924},
{"f_7927:chicken_syntax_scm",(void*)f_7927},
{"f_7963:chicken_syntax_scm",(void*)f_7963},
{"f_7978:chicken_syntax_scm",(void*)f_7978},
{"f_8032:chicken_syntax_scm",(void*)f_8032},
{"f_7993:chicken_syntax_scm",(void*)f_7993},
{"f_7956:chicken_syntax_scm",(void*)f_7956},
{"f_7915:chicken_syntax_scm",(void*)f_7915},
{"f_1636:chicken_syntax_scm",(void*)f_1636},
{"f_7818:chicken_syntax_scm",(void*)f_7818},
{"f_7822:chicken_syntax_scm",(void*)f_7822},
{"f_7825:chicken_syntax_scm",(void*)f_7825},
{"f_7828:chicken_syntax_scm",(void*)f_7828},
{"f_7907:chicken_syntax_scm",(void*)f_7907},
{"f_7816:chicken_syntax_scm",(void*)f_7816},
{"f_1639:chicken_syntax_scm",(void*)f_1639},
{"f_7800:chicken_syntax_scm",(void*)f_7800},
{"f_7808:chicken_syntax_scm",(void*)f_7808},
{"f_7798:chicken_syntax_scm",(void*)f_7798},
{"f_1642:chicken_syntax_scm",(void*)f_1642},
{"f_7711:chicken_syntax_scm",(void*)f_7711},
{"f_7715:chicken_syntax_scm",(void*)f_7715},
{"f_7718:chicken_syntax_scm",(void*)f_7718},
{"f_7721:chicken_syntax_scm",(void*)f_7721},
{"f_7787:chicken_syntax_scm",(void*)f_7787},
{"f_7724:chicken_syntax_scm",(void*)f_7724},
{"f_7737:chicken_syntax_scm",(void*)f_7737},
{"f_7781:chicken_syntax_scm",(void*)f_7781},
{"f_7748:chicken_syntax_scm",(void*)f_7748},
{"f_7756:chicken_syntax_scm",(void*)f_7756},
{"f_7758:chicken_syntax_scm",(void*)f_7758},
{"f_7775:chicken_syntax_scm",(void*)f_7775},
{"f_7743:chicken_syntax_scm",(void*)f_7743},
{"f_7735:chicken_syntax_scm",(void*)f_7735},
{"f_7731:chicken_syntax_scm",(void*)f_7731},
{"f_7709:chicken_syntax_scm",(void*)f_7709},
{"f_1645:chicken_syntax_scm",(void*)f_1645},
{"f_7600:chicken_syntax_scm",(void*)f_7600},
{"f_7604:chicken_syntax_scm",(void*)f_7604},
{"f_7613:chicken_syntax_scm",(void*)f_7613},
{"f_7616:chicken_syntax_scm",(void*)f_7616},
{"f_7619:chicken_syntax_scm",(void*)f_7619},
{"f_7662:chicken_syntax_scm",(void*)f_7662},
{"f_7598:chicken_syntax_scm",(void*)f_7598},
{"f_1648:chicken_syntax_scm",(void*)f_1648},
{"f_7463:chicken_syntax_scm",(void*)f_7463},
{"f_7467:chicken_syntax_scm",(void*)f_7467},
{"f_7479:chicken_syntax_scm",(void*)f_7479},
{"f_7482:chicken_syntax_scm",(void*)f_7482},
{"f_7485:chicken_syntax_scm",(void*)f_7485},
{"f_7536:chicken_syntax_scm",(void*)f_7536},
{"f_7532:chicken_syntax_scm",(void*)f_7532},
{"f_7461:chicken_syntax_scm",(void*)f_7461},
{"f_1651:chicken_syntax_scm",(void*)f_1651},
{"f_7205:chicken_syntax_scm",(void*)f_7205},
{"f_7209:chicken_syntax_scm",(void*)f_7209},
{"f_7218:chicken_syntax_scm",(void*)f_7218},
{"f_7449:chicken_syntax_scm",(void*)f_7449},
{"f_7457:chicken_syntax_scm",(void*)f_7457},
{"f_7221:chicken_syntax_scm",(void*)f_7221},
{"f_7439:chicken_syntax_scm",(void*)f_7439},
{"f_7447:chicken_syntax_scm",(void*)f_7447},
{"f_7224:chicken_syntax_scm",(void*)f_7224},
{"f_7227:chicken_syntax_scm",(void*)f_7227},
{"f_7230:chicken_syntax_scm",(void*)f_7230},
{"f_7437:chicken_syntax_scm",(void*)f_7437},
{"f_7397:chicken_syntax_scm",(void*)f_7397},
{"f_7415:chicken_syntax_scm",(void*)f_7415},
{"f_7429:chicken_syntax_scm",(void*)f_7429},
{"f_7409:chicken_syntax_scm",(void*)f_7409},
{"f_7405:chicken_syntax_scm",(void*)f_7405},
{"f_7401:chicken_syntax_scm",(void*)f_7401},
{"f_7241:chicken_syntax_scm",(void*)f_7241},
{"f_7381:chicken_syntax_scm",(void*)f_7381},
{"f_7349:chicken_syntax_scm",(void*)f_7349},
{"f_7367:chicken_syntax_scm",(void*)f_7367},
{"f_7357:chicken_syntax_scm",(void*)f_7357},
{"f_7353:chicken_syntax_scm",(void*)f_7353},
{"f_7345:chicken_syntax_scm",(void*)f_7345},
{"f_7337:chicken_syntax_scm",(void*)f_7337},
{"f_7317:chicken_syntax_scm",(void*)f_7317},
{"f_7285:chicken_syntax_scm",(void*)f_7285},
{"f_7303:chicken_syntax_scm",(void*)f_7303},
{"f_7293:chicken_syntax_scm",(void*)f_7293},
{"f_7289:chicken_syntax_scm",(void*)f_7289},
{"f_7281:chicken_syntax_scm",(void*)f_7281},
{"f_7203:chicken_syntax_scm",(void*)f_7203},
{"f_1654:chicken_syntax_scm",(void*)f_1654},
{"f_7084:chicken_syntax_scm",(void*)f_7084},
{"f_7088:chicken_syntax_scm",(void*)f_7088},
{"f_7094:chicken_syntax_scm",(void*)f_7094},
{"f_7195:chicken_syntax_scm",(void*)f_7195},
{"f_7100:chicken_syntax_scm",(void*)f_7100},
{"f_7103:chicken_syntax_scm",(void*)f_7103},
{"f_7106:chicken_syntax_scm",(void*)f_7106},
{"f_7146:chicken_syntax_scm",(void*)f_7146},
{"f_7169:chicken_syntax_scm",(void*)f_7169},
{"f_7176:chicken_syntax_scm",(void*)f_7176},
{"f_7183:chicken_syntax_scm",(void*)f_7183},
{"f_7159:chicken_syntax_scm",(void*)f_7159},
{"f_7109:chicken_syntax_scm",(void*)f_7109},
{"f_7082:chicken_syntax_scm",(void*)f_7082},
{"f_1657:chicken_syntax_scm",(void*)f_1657},
{"f_6882:chicken_syntax_scm",(void*)f_6882},
{"f_6886:chicken_syntax_scm",(void*)f_6886},
{"f_6895:chicken_syntax_scm",(void*)f_6895},
{"f_6898:chicken_syntax_scm",(void*)f_6898},
{"f_6901:chicken_syntax_scm",(void*)f_6901},
{"f_6904:chicken_syntax_scm",(void*)f_6904},
{"f_6907:chicken_syntax_scm",(void*)f_6907},
{"f_7070:chicken_syntax_scm",(void*)f_7070},
{"f_7078:chicken_syntax_scm",(void*)f_7078},
{"f_6910:chicken_syntax_scm",(void*)f_6910},
{"f_7060:chicken_syntax_scm",(void*)f_7060},
{"f_7068:chicken_syntax_scm",(void*)f_7068},
{"f_6913:chicken_syntax_scm",(void*)f_6913},
{"f_7054:chicken_syntax_scm",(void*)f_7054},
{"f_7058:chicken_syntax_scm",(void*)f_7058},
{"f_6924:chicken_syntax_scm",(void*)f_6924},
{"f_6998:chicken_syntax_scm",(void*)f_6998},
{"f_6996:chicken_syntax_scm",(void*)f_6996},
{"f_6992:chicken_syntax_scm",(void*)f_6992},
{"f_6972:chicken_syntax_scm",(void*)f_6972},
{"f_6880:chicken_syntax_scm",(void*)f_6880},
{"f_1660:chicken_syntax_scm",(void*)f_1660},
{"f_6837:chicken_syntax_scm",(void*)f_6837},
{"f_6841:chicken_syntax_scm",(void*)f_6841},
{"f_6848:chicken_syntax_scm",(void*)f_6848},
{"f_6868:chicken_syntax_scm",(void*)f_6868},
{"f_6872:chicken_syntax_scm",(void*)f_6872},
{"f_6835:chicken_syntax_scm",(void*)f_6835},
{"f_1663:chicken_syntax_scm",(void*)f_1663},
{"f_6784:chicken_syntax_scm",(void*)f_6784},
{"f_6788:chicken_syntax_scm",(void*)f_6788},
{"f_6795:chicken_syntax_scm",(void*)f_6795},
{"f_6823:chicken_syntax_scm",(void*)f_6823},
{"f_6827:chicken_syntax_scm",(void*)f_6827},
{"f_6782:chicken_syntax_scm",(void*)f_6782},
{"f_1666:chicken_syntax_scm",(void*)f_1666},
{"f_6639:chicken_syntax_scm",(void*)f_6639},
{"f_6643:chicken_syntax_scm",(void*)f_6643},
{"f_6652:chicken_syntax_scm",(void*)f_6652},
{"f_6721:chicken_syntax_scm",(void*)f_6721},
{"f_6754:chicken_syntax_scm",(void*)f_6754},
{"f_6752:chicken_syntax_scm",(void*)f_6752},
{"f_6748:chicken_syntax_scm",(void*)f_6748},
{"f_6637:chicken_syntax_scm",(void*)f_6637},
{"f_1669:chicken_syntax_scm",(void*)f_1669},
{"f_6597:chicken_syntax_scm",(void*)f_6597},
{"f_6601:chicken_syntax_scm",(void*)f_6601},
{"f_6621:chicken_syntax_scm",(void*)f_6621},
{"f_6629:chicken_syntax_scm",(void*)f_6629},
{"f_6604:chicken_syntax_scm",(void*)f_6604},
{"f_6611:chicken_syntax_scm",(void*)f_6611},
{"f_6615:chicken_syntax_scm",(void*)f_6615},
{"f_6595:chicken_syntax_scm",(void*)f_6595},
{"f_1672:chicken_syntax_scm",(void*)f_1672},
{"f_6209:chicken_syntax_scm",(void*)f_6209},
{"f_6213:chicken_syntax_scm",(void*)f_6213},
{"f_6222:chicken_syntax_scm",(void*)f_6222},
{"f_6225:chicken_syntax_scm",(void*)f_6225},
{"f_6300:chicken_syntax_scm",(void*)f_6300},
{"f_6553:chicken_syntax_scm",(void*)f_6553},
{"f_6566:chicken_syntax_scm",(void*)f_6566},
{"f_6303:chicken_syntax_scm",(void*)f_6303},
{"f_6539:chicken_syntax_scm",(void*)f_6539},
{"f_6551:chicken_syntax_scm",(void*)f_6551},
{"f_6547:chicken_syntax_scm",(void*)f_6547},
{"f_6306:chicken_syntax_scm",(void*)f_6306},
{"f_6493:chicken_syntax_scm",(void*)f_6493},
{"f_6526:chicken_syntax_scm",(void*)f_6526},
{"f_6533:chicken_syntax_scm",(void*)f_6533},
{"f_6509:chicken_syntax_scm",(void*)f_6509},
{"f_6318:chicken_syntax_scm",(void*)f_6318},
{"f_6487:chicken_syntax_scm",(void*)f_6487},
{"f_6325:chicken_syntax_scm",(void*)f_6325},
{"f_6327:chicken_syntax_scm",(void*)f_6327},
{"f_6481:chicken_syntax_scm",(void*)f_6481},
{"f_6365:chicken_syntax_scm",(void*)f_6365},
{"f_6447:chicken_syntax_scm",(void*)f_6447},
{"f_6404:chicken_syntax_scm",(void*)f_6404},
{"f_6384:chicken_syntax_scm",(void*)f_6384},
{"f_6351:chicken_syntax_scm",(void*)f_6351},
{"f_6359:chicken_syntax_scm",(void*)f_6359},
{"f_6345:chicken_syntax_scm",(void*)f_6345},
{"f_6349:chicken_syntax_scm",(void*)f_6349},
{"f_6307:chicken_syntax_scm",(void*)f_6307},
{"f_6258:chicken_syntax_scm",(void*)f_6258},
{"f_6281:chicken_syntax_scm",(void*)f_6281},
{"f_6285:chicken_syntax_scm",(void*)f_6285},
{"f_6227:chicken_syntax_scm",(void*)f_6227},
{"f_6248:chicken_syntax_scm",(void*)f_6248},
{"f_6207:chicken_syntax_scm",(void*)f_6207},
{"f_1675:chicken_syntax_scm",(void*)f_1675},
{"f_6137:chicken_syntax_scm",(void*)f_6137},
{"f_6141:chicken_syntax_scm",(void*)f_6141},
{"f_6150:chicken_syntax_scm",(void*)f_6150},
{"f_6153:chicken_syntax_scm",(void*)f_6153},
{"f_6158:chicken_syntax_scm",(void*)f_6158},
{"f_6195:chicken_syntax_scm",(void*)f_6195},
{"f_6176:chicken_syntax_scm",(void*)f_6176},
{"f_6135:chicken_syntax_scm",(void*)f_6135},
{"f_1678:chicken_syntax_scm",(void*)f_1678},
{"f_5971:chicken_syntax_scm",(void*)f_5971},
{"f_5975:chicken_syntax_scm",(void*)f_5975},
{"f_5984:chicken_syntax_scm",(void*)f_5984},
{"f_5987:chicken_syntax_scm",(void*)f_5987},
{"f_6127:chicken_syntax_scm",(void*)f_6127},
{"f_6125:chicken_syntax_scm",(void*)f_6125},
{"f_5990:chicken_syntax_scm",(void*)f_5990},
{"f_6109:chicken_syntax_scm",(void*)f_6109},
{"f_6121:chicken_syntax_scm",(void*)f_6121},
{"f_6117:chicken_syntax_scm",(void*)f_6117},
{"f_5993:chicken_syntax_scm",(void*)f_5993},
{"f_6103:chicken_syntax_scm",(void*)f_6103},
{"f_6013:chicken_syntax_scm",(void*)f_6013},
{"f_6027:chicken_syntax_scm",(void*)f_6027},
{"f_6055:chicken_syntax_scm",(void*)f_6055},
{"f_6065:chicken_syntax_scm",(void*)f_6065},
{"f_6081:chicken_syntax_scm",(void*)f_6081},
{"f_6063:chicken_syntax_scm",(void*)f_6063},
{"f_6059:chicken_syntax_scm",(void*)f_6059},
{"f_6021:chicken_syntax_scm",(void*)f_6021},
{"f_6025:chicken_syntax_scm",(void*)f_6025},
{"f_6017:chicken_syntax_scm",(void*)f_6017},
{"f_5994:chicken_syntax_scm",(void*)f_5994},
{"f_5969:chicken_syntax_scm",(void*)f_5969},
{"f_1681:chicken_syntax_scm",(void*)f_1681},
{"f_5965:chicken_syntax_scm",(void*)f_5965},
{"f_5888:chicken_syntax_scm",(void*)f_5888},
{"f_5892:chicken_syntax_scm",(void*)f_5892},
{"f_5895:chicken_syntax_scm",(void*)f_5895},
{"f_5898:chicken_syntax_scm",(void*)f_5898},
{"f_5933:chicken_syntax_scm",(void*)f_5933},
{"f_5886:chicken_syntax_scm",(void*)f_5886},
{"f_1684:chicken_syntax_scm",(void*)f_1684},
{"f_5783:chicken_syntax_scm",(void*)f_5783},
{"f_5787:chicken_syntax_scm",(void*)f_5787},
{"f_5874:chicken_syntax_scm",(void*)f_5874},
{"f_5870:chicken_syntax_scm",(void*)f_5870},
{"f_5789:chicken_syntax_scm",(void*)f_5789},
{"f_5793:chicken_syntax_scm",(void*)f_5793},
{"f_5850:chicken_syntax_scm",(void*)f_5850},
{"f_5802:chicken_syntax_scm",(void*)f_5802},
{"f_5824:chicken_syntax_scm",(void*)f_5824},
{"f_5814:chicken_syntax_scm",(void*)f_5814},
{"f_5805:chicken_syntax_scm",(void*)f_5805},
{"f_5781:chicken_syntax_scm",(void*)f_5781},
{"f_1687:chicken_syntax_scm",(void*)f_1687},
{"f_5620:chicken_syntax_scm",(void*)f_5620},
{"f_5624:chicken_syntax_scm",(void*)f_5624},
{"f_5633:chicken_syntax_scm",(void*)f_5633},
{"f_5636:chicken_syntax_scm",(void*)f_5636},
{"f_5641:chicken_syntax_scm",(void*)f_5641},
{"f_5686:chicken_syntax_scm",(void*)f_5686},
{"f_5753:chicken_syntax_scm",(void*)f_5753},
{"f_5715:chicken_syntax_scm",(void*)f_5715},
{"f_5655:chicken_syntax_scm",(void*)f_5655},
{"f_5659:chicken_syntax_scm",(void*)f_5659},
{"f_5618:chicken_syntax_scm",(void*)f_5618},
{"f_1690:chicken_syntax_scm",(void*)f_1690},
{"f_5454:chicken_syntax_scm",(void*)f_5454},
{"f_5458:chicken_syntax_scm",(void*)f_5458},
{"f_5467:chicken_syntax_scm",(void*)f_5467},
{"f_5470:chicken_syntax_scm",(void*)f_5470},
{"f_5473:chicken_syntax_scm",(void*)f_5473},
{"f_5476:chicken_syntax_scm",(void*)f_5476},
{"f_5479:chicken_syntax_scm",(void*)f_5479},
{"f_5486:chicken_syntax_scm",(void*)f_5486},
{"f_5504:chicken_syntax_scm",(void*)f_5504},
{"f_5520:chicken_syntax_scm",(void*)f_5520},
{"f_5526:chicken_syntax_scm",(void*)f_5526},
{"f_5582:chicken_syntax_scm",(void*)f_5582},
{"f_5580:chicken_syntax_scm",(void*)f_5580},
{"f_5576:chicken_syntax_scm",(void*)f_5576},
{"f_5568:chicken_syntax_scm",(void*)f_5568},
{"f_5564:chicken_syntax_scm",(void*)f_5564},
{"f_5533:chicken_syntax_scm",(void*)f_5533},
{"f_5502:chicken_syntax_scm",(void*)f_5502},
{"f_5452:chicken_syntax_scm",(void*)f_5452},
{"f_1693:chicken_syntax_scm",(void*)f_1693},
{"f_5448:chicken_syntax_scm",(void*)f_5448},
{"f_5444:chicken_syntax_scm",(void*)f_5444},
{"f_4999:chicken_syntax_scm",(void*)f_4999},
{"f_5003:chicken_syntax_scm",(void*)f_5003},
{"f_5015:chicken_syntax_scm",(void*)f_5015},
{"f_5018:chicken_syntax_scm",(void*)f_5018},
{"f_5021:chicken_syntax_scm",(void*)f_5021},
{"f_5321:chicken_syntax_scm",(void*)f_5321},
{"f_5324:chicken_syntax_scm",(void*)f_5324},
{"f_5327:chicken_syntax_scm",(void*)f_5327},
{"f_5420:chicken_syntax_scm",(void*)f_5420},
{"f_5428:chicken_syntax_scm",(void*)f_5428},
{"f_5343:chicken_syntax_scm",(void*)f_5343},
{"f_5346:chicken_syntax_scm",(void*)f_5346},
{"f_5349:chicken_syntax_scm",(void*)f_5349},
{"f_5352:chicken_syntax_scm",(void*)f_5352},
{"f_5410:chicken_syntax_scm",(void*)f_5410},
{"f_5418:chicken_syntax_scm",(void*)f_5418},
{"f_5355:chicken_syntax_scm",(void*)f_5355},
{"f_5358:chicken_syntax_scm",(void*)f_5358},
{"f_5361:chicken_syntax_scm",(void*)f_5361},
{"f_5368:chicken_syntax_scm",(void*)f_5368},
{"f_5328:chicken_syntax_scm",(void*)f_5328},
{"f_5340:chicken_syntax_scm",(void*)f_5340},
{"f_5336:chicken_syntax_scm",(void*)f_5336},
{"f_5120:chicken_syntax_scm",(void*)f_5120},
{"f_5126:chicken_syntax_scm",(void*)f_5126},
{"f_5314:chicken_syntax_scm",(void*)f_5314},
{"f_5302:chicken_syntax_scm",(void*)f_5302},
{"f_5286:chicken_syntax_scm",(void*)f_5286},
{"f_5250:chicken_syntax_scm",(void*)f_5250},
{"f_5200:chicken_syntax_scm",(void*)f_5200},
{"f_5188:chicken_syntax_scm",(void*)f_5188},
{"f_5023:chicken_syntax_scm",(void*)f_5023},
{"f_5031:chicken_syntax_scm",(void*)f_5031},
{"f_5035:chicken_syntax_scm",(void*)f_5035},
{"f_5039:chicken_syntax_scm",(void*)f_5039},
{"f_5041:chicken_syntax_scm",(void*)f_5041},
{"f_5094:chicken_syntax_scm",(void*)f_5094},
{"f_5110:chicken_syntax_scm",(void*)f_5110},
{"f_5106:chicken_syntax_scm",(void*)f_5106},
{"f_5062:chicken_syntax_scm",(void*)f_5062},
{"f_4997:chicken_syntax_scm",(void*)f_4997},
{"f_1696:chicken_syntax_scm",(void*)f_1696},
{"f_4989:chicken_syntax_scm",(void*)f_4989},
{"f_4985:chicken_syntax_scm",(void*)f_4985},
{"f_4981:chicken_syntax_scm",(void*)f_4981},
{"f_4774:chicken_syntax_scm",(void*)f_4774},
{"f_4778:chicken_syntax_scm",(void*)f_4778},
{"f_4781:chicken_syntax_scm",(void*)f_4781},
{"f_4784:chicken_syntax_scm",(void*)f_4784},
{"f_4791:chicken_syntax_scm",(void*)f_4791},
{"f_4941:chicken_syntax_scm",(void*)f_4941},
{"f_4826:chicken_syntax_scm",(void*)f_4826},
{"f_4902:chicken_syntax_scm",(void*)f_4902},
{"f_4914:chicken_syntax_scm",(void*)f_4914},
{"f_4886:chicken_syntax_scm",(void*)f_4886},
{"f_4772:chicken_syntax_scm",(void*)f_4772},
{"f_1699:chicken_syntax_scm",(void*)f_1699},
{"f_4764:chicken_syntax_scm",(void*)f_4764},
{"f_4460:chicken_syntax_scm",(void*)f_4460},
{"f_4464:chicken_syntax_scm",(void*)f_4464},
{"f_4476:chicken_syntax_scm",(void*)f_4476},
{"f_4479:chicken_syntax_scm",(void*)f_4479},
{"f_4482:chicken_syntax_scm",(void*)f_4482},
{"f_4485:chicken_syntax_scm",(void*)f_4485},
{"f_4488:chicken_syntax_scm",(void*)f_4488},
{"f_4491:chicken_syntax_scm",(void*)f_4491},
{"f_4512:chicken_syntax_scm",(void*)f_4512},
{"f_4740:chicken_syntax_scm",(void*)f_4740},
{"f_4602:chicken_syntax_scm",(void*)f_4602},
{"f_4621:chicken_syntax_scm",(void*)f_4621},
{"f_4578:chicken_syntax_scm",(void*)f_4578},
{"f_4510:chicken_syntax_scm",(void*)f_4510},
{"f_4458:chicken_syntax_scm",(void*)f_4458},
{"f_1702:chicken_syntax_scm",(void*)f_1702},
{"f_4450:chicken_syntax_scm",(void*)f_4450},
{"f_4446:chicken_syntax_scm",(void*)f_4446},
{"f_4442:chicken_syntax_scm",(void*)f_4442},
{"f_4438:chicken_syntax_scm",(void*)f_4438},
{"f_3995:chicken_syntax_scm",(void*)f_3995},
{"f_3999:chicken_syntax_scm",(void*)f_3999},
{"f_4036:chicken_syntax_scm",(void*)f_4036},
{"f_4391:chicken_syntax_scm",(void*)f_4391},
{"f_4401:chicken_syntax_scm",(void*)f_4401},
{"f_4389:chicken_syntax_scm",(void*)f_4389},
{"f_4039:chicken_syntax_scm",(void*)f_4039},
{"f_4042:chicken_syntax_scm",(void*)f_4042},
{"f_4045:chicken_syntax_scm",(void*)f_4045},
{"f_4048:chicken_syntax_scm",(void*)f_4048},
{"f_4051:chicken_syntax_scm",(void*)f_4051},
{"f_4054:chicken_syntax_scm",(void*)f_4054},
{"f_4057:chicken_syntax_scm",(void*)f_4057},
{"f_4060:chicken_syntax_scm",(void*)f_4060},
{"f_4063:chicken_syntax_scm",(void*)f_4063},
{"f_4066:chicken_syntax_scm",(void*)f_4066},
{"f_4069:chicken_syntax_scm",(void*)f_4069},
{"f_4080:chicken_syntax_scm",(void*)f_4080},
{"f_4106:chicken_syntax_scm",(void*)f_4106},
{"f_4116:chicken_syntax_scm",(void*)f_4116},
{"f_4120:chicken_syntax_scm",(void*)f_4120},
{"f_4134:chicken_syntax_scm",(void*)f_4134},
{"f_4158:chicken_syntax_scm",(void*)f_4158},
{"f_4185:chicken_syntax_scm",(void*)f_4185},
{"f_4333:chicken_syntax_scm",(void*)f_4333},
{"f_4253:chicken_syntax_scm",(void*)f_4253},
{"f_4272:chicken_syntax_scm",(void*)f_4272},
{"f_4242:chicken_syntax_scm",(void*)f_4242},
{"f_4210:chicken_syntax_scm",(void*)f_4210},
{"f_4162:chicken_syntax_scm",(void*)f_4162},
{"f_4179:chicken_syntax_scm",(void*)f_4179},
{"f_4148:chicken_syntax_scm",(void*)f_4148},
{"f_4156:chicken_syntax_scm",(void*)f_4156},
{"f_4142:chicken_syntax_scm",(void*)f_4142},
{"f_4104:chicken_syntax_scm",(void*)f_4104},
{"f_4001:chicken_syntax_scm",(void*)f_4001},
{"f_4007:chicken_syntax_scm",(void*)f_4007},
{"f_4033:chicken_syntax_scm",(void*)f_4033},
{"f_4021:chicken_syntax_scm",(void*)f_4021},
{"f_4025:chicken_syntax_scm",(void*)f_4025},
{"f_3993:chicken_syntax_scm",(void*)f_3993},
{"f_1705:chicken_syntax_scm",(void*)f_1705},
{"f_3893:chicken_syntax_scm",(void*)f_3893},
{"f_3897:chicken_syntax_scm",(void*)f_3897},
{"f_3962:chicken_syntax_scm",(void*)f_3962},
{"f_3977:chicken_syntax_scm",(void*)f_3977},
{"f_3912:chicken_syntax_scm",(void*)f_3912},
{"f_3935:chicken_syntax_scm",(void*)f_3935},
{"f_3947:chicken_syntax_scm",(void*)f_3947},
{"f_3891:chicken_syntax_scm",(void*)f_3891},
{"f_1708:chicken_syntax_scm",(void*)f_1708},
{"f_3887:chicken_syntax_scm",(void*)f_3887},
{"f_3883:chicken_syntax_scm",(void*)f_3883},
{"f_3679:chicken_syntax_scm",(void*)f_3679},
{"f_3683:chicken_syntax_scm",(void*)f_3683},
{"f_3686:chicken_syntax_scm",(void*)f_3686},
{"f_3689:chicken_syntax_scm",(void*)f_3689},
{"f_3692:chicken_syntax_scm",(void*)f_3692},
{"f_3703:chicken_syntax_scm",(void*)f_3703},
{"f_3731:chicken_syntax_scm",(void*)f_3731},
{"f_3823:chicken_syntax_scm",(void*)f_3823},
{"f_3677:chicken_syntax_scm",(void*)f_3677},
{"f_1711:chicken_syntax_scm",(void*)f_1711},
{"f_3669:chicken_syntax_scm",(void*)f_3669},
{"f_3665:chicken_syntax_scm",(void*)f_3665},
{"f_3325:chicken_syntax_scm",(void*)f_3325},
{"f_3329:chicken_syntax_scm",(void*)f_3329},
{"f_3332:chicken_syntax_scm",(void*)f_3332},
{"f_3335:chicken_syntax_scm",(void*)f_3335},
{"f_3338:chicken_syntax_scm",(void*)f_3338},
{"f_3341:chicken_syntax_scm",(void*)f_3341},
{"f_3344:chicken_syntax_scm",(void*)f_3344},
{"f_3347:chicken_syntax_scm",(void*)f_3347},
{"f_3350:chicken_syntax_scm",(void*)f_3350},
{"f_3525:chicken_syntax_scm",(void*)f_3525},
{"f_3565:chicken_syntax_scm",(void*)f_3565},
{"f_3573:chicken_syntax_scm",(void*)f_3573},
{"f_3569:chicken_syntax_scm",(void*)f_3569},
{"f_3352:chicken_syntax_scm",(void*)f_3352},
{"f_3476:chicken_syntax_scm",(void*)f_3476},
{"f_3474:chicken_syntax_scm",(void*)f_3474},
{"f_3470:chicken_syntax_scm",(void*)f_3470},
{"f_3462:chicken_syntax_scm",(void*)f_3462},
{"f_3443:chicken_syntax_scm",(void*)f_3443},
{"f_3428:chicken_syntax_scm",(void*)f_3428},
{"f_3413:chicken_syntax_scm",(void*)f_3413},
{"f_3394:chicken_syntax_scm",(void*)f_3394},
{"f_3379:chicken_syntax_scm",(void*)f_3379},
{"f_3323:chicken_syntax_scm",(void*)f_3323},
{"f_1714:chicken_syntax_scm",(void*)f_1714},
{"f_2923:chicken_syntax_scm",(void*)f_2923},
{"f_2927:chicken_syntax_scm",(void*)f_2927},
{"f_2942:chicken_syntax_scm",(void*)f_2942},
{"f_2945:chicken_syntax_scm",(void*)f_2945},
{"f_2948:chicken_syntax_scm",(void*)f_2948},
{"f_2951:chicken_syntax_scm",(void*)f_2951},
{"f_2954:chicken_syntax_scm",(void*)f_2954},
{"f_2960:chicken_syntax_scm",(void*)f_2960},
{"f_2963:chicken_syntax_scm",(void*)f_2963},
{"f_2966:chicken_syntax_scm",(void*)f_2966},
{"f_3284:chicken_syntax_scm",(void*)f_3284},
{"f_3282:chicken_syntax_scm",(void*)f_3282},
{"f_3278:chicken_syntax_scm",(void*)f_3278},
{"f_2995:chicken_syntax_scm",(void*)f_2995},
{"f_3021:chicken_syntax_scm",(void*)f_3021},
{"f_3061:chicken_syntax_scm",(void*)f_3061},
{"f_3037:chicken_syntax_scm",(void*)f_3037},
{"f_3033:chicken_syntax_scm",(void*)f_3033},
{"f_2993:chicken_syntax_scm",(void*)f_2993},
{"f_2989:chicken_syntax_scm",(void*)f_2989},
{"f_2921:chicken_syntax_scm",(void*)f_2921},
{"f_1717:chicken_syntax_scm",(void*)f_1717},
{"f_2913:chicken_syntax_scm",(void*)f_2913},
{"f_2723:chicken_syntax_scm",(void*)f_2723},
{"f_2727:chicken_syntax_scm",(void*)f_2727},
{"f_2730:chicken_syntax_scm",(void*)f_2730},
{"f_2733:chicken_syntax_scm",(void*)f_2733},
{"f_2736:chicken_syntax_scm",(void*)f_2736},
{"f_2739:chicken_syntax_scm",(void*)f_2739},
{"f_2748:chicken_syntax_scm",(void*)f_2748},
{"f_2851:chicken_syntax_scm",(void*)f_2851},
{"f_2879:chicken_syntax_scm",(void*)f_2879},
{"f_2873:chicken_syntax_scm",(void*)f_2873},
{"f_2854:chicken_syntax_scm",(void*)f_2854},
{"f_2758:chicken_syntax_scm",(void*)f_2758},
{"f_2761:chicken_syntax_scm",(void*)f_2761},
{"f_2833:chicken_syntax_scm",(void*)f_2833},
{"f_2810:chicken_syntax_scm",(void*)f_2810},
{"f_2767:chicken_syntax_scm",(void*)f_2767},
{"f_2778:chicken_syntax_scm",(void*)f_2778},
{"f_2798:chicken_syntax_scm",(void*)f_2798},
{"f_2721:chicken_syntax_scm",(void*)f_2721},
{"f_1720:chicken_syntax_scm",(void*)f_1720},
{"f_2713:chicken_syntax_scm",(void*)f_2713},
{"f_2492:chicken_syntax_scm",(void*)f_2492},
{"f_2496:chicken_syntax_scm",(void*)f_2496},
{"f_2499:chicken_syntax_scm",(void*)f_2499},
{"f_2502:chicken_syntax_scm",(void*)f_2502},
{"f_2505:chicken_syntax_scm",(void*)f_2505},
{"f_2508:chicken_syntax_scm",(void*)f_2508},
{"f_2517:chicken_syntax_scm",(void*)f_2517},
{"f_2636:chicken_syntax_scm",(void*)f_2636},
{"f_2664:chicken_syntax_scm",(void*)f_2664},
{"f_2697:chicken_syntax_scm",(void*)f_2697},
{"f_2670:chicken_syntax_scm",(void*)f_2670},
{"f_2658:chicken_syntax_scm",(void*)f_2658},
{"f_2639:chicken_syntax_scm",(void*)f_2639},
{"f_2527:chicken_syntax_scm",(void*)f_2527},
{"f_2530:chicken_syntax_scm",(void*)f_2530},
{"f_2626:chicken_syntax_scm",(void*)f_2626},
{"f_2591:chicken_syntax_scm",(void*)f_2591},
{"f_2536:chicken_syntax_scm",(void*)f_2536},
{"f_2559:chicken_syntax_scm",(void*)f_2559},
{"f_2579:chicken_syntax_scm",(void*)f_2579},
{"f_2490:chicken_syntax_scm",(void*)f_2490},
{"f_1723:chicken_syntax_scm",(void*)f_1723},
{"f_2211:chicken_syntax_scm",(void*)f_2211},
{"f_2215:chicken_syntax_scm",(void*)f_2215},
{"f_2218:chicken_syntax_scm",(void*)f_2218},
{"f_2221:chicken_syntax_scm",(void*)f_2221},
{"f_2224:chicken_syntax_scm",(void*)f_2224},
{"f_2227:chicken_syntax_scm",(void*)f_2227},
{"f_2230:chicken_syntax_scm",(void*)f_2230},
{"f_2239:chicken_syntax_scm",(void*)f_2239},
{"f_2385:chicken_syntax_scm",(void*)f_2385},
{"f_2388:chicken_syntax_scm",(void*)f_2388},
{"f_2397:chicken_syntax_scm",(void*)f_2397},
{"f_2422:chicken_syntax_scm",(void*)f_2422},
{"f_2447:chicken_syntax_scm",(void*)f_2447},
{"f_2469:chicken_syntax_scm",(void*)f_2469},
{"f_2462:chicken_syntax_scm",(void*)f_2462},
{"f_2454:chicken_syntax_scm",(void*)f_2454},
{"f_2441:chicken_syntax_scm",(void*)f_2441},
{"f_2437:chicken_syntax_scm",(void*)f_2437},
{"f_2416:chicken_syntax_scm",(void*)f_2416},
{"f_2412:chicken_syntax_scm",(void*)f_2412},
{"f_2379:chicken_syntax_scm",(void*)f_2379},
{"f_2249:chicken_syntax_scm",(void*)f_2249},
{"f_2256:chicken_syntax_scm",(void*)f_2256},
{"f_2364:chicken_syntax_scm",(void*)f_2364},
{"f_2352:chicken_syntax_scm",(void*)f_2352},
{"f_2348:chicken_syntax_scm",(void*)f_2348},
{"f_2284:chicken_syntax_scm",(void*)f_2284},
{"f_2312:chicken_syntax_scm",(void*)f_2312},
{"f_2324:chicken_syntax_scm",(void*)f_2324},
{"f_2308:chicken_syntax_scm",(void*)f_2308},
{"f_2209:chicken_syntax_scm",(void*)f_2209},
{"f_1726:chicken_syntax_scm",(void*)f_1726},
{"f_2107:chicken_syntax_scm",(void*)f_2107},
{"f_2111:chicken_syntax_scm",(void*)f_2111},
{"f_2117:chicken_syntax_scm",(void*)f_2117},
{"f_2201:chicken_syntax_scm",(void*)f_2201},
{"f_2162:chicken_syntax_scm",(void*)f_2162},
{"f_2174:chicken_syntax_scm",(void*)f_2174},
{"f_2105:chicken_syntax_scm",(void*)f_2105},
{"f_1729:chicken_syntax_scm",(void*)f_1729},
{"f_2070:chicken_syntax_scm",(void*)f_2070},
{"f_2074:chicken_syntax_scm",(void*)f_2074},
{"f_2081:chicken_syntax_scm",(void*)f_2081},
{"f_2093:chicken_syntax_scm",(void*)f_2093},
{"f_2097:chicken_syntax_scm",(void*)f_2097},
{"f_2068:chicken_syntax_scm",(void*)f_2068},
{"f_1732:chicken_syntax_scm",(void*)f_1732},
{"f_2045:chicken_syntax_scm",(void*)f_2045},
{"f_2049:chicken_syntax_scm",(void*)f_2049},
{"f_2043:chicken_syntax_scm",(void*)f_2043},
{"f_1735:chicken_syntax_scm",(void*)f_1735},
{"f_1913:chicken_syntax_scm",(void*)f_1913},
{"f_1923:chicken_syntax_scm",(void*)f_1923},
{"f_1973:chicken_syntax_scm",(void*)f_1973},
{"f_1986:chicken_syntax_scm",(void*)f_1986},
{"f_1939:chicken_syntax_scm",(void*)f_1939},
{"f_1955:chicken_syntax_scm",(void*)f_1955},
{"f_1911:chicken_syntax_scm",(void*)f_1911},
{"f_1738:chicken_syntax_scm",(void*)f_1738},
{"f_1766:chicken_syntax_scm",(void*)f_1766},
{"f_1859:chicken_syntax_scm",(void*)f_1859},
{"f_1863:chicken_syntax_scm",(void*)f_1863},
{"f_1881:chicken_syntax_scm",(void*)f_1881},
{"f_1846:chicken_syntax_scm",(void*)f_1846},
{"f_1776:chicken_syntax_scm",(void*)f_1776},
{"f_1826:chicken_syntax_scm",(void*)f_1826},
{"f_1779:chicken_syntax_scm",(void*)f_1779},
{"f_1812:chicken_syntax_scm",(void*)f_1812},
{"f_1782:chicken_syntax_scm",(void*)f_1782},
{"f_1792:chicken_syntax_scm",(void*)f_1792},
{"f_1802:chicken_syntax_scm",(void*)f_1802},
{"f_1800:chicken_syntax_scm",(void*)f_1800},
{"f_1764:chicken_syntax_scm",(void*)f_1764},
{"f_1741:chicken_syntax_scm",(void*)f_1741},
{"f_1756:chicken_syntax_scm",(void*)f_1756},
{"f_1754:chicken_syntax_scm",(void*)f_1754},
{"f_1744:chicken_syntax_scm",(void*)f_1744},
{"f_1747:chicken_syntax_scm",(void*)f_1747},
{"f_1750:chicken_syntax_scm",(void*)f_1750},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
