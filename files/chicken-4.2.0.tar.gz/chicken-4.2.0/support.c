/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:29
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: support.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -extend private-namespace.scm -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[507];
static double C_possibly_force_alignment;


/* from k4543 */
static C_word C_fcall stub334(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub334(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k4536 */
static C_word C_fcall stub329(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub329(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11492)
static void C_ccall f_11492(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11496)
static void C_ccall f_11496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11555)
static void C_ccall f_11555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11502)
static void C_ccall f_11502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11508)
static void C_ccall f_11508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11548)
static void C_ccall f_11548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11513)
static void C_ccall f_11513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11529)
static void C_ccall f_11529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11525)
static void C_ccall f_11525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11481)
static void C_ccall f_11481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11486)
static void C_ccall f_11486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11470)
static void C_ccall f_11470(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11475)
static void C_ccall f_11475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11464)
static void C_ccall f_11464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11436)
static void C_ccall f_11436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11436)
static void C_ccall f_11436r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11440)
static void C_ccall f_11440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11415)
static void C_ccall f_11415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11419)
static void C_ccall f_11419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11382)
static void C_ccall f_11382(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11388)
static void C_ccall f_11388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11349)
static void C_ccall f_11349(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11355)
static void C_ccall f_11355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11325)
static void C_ccall f_11325(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11256)
static void C_ccall f_11256(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11260)
static void C_ccall f_11260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11265)
static void C_fcall f_11265(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11269)
static void C_ccall f_11269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11320)
static void C_ccall f_11320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11299)
static void C_ccall f_11299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11311)
static void C_ccall f_11311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11314)
static void C_ccall f_11314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11287)
static void C_ccall f_11287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11223)
static void C_ccall f_11223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11233)
static void C_ccall f_11233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11236)
static void C_ccall f_11236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11136)
static void C_ccall f_11136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11145)
static void C_fcall f_11145(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11158)
static void C_ccall f_11158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11164)
static void C_ccall f_11164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11217)
static void C_ccall f_11217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11167)
static void C_ccall f_11167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11182)
static void C_ccall f_11182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11190)
static void C_fcall f_11190(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11200)
static void C_ccall f_11200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11185)
static void C_ccall f_11185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11173)
static void C_ccall f_11173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11140)
static void C_ccall f_11140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11130)
static void C_ccall f_11130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11112)
static void C_ccall f_11112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11066)
static void C_ccall f_11066(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11085)
static void C_ccall f_11085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11096)
static void C_ccall f_11096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11092)
static void C_ccall f_11092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11054)
static void C_ccall f_11054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11060)
static void C_ccall f_11060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11042)
static void C_ccall f_11042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11046)
static void C_ccall f_11046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10963)
static void C_ccall f_10963(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_10963)
static void C_ccall f_10963r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_10982)
static void C_ccall f_10982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11007)
static void C_ccall f_11007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11011)
static void C_ccall f_11011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11013)
static void C_fcall f_11013(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11020)
static void C_ccall f_11020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11033)
static void C_ccall f_11033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11037)
static void C_ccall f_11037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10966)
static void C_fcall f_10966(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10970)
static void C_ccall f_10970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10976)
static void C_ccall f_10976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10957)
static void C_ccall f_10957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10913)
static void C_ccall f_10913(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_10913)
static void C_ccall f_10913r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_10925)
static void C_ccall f_10925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10929)
static void C_ccall f_10929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10933)
static void C_ccall f_10933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10921)
static void C_ccall f_10921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10904)
static void C_ccall f_10904(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10898)
static void C_ccall f_10898(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10892)
static void C_ccall f_10892(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10880)
static void C_ccall f_10880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10884)
static void C_ccall f_10884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10887)
static void C_ccall f_10887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10842)
static void C_ccall f_10842(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_10842)
static void C_ccall f_10842r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_10846)
static void C_ccall f_10846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10849)
static void C_ccall f_10849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10856)
static void C_ccall f_10856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10800)
static void C_ccall f_10800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10809)
static void C_fcall f_10809(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10771)
static void C_ccall f_10771(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10781)
static void C_fcall f_10781(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10599)
static void C_ccall f_10599(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10766)
static void C_ccall f_10766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10753)
static void C_fcall f_10753(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10759)
static void C_ccall f_10759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10602)
static void C_fcall f_10602(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10621)
static void C_fcall f_10621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10715)
static void C_ccall f_10715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10727)
static void C_ccall f_10727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10685)
static void C_ccall f_10685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10696)
static void C_ccall f_10696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10676)
static void C_ccall f_10676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10662)
static void C_fcall f_10662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10640)
static void C_ccall f_10640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10646)
static void C_ccall f_10646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10650)
static void C_ccall f_10650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10521)
static void C_ccall f_10521(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10527)
static void C_ccall f_10527(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10582)
static void C_fcall f_10582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10555)
static void C_fcall f_10555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10549)
static void C_fcall f_10549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10525)
static void C_ccall f_10525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10223)
static void C_ccall f_10223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10422)
static void C_fcall f_10422(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10443)
static void C_fcall f_10443(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9907)
static void C_ccall f_9907(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10217)
static void C_ccall f_10217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9919)
static void C_ccall f_9919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9929)
static void C_fcall f_9929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9947)
static void C_ccall f_9947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9981)
static void C_fcall f_9981(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9910)
static void C_fcall f_9910(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9582)
static void C_ccall f_9582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9901)
static void C_ccall f_9901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9588)
static void C_ccall f_9588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9598)
static void C_fcall f_9598(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9607)
static void C_fcall f_9607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9619)
static void C_fcall f_9619(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9631)
static void C_fcall f_9631(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9637)
static void C_ccall f_9637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9671)
static void C_fcall f_9671(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9542)
static void C_ccall f_9542(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9576)
static void C_ccall f_9576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9548)
static void C_ccall f_9548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9552)
static void C_ccall f_9552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9511)
static void C_ccall f_9511(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9524)
static void C_ccall f_9524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9515)
static void C_fcall f_9515(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9480)
static void C_ccall f_9480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9493)
static void C_ccall f_9493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9484)
static void C_fcall f_9484(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8427)
static void C_ccall f_8427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9474)
static void C_ccall f_9474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8433)
static void C_ccall f_8433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8439)
static void C_fcall f_8439(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8468)
static void C_fcall f_8468(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8487)
static void C_fcall f_8487(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8506)
static void C_fcall f_8506(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8576)
static void C_fcall f_8576(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8595)
static void C_fcall f_8595(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8677)
static void C_fcall f_8677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8716)
static void C_fcall f_8716(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8735)
static void C_fcall f_8735(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8754)
static void C_fcall f_8754(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8834)
static void C_fcall f_8834(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8919)
static void C_fcall f_8919(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8994)
static void C_ccall f_8994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9028)
static void C_fcall f_9028(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9098)
static void C_ccall f_9098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9031)
static void C_ccall f_9031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8837)
static void C_ccall f_8837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8868)
static void C_fcall f_8868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8757)
static void C_ccall f_8757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8598)
static void C_ccall f_8598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8629)
static void C_fcall f_8629(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8509)
static void C_ccall f_8509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8540)
static void C_fcall f_8540(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8391)
static void C_ccall f_8391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8395)
static void C_ccall f_8395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8406)
static void C_ccall f_8406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8412)
static void C_ccall f_8412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8416)
static void C_ccall f_8416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8398)
static void C_ccall f_8398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8352)
static void C_ccall f_8352(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8364)
static void C_ccall f_8364(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8371)
static void C_ccall f_8371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8374)
static void C_ccall f_8374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8377)
static void C_ccall f_8377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8380)
static void C_ccall f_8380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8383)
static void C_ccall f_8383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8386)
static void C_ccall f_8386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8358)
static void C_ccall f_8358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8272)
static void C_ccall f_8272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8281)
static void C_ccall f_8281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8287)
static void C_ccall f_8287(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8276)
static void C_ccall f_8276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8251)
static void C_ccall f_8251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8261)
static void C_ccall f_8261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8212)
static void C_ccall f_8212(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8218)
static void C_ccall f_8218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8242)
static void C_fcall f_8242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8231)
static void C_ccall f_8231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8185)
static void C_ccall f_8185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8191)
static void C_ccall f_8191(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8201)
static void C_ccall f_8201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8154)
static void C_ccall f_8154(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8160)
static void C_ccall f_8160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8167)
static void C_fcall f_8167(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8170)
static void C_ccall f_8170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8062)
static void C_ccall f_8062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8086)
static void C_ccall f_8086(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7976)
static void C_ccall f_7976(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7982)
static void C_ccall f_7982(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7998)
static void C_fcall f_7998(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8012)
static void C_ccall f_8012(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8020)
static void C_ccall f_8020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7781)
static void C_ccall f_7781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7960)
static void C_ccall f_7960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7966)
static void C_ccall f_7966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7856)
static void C_fcall f_7856(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7878)
static void C_ccall f_7878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7891)
static void C_fcall f_7891(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7922)
static void C_ccall f_7922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7813)
static void C_fcall f_7813(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7835)
static void C_ccall f_7835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7784)
static void C_fcall f_7784(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7808)
static void C_ccall f_7808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7712)
static void C_ccall f_7712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7718)
static void C_ccall f_7718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7724)
static void C_fcall f_7724(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7728)
static void C_ccall f_7728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7775)
static void C_ccall f_7775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7739)
static void C_ccall f_7739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7764)
static void C_ccall f_7764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7532)
static void C_ccall f_7532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7563)
static void C_ccall f_7563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7710)
static void C_ccall f_7710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7567)
static void C_ccall f_7567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7575)
static void C_ccall f_7575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7582)
static void C_ccall f_7582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7703)
static void C_ccall f_7703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7606)
static void C_fcall f_7606(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7627)
static void C_ccall f_7627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7684)
static void C_ccall f_7684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7639)
static void C_ccall f_7639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7642)
static void C_fcall f_7642(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7660)
static void C_ccall f_7660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7649)
static void C_ccall f_7649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7570)
static void C_ccall f_7570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7536)
static void C_ccall f_7536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7542)
static void C_ccall f_7542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7555)
static void C_ccall f_7555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7547)
static void C_ccall f_7547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7507)
static void C_ccall f_7507(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7513)
static void C_ccall f_7513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7523)
static void C_ccall f_7523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7471)
static void C_ccall f_7471(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7477)
static void C_ccall f_7477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7501)
static void C_ccall f_7501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7497)
static void C_ccall f_7497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7447)
static void C_ccall f_7447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7451)
static void C_ccall f_7451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7454)
static void C_ccall f_7454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7457)
static void C_ccall f_7457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7413)
static void C_ccall f_7413(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7419)
static void C_fcall f_7419(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7433)
static void C_ccall f_7433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7437)
static void C_ccall f_7437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7235)
static void C_ccall f_7235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7239)
static void C_ccall f_7239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7247)
static void C_fcall f_7247(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7396)
static void C_ccall f_7396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7404)
static void C_ccall f_7404(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7399)
static void C_ccall f_7399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7348)
static void C_ccall f_7348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7352)
static void C_ccall f_7352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7355)
static void C_ccall f_7355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7374)
static void C_ccall f_7374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7390)
static void C_ccall f_7390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7382)
static void C_ccall f_7382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7366)
static void C_ccall f_7366(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7361)
static void C_ccall f_7361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7315)
static void C_ccall f_7315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7318)
static void C_ccall f_7318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7329)
static void C_ccall f_7329(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7324)
static void C_ccall f_7324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7299)
static void C_ccall f_7299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7291)
static void C_ccall f_7291(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7286)
static void C_ccall f_7286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7270)
static void C_ccall f_7270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7241)
static void C_fcall f_7241(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7142)
static void C_ccall f_7142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7148)
static void C_ccall f_7148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7160)
static void C_ccall f_7160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7164)
static void C_ccall f_7164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7167)
static void C_ccall f_7167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7227)
static void C_ccall f_7227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7203)
static void C_fcall f_7203(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7186)
static void C_fcall f_7186(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7190)
static void C_ccall f_7190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7172)
static void C_ccall f_7172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7154)
static void C_ccall f_7154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7094)
static void C_ccall f_7094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7100)
static void C_fcall f_7100(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7120)
static void C_ccall f_7120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7124)
static void C_ccall f_7124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6776)
static void C_ccall f_6776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6782)
static void C_ccall f_6782(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6801)
static void C_fcall f_6801(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7035)
static void C_fcall f_7035(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7065)
static void C_ccall f_7065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7061)
static void C_ccall f_7061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7042)
static void C_ccall f_7042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7046)
static void C_ccall f_7046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6973)
static void C_fcall f_6973(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7022)
static void C_ccall f_7022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6991)
static void C_ccall f_6991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6999)
static void C_ccall f_6999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6949)
static void C_ccall f_6949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6916)
static void C_ccall f_6916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6895)
static void C_ccall f_6895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6891)
static void C_ccall f_6891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6875)
static void C_ccall f_6875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6887)
static void C_ccall f_6887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6883)
static void C_ccall f_6883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6829)
static void C_ccall f_6829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6825)
static void C_ccall f_6825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6808)
static void C_ccall f_6808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6262)
static void C_ccall f_6262(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6771)
static void C_ccall f_6771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6774)
static void C_ccall f_6774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6265)
static void C_ccall f_6265(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6641)
static void C_fcall f_6641(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6684)
static void C_ccall f_6684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6721)
static void C_ccall f_6721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6698)
static void C_fcall f_6698(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6705)
static void C_ccall f_6705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6712)
static void C_ccall f_6712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6702)
static void C_ccall f_6702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6691)
static void C_ccall f_6691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6678)
static void C_ccall f_6678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6666)
static void C_ccall f_6666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6650)
static void C_ccall f_6650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6620)
static void C_ccall f_6620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6604)
static void C_ccall f_6604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6600)
static void C_ccall f_6600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6567)
static void C_ccall f_6567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6525)
static void C_ccall f_6525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6494)
static void C_fcall f_6494(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6480)
static void C_ccall f_6480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6454)
static void C_ccall f_6454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6400)
static void C_ccall f_6400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6418)
static void C_ccall f_6418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6403)
static void C_ccall f_6403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6350)
static void C_fcall f_6350(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6353)
static void C_ccall f_6353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6360)
static void C_ccall f_6360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6347)
static void C_fcall f_6347(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6253)
static void C_ccall f_6253(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6244)
static void C_ccall f_6244(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6238)
static void C_ccall f_6238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6229)
static void C_ccall f_6229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6220)
static void C_ccall f_6220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6211)
static void C_ccall f_6211(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6202)
static void C_ccall f_6202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6184)
static void C_ccall f_6184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6178)
static void C_ccall f_6178(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6170)
static void C_ccall f_6170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5728)
static void C_fcall f_5728(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5743)
static void C_ccall f_5743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5861)
static void C_fcall f_5861(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5871)
static void C_ccall f_5871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5887)
static void C_fcall f_5887(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5960)
static void C_fcall f_5960(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5991)
static void C_ccall f_5991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5981)
static void C_ccall f_5981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5967)
static void C_ccall f_5967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5971)
static void C_ccall f_5971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5951)
static void C_ccall f_5951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5925)
static void C_ccall f_5925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5902)
static void C_ccall f_5902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5874)
static void C_ccall f_5874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5746)
static void C_ccall f_5746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5781)
static void C_fcall f_5781(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_fcall f_5802(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5823)
static void C_fcall f_5823(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5749)
static void C_ccall f_5749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5752)
static void C_ccall f_5752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5755)
static void C_ccall f_5755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5705)
static void C_ccall f_5705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5711)
static void C_ccall f_5711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5722)
static void C_ccall f_5722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5687)
static void C_fcall f_5687(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5697)
static void C_ccall f_5697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5655)
static void C_fcall f_5655(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5635)
static void C_ccall f_5635(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5578)
static void C_ccall f_5578(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5578)
static void C_ccall f_5578r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5582)
static void C_ccall f_5582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5612)
static void C_ccall f_5612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5530)
static void C_ccall f_5530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5462)
static void C_ccall f_5462(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5462)
static void C_ccall f_5462r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5466)
static void C_ccall f_5466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5474)
static void C_ccall f_5474(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5257)
static void C_ccall f_5257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5375)
static void C_ccall f_5375(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5406)
static void C_ccall f_5406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5417)
static void C_ccall f_5417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5265)
static void C_ccall f_5265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5312)
static void C_ccall f_5312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5337)
static void C_ccall f_5337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5348)
static void C_ccall f_5348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5273)
static void C_ccall f_5273(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5279)
static void C_ccall f_5279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5116)
static void C_ccall f_5116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5120)
static void C_ccall f_5120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5124)
static void C_ccall f_5124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5113)
static void C_ccall f_5113(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5110)
static void C_ccall f_5110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5043)
static void C_ccall f_5043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5097)
static void C_ccall f_5097(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5097)
static void C_ccall f_5097r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5103)
static void C_ccall f_5103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5049)
static void C_ccall f_5049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5081)
static void C_ccall f_5081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5095)
static void C_ccall f_5095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5053)
static void C_ccall f_5053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5035)
static void C_ccall f_5035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5010)
static void C_ccall f_5010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4908)
static void C_fcall f_4908(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4936)
static void C_fcall f_4936(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4900)
static void C_ccall f_4900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4879)
static void C_ccall f_4879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4796)
static void C_ccall f_4796(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4800)
static void C_fcall f_4800(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4714)
static void C_ccall f_4714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4675)
static void C_fcall f_4675(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4622)
static void C_fcall f_4622(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4630)
static void C_fcall f_4630(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4594)
static void C_ccall f_4594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4547)
static void C_ccall f_4547(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4547)
static void C_ccall f_4547r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4575)
static void C_fcall f_4575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4540)
static void C_ccall f_4540(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4477)
static void C_ccall f_4477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4531)
static void C_ccall f_4531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4504)
static void C_ccall f_4504(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4401)
static void C_fcall f_4401(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4423)
static void C_fcall f_4423(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4430)
static void C_fcall f_4430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4438)
static void C_ccall f_4438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4339)
static void C_ccall f_4339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4345)
static void C_fcall f_4345(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4263)
static C_word C_fcall f_4263(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4213)
static void C_fcall f_4213(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4192)
static void C_fcall f_4192(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4200)
static void C_ccall f_4200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4146)
static void C_ccall f_4146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4152)
static void C_fcall f_4152(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4143)
static void C_ccall f_4143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4102)
static void C_ccall f_4102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4105)
static void C_fcall f_4105(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4108)
static void C_ccall f_4108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4119)
static void C_ccall f_4119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4111)
static void C_ccall f_4111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4057)
static void C_fcall f_4057(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4035)
static void C_ccall f_4035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4026)
static void C_ccall f_4026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_11265)
static void C_fcall trf_11265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11265(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11265(t0,t1);}

C_noret_decl(trf_11145)
static void C_fcall trf_11145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11145(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11145(t0,t1,t2,t3);}

C_noret_decl(trf_11190)
static void C_fcall trf_11190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11190(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11190(t0,t1,t2);}

C_noret_decl(trf_11013)
static void C_fcall trf_11013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11013(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11013(t0,t1,t2,t3);}

C_noret_decl(trf_10966)
static void C_fcall trf_10966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10966(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10966(t0,t1);}

C_noret_decl(trf_10809)
static void C_fcall trf_10809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10809(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10809(t0,t1,t2);}

C_noret_decl(trf_10781)
static void C_fcall trf_10781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10781(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10781(t0,t1);}

C_noret_decl(trf_10753)
static void C_fcall trf_10753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10753(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10753(t0,t1,t2,t3);}

C_noret_decl(trf_10602)
static void C_fcall trf_10602(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10602(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10602(t0,t1,t2,t3);}

C_noret_decl(trf_10621)
static void C_fcall trf_10621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10621(t0,t1);}

C_noret_decl(trf_10662)
static void C_fcall trf_10662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10662(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10662(t0,t1);}

C_noret_decl(trf_10582)
static void C_fcall trf_10582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10582(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10582(t0,t1);}

C_noret_decl(trf_10555)
static void C_fcall trf_10555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10555(t0,t1);}

C_noret_decl(trf_10549)
static void C_fcall trf_10549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10549(t0,t1);}

C_noret_decl(trf_10422)
static void C_fcall trf_10422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10422(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10422(t0,t1);}

C_noret_decl(trf_10443)
static void C_fcall trf_10443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10443(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10443(t0,t1);}

C_noret_decl(trf_9929)
static void C_fcall trf_9929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9929(t0,t1);}

C_noret_decl(trf_9981)
static void C_fcall trf_9981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9981(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9981(t0,t1);}

C_noret_decl(trf_9910)
static void C_fcall trf_9910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9910(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9910(t0,t1);}

C_noret_decl(trf_9598)
static void C_fcall trf_9598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9598(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9598(t0,t1);}

C_noret_decl(trf_9607)
static void C_fcall trf_9607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9607(t0,t1);}

C_noret_decl(trf_9619)
static void C_fcall trf_9619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9619(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9619(t0,t1);}

C_noret_decl(trf_9631)
static void C_fcall trf_9631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9631(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9631(t0,t1);}

C_noret_decl(trf_9671)
static void C_fcall trf_9671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9671(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9671(t0,t1);}

C_noret_decl(trf_9515)
static void C_fcall trf_9515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9515(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9515(t0,t1);}

C_noret_decl(trf_9484)
static void C_fcall trf_9484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9484(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9484(t0,t1);}

C_noret_decl(trf_8439)
static void C_fcall trf_8439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8439(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8439(t0,t1,t2);}

C_noret_decl(trf_8468)
static void C_fcall trf_8468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8468(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8468(t0,t1);}

C_noret_decl(trf_8487)
static void C_fcall trf_8487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8487(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8487(t0,t1);}

C_noret_decl(trf_8506)
static void C_fcall trf_8506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8506(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8506(t0,t1);}

C_noret_decl(trf_8576)
static void C_fcall trf_8576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8576(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8576(t0,t1);}

C_noret_decl(trf_8595)
static void C_fcall trf_8595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8595(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8595(t0,t1);}

C_noret_decl(trf_8677)
static void C_fcall trf_8677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8677(t0,t1);}

C_noret_decl(trf_8716)
static void C_fcall trf_8716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8716(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8716(t0,t1);}

C_noret_decl(trf_8735)
static void C_fcall trf_8735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8735(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8735(t0,t1);}

C_noret_decl(trf_8754)
static void C_fcall trf_8754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8754(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8754(t0,t1);}

C_noret_decl(trf_8834)
static void C_fcall trf_8834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8834(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8834(t0,t1);}

C_noret_decl(trf_8919)
static void C_fcall trf_8919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8919(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8919(t0,t1);}

C_noret_decl(trf_9028)
static void C_fcall trf_9028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9028(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9028(t0,t1);}

C_noret_decl(trf_8868)
static void C_fcall trf_8868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8868(t0,t1);}

C_noret_decl(trf_8629)
static void C_fcall trf_8629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8629(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8629(t0,t1);}

C_noret_decl(trf_8540)
static void C_fcall trf_8540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8540(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8540(t0,t1);}

C_noret_decl(trf_8242)
static void C_fcall trf_8242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8242(t0,t1);}

C_noret_decl(trf_8167)
static void C_fcall trf_8167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8167(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8167(t0,t1);}

C_noret_decl(trf_7998)
static void C_fcall trf_7998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7998(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7998(t0,t1);}

C_noret_decl(trf_7856)
static void C_fcall trf_7856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7856(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7856(t0,t1,t2,t3);}

C_noret_decl(trf_7891)
static void C_fcall trf_7891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7891(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7891(t0,t1,t2,t3);}

C_noret_decl(trf_7813)
static void C_fcall trf_7813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7813(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7813(t0,t1,t2,t3);}

C_noret_decl(trf_7784)
static void C_fcall trf_7784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7784(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7784(t0,t1,t2,t3);}

C_noret_decl(trf_7724)
static void C_fcall trf_7724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7724(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7724(t0,t1);}

C_noret_decl(trf_7606)
static void C_fcall trf_7606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7606(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7606(t0,t1);}

C_noret_decl(trf_7642)
static void C_fcall trf_7642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7642(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7642(t0,t1);}

C_noret_decl(trf_7419)
static void C_fcall trf_7419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7419(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7419(t0,t1,t2);}

C_noret_decl(trf_7247)
static void C_fcall trf_7247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7247(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7247(t0,t1,t2,t3);}

C_noret_decl(trf_7241)
static void C_fcall trf_7241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7241(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7241(t0,t1,t2);}

C_noret_decl(trf_7203)
static void C_fcall trf_7203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7203(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7203(t0,t1);}

C_noret_decl(trf_7186)
static void C_fcall trf_7186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7186(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7186(t0,t1);}

C_noret_decl(trf_7100)
static void C_fcall trf_7100(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7100(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7100(t0,t1,t2);}

C_noret_decl(trf_6801)
static void C_fcall trf_6801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6801(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6801(t0,t1);}

C_noret_decl(trf_7035)
static void C_fcall trf_7035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7035(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7035(t0,t1);}

C_noret_decl(trf_6973)
static void C_fcall trf_6973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6973(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6973(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6641)
static void C_fcall trf_6641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6641(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6641(t0,t1);}

C_noret_decl(trf_6698)
static void C_fcall trf_6698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6698(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6698(t0,t1);}

C_noret_decl(trf_6494)
static void C_fcall trf_6494(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6494(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6494(t0,t1);}

C_noret_decl(trf_6350)
static void C_fcall trf_6350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6350(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6350(t0,t1);}

C_noret_decl(trf_6347)
static void C_fcall trf_6347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6347(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6347(t0,t1);}

C_noret_decl(trf_5728)
static void C_fcall trf_5728(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5728(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5728(t0,t1);}

C_noret_decl(trf_5861)
static void C_fcall trf_5861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5861(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5861(t0,t1,t2);}

C_noret_decl(trf_5887)
static void C_fcall trf_5887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5887(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5887(t0,t1);}

C_noret_decl(trf_5960)
static void C_fcall trf_5960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5960(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5960(t0,t1);}

C_noret_decl(trf_5781)
static void C_fcall trf_5781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5781(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5781(t0,t1);}

C_noret_decl(trf_5802)
static void C_fcall trf_5802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5802(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5802(t0,t1);}

C_noret_decl(trf_5823)
static void C_fcall trf_5823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5823(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5823(t0,t1);}

C_noret_decl(trf_5687)
static void C_fcall trf_5687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5687(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5687(t0,t1,t2);}

C_noret_decl(trf_5655)
static void C_fcall trf_5655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5655(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5655(t0,t1);}

C_noret_decl(trf_4908)
static void C_fcall trf_4908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4908(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4908(t0,t1,t2);}

C_noret_decl(trf_4936)
static void C_fcall trf_4936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4936(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4936(t0,t1);}

C_noret_decl(trf_4800)
static void C_fcall trf_4800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4800(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4800(t0,t1);}

C_noret_decl(trf_4675)
static void C_fcall trf_4675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4675(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4675(t0,t1,t2,t3);}

C_noret_decl(trf_4622)
static void C_fcall trf_4622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4622(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4622(t0,t1,t2);}

C_noret_decl(trf_4630)
static void C_fcall trf_4630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4630(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4630(t0,t1);}

C_noret_decl(trf_4575)
static void C_fcall trf_4575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4575(t0,t1);}

C_noret_decl(trf_4401)
static void C_fcall trf_4401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4401(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4401(t0,t1,t2);}

C_noret_decl(trf_4423)
static void C_fcall trf_4423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4423(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4423(t0,t1);}

C_noret_decl(trf_4430)
static void C_fcall trf_4430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4430(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4430(t0,t1);}

C_noret_decl(trf_4345)
static void C_fcall trf_4345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4345(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4345(t0,t1,t2,t3);}

C_noret_decl(trf_4213)
static void C_fcall trf_4213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4213(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4213(t0,t1,t2,t3);}

C_noret_decl(trf_4192)
static void C_fcall trf_4192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4192(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4192(t0,t1);}

C_noret_decl(trf_4152)
static void C_fcall trf_4152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4152(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4152(t0,t1,t2);}

C_noret_decl(trf_4105)
static void C_fcall trf_4105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4105(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4105(t0,t1);}

C_noret_decl(trf_4057)
static void C_fcall trf_4057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4057(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4057(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5098)){
C_save(t1);
C_rereclaim2(5098*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,507);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],30,"\010compilercompiler-cleanup-hook");
lf[3]=C_h_intern(&lf[3],26,"\010compilerdebugging-chicken");
lf[4]=C_h_intern(&lf[4],26,"\010compilerdisabled-warnings");
lf[5]=C_h_intern(&lf[5],13,"\010compilerbomb");
lf[6]=C_h_intern(&lf[6],5,"error");
lf[7]=C_h_intern(&lf[7],13,"string-append");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[10]=C_h_intern(&lf[10],18,"\010compilerdebugging");
lf[11]=C_h_intern(&lf[11],12,"flush-output");
lf[12]=C_h_intern(&lf[12],7,"newline");
lf[13]=C_h_intern(&lf[13],6,"printf");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\003~s ");
lf[15]=C_h_intern(&lf[15],5,"force");
lf[16]=C_h_intern(&lf[16],12,"\003sysfor-each");
lf[17]=C_h_intern(&lf[17],7,"display");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[20]=C_h_intern(&lf[20],25,"\010compilercompiler-warning");
lf[21]=C_h_intern(&lf[21],7,"fprintf");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\012\012Warning: ");
lf[23]=C_h_intern(&lf[23],18,"current-error-port");
lf[24]=C_h_intern(&lf[24],20,"\003syswarnings-enabled");
lf[25]=C_h_intern(&lf[25],4,"quit");
lf[26]=C_h_intern(&lf[26],4,"exit");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\010\012Error: ");
lf[28]=C_h_intern(&lf[28],21,"\003syssyntax-error-hook");
lf[29]=C_h_intern(&lf[29],16,"print-call-chain");
lf[30]=C_h_intern(&lf[30],18,"\003syscurrent-thread");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\031Syntax error (~a): ~a~%~%");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\024Syntax error: ~a~%~%");
lf[35]=C_h_intern(&lf[35],12,"syntax-error");
lf[36]=C_h_intern(&lf[36],31,"\010compileremit-syntax-trace-info");
lf[37]=C_h_intern(&lf[37],9,"map-llist");
lf[38]=C_h_intern(&lf[38],24,"\010compilercheck-signature");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[40]=C_h_intern(&lf[40],18,"\010compilerreal-name");
lf[41]=C_h_intern(&lf[41],13,"\010compilerposq");
lf[42]=C_h_intern(&lf[42],18,"\010compilerstringify");
lf[43]=C_h_intern(&lf[43],14,"symbol->string");
lf[44]=C_h_intern(&lf[44],7,"sprintf");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[46]=C_h_intern(&lf[46],18,"\010compilersymbolify");
lf[47]=C_h_intern(&lf[47],14,"string->symbol");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\002~a");
lf[49]=C_h_intern(&lf[49],26,"\010compilerbuild-lambda-list");
lf[50]=C_h_intern(&lf[50],29,"\010compilerstring->c-identifier");
lf[51]=C_h_intern(&lf[51],24,"\003sysstring->c-identifier");
lf[52]=C_h_intern(&lf[52],21,"\010compilerc-ify-string");
lf[53]=C_h_intern(&lf[53],16,"\003syslist->string");
lf[54]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[55]=C_h_intern(&lf[55],6,"append");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[57]=C_h_intern(&lf[57],16,"\003sysstring->list");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[61]=C_h_intern(&lf[61],28,"\010compilervalid-c-identifier\077");
lf[62]=C_h_intern(&lf[62],3,"any");
lf[63]=C_h_intern(&lf[63],8,"->string");
lf[64]=C_h_intern(&lf[64],14,"\010compilerwords");
lf[65]=C_h_intern(&lf[65],21,"\010compilerwords->bytes");
lf[66]=C_h_intern(&lf[66],34,"\010compilercheck-and-open-input-file");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[68]=C_h_intern(&lf[68],18,"current-input-port");
lf[69]=C_h_intern(&lf[69],15,"open-input-file");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\037Can not open file ~s in line ~s");
lf[72]=C_h_intern(&lf[72],12,"file-exists\077");
lf[73]=C_h_intern(&lf[73],33,"\010compilerclose-checked-input-file");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[75]=C_h_intern(&lf[75],16,"close-input-port");
lf[76]=C_h_intern(&lf[76],19,"\010compilerfold-inner");
lf[77]=C_h_intern(&lf[77],7,"reverse");
lf[78]=C_h_intern(&lf[78],28,"\010compilerfollow-without-loop");
lf[79]=C_h_intern(&lf[79],21,"\010compilersort-symbols");
lf[80]=C_h_intern(&lf[80],8,"string<\077");
lf[81]=C_h_intern(&lf[81],4,"sort");
lf[82]=C_h_intern(&lf[82],18,"\010compilerconstant\077");
lf[83]=C_h_intern(&lf[83],5,"quote");
lf[84]=C_h_intern(&lf[84],29,"\010compilercollapsable-literal\077");
lf[85]=C_h_intern(&lf[85],19,"\010compilerimmediate\077");
lf[86]=C_h_intern(&lf[86],20,"\010compilerbig-fixnum\077");
lf[87]=C_h_intern(&lf[87],23,"\010compilerbasic-literal\077");
lf[88]=C_h_intern(&lf[88],5,"every");
lf[89]=C_h_intern(&lf[89],12,"vector->list");
lf[90]=C_h_intern(&lf[90],32,"\010compilercanonicalize-begin-body");
lf[91]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[92]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[93]=C_h_intern(&lf[93],3,"let");
lf[94]=C_h_intern(&lf[94],6,"gensym");
lf[95]=C_h_intern(&lf[95],1,"t");
lf[96]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[97]=C_h_intern(&lf[97],21,"\010compilerstring->expr");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot parse expression: ~s [~a]~%");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[100]=C_h_intern(&lf[100],5,"begin");
lf[101]=C_h_intern(&lf[101],10,"\003sysappend");
lf[102]=C_h_intern(&lf[102],4,"read");
lf[103]=C_h_intern(&lf[103],6,"unfold");
lf[104]=C_h_intern(&lf[104],11,"eof-object\077");
lf[105]=C_h_intern(&lf[105],6,"values");
lf[106]=C_h_intern(&lf[106],22,"with-input-from-string");
lf[107]=C_h_intern(&lf[107],22,"with-exception-handler");
lf[108]=C_h_intern(&lf[108],30,"call-with-current-continuation");
lf[109]=C_h_intern(&lf[109],30,"\010compilerdecompose-lambda-list");
lf[110]=C_h_intern(&lf[110],25,"\003sysdecompose-lambda-list");
lf[111]=C_h_intern(&lf[111],37,"\010compilerprocess-lambda-documentation");
lf[112]=C_h_intern(&lf[112],21,"\010compilerllist-length");
lf[113]=C_h_intern(&lf[113],30,"\010compilerexpand-profile-lambda");
lf[114]=C_h_intern(&lf[114],29,"\010compilerprofile-lambda-index");
lf[115]=C_h_intern(&lf[115],28,"\010compilerprofile-lambda-list");
lf[116]=C_h_intern(&lf[116],33,"\010compilerprofile-info-vector-name");
lf[117]=C_h_intern(&lf[117],17,"\003sysprofile-entry");
lf[118]=C_h_intern(&lf[118],6,"lambda");
lf[119]=C_h_intern(&lf[119],5,"apply");
lf[120]=C_h_intern(&lf[120],16,"\003sysprofile-exit");
lf[121]=C_h_intern(&lf[121],16,"\003sysdynamic-wind");
lf[122]=C_h_intern(&lf[122],10,"alist-cons");
lf[123]=C_h_intern(&lf[123],37,"\010compilerinitialize-analysis-database");
lf[124]=C_h_intern(&lf[124],8,"internal");
lf[125]=C_h_intern(&lf[125],8,"\003sysput!");
lf[126]=C_h_intern(&lf[126],18,"\010compilerintrinsic");
lf[127]=C_h_intern(&lf[127],9,"\003syserror");
lf[128]=C_h_intern(&lf[128],26,"\010compilerinternal-bindings");
lf[129]=C_h_intern(&lf[129],26,"\010compilerfoldable-bindings");
lf[130]=C_h_intern(&lf[130],17,"\010compilerfoldable");
lf[131]=C_h_intern(&lf[131],8,"extended");
lf[132]=C_h_intern(&lf[132],17,"extended-bindings");
lf[133]=C_h_intern(&lf[133],8,"standard");
lf[134]=C_h_intern(&lf[134],17,"standard-bindings");
lf[135]=C_h_intern(&lf[135],12,"\010compilerget");
lf[136]=C_h_intern(&lf[136],18,"\003syshash-table-ref");
lf[137]=C_h_intern(&lf[137],16,"\010compilerget-all");
lf[138]=C_h_intern(&lf[138],10,"filter-map");
lf[139]=C_h_intern(&lf[139],13,"\010compilerput!");
lf[140]=C_h_intern(&lf[140],19,"\003syshash-table-set!");
lf[141]=C_h_intern(&lf[141],17,"\010compilercollect!");
lf[142]=C_h_intern(&lf[142],15,"\010compilercount!");
lf[143]=C_h_intern(&lf[143],17,"\010compilerget-line");
lf[144]=C_h_intern(&lf[144],24,"\003sysline-number-database");
lf[145]=C_h_intern(&lf[145],19,"\010compilerget-line-2");
lf[146]=C_h_intern(&lf[146],30,"\010compilerfind-lambda-container");
lf[147]=C_h_intern(&lf[147],12,"contained-in");
lf[148]=C_h_intern(&lf[148],37,"\010compilerdisplay-line-number-database");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\007~S ~S~%");
lf[150]=C_h_intern(&lf[150],7,"\003sysmap");
lf[151]=C_h_intern(&lf[151],3,"cdr");
lf[152]=C_h_intern(&lf[152],23,"\003syshash-table-for-each");
lf[153]=C_h_intern(&lf[153],34,"\010compilerdisplay-analysis-database");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\007\011css=~s");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\010\011refs=~s");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\007\011val=~s");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\010\011lval=~s");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\010\011pval=~s");
lf[159]=C_h_intern(&lf[159],7,"unknown");
lf[160]=C_h_intern(&lf[160],8,"captured");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376"
"\001\000\000\003col\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\011undefined\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003"
"uud\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000"
"\000\002\376\003\000\000\002\376\001\000\000\012boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\003\011~a");
lf[163]=C_h_intern(&lf[163],4,"caar");
lf[164]=C_h_intern(&lf[164],5,"value");
lf[165]=C_h_intern(&lf[165],4,"cdar");
lf[166]=C_h_intern(&lf[166],11,"local-value");
lf[167]=C_h_intern(&lf[167],15,"potential-value");
lf[168]=C_h_intern(&lf[168],10,"replacable");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\006\011~a=~s");
lf[170]=C_h_intern(&lf[170],10,"references");
lf[171]=C_h_intern(&lf[171],10,"call-sites");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[173]=C_h_intern(&lf[173],4,"home");
lf[174]=C_h_intern(&lf[174],8,"contains");
lf[175]=C_h_intern(&lf[175],8,"use-expr");
lf[176]=C_h_intern(&lf[176],12,"closure-size");
lf[177]=C_h_intern(&lf[177],14,"rest-parameter");
lf[178]=C_h_intern(&lf[178],16,"o-r/access-count");
lf[179]=C_h_intern(&lf[179],18,"captured-variables");
lf[180]=C_h_intern(&lf[180],13,"explicit-rest");
lf[181]=C_h_intern(&lf[181],8,"assigned");
lf[182]=C_h_intern(&lf[182],5,"boxed");
lf[183]=C_h_intern(&lf[183],6,"global");
lf[184]=C_h_intern(&lf[184],12,"contractable");
lf[185]=C_h_intern(&lf[185],16,"standard-binding");
lf[186]=C_h_intern(&lf[186],16,"assigned-locally");
lf[187]=C_h_intern(&lf[187],11,"collapsable");
lf[188]=C_h_intern(&lf[188],9,"removable");
lf[189]=C_h_intern(&lf[189],9,"undefined");
lf[190]=C_h_intern(&lf[190],9,"replacing");
lf[191]=C_h_intern(&lf[191],6,"unused");
lf[192]=C_h_intern(&lf[192],6,"simple");
lf[193]=C_h_intern(&lf[193],9,"inlinable");
lf[194]=C_h_intern(&lf[194],13,"inline-export");
lf[195]=C_h_intern(&lf[195],21,"has-unused-parameters");
lf[196]=C_h_intern(&lf[196],16,"extended-binding");
lf[197]=C_h_intern(&lf[197],12,"customizable");
lf[198]=C_h_intern(&lf[198],8,"constant");
lf[199]=C_h_intern(&lf[199],10,"boxed-rest");
lf[200]=C_h_intern(&lf[200],11,"hidden-refs");
lf[201]=C_h_intern(&lf[201],5,"write");
lf[202]=C_h_intern(&lf[202],34,"\010compilerdefault-standard-bindings");
lf[203]=C_h_intern(&lf[203],34,"\010compilerdefault-extended-bindings");
lf[204]=C_h_intern(&lf[204],9,"make-node");
lf[205]=C_h_intern(&lf[205],4,"node");
lf[206]=C_h_intern(&lf[206],5,"node\077");
lf[207]=C_h_intern(&lf[207],15,"node-class-set!");
lf[208]=C_h_intern(&lf[208],14,"\003sysblock-set!");
lf[209]=C_h_intern(&lf[209],10,"node-class");
lf[210]=C_h_intern(&lf[210],20,"node-parameters-set!");
lf[211]=C_h_intern(&lf[211],15,"node-parameters");
lf[212]=C_h_intern(&lf[212],24,"node-subexpressions-set!");
lf[213]=C_h_intern(&lf[213],19,"node-subexpressions");
lf[214]=C_h_intern(&lf[214],16,"\010compilervarnode");
lf[215]=C_h_intern(&lf[215],13,"\004corevariable");
lf[216]=C_h_intern(&lf[216],14,"\010compilerqnode");
lf[217]=C_h_intern(&lf[217],25,"\010compilerbuild-node-graph");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[219]=C_h_intern(&lf[219],15,"\004coreglobal-ref");
lf[220]=C_h_intern(&lf[220],2,"if");
lf[221]=C_h_intern(&lf[221],14,"\004coreundefined");
lf[222]=C_h_intern(&lf[222],8,"truncate");
lf[223]=C_h_intern(&lf[223],4,"type");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000;literal \047~s\047 is out of range - will be truncated to integer");
lf[225]=C_h_intern(&lf[225],6,"fixnum");
lf[226]=C_h_intern(&lf[226],11,"number-type");
lf[227]=C_h_intern(&lf[227],6,"unzip1");
lf[228]=C_h_intern(&lf[228],11,"\004corelambda");
lf[229]=C_h_intern(&lf[229],14,"\004coreprimitive");
lf[230]=C_h_intern(&lf[230],11,"\004coreinline");
lf[231]=C_h_intern(&lf[231],13,"\004corecallunit");
lf[232]=C_h_intern(&lf[232],9,"\004coreproc");
lf[233]=C_h_intern(&lf[233],4,"set!");
lf[234]=C_h_intern(&lf[234],9,"\004coreset!");
lf[235]=C_h_intern(&lf[235],29,"\004coreforeign-callback-wrapper");
lf[236]=C_h_intern(&lf[236],5,"sixth");
lf[237]=C_h_intern(&lf[237],5,"fifth");
lf[238]=C_h_intern(&lf[238],20,"\004coreinline_allocate");
lf[239]=C_h_intern(&lf[239],8,"\004coreapp");
lf[240]=C_h_intern(&lf[240],9,"\004corecall");
lf[241]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[242]=C_h_intern(&lf[242],24,"\010compilersource-filename");
lf[243]=C_h_intern(&lf[243],28,"\003syssymbol->qualified-string");
lf[244]=C_h_intern(&lf[244],7,"\003sysget");
lf[245]=C_h_intern(&lf[245],34,"\010compileralways-bound-to-procedure");
lf[246]=C_h_intern(&lf[246],15,"\004coreinline_ref");
lf[247]=C_h_intern(&lf[247],18,"\004coreinline_update");
lf[248]=C_h_intern(&lf[248],19,"\004coreinline_loc_ref");
lf[249]=C_h_intern(&lf[249],22,"\004coreinline_loc_update");
lf[250]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[251]=C_h_intern(&lf[251],1,"o");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[253]=C_h_intern(&lf[253],30,"\010compilerbuild-expression-tree");
lf[254]=C_h_intern(&lf[254],12,"\004coreclosure");
lf[255]=C_h_intern(&lf[255],4,"last");
lf[256]=C_h_intern(&lf[256],3,"map");
lf[257]=C_h_intern(&lf[257],4,"list");
lf[258]=C_h_intern(&lf[258],7,"butlast");
lf[259]=C_h_intern(&lf[259],5,"cons*");
lf[260]=C_h_intern(&lf[260],9,"\004corebind");
lf[261]=C_h_intern(&lf[261],10,"\004coreunbox");
lf[262]=C_h_intern(&lf[262],8,"\004coreref");
lf[263]=C_h_intern(&lf[263],11,"\004coreupdate");
lf[264]=C_h_intern(&lf[264],13,"\004coreupdate_i");
lf[265]=C_h_intern(&lf[265],8,"\004corebox");
lf[266]=C_h_intern(&lf[266],9,"\004corecond");
lf[267]=C_h_intern(&lf[267],21,"\010compilerfold-boolean");
lf[268]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[269]=C_h_intern(&lf[269],31,"\010compilerinline-lambda-bindings");
lf[270]=C_h_intern(&lf[270],8,"split-at");
lf[271]=C_h_intern(&lf[271],10,"fold-right");
lf[272]=C_h_intern(&lf[272],4,"take");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[274]=C_h_intern(&lf[274],34,"\010compilercopy-node-tree-and-rename");
lf[275]=C_h_intern(&lf[275],9,"alist-ref");
lf[276]=C_h_intern(&lf[276],3,"eq\077");
lf[277]=C_h_intern(&lf[277],1,"f");
lf[278]=C_h_intern(&lf[278],18,"\010compilertree-copy");
lf[279]=C_h_intern(&lf[279],4,"cons");
lf[280]=C_h_intern(&lf[280],19,"\010compilercopy-node!");
lf[281]=C_h_intern(&lf[281],20,"\010compilernode->sexpr");
lf[282]=C_h_intern(&lf[282],20,"\010compilersexpr->node");
lf[283]=C_h_intern(&lf[283],32,"\010compileremit-global-inline-file");
lf[284]=C_h_intern(&lf[284],5,"print");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[286]=C_h_intern(&lf[286],1,"i");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\0001the following procedures can be globally inlined:");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\015; END OF FILE");
lf[289]=C_h_intern(&lf[289],2,"pp");
lf[290]=C_h_intern(&lf[290],3,"yes");
lf[291]=C_h_intern(&lf[291],2,"no");
lf[292]=C_h_intern(&lf[292],24,"\010compilerinline-max-size");
lf[293]=C_h_intern(&lf[293],15,"\010compilerinline");
lf[294]=C_h_intern(&lf[294],22,"\010compilerinline-global");
lf[295]=C_h_intern(&lf[295],26,"\010compilervariable-visible\077");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\027; GENERATED BY CHICKEN ");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\006 FROM ");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[299]=C_h_intern(&lf[299],15,"chicken-version");
lf[300]=C_h_intern(&lf[300],19,"with-output-to-file");
lf[301]=C_h_intern(&lf[301],25,"\010compilerload-inline-file");
lf[302]=C_h_intern(&lf[302],20,"with-input-from-file");
lf[303]=C_h_intern(&lf[303],19,"\010compilermatch-node");
lf[304]=C_h_intern(&lf[304],1,"a");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[306]=C_h_intern(&lf[306],37,"\010compilerexpression-has-side-effects\077");
lf[307]=C_h_intern(&lf[307],24,"foreign-callback-stub-id");
lf[308]=C_h_intern(&lf[308],4,"find");
lf[309]=C_h_intern(&lf[309],22,"foreign-callback-stubs");
lf[310]=C_h_intern(&lf[310],28,"\010compilersimple-lambda-node\077");
lf[311]=C_h_intern(&lf[311],31,"\010compilerdump-undefined-globals");
lf[312]=C_h_intern(&lf[312],29,"\010compilerdump-defined-globals");
lf[313]=C_h_intern(&lf[313],25,"\010compilerdump-global-refs");
lf[314]=C_h_intern(&lf[314],28,"\003systoplevel-definition-hook");
lf[315]=C_h_intern(&lf[315],22,"\010compilerhide-variable");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[317]=C_h_intern(&lf[317],36,"\010compilercompute-database-statistics");
lf[318]=C_h_intern(&lf[318],29,"\010compilercurrent-program-size");
lf[319]=C_h_intern(&lf[319],30,"\010compileroriginal-program-size");
lf[320]=C_h_intern(&lf[320],33,"\010compilerprint-program-statistics");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\032;   database entries: \011~s\012");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known call sites: \011~s\012");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\032;   global variables: \011~s\012");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\032;   known procedures: \011~s\012");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000%;   variables with known values: \011~s\012");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\0002;   program size: \011~s \011original program size: \011~s\012");
lf[327]=C_h_intern(&lf[327],1,"s");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[329]=C_h_intern(&lf[329],35,"\010compilerpprint-expressions-to-file");
lf[330]=C_h_intern(&lf[330],17,"close-output-port");
lf[331]=C_h_intern(&lf[331],12,"pretty-print");
lf[332]=C_h_intern(&lf[332],19,"with-output-to-port");
lf[333]=C_h_intern(&lf[333],16,"open-output-file");
lf[334]=C_h_intern(&lf[334],19,"current-output-port");
lf[335]=C_h_intern(&lf[335],27,"\010compilerforeign-type-check");
lf[336]=C_h_intern(&lf[336],4,"char");
lf[337]=C_h_intern(&lf[337],13,"unsigned-char");
lf[338]=C_h_intern(&lf[338],6,"unsafe");
lf[339]=C_h_intern(&lf[339],25,"\003sysforeign-char-argument");
lf[340]=C_h_intern(&lf[340],3,"int");
lf[341]=C_h_intern(&lf[341],27,"\003sysforeign-fixnum-argument");
lf[342]=C_h_intern(&lf[342],5,"float");
lf[343]=C_h_intern(&lf[343],27,"\003sysforeign-flonum-argument");
lf[344]=C_h_intern(&lf[344],7,"pointer");
lf[345]=C_h_intern(&lf[345],26,"\003sysforeign-block-argument");
lf[346]=C_h_intern(&lf[346],15,"nonnull-pointer");
lf[347]=C_h_intern(&lf[347],8,"u8vector");
lf[348]=C_h_intern(&lf[348],34,"\003sysforeign-number-vector-argument");
lf[349]=C_h_intern(&lf[349],16,"nonnull-u8vector");
lf[350]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[351]=C_h_intern(&lf[351],7,"integer");
lf[352]=C_h_intern(&lf[352],28,"\003sysforeign-integer-argument");
lf[353]=C_h_intern(&lf[353],16,"unsigned-integer");
lf[354]=C_h_intern(&lf[354],37,"\003sysforeign-unsigned-integer-argument");
lf[355]=C_h_intern(&lf[355],9,"c-pointer");
lf[356]=C_h_intern(&lf[356],28,"\003sysforeign-pointer-argument");
lf[357]=C_h_intern(&lf[357],17,"nonnull-c-pointer");
lf[358]=C_h_intern(&lf[358],8,"c-string");
lf[359]=C_h_intern(&lf[359],17,"\003sysmake-c-string");
lf[360]=C_h_intern(&lf[360],27,"\003sysforeign-string-argument");
lf[361]=C_h_intern(&lf[361],16,"nonnull-c-string");
lf[362]=C_h_intern(&lf[362],6,"symbol");
lf[363]=C_h_intern(&lf[363],18,"\003syssymbol->string");
lf[364]=C_h_intern(&lf[364],3,"ref");
lf[365]=C_h_intern(&lf[365],8,"instance");
lf[366]=C_h_intern(&lf[366],12,"instance-ref");
lf[367]=C_h_intern(&lf[367],4,"this");
lf[368]=C_h_intern(&lf[368],8,"slot-ref");
lf[369]=C_h_intern(&lf[369],16,"nonnull-instance");
lf[370]=C_h_intern(&lf[370],5,"const");
lf[371]=C_h_intern(&lf[371],4,"enum");
lf[372]=C_h_intern(&lf[372],8,"function");
lf[373]=C_h_intern(&lf[373],27,"\010compilerforeign-type-table");
lf[374]=C_h_intern(&lf[374],17,"nonnull-c-string*");
lf[375]=C_h_intern(&lf[375],26,"nonnull-unsigned-c-string*");
lf[376]=C_h_intern(&lf[376],9,"c-string*");
lf[377]=C_h_intern(&lf[377],17,"unsigned-c-string");
lf[378]=C_h_intern(&lf[378],18,"unsigned-c-string*");
lf[379]=C_h_intern(&lf[379],13,"c-string-list");
lf[380]=C_h_intern(&lf[380],14,"c-string-list*");
lf[381]=C_h_intern(&lf[381],18,"unsigned-integer32");
lf[382]=C_h_intern(&lf[382],13,"unsigned-long");
lf[383]=C_h_intern(&lf[383],4,"long");
lf[384]=C_h_intern(&lf[384],9,"integer32");
lf[385]=C_h_intern(&lf[385],17,"nonnull-u16vector");
lf[386]=C_h_intern(&lf[386],16,"nonnull-s8vector");
lf[387]=C_h_intern(&lf[387],17,"nonnull-s16vector");
lf[388]=C_h_intern(&lf[388],17,"nonnull-u32vector");
lf[389]=C_h_intern(&lf[389],17,"nonnull-s32vector");
lf[390]=C_h_intern(&lf[390],17,"nonnull-f32vector");
lf[391]=C_h_intern(&lf[391],17,"nonnull-f64vector");
lf[392]=C_h_intern(&lf[392],9,"u16vector");
lf[393]=C_h_intern(&lf[393],8,"s8vector");
lf[394]=C_h_intern(&lf[394],9,"s16vector");
lf[395]=C_h_intern(&lf[395],9,"u32vector");
lf[396]=C_h_intern(&lf[396],9,"s32vector");
lf[397]=C_h_intern(&lf[397],9,"f32vector");
lf[398]=C_h_intern(&lf[398],9,"f64vector");
lf[399]=C_h_intern(&lf[399],22,"nonnull-scheme-pointer");
lf[400]=C_h_intern(&lf[400],12,"nonnull-blob");
lf[401]=C_h_intern(&lf[401],19,"nonnull-byte-vector");
lf[402]=C_h_intern(&lf[402],11,"byte-vector");
lf[403]=C_h_intern(&lf[403],4,"blob");
lf[404]=C_h_intern(&lf[404],14,"scheme-pointer");
lf[405]=C_h_intern(&lf[405],6,"double");
lf[406]=C_h_intern(&lf[406],6,"number");
lf[407]=C_h_intern(&lf[407],12,"unsigned-int");
lf[408]=C_h_intern(&lf[408],5,"short");
lf[409]=C_h_intern(&lf[409],14,"unsigned-short");
lf[410]=C_h_intern(&lf[410],4,"byte");
lf[411]=C_h_intern(&lf[411],13,"unsigned-byte");
lf[412]=C_h_intern(&lf[412],5,"int32");
lf[413]=C_h_intern(&lf[413],14,"unsigned-int32");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[415]=C_h_intern(&lf[415],36,"\010compilerforeign-type-convert-result");
lf[416]=C_h_intern(&lf[416],38,"\010compilerforeign-type-convert-argument");
lf[417]=C_h_intern(&lf[417],27,"\010compilerfinal-foreign-type");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[419]=C_h_intern(&lf[419],37,"\010compilerestimate-foreign-result-size");
lf[420]=C_h_intern(&lf[420],9,"integer64");
lf[421]=C_h_intern(&lf[421],4,"bool");
lf[422]=C_h_intern(&lf[422],4,"void");
lf[423]=C_h_intern(&lf[423],13,"scheme-object");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[425]=C_h_intern(&lf[425],46,"\010compilerestimate-foreign-result-location-size");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\0005cannot compute size of location for foreign type `~S\047");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[428]=C_h_intern(&lf[428],30,"\010compilerfinish-foreign-result");
lf[429]=C_h_intern(&lf[429],17,"\003syspeek-c-string");
lf[430]=C_h_intern(&lf[430],25,"\003syspeek-nonnull-c-string");
lf[431]=C_h_intern(&lf[431],26,"\003syspeek-and-free-c-string");
lf[432]=C_h_intern(&lf[432],34,"\003syspeek-and-free-nonnull-c-string");
lf[433]=C_h_intern(&lf[433],17,"\003sysintern-symbol");
lf[434]=C_h_intern(&lf[434],22,"\003syspeek-c-string-list");
lf[435]=C_h_intern(&lf[435],31,"\003syspeek-and-free-c-string-list");
lf[436]=C_h_intern(&lf[436],35,"\010tinyclosmake-instance-from-pointer");
lf[437]=C_h_intern(&lf[437],4,"make");
lf[438]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\014instance-ref\376\377\016");
lf[439]=C_h_intern(&lf[439],28,"\010compilerscan-used-variables");
lf[440]=C_h_intern(&lf[440],28,"\010compilerscan-free-variables");
lf[441]=C_h_intern(&lf[441],11,"lset-adjoin");
lf[442]=C_h_intern(&lf[442],23,"\010compilerchop-separator");
lf[443]=C_h_intern(&lf[443],9,"substring");
lf[444]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[445]=C_h_intern(&lf[445],23,"\010compilerchop-extension");
lf[446]=C_h_intern(&lf[446],22,"\010compilerprint-version");
lf[447]=C_h_intern(&lf[447],6,"print*");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\077(c)2008-2009 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[449]=C_h_intern(&lf[449],20,"\010compilerprint-usage");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\030LUsage: chicken FILENAME OPTION ...\012\012  `chicken\047 is the CHICKEN compiler.\012  "
"\012  FILENAME should be a complete source file name with extension, or \042-\042 for\012  s"
"tandard input. OPTION may be one of the following:\012\012  General options:\012\012    -hel"
"p                        display this text and exit\012    -version                "
"     display compiler version and exit\012    -release                     print re"
"lease number and exit\012    -verbose                     display information on co"
"mpilation progress\012\012  File and pathname options:\012\012    -output-file FILENAME     "
"   specifies output-filename, default is \047out.c\047\012    -include-path PATHNAME     "
"  specifies alternative path for included files\012    -to-stdout                  "
" write compiled file to stdout instead of file\012\012  Language options:\012\012    -featur"
"e SYMBOL              register feature identifier\012\012  Syntax related options:\012\012  "
"  -case-insensitive            don\047t preserve case of read symbols\012    -keyword-"
"style STYLE         allow alternative keyword syntax\012                           "
"       (prefix, suffix or none)\012    -no-parentheses-synonyms     disables list d"
"elimiter synonyms\012    -no-symbol-escape            disables support for escaped "
"symbols\012    -r5rs-syntax                 disables the Chicken extensions to\012    "
"                              R5RS syntax\012    -compile-syntax              macro"
"s are made available at run-time\012    -emit-import-library MODULE  write compile-"
"time module information into\012                                  separate file\012   "
" -emit-all-import-libraries   emit import-libraries for all defined modules\012    "
"-no-compiler-syntax          disable expansion of compiler-macros\012\012  Translation"
" options:\012\012    -explicit-use                do not use units \047library\047 and \047eval"
"\047 by\012                                  default\012    -check-syntax                "
"stop compilation after macro-expansion\012    -analyze-only                stop com"
"pilation after first analysis pass\012\012  Debugging options:\012\012    -no-warnings      "
"           disable warnings\012    -disable-warning CLASS       disable specific cl"
"ass of warnings\012    -debug-level NUMBER          set level of available debuggin"
"g information\012    -no-trace                    disable tracing information\012    -"
"profile                     executable emits profiling information \012    -profile"
"-name FILENAME       name of the generated profile information file\012    -accumul"
"ate-profile          executable emits profiling information in\012                 "
"                 append mode\012    -no-lambda-info              omit additional pr"
"ocedure-information\012    -scrutinize                  perform local flow analysis"
"\012    -types FILENAME              load additional type database\012\012  Optimization "
"options:\012\012    -optimize-level NUMBER       enable certain sets of optimization o"
"ptions\012    -optimize-leaf-routines      enable leaf routine optimization\012    -la"
"mbda-lift                 enable lambda-lifting\012    -no-usual-integrations      "
" standard procedures may be redefined\012    -unsafe                      disable a"
"ll safety checks\012    -local                       assume globals are only modifi"
"ed in current\012                                  file\012    -block                 "
"      enable block-compilation\012    -disable-interrupts          disable interrup"
"ts in compiled code\012    -fixnum-arithmetic           assume all numbers are fixn"
"ums\012    -benchmark-mode              equivalent to \047block -optimize-level 4\012    "
"                              -debug-level 0 -fixnum-arithmetic -lambda-lift\012   "
"                               -inline -disable-interrupts\047\012    -disable-stack-o"
"verflow-checks  disables detection of stack-overflows\012    -inline               "
"       enable inlining\012    -inline-limit                set inlining threshold\012 "
"   -inline-global               enable cross-module inlining\012    -emit-inline-fi"
"le FILENAME   generate file with globally inlinable\012                            "
"      procedures (implies -inline -local)\012    -consult-inline-file FILENAME  exp"
"licitly load inline file\012    -no-argc-checks              disable argument count"
" checks\012    -no-bound-checks             disable bound variable checks\012    -no-p"
"rocedure-checks         disable procedure call checks\012    -no-procedure-checks-f"
"or-usual-bindings\012                                 disable procedure call checks"
" only for usual\012                                  bindings\012\012  Configuration opti"
"ons:\012\012    -unit NAME                   compile file as a library unit\012    -uses "
"NAME                   declare library unit as used.\012    -heap-size NUMBER      "
"      specifies heap-size of compiled executable\012    -heap-initial-size NUMBER  "
"  specifies heap-size at startup time\012    -heap-growth PERCENTAGE      specifies"
" growth-rate of expanding heap\012    -heap-shrinkage PERCENTAGE   specifies shrink"
"-rate of contracting heap\012    -nursery NUMBER  -stack-size NUMBER\012              "
"                   specifies nursery size of compiled executable\012    -extend FIL"
"ENAME             load file before compilation commences\012    -prelude EXPRESSION"
"          add expression to front of source file\012    -postlude EXPRESSION       "
"  add expression to end of source file\012    -prologue FILENAME           include "
"file before main source file\012    -epilogue FILENAME           include file after"
" main source file\012    -dynamic                     compile as dynamically loadab"
"le code\012    -require-extension NAME      require and import extension NAME\012    -"
"static-extension NAME       import extension NAME but link statically\012          "
"                        (if available)\012\012  Obscure options:\012\012    -debug MODES    "
"             display debugging output for the given modes\012    -unsafe-libraries "
"           marks the generated file as being linked with\012                       "
"           the unsafe runtime system\012    -raw                         do not gen"
"erate implicit init- and exit code                           \012    -emit-external"
"-prototypes-first\012                                 emit prototypes for callbacks"
" before foreign\012                                  declarations\012    -ignore-repos"
"itory           do not refer to repository for extensions\012    -setup-mode       "
"           prefer the current directory when locating extensions\012");
lf[451]=C_h_intern(&lf[451],36,"\010compilermake-block-variable-literal");
lf[452]=C_h_intern(&lf[452],22,"block-variable-literal");
lf[453]=C_h_intern(&lf[453],32,"\010compilerblock-variable-literal\077");
lf[454]=C_h_intern(&lf[454],36,"\010compilerblock-variable-literal-name");
lf[455]=C_h_intern(&lf[455],25,"\010compilermake-random-name");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\007~A-~A~A");
lf[457]=C_h_intern(&lf[457],6,"random");
lf[458]=C_h_intern(&lf[458],15,"current-seconds");
lf[459]=C_h_intern(&lf[459],23,"\010compilerset-real-name!");
lf[460]=C_h_intern(&lf[460],24,"\010compilerreal-name-table");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\010~A in ~A");
lf[462]=C_h_intern(&lf[462],19,"\010compilerreal-name2");
lf[463]=C_h_intern(&lf[463],32,"\010compilerdisplay-real-name-table");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\007~S\011~S~%");
lf[465]=C_h_intern(&lf[465],28,"\010compilersource-info->string");
lf[466]=C_h_intern(&lf[466],4,"conc");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[469]=C_h_intern(&lf[469],11,"make-string");
lf[470]=C_h_intern(&lf[470],3,"max");
lf[471]=C_h_intern(&lf[471],26,"\010compilersource-info->line");
lf[472]=C_h_intern(&lf[472],12,"string-null\077");
lf[473]=C_h_intern(&lf[473],19,"\010compilerdump-nodes");
lf[474]=C_h_intern(&lf[474],19,"\003syswrite-char/port");
lf[475]=C_h_intern(&lf[475],19,"\003sysstandard-output");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\003 ~S");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\003[~S");
lf[478]=C_decode_literal(C_heaptop,"\376B\000\000\012~%~A<~A ~S");
lf[479]=C_h_intern(&lf[479],18,"\003sysuser-read-hook");
lf[480]=C_h_intern(&lf[480],15,"foreign-declare");
lf[481]=C_h_intern(&lf[481],7,"declare");
lf[482]=C_h_intern(&lf[482],34,"\010compilerscan-sharp-greater-string");
lf[483]=C_h_intern(&lf[483],18,"\003sysread-char/port");
lf[484]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[485]=C_h_intern(&lf[485],17,"get-output-string");
lf[486]=C_h_intern(&lf[486],18,"open-output-string");
lf[487]=C_h_intern(&lf[487],6,"hidden");
lf[488]=C_h_intern(&lf[488],19,"\010compilervisibility");
lf[489]=C_h_intern(&lf[489],24,"\010compilerexport-variable");
lf[490]=C_h_intern(&lf[490],8,"exported");
lf[491]=C_h_intern(&lf[491],26,"\010compilerblock-compilation");
lf[492]=C_h_intern(&lf[492],22,"\010compilermark-variable");
lf[493]=C_h_intern(&lf[493],22,"\010compilervariable-mark");
lf[494]=C_h_intern(&lf[494],19,"\010compilerintrinsic\077");
lf[495]=C_h_intern(&lf[495],9,"foldable\077");
lf[496]=C_h_intern(&lf[496],33,"\010compilerload-identifier-database");
lf[497]=C_h_intern(&lf[497],7,"\004coredb");
lf[498]=C_h_intern(&lf[498],9,"read-file");
lf[499]=C_h_intern(&lf[499],21,"\010compilerverbose-mode");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000$loading identifier database ~a ...~%");
lf[501]=C_h_intern(&lf[501],13,"make-pathname");
lf[502]=C_h_intern(&lf[502],15,"repository-path");
lf[503]=C_h_intern(&lf[503],27,"condition-property-accessor");
lf[504]=C_h_intern(&lf[504],3,"exn");
lf[505]=C_h_intern(&lf[505],7,"message");
lf[506]=C_h_intern(&lf[506],19,"condition-predicate");
C_register_lf2(lf,507,create_ptable());
t2=C_mutate(&lf[0] /* (set! c664 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3959,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3957 */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3962,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3960 in k3957 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3965,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3963 in k3960 in k3957 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3968,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_3968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3974,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3974,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3978,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[3] /* debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[4] /* disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[5]+1 /* (set! bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3983,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4010,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[20]+1 /* (set! compiler-warning ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4050,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[25]+1 /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4079,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[28]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4098,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[35]+1 /* (set! syntax-error ...) */,C_retrieve(lf[28]));
t11=C_mutate((C_word*)lf[36]+1 /* (set! emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4143,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[37]+1 /* (set! map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4146,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[38]+1 /* (set! check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4189,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[41]+1 /* (set! posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4257,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[42]+1 /* (set! stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4293,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[46]+1 /* (set! symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4314,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[49]+1 /* (set! build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4339,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[50]+1 /* (set! string->c-identifier ...) */,C_retrieve(lf[51]));
t19=C_mutate((C_word*)lf[52]+1 /* (set! c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4383,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[61]+1 /* (set! valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4477,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[64]+1 /* (set! words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4533,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[65]+1 /* (set! words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4540,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[66]+1 /* (set! check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4547,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[73]+1 /* (set! close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4594,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[76]+1 /* (set! fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4606,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[78]+1 /* (set! follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4669,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[79]+1 /* (set! sort-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4700,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[82]+1 /* (set! constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4720,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[84]+1 /* (set! collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4766,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[85]+1 /* (set! immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4796,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[87]+1 /* (set! basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4842,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[90]+1 /* (set! canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4902,tmp=(C_word)a,a+=2,tmp));
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4999,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 251  condition-predicate */
((C_proc3)C_retrieve_symbol_proc(lf[506]))(3,*((C_word*)lf[506]+1),t33,lf[504]);}

/* k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5002,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 252  condition-property-accessor */
((C_proc4)C_retrieve_symbol_proc(lf[503]))(4,*((C_word*)lf[503]+1),t2,lf[504],lf[505]);}

/* k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word ab[175],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5002,2,t0,t1);}
t2=C_mutate((C_word*)lf[97]+1 /* (set! string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5003,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[109]+1 /* (set! decompose-lambda-list ...) */,C_retrieve(lf[110]));
t4=C_mutate((C_word*)lf[111]+1 /* (set! process-lambda-documentation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5110,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[112]+1 /* (set! llist-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5113,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[113]+1 /* (set! expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5116,tmp=(C_word)a,a+=2,tmp));
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_mutate((C_word*)lf[123]+1 /* (set! initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5257,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[135]+1 /* (set! get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5444,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[137]+1 /* (set! get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5462,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[139]+1 /* (set! put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5480,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[141]+1 /* (set! collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5526,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[142]+1 /* (set! count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5578,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[143]+1 /* (set! get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5635,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[145]+1 /* (set! get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5645,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[146]+1 /* (set! find-lambda-container ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5681,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[148]+1 /* (set! display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5705,tmp=(C_word)a,a+=2,tmp));
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_mutate((C_word*)lf[153]+1 /* (set! display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5724,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[204]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6172,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[206]+1 /* (set! node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6178,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[207]+1 /* (set! node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6184,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[209]+1 /* (set! node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6193,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[210]+1 /* (set! node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6202,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[211]+1 /* (set! node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6211,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[212]+1 /* (set! node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6220,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[213]+1 /* (set! node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6229,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[204]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6238,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[214]+1 /* (set! varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6244,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[216]+1 /* (set! qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6253,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[217]+1 /* (set! build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6262,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[253]+1 /* (set! build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6776,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[267]+1 /* (set! fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7094,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[269]+1 /* (set! inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7142,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[274]+1 /* (set! copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7235,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[278]+1 /* (set! tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7413,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[280]+1 /* (set! copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7447,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[281]+1 /* (set! node->sexpr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7471,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[282]+1 /* (set! sexpr->node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7507,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[283]+1 /* (set! emit-global-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7532,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[301]+1 /* (set! load-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7712,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[303]+1 /* (set! match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7781,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[306]+1 /* (set! expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7976,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[310]+1 /* (set! simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8062,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[311]+1 /* (set! dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8154,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[312]+1 /* (set! dump-defined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8185,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[313]+1 /* (set! dump-global-refs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8212,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[314]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8251,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[317]+1 /* (set! compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8272,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[320]+1 /* (set! print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8352,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[329]+1 /* (set! pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8391,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[335]+1 /* (set! foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8427,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[415]+1 /* (set! foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9480,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[416]+1 /* (set! foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9511,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[417]+1 /* (set! final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9542,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[419]+1 /* (set! estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9582,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[425]+1 /* (set! estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9907,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[428]+1 /* (set! finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10223,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[439]+1 /* (set! scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10521,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[440]+1 /* (set! scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10599,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[442]+1 /* (set! chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10771,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[445]+1 /* (set! chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10800,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[446]+1 /* (set! print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10842,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[449]+1 /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10880,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[451]+1 /* (set! make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10892,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[453]+1 /* (set! block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10898,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[454]+1 /* (set! block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10904,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[455]+1 /* (set! make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10913,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[459]+1 /* (set! set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10957,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[40]+1 /* (set! real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10963,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[462]+1 /* (set! real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11042,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[463]+1 /* (set! display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11054,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[465]+1 /* (set! source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11066,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[471]+1 /* (set! source-info->line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11112,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[472]+1 /* (set! string-null? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11130,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[473]+1 /* (set! dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11136,tmp=(C_word)a,a+=2,tmp));
t79=C_retrieve(lf[479]);
t80=C_mutate((C_word*)lf[479]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11223,a[2]=t79,tmp=(C_word)a,a+=3,tmp));
t81=C_mutate((C_word*)lf[482]+1 /* (set! scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11256,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[86]+1 /* (set! big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11325,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[315]+1 /* (set! hide-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11349,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[489]+1 /* (set! export-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11382,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[295]+1 /* (set! variable-visible? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11415,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[492]+1 /* (set! mark-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11436,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[493]+1 /* (set! variable-mark ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11464,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[494]+1 /* (set! intrinsic? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11470,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[495]+1 /* (set! foldable? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11481,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[496]+1 /* (set! load-identifier-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11492,tmp=(C_word)a,a+=2,tmp));
t91=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t91+1)))(2,t91,C_SCHEME_UNDEFINED);}

/* ##compiler#load-identifier-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11492(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11492,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11496,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1452 repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[502]))(2,*((C_word*)lf[502]+1),t3);}

/* k11494 in ##compiler#load-identifier-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11496,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11502,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11555,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1453 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[501]))(4,*((C_word*)lf[501]+1),t3,t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11553 in k11494 in ##compiler#load-identifier-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1453 file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),((C_word*)t0)[2],t1);}

/* k11500 in k11494 in ##compiler#load-identifier-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11502,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11508,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[499]))){
/* support.scm: 1455 printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[500],t1);}
else{
t3=t2;
f_11508(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11506 in k11500 in k11494 in ##compiler#load-identifier-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11513,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11548,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1461 read-file */
((C_proc3)C_retrieve_symbol_proc(lf[498]))(3,*((C_word*)lf[498]+1),t3,((C_word*)t0)[2]);}

/* k11546 in k11506 in k11500 in k11494 in ##compiler#load-identifier-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11512 in k11506 in k11500 in k11494 in ##compiler#load-identifier-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11513,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11525,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11529,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_car(t2);
/* support.scm: 1460 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t5,t6,lf[497]);}

/* k11527 in a11512 in k11506 in k11500 in k11494 in ##compiler#load-identifier-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11529,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* support.scm: 1460 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),((C_word*)t0)[2],t2,t4);}

/* k11523 in a11512 in k11506 in k11500 in k11494 in ##compiler#load-identifier-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1458 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[497],t1);}

/* foldable? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11481,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11486,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[130]);}

/* f_11486 in foldable? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11486,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t1,t2,t3);}

/* ##compiler#intrinsic? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11470(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11470,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11475,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[126]);}

/* f_11475 in ##compiler#intrinsic? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11475,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t1,t2,t3);}

/* ##compiler#variable-mark in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11464,4,t0,t1,t2,t3);}
/* support.scm: 1443 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t1,t2,t3);}

/* ##compiler#mark-variable in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11436r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11436r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11436r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11440,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11440(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11440(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11438 in ##compiler#mark-variable in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1440 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#variable-visible? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11415,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11419,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1433 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t3,t2,lf[488]);}

/* k11417 in ##compiler#variable-visible? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[487]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(t1,lf[490]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_i_not(C_retrieve(lf[491]))));}}

/* ##compiler#export-variable in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11382(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11382,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[490]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11388,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_11388(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_11388(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k11386 in ##compiler#export-variable in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[488],t1);}

/* ##compiler#hide-variable in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11349(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11349,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[487]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11355,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_11355(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_11355(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k11353 in ##compiler#hide-variable in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[488],t1);}

/* ##compiler#big-fixnum? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11325(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11325,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
if(C_truep((C_word)C_fudge(C_fix(3)))){
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#scan-sharp-greater-string in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11256(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11256,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11260,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1395 open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[486]))(2,*((C_word*)lf[486]+1),t3);}

/* k11258 in ##compiler#scan-sharp-greater-string in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11260,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11265,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11265(t5,((C_word*)t0)[2]);}

/* loop in k11258 in ##compiler#scan-sharp-greater-string in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_11265(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11265,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11269,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=C_retrieve(lf[483]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k11267 in loop in k11258 in ##compiler#scan-sharp-greater-string in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11269,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* support.scm: 1398 quit */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[5],lf[484]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11287,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1400 newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11299,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=C_retrieve(lf[483]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11320,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[474]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k11318 in k11267 in loop in k11258 in ##compiler#scan-sharp-greater-string in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1412 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11265(t2,((C_word*)t0)[2]);}

/* k11297 in k11267 in loop in k11258 in ##compiler#scan-sharp-greater-string in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11299,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
/* support.scm: 1405 get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[485]))(3,*((C_word*)lf[485]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11311,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t4=C_retrieve(lf[474]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k11309 in k11297 in k11267 in loop in k11258 in ##compiler#scan-sharp-greater-string in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11314,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[474]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11312 in k11309 in k11297 in k11267 in loop in k11258 in ##compiler#scan-sharp-greater-string in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1409 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11265(t2,((C_word*)t0)[2]);}

/* k11285 in k11267 in loop in k11258 in ##compiler#scan-sharp-greater-string in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1401 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11265(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11223,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11233,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t6=C_retrieve(lf[483]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* support.scm: 1392 old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k11231 in ##sys#user-read-hook in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11236,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1390 scan-sharp-greater-string */
((C_proc3)C_retrieve_symbol_proc(lf[482]))(3,*((C_word*)lf[482]+1),t2,((C_word*)t0)[2]);}

/* k11234 in k11231 in ##sys#user-read-hook in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11236,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[480],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[481],t4));}

/* ##compiler#dump-nodes in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11136,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11140,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11145,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_11145(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_11145(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11145,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11158,a[2]=t7,a[3]=t5,a[4]=t9,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1368 make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[469]+1)))(4,*((C_word*)lf[469]+1),t10,t2,C_make_character(32));}

/* k11156 in loop in ##compiler#dump-nodes in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11158,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11164,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1370 printf */
((C_proc6)C_retrieve_symbol_proc(lf[13]))(6,*((C_word*)lf[13]+1),t3,lf[478],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11162 in k11156 in loop in ##compiler#dump-nodes in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11167,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11217,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11216 in k11162 in k11156 in loop in ##compiler#dump-nodes in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11217,3,t0,t1,t2);}
/* loop3587 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11145(t3,t1,((C_word*)t0)[2],t2);}

/* k11165 in k11162 in k11156 in loop in ##compiler#dump-nodes in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11167,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11173,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(4)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11182,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* support.scm: 1374 printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t4,lf[477],t5);}
else{
t4=t3;
f_11173(2,t4,C_SCHEME_UNDEFINED);}}

/* k11180 in k11165 in k11162 in k11156 in loop in ##compiler#dump-nodes in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11185,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11190,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_11190(t6,t2,C_fix(5));}

/* doloop3620 in k11180 in k11165 in k11162 in k11156 in loop in ##compiler#dump-nodes in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_11190(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11190,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11200,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
/* support.scm: 1377 printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t3,lf[476],t4);}}

/* k11198 in doloop3620 in k11180 in k11165 in k11162 in k11156 in loop in ##compiler#dump-nodes in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11190(t3,((C_word*)t0)[2],t2);}

/* k11183 in k11180 in k11165 in k11162 in k11156 in loop in ##compiler#dump-nodes in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[474]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[475]+1));}

/* k11171 in k11165 in k11162 in k11156 in loop in ##compiler#dump-nodes in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[474]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[475]+1));}

/* k11138 in ##compiler#dump-nodes in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1380 newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* string-null? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11130,3,t0,t1,t2);}
/* support.scm: 1358 string-null? */
((C_proc3)C_retrieve_symbol_proc(lf[472]))(3,*((C_word*)lf[472]+1),t1,t2);}

/* ##compiler#source-info->line in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11112,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}
else{
if(C_truep(t2)){
/* support.scm: 1353 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[63]))(3,*((C_word*)lf[63]+1),t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* ##compiler#source-info->string in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11066(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11066,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_caddr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11085,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1346 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[63]))(3,*((C_word*)lf[63]+1),t6,t4);}
else{
if(C_truep(t2)){
/* support.scm: 1348 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[63]))(3,*((C_word*)lf[63]+1),t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k11083 in ##compiler#source-info->string in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11092,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11096,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_string_length(t1);
t5=(C_word)C_fixnum_difference(C_fix(4),t4);
/* support.scm: 1347 max */
((C_proc4)C_retrieve_proc(*((C_word*)lf[470]+1)))(4,*((C_word*)lf[470]+1),t3,C_fix(0),t5);}

/* k11094 in k11083 in ##compiler#source-info->string in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1347 make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[469]+1)))(4,*((C_word*)lf[469]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k11090 in k11083 in ##compiler#source-info->string in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1347 conc */
((C_proc8)C_retrieve_symbol_proc(lf[466]))(8,*((C_word*)lf[466]+1),((C_word*)t0)[5],((C_word*)t0)[4],lf[467],((C_word*)t0)[3],t1,lf[468],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11060,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1336 ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t1,t2,C_retrieve(lf[460]));}

/* a11059 in ##compiler#display-real-name-table in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11060,4,t0,t1,t2,t3);}
/* support.scm: 1338 printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),t1,lf[464],t2,t3);}

/* ##compiler#real-name2 in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11042,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11046,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1332 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t4,C_retrieve(lf[460]),t2);}

/* k11044 in ##compiler#real-name2 in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1333 real-name */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10963(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_10963r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_10963r(t0,t1,t2,t3);}}

static void C_ccall f_10963r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10966,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10982,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1316 resolve */
f_10966(t5,t2);}

/* k10980 in ##compiler#real-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10982,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[5]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1320 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),t4,t1);}
else{
/* support.scm: 1329 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),((C_word*)t0)[3],t1);}}
else{
/* support.scm: 1317 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11005 in k10980 in ##compiler#real-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11011,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1321 get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[147]);}

/* k11009 in k11005 in k10980 in ##compiler#real-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11011,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11013,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11013(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k11009 in k11005 in k10980 in ##compiler#real-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_11013(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11013,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1323 resolve */
f_10966(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k11018 in loop in k11009 in k11005 in k10980 in ##compiler#real-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11020,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11033,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1326 sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),t3,lf[461],((C_word*)t0)[4],t1);}}

/* k11031 in k11018 in loop in k11009 in k11005 in k10980 in ##compiler#real-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11037,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1327 get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[147]);}

/* k11035 in k11031 in k11018 in loop in k11009 in k11005 in k10980 in ##compiler#real-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_11037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1326 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11013(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_10966(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10966,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10970,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1311 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t3,C_retrieve(lf[460]),t2);}

/* k10968 in resolve in ##compiler#real-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10970,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10976,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1313 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t2,C_retrieve(lf[460]),t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k10974 in k10968 in resolve in ##compiler#real-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10957,4,t0,t1,t2,t3);}
/* support.scm: 1307 ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[140]))(5,*((C_word*)lf[140]+1),t1,C_retrieve(lf[460]),t2,t3);}

/* ##compiler#make-random-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10913(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_10913r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_10913r(t0,t1,t2);}}

static void C_ccall f_10913r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10921,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10925,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 1294 gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t4);}
else{
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_10925(2,t6,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t6=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t2);}}}

/* k10923 in ##compiler#make-random-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10929,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1295 current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[458]))(2,*((C_word*)lf[458]+1),t2);}

/* k10927 in k10923 in ##compiler#make-random-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10933,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1296 random */
((C_proc3)C_retrieve_symbol_proc(lf[457]))(3,*((C_word*)lf[457]+1),t2,C_fix(1000));}

/* k10931 in k10927 in k10923 in ##compiler#make-random-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1293 sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[44]))(6,*((C_word*)lf[44]+1),((C_word*)t0)[4],lf[456],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10919 in ##compiler#make-random-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1292 string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10904(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10904,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[452]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* ##compiler#block-variable-literal? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10898(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10898,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[452]));}

/* ##compiler#make-block-variable-literal in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10892(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10892,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[452],t2));}

/* ##compiler#print-usage in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10884,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1153 print-version */
((C_proc2)C_retrieve_symbol_proc(lf[446]))(2,*((C_word*)lf[446]+1),t2);}

/* k10882 in ##compiler#print-usage in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10887,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1154 newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),t2);}

/* k10885 in k10882 in ##compiler#print-usage in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1155 display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),((C_word*)t0)[2],lf[450]);}

/* ##compiler#print-version in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10842(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_10842r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_10842r(t0,t1,t2);}}

static void C_ccall f_10842r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10846,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_10846(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_10846(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k10844 in ##compiler#print-version in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10849,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* support.scm: 1149 print* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[447]+1)))(3,*((C_word*)lf[447]+1),t2,lf[448]);}
else{
t3=t2;
f_10849(2,t3,C_SCHEME_UNDEFINED);}}

/* k10847 in k10844 in ##compiler#print-version in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10856,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1150 chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[299]))(3,*((C_word*)lf[299]+1),t2,C_SCHEME_TRUE);}

/* k10854 in k10847 in k10844 in ##compiler#print-version in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1150 print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[284]+1)))(3,*((C_word*)lf[284]+1),((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10800,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10809,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10809(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_10809(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10809,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
/* support.scm: 1142 substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[443]+1)))(5,*((C_word*)lf[443]+1),t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=(C_word)C_fixnum_decrease(t2);
/* support.scm: 1143 loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#chop-separator in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10771(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10771,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10781,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t6=(C_word)C_i_string_ref(t2,t4);
t7=t5;
f_10781(t7,(C_word)C_i_memq(t6,lf[444]));}
else{
t6=t5;
f_10781(t6,C_SCHEME_FALSE);}}

/* k10779 in ##compiler#chop-separator in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_10781(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1135 substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[443]+1)))(5,*((C_word*)lf[443]+1),((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#scan-free-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10599(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10599,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10602,a[2]=t10,a[3]=t8,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10753,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10766,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1125 walk */
t14=((C_word*)t8)[1];
f_10602(t14,t13,t2,C_SCHEME_END_OF_LIST);}

/* k10764 in ##compiler#scan-free-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1126 values */
C_values(4,0,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_10753(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10753,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10759,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a10758 in walkeach in ##compiler#scan-free-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10759,3,t0,t1,t2);}
/* support.scm: 1123 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10602(t3,t1,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#scan-free-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_10602(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10602,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[83]);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t7,a[9]=t9,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t10)){
t12=t11;
f_10621(t12,t10);}
else{
t12=(C_word)C_eqp(t9,lf[221]);
if(C_truep(t12)){
t13=t11;
f_10621(t13,t12);}
else{
t13=(C_word)C_eqp(t9,lf[229]);
if(C_truep(t13)){
t14=t11;
f_10621(t14,t13);}
else{
t14=(C_word)C_eqp(t9,lf[232]);
t15=t11;
f_10621(t15,(C_truep(t14)?t14:(C_word)C_eqp(t9,lf[246])));}}}}

/* k10619 in walk in ##compiler#scan-free-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_10621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10621,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[215]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[7]))){
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10640,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1105 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[441]))(5,*((C_word*)lf[441]+1),t4,*((C_word*)lf[276]+1),((C_word*)((C_word*)t0)[6])[1],t3);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[233]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10662,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[7]))){
t6=t5;
f_10662(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10676,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1110 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[441]))(5,*((C_word*)lf[441]+1),t6,*((C_word*)lf[276]+1),((C_word*)((C_word*)t0)[6])[1],t4);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[93]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10685,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* support.scm: 1113 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_10602(t7,t5,t6,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[228]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10715,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1116 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[10],t6,t7);}
else{
/* support.scm: 1120 walkeach */
t6=((C_word*)((C_word*)t0)[2])[1];
f_10753(t6,((C_word*)t0)[10],((C_word*)t0)[4],((C_word*)t0)[7]);}}}}}}

/* a10714 in k10619 in walk in ##compiler#scan-free-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10715,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10727,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1119 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),t6,t2,((C_word*)t0)[2]);}

/* k10725 in a10714 in k10619 in walk in ##compiler#scan-free-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1119 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10602(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10683 in k10619 in walk in ##compiler#scan-free-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10685,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10696,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1114 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10694 in k10683 in k10619 in walk in ##compiler#scan-free-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1114 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10602(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10674 in k10619 in walk in ##compiler#scan-free-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_10662(t3,t2);}

/* k10660 in k10619 in walk in ##compiler#scan-free-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_10662(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 1111 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10602(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k10638 in k10619 in walk in ##compiler#scan-free-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10640,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1106 variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[295]))(3,*((C_word*)lf[295]+1),t3,((C_word*)t0)[2]);}

/* k10644 in k10638 in k10619 in walk in ##compiler#scan-free-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10646,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10650,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1107 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[441]))(5,*((C_word*)lf[441]+1),t2,*((C_word*)lf[276]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k10648 in k10644 in k10638 in k10619 in walk in ##compiler#scan-free-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10521(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10521,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10525,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10527,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_10527(3,t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10527(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10527,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[215]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,lf[233]));
if(C_truep(t8)){
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_car(t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10549,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10555,a[2]=t12,a[3]=((C_word*)t0)[3],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t14=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[3])[1]);
t15=t13;
f_10555(t15,(C_word)C_i_not(t14));}
else{
t14=t13;
f_10555(t14,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t6,lf[83]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10582,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_10582(t11,t9);}
else{
t11=(C_word)C_eqp(t6,lf[221]);
t12=t10;
f_10582(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[229])));}}}

/* k10580 in walk in ##compiler#scan-used-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_10582(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k10553 in walk in ##compiler#scan-used-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_10555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10555,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10549(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10549(t2,C_SCHEME_UNDEFINED);}}

/* k10547 in walk in ##compiler#scan-used-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_10549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k10523 in ##compiler#scan-used-variables in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10223,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[358]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,lf[377]));
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[83],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[429],t10));}
else{
t7=(C_word)C_eqp(t4,lf[361]);
if(C_truep(t7)){
t8=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[83],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[430],t11));}
else{
t8=(C_word)C_eqp(t4,lf[376]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t4,lf[378]));
if(C_truep(t9)){
t10=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,lf[83],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t3,t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,lf[431],t13));}
else{
t10=(C_word)C_eqp(t4,lf[374]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[375]));
if(C_truep(t11)){
t12=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,lf[83],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_a_i_cons(&a,2,lf[432],t15));}
else{
t12=(C_word)C_eqp(t4,lf[362]);
if(C_truep(t12)){
t13=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[83],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=(C_word)C_a_i_cons(&a,2,lf[429],t16);
t18=(C_word)C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_cons(&a,2,lf[433],t18));}
else{
t13=(C_word)C_eqp(t4,lf[379]);
if(C_truep(t13)){
t14=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[83],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[434],t17));}
else{
t14=(C_word)C_eqp(t4,lf[380]);
if(C_truep(t14)){
t15=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[83],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,t3,t17);
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_cons(&a,2,lf[435],t18));}
else{
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10422,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t16=(C_word)C_i_length(t2);
t17=(C_word)C_eqp(C_fix(3),t16);
if(C_truep(t17)){
t18=(C_word)C_i_car(t2);
t19=t15;
f_10422(t19,(C_word)C_i_memq(t18,lf[438]));}
else{
t18=t15;
f_10422(t18,C_SCHEME_FALSE);}}
else{
t16=t15;
f_10422(t16,C_SCHEME_FALSE);}}}}}}}}}

/* k10420 in ##compiler#finish-foreign-result in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_10422(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10422,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[436],t4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_eqp(C_fix(3),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t2;
f_10443(t6,(C_word)C_eqp(lf[369],t5));}
else{
t5=t2;
f_10443(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_10443(t3,C_SCHEME_FALSE);}}}

/* k10441 in k10420 in ##compiler#finish-foreign-result in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_10443(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10443,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[367],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[437],t7));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##compiler#estimate-foreign-result-location-size in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9907(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9907,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9910,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9919,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10217,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1029 follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t1,t2,t4,t5);}

/* a10216 in ##compiler#estimate-foreign-result-location-size in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_10217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10217,2,t0,t1);}
/* support.scm: 1050 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[427],((C_word*)t0)[2]);}

/* a9918 in ##compiler#estimate-foreign-result-location-size in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9919,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[336]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9929,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_9929(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[340]);
if(C_truep(t7)){
t8=t6;
f_9929(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t8)){
t9=t6;
f_9929(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[421]);
if(C_truep(t9)){
t10=t6;
f_9929(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t10)){
t11=t6;
f_9929(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[337]);
if(C_truep(t11)){
t12=t6;
f_9929(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t12)){
t13=t6;
f_9929(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[383]);
if(C_truep(t13)){
t14=t6;
f_9929(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[382]);
if(C_truep(t14)){
t15=t6;
f_9929(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[410]);
if(C_truep(t15)){
t16=t6;
f_9929(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[411]);
if(C_truep(t16)){
t17=t6;
f_9929(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[355]);
if(C_truep(t17)){
t18=t6;
f_9929(t18,t17);}
else{
t18=(C_word)C_eqp(t4,lf[344]);
if(C_truep(t18)){
t19=t6;
f_9929(t19,t18);}
else{
t19=(C_word)C_eqp(t4,lf[357]);
if(C_truep(t19)){
t20=t6;
f_9929(t20,t19);}
else{
t20=(C_word)C_eqp(t4,lf[353]);
if(C_truep(t20)){
t21=t6;
f_9929(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[351]);
if(C_truep(t21)){
t22=t6;
f_9929(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[342]);
if(C_truep(t22)){
t23=t6;
f_9929(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[358]);
if(C_truep(t23)){
t24=t6;
f_9929(t24,t23);}
else{
t24=(C_word)C_eqp(t4,lf[362]);
if(C_truep(t24)){
t25=t6;
f_9929(t25,t24);}
else{
t25=(C_word)C_eqp(t4,lf[404]);
if(C_truep(t25)){
t26=t6;
f_9929(t26,t25);}
else{
t26=(C_word)C_eqp(t4,lf[399]);
if(C_truep(t26)){
t27=t6;
f_9929(t27,t26);}
else{
t27=(C_word)C_eqp(t4,lf[412]);
if(C_truep(t27)){
t28=t6;
f_9929(t28,t27);}
else{
t28=(C_word)C_eqp(t4,lf[413]);
if(C_truep(t28)){
t29=t6;
f_9929(t29,t28);}
else{
t29=(C_word)C_eqp(t4,lf[384]);
if(C_truep(t29)){
t30=t6;
f_9929(t30,t29);}
else{
t30=(C_word)C_eqp(t4,lf[381]);
if(C_truep(t30)){
t31=t6;
f_9929(t31,t30);}
else{
t31=(C_word)C_eqp(t4,lf[377]);
if(C_truep(t31)){
t32=t6;
f_9929(t32,t31);}
else{
t32=(C_word)C_eqp(t4,lf[378]);
if(C_truep(t32)){
t33=t6;
f_9929(t33,t32);}
else{
t33=(C_word)C_eqp(t4,lf[375]);
if(C_truep(t33)){
t34=t6;
f_9929(t34,t33);}
else{
t34=(C_word)C_eqp(t4,lf[361]);
if(C_truep(t34)){
t35=t6;
f_9929(t35,t34);}
else{
t35=(C_word)C_eqp(t4,lf[376]);
if(C_truep(t35)){
t36=t6;
f_9929(t36,t35);}
else{
t36=(C_word)C_eqp(t4,lf[374]);
if(C_truep(t36)){
t37=t6;
f_9929(t37,t36);}
else{
t37=(C_word)C_eqp(t4,lf[379]);
t38=t6;
f_9929(t38,(C_truep(t37)?t37:(C_word)C_eqp(t4,lf[380])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k9927 in a9918 in ##compiler#estimate-foreign-result-location-size in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_9929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9929,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub334(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[405]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[406]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
t5=(C_word)C_i_foreign_fixnum_argumentp(C_fix(2));
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub334(C_SCHEME_UNDEFINED,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 1042 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t4,C_retrieve(lf[373]),((C_word*)t0)[3]);}
else{
t5=t4;
f_9947(2,t5,C_SCHEME_FALSE);}}}}

/* k9945 in k9927 in a9918 in ##compiler#estimate-foreign-result-location-size in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9947,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1044 next */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[364]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9981,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_9981(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[346]);
if(C_truep(t5)){
t6=t4;
f_9981(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t6)){
t7=t4;
f_9981(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[355]);
if(C_truep(t7)){
t8=t4;
f_9981(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[357]);
t9=t4;
f_9981(t9,(C_truep(t8)?t8:(C_word)C_eqp(t2,lf[372])));}}}}}
else{
/* support.scm: 1049 err */
f_9910(((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k9979 in k9945 in k9927 in a9918 in ##compiler#estimate-foreign-result-location-size in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_9981(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub334(C_SCHEME_UNDEFINED,t3));}
else{
/* support.scm: 1048 err */
f_9910(((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##compiler#estimate-foreign-result-location-size in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_9910(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9910,NULL,2,t1,t2);}
/* support.scm: 1028 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[426],t2);}

/* ##compiler#estimate-foreign-result-size in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9582,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9588,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9901,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 999  follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t1,t2,t3,t4);}

/* a9900 in ##compiler#estimate-foreign-result-size in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9901,2,t0,t1);}
/* support.scm: 1024 quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[424],((C_word*)t0)[2]);}

/* a9587 in ##compiler#estimate-foreign-result-size in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9588,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[336]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9598,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_9598(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[340]);
if(C_truep(t7)){
t8=t6;
f_9598(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t8)){
t9=t6;
f_9598(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[421]);
if(C_truep(t9)){
t10=t6;
f_9598(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[422]);
if(C_truep(t10)){
t11=t6;
f_9598(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t11)){
t12=t6;
f_9598(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[423]);
if(C_truep(t12)){
t13=t6;
f_9598(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[337]);
if(C_truep(t13)){
t14=t6;
f_9598(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t14)){
t15=t6;
f_9598(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[410]);
if(C_truep(t15)){
t16=t6;
f_9598(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[411]);
if(C_truep(t16)){
t17=t6;
f_9598(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[412]);
t18=t6;
f_9598(t18,(C_truep(t17)?t17:(C_word)C_eqp(t4,lf[413])));}}}}}}}}}}}}

/* k9596 in a9587 in ##compiler#estimate-foreign-result-size in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_9598(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9598,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[358]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9607(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[361]);
if(C_truep(t4)){
t5=t3;
f_9607(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[355]);
if(C_truep(t5)){
t6=t3;
f_9607(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[357]);
if(C_truep(t6)){
t7=t3;
f_9607(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[362]);
if(C_truep(t7)){
t8=t3;
f_9607(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[376]);
if(C_truep(t8)){
t9=t3;
f_9607(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[374]);
if(C_truep(t9)){
t10=t3;
f_9607(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[377]);
if(C_truep(t10)){
t11=t3;
f_9607(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[378]);
if(C_truep(t11)){
t12=t3;
f_9607(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[375]);
if(C_truep(t12)){
t13=t3;
f_9607(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[379]);
t14=t3;
f_9607(t14,(C_truep(t13)?t13:(C_word)C_eqp(((C_word*)t0)[4],lf[380])));}}}}}}}}}}}}

/* k9605 in k9596 in a9587 in ##compiler#estimate-foreign-result-size in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_9607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9607,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub334(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[353]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9619(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[383]);
if(C_truep(t4)){
t5=t3;
f_9619(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[351]);
if(C_truep(t5)){
t6=t3;
f_9619(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[382]);
if(C_truep(t6)){
t7=t3;
f_9619(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[384]);
t8=t3;
f_9619(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[381])));}}}}}}

/* k9617 in k9605 in k9596 in a9587 in ##compiler#estimate-foreign-result-size in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_9619(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9619,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub334(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[342]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_9631(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[405]);
if(C_truep(t4)){
t5=t3;
f_9631(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[406]);
t6=t3;
f_9631(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[420])));}}}}

/* k9629 in k9617 in k9605 in k9596 in a9587 in ##compiler#estimate-foreign-result-size in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_9631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9631,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub334(C_SCHEME_UNDEFINED,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm: 1015 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t2,C_retrieve(lf[373]),((C_word*)t0)[2]);}
else{
t3=t2;
f_9637(2,t3,C_SCHEME_FALSE);}}}

/* k9635 in k9629 in k9617 in k9605 in k9596 in a9587 in ##compiler#estimate-foreign-result-size in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9637,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 1017 next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[364]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9671,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_9671(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[346]);
if(C_truep(t5)){
t6=t4;
f_9671(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t6)){
t7=t4;
f_9671(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[355]);
if(C_truep(t7)){
t8=t4;
f_9671(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[357]);
if(C_truep(t8)){
t9=t4;
f_9671(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[372]);
if(C_truep(t9)){
t10=t4;
f_9671(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[365]);
if(C_truep(t10)){
t11=t4;
f_9671(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[366]);
t12=t4;
f_9671(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[369])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k9669 in k9635 in k9629 in k9617 in k9605 in k9596 in a9587 in ##compiler#estimate-foreign-result-size in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_9671(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub334(C_SCHEME_UNDEFINED,t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* ##compiler#final-foreign-type in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9542(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9542,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9548,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9576,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 986  follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t1,t2,t3,t4);}

/* a9575 in ##compiler#final-foreign-type in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9576,2,t0,t1);}
/* support.scm: 993  quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[418],((C_word*)t0)[2]);}

/* a9547 in ##compiler#final-foreign-type in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9548,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9552,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 989  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t4,C_retrieve(lf[373]),t2);}
else{
t5=t4;
f_9552(2,t5,C_SCHEME_FALSE);}}

/* k9550 in a9547 in ##compiler#final-foreign-type in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 991  next */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* ##compiler#foreign-type-convert-argument in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9511(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9511,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9515,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9524,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 980  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t5,C_retrieve(lf[373]),t3);}
else{
t5=t4;
f_9515(t5,C_SCHEME_FALSE);}}

/* k9522 in ##compiler#foreign-type-convert-argument in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9524,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=((C_word*)t0)[3];
f_9515(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_9515(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9515(t2,C_SCHEME_FALSE);}}

/* k9513 in ##compiler#foreign-type-convert-argument in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_9515(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-convert-result in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9480,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9484,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9493,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 973  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t5,C_retrieve(lf[373]),t3);}
else{
t5=t4;
f_9484(t5,C_SCHEME_FALSE);}}

/* k9491 in ##compiler#foreign-type-convert-result in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9493,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(2));
t3=((C_word*)t0)[3];
f_9484(t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_9484(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9484(t2,C_SCHEME_FALSE);}}

/* k9482 in ##compiler#foreign-type-convert-result in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_9484(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8427,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8433,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9474,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 874  follow-without-loop */
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t1,t3,t4,t5);}

/* a9473 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9474,2,t0,t1);}
/* support.scm: 966  quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),t1,lf[414],((C_word*)t0)[2]);}

/* a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8433,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8439,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_8439(t7,t1,t2);}

/* repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8439(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8439,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[336]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[337]));
if(C_truep(t5)){
if(C_truep(C_retrieve(lf[338]))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[4]);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[339],t6));}}
else{
t6=(C_word)C_eqp(t3,lf[340]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_8468(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[407]);
if(C_truep(t8)){
t9=t7;
f_8468(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[408]);
if(C_truep(t9)){
t10=t7;
f_8468(t10,t9);}
else{
t10=(C_word)C_eqp(t3,lf[409]);
if(C_truep(t10)){
t11=t7;
f_8468(t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[410]);
if(C_truep(t11)){
t12=t7;
f_8468(t12,t11);}
else{
t12=(C_word)C_eqp(t3,lf[411]);
if(C_truep(t12)){
t13=t7;
f_8468(t13,t12);}
else{
t13=(C_word)C_eqp(t3,lf[412]);
t14=t7;
f_8468(t14,(C_truep(t13)?t13:(C_word)C_eqp(t3,lf[413])));}}}}}}}}

/* k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8468(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8468,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[338]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[341],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[342]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8487(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[405]);
t5=t3;
f_8487(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[406])));}}}

/* k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8487(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8487,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[338]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[343],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[344]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8506(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[402]);
if(C_truep(t4)){
t5=t3;
f_8506(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[403]);
t6=t3;
f_8506(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[404])));}}}}

/* k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8506,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8509,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 884  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[346]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8576(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[399]);
if(C_truep(t4)){
t5=t3;
f_8576(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[400]);
t6=t3;
f_8576(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[401])));}}}}

/* k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8576(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8576,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[338]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[345],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[347]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8595(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[392]);
if(C_truep(t4)){
t5=t3;
f_8595(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[393]);
if(C_truep(t5)){
t6=t3;
f_8595(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[394]);
if(C_truep(t6)){
t7=t3;
f_8595(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[395]);
if(C_truep(t7)){
t8=t3;
f_8595(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[396]);
if(C_truep(t8)){
t9=t3;
f_8595(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[397]);
t10=t3;
f_8595(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[398])));}}}}}}}}

/* k8593 in k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8595(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8595,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8598,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 896  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8677(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[385]);
if(C_truep(t4)){
t5=t3;
f_8677(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[386]);
if(C_truep(t5)){
t6=t3;
f_8677(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[387]);
if(C_truep(t6)){
t7=t3;
f_8677(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[388]);
if(C_truep(t7)){
t8=t3;
f_8677(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[389]);
if(C_truep(t8)){
t9=t3;
f_8677(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[390]);
t10=t3;
f_8677(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[391])));}}}}}}}}

/* k8675 in k8593 in k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8677,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[338]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[5],lf[350]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[83],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[348],t7));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[351]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8716,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8716(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[383]);
t5=t3;
f_8716(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[384])));}}}

/* k8714 in k8675 in k8593 in k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8716(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8716,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[338]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[352],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[353]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8735,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8735(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[381]);
t5=t3;
f_8735(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[382])));}}}

/* k8733 in k8714 in k8675 in k8593 in k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8735(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8735,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[338]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[354],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[355]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8754(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[379]);
t5=t3;
f_8754(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[380])));}}}

/* k8752 in k8733 in k8714 in k8675 in k8593 in k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8754(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8754,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8757,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 916  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[357]);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[356],t3));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[358]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_8834(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[376]);
if(C_truep(t5)){
t6=t4;
f_8834(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[377]);
t7=t4;
f_8834(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[378])));}}}}}

/* k8832 in k8752 in k8733 in k8714 in k8675 in k8593 in k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8834(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8834,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8837,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 924  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[361]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8919(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[374]);
t5=t3;
f_8919(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[375])));}}}

/* k8917 in k8832 in k8752 in k8733 in k8714 in k8675 in k8593 in k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8919(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8919,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[338]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[359],t2));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[360],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[359],t4));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[362]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[338]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[363],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[359],t5));}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[363],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[360],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[359],t7));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 940  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t3,C_retrieve(lf[373]),((C_word*)t0)[3]);}
else{
t4=t3;
f_8994(2,t4,C_SCHEME_FALSE);}}}}

/* k8992 in k8917 in k8832 in k8752 in k8733 in k8714 in k8675 in k8593 in k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8994,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* support.scm: 942  next */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[364]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_9028(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t5)){
t6=t4;
f_9028(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[372]);
t7=t4;
f_9028(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[355])));}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k9026 in k8992 in k8917 in k8832 in k8752 in k8733 in k8714 in k8675 in k8593 in k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_9028(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9028,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9031,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 946  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[365]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[366]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9098,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 952  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[369]);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[367],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[83],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t7);
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[368],t8));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[370]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* support.scm: 959  repeat */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8439(t7,((C_word*)t0)[5],t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[371]);
if(C_truep(t6)){
if(C_truep(C_retrieve(lf[338]))){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[6]);}
else{
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[352],t7));}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[346]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[357]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[356],t9));}
else{
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[6]);}}}}}}}

/* k9096 in k9026 in k8992 in k8917 in k8832 in k8752 in k8733 in k8714 in k8675 in k8593 in k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9098,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[367],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[83],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[368],t8);
t10=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,lf[83],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t9,t12);
t14=(C_word)C_a_i_cons(&a,2,t1,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[220],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t4,t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[93],t17));}

/* k9029 in k9026 in k8992 in k8917 in k8832 in k8752 in k8733 in k8714 in k8675 in k8593 in k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_9031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9031,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[356],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[83],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[220],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[93],t14));}

/* k8835 in k8832 in k8752 in k8733 in k8714 in k8675 in k8593 in k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8837,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8868,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[338]))){
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_8868(t7,(C_word)C_a_i_cons(&a,2,lf[359],t6));}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[360],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t5;
f_8868(t9,(C_word)C_a_i_cons(&a,2,lf[359],t8));}}

/* k8866 in k8835 in k8832 in k8752 in k8733 in k8714 in k8675 in k8593 in k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8868,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[220],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[93],t9));}

/* k8755 in k8752 in k8733 in k8714 in k8675 in k8593 in k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8757,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[356],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[83],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[220],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[93],t14));}

/* k8596 in k8593 in k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8598,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8629,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[338]))){
t6=t5;
f_8629(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[83],t6);
t8=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=t5;
f_8629(t10,(C_word)C_a_i_cons(&a,2,lf[348],t9));}}

/* k8627 in k8596 in k8593 in k8574 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8629(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8629,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[220],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[93],t9));}

/* k8507 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8509,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8540,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[338]))){
t6=t5;
f_8540(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_8540(t7,(C_word)C_a_i_cons(&a,2,lf[345],t6));}}

/* k8538 in k8507 in k8504 in k8485 in k8466 in repeat in a8432 in ##compiler#foreign-type-check in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8540(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8540,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[220],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[93],t9));}

/* ##compiler#pprint-expressions-to-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8391,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8395,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm: 855  open-output-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[333]+1)))(3,*((C_word*)lf[333]+1),t4,t3);}
else{
/* support.scm: 855  current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[334]+1)))(2,*((C_word*)lf[334]+1),t4);}}

/* k8393 in ##compiler#pprint-expressions-to-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8398,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8406,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 856  with-output-to-port */
((C_proc4)C_retrieve_symbol_proc(lf[332]))(4,*((C_word*)lf[332]+1),t2,t1,t3);}

/* a8405 in k8393 in ##compiler#pprint-expressions-to-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8412,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a8411 in a8405 in k8393 in ##compiler#pprint-expressions-to-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8412,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8416,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 860  pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[331]))(3,*((C_word*)lf[331]+1),t3,t2);}

/* k8414 in a8411 in a8405 in k8393 in ##compiler#pprint-expressions-to-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 861  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k8396 in k8393 in ##compiler#pprint-expressions-to-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 863  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[330]+1)))(3,*((C_word*)lf[330]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#print-program-statistics in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8352(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8352,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8358,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8364,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a8363 in ##compiler#print-program-statistics in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8364(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8364,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8371,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 843  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[10]))(4,*((C_word*)lf[10]+1),t9,lf[327],lf[328]);}

/* k8369 in a8363 in ##compiler#print-program-statistics in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8371,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8374,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* support.scm: 844  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),t2,lf[326],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8372 in k8369 in a8363 in ##compiler#print-program-statistics in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8377,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 845  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[325],((C_word*)t0)[2]);}

/* k8375 in k8372 in k8369 in a8363 in ##compiler#print-program-statistics in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8380,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 846  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[324],((C_word*)t0)[2]);}

/* k8378 in k8375 in k8372 in k8369 in a8363 in ##compiler#print-program-statistics in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8383,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 847  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[323],((C_word*)t0)[2]);}

/* k8381 in k8378 in k8375 in k8372 in k8369 in a8363 in ##compiler#print-program-statistics in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8386,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 848  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[322],((C_word*)t0)[2]);}

/* k8384 in k8381 in k8378 in k8375 in k8372 in k8369 in a8363 in ##compiler#print-program-statistics in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 849  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[321],((C_word*)t0)[2]);}

/* a8357 in ##compiler#print-program-statistics in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8358,2,t0,t1);}
/* support.scm: 842  compute-database-statistics */
((C_proc3)C_retrieve_symbol_proc(lf[317]))(3,*((C_word*)lf[317]+1),t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8272,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8276,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8281,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 818  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t13,t14,t2);}

/* a8280 in ##compiler#compute-database-statistics in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8281,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8287,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a8286 in a8280 in ##compiler#compute-database-statistics in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8287(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8287,3,t0,t1,t2);}
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[183]);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=(C_word)C_eqp(t5,lf[164]);
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[228],t11);
if(C_truep(t12)){
t13=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t14=C_mutate(((C_word *)((C_word*)t0)[3])+1,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}}
else{
t8=(C_word)C_eqp(t5,lf[171]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t10);
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}}}

/* k8274 in ##compiler#compute-database-statistics in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 832  values */
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[318]),C_retrieve(lf[319]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#toplevel-definition-hook in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8251,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8261,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 795  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t7,lf[251],lf[316],t2);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k8259 in ##sys#toplevel-definition-hook in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 796  hide-variable */
((C_proc3)C_retrieve_symbol_proc(lf[315]))(3,*((C_word*)lf[315]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#dump-global-refs in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8212(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8212,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8218,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 781  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t1,t3,t2);}

/* a8217 in ##compiler#dump-global-refs in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8218,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_assq(lf[183],t3))){
t4=(C_word)C_i_assq(lf[170],t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8231,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8242,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t7=(C_word)C_i_cdr(t4);
t8=t6;
f_8242(t8,(C_word)C_i_length(t7));}
else{
t7=t6;
f_8242(t7,C_fix(0));}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k8240 in a8217 in ##compiler#dump-global-refs in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8242,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 785  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[201]+1)))(3,*((C_word*)lf[201]+1),((C_word*)t0)[2],t2);}

/* k8229 in a8217 in ##compiler#dump-global-refs in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 786  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* ##compiler#dump-defined-globals in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8185,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8191,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 772  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t1,t3,t2);}

/* a8190 in ##compiler#dump-defined-globals in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8191(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8191,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(lf[183],t3);
t5=(C_truep(t4)?(C_word)C_i_assq(lf[181],t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8201,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 776  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[201]+1)))(3,*((C_word*)lf[201]+1),t6,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k8199 in a8190 in ##compiler#dump-defined-globals in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 777  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* ##compiler#dump-undefined-globals in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8154(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8154,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8160,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 763  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t1,t3,t2);}

/* a8159 in ##compiler#dump-undefined-globals in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8160,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8167,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_assq(lf[183],t3))){
t5=(C_word)C_i_assq(lf[181],t3);
t6=t4;
f_8167(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_8167(t5,C_SCHEME_FALSE);}}

/* k8165 in a8159 in ##compiler#dump-undefined-globals in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_8167(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8167,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8170,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 767  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[201]+1)))(3,*((C_word*)lf[201]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8168 in k8165 in a8159 in ##compiler#dump-undefined-globals in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 768  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* ##compiler#simple-lambda-node? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8062,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_car(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
if(C_truep((C_word)C_i_cadr(t4))){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8086,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_8086(3,t11,t1,t2);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* rec in ##compiler#simple-lambda-node? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8086(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8086,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(t4,lf[240]);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(lf[215],t9);
if(C_truep(t10)){
t11=(C_word)C_slot(t8,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(C_word)C_eqp(((C_word*)t0)[3],t12);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t7);
/* support.scm: 755  every */
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),t1,((C_word*)((C_word*)t0)[2])[1],t14);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(t4,lf[231]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
/* support.scm: 757  every */
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* ##compiler#expression-has-side-effects? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7976(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7976,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7982,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_7982(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7982(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7982,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[215]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7998,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_7998(t9,t7);}
else{
t9=(C_word)C_eqp(t6,lf[83]);
if(C_truep(t9)){
t10=t8;
f_7998(t10,t9);}
else{
t10=(C_word)C_eqp(t6,lf[221]);
if(C_truep(t10)){
t11=t8;
f_7998(t11,t10);}
else{
t11=(C_word)C_eqp(t6,lf[232]);
t12=t8;
f_7998(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[219])));}}}}

/* k7996 in walk in ##compiler#expression-has-side-effects? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_7998(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7998,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[228]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8012,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 738  find */
((C_proc4)C_retrieve_symbol_proc(lf[308]))(4,*((C_word*)lf[308]+1),((C_word*)t0)[6],t6,C_retrieve(lf[309]));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[220]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[93]));
if(C_truep(t4)){
/* support.scm: 739  any */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}

/* a8011 in k7996 in walk in ##compiler#expression-has-side-effects? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8012(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8012,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8020,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 738  foreign-callback-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[307]))(3,*((C_word*)lf[307]+1),t3,t2);}

/* k8018 in a8011 in k7996 in walk in ##compiler#expression-has-side-effects? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_8020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7781,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7784,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7813,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7856,a[2]=t9,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7960,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 722  matchn */
t15=((C_word*)t12)[1];
f_7856(t15,t14,t2,t3);}

/* k7958 in ##compiler#match-node in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7960,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7966,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=(C_word)C_slot(t3,C_fix(1));
t5=((C_word*)t0)[3];
t6=(C_word)C_slot(t5,C_fix(2));
/* support.scm: 725  debugging */
((C_proc7)C_retrieve_symbol_proc(lf[10]))(7,*((C_word*)lf[10]+1),t2,lf[304],lf[305],t4,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7964 in k7958 in ##compiler#match-node in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* matchn in ##compiler#match-node in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_7856(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7856,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 711  resolve */
t4=((C_word*)t0)[4];
f_7784(t4,t1,t3,t2);}
else{
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_i_car(t3);
t7=(C_word)C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7878,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_cadr(t3);
/* support.scm: 713  match1 */
t12=((C_word*)((C_word*)t0)[2])[1];
f_7813(t12,t8,t10,t11);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}

/* k7876 in matchn in ##compiler#match-node in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7878,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7891,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7891(t8,((C_word*)t0)[2],t3,t4);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop in k7876 in matchn in ##compiler#match-node in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_7891(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7891,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t2));}
else{
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 717  resolve */
t4=((C_word*)t0)[4];
f_7784(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7922,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 719  matchn */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7856(t7,t4,t5,t6);}}}}

/* k7920 in loop in k7876 in matchn in ##compiler#match-node in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 720  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7891(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_7813(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7813,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
/* support.scm: 704  resolve */
t4=((C_word*)t0)[3];
f_7784(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7835,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* support.scm: 706  match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k7833 in match1 in ##compiler#match-node in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 706  match1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7813(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_7784(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7784,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t3,t5));}
else{
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7808,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 699  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}

/* k7806 in resolve in ##compiler#match-node in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##compiler#load-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7712,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7718,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 679  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[302]))(4,*((C_word*)lf[302]+1),t1,t2,t3);}

/* a7717 in ##compiler#load-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7718,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7724,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7724(t5,t1);}

/* loop in a7717 in ##compiler#load-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_7724(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7724,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7728,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 682  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[102]+1)))(2,*((C_word*)lf[102]+1),t2);}

/* k7726 in loop in a7717 in ##compiler#load-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7728,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7764,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7775,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t1);
/* support.scm: 687  sexpr->node */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t4,t5);}}

/* k7773 in k7726 in loop in a7717 in ##compiler#load-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7775,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_7739(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_7739(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k7737 in k7773 in k7726 in loop in a7717 in ##compiler#load-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[294],t1);}

/* k7762 in k7726 in loop in a7717 in ##compiler#load-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 688  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7724(t2,((C_word*)t0)[2]);}

/* ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7532,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7536,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7563,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 648  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[300]))(4,*((C_word*)lf[300]+1),t6,t2,t7);}

/* a7562 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7710,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 650  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[299]))(2,*((C_word*)lf[299]+1),t3);}

/* k7708 in a7562 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 650  print */
((C_proc7)C_retrieve_proc(*((C_word*)lf[284]+1)))(7,*((C_word*)lf[284]+1),((C_word*)t0)[2],lf[296],t1,lf[297],C_retrieve(lf[242]),lf[298]);}

/* k7565 in a7562 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7570,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 652  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t2,t3,((C_word*)t0)[2]);}

/* a7574 in k7565 in a7562 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7575,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 654  variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[295]))(3,*((C_word*)lf[295]+1),t4,t2);}

/* k7580 in a7574 in k7565 in a7562 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7582,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[166],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t4,t3,lf[294]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7701 in k7580 in a7574 in k7565 in a7562 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7703,2,t0,t1);}
if(C_truep((C_word)C_i_structurep(t1,lf[205]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_assq(lf[164],((C_word*)t0)[6]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_7606(t5,t3);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_eqp(lf[159],t5);
t7=t4;
f_7606(t7,(C_word)C_i_not(t6));}}}

/* k7604 in k7701 in k7580 in a7574 in k7565 in a7562 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_7606(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7606,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_assq(lf[193],((C_word*)t0)[7]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7627,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_i_car(t3);
/* support.scm: 662  get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t4,((C_word*)t0)[2],t5,lf[192]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7625 in k7604 in k7701 in k7580 in a7574 in k7565 in a7562 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7627,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7684,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 663  get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[200]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7682 in k7625 in k7604 in k7701 in k7580 in a7574 in k7565 in a7562 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7684,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t3,t2,lf[293]);}}

/* k7637 in k7682 in k7625 in k7604 in k7701 in k7580 in a7574 in k7565 in a7562 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7642,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(t1,lf[290]);
if(C_truep(t3)){
t4=t2;
f_7642(t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(t1,lf[291]);
if(C_truep(t4)){
t5=t2;
f_7642(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t6=C_retrieve(lf[292]);
t7=t2;
f_7642(t7,(C_word)C_fixnum_lessp(t5,t6));}}}

/* k7640 in k7637 in k7682 in k7625 in k7604 in k7701 in k7580 in a7574 in k7565 in a7562 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_7642(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7642,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7649,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7660,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 670  node->sexpr */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7658 in k7640 in k7637 in k7682 in k7625 in k7604 in k7701 in k7580 in a7574 in k7565 in a7562 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7660,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 670  pp */
((C_proc3)C_retrieve_symbol_proc(lf[289]))(3,*((C_word*)lf[289]+1),((C_word*)t0)[2],t2);}

/* k7647 in k7640 in k7637 in k7682 in k7625 in k7604 in k7701 in k7580 in a7574 in k7565 in a7562 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 671  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k7568 in k7565 in a7562 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 673  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[284]+1)))(3,*((C_word*)lf[284]+1),((C_word*)t0)[2],lf[288]);}

/* k7534 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* support.scm: 675  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[10]))(4,*((C_word*)lf[10]+1),t2,lf[286],lf[287]);}
else{
t3=t2;
f_7542(2,t3,C_SCHEME_FALSE);}}

/* k7540 in k7534 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7542,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7547,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7555,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 676  sort-symbols */
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7553 in k7540 in k7534 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7546 in k7540 in k7534 in ##compiler#emit-global-inline-file in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7547,3,t0,t1,t2);}
/* print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[284]+1)))(4,*((C_word*)lf[284]+1),t1,lf[285],t2);}

/* ##compiler#sexpr->node in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7507(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7507,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7513,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7513(3,t6,t1,t2);}

/* walk in ##compiler#sexpr->node in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7513,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7523,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cddr(t2);
/* map */
t7=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)((C_word*)t0)[2])[1],t6);}

/* k7521 in walk in ##compiler#sexpr->node in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7523,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* ##compiler#node->sexpr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7471(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7471,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7477,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7477(3,t6,t1,t2);}

/* walk in ##compiler#node->sexpr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7477,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7497,a[2]=t4,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7501,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=t2;
t10=(C_word)C_slot(t9,C_fix(3));
/* map */
t11=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,((C_word*)((C_word*)t0)[2])[1],t10);}

/* k7499 in walk in ##compiler#node->sexpr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7495 in walk in ##compiler#node->sexpr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7497,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* ##compiler#copy-node! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7447,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7451,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
/* support.scm: 631  node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[207]))(4,*((C_word*)lf[207]+1),t4,t3,t6);}

/* k7449 in ##compiler#copy-node! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_slot(t3,C_fix(2));
/* support.scm: 632  node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[210]))(4,*((C_word*)lf[210]+1),t2,((C_word*)t0)[3],t4);}

/* k7452 in k7449 in ##compiler#copy-node! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7457,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_slot(t3,C_fix(3));
/* support.scm: 633  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[212]))(4,*((C_word*)lf[212]+1),t2,((C_word*)t0)[3],t4);}

/* k7455 in k7452 in k7449 in ##compiler#copy-node! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#tree-copy in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7413(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7413,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7419,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7419(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_7419(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7419,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7433,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 627  rec */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k7431 in rec in ##compiler#tree-copy in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7437,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 627  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7419(t4,t2,t3);}

/* k7435 in k7431 in rec in ##compiler#tree-copy in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7437,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7235,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7239,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 595  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[256]+1)))(5,*((C_word*)lf[256]+1),t5,*((C_word*)lf[279]+1),t3,t4);}

/* k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7241,tmp=(C_word)a,a+=2,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7247,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
/* support.scm: 622  walk */
t6=((C_word*)t4)[1];
f_7247(t6,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_7247(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7247,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[215]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7270,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_car(t7);
/* support.scm: 602  rename */
f_7241(t11,t12,t3);}
else{
t11=(C_word)C_eqp(t9,lf[233]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7299,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_car(t7);
/* support.scm: 603  rename */
f_7241(t12,t13,t3);}
else{
t12=(C_word)C_eqp(t9,lf[93]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7315,a[2]=t3,a[3]=t13,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 606  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),t14,t13);}
else{
t13=(C_word)C_eqp(t9,lf[228]);
if(C_truep(t13)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7348,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 610  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t1,t14,t15);}
else{
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7396,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 621  tree-copy */
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t14,t7);}}}}}

/* k7394 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7399,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7404,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7403 in k7394 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7404(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7404,3,t0,t1,t2);}
/* walk1578 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7247(t3,t1,t2,((C_word*)t0)[2]);}

/* k7397 in k7394 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7399,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a7347 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7348,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t6=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[94]),t2);}

/* k7350 in a7347 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7355,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm: 614  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),t2,t1,((C_word*)t0)[2]);}

/* k7353 in k7350 in a7347 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* support.scm: 617  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),t2,lf[277]);}

/* k7372 in k7353 in k7350 in a7347 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7374,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7382,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7390,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* support.scm: 618  rename */
f_7241(t4,((C_word*)t0)[3],((C_word*)t0)[7]);}
else{
t5=t4;
f_7390(2,t5,C_SCHEME_FALSE);}}

/* k7388 in k7372 in k7353 in k7350 in a7347 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 618  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[49]))(5,*((C_word*)lf[49]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7380 in k7372 in k7353 in k7350 in a7347 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7382,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7361,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7366,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a7365 in k7380 in k7372 in k7353 in k7350 in a7347 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7366(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7366,3,t0,t1,t2);}
/* walk1578 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7247(t3,t1,t2,((C_word*)t0)[2]);}

/* k7359 in k7380 in k7372 in k7353 in k7350 in a7347 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7361,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],lf[228],((C_word*)t0)[2],t1));}

/* k7313 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7318,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 607  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7316 in k7313 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7318,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7324,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7329,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7328 in k7316 in k7313 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7329(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7329,3,t0,t1,t2);}
/* walk1578 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7247(t3,t1,t2,((C_word*)t0)[2]);}

/* k7322 in k7316 in k7313 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7324,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],lf[93],((C_word*)t0)[2],t1));}

/* k7297 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7299,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7286,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7291,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7290 in k7297 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7291(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7291,3,t0,t1,t2);}
/* walk1578 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7247(t3,t1,t2,((C_word*)t0)[2]);}

/* k7284 in k7297 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7286,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],lf[233],((C_word*)t0)[2],t1));}

/* k7268 in walk in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7270,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_list(&a,1,t1);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[205],lf[215],t3,C_SCHEME_END_OF_LIST));}

/* rename in k7237 in ##compiler#copy-node-tree-and-rename in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_7241(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7241,NULL,3,t1,t2,t3);}
/* support.scm: 596  alist-ref */
((C_proc6)C_retrieve_symbol_proc(lf[275]))(6,*((C_word*)lf[275]+1),t1,t2,t3,*((C_word*)lf[276]+1),t2);}

/* ##compiler#inline-lambda-bindings in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7142,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7148,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 573  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t1,t2,t6);}

/* a7147 in ##compiler#inline-lambda-bindings in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7148,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7154,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7160,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a7159 in a7147 in ##compiler#inline-lambda-bindings in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7160,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[94]),((C_word*)t0)[2]);}
else{
t5=t4;
f_7164(2,t5,((C_word*)t0)[2]);}}

/* k7162 in a7159 in a7147 in ##compiler#inline-lambda-bindings in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7167,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 579  copy-node-tree-and-rename */
((C_proc5)C_retrieve_symbol_proc(lf[274]))(5,*((C_word*)lf[274]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}
else{
t3=t2;
f_7167(2,t3,((C_word*)t0)[3]);}}

/* k7165 in k7162 in a7159 in a7147 in ##compiler#inline-lambda-bindings in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7172,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7186,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7227,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 585  last */
((C_proc3)C_retrieve_symbol_proc(lf[255]))(3,*((C_word*)lf[255]+1),t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_7186(t4,t1);}}

/* k7225 in k7165 in k7162 in a7159 in a7147 in ##compiler#inline-lambda-bindings in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7227,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7203,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
t4=(C_word)C_a_i_list(&a,1,C_SCHEME_END_OF_LIST);
t5=t3;
f_7203(t5,(C_word)C_a_i_record(&a,4,lf[205],lf[83],t4,C_SCHEME_END_OF_LIST));}
else{
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=(C_word)C_fixnum_times(C_fix(3),t4);
t6=(C_word)C_a_i_list(&a,2,lf[273],t5);
t7=((C_word*)t0)[2];
t8=t3;
f_7203(t8,(C_word)C_a_i_record(&a,4,lf[205],lf[238],t6,t7));}}

/* k7201 in k7225 in k7165 in k7162 in a7159 in a7147 in ##compiler#inline-lambda-bindings in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_7203(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7203,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_7186(t3,(C_word)C_a_i_record(&a,4,lf[205],lf[93],((C_word*)t0)[2],t2));}

/* k7184 in k7165 in k7162 in a7159 in a7147 in ##compiler#inline-lambda-bindings in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_7186(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7186,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7190,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 591  take */
((C_proc4)C_retrieve_symbol_proc(lf[272]))(4,*((C_word*)lf[272]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7188 in k7184 in k7165 in k7162 in a7159 in a7147 in ##compiler#inline-lambda-bindings in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 581  fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[271]))(6,*((C_word*)lf[271]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a7171 in k7165 in k7162 in a7159 in a7147 in ##compiler#inline-lambda-bindings in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7172,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[205],lf[93],t5,t6));}

/* a7153 in a7147 in ##compiler#inline-lambda-bindings in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7154,2,t0,t1);}
/* support.scm: 576  split-at */
((C_proc4)C_retrieve_symbol_proc(lf[270]))(4,*((C_word*)lf[270]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7094,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7100,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7100(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_7100(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7100,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7120,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
/* support.scm: 569  proc */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k7118 in fold in ##compiler#fold-boolean in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7124,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 570  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7100(t4,t2,t3);}

/* k7122 in k7118 in fold in ##compiler#fold-boolean in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7124,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[205],lf[230],lf[268],t2));}

/* ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6776,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6782,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6782(3,t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6782(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6782,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[220]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6801,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t8,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_6801(t11,t9);}
else{
t11=(C_word)C_eqp(t8,lf[265]);
t12=t10;
f_6801(t12,(C_truep(t11)?t11:(C_word)C_eqp(t8,lf[266])));}}

/* k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_6801(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6801,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6808,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[254]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6825,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6829,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[215]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[219]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[83]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[83],t7));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[93]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6875,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6891,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6895,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 543  butlast */
((C_proc3)C_retrieve_symbol_proc(lf[258]))(3,*((C_word*)lf[258]+1),t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[228]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[118]:lf[228]);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6916,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 550  walk */
t13=((C_word*)((C_word*)t0)[4])[1];
f_6782(3,t13,t11,t12);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[240]);
if(C_truep(t8)){
/* map */
t9=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[231]);
if(C_truep(t9)){
t10=(C_word)C_i_car(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6949,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[221]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[260]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6973,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_6973(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[261]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7035,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_7035(t14,t12);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[262]);
if(C_truep(t14)){
t15=t13;
f_7035(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[263]);
t16=t13;
f_7035(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[264])));}}}}}}}}}}}}}

/* k7033 in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_7035(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7035,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7042,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 560  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6782(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7061,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7065,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k7063 in k7033 in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 561  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7059 in k7033 in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7061,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7040 in k7033 in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7046,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k7044 in k7040 in k7033 in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 560  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[259]))(6,*((C_word*)lf[259]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_6973(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6973,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6991,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 557  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t6,t4);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7022,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_car(t3);
/* support.scm: 558  walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_6782(3,t10,t8,t9);}}

/* k7020 in loop in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_7022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7022,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* support.scm: 558  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6973(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6989 in loop in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6999,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* support.scm: 557  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6782(3,t4,t2,t3);}

/* k6997 in k6989 in loop in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6999,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[260],t3));}

/* k6947 in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 552  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[259]))(5,*((C_word*)lf[259]+1),((C_word*)t0)[3],lf[231],((C_word*)t0)[2],t1);}

/* k6914 in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6916,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6893 in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k6889 in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 543  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[256]+1)))(5,*((C_word*)lf[256]+1),((C_word*)t0)[3],*((C_word*)lf[257]+1),((C_word*)t0)[2],t1);}

/* k6873 in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6883,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6887,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 544  last */
((C_proc3)C_retrieve_symbol_proc(lf[255]))(3,*((C_word*)lf[255]+1),t3,((C_word*)t0)[2]);}

/* k6885 in k6873 in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 544  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6782(3,t2,((C_word*)t0)[2],t1);}

/* k6881 in k6873 in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6883,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[93],t3));}

/* k6827 in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6823 in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6825,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[254],t2));}

/* k6806 in k6799 in walk in ##compiler#build-expression-tree in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6808,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6262(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6262,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6265,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6771,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 527  walk */
t9=((C_word*)t6)[1];
f_6265(3,t9,t8,t2);}

/* k6769 in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6774,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 528  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t2,lf[251],lf[252],((C_word*)((C_word*)t0)[2])[1]);}

/* k6772 in k6769 in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6265(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word *a;
loop:
a=C_alloc(11);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_6265,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
t4=t2;
t5=(C_word)C_a_i_list(&a,1,t4);
t6=t3;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[205],lf[215],t5,C_SCHEME_END_OF_LIST));}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
/* support.scm: 462  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t1,lf[218],t2);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[219]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[205],lf[219],t7,C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_eqp(t4,lf[220]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[221]));
if(C_truep(t7)){
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6324,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t8=(C_word)C_eqp(t4,lf[83]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6347,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6350,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t9))){
t12=(C_word)C_eqp(lf[225],C_retrieve(lf[226]));
if(C_truep(t12)){
t13=(C_word)C_i_integerp(t9);
t14=t11;
f_6350(t14,(C_word)C_i_not(t13));}
else{
t13=t11;
f_6350(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_6350(t12,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t4,lf[93]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_nullp(t10))){
/* support.scm: 482  walk */
t68=t1;
t69=t11;
t1=t68;
t2=t69;
c=3;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6400,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 483  unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[227]))(3,*((C_word*)lf[227]+1),t12,t10);}}
else{
t10=(C_word)C_eqp(t4,lf[118]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[228]));
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6454,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_caddr(t2);
/* support.scm: 487  walk */
t68=t14;
t69=t15;
t1=t68;
t2=t69;
c=3;
goto loop;}
else{
t12=(C_word)C_eqp(t4,lf[229]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_i_car(t2);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6494,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t14,a[5]=t1,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t13))){
t16=(C_word)C_i_car(t13);
t17=t15;
f_6494(t17,(C_word)C_eqp(lf[83],t16));}
else{
t16=t15;
f_6494(t16,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_eqp(t4,lf[230]);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t4,lf[231]));
if(C_truep(t14)){
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,1,t16);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6525,a[2]=t17,a[3]=t15,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t19=(C_word)C_i_cddr(t2);
/* map */
t20=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t18,((C_word*)((C_word*)t0)[3])[1],t19);}
else{
t15=(C_word)C_eqp(t4,lf[232]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,2,t16,C_SCHEME_TRUE);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_record(&a,4,lf[205],lf[232],t17,C_SCHEME_END_OF_LIST));}
else{
t16=(C_word)C_eqp(t4,lf[233]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t4,lf[234]));
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_a_i_list(&a,1,t18);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6567,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(C_word)C_i_cddr(t2);
/* map */
t22=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t20,((C_word*)((C_word*)t0)[3])[1],t21);}
else{
t18=(C_word)C_eqp(t4,lf[235]);
if(C_truep(t18)){
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_i_cadr(t19);
t21=(C_word)C_i_caddr(t2);
t22=(C_word)C_i_cadr(t21);
t23=(C_word)C_i_cadddr(t2);
t24=(C_word)C_i_cadr(t23);
t25=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6620,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t24,a[6]=t22,a[7]=t20,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 506  fifth */
((C_proc3)C_retrieve_symbol_proc(lf[237]))(3,*((C_word*)lf[237]+1),t25,t2);}
else{
t19=(C_word)C_eqp(t4,lf[238]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6641,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_6641(t21,t19);}
else{
t21=(C_word)C_eqp(t4,lf[246]);
if(C_truep(t21)){
t22=t20;
f_6641(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[247]);
if(C_truep(t22)){
t23=t20;
f_6641(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[248]);
t24=t20;
f_6641(t24,(C_truep(t23)?t23:(C_word)C_eqp(t4,lf[249])));}}}}}}}}}}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6761,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t2);}}}}

/* k6759 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6761,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],lf[240],lf[250],t1));}

/* k6639 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_6641(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6641,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6650,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* map */
t6=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[239]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6666,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6678,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a6683 in k6639 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6684,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6698,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=t2;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6721,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t6,t5,lf[245]);}

/* k6719 in a6683 in k6639 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_6698(t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
f_6698(t2,C_SCHEME_FALSE);}}

/* k6696 in a6683 in k6639 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_6698(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6698,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6702,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 522  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),t3,((C_word*)t0)[2]);}
else{
/* support.scm: 524  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),t2,((C_word*)t0)[2]);}}

/* k6703 in k6696 in a6683 in k6639 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6712,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6712(2,t3,t1);}
else{
/* support.scm: 523  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),t2,((C_word*)t0)[2]);}}

/* k6710 in k6703 in k6696 in a6683 in k6639 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6712,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6702(2,t2,(C_word)C_a_i_list(&a,3,C_retrieve(lf[242]),((C_word*)t0)[2],t1));}

/* k6700 in k6696 in a6683 in k6639 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6702,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6691,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k6689 in k6700 in k6696 in a6683 in k6639 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6691,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],lf[240],((C_word*)t0)[2],t1));}

/* a6677 in k6639 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6678,2,t0,t1);}
/* support.scm: 514  get-line-2 */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t1,((C_word*)t0)[2]);}

/* k6664 in k6639 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6666,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],lf[240],lf[241],t1));}

/* k6648 in k6639 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6650,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6618 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6620,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6600,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6604,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 507  sixth */
((C_proc3)C_retrieve_symbol_proc(lf[236]))(3,*((C_word*)lf[236]+1),t5,((C_word*)t0)[2]);}

/* k6602 in k6618 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 507  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6265(3,t2,((C_word*)t0)[2],t1);}

/* k6598 in k6618 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6600,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[205],lf[235],((C_word*)t0)[2],t2));}

/* k6565 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6567,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],lf[233],((C_word*)t0)[2],t1));}

/* k6523 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6525,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6492 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_6494(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6494,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[6]):((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6480,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k6478 in k6492 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6480,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6452 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6454,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[205],lf[118],((C_word*)t0)[2],t2));}

/* k6398 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6403,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a6419 in k6398 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6420,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* support.scm: 484  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6265(3,t4,t1,t3);}

/* k6408 in k6398 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6418,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 485  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6265(3,t3,t2,((C_word*)t0)[2]);}

/* k6416 in k6408 in k6398 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6418,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* support.scm: 484  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[55]+1)))(4,*((C_word*)lf[55]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6401 in k6398 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6403,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],lf[93],((C_word*)t0)[2],t1));}

/* k6348 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_6350(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6350,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 473  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[20]))(5,*((C_word*)lf[20]+1),t2,lf[223],lf[224],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_6347(t2,((C_word*)t0)[2]);}}

/* k6351 in k6348 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6360,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 476  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[222]+1)))(3,*((C_word*)lf[222]+1),t2,((C_word*)t0)[2]);}

/* k6358 in k6351 in k6348 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6347(t2,(C_word)C_i_inexact_to_exact(t1));}

/* k6345 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_6347(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6347,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_list(&a,1,t1);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[205],lf[83],t3,C_SCHEME_END_OF_LIST));}

/* k6322 in walk in ##compiler#build-node-graph in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6324,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[205],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1));}

/* ##compiler#qnode in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6253(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6253,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[205],lf[83],t3,C_SCHEME_END_OF_LIST));}

/* ##compiler#varnode in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6244(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6244,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[205],lf[215],t3,C_SCHEME_END_OF_LIST));}

/* make-node in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6238,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* node-subexpressions in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6229,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[205]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* node-subexpressions-set! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6220,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[205]);
/* ##sys#block-set! */
t5=*((C_word*)lf[208]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-parameters in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6211(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6211,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[205]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* node-parameters-set! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6202,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[205]);
/* ##sys#block-set! */
t5=*((C_word*)lf[208]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-class in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6193,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[205]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* node-class-set! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6184,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[205]);
/* ##sys#block-set! */
t5=*((C_word*)lf[208]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node? in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6178(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6178,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[205]));}

/* f_6172 in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6172,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[205],t2,t3,t4));}

/* ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5724(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5724,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5728,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_5728(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6170,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 392  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[55]+1)))(5,*((C_word*)lf[55]+1),t4,C_retrieve(lf[202]),C_retrieve(lf[203]),C_retrieve(lf[128]));}}

/* k6168 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_6170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5728(t3,t2);}

/* k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_5728(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5728,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5733,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 395  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5733,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5743,a[2]=t3,a[3]=t9,a[4]=t7,a[5]=t5,a[6]=t13,a[7]=t11,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 403  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[201]+1)))(3,*((C_word*)lf[201]+1),t14,t2);}}

/* k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5746,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5861,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_5861(t6,t2,((C_word*)t0)[2]);}

/* loop in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_5861(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5861,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 407  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5869 in loop in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5874,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[160]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t3)){
t5=t4;
f_5887(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[181]);
if(C_truep(t5)){
t6=t4;
f_5887(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[182]);
if(C_truep(t6)){
t7=t4;
f_5887(t7,t6);}
else{
t7=(C_word)C_eqp(t1,lf[183]);
if(C_truep(t7)){
t8=t4;
f_5887(t8,t7);}
else{
t8=(C_word)C_eqp(t1,lf[184]);
if(C_truep(t8)){
t9=t4;
f_5887(t9,t8);}
else{
t9=(C_word)C_eqp(t1,lf[185]);
if(C_truep(t9)){
t10=t4;
f_5887(t10,t9);}
else{
t10=(C_word)C_eqp(t1,lf[186]);
if(C_truep(t10)){
t11=t4;
f_5887(t11,t10);}
else{
t11=(C_word)C_eqp(t1,lf[187]);
if(C_truep(t11)){
t12=t4;
f_5887(t12,t11);}
else{
t12=(C_word)C_eqp(t1,lf[188]);
if(C_truep(t12)){
t13=t4;
f_5887(t13,t12);}
else{
t13=(C_word)C_eqp(t1,lf[189]);
if(C_truep(t13)){
t14=t4;
f_5887(t14,t13);}
else{
t14=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t14)){
t15=t4;
f_5887(t15,t14);}
else{
t15=(C_word)C_eqp(t1,lf[191]);
if(C_truep(t15)){
t16=t4;
f_5887(t16,t15);}
else{
t16=(C_word)C_eqp(t1,lf[192]);
if(C_truep(t16)){
t17=t4;
f_5887(t17,t16);}
else{
t17=(C_word)C_eqp(t1,lf[193]);
if(C_truep(t17)){
t18=t4;
f_5887(t18,t17);}
else{
t18=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t18)){
t19=t4;
f_5887(t19,t18);}
else{
t19=(C_word)C_eqp(t1,lf[195]);
if(C_truep(t19)){
t20=t4;
f_5887(t20,t19);}
else{
t20=(C_word)C_eqp(t1,lf[196]);
if(C_truep(t20)){
t21=t4;
f_5887(t21,t20);}
else{
t21=(C_word)C_eqp(t1,lf[197]);
if(C_truep(t21)){
t22=t4;
f_5887(t22,t21);}
else{
t22=(C_word)C_eqp(t1,lf[198]);
if(C_truep(t22)){
t23=t4;
f_5887(t23,t22);}
else{
t23=(C_word)C_eqp(t1,lf[199]);
t24=t4;
f_5887(t24,(C_truep(t23)?t23:(C_word)C_eqp(t1,lf[200])));}}}}}}}}}}}}}}}}}}}}

/* k5885 in k5869 in loop in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_5887(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5887,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5902,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 411  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[159]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,lf[159]);
t4=((C_word*)t0)[9];
f_5874(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[164]);
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],lf[159]);
if(C_truep(t4)){
t5=((C_word*)t0)[9];
f_5874(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5925,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 415  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t5,((C_word*)t0)[8]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[166]);
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],lf[159]);
if(C_truep(t5)){
t6=((C_word*)t0)[9];
f_5874(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5941,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 417  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t6,((C_word*)t0)[8]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[167]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5951,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 419  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t6,((C_word*)t0)[8]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[168]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_5960(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[7],lf[173]);
if(C_truep(t8)){
t9=t7;
f_5960(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[7],lf[174]);
if(C_truep(t9)){
t10=t7;
f_5960(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[7],lf[147]);
if(C_truep(t10)){
t11=t7;
f_5960(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[7],lf[175]);
if(C_truep(t11)){
t12=t7;
f_5960(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[7],lf[176]);
if(C_truep(t12)){
t13=t7;
f_5960(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[7],lf[177]);
if(C_truep(t13)){
t14=t7;
f_5960(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[7],lf[178]);
if(C_truep(t14)){
t15=t7;
f_5960(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[7],lf[179]);
t16=t7;
f_5960(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[7],lf[180])));}}}}}}}}}}}}}}

/* k5958 in k5885 in k5869 in loop in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_5960(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5960,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5967,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 422  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[170]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5981,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 424  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[171]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5991,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 426  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* support.scm: 427  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[6],lf[172],t4);}}}}

/* k5989 in k5958 in k5885 in k5869 in loop in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5874(2,t3,t2);}

/* k5979 in k5958 in k5885 in k5869 in loop in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5874(2,t3,t2);}

/* k5965 in k5958 in k5885 in k5869 in loop in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5971,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 422  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[165]+1)))(3,*((C_word*)lf[165]+1),t2,((C_word*)t0)[2]);}

/* k5969 in k5965 in k5958 in k5885 in k5869 in loop in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 422  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[169],((C_word*)t0)[2],t1);}

/* k5949 in k5885 in k5869 in loop in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5874(2,t3,t2);}

/* k5939 in k5885 in k5869 in loop in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5874(2,t3,t2);}

/* k5923 in k5885 in k5869 in loop in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5874(2,t3,t2);}

/* k5900 in k5885 in k5869 in loop in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(t1,lf[161]);
t3=(C_word)C_i_cdr(t2);
/* support.scm: 411  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[162],t3);}

/* k5872 in k5869 in loop in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 428  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5861(t3,((C_word*)t0)[2],t2);}

/* k5744 in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5749,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[159]);
t5=t3;
f_5781(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5781(t4,C_SCHEME_FALSE);}}

/* k5779 in k5744 in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_5781(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5781,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[5])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* support.scm: 430  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[4],lf[156],t6);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5802,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[159]);
t4=t2;
f_5802(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5802(t3,C_SCHEME_FALSE);}}}

/* k5800 in k5779 in k5744 in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_5802(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5802,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[5])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* support.scm: 432  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[4],lf[157],t6);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5823,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[159]);
t4=t2;
f_5823(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5823(t3,C_SCHEME_FALSE);}}}

/* k5821 in k5800 in k5779 in k5744 in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_5823(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5823,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[3])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* support.scm: 434  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[158],t6);}
else{
t2=((C_word*)t0)[2];
f_5749(2,t2,C_SCHEME_UNDEFINED);}}

/* k5747 in k5744 in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5752,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 435  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[155],t3);}
else{
t3=t2;
f_5752(2,t3,C_SCHEME_UNDEFINED);}}

/* k5750 in k5747 in k5744 in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5755,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(C_word)C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm: 436  printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,lf[154],t3);}
else{
t3=t2;
f_5755(2,t3,C_SCHEME_UNDEFINED);}}

/* k5753 in k5750 in k5747 in k5744 in k5741 in a5732 in k5726 in ##compiler#display-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 437  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5711,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 374  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t1,t2,C_retrieve(lf[144]));}

/* a5710 in ##compiler#display-line-number-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5711,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5722,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[151]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5720 in a5710 in ##compiler#display-line-number-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 376  printf */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[149],((C_word*)t0)[2],t1);}

/* ##compiler#find-lambda-container in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5681,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5687,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5687(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_5687(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5687,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5697,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 370  get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t4,((C_word*)t0)[2],t2,lf[147]);}}

/* k5695 in loop in ##compiler#find-lambda-container in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 371  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5687(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5645,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5652,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 362  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t4,C_retrieve(lf[144]),t3);}

/* k5650 in ##compiler#get-line-2 in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5655,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cdr(t1);
t4=t2;
f_5655(t4,(C_word)C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_5655(t3,C_SCHEME_FALSE);}}

/* k5653 in k5650 in ##compiler#get-line-2 in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_5655(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t1);
/* support.scm: 364  values */
C_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
/* support.scm: 365  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* ##compiler#get-line in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5635(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5635,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* support.scm: 358  get */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t1,C_retrieve(lf[144]),t3,t2);}

/* ##compiler#count! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5578(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_5578r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5578r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5578r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5582,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 346  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t6,t2,t3);}

/* k5580 in ##compiler#count! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5582,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5612,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 351  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* support.scm: 352  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[140]))(5,*((C_word*)lf[140]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k5610 in k5580 in ##compiler#count! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5526,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5530,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 338  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t6,t2,t3);}

/* k5528 in ##compiler#collect! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5530,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5557,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 342  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 343  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[140]))(5,*((C_word*)lf[140]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k5555 in k5528 in ##compiler#collect! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5480,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5484,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 330  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t6,t2,t3);}

/* k5482 in ##compiler#put! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5484,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5506,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t1,C_fix(1));
/* support.scm: 334  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* support.scm: 335  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[140]))(5,*((C_word*)lf[140]+1),((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k5504 in k5482 in ##compiler#put! in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5462(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_5462r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5462r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5462r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5466,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 324  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t5,t2,t3);}

/* k5464 in ##compiler#get-all in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5466,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5474,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 326  filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a5473 in k5464 in ##compiler#get-all in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5474(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5474,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5444,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5448,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 318  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t5,t2,t3);}

/* k5446 in ##compiler#get in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5261,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5265,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5375,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve(lf[134]));}
else{
t3=t2;
f_5261(2,t3,C_SCHEME_UNDEFINED);}}

/* a5374 in ##compiler#initialize-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5375(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5375,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5406,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_list(&a,1,lf[133]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5381,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
t7=t6;
f_5381(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_5381(2,t8,(C_word)C_i_car(t5));}
else{
/* ##sys#error */
t8=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}

/* k5379 in a5374 in ##compiler#initialize-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[126],t1);}

/* k5404 in a5374 in ##compiler#initialize-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5406,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[3],C_retrieve(lf[129])))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5417,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5417(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5417(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5415 in k5404 in a5374 in ##compiler#initialize-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[130],t1);}

/* k5263 in ##compiler#initialize-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5268,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5306,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[132]));}

/* a5305 in k5263 in ##compiler#initialize-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5306,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5337,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_list(&a,1,lf[131]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5312,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
t7=t6;
f_5312(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_5312(2,t8,(C_word)C_i_car(t5));}
else{
/* ##sys#error */
t8=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}

/* k5310 in a5305 in k5263 in ##compiler#initialize-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[126],t1);}

/* k5335 in a5305 in k5263 in ##compiler#initialize-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5337,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[3],C_retrieve(lf[129])))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5348,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5348(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5348(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5346 in k5335 in a5305 in k5263 in ##compiler#initialize-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[130],t1);}

/* k5266 in k5263 in ##compiler#initialize-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5273,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[128]));}

/* a5272 in k5266 in k5263 in ##compiler#initialize-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5273(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5273,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[124]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5279,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5279(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5279(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5277 in a5272 in k5266 in k5263 in ##compiler#initialize-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[126],t1);}

/* k5259 in ##compiler#initialize-analysis-database in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#expand-profile-lambda in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5116,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[114]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5120,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 278  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t6);}

/* k5118 in ##compiler#expand-profile-lambda in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5124,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 279  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[115]));}

/* k5122 in k5118 in ##compiler#expand-profile-lambda in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5124,2,t0,t1);}
t2=C_mutate((C_word*)lf[115]+1 /* (set! profile-lambda-list ...) */,t1);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[114]+1 /* (set! profile-lambda-index ...) */,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[83],t5);
t7=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[116]),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[117],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[118],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[118],t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t15,t16);
t18=(C_word)C_a_i_cons(&a,2,lf[119],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t19);
t21=(C_word)C_a_i_cons(&a,2,lf[118],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[83],t22);
t24=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[116]),C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t23,t24);
t26=(C_word)C_a_i_cons(&a,2,lf[120],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[118],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t21,t30);
t32=(C_word)C_a_i_cons(&a,2,t12,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[121],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t34);
t36=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t36+1)))(2,t36,(C_word)C_a_i_cons(&a,2,lf[118],t35));}

/* ##compiler#llist-length in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5113(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5113,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_length(t2));}

/* ##compiler#process-lambda-documentation in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5110,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* ##compiler#string->expr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5003,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5010,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[108]+1)))(3,*((C_word*)lf[108]+1),t3,t4);}

/* a5011 in ##compiler#string->expr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5012,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5018,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5043,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t1,t3,t4);}

/* a5042 in a5011 in ##compiler#string->expr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5049,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5097,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a5096 in a5042 in a5011 in ##compiler#string->expr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5097(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_5097r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5097r(t0,t1,t2);}}

static void C_ccall f_5097r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5103,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k576582 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a5102 in a5096 in a5042 in a5011 in ##compiler#string->expr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5103,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a5048 in a5042 in a5011 in ##compiler#string->expr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5053,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5081,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 260  with-input-from-string */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t2,((C_word*)t0)[2],t3);}

/* a5080 in a5048 in a5042 in a5011 in ##compiler#string->expr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5087,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5095,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 260  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[102]+1)))(2,*((C_word*)lf[102]+1),t3);}

/* k5093 in a5080 in a5048 in a5042 in a5011 in ##compiler#string->expr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 260  unfold */
((C_proc6)C_retrieve_symbol_proc(lf[103]))(6,*((C_word*)lf[103]+1),((C_word*)t0)[3],*((C_word*)lf[104]+1),*((C_word*)lf[105]+1),((C_word*)t0)[2],t1);}

/* a5086 in a5080 in a5048 in a5042 in a5011 in ##compiler#string->expr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5087,3,t0,t1,t2);}
/* support.scm: 260  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[102]+1)))(2,*((C_word*)lf[102]+1),t1);}

/* k5051 in a5048 in a5042 in a5011 in ##compiler#string->expr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5053,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[99]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5075,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t4=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_END_OF_LIST);}}}

/* k5073 in k5051 in a5048 in a5042 in a5011 in ##compiler#string->expr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5075,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[100],t1));}

/* a5017 in a5011 in ##compiler#string->expr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5018,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5024,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* k576582 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a5023 in a5017 in a5011 in ##compiler#string->expr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5032,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5035,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 257  exn? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k5033 in a5023 in a5017 in a5011 in ##compiler#string->expr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 258  exn-msg */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* support.scm: 259  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[63]))(3,*((C_word*)lf[63]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5030 in a5023 in a5017 in a5011 in ##compiler#string->expr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 255  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],lf[98],((C_word*)t0)[2],t1);}

/* k5008 in ##compiler#string->expr in k5000 in k4997 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_5010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#canonicalize-begin-body in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4902,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4908,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4908(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_4908(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4908,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[91]);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_equalp(t4,lf[92]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4936,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_4936(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4985,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 244  constant? */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),t7,t4);}}}}

/* k4983 in loop in ##compiler#canonicalize-begin-body in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4936(t2,(C_truep(t1)?t1:(C_word)C_i_equalp(((C_word*)t0)[2],lf[96])));}

/* k4934 in loop in ##compiler#canonicalize-begin-body in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_4936(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4936,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 246  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4908(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4974,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 247  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),t2,lf[95]);}}

/* k4972 in k4934 in loop in ##compiler#canonicalize-begin-body in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4974,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4962,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 248  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4908(t8,t6,t7);}

/* k4960 in k4972 in k4934 in loop in ##compiler#canonicalize-begin-body in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4962,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[93],t3));}

/* ##compiler#basic-literal? in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4842,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4858,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 229  constant? */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),t5,t2);}}}

/* k4856 in ##compiler#basic-literal? in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4858,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4900,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 230  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[89]+1)))(3,*((C_word*)lf[89]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4864(2,t3,C_SCHEME_FALSE);}}}

/* k4898 in k4856 in ##compiler#basic-literal? in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 230  every */
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),((C_word*)t0)[2],C_retrieve(lf[87]),t1);}

/* k4862 in k4856 in ##compiler#basic-literal? in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4864,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4879,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* support.scm: 232  basic-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[87]))(3,*((C_word*)lf[87]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k4877 in k4862 in k4856 in ##compiler#basic-literal? in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 233  basic-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[87]))(3,*((C_word*)lf[87]+1),((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4796(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4796,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4800,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4840,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 219  big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),t4,t2);}
else{
t4=t3;
f_4800(t4,C_SCHEME_FALSE);}}

/* k4838 in ##compiler#immediate? in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4800(t2,(C_word)C_i_not(t1));}

/* k4798 in ##compiler#immediate? in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_4800(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:(C_word)C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4766,3,t0,t1,t2);}
t3=(C_word)C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4720(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4720,3,t0,t1,t2);}
t3=(C_word)C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(lf[83],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#sort-symbols in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4700,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4706,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 198  sort */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t1,t2,t3);}

/* a4705 in ##compiler#sort-symbols in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4706,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4714,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 198  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t4,t2);}

/* k4712 in a4705 in ##compiler#sort-symbols in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4718,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 198  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}

/* k4716 in k4712 in a4705 in ##compiler#sort-symbols in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 198  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[80]+1)))(4,*((C_word*)lf[80]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#follow-without-loop in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4669,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4675,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4675(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_4675(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4675,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_member(t2,t3))){
/* support.scm: 194  abort */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4690,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 195  proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a4689 in loop in ##compiler#follow-without-loop in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4690(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4690,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* support.scm: 195  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4675(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4606,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4620,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 184  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t5,t3);}}

/* k4618 in ##compiler#fold-inner in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4620,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4622,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4622(t5,((C_word*)t0)[2],t1);}

/* fold in k4618 in ##compiler#fold-inner in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_4622(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4622,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4630,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_car(t2);
t7=t3;
f_4630(t7,(C_word)C_a_i_list(&a,2,t5,t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4651,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* support.scm: 189  fold */
t10=t5;
t11=t6;
t1=t10;
t2=t11;
goto loop;}}

/* k4649 in fold in k4618 in ##compiler#fold-inner in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4651,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4630(t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k4628 in fold in k4618 in ##compiler#fold-inner in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_4630(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#close-checked-input-file in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4594,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_string_equal_p(t3,lf[74]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 179  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[75]+1)))(3,*((C_word*)lf[75]+1),t1,t2);}}

/* ##compiler#check-and-open-input-file in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4547(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4547r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4547r(t0,t1,t2,t3);}}

static void C_ccall f_4547r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_string_equal_p(t2,lf[67]))){
/* support.scm: 173  current-input-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[68]+1)))(2,*((C_word*)lf[68]+1),t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4563,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 174  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),t4,t2);}}

/* k4561 in ##compiler#check-and-open-input-file in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4563,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 174  open-input-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[69]+1)))(3,*((C_word*)lf[69]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_4575(t4,t2);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4575(t5,(C_word)C_i_not(t4));}}}

/* k4573 in k4561 in ##compiler#check-and-open-input-file in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_4575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 175  quit */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),((C_word*)t0)[4],lf[70],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* support.scm: 176  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[4],lf[71],((C_word*)t0)[3],t2);}}

/* ##compiler#words->bytes in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4540(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4540,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub334(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4533,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub329(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4477,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4481,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4531,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 154  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[63]))(3,*((C_word*)lf[63]+1),t4,t2);}

/* k4529 in ##compiler#valid-c-identifier? in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[57]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4479 in ##compiler#valid-c-identifier? in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4481,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4504,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_cdr(t1);
/* support.scm: 158  any */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4503 in k4479 in ##compiler#valid-c-identifier? in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4504(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4504,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4383(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4383,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4395,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4399,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=C_retrieve(lf[57]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4397 in ##compiler#c-ify-string in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4399,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4401,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4401(t5,((C_word*)t0)[2],t1);}

/* loop in k4397 in ##compiler#c-ify-string in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_4401(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4401,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[54]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4423,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_4423(t7,t5);}
else{
t7=(C_word)C_fixnum_greater_or_equal_p(t4,C_fix(127));
t8=t6;
f_4423(t8,(C_truep(t7)?t7:(C_word)C_i_memq(t3,lf[60])));}}}

/* k4421 in loop in k4397 in ##compiler#c-ify-string in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_4423(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4423,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4430,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_4430(t3,lf[58]);}
else{
t3=(C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_4430(t4,(C_truep(t3)?lf[59]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 151  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4401(t4,t2,t3);}}

/* k4460 in k4421 in loop in k4397 in ##compiler#c-ify-string in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4462,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4428 in k4421 in loop in k4397 in ##compiler#c-ify-string in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_4430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4430,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4434,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4446,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 149  number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k4444 in k4428 in k4421 in loop in k4397 in ##compiler#c-ify-string in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[57]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4432 in k4428 in k4421 in loop in k4397 in ##compiler#c-ify-string in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4438,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 150  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4401(t4,t2,t3);}

/* k4436 in k4432 in k4428 in k4421 in loop in k4397 in ##compiler#c-ify-string in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 145  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[55]+1)))(6,*((C_word*)lf[55]+1),((C_word*)t0)[4],lf[56],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4393 in ##compiler#c-ify-string in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4395,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=C_retrieve(lf[53]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4339,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4345,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4345(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_4345(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4345,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4369,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_decrease(t3);
/* support.scm: 131  loop */
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k4367 in loop in ##compiler#build-lambda-list in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4369,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4314(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4314,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
/* support.scm: 125  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4337,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 126  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t3,lf[48],t2);}}}

/* k4335 in ##compiler#symbolify in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 126  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4293,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 120  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t1,t2);}
else{
/* support.scm: 121  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,lf[45],t2);}}}

/* ##compiler#posq in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4257,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4263,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4263(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static C_word C_fcall f_4263(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_fixnum_increase(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#check-signature in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4189,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4192,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4213,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4213(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_4213(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4213,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 104  err */
t4=((C_word*)t0)[3];
f_4192(t4,t1);}}
else{
t4=(C_word)C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* support.scm: 106  err */
t5=((C_word*)t0)[3];
f_4192(t5,t1);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
/* support.scm: 107  loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_4192(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4192,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4200,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 101  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),t2,((C_word*)t0)[2]);}

/* k4198 in err in ##compiler#check-signature in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4204,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 102  map-llist */
((C_proc4)C_retrieve_symbol_proc(lf[37]))(4,*((C_word*)lf[37]+1),t2,C_retrieve(lf[40]),t3);}

/* k4202 in k4198 in err in ##compiler#check-signature in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 100  quit */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],lf[39],((C_word*)t0)[2],t1);}

/* map-llist in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4146,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4152,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4152(t7,t1,t3);}

/* loop in map-llist in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_4152(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4152,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* support.scm: 95   proc */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4175,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 96   proc */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k4173 in loop in map-llist in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4179,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 96   loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4152(t4,t2,t3);}

/* k4177 in k4173 in loop in map-llist in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4179,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4143,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_emit_syntax_trace_info(t2,t3,C_retrieve(lf[30])));}

/* ##sys#syntax-error-hook in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4098(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4098r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4098r(t0,t1,t2,t3);}}

static void C_ccall f_4098r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4102,a[2]=t4,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 74   current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t6);}

/* k4100 in ##sys#syntax-error-hook in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)((C_word*)t0)[2])[1]))){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t2;
f_4105(t8,t3);}
else{
t3=t2;
f_4105(t3,C_SCHEME_FALSE);}}

/* k4103 in k4100 in ##sys#syntax-error-hook in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_4105(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4105,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4108,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
/* support.scm: 81   fprintf */
((C_proc6)C_retrieve_symbol_proc(lf[21]))(6,*((C_word*)lf[21]+1),t2,((C_word*)t0)[4],lf[33],t1,((C_word*)((C_word*)t0)[2])[1]);}
else{
/* support.scm: 82   fprintf */
((C_proc5)C_retrieve_symbol_proc(lf[21]))(5,*((C_word*)lf[21]+1),t2,((C_word*)t0)[4],lf[34],((C_word*)((C_word*)t0)[2])[1]);}}

/* k4106 in k4103 in k4100 in ##sys#syntax-error-hook in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4111,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4119,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a4118 in k4106 in k4103 in k4100 in ##sys#syntax-error-hook in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4119,3,t0,t1,t2);}
/* fprintf */
((C_proc5)C_retrieve_symbol_proc(lf[21]))(5,*((C_word*)lf[21]+1),t1,((C_word*)t0)[2],lf[32],t2);}

/* k4109 in k4106 in k4103 in k4100 in ##sys#syntax-error-hook in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4114,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 84   print-call-chain */
((C_proc6)C_retrieve_symbol_proc(lf[29]))(6,*((C_word*)lf[29]+1),t2,((C_word*)t0)[2],C_fix(0),C_retrieve(lf[30]),lf[31]);}

/* k4112 in k4109 in k4106 in k4103 in k4100 in ##sys#syntax-error-hook in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 85   exit */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),((C_word*)t0)[2],C_fix(70));}

/* quit in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4079(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4079r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4079r(t0,t1,t2,t3);}}

static void C_ccall f_4079r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4083,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 67   current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t4);}

/* k4081 in quit in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4086,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4096,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 68   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[27],((C_word*)t0)[2]);}

/* k4094 in k4081 in quit in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[21]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4084 in k4081 in quit in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4089,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 69   newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,((C_word*)t0)[2]);}

/* k4087 in k4084 in k4081 in quit in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 70   exit */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),((C_word*)t0)[2],C_fix(1));}

/* ##compiler#compiler-warning in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4050r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4050r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4050r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4057,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[24]))){
t6=(C_word)C_i_memq(t2,C_retrieve(lf[4]));
t7=t5;
f_4057(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_4057(t6,C_SCHEME_FALSE);}}

/* k4055 in ##compiler#compiler-warning in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_fcall f_4057(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4057,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 62   current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t2);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4058 in k4055 in ##compiler#compiler-warning in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4063,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 63   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[22],((C_word*)t0)[2]);}

/* k4068 in k4058 in k4055 in ##compiler#compiler-warning in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[21]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4061 in k4058 in k4055 in ##compiler#compiler-warning in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 64   newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_4010r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4010r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4010r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[3])))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4020,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 51   printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t5,lf[19],t3);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k4018 in ##compiler#debugging in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4023,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4035,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 54   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),t3,lf[18]);}
else{
t3=t2;
f_4023(2,t3,C_SCHEME_UNDEFINED);}}

/* k4033 in k4018 in ##compiler#debugging in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4040,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a4039 in k4033 in k4018 in ##compiler#debugging in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4040(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4040,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4048,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 55   force */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t3,t2);}

/* k4046 in a4039 in k4033 in k4018 in ##compiler#debugging in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 55   printf */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[14],t1);}

/* k4021 in k4018 in ##compiler#debugging in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4026,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 56   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),t2);}

/* k4024 in k4021 in k4018 in ##compiler#debugging in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4029,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 57   flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[11]+1)))(2,*((C_word*)lf[11]+1),t2);}

/* k4027 in k4024 in k4021 in k4018 in ##compiler#debugging in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_3983(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3983r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3983r(t0,t1,t2);}}

static void C_ccall f_3983r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3997,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* support.scm: 45   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[8],t4);}
else{
/* support.scm: 46   error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t1,lf[9]);}}

/* k3995 in ##compiler#bomb in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[6]+1),t1,t2);}

/* ##compiler#compiler-cleanup-hook in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3978,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[548] = {
{"toplevel:support_scm",(void*)C_support_toplevel},
{"f_3959:support_scm",(void*)f_3959},
{"f_3962:support_scm",(void*)f_3962},
{"f_3965:support_scm",(void*)f_3965},
{"f_3968:support_scm",(void*)f_3968},
{"f_3971:support_scm",(void*)f_3971},
{"f_3974:support_scm",(void*)f_3974},
{"f_4999:support_scm",(void*)f_4999},
{"f_5002:support_scm",(void*)f_5002},
{"f_11492:support_scm",(void*)f_11492},
{"f_11496:support_scm",(void*)f_11496},
{"f_11555:support_scm",(void*)f_11555},
{"f_11502:support_scm",(void*)f_11502},
{"f_11508:support_scm",(void*)f_11508},
{"f_11548:support_scm",(void*)f_11548},
{"f_11513:support_scm",(void*)f_11513},
{"f_11529:support_scm",(void*)f_11529},
{"f_11525:support_scm",(void*)f_11525},
{"f_11481:support_scm",(void*)f_11481},
{"f_11486:support_scm",(void*)f_11486},
{"f_11470:support_scm",(void*)f_11470},
{"f_11475:support_scm",(void*)f_11475},
{"f_11464:support_scm",(void*)f_11464},
{"f_11436:support_scm",(void*)f_11436},
{"f_11440:support_scm",(void*)f_11440},
{"f_11415:support_scm",(void*)f_11415},
{"f_11419:support_scm",(void*)f_11419},
{"f_11382:support_scm",(void*)f_11382},
{"f_11388:support_scm",(void*)f_11388},
{"f_11349:support_scm",(void*)f_11349},
{"f_11355:support_scm",(void*)f_11355},
{"f_11325:support_scm",(void*)f_11325},
{"f_11256:support_scm",(void*)f_11256},
{"f_11260:support_scm",(void*)f_11260},
{"f_11265:support_scm",(void*)f_11265},
{"f_11269:support_scm",(void*)f_11269},
{"f_11320:support_scm",(void*)f_11320},
{"f_11299:support_scm",(void*)f_11299},
{"f_11311:support_scm",(void*)f_11311},
{"f_11314:support_scm",(void*)f_11314},
{"f_11287:support_scm",(void*)f_11287},
{"f_11223:support_scm",(void*)f_11223},
{"f_11233:support_scm",(void*)f_11233},
{"f_11236:support_scm",(void*)f_11236},
{"f_11136:support_scm",(void*)f_11136},
{"f_11145:support_scm",(void*)f_11145},
{"f_11158:support_scm",(void*)f_11158},
{"f_11164:support_scm",(void*)f_11164},
{"f_11217:support_scm",(void*)f_11217},
{"f_11167:support_scm",(void*)f_11167},
{"f_11182:support_scm",(void*)f_11182},
{"f_11190:support_scm",(void*)f_11190},
{"f_11200:support_scm",(void*)f_11200},
{"f_11185:support_scm",(void*)f_11185},
{"f_11173:support_scm",(void*)f_11173},
{"f_11140:support_scm",(void*)f_11140},
{"f_11130:support_scm",(void*)f_11130},
{"f_11112:support_scm",(void*)f_11112},
{"f_11066:support_scm",(void*)f_11066},
{"f_11085:support_scm",(void*)f_11085},
{"f_11096:support_scm",(void*)f_11096},
{"f_11092:support_scm",(void*)f_11092},
{"f_11054:support_scm",(void*)f_11054},
{"f_11060:support_scm",(void*)f_11060},
{"f_11042:support_scm",(void*)f_11042},
{"f_11046:support_scm",(void*)f_11046},
{"f_10963:support_scm",(void*)f_10963},
{"f_10982:support_scm",(void*)f_10982},
{"f_11007:support_scm",(void*)f_11007},
{"f_11011:support_scm",(void*)f_11011},
{"f_11013:support_scm",(void*)f_11013},
{"f_11020:support_scm",(void*)f_11020},
{"f_11033:support_scm",(void*)f_11033},
{"f_11037:support_scm",(void*)f_11037},
{"f_10966:support_scm",(void*)f_10966},
{"f_10970:support_scm",(void*)f_10970},
{"f_10976:support_scm",(void*)f_10976},
{"f_10957:support_scm",(void*)f_10957},
{"f_10913:support_scm",(void*)f_10913},
{"f_10925:support_scm",(void*)f_10925},
{"f_10929:support_scm",(void*)f_10929},
{"f_10933:support_scm",(void*)f_10933},
{"f_10921:support_scm",(void*)f_10921},
{"f_10904:support_scm",(void*)f_10904},
{"f_10898:support_scm",(void*)f_10898},
{"f_10892:support_scm",(void*)f_10892},
{"f_10880:support_scm",(void*)f_10880},
{"f_10884:support_scm",(void*)f_10884},
{"f_10887:support_scm",(void*)f_10887},
{"f_10842:support_scm",(void*)f_10842},
{"f_10846:support_scm",(void*)f_10846},
{"f_10849:support_scm",(void*)f_10849},
{"f_10856:support_scm",(void*)f_10856},
{"f_10800:support_scm",(void*)f_10800},
{"f_10809:support_scm",(void*)f_10809},
{"f_10771:support_scm",(void*)f_10771},
{"f_10781:support_scm",(void*)f_10781},
{"f_10599:support_scm",(void*)f_10599},
{"f_10766:support_scm",(void*)f_10766},
{"f_10753:support_scm",(void*)f_10753},
{"f_10759:support_scm",(void*)f_10759},
{"f_10602:support_scm",(void*)f_10602},
{"f_10621:support_scm",(void*)f_10621},
{"f_10715:support_scm",(void*)f_10715},
{"f_10727:support_scm",(void*)f_10727},
{"f_10685:support_scm",(void*)f_10685},
{"f_10696:support_scm",(void*)f_10696},
{"f_10676:support_scm",(void*)f_10676},
{"f_10662:support_scm",(void*)f_10662},
{"f_10640:support_scm",(void*)f_10640},
{"f_10646:support_scm",(void*)f_10646},
{"f_10650:support_scm",(void*)f_10650},
{"f_10521:support_scm",(void*)f_10521},
{"f_10527:support_scm",(void*)f_10527},
{"f_10582:support_scm",(void*)f_10582},
{"f_10555:support_scm",(void*)f_10555},
{"f_10549:support_scm",(void*)f_10549},
{"f_10525:support_scm",(void*)f_10525},
{"f_10223:support_scm",(void*)f_10223},
{"f_10422:support_scm",(void*)f_10422},
{"f_10443:support_scm",(void*)f_10443},
{"f_9907:support_scm",(void*)f_9907},
{"f_10217:support_scm",(void*)f_10217},
{"f_9919:support_scm",(void*)f_9919},
{"f_9929:support_scm",(void*)f_9929},
{"f_9947:support_scm",(void*)f_9947},
{"f_9981:support_scm",(void*)f_9981},
{"f_9910:support_scm",(void*)f_9910},
{"f_9582:support_scm",(void*)f_9582},
{"f_9901:support_scm",(void*)f_9901},
{"f_9588:support_scm",(void*)f_9588},
{"f_9598:support_scm",(void*)f_9598},
{"f_9607:support_scm",(void*)f_9607},
{"f_9619:support_scm",(void*)f_9619},
{"f_9631:support_scm",(void*)f_9631},
{"f_9637:support_scm",(void*)f_9637},
{"f_9671:support_scm",(void*)f_9671},
{"f_9542:support_scm",(void*)f_9542},
{"f_9576:support_scm",(void*)f_9576},
{"f_9548:support_scm",(void*)f_9548},
{"f_9552:support_scm",(void*)f_9552},
{"f_9511:support_scm",(void*)f_9511},
{"f_9524:support_scm",(void*)f_9524},
{"f_9515:support_scm",(void*)f_9515},
{"f_9480:support_scm",(void*)f_9480},
{"f_9493:support_scm",(void*)f_9493},
{"f_9484:support_scm",(void*)f_9484},
{"f_8427:support_scm",(void*)f_8427},
{"f_9474:support_scm",(void*)f_9474},
{"f_8433:support_scm",(void*)f_8433},
{"f_8439:support_scm",(void*)f_8439},
{"f_8468:support_scm",(void*)f_8468},
{"f_8487:support_scm",(void*)f_8487},
{"f_8506:support_scm",(void*)f_8506},
{"f_8576:support_scm",(void*)f_8576},
{"f_8595:support_scm",(void*)f_8595},
{"f_8677:support_scm",(void*)f_8677},
{"f_8716:support_scm",(void*)f_8716},
{"f_8735:support_scm",(void*)f_8735},
{"f_8754:support_scm",(void*)f_8754},
{"f_8834:support_scm",(void*)f_8834},
{"f_8919:support_scm",(void*)f_8919},
{"f_8994:support_scm",(void*)f_8994},
{"f_9028:support_scm",(void*)f_9028},
{"f_9098:support_scm",(void*)f_9098},
{"f_9031:support_scm",(void*)f_9031},
{"f_8837:support_scm",(void*)f_8837},
{"f_8868:support_scm",(void*)f_8868},
{"f_8757:support_scm",(void*)f_8757},
{"f_8598:support_scm",(void*)f_8598},
{"f_8629:support_scm",(void*)f_8629},
{"f_8509:support_scm",(void*)f_8509},
{"f_8540:support_scm",(void*)f_8540},
{"f_8391:support_scm",(void*)f_8391},
{"f_8395:support_scm",(void*)f_8395},
{"f_8406:support_scm",(void*)f_8406},
{"f_8412:support_scm",(void*)f_8412},
{"f_8416:support_scm",(void*)f_8416},
{"f_8398:support_scm",(void*)f_8398},
{"f_8352:support_scm",(void*)f_8352},
{"f_8364:support_scm",(void*)f_8364},
{"f_8371:support_scm",(void*)f_8371},
{"f_8374:support_scm",(void*)f_8374},
{"f_8377:support_scm",(void*)f_8377},
{"f_8380:support_scm",(void*)f_8380},
{"f_8383:support_scm",(void*)f_8383},
{"f_8386:support_scm",(void*)f_8386},
{"f_8358:support_scm",(void*)f_8358},
{"f_8272:support_scm",(void*)f_8272},
{"f_8281:support_scm",(void*)f_8281},
{"f_8287:support_scm",(void*)f_8287},
{"f_8276:support_scm",(void*)f_8276},
{"f_8251:support_scm",(void*)f_8251},
{"f_8261:support_scm",(void*)f_8261},
{"f_8212:support_scm",(void*)f_8212},
{"f_8218:support_scm",(void*)f_8218},
{"f_8242:support_scm",(void*)f_8242},
{"f_8231:support_scm",(void*)f_8231},
{"f_8185:support_scm",(void*)f_8185},
{"f_8191:support_scm",(void*)f_8191},
{"f_8201:support_scm",(void*)f_8201},
{"f_8154:support_scm",(void*)f_8154},
{"f_8160:support_scm",(void*)f_8160},
{"f_8167:support_scm",(void*)f_8167},
{"f_8170:support_scm",(void*)f_8170},
{"f_8062:support_scm",(void*)f_8062},
{"f_8086:support_scm",(void*)f_8086},
{"f_7976:support_scm",(void*)f_7976},
{"f_7982:support_scm",(void*)f_7982},
{"f_7998:support_scm",(void*)f_7998},
{"f_8012:support_scm",(void*)f_8012},
{"f_8020:support_scm",(void*)f_8020},
{"f_7781:support_scm",(void*)f_7781},
{"f_7960:support_scm",(void*)f_7960},
{"f_7966:support_scm",(void*)f_7966},
{"f_7856:support_scm",(void*)f_7856},
{"f_7878:support_scm",(void*)f_7878},
{"f_7891:support_scm",(void*)f_7891},
{"f_7922:support_scm",(void*)f_7922},
{"f_7813:support_scm",(void*)f_7813},
{"f_7835:support_scm",(void*)f_7835},
{"f_7784:support_scm",(void*)f_7784},
{"f_7808:support_scm",(void*)f_7808},
{"f_7712:support_scm",(void*)f_7712},
{"f_7718:support_scm",(void*)f_7718},
{"f_7724:support_scm",(void*)f_7724},
{"f_7728:support_scm",(void*)f_7728},
{"f_7775:support_scm",(void*)f_7775},
{"f_7739:support_scm",(void*)f_7739},
{"f_7764:support_scm",(void*)f_7764},
{"f_7532:support_scm",(void*)f_7532},
{"f_7563:support_scm",(void*)f_7563},
{"f_7710:support_scm",(void*)f_7710},
{"f_7567:support_scm",(void*)f_7567},
{"f_7575:support_scm",(void*)f_7575},
{"f_7582:support_scm",(void*)f_7582},
{"f_7703:support_scm",(void*)f_7703},
{"f_7606:support_scm",(void*)f_7606},
{"f_7627:support_scm",(void*)f_7627},
{"f_7684:support_scm",(void*)f_7684},
{"f_7639:support_scm",(void*)f_7639},
{"f_7642:support_scm",(void*)f_7642},
{"f_7660:support_scm",(void*)f_7660},
{"f_7649:support_scm",(void*)f_7649},
{"f_7570:support_scm",(void*)f_7570},
{"f_7536:support_scm",(void*)f_7536},
{"f_7542:support_scm",(void*)f_7542},
{"f_7555:support_scm",(void*)f_7555},
{"f_7547:support_scm",(void*)f_7547},
{"f_7507:support_scm",(void*)f_7507},
{"f_7513:support_scm",(void*)f_7513},
{"f_7523:support_scm",(void*)f_7523},
{"f_7471:support_scm",(void*)f_7471},
{"f_7477:support_scm",(void*)f_7477},
{"f_7501:support_scm",(void*)f_7501},
{"f_7497:support_scm",(void*)f_7497},
{"f_7447:support_scm",(void*)f_7447},
{"f_7451:support_scm",(void*)f_7451},
{"f_7454:support_scm",(void*)f_7454},
{"f_7457:support_scm",(void*)f_7457},
{"f_7413:support_scm",(void*)f_7413},
{"f_7419:support_scm",(void*)f_7419},
{"f_7433:support_scm",(void*)f_7433},
{"f_7437:support_scm",(void*)f_7437},
{"f_7235:support_scm",(void*)f_7235},
{"f_7239:support_scm",(void*)f_7239},
{"f_7247:support_scm",(void*)f_7247},
{"f_7396:support_scm",(void*)f_7396},
{"f_7404:support_scm",(void*)f_7404},
{"f_7399:support_scm",(void*)f_7399},
{"f_7348:support_scm",(void*)f_7348},
{"f_7352:support_scm",(void*)f_7352},
{"f_7355:support_scm",(void*)f_7355},
{"f_7374:support_scm",(void*)f_7374},
{"f_7390:support_scm",(void*)f_7390},
{"f_7382:support_scm",(void*)f_7382},
{"f_7366:support_scm",(void*)f_7366},
{"f_7361:support_scm",(void*)f_7361},
{"f_7315:support_scm",(void*)f_7315},
{"f_7318:support_scm",(void*)f_7318},
{"f_7329:support_scm",(void*)f_7329},
{"f_7324:support_scm",(void*)f_7324},
{"f_7299:support_scm",(void*)f_7299},
{"f_7291:support_scm",(void*)f_7291},
{"f_7286:support_scm",(void*)f_7286},
{"f_7270:support_scm",(void*)f_7270},
{"f_7241:support_scm",(void*)f_7241},
{"f_7142:support_scm",(void*)f_7142},
{"f_7148:support_scm",(void*)f_7148},
{"f_7160:support_scm",(void*)f_7160},
{"f_7164:support_scm",(void*)f_7164},
{"f_7167:support_scm",(void*)f_7167},
{"f_7227:support_scm",(void*)f_7227},
{"f_7203:support_scm",(void*)f_7203},
{"f_7186:support_scm",(void*)f_7186},
{"f_7190:support_scm",(void*)f_7190},
{"f_7172:support_scm",(void*)f_7172},
{"f_7154:support_scm",(void*)f_7154},
{"f_7094:support_scm",(void*)f_7094},
{"f_7100:support_scm",(void*)f_7100},
{"f_7120:support_scm",(void*)f_7120},
{"f_7124:support_scm",(void*)f_7124},
{"f_6776:support_scm",(void*)f_6776},
{"f_6782:support_scm",(void*)f_6782},
{"f_6801:support_scm",(void*)f_6801},
{"f_7035:support_scm",(void*)f_7035},
{"f_7065:support_scm",(void*)f_7065},
{"f_7061:support_scm",(void*)f_7061},
{"f_7042:support_scm",(void*)f_7042},
{"f_7046:support_scm",(void*)f_7046},
{"f_6973:support_scm",(void*)f_6973},
{"f_7022:support_scm",(void*)f_7022},
{"f_6991:support_scm",(void*)f_6991},
{"f_6999:support_scm",(void*)f_6999},
{"f_6949:support_scm",(void*)f_6949},
{"f_6916:support_scm",(void*)f_6916},
{"f_6895:support_scm",(void*)f_6895},
{"f_6891:support_scm",(void*)f_6891},
{"f_6875:support_scm",(void*)f_6875},
{"f_6887:support_scm",(void*)f_6887},
{"f_6883:support_scm",(void*)f_6883},
{"f_6829:support_scm",(void*)f_6829},
{"f_6825:support_scm",(void*)f_6825},
{"f_6808:support_scm",(void*)f_6808},
{"f_6262:support_scm",(void*)f_6262},
{"f_6771:support_scm",(void*)f_6771},
{"f_6774:support_scm",(void*)f_6774},
{"f_6265:support_scm",(void*)f_6265},
{"f_6761:support_scm",(void*)f_6761},
{"f_6641:support_scm",(void*)f_6641},
{"f_6684:support_scm",(void*)f_6684},
{"f_6721:support_scm",(void*)f_6721},
{"f_6698:support_scm",(void*)f_6698},
{"f_6705:support_scm",(void*)f_6705},
{"f_6712:support_scm",(void*)f_6712},
{"f_6702:support_scm",(void*)f_6702},
{"f_6691:support_scm",(void*)f_6691},
{"f_6678:support_scm",(void*)f_6678},
{"f_6666:support_scm",(void*)f_6666},
{"f_6650:support_scm",(void*)f_6650},
{"f_6620:support_scm",(void*)f_6620},
{"f_6604:support_scm",(void*)f_6604},
{"f_6600:support_scm",(void*)f_6600},
{"f_6567:support_scm",(void*)f_6567},
{"f_6525:support_scm",(void*)f_6525},
{"f_6494:support_scm",(void*)f_6494},
{"f_6480:support_scm",(void*)f_6480},
{"f_6454:support_scm",(void*)f_6454},
{"f_6400:support_scm",(void*)f_6400},
{"f_6420:support_scm",(void*)f_6420},
{"f_6410:support_scm",(void*)f_6410},
{"f_6418:support_scm",(void*)f_6418},
{"f_6403:support_scm",(void*)f_6403},
{"f_6350:support_scm",(void*)f_6350},
{"f_6353:support_scm",(void*)f_6353},
{"f_6360:support_scm",(void*)f_6360},
{"f_6347:support_scm",(void*)f_6347},
{"f_6324:support_scm",(void*)f_6324},
{"f_6253:support_scm",(void*)f_6253},
{"f_6244:support_scm",(void*)f_6244},
{"f_6238:support_scm",(void*)f_6238},
{"f_6229:support_scm",(void*)f_6229},
{"f_6220:support_scm",(void*)f_6220},
{"f_6211:support_scm",(void*)f_6211},
{"f_6202:support_scm",(void*)f_6202},
{"f_6193:support_scm",(void*)f_6193},
{"f_6184:support_scm",(void*)f_6184},
{"f_6178:support_scm",(void*)f_6178},
{"f_6172:support_scm",(void*)f_6172},
{"f_5724:support_scm",(void*)f_5724},
{"f_6170:support_scm",(void*)f_6170},
{"f_5728:support_scm",(void*)f_5728},
{"f_5733:support_scm",(void*)f_5733},
{"f_5743:support_scm",(void*)f_5743},
{"f_5861:support_scm",(void*)f_5861},
{"f_5871:support_scm",(void*)f_5871},
{"f_5887:support_scm",(void*)f_5887},
{"f_5960:support_scm",(void*)f_5960},
{"f_5991:support_scm",(void*)f_5991},
{"f_5981:support_scm",(void*)f_5981},
{"f_5967:support_scm",(void*)f_5967},
{"f_5971:support_scm",(void*)f_5971},
{"f_5951:support_scm",(void*)f_5951},
{"f_5941:support_scm",(void*)f_5941},
{"f_5925:support_scm",(void*)f_5925},
{"f_5902:support_scm",(void*)f_5902},
{"f_5874:support_scm",(void*)f_5874},
{"f_5746:support_scm",(void*)f_5746},
{"f_5781:support_scm",(void*)f_5781},
{"f_5802:support_scm",(void*)f_5802},
{"f_5823:support_scm",(void*)f_5823},
{"f_5749:support_scm",(void*)f_5749},
{"f_5752:support_scm",(void*)f_5752},
{"f_5755:support_scm",(void*)f_5755},
{"f_5705:support_scm",(void*)f_5705},
{"f_5711:support_scm",(void*)f_5711},
{"f_5722:support_scm",(void*)f_5722},
{"f_5681:support_scm",(void*)f_5681},
{"f_5687:support_scm",(void*)f_5687},
{"f_5697:support_scm",(void*)f_5697},
{"f_5645:support_scm",(void*)f_5645},
{"f_5652:support_scm",(void*)f_5652},
{"f_5655:support_scm",(void*)f_5655},
{"f_5635:support_scm",(void*)f_5635},
{"f_5578:support_scm",(void*)f_5578},
{"f_5582:support_scm",(void*)f_5582},
{"f_5612:support_scm",(void*)f_5612},
{"f_5526:support_scm",(void*)f_5526},
{"f_5530:support_scm",(void*)f_5530},
{"f_5557:support_scm",(void*)f_5557},
{"f_5480:support_scm",(void*)f_5480},
{"f_5484:support_scm",(void*)f_5484},
{"f_5506:support_scm",(void*)f_5506},
{"f_5462:support_scm",(void*)f_5462},
{"f_5466:support_scm",(void*)f_5466},
{"f_5474:support_scm",(void*)f_5474},
{"f_5444:support_scm",(void*)f_5444},
{"f_5448:support_scm",(void*)f_5448},
{"f_5257:support_scm",(void*)f_5257},
{"f_5375:support_scm",(void*)f_5375},
{"f_5381:support_scm",(void*)f_5381},
{"f_5406:support_scm",(void*)f_5406},
{"f_5417:support_scm",(void*)f_5417},
{"f_5265:support_scm",(void*)f_5265},
{"f_5306:support_scm",(void*)f_5306},
{"f_5312:support_scm",(void*)f_5312},
{"f_5337:support_scm",(void*)f_5337},
{"f_5348:support_scm",(void*)f_5348},
{"f_5268:support_scm",(void*)f_5268},
{"f_5273:support_scm",(void*)f_5273},
{"f_5279:support_scm",(void*)f_5279},
{"f_5261:support_scm",(void*)f_5261},
{"f_5116:support_scm",(void*)f_5116},
{"f_5120:support_scm",(void*)f_5120},
{"f_5124:support_scm",(void*)f_5124},
{"f_5113:support_scm",(void*)f_5113},
{"f_5110:support_scm",(void*)f_5110},
{"f_5003:support_scm",(void*)f_5003},
{"f_5012:support_scm",(void*)f_5012},
{"f_5043:support_scm",(void*)f_5043},
{"f_5097:support_scm",(void*)f_5097},
{"f_5103:support_scm",(void*)f_5103},
{"f_5049:support_scm",(void*)f_5049},
{"f_5081:support_scm",(void*)f_5081},
{"f_5095:support_scm",(void*)f_5095},
{"f_5087:support_scm",(void*)f_5087},
{"f_5053:support_scm",(void*)f_5053},
{"f_5075:support_scm",(void*)f_5075},
{"f_5018:support_scm",(void*)f_5018},
{"f_5024:support_scm",(void*)f_5024},
{"f_5035:support_scm",(void*)f_5035},
{"f_5032:support_scm",(void*)f_5032},
{"f_5010:support_scm",(void*)f_5010},
{"f_4902:support_scm",(void*)f_4902},
{"f_4908:support_scm",(void*)f_4908},
{"f_4985:support_scm",(void*)f_4985},
{"f_4936:support_scm",(void*)f_4936},
{"f_4974:support_scm",(void*)f_4974},
{"f_4962:support_scm",(void*)f_4962},
{"f_4842:support_scm",(void*)f_4842},
{"f_4858:support_scm",(void*)f_4858},
{"f_4900:support_scm",(void*)f_4900},
{"f_4864:support_scm",(void*)f_4864},
{"f_4879:support_scm",(void*)f_4879},
{"f_4796:support_scm",(void*)f_4796},
{"f_4840:support_scm",(void*)f_4840},
{"f_4800:support_scm",(void*)f_4800},
{"f_4766:support_scm",(void*)f_4766},
{"f_4720:support_scm",(void*)f_4720},
{"f_4700:support_scm",(void*)f_4700},
{"f_4706:support_scm",(void*)f_4706},
{"f_4714:support_scm",(void*)f_4714},
{"f_4718:support_scm",(void*)f_4718},
{"f_4669:support_scm",(void*)f_4669},
{"f_4675:support_scm",(void*)f_4675},
{"f_4690:support_scm",(void*)f_4690},
{"f_4606:support_scm",(void*)f_4606},
{"f_4620:support_scm",(void*)f_4620},
{"f_4622:support_scm",(void*)f_4622},
{"f_4651:support_scm",(void*)f_4651},
{"f_4630:support_scm",(void*)f_4630},
{"f_4594:support_scm",(void*)f_4594},
{"f_4547:support_scm",(void*)f_4547},
{"f_4563:support_scm",(void*)f_4563},
{"f_4575:support_scm",(void*)f_4575},
{"f_4540:support_scm",(void*)f_4540},
{"f_4533:support_scm",(void*)f_4533},
{"f_4477:support_scm",(void*)f_4477},
{"f_4531:support_scm",(void*)f_4531},
{"f_4481:support_scm",(void*)f_4481},
{"f_4504:support_scm",(void*)f_4504},
{"f_4383:support_scm",(void*)f_4383},
{"f_4399:support_scm",(void*)f_4399},
{"f_4401:support_scm",(void*)f_4401},
{"f_4423:support_scm",(void*)f_4423},
{"f_4462:support_scm",(void*)f_4462},
{"f_4430:support_scm",(void*)f_4430},
{"f_4446:support_scm",(void*)f_4446},
{"f_4434:support_scm",(void*)f_4434},
{"f_4438:support_scm",(void*)f_4438},
{"f_4395:support_scm",(void*)f_4395},
{"f_4339:support_scm",(void*)f_4339},
{"f_4345:support_scm",(void*)f_4345},
{"f_4369:support_scm",(void*)f_4369},
{"f_4314:support_scm",(void*)f_4314},
{"f_4337:support_scm",(void*)f_4337},
{"f_4293:support_scm",(void*)f_4293},
{"f_4257:support_scm",(void*)f_4257},
{"f_4263:support_scm",(void*)f_4263},
{"f_4189:support_scm",(void*)f_4189},
{"f_4213:support_scm",(void*)f_4213},
{"f_4192:support_scm",(void*)f_4192},
{"f_4200:support_scm",(void*)f_4200},
{"f_4204:support_scm",(void*)f_4204},
{"f_4146:support_scm",(void*)f_4146},
{"f_4152:support_scm",(void*)f_4152},
{"f_4175:support_scm",(void*)f_4175},
{"f_4179:support_scm",(void*)f_4179},
{"f_4143:support_scm",(void*)f_4143},
{"f_4098:support_scm",(void*)f_4098},
{"f_4102:support_scm",(void*)f_4102},
{"f_4105:support_scm",(void*)f_4105},
{"f_4108:support_scm",(void*)f_4108},
{"f_4119:support_scm",(void*)f_4119},
{"f_4111:support_scm",(void*)f_4111},
{"f_4114:support_scm",(void*)f_4114},
{"f_4079:support_scm",(void*)f_4079},
{"f_4083:support_scm",(void*)f_4083},
{"f_4096:support_scm",(void*)f_4096},
{"f_4086:support_scm",(void*)f_4086},
{"f_4089:support_scm",(void*)f_4089},
{"f_4050:support_scm",(void*)f_4050},
{"f_4057:support_scm",(void*)f_4057},
{"f_4060:support_scm",(void*)f_4060},
{"f_4070:support_scm",(void*)f_4070},
{"f_4063:support_scm",(void*)f_4063},
{"f_4010:support_scm",(void*)f_4010},
{"f_4020:support_scm",(void*)f_4020},
{"f_4035:support_scm",(void*)f_4035},
{"f_4040:support_scm",(void*)f_4040},
{"f_4048:support_scm",(void*)f_4048},
{"f_4023:support_scm",(void*)f_4023},
{"f_4026:support_scm",(void*)f_4026},
{"f_4029:support_scm",(void*)f_4029},
{"f_3983:support_scm",(void*)f_3983},
{"f_3997:support_scm",(void*)f_3997},
{"f_3978:support_scm",(void*)f_3978},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
