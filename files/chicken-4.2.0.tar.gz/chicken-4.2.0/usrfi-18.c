/* Generated from srfi-18.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:27
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: srfi-18.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file usrfi-18.c
   unit: srfi_18
*/

#include "chicken.h"

static C_TLS long C_ms;
#define C_get_seconds   C_seconds(&C_ms)

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[111];
static double C_possibly_force_alignment;


C_noret_decl(C_srfi_18_toplevel)
C_externexport void C_ccall C_srfi_18_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_679)
static void C_ccall f_679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_682)
static void C_ccall f_682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_948)
static void C_ccall f_948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2072)
static void C_ccall f_2072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_fcall f_2014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1691)
static void C_ccall f_1691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1706)
static void C_ccall f_1706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1709)
static void C_ccall f_1709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1442)
static void C_ccall f_1442(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1442)
static void C_ccall f_1442r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1517)
static void C_fcall f_1517(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1520)
static void C_ccall f_1520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1639)
static void C_ccall f_1639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_fcall f_1493(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1472)
static void C_fcall f_1472(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1483)
static void C_ccall f_1483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1400)
static void C_ccall f_1400(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1391)
static void C_ccall f_1391(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1367)
static void C_ccall f_1367(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1355)
static void C_ccall f_1355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1362)
static void C_ccall f_1362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1305)
static void C_ccall f_1305(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1290)
static void C_ccall f_1290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1299)
static void C_ccall f_1299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1228)
static void C_ccall f_1228(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1270)
static void C_ccall f_1270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1235)
static void C_ccall f_1235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1244)
static void C_ccall f_1244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1100)
static void C_ccall f_1100(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1100)
static void C_ccall f_1100r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1107)
static void C_ccall f_1107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1125)
static void C_ccall f_1125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1136)
static void C_ccall f_1136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1194)
static void C_ccall f_1194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1149)
static void C_ccall f_1149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1064)
static void C_ccall f_1064(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1094)
static void C_ccall f_1094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1068)
static void C_fcall f_1068(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1071)
static void C_ccall f_1071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1039)
static void C_ccall f_1039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1030)
static void C_ccall f_1030(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1021)
static void C_ccall f_1021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1012)
static void C_ccall f_1012(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1003)
static void C_ccall f_1003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_950)
static void C_ccall f_950(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_950)
static void C_ccall f_950r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_954)
static void C_ccall f_954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_972)
static void C_ccall f_972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_930)
static void C_ccall f_930(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_914)
static void C_ccall f_914(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_898)
static void C_ccall f_898(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_882)
static void C_ccall f_882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_874)
static void C_ccall f_874(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_858)
static void C_ccall f_858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_804)
static void C_ccall f_804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_811)
static void C_ccall f_811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_852)
static void C_ccall f_852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_848)
static void C_ccall f_848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_814)
static void C_ccall f_814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_832)
static void C_ccall f_832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_824)
static void C_ccall f_824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_775)
static void C_ccall f_775(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_754)
static void C_ccall f_754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_727)
static void C_ccall f_727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_739)
static void C_ccall f_739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_684)
static void C_fcall f_684(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_718)
static void C_ccall f_718(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2014)
static void C_fcall trf_2014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2014(t0,t1);}

C_noret_decl(trf_1517)
static void C_fcall trf_1517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1517(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1517(t0,t1);}

C_noret_decl(trf_1493)
static void C_fcall trf_1493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1493(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1493(t0,t1);}

C_noret_decl(trf_1472)
static void C_fcall trf_1472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1472(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1472(t0,t1);}

C_noret_decl(trf_1068)
static void C_fcall trf_1068(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1068(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1068(t0,t1);}

C_noret_decl(trf_684)
static void C_fcall trf_684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_684(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_684(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_18_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_18_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_18_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1095)){
C_save(t1);
C_rereclaim2(1095*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,111);
lf[0]=C_h_intern(&lf[0],8,"truncate");
lf[2]=C_h_intern(&lf[2],4,"time");
lf[3]=C_h_intern(&lf[3],15,"\003syssignal-hook");
lf[4]=C_h_intern(&lf[4],11,"\000type-error");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid timeout argument");
lf[6]=C_h_intern(&lf[6],12,"current-time");
lf[7]=C_h_intern(&lf[7],20,"srfi-18:current-time");
lf[8]=C_h_intern(&lf[8],13,"time->seconds");
lf[9]=C_h_intern(&lf[9],18,"time->milliseconds");
lf[10]=C_h_intern(&lf[10],13,"seconds->time");
lf[11]=C_h_intern(&lf[11],19,"\003sysflonum-fraction");
lf[12]=C_h_intern(&lf[12],18,"\003sysexact->inexact");
lf[13]=C_h_intern(&lf[13],3,"max");
lf[14]=C_h_intern(&lf[14],18,"milliseconds->time");
lf[15]=C_h_intern(&lf[15],5,"time\077");
lf[16]=C_h_intern(&lf[16],13,"srfi-18:time\077");
lf[17]=C_h_intern(&lf[17],5,"raise");
lf[18]=C_h_intern(&lf[18],10,"\003syssignal");
lf[19]=C_h_intern(&lf[19],23,"join-timeout-exception\077");
lf[20]=C_h_intern(&lf[20],9,"condition");
lf[21]=C_h_intern(&lf[21],22,"join-timeout-exception");
lf[22]=C_h_intern(&lf[22],26,"abandoned-mutex-exception\077");
lf[23]=C_h_intern(&lf[23],25,"abandoned-mutex-exception");
lf[24]=C_h_intern(&lf[24],28,"terminated-thread-exception\077");
lf[25]=C_h_intern(&lf[25],27,"terminated-thread-exception");
lf[26]=C_h_intern(&lf[26],19,"uncaught-exception\077");
lf[27]=C_h_intern(&lf[27],18,"uncaught-exception");
lf[28]=C_h_intern(&lf[28],25,"uncaught-exception-reason");
lf[29]=C_h_intern(&lf[29],6,"gensym");
lf[30]=C_h_intern(&lf[30],11,"make-thread");
lf[31]=C_h_intern(&lf[31],12,"\003sysschedule");
lf[32]=C_h_intern(&lf[32],16,"\003systhread-kill!");
lf[33]=C_h_intern(&lf[33],4,"dead");
lf[34]=C_h_intern(&lf[34],18,"\003syscurrent-thread");
lf[35]=C_h_intern(&lf[35],15,"\003sysmake-thread");
lf[36]=C_h_intern(&lf[36],7,"created");
lf[37]=C_h_intern(&lf[37],6,"thread");
lf[38]=C_h_intern(&lf[38],7,"thread\077");
lf[39]=C_h_intern(&lf[39],14,"current-thread");
lf[40]=C_h_intern(&lf[40],12,"thread-state");
lf[41]=C_h_intern(&lf[41],15,"thread-specific");
lf[42]=C_h_intern(&lf[42],20,"thread-specific-set!");
lf[43]=C_h_intern(&lf[43],14,"thread-quantum");
lf[44]=C_h_intern(&lf[44],19,"thread-quantum-set!");
lf[45]=C_h_intern(&lf[45],11,"thread-name");
lf[46]=C_h_intern(&lf[46],13,"thread-start!");
lf[47]=C_h_intern(&lf[47],5,"ready");
lf[48]=C_h_intern(&lf[48],22,"\003sysadd-to-ready-queue");
lf[49]=C_h_intern(&lf[49],9,"\003syserror");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000&thread cannot be started a second time");
lf[51]=C_h_intern(&lf[51],13,"thread-yield!");
lf[52]=C_h_intern(&lf[52],17,"\003systhread-yield!");
lf[53]=C_h_intern(&lf[53],12,"thread-join!");
lf[54]=C_h_intern(&lf[54],28,"\003sysremove-from-timeout-list");
lf[55]=C_h_intern(&lf[55],10,"terminated");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022uncaught-exception\376\001\000\000\006reason");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022uncaught-exception\376\377\016");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\026join-timeout-exception\376\377\016");
lf[59]=C_h_intern(&lf[59],33,"\003systhread-block-for-termination!");
lf[60]=C_h_intern(&lf[60],29,"\003systhread-block-for-timeout!");
lf[61]=C_h_intern(&lf[61],17,"thread-terminate!");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\033terminated-thread-exception\376\377\016");
lf[63]=C_h_intern(&lf[63],21,"\003sysprimordial-thread");
lf[64]=C_h_intern(&lf[64],16,"\003sysexit-handler");
lf[65]=C_h_intern(&lf[65],15,"thread-suspend!");
lf[66]=C_h_intern(&lf[66],9,"suspended");
lf[67]=C_h_intern(&lf[67],14,"thread-resume!");
lf[68]=C_h_intern(&lf[68],13,"thread-sleep!");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid timeout argument");
lf[70]=C_h_intern(&lf[70],6,"mutex\077");
lf[71]=C_h_intern(&lf[71],5,"mutex");
lf[72]=C_h_intern(&lf[72],10,"make-mutex");
lf[73]=C_h_intern(&lf[73],14,"\003sysmake-mutex");
lf[74]=C_h_intern(&lf[74],10,"mutex-name");
lf[75]=C_h_intern(&lf[75],14,"mutex-specific");
lf[76]=C_h_intern(&lf[76],19,"mutex-specific-set!");
lf[77]=C_h_intern(&lf[77],11,"mutex-state");
lf[78]=C_h_intern(&lf[78],9,"not-owned");
lf[79]=C_h_intern(&lf[79],9,"abandoned");
lf[80]=C_h_intern(&lf[80],13,"not-abandoned");
lf[81]=C_h_intern(&lf[81],11,"mutex-lock!");
lf[82]=C_h_intern(&lf[82],10,"\003sysappend");
lf[83]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\031abandoned-mutex-exception\376\377\016");
lf[84]=C_h_intern(&lf[84],8,"\003sysdelq");
lf[85]=C_h_intern(&lf[85],8,"sleeping");
lf[86]=C_h_intern(&lf[86],13,"mutex-unlock!");
lf[87]=C_h_intern(&lf[87],18,"condition-variable");
lf[88]=C_h_intern(&lf[88],7,"blocked");
lf[89]=C_h_intern(&lf[89],23,"make-condition-variable");
lf[90]=C_h_intern(&lf[90],19,"condition-variable\077");
lf[91]=C_h_intern(&lf[91],27,"condition-variable-specific");
lf[92]=C_h_intern(&lf[92],32,"condition-variable-specific-set!");
lf[93]=C_h_intern(&lf[93],26,"condition-variable-signal!");
lf[94]=C_h_intern(&lf[94],25,"\003systhread-basic-unblock!");
lf[95]=C_h_intern(&lf[95],29,"condition-variable-broadcast!");
lf[96]=C_h_intern(&lf[96],12,"\003sysfor-each");
lf[97]=C_h_intern(&lf[97],14,"thread-signal!");
lf[98]=C_h_intern(&lf[98],19,"\003systhread-unblock!");
lf[99]=C_h_intern(&lf[99],20,"thread-wait-for-i/o!");
lf[100]=C_h_intern(&lf[100],4,"\000all");
lf[101]=C_h_intern(&lf[101],25,"\003systhread-block-for-i/o!");
lf[102]=C_h_intern(&lf[102],4,"msvc");
lf[103]=C_h_intern(&lf[103],20,"\003sysread-prompt-hook");
lf[104]=C_h_intern(&lf[104],13,"\003systty-port\077");
lf[105]=C_h_intern(&lf[105],18,"\003sysstandard-input");
lf[106]=C_h_intern(&lf[106],14,"build-platform");
lf[107]=C_h_intern(&lf[107],27,"condition-property-accessor");
lf[108]=C_h_intern(&lf[108],6,"reason");
lf[109]=C_h_intern(&lf[109],17,"register-feature!");
lf[110]=C_h_intern(&lf[110],7,"srfi-18");
C_register_lf2(lf,111,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_679,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k677 */
static void C_ccall f_679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_682,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 55   register-feature! */
t3=*((C_word*)lf[109]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[110]);}

/* k680 in k677 */
static void C_ccall f_682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_682,2,t0,t1);}
t2=*((C_word*)lf[0]+1);
t3=C_mutate(&lf[1] /* (set! compute-time-limit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_684,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[6]+1 /* (set! current-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_727,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[7]+1 /* (set! srfi-18:current-time ...) */,*((C_word*)lf[6]+1));
t6=C_mutate((C_word*)lf[8]+1 /* (set! time->seconds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_754,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[9]+1 /* (set! time->milliseconds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_775,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[10]+1 /* (set! seconds->time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_804,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[14]+1 /* (set! milliseconds->time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_858,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[15]+1 /* (set! time? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_874,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[16]+1 /* (set! srfi-18:time? ...) */,*((C_word*)lf[15]+1));
t12=C_mutate((C_word*)lf[17]+1 /* (set! raise ...) */,*((C_word*)lf[18]+1));
t13=C_mutate((C_word*)lf[19]+1 /* (set! join-timeout-exception? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_882,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[22]+1 /* (set! abandoned-mutex-exception? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_898,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[24]+1 /* (set! terminated-thread-exception? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_914,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[26]+1 /* (set! uncaught-exception? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_930,tmp=(C_word)a,a+=2,tmp));
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_948,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 145  condition-property-accessor */
t18=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,lf[27],lf[108]);}

/* k946 in k680 in k677 */
static void C_ccall f_948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[70],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_948,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1 /* (set! uncaught-exception-reason ...) */,t1);
t3=*((C_word*)lf[29]+1);
t4=C_mutate((C_word*)lf[30]+1 /* (set! make-thread ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_950,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[38]+1 /* (set! thread? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_994,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[39]+1 /* (set! current-thread ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1000,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[40]+1 /* (set! thread-state ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1003,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[41]+1 /* (set! thread-specific ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1012,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[42]+1 /* (set! thread-specific-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1021,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[43]+1 /* (set! thread-quantum ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1030,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[44]+1 /* (set! thread-quantum-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1039,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[45]+1 /* (set! thread-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1055,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[30]+1);
t14=C_mutate((C_word*)lf[46]+1 /* (set! thread-start! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1064,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[51]+1 /* (set! thread-yield! ...) */,*((C_word*)lf[52]+1));
t16=C_mutate((C_word*)lf[53]+1 /* (set! thread-join! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1100,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[61]+1 /* (set! thread-terminate! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1228,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[65]+1 /* (set! thread-suspend! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1272,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[67]+1 /* (set! thread-resume! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1305,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[68]+1 /* (set! thread-sleep! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1327,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[70]+1 /* (set! mutex? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1367,tmp=(C_word)a,a+=2,tmp));
t22=*((C_word*)lf[29]+1);
t23=C_mutate((C_word*)lf[72]+1 /* (set! make-mutex ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1373,a[2]=t22,tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[74]+1 /* (set! mutex-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1391,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[75]+1 /* (set! mutex-specific ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1400,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[76]+1 /* (set! mutex-specific-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1409,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[77]+1 /* (set! mutex-state ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1418,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[81]+1 /* (set! mutex-lock! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1442,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[86]+1 /* (set! mutex-unlock! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1666,tmp=(C_word)a,a+=2,tmp));
t30=*((C_word*)lf[29]+1);
t31=C_mutate((C_word*)lf[89]+1 /* (set! make-condition-variable ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1857,a[2]=t30,tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[90]+1 /* (set! condition-variable? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1876,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[91]+1 /* (set! condition-variable-specific ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1882,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[92]+1 /* (set! condition-variable-specific-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1891,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[93]+1 /* (set! condition-variable-signal! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1900,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[95]+1 /* (set! condition-variable-broadcast! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1943,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[97]+1 /* (set! thread-signal! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1980,tmp=(C_word)a,a+=2,tmp));
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2072,a[2]=t38,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 469  build-platform */
t40=*((C_word*)lf[106]+1);
((C_proc2)(void*)(*((C_word*)t40+1)))(2,t40,t39);}

/* k2070 in k946 in k680 in k677 */
static void C_ccall f_2072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2072,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[102]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_2014(t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[103]+1);
t4=*((C_word*)lf[51]+1);
t5=C_mutate((C_word*)lf[103]+1 /* (set! read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2046,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t0)[2];
f_2014(t6,t5);}}

/* ##sys#read-prompt-hook in k2070 in k946 in k680 in k677 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2046,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(12));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2056,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_2056(2,t4,t2);}
else{
/* srfi-18.scm: 474  ##sys#tty-port? */
t4=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[105]+1));}}

/* k2054 in ##sys#read-prompt-hook in k2070 in k946 in k680 in k677 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 475  old */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2057 in k2054 in ##sys#read-prompt-hook in k2070 in k946 in k680 in k677 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 476  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[34]+1),C_fix(0),C_SCHEME_TRUE);}

/* k2060 in k2057 in k2054 in ##sys#read-prompt-hook in k2070 in k946 in k680 in k677 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 477  thread-yield! */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2012 in k946 in k680 in k677 */
static void C_fcall f_2014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2014,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[99]+1 /* (set! thread-wait-for-i/o! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2016,tmp=(C_word)a,a+=2,tmp));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* thread-wait-for-i/o! in k2012 in k946 in k680 in k677 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2016r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2016r(t0,t1,t2,t3);}}

static void C_ccall f_2016r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(3);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?lf[100]:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t2,lf[99]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2026,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 484  ##sys#thread-block-for-i/o! */
t8=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,*((C_word*)lf[34]+1),t2,t5);}

/* k2024 in thread-wait-for-i/o! in k2012 in k946 in k680 in k677 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 485  thread-yield! */
t2=*((C_word*)lf[51]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* thread-signal! in k946 in k680 in k677 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1980,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[37],lf[97]);
t5=(C_word)C_eqp(t2,*((C_word*)lf[34]+1));
if(C_truep(t5)){
/* srfi-18.scm: 457  ##sys#signal */
t6=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2004,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_setslot(t2,C_fix(1),t7);
/* srfi-18.scm: 464  ##sys#thread-unblock! */
t9=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t2);}}

/* a2003 in thread-signal! in k946 in k680 in k677 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2008,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 462  ##sys#signal */
t3=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2006 in a2003 in thread-signal! in k946 in k680 in k677 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 463  old */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* condition-variable-broadcast! in k946 in k680 in k677 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1943,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[87],lf[95]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1950,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1955,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_slot(t2,C_fix(2));
/* srfi-18.scm: 443  ##sys#for-each */
t7=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}

/* a1954 in condition-variable-broadcast! in k946 in k680 in k677 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1955,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_eqp(t3,lf[88]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[85]));
if(C_truep(t5)){
/* srfi-18.scm: 447  ##sys#thread-basic-unblock! */
t6=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k1948 in condition-variable-broadcast! in k946 in k680 in k677 */
static void C_ccall f_1950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_SCHEME_END_OF_LIST));}

/* condition-variable-signal! in k946 in k680 in k677 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1900,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[87],lf[93]);
t4=(C_word)C_slot(t2,C_fix(2));
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(3));
t7=(C_word)C_slot(t4,C_fix(1));
t8=(C_word)C_i_setslot(t2,C_fix(2),t7);
t9=(C_word)C_eqp(t6,lf[88]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,lf[85]));
if(C_truep(t10)){
/* srfi-18.scm: 438  ##sys#thread-basic-unblock! */
t11=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t1,t5);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}}

/* condition-variable-specific-set! in k946 in k680 in k677 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1891,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[87],lf[92]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(3),t3));}

/* condition-variable-specific in k946 in k680 in k677 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1882,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[87],lf[91]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* condition-variable? in k946 in k680 in k677 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1876,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[87]));}

/* make-condition-variable in k946 in k680 in k677 */
static void C_ccall f_1857(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1857r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1857r(t0,t1,t2);}}

static void C_ccall f_1857r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1865,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_1865(2,t4,(C_word)C_slot(t2,C_fix(0)));}
else{
/* srfi-18.scm: 414  gensym */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[87]);}}

/* k1863 in make-condition-variable in k946 in k680 in k677 */
static void C_ccall f_1865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1865,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[87],t1,C_SCHEME_END_OF_LIST,C_SCHEME_UNDEFINED));}

/* mutex-unlock! in k946 in k680 in k677 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1666r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1666r(t0,t1,t2,t3);}}

static void C_ccall f_1666r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(6);
t4=(C_word)C_i_check_structure_2(t2,lf[71],lf[86]);
t5=*((C_word*)lf[34]+1);
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t8=(C_word)C_block_size(t3);
t9=(C_word)C_fixnum_greaterp(t8,C_fix(1));
t10=(C_truep(t9)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE);
t11=(C_truep(t7)?(C_word)C_i_check_structure_2(t7,lf[87],lf[86]):C_SCHEME_UNDEFINED);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1684,a[2]=t10,a[3]=t7,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-18.scm: 371  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t12);}

/* a1683 in mutex-unlock! in k946 in k680 in k677 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1684,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1691,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* srfi-18.scm: 374  ##sys#compute-time-limit */
t5=lf[1];
f_684(t5,t4,((C_word*)t0)[2]);}
else{
t5=t4;
f_1691(2,t5,C_SCHEME_FALSE);}}

/* k1689 in a1683 in mutex-unlock! in k946 in k680 in k677 */
static void C_ccall f_1691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1691,2,t0,t1);}
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[7],C_fix(4),C_SCHEME_FALSE);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[7],C_fix(5),C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1829,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(8));
/* srfi-18.scm: 378  ##sys#delq */
t6=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[7],t5);}

/* k1827 in k1689 in a1683 in mutex-unlock! in k946 in k680 in k677 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1829,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[8],C_fix(8),t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1821,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[8],C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1706,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1811,a[2]=t5,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
/* srfi-18.scm: 381  ##sys#append */
t9=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}
else{
t6=t5;
f_1706(2,t6,C_SCHEME_UNDEFINED);}}

/* k1809 in k1827 in k1689 in a1683 in mutex-unlock! in k946 in k680 in k677 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1811,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(2),t1);
if(C_truep(((C_word*)t0)[5])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1780,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t3);
/* srfi-18.scm: 390  ##sys#thread-block-for-timeout! */
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[2];
f_1706(2,t3,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(3),lf[85]));}}

/* a1779 in k1809 in k1827 in k1689 in a1683 in mutex-unlock! in k946 in k680 in k677 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1800,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
/* srfi-18.scm: 386  ##sys#delq */
t4=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k1798 in a1779 in k1809 in k1827 in k1689 in a1683 in mutex-unlock! in k946 in k680 in k677 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1800,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(2),t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1787,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[2],C_fix(13)))){
t4=t3;
f_1787(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-18.scm: 388  ##sys#remove-from-timeout-list */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k1785 in k1798 in a1779 in k1809 in k1827 in k1689 in a1683 in mutex-unlock! in k946 in k680 in k677 */
static void C_ccall f_1787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 389  return */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1704 in k1827 in k1689 in a1683 in mutex-unlock! in k946 in k680 in k677 */
static void C_ccall f_1706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1709,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t3=t2;
f_1709(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t6=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(3),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_SCHEME_TRUE);
t8=(C_word)C_eqp(t4,lf[88]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t4,lf[85]));
if(C_truep(t9)){
t10=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(2),t3);
t11=(C_word)C_slot(t3,C_fix(8));
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t11);
t13=(C_word)C_i_setslot(t3,C_fix(8),t12);
t14=(C_word)C_eqp(t4,lf[85]);
if(C_truep(t14)){
/* srfi-18.scm: 401  ##sys#add-to-ready-queue */
t15=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t2,t3);}
else{
t15=t2;
f_1709(2,t15,C_SCHEME_UNDEFINED);}}
else{
t10=t2;
f_1709(2,t10,C_SCHEME_UNDEFINED);}}}

/* k1707 in k1704 in k1827 in k1689 in a1683 in mutex-unlock! in k946 in k680 in k677 */
static void C_ccall f_1709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 402  ##sys#schedule */
t2=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1820 in k1827 in k1689 in a1683 in mutex-unlock! in k946 in k680 in k677 */
static void C_ccall f_1821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1821,2,t0,t1);}
/* srfi-18.scm: 379  return */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_TRUE);}

/* mutex-lock! in k946 in k680 in k677 */
static void C_ccall f_1442(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1442r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1442r(t0,t1,t2,t3);}}

static void C_ccall f_1442r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_structure_2(t2,lf[71],lf[81]);
t5=(C_word)C_notvemptyp(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1452,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=(C_word)C_slot(t3,C_fix(0));
/* srfi-18.scm: 315  ##sys#compute-time-limit */
t8=lf[1];
f_684(t8,t6,t7);}
else{
t7=t6;
f_1452(2,t7,C_SCHEME_FALSE);}}

/* k1450 in mutex-lock! in k946 in k680 in k677 */
static void C_ccall f_1452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1452,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1));
t4=(C_truep(t3)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
t6=(C_truep(t4)?(C_word)C_i_check_structure_2(t4,lf[37],lf[81]):C_SCHEME_UNDEFINED);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1469,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t5,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* srfi-18.scm: 320  ##sys#call-with-current-continuation */
C_call_cc(3,0,((C_word*)t0)[2],t7);}

/* a1468 in k1450 in mutex-lock! in k946 in k680 in k677 */
static void C_ccall f_1469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1469,3,t0,t1,t2);}
t3=*((C_word*)lf[34]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1472,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1493,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[6],C_fix(5)))){
if(C_truep(((C_word*)t0)[4])){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1579,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* srfi-18.scm: 346  check */
t7=t5;
f_1493(t7,t6);}
else{
t6=(C_word)C_i_setslot(t3,C_fix(3),lf[85]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1639,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_setslot(t3,C_fix(1),t7);
/* srfi-18.scm: 361  switch */
t9=t4;
f_1472(t9,t1);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1517,a[2]=t5,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_truep(((C_word*)t0)[2])?(C_word)C_i_not(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),C_SCHEME_FALSE);
t9=t6;
f_1517(t9,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(5),C_SCHEME_TRUE));}
else{
t8=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:t3);
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(lf[55],t9);
t11=(C_truep(t10)?t10:(C_word)C_eqp(lf[33],t9));
if(C_truep(t11)){
t12=t6;
f_1517(t12,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(4),C_SCHEME_TRUE));}
else{
t12=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(5),C_SCHEME_TRUE);
t13=(C_word)C_slot(t8,C_fix(8));
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t13);
t15=(C_word)C_i_setslot(t8,C_fix(8),t14);
t16=t6;
f_1517(t16,(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(2),t8));}}}}

/* k1515 in a1468 in k1450 in mutex-lock! in k946 in k680 in k677 */
static void C_fcall f_1517(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1517,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1520,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 343  check */
t3=((C_word*)t0)[2];
f_1493(t3,t2);}

/* k1518 in k1515 in a1468 in k1450 in mutex-lock! in k946 in k680 in k677 */
static void C_ccall f_1520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 344  return */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* a1638 in a1468 in k1450 in mutex-lock! in k946 in k680 in k677 */
static void C_ccall f_1639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1639,2,t0,t1);}
/* srfi-18.scm: 360  return */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_TRUE);}

/* k1577 in a1468 in k1450 in mutex-lock! in k946 in k680 in k677 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_setslot(((C_word*)t0)[7],C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 356  ##sys#thread-block-for-timeout! */
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k1583 in k1577 in a1468 in k1450 in mutex-lock! in k946 in k680 in k677 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 357  switch */
t2=((C_word*)t0)[3];
f_1472(t2,((C_word*)t0)[2]);}

/* a1589 in k1577 in a1468 in k1450 in mutex-lock! in k946 in k680 in k677 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1624,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
/* srfi-18.scm: 350  ##sys#delq */
t4=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[4],t3);}

/* k1622 in a1589 in k1577 in a1468 in k1450 in mutex-lock! in k946 in k680 in k677 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1624,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(3),t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1597,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[5],C_fix(13)))){
t4=t3;
f_1597(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-18.scm: 352  ##sys#remove-from-timeout-list */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}}

/* k1595 in k1622 in a1589 in k1577 in a1468 in k1450 in mutex-lock! in k946 in k680 in k677 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1597,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(8));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(8),t3);
t5=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(2),((C_word*)t0)[4]);
/* srfi-18.scm: 355  return */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* check in a1468 in k1450 in mutex-lock! in k946 in k680 in k677 */
static void C_fcall f_1493(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1493,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[3])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1504,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_record(&a,3,lf[20],lf[83],C_SCHEME_END_OF_LIST);
/* srfi-18.scm: 328  ##sys#signal */
t4=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1502 in check in a1468 in k1450 in mutex-lock! in k946 in k680 in k677 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 328  return */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* switch in a1468 in k1450 in mutex-lock! in k946 in k680 in k677 */
static void C_fcall f_1472(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1472,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1483,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* srfi-18.scm: 324  ##sys#append */
t5=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* k1481 in switch in a1468 in k1450 in mutex-lock! in k946 in k680 in k677 */
static void C_ccall f_1483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(3),t1);
/* srfi-18.scm: 325  ##sys#schedule */
t3=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* mutex-state in k946 in k680 in k677 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1418,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[71],lf[77]);
if(C_truep((C_word)C_slot(t2,C_fix(5)))){
t4=(C_word)C_slot(t2,C_fix(2));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:lf[78]));}
else{
t4=(C_word)C_slot(t2,C_fix(4));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?lf[79]:lf[80]));}}

/* mutex-specific-set! in k946 in k680 in k677 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1409,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[71],lf[76]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(6),t3));}

/* mutex-specific in k946 in k680 in k677 */
static void C_ccall f_1400(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1400,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[71],lf[75]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* mutex-name in k946 in k680 in k677 */
static void C_ccall f_1391(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1391,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[71],lf[74]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* make-mutex in k946 in k680 in k677 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1373r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1373r(t0,t1,t2);}}

static void C_ccall f_1373r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1377,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_1377(2,t4,(C_word)C_slot(t2,C_fix(0)));}
else{
/* srfi-18.scm: 289  gensym */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[71]);}}

/* k1375 in make-mutex in k946 in k680 in k677 */
static void C_ccall f_1377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 290  ##sys#make-mutex */
t2=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[34]+1));}

/* mutex? in k946 in k680 in k677 */
static void C_ccall f_1367(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1367,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[71]));}

/* thread-sleep! in k946 in k680 in k677 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1327,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1355,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_1355(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-18.scm: 278  ##sys#signal-hook */
t4=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[4],lf[68],lf[69],t2);}}

/* k1353 in thread-sleep! in k946 in k680 in k677 */
static void C_ccall f_1355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1362,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 279  ##sys#compute-time-limit */
t3=lf[1];
f_684(t3,t2,((C_word*)t0)[2]);}

/* k1360 in k1353 in thread-sleep! in k946 in k680 in k677 */
static void C_ccall f_1362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1362,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1336,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 272  ##sys#call-with-current-continuation */
C_call_cc(3,0,t2,t3);}

/* a1335 in k1360 in k1353 in thread-sleep! in k946 in k680 in k677 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1336,3,t0,t1,t2);}
t3=*((C_word*)lf[34]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1348,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1343,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 276  ##sys#thread-block-for-timeout! */
t7=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,((C_word*)t0)[2]);}

/* k1341 in a1335 in k1360 in k1353 in thread-sleep! in k946 in k680 in k677 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 277  ##sys#schedule */
t2=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1347 in a1335 in k1360 in k1353 in thread-sleep! in k946 in k680 in k677 */
static void C_ccall f_1348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1348,2,t0,t1);}
/* srfi-18.scm: 275  return */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* thread-resume! in k946 in k680 in k677 */
static void C_ccall f_1305(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1305,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[67]);
t4=(C_word)C_slot(t2,C_fix(3));
t5=(C_word)C_eqp(t4,lf[66]);
if(C_truep(t5)){
t6=(C_word)C_i_setslot(t2,C_fix(3),lf[47]);
/* srfi-18.scm: 268  ##sys#add-to-ready-queue */
t7=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* thread-suspend! in k946 in k680 in k677 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1272,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[65]);
t4=(C_word)C_i_setslot(t2,C_fix(3),lf[66]);
t5=(C_word)C_eqp(t2,*((C_word*)lf[34]+1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1290,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 259  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* a1289 in thread-suspend! in k946 in k680 in k677 */
static void C_ccall f_1290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1290,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1299,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t3);
/* srfi-18.scm: 262  ##sys#schedule */
t5=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* a1298 in a1289 in thread-suspend! in k946 in k680 in k677 */
static void C_ccall f_1299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1299,2,t0,t1);}
/* srfi-18.scm: 261  return */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* thread-terminate! in k946 in k680 in k677 */
static void C_ccall f_1228(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1228,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[61]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1235,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,*((C_word*)lf[63]+1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1270,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 249  ##sys#exit-handler */
t7=*((C_word*)lf[64]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_1235(2,t6,C_SCHEME_UNDEFINED);}}

/* k1268 in thread-terminate! in k946 in k680 in k677 */
static void C_ccall f_1270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1233 in thread-terminate! in k946 in k680 in k677 */
static void C_ccall f_1235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1235,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,C_SCHEME_UNDEFINED);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(2),t2);
t4=(C_word)C_a_i_record(&a,3,lf[20],lf[62],C_SCHEME_END_OF_LIST);
t5=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(7),t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 252  ##sys#thread-kill! */
t7=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[3],lf[55]);}

/* k1242 in k1233 in thread-terminate! in k946 in k680 in k677 */
static void C_ccall f_1244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[3],*((C_word*)lf[34]+1));
if(C_truep(t2)){
/* srfi-18.scm: 253  ##sys#schedule */
t3=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* thread-join! in k946 in k680 in k677 */
static void C_ccall f_1100(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1100r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1100r(t0,t1,t2,t3);}}

static void C_ccall f_1100r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_structure_2(t2,lf[37],lf[53]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1107,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t6=(C_word)C_slot(t3,C_fix(0));
/* srfi-18.scm: 215  ##sys#compute-time-limit */
t7=lf[1];
f_684(t7,t5,t6);}
else{
t6=t5;
f_1107(2,t6,C_SCHEME_FALSE);}}

/* k1105 in thread-join! in k946 in k680 in k677 */
static void C_ccall f_1107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1107,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(C_truep(t3)?(C_word)C_i_pairp(t3):C_SCHEME_FALSE);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1121,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-18.scm: 219  ##sys#call-with-current-continuation */
C_call_cc(3,0,((C_word*)t0)[2],t6);}

/* a1120 in k1105 in thread-join! in k946 in k680 in k677 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1121,3,t0,t1,t2);}
t3=*((C_word*)lf[34]+1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1125,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* srfi-18.scm: 222  ##sys#thread-block-for-timeout! */
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,((C_word*)t0)[2]);}
else{
t5=t4;
f_1125(2,t5,C_SCHEME_UNDEFINED);}}

/* k1123 in a1120 in k1105 in thread-join! in k946 in k680 in k677 */
static void C_ccall f_1125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1136,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1131,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 243  ##sys#thread-block-for-termination! */
t5=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],((C_word*)t0)[7]);}

/* k1129 in k1123 in a1120 in k1105 in thread-join! in k946 in k680 in k677 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 244  ##sys#schedule */
t2=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1135 in k1123 in a1120 in k1105 in thread-join! in k946 in k680 in k677 */
static void C_ccall f_1136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1136,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t3=(C_word)C_eqp(t2,lf[33]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1149,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[4],C_fix(13)))){
t5=t4;
f_1149(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-18.scm: 229  ##sys#remove-from-timeout-list */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}}
else{
t4=(C_word)C_eqp(t2,lf[55]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1175,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(7));
t7=(C_word)C_a_i_list(&a,2,lf[56],t6);
t8=(C_word)C_a_i_record(&a,3,lf[20],lf[57],t7);
/* srfi-18.scm: 233  ##sys#signal */
t9=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t5,t8);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1194,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=t5;
f_1194(2,t6,((C_word*)t0)[2]);}
else{
t6=(C_word)C_a_i_record(&a,3,lf[20],lf[58],C_SCHEME_END_OF_LIST);
/* srfi-18.scm: 241  ##sys#signal */
t7=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}}}

/* k1192 in a1135 in k1123 in a1120 in k1105 in thread-join! in k946 in k680 in k677 */
static void C_ccall f_1194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 238  return */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1173 in a1135 in k1123 in a1120 in k1105 in thread-join! in k946 in k680 in k677 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 232  return */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1147 in a1135 in k1123 in a1120 in k1105 in thread-join! in k946 in k680 in k677 */
static void C_ccall f_1149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* thread-start! in k946 in k680 in k677 */
static void C_ccall f_1064(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1064,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1068,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_closurep(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1094,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 202  make-thread */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t3)[1]);}
else{
t5=t4;
f_1068(t5,(C_word)C_i_check_structure_2(((C_word*)t3)[1],lf[37],lf[46]));}}

/* k1092 in thread-start! in k946 in k680 in k677 */
static void C_ccall f_1094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1068(t3,t2);}

/* k1066 in thread-start! in k946 in k680 in k677 */
static void C_fcall f_1068(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1068,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(3));
t4=(C_word)C_eqp(lf[36],t3);
if(C_truep(t4)){
t5=t2;
f_1071(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-18.scm: 205  ##sys#error */
t5=*((C_word*)lf[49]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[46],lf[50],((C_word*)((C_word*)t0)[3])[1]);}}

/* k1069 in k1066 in thread-start! in k946 in k680 in k677 */
static void C_ccall f_1071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1071,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(3),lf[47]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1077,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm: 207  ##sys#add-to-ready-queue */
t4=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[3])[1]);}

/* k1075 in k1069 in k1066 in thread-start! in k946 in k680 in k677 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* thread-name in k946 in k680 in k677 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1055,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[45]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* thread-quantum-set! in k946 in k680 in k677 */
static void C_ccall f_1039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1039,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[37],lf[44]);
t5=(C_word)C_i_check_exact_2(t3,lf[44]);
t6=(C_word)C_i_fixnum_max(t3,C_fix(10));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_set_i_slot(t2,C_fix(9),t6));}

/* thread-quantum in k946 in k680 in k677 */
static void C_ccall f_1030(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1030,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[43]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(9)));}

/* thread-specific-set! in k946 in k680 in k677 */
static void C_ccall f_1021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1021,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[37],lf[42]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(10),t3));}

/* thread-specific in k946 in k680 in k677 */
static void C_ccall f_1012(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1012,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[41]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(10)));}

/* thread-state in k946 in k680 in k677 */
static void C_ccall f_1003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1003,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[37],lf[40]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* current-thread in k946 in k680 in k677 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1000,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[34]+1));}

/* thread? in k946 in k680 in k677 */
static void C_ccall f_994(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_994,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[37]));}

/* make-thread in k946 in k680 in k677 */
static void C_ccall f_950(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_950r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_950r(t0,t1,t2,t3);}}

static void C_ccall f_950r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_954,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_979,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t6=t5;
f_979(2,t6,(C_word)C_slot(t3,C_fix(0)));}
else{
/* srfi-18.scm: 157  gensym */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[37]);}}

/* k977 in make-thread in k946 in k680 in k677 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(*((C_word*)lf[34]+1),C_fix(9));
/* srfi-18.scm: 154  ##sys#make-thread */
t3=*((C_word*)lf[35]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],C_SCHEME_FALSE,lf[36],t1,t2);}

/* k952 in make-thread in k946 in k680 in k677 */
static void C_ccall f_954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_959,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_setslot(t1,C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* a958 in k952 in make-thread in k946 in k680 in k677 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_965,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 162  ##sys#call-with-values */
C_u_call_with_values(4,0,t1,((C_word*)t0)[2],t2);}

/* a964 in a958 in k952 in make-thread in k946 in k680 in k677 */
static void C_ccall f_965(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_965r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_965r(t0,t1,t2);}}

static void C_ccall f_965r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(2),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_972,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 166  ##sys#thread-kill! */
t5=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],lf[33]);}

/* k970 in a964 in a958 in k952 in make-thread in k946 in k680 in k677 */
static void C_ccall f_972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 167  ##sys#schedule */
t2=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* uncaught-exception? in k680 in k677 */
static void C_ccall f_930(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_930,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[20]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_memq(lf[27],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* terminated-thread-exception? in k680 in k677 */
static void C_ccall f_914(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_914,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[20]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_memq(lf[25],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* abandoned-mutex-exception? in k680 in k677 */
static void C_ccall f_898(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_898,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[20]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_memq(lf[23],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* join-timeout-exception? in k680 in k677 */
static void C_ccall f_882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_882,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[20]))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_memq(lf[21],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* time? in k680 in k677 */
static void C_ccall f_874(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_874,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[2]));}

/* milliseconds->time in k680 in k677 */
static void C_ccall f_858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_858,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[14]);
t4=(C_word)C_a_i_divide(&a,2,t2,C_fix(1000));
t5=(C_word)C_a_i_plus(&a,2,C_flonum(&a,C_startup_time_seconds),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[2],t2,t5,C_fix(0)));}

/* seconds->time in k680 in k677 */
static void C_ccall f_804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_804,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[10]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_811,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_minus(&a,2,t2,C_flonum(&a,C_startup_time_seconds));
/* srfi-18.scm: 109  max */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_fix(0),t5);}

/* k809 in seconds->time in k680 in k677 */
static void C_ccall f_811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_814,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_848,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_852,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm: 110  ##sys#exact->inexact */
t5=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k850 in k809 in seconds->time in k680 in k677 */
static void C_ccall f_852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm: 110  ##sys#flonum-fraction */
t2=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k846 in k809 in seconds->time in k680 in k677 */
static void C_ccall f_848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_848,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,C_fix(1000),t1);
/* srfi-18.scm: 110  truncate */
t3=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k812 in k809 in seconds->time in k680 in k677 */
static void C_ccall f_814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_832,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_times(&a,2,((C_word*)t0)[2],C_fix(1000));
t4=(C_word)C_a_i_plus(&a,2,t3,t1);
/* srfi-18.scm: 111  truncate */
t5=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t2,t4);}

/* k830 in k812 in k809 in seconds->time in k680 in k677 */
static void C_ccall f_832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_832,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_824,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-18.scm: 112  truncate */
t4=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k822 in k830 in k812 in k809 in seconds->time in k680 in k677 */
static void C_ccall f_824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_824,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[2],((C_word*)t0)[2],t1,t2));}

/* time->milliseconds in k680 in k677 */
static void C_ccall f_775(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_775,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[2],lf[9]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_a_i_minus(&a,2,t4,C_flonum(&a,C_startup_time_seconds));
t6=(C_word)C_a_i_times(&a,2,t5,C_fix(1000));
t7=(C_word)C_i_inexact_to_exact(t6);
t8=(C_word)C_slot(t2,C_fix(3));
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_plus(&a,2,t7,t8));}

/* time->seconds in k680 in k677 */
static void C_ccall f_754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_754,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[2],lf[8]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_a_i_divide(&a,2,t5,C_fix(1000));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_plus(&a,2,t4,t6));}

/* current-time in k680 in k677 */
static void C_ccall f_727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_727,2,t0,t1);}
t2=C_flonum(&a,C_get_seconds);
t3=C_flonum(&a,C_startup_time_seconds);
t4=C_long_to_num(&a,C_ms);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_739,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_minus(&a,2,t2,t3);
t7=(C_word)C_a_i_times(&a,2,t6,C_fix(1000));
t8=(C_word)C_a_i_plus(&a,2,t7,C_long_to_num(&a,C_ms));
/* srfi-18.scm: 92   truncate */
t9=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t5,t8);}

/* k737 in current-time in k680 in k677 */
static void C_ccall f_739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_739,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[2],t2,((C_word*)t0)[2],C_long_to_num(&a,C_ms)));}

/* ##sys#compute-time-limit in k680 in k677 */
static void C_fcall f_684(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_684,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
if(C_truep((C_word)C_i_structurep(t2,lf[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t3=(C_word)C_fudge(C_fix(16));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_718,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_times(&a,2,t2,C_fix(1000));
/* srfi-18.scm: 69   truncate */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
/* srfi-18.scm: 70   ##sys#signal-hook */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,lf[4],lf[5],t2);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k716 in ##sys#compute-time-limit in k680 in k677 */
static void C_ccall f_718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t2));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[119] = {
{"toplevel:srfi_18_scm",(void*)C_srfi_18_toplevel},
{"f_679:srfi_18_scm",(void*)f_679},
{"f_682:srfi_18_scm",(void*)f_682},
{"f_948:srfi_18_scm",(void*)f_948},
{"f_2072:srfi_18_scm",(void*)f_2072},
{"f_2046:srfi_18_scm",(void*)f_2046},
{"f_2056:srfi_18_scm",(void*)f_2056},
{"f_2059:srfi_18_scm",(void*)f_2059},
{"f_2062:srfi_18_scm",(void*)f_2062},
{"f_2014:srfi_18_scm",(void*)f_2014},
{"f_2016:srfi_18_scm",(void*)f_2016},
{"f_2026:srfi_18_scm",(void*)f_2026},
{"f_1980:srfi_18_scm",(void*)f_1980},
{"f_2004:srfi_18_scm",(void*)f_2004},
{"f_2008:srfi_18_scm",(void*)f_2008},
{"f_1943:srfi_18_scm",(void*)f_1943},
{"f_1955:srfi_18_scm",(void*)f_1955},
{"f_1950:srfi_18_scm",(void*)f_1950},
{"f_1900:srfi_18_scm",(void*)f_1900},
{"f_1891:srfi_18_scm",(void*)f_1891},
{"f_1882:srfi_18_scm",(void*)f_1882},
{"f_1876:srfi_18_scm",(void*)f_1876},
{"f_1857:srfi_18_scm",(void*)f_1857},
{"f_1865:srfi_18_scm",(void*)f_1865},
{"f_1666:srfi_18_scm",(void*)f_1666},
{"f_1684:srfi_18_scm",(void*)f_1684},
{"f_1691:srfi_18_scm",(void*)f_1691},
{"f_1829:srfi_18_scm",(void*)f_1829},
{"f_1811:srfi_18_scm",(void*)f_1811},
{"f_1780:srfi_18_scm",(void*)f_1780},
{"f_1800:srfi_18_scm",(void*)f_1800},
{"f_1787:srfi_18_scm",(void*)f_1787},
{"f_1706:srfi_18_scm",(void*)f_1706},
{"f_1709:srfi_18_scm",(void*)f_1709},
{"f_1821:srfi_18_scm",(void*)f_1821},
{"f_1442:srfi_18_scm",(void*)f_1442},
{"f_1452:srfi_18_scm",(void*)f_1452},
{"f_1469:srfi_18_scm",(void*)f_1469},
{"f_1517:srfi_18_scm",(void*)f_1517},
{"f_1520:srfi_18_scm",(void*)f_1520},
{"f_1639:srfi_18_scm",(void*)f_1639},
{"f_1579:srfi_18_scm",(void*)f_1579},
{"f_1585:srfi_18_scm",(void*)f_1585},
{"f_1590:srfi_18_scm",(void*)f_1590},
{"f_1624:srfi_18_scm",(void*)f_1624},
{"f_1597:srfi_18_scm",(void*)f_1597},
{"f_1493:srfi_18_scm",(void*)f_1493},
{"f_1504:srfi_18_scm",(void*)f_1504},
{"f_1472:srfi_18_scm",(void*)f_1472},
{"f_1483:srfi_18_scm",(void*)f_1483},
{"f_1418:srfi_18_scm",(void*)f_1418},
{"f_1409:srfi_18_scm",(void*)f_1409},
{"f_1400:srfi_18_scm",(void*)f_1400},
{"f_1391:srfi_18_scm",(void*)f_1391},
{"f_1373:srfi_18_scm",(void*)f_1373},
{"f_1377:srfi_18_scm",(void*)f_1377},
{"f_1367:srfi_18_scm",(void*)f_1367},
{"f_1327:srfi_18_scm",(void*)f_1327},
{"f_1355:srfi_18_scm",(void*)f_1355},
{"f_1362:srfi_18_scm",(void*)f_1362},
{"f_1336:srfi_18_scm",(void*)f_1336},
{"f_1343:srfi_18_scm",(void*)f_1343},
{"f_1348:srfi_18_scm",(void*)f_1348},
{"f_1305:srfi_18_scm",(void*)f_1305},
{"f_1272:srfi_18_scm",(void*)f_1272},
{"f_1290:srfi_18_scm",(void*)f_1290},
{"f_1299:srfi_18_scm",(void*)f_1299},
{"f_1228:srfi_18_scm",(void*)f_1228},
{"f_1270:srfi_18_scm",(void*)f_1270},
{"f_1235:srfi_18_scm",(void*)f_1235},
{"f_1244:srfi_18_scm",(void*)f_1244},
{"f_1100:srfi_18_scm",(void*)f_1100},
{"f_1107:srfi_18_scm",(void*)f_1107},
{"f_1121:srfi_18_scm",(void*)f_1121},
{"f_1125:srfi_18_scm",(void*)f_1125},
{"f_1131:srfi_18_scm",(void*)f_1131},
{"f_1136:srfi_18_scm",(void*)f_1136},
{"f_1194:srfi_18_scm",(void*)f_1194},
{"f_1175:srfi_18_scm",(void*)f_1175},
{"f_1149:srfi_18_scm",(void*)f_1149},
{"f_1064:srfi_18_scm",(void*)f_1064},
{"f_1094:srfi_18_scm",(void*)f_1094},
{"f_1068:srfi_18_scm",(void*)f_1068},
{"f_1071:srfi_18_scm",(void*)f_1071},
{"f_1077:srfi_18_scm",(void*)f_1077},
{"f_1055:srfi_18_scm",(void*)f_1055},
{"f_1039:srfi_18_scm",(void*)f_1039},
{"f_1030:srfi_18_scm",(void*)f_1030},
{"f_1021:srfi_18_scm",(void*)f_1021},
{"f_1012:srfi_18_scm",(void*)f_1012},
{"f_1003:srfi_18_scm",(void*)f_1003},
{"f_1000:srfi_18_scm",(void*)f_1000},
{"f_994:srfi_18_scm",(void*)f_994},
{"f_950:srfi_18_scm",(void*)f_950},
{"f_979:srfi_18_scm",(void*)f_979},
{"f_954:srfi_18_scm",(void*)f_954},
{"f_959:srfi_18_scm",(void*)f_959},
{"f_965:srfi_18_scm",(void*)f_965},
{"f_972:srfi_18_scm",(void*)f_972},
{"f_930:srfi_18_scm",(void*)f_930},
{"f_914:srfi_18_scm",(void*)f_914},
{"f_898:srfi_18_scm",(void*)f_898},
{"f_882:srfi_18_scm",(void*)f_882},
{"f_874:srfi_18_scm",(void*)f_874},
{"f_858:srfi_18_scm",(void*)f_858},
{"f_804:srfi_18_scm",(void*)f_804},
{"f_811:srfi_18_scm",(void*)f_811},
{"f_852:srfi_18_scm",(void*)f_852},
{"f_848:srfi_18_scm",(void*)f_848},
{"f_814:srfi_18_scm",(void*)f_814},
{"f_832:srfi_18_scm",(void*)f_832},
{"f_824:srfi_18_scm",(void*)f_824},
{"f_775:srfi_18_scm",(void*)f_775},
{"f_754:srfi_18_scm",(void*)f_754},
{"f_727:srfi_18_scm",(void*)f_727},
{"f_739:srfi_18_scm",(void*)f_739},
{"f_684:srfi_18_scm",(void*)f_684},
{"f_718:srfi_18_scm",(void*)f_718},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
