/* Generated from regex.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:28
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: regex.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file uregex.c
   unit: regex
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[332];
static double C_possibly_force_alignment;


C_noret_decl(C_regex_toplevel)
C_externexport void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4890)
static void C_ccall f_4890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21583)
static void C_ccall f_21583(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21590)
static void C_ccall f_21590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21598)
static void C_fcall f_21598(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21630)
static void C_ccall f_21630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21617)
static void C_ccall f_21617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21620)
static void C_ccall f_21620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21543)
static void C_ccall f_21543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21552)
static void C_fcall f_21552(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21571)
static void C_ccall f_21571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21578)
static void C_ccall f_21578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21266)
static void C_ccall f_21266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21281)
static void C_ccall f_21281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21283)
static void C_fcall f_21283(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21538)
static void C_ccall f_21538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21534)
static void C_ccall f_21534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21523)
static void C_ccall f_21523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21345)
static void C_fcall f_21345(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21375)
static void C_fcall f_21375(C_word t0,C_word t1) C_noret;
C_noret_decl(f_21404)
static void C_fcall f_21404(C_word t0,C_word t1) C_noret;
C_noret_decl(f_21452)
static void C_ccall f_21452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21431)
static void C_ccall f_21431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21427)
static void C_ccall f_21427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21394)
static void C_ccall f_21394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21390)
static void C_ccall f_21390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21365)
static void C_ccall f_21365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21343)
static void C_ccall f_21343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21330)
static void C_ccall f_21330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21317)
static void C_ccall f_21317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21313)
static void C_ccall f_21313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21277)
static void C_ccall f_21277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21181)
static void C_ccall f_21181(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21194)
static void C_fcall f_21194(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21213)
static void C_fcall f_21213(C_word t0,C_word t1) C_noret;
C_noret_decl(f_21129)
static void C_ccall f_21129(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_21129)
static void C_ccall f_21129r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_21144)
static void C_fcall f_21144(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21161)
static void C_ccall f_21161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20874)
static void C_ccall f_20874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_20874)
static void C_ccall f_20874r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_21016)
static void C_fcall f_21016(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21020)
static void C_ccall f_21020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21111)
static void C_ccall f_21111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21107)
static void C_ccall f_21107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21078)
static void C_ccall f_21078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21060)
static void C_ccall f_21060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21053)
static void C_ccall f_21053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20910)
static void C_fcall f_20910(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20916)
static void C_fcall f_20916(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20983)
static void C_ccall f_20983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20971)
static void C_ccall f_20971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20930)
static void C_ccall f_20930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20895)
static C_word C_fcall f_20895(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_20692)
static void C_ccall f_20692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_20692)
static void C_ccall f_20692r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_20856)
static void C_ccall f_20856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20830)
static void C_ccall f_20830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20855)
static void C_ccall f_20855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20810)
static void C_ccall f_20810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20711)
static void C_fcall f_20711(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20719)
static void C_fcall f_20719(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20723)
static void C_ccall f_20723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20784)
static void C_ccall f_20784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20765)
static void C_ccall f_20765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20799)
static void C_ccall f_20799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_20794)
static void C_ccall f_20794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_20572)
static void C_ccall f_20572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_20572)
static void C_ccall f_20572r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_20647)
static void C_fcall f_20647(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20638)
static void C_fcall f_20638(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20574)
static void C_fcall f_20574(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20578)
static void C_ccall f_20578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20633)
static void C_ccall f_20633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20587)
static void C_ccall f_20587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20597)
static void C_ccall f_20597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20599)
static void C_fcall f_20599(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20460)
static void C_ccall f_20460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_20460)
static void C_ccall f_20460r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_20527)
static void C_fcall f_20527(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20518)
static void C_fcall f_20518(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20462)
static void C_fcall f_20462(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20466)
static void C_ccall f_20466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20513)
static void C_ccall f_20513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20475)
static void C_ccall f_20475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20485)
static void C_ccall f_20485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20487)
static void C_fcall f_20487(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20509)
static void C_ccall f_20509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20398)
static void C_ccall f_20398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20402)
static void C_ccall f_20402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20405)
static void C_ccall f_20405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20415)
static void C_ccall f_20415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20417)
static void C_fcall f_20417(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20352)
static void C_ccall f_20352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20356)
static void C_ccall f_20356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20359)
static void C_ccall f_20359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20369)
static void C_ccall f_20369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20371)
static void C_fcall f_20371(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20396)
static void C_ccall f_20396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20331)
static void C_fcall f_20331(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20338)
static void C_ccall f_20338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20347)
static void C_ccall f_20347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20228)
static void C_ccall f_20228(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_20228)
static void C_ccall f_20228r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_20271)
static void C_fcall f_20271(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20266)
static void C_fcall f_20266(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20261)
static void C_fcall f_20261(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20230)
static void C_fcall f_20230(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_20242)
static void C_fcall f_20242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20245)
static void C_fcall f_20245(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20248)
static void C_fcall f_20248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20238)
static void C_ccall f_20238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20210)
static void C_ccall f_20210(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20028)
static void C_ccall f_20028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20034)
static void C_fcall f_20034(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20156)
static void C_ccall f_20156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20160)
static void C_ccall f_20160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20168)
static void C_ccall f_20168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20152)
static void C_ccall f_20152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20127)
static void C_ccall f_20127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20131)
static void C_ccall f_20131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20123)
static void C_ccall f_20123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20090)
static void C_ccall f_20090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20062)
static void C_ccall f_20062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19972)
static void C_ccall f_19972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_19972)
static void C_ccall f_19972r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_20005)
static void C_ccall f_20005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20026)
static void C_ccall f_20026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20016)
static void C_fcall f_20016(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19978)
static void C_ccall f_19978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_19982)
static void C_ccall f_19982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19989)
static void C_ccall f_19989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20003)
static void C_ccall f_20003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19993)
static void C_fcall f_19993(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19920)
static void C_ccall f_19920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_19920)
static void C_ccall f_19920r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_19970)
static void C_ccall f_19970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19924)
static void C_ccall f_19924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19962)
static void C_ccall f_19962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19938)
static void C_ccall f_19938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19946)
static void C_ccall f_19946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19958)
static void C_ccall f_19958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19954)
static void C_ccall f_19954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19942)
static void C_ccall f_19942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19807)
static void C_ccall f_19807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_19807)
static void C_ccall f_19807r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_19811)
static void C_ccall f_19811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19814)
static void C_ccall f_19814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19897)
static void C_fcall f_19897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19868)
static void C_fcall f_19868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19831)
static void C_fcall f_19831(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19844)
static void C_ccall f_19844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19856)
static void C_ccall f_19856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19859)
static void C_ccall f_19859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19862)
static void C_ccall f_19862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19917)
static void C_ccall f_19917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19642)
static void C_ccall f_19642(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19648)
static void C_fcall f_19648(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19664)
static void C_fcall f_19664(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19701)
static void C_fcall f_19701(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19759)
static void C_ccall f_19759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19716)
static void C_ccall f_19716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19712)
static void C_ccall f_19712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19684)
static void C_ccall f_19684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19632)
static void C_fcall f_19632(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19640)
static void C_ccall f_19640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19514)
static void C_ccall f_19514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19520)
static void C_fcall f_19520(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_19622)
static void C_ccall f_19622(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19530)
static void C_ccall f_19530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19597)
static void C_ccall f_19597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19538)
static void C_ccall f_19538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_19589)
static void C_ccall f_19589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19542)
static void C_ccall f_19542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19551)
static void C_ccall f_19551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19554)
static void C_ccall f_19554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19561)
static void C_ccall f_19561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19393)
static void C_fcall f_19393(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19500)
static void C_ccall f_19500(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19416)
static void C_ccall f_19416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19475)
static void C_ccall f_19475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19424)
static void C_ccall f_19424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_19467)
static void C_ccall f_19467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19428)
static void C_ccall f_19428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19437)
static void C_ccall f_19437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19440)
static void C_ccall f_19440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19306)
static void C_ccall f_19306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19383)
static void C_ccall f_19383(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19316)
static void C_ccall f_19316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19362)
static void C_ccall f_19362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19334)
static void C_ccall f_19334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19326)
static void C_ccall f_19326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19161)
static void C_fcall f_19161(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19177)
static void C_fcall f_19177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19149)
static C_word C_fcall f_19149(C_word *a,C_word t0);
C_noret_decl(f_19111)
static void C_fcall f_19111(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19117)
static void C_ccall f_19117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_18830)
static void C_fcall f_18830(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_18840)
static void C_fcall f_18840(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19004)
static void C_ccall f_19004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19008)
static void C_ccall f_19008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13588)
static void C_fcall f_13588(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13615)
static void C_ccall f_13615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13611)
static void C_ccall f_13611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18987)
static void C_ccall f_18987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18754)
static void C_fcall f_18754(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_18977)
static void C_ccall f_18977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18956)
static void C_ccall f_18956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18960)
static void C_ccall f_18960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18948)
static void C_ccall f_18948(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_18925)
static void C_ccall f_18925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18929)
static void C_ccall f_18929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18900)
static void C_ccall f_18900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18904)
static void C_ccall f_18904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18896)
static void C_ccall f_18896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18869)
static void C_ccall f_18869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18843)
static void C_ccall f_18843(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_18713)
static void C_fcall f_18713(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_18715)
static void C_ccall f_18715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18722)
static void C_ccall f_18722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16349)
static void C_fcall f_16349(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16389)
static void C_ccall f_16389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16268)
static void C_fcall f_16268(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16274)
static void C_fcall f_16274(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_16323)
static void C_ccall f_16323(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16321)
static void C_ccall f_16321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16313)
static void C_ccall f_16313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16301)
static void C_ccall f_16301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16305)
static void C_ccall f_16305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16152)
static void C_fcall f_16152(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16185)
static void C_fcall f_16185(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16189)
static void C_fcall f_16189(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16197)
static void C_fcall f_16197(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16166)
static void C_ccall f_16166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16078)
static void C_fcall f_16078(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16086)
static void C_fcall f_16086(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16090)
static void C_fcall f_16090(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16066)
static C_word C_fcall f_16066(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_15604)
static void C_fcall f_15604(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15813)
static void C_fcall f_15813(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15841)
static void C_fcall f_15841(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15998)
static void C_fcall f_15998(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15899)
static void C_fcall f_15899(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15969)
static void C_ccall f_15969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15904)
static void C_ccall f_15904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_15957)
static void C_ccall f_15957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15917)
static void C_fcall f_15917(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15920)
static void C_fcall f_15920(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15927)
static void C_ccall f_15927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15885)
static void C_ccall f_15885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15846)
static void C_ccall f_15846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15873)
static void C_ccall f_15873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15857)
static void C_ccall f_15857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15635)
static void C_fcall f_15635(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15684)
static void C_fcall f_15684(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15751)
static void C_ccall f_15751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15689)
static void C_ccall f_15689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15739)
static void C_ccall f_15739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15705)
static void C_fcall f_15705(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15709)
static void C_fcall f_15709(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15701)
static void C_ccall f_15701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15670)
static void C_ccall f_15670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15607)
static void C_fcall f_15607(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15307)
static void C_fcall f_15307(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15422)
static void C_ccall f_15422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15320)
static void C_fcall f_15320(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_15515)
static void C_fcall f_15515(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_15594)
static void C_ccall f_15594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15533)
static void C_ccall f_15533(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15545)
static void C_ccall f_15545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15353)
static void C_ccall f_15353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15365)
static void C_fcall f_15365(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15400)
static void C_ccall f_15400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15372)
static void C_ccall f_15372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15396)
static void C_ccall f_15396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15388)
static void C_ccall f_15388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15334)
static void C_ccall f_15334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15499)
static void C_ccall f_15499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15503)
static void C_ccall f_15503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15442)
static void C_ccall f_15442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15461)
static void C_ccall f_15461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15475)
static void C_ccall f_15475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15473)
static void C_ccall f_15473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15459)
static void C_ccall f_15459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15444)
static C_word C_fcall f_15444(C_word t0,C_word t1);
C_noret_decl(f_14517)
static void C_fcall f_14517(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14535)
static void C_fcall f_14535(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_14798)
static void C_fcall f_14798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14852)
static void C_fcall f_14852(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15112)
static void C_ccall f_15112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15200)
static void C_ccall f_15200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15118)
static void C_ccall f_15118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15196)
static void C_ccall f_15196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15121)
static void C_ccall f_15121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15176)
static void C_ccall f_15176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15127)
static void C_fcall f_15127(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15146)
static void C_ccall f_15146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15052)
static void C_ccall f_15052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15096)
static void C_ccall f_15096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15058)
static void C_ccall f_15058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15080)
static void C_ccall f_15080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14949)
static void C_ccall f_14949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15031)
static void C_ccall f_15031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14952)
static void C_ccall f_14952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15016)
static void C_ccall f_15016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14955)
static void C_ccall f_14955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14981)
static void C_ccall f_14981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14973)
static void C_ccall f_14973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14977)
static void C_ccall f_14977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14969)
static void C_ccall f_14969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14940)
static void C_ccall f_14940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14855)
static void C_ccall f_14855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14882)
static void C_ccall f_14882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14910)
static void C_ccall f_14910(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14908)
static void C_ccall f_14908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14896)
static void C_ccall f_14896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14900)
static void C_ccall f_14900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14871)
static void C_ccall f_14871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14801)
static void C_ccall f_14801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14804)
static void C_ccall f_14804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14818)
static void C_ccall f_14818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14781)
static void C_ccall f_14781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14758)
static void C_ccall f_14758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14681)
static void C_ccall f_14681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14648)
static void C_fcall f_14648(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14670)
static void C_ccall f_14670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14655)
static void C_ccall f_14655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14625)
static void C_ccall f_14625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14604)
static void C_ccall f_14604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14600)
static void C_ccall f_14600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14552)
static void C_fcall f_14552(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14567)
static void C_ccall f_14567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14573)
static void C_ccall f_14573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14571)
static void C_ccall f_14571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14538)
static void C_fcall f_14538(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14410)
static void C_fcall f_14410(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_14424)
static void C_fcall f_14424(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_14462)
static void C_ccall f_14462(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14437)
static void C_ccall f_14437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14315)
static C_word C_fcall f_14315(C_word t0);
C_noret_decl(f_14305)
static C_word C_fcall f_14305(C_word t0,C_word t1);
C_noret_decl(f_14299)
static C_word C_fcall f_14299(C_word t0);
C_noret_decl(f_14232)
static void C_ccall f_14232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14236)
static void C_ccall f_14236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14239)
static void C_ccall f_14239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14251)
static void C_ccall f_14251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14279)
static void C_ccall f_14279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14296)
static void C_ccall f_14296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14282)
static void C_ccall f_14282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14276)
static void C_ccall f_14276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14254)
static void C_ccall f_14254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14272)
static void C_ccall f_14272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14269)
static void C_ccall f_14269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14073)
static void C_ccall f_14073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_14080)
static void C_ccall f_14080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14196)
static void C_ccall f_14196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14201)
static void C_fcall f_14201(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14229)
static void C_ccall f_14229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14211)
static void C_ccall f_14211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14193)
static void C_ccall f_14193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14086)
static void C_ccall f_14086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14189)
static void C_ccall f_14189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14331)
static void C_fcall f_14331(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14366)
static void C_ccall f_14366(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14350)
static void C_ccall f_14350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14111)
static void C_ccall f_14111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14185)
static void C_ccall f_14185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14120)
static void C_ccall f_14120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14126)
static void C_ccall f_14126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14131)
static void C_fcall f_14131(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14141)
static void C_ccall f_14141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14156)
static void C_ccall f_14156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14153)
static void C_ccall f_14153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14108)
static void C_ccall f_14108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14089)
static void C_ccall f_14089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14104)
static void C_ccall f_14104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14101)
static void C_ccall f_14101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14027)
static void C_ccall f_14027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_14027)
static void C_ccall f_14027r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_14031)
static void C_ccall f_14031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14049)
static void C_fcall f_14049(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14040)
static void C_ccall f_14040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13910)
static void C_ccall f_13910(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13929)
static void C_fcall f_13929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14000)
static void C_ccall f_14000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13967)
static void C_ccall f_13967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13874)
static void C_fcall f_13874(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13904)
static void C_ccall f_13904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13896)
static void C_ccall f_13896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13644)
static void C_fcall f_13644(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13742)
static void C_fcall f_13742(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13529)
static void C_ccall f_13529(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13504)
static C_word C_fcall f_13504(C_word *a,C_word t0);
C_noret_decl(f_13479)
static C_word C_fcall f_13479(C_word *a,C_word t0);
C_noret_decl(f_12384)
static void C_fcall f_12384(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12390)
static void C_ccall f_12390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12415)
static void C_fcall f_12415(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12358)
static void C_ccall f_12358(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12272)
static void C_ccall f_12272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12311)
static void C_fcall f_12311(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12324)
static void C_ccall f_12324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12186)
static void C_ccall f_12186(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12225)
static void C_fcall f_12225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12130)
static C_word C_fcall f_12130(C_word t0);
C_noret_decl(f_12054)
static void C_ccall f_12054(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12079)
static void C_fcall f_12079(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11926)
static void C_ccall f_11926(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11945)
static void C_fcall f_11945(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11994)
static void C_fcall f_11994(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11785)
static void C_ccall f_11785(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11785)
static void C_ccall f_11785r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11789)
static void C_ccall f_11789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11472)
static void C_ccall f_11472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11476)
static void C_ccall f_11476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11478)
static void C_fcall f_11478(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11732)
static void C_ccall f_11732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11743)
static void C_ccall f_11743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11739)
static void C_ccall f_11739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11591)
static void C_fcall f_11591(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11695)
static void C_ccall f_11695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11676)
static void C_ccall f_11676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11600)
static void C_ccall f_11600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11621)
static void C_ccall f_11621(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11631)
static void C_ccall f_11631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11606)
static void C_ccall f_11606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11616)
static void C_ccall f_11616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11574)
static void C_ccall f_11574(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11572)
static void C_ccall f_11572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11547)
static void C_ccall f_11547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11545)
static void C_ccall f_11545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11481)
static void C_ccall f_11481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11792)
static void C_ccall f_11792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11795)
static void C_ccall f_11795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11798)
static void C_ccall f_11798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11801)
static void C_fcall f_11801(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11875)
static void C_ccall f_11875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11804)
static void C_ccall f_11804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11807)
static void C_ccall f_11807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11810)
static void C_ccall f_11810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16405)
static void C_fcall f_16405(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_16729)
static void C_ccall f_16729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16419)
static void C_ccall f_16419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16432)
static void C_ccall f_16432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16423)
static void C_ccall f_16423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16424)
static void C_ccall f_16424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16680)
static void C_ccall f_16680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16681)
static void C_ccall f_16681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16685)
static void C_ccall f_16685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16688)
static void C_fcall f_16688(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16655)
static void C_ccall f_16655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16656)
static void C_ccall f_16656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16660)
static void C_ccall f_16660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16599)
static void C_ccall f_16599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16624)
static void C_ccall f_16624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16628)
static void C_ccall f_16628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16601)
static void C_ccall f_16601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16605)
static void C_ccall f_16605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16549)
static void C_ccall f_16549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16574)
static void C_ccall f_16574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16552)
static void C_ccall f_16552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16553)
static void C_ccall f_16553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16557)
static void C_ccall f_16557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16456)
static void C_ccall f_16456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16525)
static void C_ccall f_16525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16459)
static void C_ccall f_16459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16460)
static void C_ccall f_16460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16466)
static void C_fcall f_16466(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_16476)
static void C_ccall f_16476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16479)
static void C_ccall f_16479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11813)
static void C_ccall f_11813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11816)
static void C_ccall f_11816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11819)
static void C_ccall f_11819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12447)
static void C_ccall f_12447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13468)
static void C_ccall f_13468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12450)
static void C_ccall f_12450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12459)
static void C_fcall f_12459(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_12504)
static void C_fcall f_12504(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12533)
static void C_fcall f_12533(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13263)
static void C_fcall f_13263(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13313)
static void C_fcall f_13313(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13290)
static void C_ccall f_13290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13236)
static void C_ccall f_13236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13206)
static void C_ccall f_13206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13062)
static void C_fcall f_13062(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13065)
static void C_fcall f_13065(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13130)
static void C_ccall f_13130(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13083)
static void C_ccall f_13083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13095)
static void C_fcall f_13095(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13042)
static void C_ccall f_13042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13033)
static void C_ccall f_13033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12920)
static void C_ccall f_12920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12983)
static void C_ccall f_12983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12929)
static void C_fcall f_12929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12880)
static void C_ccall f_12880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12709)
static void C_fcall f_12709(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12715)
static void C_ccall f_12715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12718)
static void C_ccall f_12718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12800)
static void C_fcall f_12800(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12727)
static void C_ccall f_12727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12741)
static void C_ccall f_12741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12753)
static void C_ccall f_12753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12755)
static void C_ccall f_12755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12784)
static void C_ccall f_12784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12780)
static void C_ccall f_12780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12767)
static void C_fcall f_12767(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12624)
static void C_fcall f_12624(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_12657)
static void C_ccall f_12657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12690)
static void C_ccall f_12690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12673)
static void C_ccall f_12673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12677)
static void C_ccall f_12677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12542)
static void C_fcall f_12542(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_12575)
static void C_ccall f_12575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12605)
static void C_ccall f_12605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12520)
static void C_ccall f_12520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12462)
static void C_fcall f_12462(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12457)
static void C_ccall f_12457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11841)
static void C_ccall f_11841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11848)
static void C_ccall f_11848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11825)
static void C_ccall f_11825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18695)
static void C_fcall f_18695(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16736)
static void C_ccall f_16736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16748)
static void C_fcall f_16748(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18683)
static void C_ccall f_18683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18602)
static void C_ccall f_18602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18635)
static void C_ccall f_18635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18642)
static void C_fcall f_18642(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18603)
static void C_ccall f_18603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18610)
static void C_ccall f_18610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18506)
static void C_ccall f_18506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18513)
static void C_fcall f_18513(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18448)
static void C_ccall f_18448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18467)
static void C_fcall f_18467(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18455)
static void C_fcall f_18455(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18414)
static void C_ccall f_18414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18424)
static void C_fcall f_18424(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18390)
static void C_ccall f_18390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18332)
static void C_ccall f_18332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18351)
static void C_fcall f_18351(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18339)
static void C_fcall f_18339(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18298)
static void C_ccall f_18298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18308)
static void C_fcall f_18308(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18278)
static void C_ccall f_18278(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18236)
static void C_ccall f_18236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18243)
static void C_fcall f_18243(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18208)
static void C_ccall f_18208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16794)
static void C_fcall f_16794(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18160)
static void C_ccall f_18160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18120)
static void C_ccall f_18120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18132)
static void C_ccall f_18132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18090)
static void C_ccall f_18090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18091)
static void C_ccall f_18091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18103)
static void C_ccall f_18103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17963)
static void C_ccall f_17963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18019)
static void C_ccall f_18019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17967)
static void C_ccall f_17967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17971)
static void C_ccall f_17971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18005)
static void C_ccall f_18005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17989)
static void C_ccall f_17989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17821)
static void C_ccall f_17821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17824)
static void C_ccall f_17824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17931)
static void C_ccall f_17931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17926)
static void C_ccall f_17926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17922)
static void C_ccall f_17922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17827)
static void C_ccall f_17827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17836)
static void C_fcall f_17836(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17882)
static void C_ccall f_17882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17883)
static void C_ccall f_17883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17889)
static void C_ccall f_17889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17839)
static void C_ccall f_17839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17840)
static void C_ccall f_17840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17807)
static void C_ccall f_17807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17784)
static void C_ccall f_17784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17785)
static void C_ccall f_17785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17800)
static void C_ccall f_17800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17789)
static void C_ccall f_17789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17766)
static void C_ccall f_17766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17735)
static void C_ccall f_17735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17736)
static void C_ccall f_17736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17757)
static void C_ccall f_17757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17759)
static void C_ccall f_17759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17753)
static void C_ccall f_17753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17717)
static void C_ccall f_17717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17686)
static void C_ccall f_17686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17687)
static void C_ccall f_17687(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17708)
static void C_ccall f_17708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17710)
static void C_ccall f_17710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17704)
static void C_ccall f_17704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17672)
static void C_ccall f_17672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17649)
static void C_ccall f_17649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17650)
static void C_ccall f_17650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17665)
static void C_ccall f_17665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17657)
static void C_ccall f_17657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17635)
static void C_ccall f_17635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17612)
static void C_ccall f_17612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17613)
static void C_ccall f_17613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17628)
static void C_ccall f_17628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17620)
static void C_ccall f_17620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17599)
static void C_ccall f_17599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17574)
static void C_ccall f_17574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17509)
static void C_ccall f_17509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17322)
static void C_fcall f_17322(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17325)
static void C_fcall f_17325(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17348)
static void C_ccall f_17348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17414)
static void C_ccall f_17414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17398)
static void C_ccall f_17398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_17351)
static void C_ccall f_17351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17383)
static void C_ccall f_17383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17378)
static void C_ccall f_17378(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_17372)
static void C_ccall f_17372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17368)
static void C_ccall f_17368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17326)
static void C_ccall f_17326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17303)
static void C_ccall f_17303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17270)
static void C_ccall f_17270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17221)
static void C_ccall f_17221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17158)
static void C_ccall f_17158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17182)
static void C_ccall f_17182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17188)
static void C_ccall f_17188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17165)
static void C_ccall f_17165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17166)
static void C_ccall f_17166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17172)
static void C_ccall f_17172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17100)
static void C_ccall f_17100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17124)
static void C_ccall f_17124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17130)
static void C_ccall f_17130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17107)
static void C_ccall f_17107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17108)
static void C_ccall f_17108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17114)
static void C_ccall f_17114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17069)
static void C_ccall f_17069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17070)
static void C_ccall f_17070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17076)
static void C_ccall f_17076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17041)
static void C_ccall f_17041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17042)
static void C_ccall f_17042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17048)
static void C_ccall f_17048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17020)
static void C_ccall f_17020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17001)
static void C_ccall f_17001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16963)
static void C_ccall f_16963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16942)
static void C_ccall f_16942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16921)
static void C_ccall f_16921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16900)
static void C_ccall f_16900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16841)
static void C_ccall f_16841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16867)
static void C_ccall f_16867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16844)
static void C_ccall f_16844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16845)
static void C_ccall f_16845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16851)
static void C_ccall f_16851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16821)
static void C_ccall f_16821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16805)
static void C_ccall f_16805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16801)
static void C_ccall f_16801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16782)
static void C_ccall f_16782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16774)
static void C_ccall f_16774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16751)
static void C_fcall f_16751(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16745)
static void C_ccall f_16745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_11834)
static void C_ccall f_11834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11775)
static void C_ccall f_11775(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11775)
static void C_ccall f_11775r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11783)
static void C_ccall f_11783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11754)
static void C_ccall f_11754(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11754)
static void C_ccall f_11754r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11761)
static void C_ccall f_11761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11304)
static void C_fcall f_11304(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11310)
static void C_fcall f_11310(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11398)
static void C_ccall f_11398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11401)
static void C_ccall f_11401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10463)
static void C_ccall f_10463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10466)
static void C_ccall f_10466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11167)
static void C_ccall f_11167(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11165)
static void C_ccall f_11165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11145)
static void C_ccall f_11145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11141)
static void C_ccall f_11141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11059)
static void C_ccall f_11059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11137)
static void C_ccall f_11137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11133)
static void C_ccall f_11133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11129)
static void C_ccall f_11129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11125)
static void C_ccall f_11125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11101)
static void C_ccall f_11101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11077)
static void C_ccall f_11077(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11075)
static void C_ccall f_11075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10967)
static void C_ccall f_10967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11041)
static void C_ccall f_11041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10989)
static void C_ccall f_10989(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10987)
static void C_ccall f_10987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10959)
static void C_ccall f_10959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10487)
static void C_ccall f_10487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10492)
static void C_fcall f_10492(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10564)
static void C_ccall f_10564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11242)
static void C_fcall f_11242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11248)
static void C_ccall f_11248(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11246)
static void C_ccall f_11246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10572)
static void C_ccall f_10572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10549)
static void C_ccall f_10549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10553)
static void C_ccall f_10553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10520)
static void C_ccall f_10520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11416)
static void C_ccall f_11416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11358)
static void C_ccall f_11358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11328)
static void C_ccall f_11328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11346)
static void C_ccall f_11346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11332)
static void C_fcall f_11332(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11324)
static void C_ccall f_11324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10820)
static void C_fcall f_10820(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10938)
static void C_ccall f_10938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10930)
static void C_ccall f_10930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10922)
static void C_ccall f_10922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10890)
static void C_ccall f_10890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10918)
static void C_ccall f_10918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10886)
static void C_ccall f_10886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10842)
static void C_ccall f_10842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10840)
static void C_ccall f_10840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10692)
static void C_fcall f_10692(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10810)
static void C_ccall f_10810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10802)
static void C_ccall f_10802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10794)
static void C_ccall f_10794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10762)
static void C_ccall f_10762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10790)
static void C_ccall f_10790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10758)
static void C_ccall f_10758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10714)
static void C_ccall f_10714(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10712)
static void C_ccall f_10712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10606)
static void C_fcall f_10606(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10640)
static void C_ccall f_10640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10648)
static void C_ccall f_10648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10658)
static void C_ccall f_10658(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10656)
static void C_ccall f_10656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10652)
static void C_ccall f_10652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10636)
static void C_ccall f_10636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10330)
static void C_fcall f_10330(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10454)
static void C_ccall f_10454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10418)
static void C_ccall f_10418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10450)
static void C_ccall f_10450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10446)
static void C_ccall f_10446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10422)
static void C_ccall f_10422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10442)
static void C_ccall f_10442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10438)
static void C_ccall f_10438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10426)
static void C_ccall f_10426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10434)
static void C_ccall f_10434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10430)
static void C_ccall f_10430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10405)
static void C_ccall f_10405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10381)
static void C_ccall f_10381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10401)
static void C_ccall f_10401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10397)
static void C_ccall f_10397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10385)
static void C_ccall f_10385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10393)
static void C_ccall f_10393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10389)
static void C_ccall f_10389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10368)
static void C_ccall f_10368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10356)
static void C_ccall f_10356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10364)
static void C_ccall f_10364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10360)
static void C_ccall f_10360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10270)
static void C_fcall f_10270(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10045)
static void C_fcall f_10045(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10220)
static void C_ccall f_10220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10172)
static void C_ccall f_10172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10208)
static void C_ccall f_10208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10176)
static void C_ccall f_10176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10196)
static void C_ccall f_10196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10180)
static void C_ccall f_10180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10184)
static void C_ccall f_10184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10168)
static void C_ccall f_10168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10151)
static void C_ccall f_10151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10119)
static void C_ccall f_10119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10139)
static void C_ccall f_10139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10123)
static void C_ccall f_10123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10127)
static void C_ccall f_10127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10115)
static void C_ccall f_10115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10098)
static void C_ccall f_10098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10082)
static void C_ccall f_10082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10086)
static void C_ccall f_10086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10048)
static C_word C_fcall f_10048(C_word t0,C_word t1);
C_noret_decl(f_10035)
static C_word C_fcall f_10035(C_word t0);
C_noret_decl(f_10025)
static void C_ccall f_10025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9233)
static void C_fcall f_9233(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9300)
static void C_ccall f_9300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9303)
static void C_ccall f_9303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5383)
static void C_fcall f_5383(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9252)
static void C_ccall f_9252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9264)
static void C_ccall f_9264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9267)
static void C_ccall f_9267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9191)
static C_word C_fcall f_9191(C_word t0);
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6289)
static void C_ccall f_6289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6294)
static void C_fcall f_6294(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_9140)
static void C_ccall f_9140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9143)
static void C_ccall f_9143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9161)
static void C_ccall f_9161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9106)
static void C_ccall f_9106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9121)
static void C_ccall f_9121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9094)
static void C_ccall f_9094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9091)
static void C_ccall f_9091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9063)
static void C_ccall f_9063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9060)
static void C_ccall f_9060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9032)
static void C_ccall f_9032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8999)
static void C_ccall f_8999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8981)
static void C_ccall f_8981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5441)
static void C_fcall f_5441(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8889)
static void C_ccall f_8889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8932)
static void C_ccall f_8932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8925)
static void C_ccall f_8925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8921)
static void C_ccall f_8921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8913)
static void C_ccall f_8913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8909)
static void C_ccall f_8909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8775)
static void C_ccall f_8775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8784)
static void C_fcall f_8784(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8846)
static void C_ccall f_8846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8691)
static void C_fcall f_8691(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8694)
static void C_ccall f_8694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8697)
static void C_ccall f_8697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8747)
static void C_ccall f_8747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8744)
static void C_ccall f_8744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8736)
static void C_ccall f_8736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8732)
static void C_ccall f_8732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8666)
static void C_ccall f_8666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8638)
static void C_ccall f_8638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8662)
static void C_ccall f_8662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8658)
static void C_ccall f_8658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8627)
static void C_ccall f_8627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8623)
static void C_ccall f_8623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8598)
static void C_ccall f_8598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8594)
static void C_ccall f_8594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8569)
static void C_ccall f_8569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8565)
static void C_ccall f_8565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8540)
static void C_ccall f_8540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8536)
static void C_ccall f_8536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8511)
static void C_ccall f_8511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8507)
static void C_ccall f_8507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8478)
static void C_ccall f_8478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8474)
static void C_ccall f_8474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8441)
static void C_ccall f_8441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8437)
static void C_ccall f_8437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8412)
static void C_ccall f_8412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8408)
static void C_ccall f_8408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8375)
static void C_ccall f_8375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8371)
static void C_ccall f_8371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8322)
static void C_ccall f_8322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8318)
static void C_ccall f_8318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8277)
static void C_ccall f_8277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8273)
static void C_ccall f_8273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8240)
static void C_ccall f_8240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8236)
static void C_ccall f_8236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8207)
static void C_ccall f_8207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8203)
static void C_ccall f_8203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8174)
static void C_ccall f_8174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8170)
static void C_ccall f_8170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8141)
static void C_ccall f_8141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8137)
static void C_ccall f_8137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8071)
static void C_fcall f_8071(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7890)
static void C_fcall f_7890(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7900)
static void C_ccall f_7900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7909)
static void C_ccall f_7909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8053)
static void C_ccall f_8053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5482)
static void C_fcall f_5482(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5485)
static void C_fcall f_5485(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7912)
static void C_ccall f_7912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7915)
static void C_ccall f_7915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7921)
static void C_ccall f_7921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8019)
static void C_ccall f_8019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7984)
static void C_ccall f_7984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7950)
static void C_ccall f_7950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9344)
static void C_ccall f_9344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10016)
static void C_ccall f_10016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9346)
static void C_fcall f_9346(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9963)
static void C_ccall f_9963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9981)
static void C_ccall f_9981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9833)
static void C_fcall f_9833(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9890)
static void C_ccall f_9890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9878)
static void C_ccall f_9878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9863)
static void C_ccall f_9863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9836)
static void C_ccall f_9836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9859)
static void C_ccall f_9859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9847)
static void C_ccall f_9847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9855)
static void C_ccall f_9855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9851)
static void C_ccall f_9851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9700)
static void C_ccall f_9700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9709)
static void C_fcall f_9709(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9752)
static void C_ccall f_9752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9748)
static void C_ccall f_9748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9715)
static void C_ccall f_9715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9718)
static void C_ccall f_9718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9741)
static void C_ccall f_9741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9729)
static void C_ccall f_9729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9737)
static void C_ccall f_9737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9733)
static void C_ccall f_9733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9648)
static void C_fcall f_9648(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9496)
static void C_fcall f_9496(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9576)
static void C_fcall f_9576(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9589)
static void C_ccall f_9589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9599)
static void C_ccall f_9599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9603)
static void C_ccall f_9603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9559)
static void C_ccall f_9559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9527)
static void C_ccall f_9527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9385)
static void C_ccall f_9385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9388)
static void C_ccall f_9388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5987)
static void C_fcall f_5987(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6011)
static void C_ccall f_6011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6008)
static void C_fcall f_6008(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9391)
static void C_ccall f_9391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9464)
static void C_ccall f_9464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9468)
static void C_ccall f_9468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9460)
static void C_ccall f_9460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9456)
static void C_ccall f_9456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9411)
static void C_fcall f_9411(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9439)
static void C_ccall f_9439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9421)
static void C_ccall f_9421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18795)
static void C_fcall f_18795(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9432)
static void C_ccall f_9432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9415)
static void C_fcall f_9415(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9398)
static void C_ccall f_9398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7871)
static void C_ccall f_7871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7847)
static void C_ccall f_7847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7867)
static void C_ccall f_7867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7832)
static void C_ccall f_7832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7097)
static void C_ccall f_7097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7101)
static void C_ccall f_7101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7566)
static void C_fcall f_7566(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7751)
static void C_ccall f_7751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7763)
static void C_ccall f_7763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7730)
static void C_ccall f_7730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7726)
static void C_ccall f_7726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7681)
static void C_ccall f_7681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7661)
static void C_ccall f_7661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7644)
static void C_ccall f_7644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7627)
static void C_ccall f_7627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7578)
static void C_fcall f_7578(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7582)
static void C_ccall f_7582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7585)
static void C_ccall f_7585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7569)
static void C_fcall f_7569(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7524)
static void C_ccall f_7524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7528)
static void C_ccall f_7528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7467)
static void C_ccall f_7467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7501)
static void C_ccall f_7501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7470)
static void C_ccall f_7470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7485)
static void C_ccall f_7485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7493)
static void C_ccall f_7493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7407)
static void C_ccall f_7407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7450)
static void C_ccall f_7450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7410)
static void C_ccall f_7410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7434)
static void C_ccall f_7434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7442)
static void C_ccall f_7442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7379)
static void C_ccall f_7379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7383)
static void C_ccall f_7383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7287)
static void C_ccall f_7287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7305)
static void C_ccall f_7305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7325)
static void C_ccall f_7325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7317)
static void C_ccall f_7317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7313)
static void C_ccall f_7313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7280)
static void C_ccall f_7280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7284)
static void C_ccall f_7284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7255)
static void C_ccall f_7255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7259)
static void C_ccall f_7259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7212)
static void C_ccall f_7212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7216)
static void C_ccall f_7216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7187)
static void C_ccall f_7187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7191)
static void C_ccall f_7191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7162)
static void C_ccall f_7162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7166)
static void C_ccall f_7166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7122)
static void C_ccall f_7122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7137)
static void C_ccall f_7137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7010)
static void C_ccall f_7010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7016)
static void C_ccall f_7016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7031)
static void C_ccall f_7031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6813)
static void C_ccall f_6813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6980)
static void C_ccall f_6980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6951)
static void C_ccall f_6951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6926)
static void C_ccall f_6926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6909)
static void C_ccall f_6909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6892)
static void C_ccall f_6892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6844)
static void C_fcall f_6844(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6804)
static void C_ccall f_6804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6801)
static void C_ccall f_6801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6739)
static void C_fcall f_6739(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6751)
static void C_ccall f_6751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6439)
static void C_fcall f_6439(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6443)
static void C_ccall f_6443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6446)
static void C_fcall f_6446(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6699)
static void C_fcall f_6699(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6710)
static void C_ccall f_6710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6449)
static void C_fcall f_6449(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6692)
static void C_ccall f_6692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6681)
static void C_ccall f_6681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6452)
static void C_ccall f_6452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6457)
static void C_fcall f_6457(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6621)
static void C_ccall f_6621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6559)
static void C_fcall f_6559(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6526)
static void C_fcall f_6526(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6460)
static C_word C_fcall f_6460(C_word *a,C_word t0);
C_noret_decl(f_6367)
static void C_fcall f_6367(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6371)
static void C_ccall f_6371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10235)
static void C_fcall f_10235(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6374)
static void C_ccall f_6374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6383)
static void C_ccall f_6383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6407)
static void C_ccall f_6407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6403)
static void C_ccall f_6403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6347)
static void C_fcall f_6347(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6365)
static void C_ccall f_6365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6361)
static void C_ccall f_6361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6327)
static void C_fcall f_6327(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6334)
static void C_ccall f_6334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6345)
static void C_ccall f_6345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6341)
static void C_ccall f_6341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6322)
static void C_ccall f_6322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6182)
static void C_fcall f_6182(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6188)
static void C_fcall f_6188(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6219)
static void C_fcall f_6219(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6213)
static void C_fcall f_6213(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6206)
static void C_ccall f_6206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6163)
static void C_ccall f_6163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6154)
static void C_ccall f_6154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6144)
static void C_fcall f_6144(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6152)
static void C_ccall f_6152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6097)
static void C_fcall f_6097(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6129)
static void C_ccall f_6129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6133)
static void C_ccall f_6133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6050)
static void C_fcall f_6050(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6082)
static void C_ccall f_6082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6086)
static void C_ccall f_6086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6078)
static void C_ccall f_6078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6034)
static void C_fcall f_6034(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6042)
static void C_ccall f_6042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6024)
static void C_fcall f_6024(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6032)
static void C_ccall f_6032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5938)
static void C_fcall f_5938(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5944)
static void C_fcall f_5944(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5968)
static void C_ccall f_5968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5965)
static void C_fcall f_5965(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5908)
static void C_fcall f_5908(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5914)
static void C_fcall f_5914(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5932)
static void C_ccall f_5932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5859)
static void C_fcall f_5859(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5879)
static void C_fcall f_5879(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5895)
static void C_ccall f_5895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5810)
static void C_fcall f_5810(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5830)
static void C_fcall f_5830(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5843)
static void C_ccall f_5843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5768)
static void C_fcall f_5768(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5783)
static C_word C_fcall f_5783(C_word t0);
C_noret_decl(f_5736)
static void C_fcall f_5736(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5742)
static void C_fcall f_5742(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5755)
static void C_ccall f_5755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5724)
static void C_fcall f_5724(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5728)
static void C_ccall f_5728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5681)
static void C_fcall f_5681(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5687)
static void C_fcall f_5687(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5694)
static void C_fcall f_5694(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5642)
static void C_fcall f_5642(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5658)
static void C_fcall f_5658(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5585)
static void C_fcall f_5585(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5595)
static void C_ccall f_5595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5614)
static void C_fcall f_5614(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5558)
static void C_fcall f_5558(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5633)
static void C_ccall f_5633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5612)
static void C_ccall f_5612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5540)
static C_word C_fcall f_5540(C_word t0);
C_noret_decl(f_5325)
static void C_fcall f_5325(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5338)
static void C_fcall f_5338(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5310)
static void C_ccall f_5310(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5310)
static void C_ccall f_5310r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5318)
static void C_ccall f_5318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5287)
static void C_ccall f_5287(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5287)
static void C_ccall f_5287r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5291)
static void C_ccall f_5291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5248)
static void C_ccall f_5248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5212)
static C_word C_fcall f_5212(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_5166)
static void C_fcall f_5166(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5152)
static C_word C_fcall f_5152(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5138)
static C_word C_fcall f_5138(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5124)
static C_word C_fcall f_5124(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_5110)
static C_word C_fcall f_5110(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_5104)
static C_word C_fcall f_5104(C_word t0,C_word t1);
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5082)
static void C_ccall f_5082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4997)
static void C_fcall f_4997(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4943)
static void C_ccall f_4943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4899)
static void C_ccall f_4899(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4893)
static C_word C_fcall f_4893(C_word *a,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7);

C_noret_decl(trf_21598)
static void C_fcall trf_21598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21598(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_21598(t0,t1,t2);}

C_noret_decl(trf_21552)
static void C_fcall trf_21552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21552(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_21552(t0,t1,t2);}

C_noret_decl(trf_21283)
static void C_fcall trf_21283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21283(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_21283(t0,t1,t2);}

C_noret_decl(trf_21345)
static void C_fcall trf_21345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21345(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_21345(t0,t1,t2);}

C_noret_decl(trf_21375)
static void C_fcall trf_21375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21375(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_21375(t0,t1);}

C_noret_decl(trf_21404)
static void C_fcall trf_21404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21404(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_21404(t0,t1);}

C_noret_decl(trf_21194)
static void C_fcall trf_21194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21194(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_21194(t0,t1,t2);}

C_noret_decl(trf_21213)
static void C_fcall trf_21213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21213(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_21213(t0,t1);}

C_noret_decl(trf_21144)
static void C_fcall trf_21144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21144(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_21144(t0,t1,t2,t3);}

C_noret_decl(trf_21016)
static void C_fcall trf_21016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21016(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_21016(t0,t1,t2,t3);}

C_noret_decl(trf_20910)
static void C_fcall trf_20910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20910(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20910(t0,t1,t2);}

C_noret_decl(trf_20916)
static void C_fcall trf_20916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20916(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20916(t0,t1,t2,t3);}

C_noret_decl(trf_20711)
static void C_fcall trf_20711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20711(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20711(t0,t1);}

C_noret_decl(trf_20719)
static void C_fcall trf_20719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20719(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20719(t0,t1,t2,t3);}

C_noret_decl(trf_20647)
static void C_fcall trf_20647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20647(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20647(t0,t1);}

C_noret_decl(trf_20638)
static void C_fcall trf_20638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20638(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20638(t0,t1,t2);}

C_noret_decl(trf_20574)
static void C_fcall trf_20574(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20574(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20574(t0,t1,t2,t3);}

C_noret_decl(trf_20599)
static void C_fcall trf_20599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20599(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20599(t0,t1,t2,t3);}

C_noret_decl(trf_20527)
static void C_fcall trf_20527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20527(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20527(t0,t1);}

C_noret_decl(trf_20518)
static void C_fcall trf_20518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20518(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20518(t0,t1,t2);}

C_noret_decl(trf_20462)
static void C_fcall trf_20462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20462(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20462(t0,t1,t2,t3);}

C_noret_decl(trf_20487)
static void C_fcall trf_20487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20487(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20487(t0,t1,t2,t3);}

C_noret_decl(trf_20417)
static void C_fcall trf_20417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20417(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20417(t0,t1,t2,t3);}

C_noret_decl(trf_20371)
static void C_fcall trf_20371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20371(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20371(t0,t1,t2,t3);}

C_noret_decl(trf_20331)
static void C_fcall trf_20331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20331(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20331(t0,t1);}

C_noret_decl(trf_20271)
static void C_fcall trf_20271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20271(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20271(t0,t1);}

C_noret_decl(trf_20266)
static void C_fcall trf_20266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20266(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20266(t0,t1,t2);}

C_noret_decl(trf_20261)
static void C_fcall trf_20261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20261(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20261(t0,t1,t2,t3);}

C_noret_decl(trf_20230)
static void C_fcall trf_20230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20230(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_20230(t0,t1,t2,t3,t4);}

C_noret_decl(trf_20242)
static void C_fcall trf_20242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20242(t0,t1);}

C_noret_decl(trf_20245)
static void C_fcall trf_20245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20245(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20245(t0,t1);}

C_noret_decl(trf_20248)
static void C_fcall trf_20248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20248(t0,t1);}

C_noret_decl(trf_20034)
static void C_fcall trf_20034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20034(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20034(t0,t1,t2,t3);}

C_noret_decl(trf_20016)
static void C_fcall trf_20016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20016(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20016(t0,t1);}

C_noret_decl(trf_19993)
static void C_fcall trf_19993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19993(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19993(t0,t1);}

C_noret_decl(trf_19897)
static void C_fcall trf_19897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19897(t0,t1);}

C_noret_decl(trf_19868)
static void C_fcall trf_19868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19868(t0,t1);}

C_noret_decl(trf_19831)
static void C_fcall trf_19831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19831(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19831(t0,t1,t2,t3);}

C_noret_decl(trf_19648)
static void C_fcall trf_19648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19648(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19648(t0,t1,t2,t3);}

C_noret_decl(trf_19664)
static void C_fcall trf_19664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19664(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19664(t0,t1);}

C_noret_decl(trf_19701)
static void C_fcall trf_19701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19701(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19701(t0,t1);}

C_noret_decl(trf_19632)
static void C_fcall trf_19632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19632(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19632(t0,t1);}

C_noret_decl(trf_19520)
static void C_fcall trf_19520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19520(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_19520(t0,t1,t2,t3,t4);}

C_noret_decl(trf_19393)
static void C_fcall trf_19393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19393(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19393(t0,t1,t2);}

C_noret_decl(trf_19161)
static void C_fcall trf_19161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19161(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19161(t0,t1,t2);}

C_noret_decl(trf_19177)
static void C_fcall trf_19177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19177(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19177(t0,t1);}

C_noret_decl(trf_19111)
static void C_fcall trf_19111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19111(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19111(t0,t1,t2);}

C_noret_decl(trf_18830)
static void C_fcall trf_18830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18830(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_18830(t0,t1,t2);}

C_noret_decl(trf_18840)
static void C_fcall trf_18840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18840(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_18840(t0,t1,t2,t3);}

C_noret_decl(trf_13588)
static void C_fcall trf_13588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13588(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_13588(t0,t1,t2,t3);}

C_noret_decl(trf_18754)
static void C_fcall trf_18754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18754(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_18754(t0,t1,t2,t3);}

C_noret_decl(trf_18713)
static void C_fcall trf_18713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18713(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_18713(t0,t1,t2);}

C_noret_decl(trf_16349)
static void C_fcall trf_16349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16349(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_16349(t0,t1,t2);}

C_noret_decl(trf_16268)
static void C_fcall trf_16268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16268(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_16268(t0,t1,t2);}

C_noret_decl(trf_16274)
static void C_fcall trf_16274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16274(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_16274(t0,t1,t2,t3);}

C_noret_decl(trf_16152)
static void C_fcall trf_16152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16152(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_16152(t0,t1,t2);}

C_noret_decl(trf_16185)
static void C_fcall trf_16185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16185(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16185(t0,t1);}

C_noret_decl(trf_16189)
static void C_fcall trf_16189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16189(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16189(t0,t1);}

C_noret_decl(trf_16197)
static void C_fcall trf_16197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16197(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16197(t0,t1);}

C_noret_decl(trf_16078)
static void C_fcall trf_16078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16078(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_16078(t0,t1,t2);}

C_noret_decl(trf_16086)
static void C_fcall trf_16086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16086(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16086(t0,t1);}

C_noret_decl(trf_16090)
static void C_fcall trf_16090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16090(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16090(t0,t1);}

C_noret_decl(trf_15604)
static void C_fcall trf_15604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15604(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15604(t0,t1,t2);}

C_noret_decl(trf_15813)
static void C_fcall trf_15813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15813(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_15813(t0,t1,t2,t3);}

C_noret_decl(trf_15841)
static void C_fcall trf_15841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15841(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15841(t0,t1);}

C_noret_decl(trf_15998)
static void C_fcall trf_15998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15998(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15998(t0,t1);}

C_noret_decl(trf_15899)
static void C_fcall trf_15899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15899(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15899(t0,t1);}

C_noret_decl(trf_15917)
static void C_fcall trf_15917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15917(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15917(t0,t1);}

C_noret_decl(trf_15920)
static void C_fcall trf_15920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15920(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15920(t0,t1);}

C_noret_decl(trf_15635)
static void C_fcall trf_15635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15635(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_15635(t0,t1,t2,t3);}

C_noret_decl(trf_15684)
static void C_fcall trf_15684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15684(t0,t1);}

C_noret_decl(trf_15705)
static void C_fcall trf_15705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15705(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15705(t0,t1);}

C_noret_decl(trf_15709)
static void C_fcall trf_15709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15709(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15709(t0,t1);}

C_noret_decl(trf_15607)
static void C_fcall trf_15607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15607(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_15607(t0,t1,t2,t3);}

C_noret_decl(trf_15307)
static void C_fcall trf_15307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15307(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15307(t0,t1,t2);}

C_noret_decl(trf_15320)
static void C_fcall trf_15320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15320(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_15320(t0,t1,t2,t3,t4);}

C_noret_decl(trf_15515)
static void C_fcall trf_15515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15515(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_15515(t0,t1,t2,t3,t4);}

C_noret_decl(trf_15365)
static void C_fcall trf_15365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15365(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15365(t0,t1);}

C_noret_decl(trf_14517)
static void C_fcall trf_14517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14517(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14517(t0,t1,t2);}

C_noret_decl(trf_14535)
static void C_fcall trf_14535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14535(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_14535(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_14798)
static void C_fcall trf_14798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14798(t0,t1);}

C_noret_decl(trf_14852)
static void C_fcall trf_14852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14852(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14852(t0,t1);}

C_noret_decl(trf_15127)
static void C_fcall trf_15127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15127(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15127(t0,t1);}

C_noret_decl(trf_14648)
static void C_fcall trf_14648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14648(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14648(t0,t1);}

C_noret_decl(trf_14552)
static void C_fcall trf_14552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14552(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_14552(t0,t1,t2,t3);}

C_noret_decl(trf_14538)
static void C_fcall trf_14538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14538(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14538(t0,t1,t2);}

C_noret_decl(trf_14410)
static void C_fcall trf_14410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14410(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_14410(t0,t1,t2,t3,t4);}

C_noret_decl(trf_14424)
static void C_fcall trf_14424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14424(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_14424(t0,t1,t2,t3,t4);}

C_noret_decl(trf_14201)
static void C_fcall trf_14201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14201(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14201(t0,t1,t2);}

C_noret_decl(trf_14331)
static void C_fcall trf_14331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14331(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_14331(t0,t1,t2,t3);}

C_noret_decl(trf_14131)
static void C_fcall trf_14131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14131(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14131(t0,t1,t2);}

C_noret_decl(trf_14049)
static void C_fcall trf_14049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14049(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14049(t0,t1);}

C_noret_decl(trf_13929)
static void C_fcall trf_13929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13929(t0,t1);}

C_noret_decl(trf_13874)
static void C_fcall trf_13874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13874(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_13874(t0,t1,t2,t3);}

C_noret_decl(trf_13644)
static void C_fcall trf_13644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13644(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_13644(t0,t1,t2,t3);}

C_noret_decl(trf_13742)
static void C_fcall trf_13742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13742(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13742(t0,t1);}

C_noret_decl(trf_12384)
static void C_fcall trf_12384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12384(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12384(t0,t1);}

C_noret_decl(trf_12415)
static void C_fcall trf_12415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12415(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12415(t0,t1);}

C_noret_decl(trf_12311)
static void C_fcall trf_12311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12311(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12311(t0,t1);}

C_noret_decl(trf_12225)
static void C_fcall trf_12225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12225(t0,t1);}

C_noret_decl(trf_12079)
static void C_fcall trf_12079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12079(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12079(t0,t1);}

C_noret_decl(trf_11945)
static void C_fcall trf_11945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11945(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11945(t0,t1);}

C_noret_decl(trf_11994)
static void C_fcall trf_11994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11994(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11994(t0,t1);}

C_noret_decl(trf_11478)
static void C_fcall trf_11478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11478(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_11478(t0,t1,t2,t3,t4);}

C_noret_decl(trf_11591)
static void C_fcall trf_11591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11591(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11591(t0,t1);}

C_noret_decl(trf_11801)
static void C_fcall trf_11801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11801(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11801(t0,t1);}

C_noret_decl(trf_16405)
static void C_fcall trf_16405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16405(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_16405(t0,t1,t2,t3,t4);}

C_noret_decl(trf_16688)
static void C_fcall trf_16688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16688(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16688(t0,t1);}

C_noret_decl(trf_16466)
static void C_fcall trf_16466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16466(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_16466(t0,t1,t2,t3);}

C_noret_decl(trf_12459)
static void C_fcall trf_12459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12459(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_12459(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_12504)
static void C_fcall trf_12504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12504(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12504(t0,t1);}

C_noret_decl(trf_12533)
static void C_fcall trf_12533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12533(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12533(t0,t1);}

C_noret_decl(trf_13263)
static void C_fcall trf_13263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13263(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13263(t0,t1);}

C_noret_decl(trf_13313)
static void C_fcall trf_13313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13313(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13313(t0,t1);}

C_noret_decl(trf_13062)
static void C_fcall trf_13062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13062(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13062(t0,t1);}

C_noret_decl(trf_13065)
static void C_fcall trf_13065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13065(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13065(t0,t1);}

C_noret_decl(trf_13095)
static void C_fcall trf_13095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13095(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13095(t0,t1);}

C_noret_decl(trf_12929)
static void C_fcall trf_12929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12929(t0,t1);}

C_noret_decl(trf_12709)
static void C_fcall trf_12709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12709(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12709(t0,t1);}

C_noret_decl(trf_12800)
static void C_fcall trf_12800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12800(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12800(t0,t1);}

C_noret_decl(trf_12767)
static void C_fcall trf_12767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12767(t0,t1);}

C_noret_decl(trf_12624)
static void C_fcall trf_12624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12624(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_12624(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_12542)
static void C_fcall trf_12542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12542(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_12542(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_12462)
static void C_fcall trf_12462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12462(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12462(t0,t1,t2);}

C_noret_decl(trf_18695)
static void C_fcall trf_18695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18695(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18695(t0,t1);}

C_noret_decl(trf_16748)
static void C_fcall trf_16748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16748(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_16748(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_18642)
static void C_fcall trf_18642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18642(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18642(t0,t1);}

C_noret_decl(trf_18513)
static void C_fcall trf_18513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18513(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18513(t0,t1);}

C_noret_decl(trf_18467)
static void C_fcall trf_18467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18467(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18467(t0,t1);}

C_noret_decl(trf_18455)
static void C_fcall trf_18455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18455(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18455(t0,t1);}

C_noret_decl(trf_18424)
static void C_fcall trf_18424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18424(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18424(t0,t1);}

C_noret_decl(trf_18351)
static void C_fcall trf_18351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18351(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18351(t0,t1);}

C_noret_decl(trf_18339)
static void C_fcall trf_18339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18339(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18339(t0,t1);}

C_noret_decl(trf_18308)
static void C_fcall trf_18308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18308(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18308(t0,t1);}

C_noret_decl(trf_18243)
static void C_fcall trf_18243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18243(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18243(t0,t1);}

C_noret_decl(trf_16794)
static void C_fcall trf_16794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16794(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16794(t0,t1);}

C_noret_decl(trf_17836)
static void C_fcall trf_17836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17836(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17836(t0,t1);}

C_noret_decl(trf_17322)
static void C_fcall trf_17322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17322(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17322(t0,t1);}

C_noret_decl(trf_17325)
static void C_fcall trf_17325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17325(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17325(t0,t1);}

C_noret_decl(trf_16751)
static void C_fcall trf_16751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16751(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_16751(t0,t1,t2);}

C_noret_decl(trf_11304)
static void C_fcall trf_11304(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11304(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11304(t0,t1);}

C_noret_decl(trf_11310)
static void C_fcall trf_11310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11310(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_11310(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10492)
static void C_fcall trf_10492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10492(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10492(t0,t1,t2,t3);}

C_noret_decl(trf_11242)
static void C_fcall trf_11242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11242(t0,t1);}

C_noret_decl(trf_11332)
static void C_fcall trf_11332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11332(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11332(t0,t1);}

C_noret_decl(trf_10820)
static void C_fcall trf_10820(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10820(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10820(t0,t1);}

C_noret_decl(trf_10692)
static void C_fcall trf_10692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10692(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10692(t0,t1);}

C_noret_decl(trf_10606)
static void C_fcall trf_10606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10606(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10606(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10330)
static void C_fcall trf_10330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10330(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10330(t0,t1);}

C_noret_decl(trf_10270)
static void C_fcall trf_10270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10270(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10270(t0,t1);}

C_noret_decl(trf_10045)
static void C_fcall trf_10045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10045(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10045(t0,t1,t2,t3);}

C_noret_decl(trf_9233)
static void C_fcall trf_9233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9233(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9233(t0,t1,t2,t3);}

C_noret_decl(trf_5383)
static void C_fcall trf_5383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5383(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5383(t0,t1,t2);}

C_noret_decl(trf_6294)
static void C_fcall trf_6294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6294(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6294(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5441)
static void C_fcall trf_5441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5441(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5441(t0,t1,t2);}

C_noret_decl(trf_8784)
static void C_fcall trf_8784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8784(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8784(t0,t1,t2);}

C_noret_decl(trf_8691)
static void C_fcall trf_8691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8691(t0,t1);}

C_noret_decl(trf_8071)
static void C_fcall trf_8071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8071(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8071(t0,t1);}

C_noret_decl(trf_7890)
static void C_fcall trf_7890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7890(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7890(t0,t1);}

C_noret_decl(trf_5482)
static void C_fcall trf_5482(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5482(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5482(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5485)
static void C_fcall trf_5485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5485(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5485(t0,t1);}

C_noret_decl(trf_9346)
static void C_fcall trf_9346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9346(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9346(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9833)
static void C_fcall trf_9833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9833(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9833(t0,t1);}

C_noret_decl(trf_9709)
static void C_fcall trf_9709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9709(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9709(t0,t1);}

C_noret_decl(trf_9648)
static void C_fcall trf_9648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9648(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9648(t0,t1);}

C_noret_decl(trf_9496)
static void C_fcall trf_9496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9496(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9496(t0,t1);}

C_noret_decl(trf_9576)
static void C_fcall trf_9576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9576(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9576(t0,t1);}

C_noret_decl(trf_5987)
static void C_fcall trf_5987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5987(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5987(t0,t1,t2,t3);}

C_noret_decl(trf_6008)
static void C_fcall trf_6008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6008(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6008(t0,t1);}

C_noret_decl(trf_9411)
static void C_fcall trf_9411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9411(t0,t1);}

C_noret_decl(trf_18795)
static void C_fcall trf_18795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18795(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_18795(t0,t1,t2,t3);}

C_noret_decl(trf_9415)
static void C_fcall trf_9415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9415(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9415(t0,t1);}

C_noret_decl(trf_7566)
static void C_fcall trf_7566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7566(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7566(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7578)
static void C_fcall trf_7578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7578(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7578(t0,t1,t2);}

C_noret_decl(trf_7569)
static void C_fcall trf_7569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7569(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7569(t0,t1,t2);}

C_noret_decl(trf_6844)
static void C_fcall trf_6844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6844(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6844(t0,t1);}

C_noret_decl(trf_6739)
static void C_fcall trf_6739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6739(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6739(t0,t1);}

C_noret_decl(trf_6439)
static void C_fcall trf_6439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6439(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6439(t0,t1);}

C_noret_decl(trf_6446)
static void C_fcall trf_6446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6446(t0,t1);}

C_noret_decl(trf_6699)
static void C_fcall trf_6699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6699(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6699(t0,t1);}

C_noret_decl(trf_6449)
static void C_fcall trf_6449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6449(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6449(t0,t1);}

C_noret_decl(trf_6457)
static void C_fcall trf_6457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6457(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6457(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6559)
static void C_fcall trf_6559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6559(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6559(t0,t1);}

C_noret_decl(trf_6526)
static void C_fcall trf_6526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6526(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6526(t0,t1);}

C_noret_decl(trf_6367)
static void C_fcall trf_6367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6367(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6367(t0,t1);}

C_noret_decl(trf_10235)
static void C_fcall trf_10235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10235(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10235(t0,t1,t2);}

C_noret_decl(trf_6347)
static void C_fcall trf_6347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6347(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6347(t0,t1);}

C_noret_decl(trf_6327)
static void C_fcall trf_6327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6327(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6327(t0,t1,t2);}

C_noret_decl(trf_6182)
static void C_fcall trf_6182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6182(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6182(t0,t1);}

C_noret_decl(trf_6188)
static void C_fcall trf_6188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6188(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6188(t0,t1,t2,t3);}

C_noret_decl(trf_6219)
static void C_fcall trf_6219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6219(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6219(t0,t1);}

C_noret_decl(trf_6213)
static void C_fcall trf_6213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6213(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6213(t0,t1);}

C_noret_decl(trf_6144)
static void C_fcall trf_6144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6144(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6144(t0,t1,t2);}

C_noret_decl(trf_6097)
static void C_fcall trf_6097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6097(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6097(t0,t1,t2);}

C_noret_decl(trf_6050)
static void C_fcall trf_6050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6050(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6050(t0,t1,t2);}

C_noret_decl(trf_6034)
static void C_fcall trf_6034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6034(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6034(t0,t1,t2);}

C_noret_decl(trf_6024)
static void C_fcall trf_6024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6024(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6024(t0,t1,t2);}

C_noret_decl(trf_5938)
static void C_fcall trf_5938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5938(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5938(t0,t1,t2);}

C_noret_decl(trf_5944)
static void C_fcall trf_5944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5944(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5944(t0,t1,t2,t3);}

C_noret_decl(trf_5965)
static void C_fcall trf_5965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5965(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5965(t0,t1);}

C_noret_decl(trf_5908)
static void C_fcall trf_5908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5908(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5908(t0,t1,t2,t3);}

C_noret_decl(trf_5914)
static void C_fcall trf_5914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5914(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5914(t0,t1,t2,t3);}

C_noret_decl(trf_5859)
static void C_fcall trf_5859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5859(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5859(t0,t1,t2);}

C_noret_decl(trf_5879)
static void C_fcall trf_5879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5879(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5879(t0,t1,t2,t3);}

C_noret_decl(trf_5810)
static void C_fcall trf_5810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5810(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5810(t0,t1,t2);}

C_noret_decl(trf_5830)
static void C_fcall trf_5830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5830(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5830(t0,t1,t2,t3);}

C_noret_decl(trf_5768)
static void C_fcall trf_5768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5768(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5768(t0,t1);}

C_noret_decl(trf_5736)
static void C_fcall trf_5736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5736(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5736(t0,t1,t2);}

C_noret_decl(trf_5742)
static void C_fcall trf_5742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5742(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5742(t0,t1,t2);}

C_noret_decl(trf_5724)
static void C_fcall trf_5724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5724(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5724(t0,t1,t2);}

C_noret_decl(trf_5681)
static void C_fcall trf_5681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5681(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5681(t0,t1,t2);}

C_noret_decl(trf_5687)
static void C_fcall trf_5687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5687(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5687(t0,t1,t2,t3);}

C_noret_decl(trf_5694)
static void C_fcall trf_5694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5694(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5694(t0,t1);}

C_noret_decl(trf_5642)
static void C_fcall trf_5642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5642(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5642(t0,t1);}

C_noret_decl(trf_5658)
static void C_fcall trf_5658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5658(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5658(t0,t1,t2,t3);}

C_noret_decl(trf_5585)
static void C_fcall trf_5585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5585(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5585(t0,t1);}

C_noret_decl(trf_5614)
static void C_fcall trf_5614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5614(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5614(t0,t1,t2,t3);}

C_noret_decl(trf_5558)
static void C_fcall trf_5558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5558(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5558(t0,t1,t2,t3);}

C_noret_decl(trf_5325)
static void C_fcall trf_5325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5325(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5325(t0,t1,t2,t3);}

C_noret_decl(trf_5338)
static void C_fcall trf_5338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5338(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5338(t0,t1,t2);}

C_noret_decl(trf_5166)
static void C_fcall trf_5166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5166(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5166(t0,t1,t2);}

C_noret_decl(trf_4997)
static void C_fcall trf_4997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4997(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4997(t0,t1,t2);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_regex_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("regex_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2540)){
C_save(t1);
C_rereclaim2(2540*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,332);
lf[1]=C_h_intern(&lf[1],13,"*irregex-tag*");
lf[2]=C_h_intern(&lf[2],8,"irregex\077");
lf[3]=C_h_intern(&lf[3],11,"irregex-dfa");
lf[4]=C_h_intern(&lf[4],18,"irregex-dfa/search");
lf[5]=C_h_intern(&lf[5],19,"irregex-dfa/extract");
lf[6]=C_h_intern(&lf[6],11,"irregex-nfa");
lf[7]=C_h_intern(&lf[7],13,"irregex-flags");
lf[8]=C_h_intern(&lf[8],18,"irregex-submatches");
lf[9]=C_h_intern(&lf[9],15,"irregex-lengths");
lf[10]=C_h_intern(&lf[10],13,"irregex-names");
lf[11]=C_h_intern(&lf[11],19,"irregex-new-matches");
lf[12]=C_h_intern(&lf[12],19,"*irregex-match-tag*");
lf[13]=C_h_intern(&lf[13],11,"make-vector");
lf[14]=C_h_intern(&lf[14],22,"irregex-reset-matches!");
lf[15]=C_h_intern(&lf[15],19,"irregex-match-data\077");
lf[16]=C_h_intern(&lf[16],28,"irregex-match-num-submatches");
lf[17]=C_h_intern(&lf[17],20,"irregex-match-string");
lf[24]=C_h_intern(&lf[24],5,"error");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\022unknown match name");
lf[27]=C_h_intern(&lf[27],23,"irregex-match-substring");
lf[28]=C_h_intern(&lf[28],13,"\003syssubstring");
lf[29]=C_h_intern(&lf[29],19,"irregex-match-start");
lf[30]=C_h_intern(&lf[30],17,"irregex-match-end");
lf[31]=C_h_intern(&lf[31],1,"/");
lf[36]=C_h_intern(&lf[36],11,"make-string");
lf[40]=C_h_intern(&lf[40],7,"reverse");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\035can\047t take last of empty list");
lf[49]=C_h_intern(&lf[49],4,"expt");
lf[57]=C_h_intern(&lf[57],1,"i");
lf[58]=C_h_intern(&lf[58],1,"m");
lf[59]=C_h_intern(&lf[59],10,"multi-line");
lf[60]=C_h_intern(&lf[60],1,"s");
lf[61]=C_h_intern(&lf[61],11,"single-line");
lf[62]=C_h_intern(&lf[62],1,"x");
lf[63]=C_h_intern(&lf[63],12,"ignore-space");
lf[64]=C_h_intern(&lf[64],1,"u");
lf[65]=C_h_intern(&lf[65],4,"utf8");
lf[66]=C_h_intern(&lf[66],2,"ci");
lf[67]=C_h_intern(&lf[67],16,"case-insensitive");
lf[68]=C_h_intern(&lf[68],11,"string->sre");
lf[70]=C_h_intern(&lf[70],2,"or");
lf[72]=C_h_intern(&lf[72],7,"\003sysmap");
lf[73]=C_h_intern(&lf[73],16,"\003sysstring->list");
lf[76]=C_h_intern(&lf[76],8,"submatch");
lf[77]=C_h_intern(&lf[77],2,"if");
lf[78]=C_h_intern(&lf[78],10,"look-ahead");
lf[79]=C_h_intern(&lf[79],14,"neg-look-ahead");
lf[80]=C_h_intern(&lf[80],11,"look-behind");
lf[81]=C_h_intern(&lf[81],15,"neg-look-behind");
lf[82]=C_h_intern(&lf[82],3,"seq");
lf[83]=C_h_intern(&lf[83],7,"epsilon");
lf[84]=C_h_intern(&lf[84],10,"\003sysappend");
lf[85]=C_h_intern(&lf[85],14,"submatch-named");
lf[86]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006atomic\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\012look-ahead\376\003\000\000\002\376\001\000\000\016neg-look-ahead\376\003\000\000\002\376\001\000"
"\000\013look-behind\376\003\000\000\002\376\001\000\000\017neg-look-behind\376\003\000\000\002\376\001\000\000\016submatch-named\376\003\000\000\002\376\001\000\000\006w/utf8\376\003"
"\000\000\002\376\001\000\000\010w/noutf8\376\377\016");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[88]=C_h_intern(&lf[88],3,"any");
lf[89]=C_h_intern(&lf[89],4,"nonl");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\030\077 can\047t follow empty sre");
lf[91]=C_h_intern(&lf[91],1,"*");
lf[92]=C_h_intern(&lf[92],2,"*\077");
lf[93]=C_h_intern(&lf[93],1,"+");
lf[94]=C_h_intern(&lf[94],3,"**\077");
lf[95]=C_h_intern(&lf[95],1,"\077");
lf[96]=C_h_intern(&lf[96],2,"\077\077");
lf[97]=C_h_intern(&lf[97],2,"**");
lf[98]=C_h_intern(&lf[98],1,"=");
lf[99]=C_h_intern(&lf[99],2,">=");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000%duplicate repetition (e.g. **) in sre");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000!can\047t repeat empty sre (e.g. ()*)");
lf[104]=C_h_intern(&lf[104],14,"string->symbol");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[107]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012look-ahead\376\377\016");
lf[108]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016neg-look-ahead\376\377\016");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[110]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\013look-behind\376\377\016");
lf[111]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\017neg-look-behind\376\377\016");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\024invalid (\077< sequence");
lf[113]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006atomic\376\377\016");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\035invalid conditional reference");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\377\016");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\036unsupported Perl-style cluster");
lf[118]=C_h_intern(&lf[118],6,"w/utf8");
lf[119]=C_h_intern(&lf[119],8,"w/noutf8");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\022incomplete cluster");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\036unknown regex cluster modifier");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\026too many )\047s in regexp");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\023incomplete char set");
lf[124]=C_h_intern(&lf[124],1,"~");
lf[125]=C_h_intern(&lf[125],6,"append");
lf[127]=C_h_intern(&lf[127],16,"\003syslist->string");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\014bad char-set");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\032inverted range in char-set");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\032incomplete character class");
lf[135]=C_h_intern(&lf[135],5,"pair\077");
lf[136]=C_h_intern(&lf[136],5,"char\077");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000!collating sequences not supported");
lf[140]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\012\376\377\016");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\032incomplete escape sequence");
lf[142]=C_h_intern(&lf[142],7,"numeric");
lf[143]=C_h_intern(&lf[143],5,"space");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\001_");
lf[145]=C_h_intern(&lf[145],12,"alphanumeric");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\001_");
lf[147]=C_h_intern(&lf[147],3,"eow");
lf[148]=C_h_intern(&lf[148],3,"bow");
lf[149]=C_h_intern(&lf[149],3,"nwb");
lf[150]=C_h_intern(&lf[150],3,"bos");
lf[151]=C_h_intern(&lf[151],3,"eos");
lf[152]=C_h_intern(&lf[152],7,"newline");
lf[153]=C_h_intern(&lf[153],5,"reset");
lf[154]=C_h_intern(&lf[154],10,"backref-ci");
lf[155]=C_h_intern(&lf[155],7,"backref");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\032interminated named backref");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\036bad \134k usage, expected \134k<...>");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\027unknown escape sequence");
lf[159]=C_h_intern(&lf[159],3,"bol");
lf[160]=C_h_intern(&lf[160],3,"eol");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\025incomplete hex escape");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\024bad hex brace escape");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\033incomplete hex brace escape");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\025incomplete hex escape");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\016bad hex escape");
lf[166]=C_decode_literal(C_heaptop,"\376\000\000\001\000\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376"
"\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000"
"\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001"
"\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001"
"\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000"
"\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377"
"\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376"
"\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000"
"\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001"
"\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001"
"\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000"
"\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377"
"\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376"
"\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\002\376\377\001\000"
"\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002"
"\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001"
"\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000"
"\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377"
"\001\000\000\000\003\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\005\376\377\001\000\000\000\005\376\377\001\000\000"
"\000\005\376\377\001\000\000\000\005\376\377\001\000\000\000\006\376\377\001\000\000\000\006\376\377\001\000\000\000\000\376\377\001\000\000\000\000");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid utf8 length");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid utf8 length");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\037unicode codepoint out of range:");
lf[173]=C_h_intern(&lf[173],13,"integer->char");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid utf8 length");
lf[178]=C_h_intern(&lf[178],7,"irregex");
lf[179]=C_h_intern(&lf[179],15,"string->irregex");
lf[180]=C_h_intern(&lf[180],12,"sre->irregex");
lf[183]=C_h_intern(&lf[183],6,"w/case");
lf[184]=C_h_intern(&lf[184],8,"w/nocase");
lf[185]=C_h_intern(&lf[185],1,":");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\024invalid sre: empty *");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid sre: empty *\077");
lf[189]=C_h_intern(&lf[189],4,"word");
lf[190]=C_h_intern(&lf[190],5,"word+");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\001_");
lf[192]=C_h_intern(&lf[192],1,"&");
lf[193]=C_h_intern(&lf[193],12,"posix-string");
lf[194]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\003any\376\377\016");
lf[195]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\003any\376\377\016");
lf[196]=C_h_intern(&lf[196],6,"atomic");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\037unknown named backref in SRE IF");
lf[198]=C_h_intern(&lf[198],11,"string-ci=\077");
lf[199]=C_h_intern(&lf[199],8,"string=\077");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\025unknown backreference");
lf[201]=C_h_intern(&lf[201],3,"dsm");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\027unknown regexp operator");
lf[203]=C_h_intern(&lf[203],1,"-");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\016unknown regexp");
lf[206]=C_h_intern(&lf[206],9,"char-ci=\077");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\016unknown regexp");
lf[210]=C_h_intern(&lf[210],3,"max");
lf[211]=C_h_intern(&lf[211],3,"min");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000!sre-length: invalid backreference");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000)sre-length: invalid forward backreference");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\025unknown backreference");
lf[215]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002>=\376\003\000\000\002\376\001\000\000\003>=\077\376\377\016");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\047sre-length-ranges: unknown sre operator");
lf[217]=C_h_intern(&lf[217],2,"=\077");
lf[218]=C_h_intern(&lf[218],3,">=\077");
lf[219]=C_h_intern(&lf[219],6,"commit");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\036sre-length-ranges: unknown sre");
lf[221]=C_h_intern(&lf[221],4,"cons");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\027unknown regexp operator");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\016unknown regexp");
lf[228]=C_h_intern(&lf[228],5,"small");
lf[229]=C_h_intern(&lf[229],4,"fast");
lf[232]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\003any\376\377\016");
lf[233]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\004nonl\376\377\016");
lf[234]=C_h_intern(&lf[234],8,"utf8-any");
lf[235]=C_h_intern(&lf[235],9,"utf8-nonl");
lf[236]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007epsilon\376\003\000\000\002\376\001\000\000\003bos\376\003\000\000\002\376\001\000\000\003eos\376\003\000\000\002\376\001\000\000\003bol\376\003\000\000\002\376\001\000\000\003eol\376\003\000\000\002\376\001\000\000\003b"
"ow\376\003\000\000\002\376\001\000\000\003eow\376\003\000\000\002\376\001\000\000\006commit\376\377\016");
lf[238]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\001+\376\377\016");
lf[240]=C_h_intern(&lf[240],14,"irregex-search");
lf[241]=C_h_intern(&lf[241],22,"irregex-search/matches");
lf[245]=C_h_intern(&lf[245],13,"irregex-match");
lf[246]=C_h_intern(&lf[246],10,"alphabetic");
lf[247]=C_h_intern(&lf[247],5,"alpha");
lf[248]=C_h_intern(&lf[248],8,"alphanum");
lf[249]=C_h_intern(&lf[249],5,"alnum");
lf[250]=C_h_intern(&lf[250],10,"lower-case");
lf[251]=C_h_intern(&lf[251],5,"lower");
lf[252]=C_h_intern(&lf[252],10,"upper-case");
lf[253]=C_h_intern(&lf[253],5,"upper");
lf[254]=C_h_intern(&lf[254],3,"num");
lf[255]=C_h_intern(&lf[255],5,"digit");
lf[256]=C_h_intern(&lf[256],11,"punctuation");
lf[257]=C_h_intern(&lf[257],5,"punct");
lf[258]=C_h_intern(&lf[258],7,"graphic");
lf[259]=C_h_intern(&lf[259],5,"graph");
lf[260]=C_h_intern(&lf[260],5,"blank");
lf[261]=C_h_intern(&lf[261],10,"whitespace");
lf[262]=C_h_intern(&lf[262],5,"white");
lf[263]=C_h_intern(&lf[263],8,"printing");
lf[264]=C_h_intern(&lf[264],5,"print");
lf[265]=C_h_intern(&lf[265],7,"control");
lf[266]=C_h_intern(&lf[266],5,"cntrl");
lf[267]=C_h_intern(&lf[267],9,"hex-digit");
lf[268]=C_h_intern(&lf[268],6,"xdigit");
lf[269]=C_h_intern(&lf[269],5,"ascii");
lf[270]=C_h_intern(&lf[270],10,"ascii-nonl");
lf[271]=C_h_intern(&lf[271],14,"utf8-tail-char");
lf[272]=C_h_intern(&lf[272],11,"utf8-2-char");
lf[273]=C_h_intern(&lf[273],11,"utf8-3-char");
lf[274]=C_h_intern(&lf[274],11,"utf8-4-char");
lf[275]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006w/case\376\003\000\000\002\376\001\000\000\010w/nocase\376\377\016");
lf[276]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006w/case\376\003\000\000\002\376\001\000\000\006w/utf8\376\377\016");
lf[277]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007epsilon\376\377\016");
lf[278]=C_h_intern(&lf[278],12,"list->vector");
lf[279]=C_h_intern(&lf[279],3,"map");
lf[280]=C_h_intern(&lf[280],3,"car");
lf[281]=C_h_intern(&lf[281],3,"cdr");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000!not a valid sre char-set operator");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\030not a valid sre char-set");
lf[296]=C_h_intern(&lf[296],12,"irregex-fold");
lf[297]=C_h_intern(&lf[297],15,"irregex-replace");
lf[298]=C_h_intern(&lf[298],19,"irregex-apply-match");
lf[299]=C_h_intern(&lf[299],19,"irregex-replace/all");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[301]=C_h_intern(&lf[301],3,"pre");
lf[302]=C_h_intern(&lf[302],4,"post");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\031unknown match replacement");
lf[304]=C_h_intern(&lf[304],7,"regexp\077");
lf[305]=C_h_intern(&lf[305],6,"regexp");
lf[307]=C_h_intern(&lf[307],12,"string-match");
lf[308]=C_h_intern(&lf[308],22,"string-match-positions");
lf[309]=C_h_intern(&lf[309],13,"string-search");
lf[310]=C_h_intern(&lf[310],23,"string-search-positions");
lf[311]=C_h_intern(&lf[311],9,"substring");
lf[312]=C_h_intern(&lf[312],19,"string-split-fields");
lf[313]=C_h_intern(&lf[313],6,"\000infix");
lf[314]=C_h_intern(&lf[314],7,"\000suffix");
lf[315]=C_h_intern(&lf[315],9,"\003syserror");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\037record does not end with suffix");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[318]=C_h_intern(&lf[318],17,"string-substitute");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\030empty substitution match");
lf[320]=C_h_intern(&lf[320],21,"\003sysfragments->string");
lf[321]=C_h_intern(&lf[321],18,"string-substitute*");
lf[322]=C_h_intern(&lf[322],5,"glob\077");
lf[323]=C_h_intern(&lf[323],12,"glob->regexp");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000!unexpected end of character class");
lf[325]=C_h_intern(&lf[325],4,"grep");
lf[326]=C_h_intern(&lf[326],13,"regexp-escape");
lf[327]=C_h_intern(&lf[327],17,"get-output-string");
lf[328]=C_h_intern(&lf[328],16,"\003syswrite-char-0");
lf[329]=C_h_intern(&lf[329],18,"open-output-string");
lf[330]=C_h_intern(&lf[330],17,"register-feature!");
lf[331]=C_h_intern(&lf[331],5,"regex");
C_register_lf2(lf,332,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4890,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 64   register-feature! */
t3=*((C_word*)lf[330]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[331],lf[178]);}

/* k4888 */
static void C_ccall f_4890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word t180;
C_word t181;
C_word t182;
C_word t183;
C_word t184;
C_word t185;
C_word t186;
C_word t187;
C_word t188;
C_word t189;
C_word t190;
C_word t191;
C_word t192;
C_word t193;
C_word t194;
C_word t195;
C_word t196;
C_word t197;
C_word t198;
C_word t199;
C_word t200;
C_word t201;
C_word t202;
C_word t203;
C_word t204;
C_word t205;
C_word t206;
C_word t207;
C_word t208;
C_word t209;
C_word t210;
C_word t211;
C_word t212;
C_word t213;
C_word t214;
C_word t215;
C_word t216;
C_word t217;
C_word t218;
C_word t219;
C_word t220;
C_word t221;
C_word t222;
C_word t223;
C_word t224;
C_word t225;
C_word t226;
C_word t227;
C_word t228;
C_word t229;
C_word t230;
C_word t231;
C_word t232;
C_word t233;
C_word t234;
C_word t235;
C_word t236;
C_word t237;
C_word t238;
C_word t239;
C_word t240;
C_word t241;
C_word t242;
C_word t243;
C_word t244;
C_word t245;
C_word t246;
C_word t247;
C_word t248;
C_word t249;
C_word t250;
C_word t251;
C_word t252;
C_word t253;
C_word t254;
C_word t255;
C_word t256;
C_word t257;
C_word t258;
C_word t259;
C_word t260;
C_word t261;
C_word t262;
C_word t263;
C_word t264;
C_word t265;
C_word t266;
C_word t267;
C_word t268;
C_word t269;
C_word t270;
C_word t271;
C_word t272;
C_word t273;
C_word t274;
C_word t275;
C_word t276;
C_word t277;
C_word t278;
C_word t279;
C_word t280;
C_word t281;
C_word t282;
C_word t283;
C_word t284;
C_word t285;
C_word t286;
C_word t287;
C_word t288;
C_word t289;
C_word t290;
C_word t291;
C_word t292;
C_word t293;
C_word t294;
C_word t295;
C_word t296;
C_word t297;
C_word t298;
C_word t299;
C_word t300;
C_word t301;
C_word t302;
C_word t303;
C_word t304;
C_word t305;
C_word t306;
C_word t307;
C_word t308;
C_word t309;
C_word t310;
C_word t311;
C_word t312;
C_word t313;
C_word t314;
C_word t315;
C_word t316;
C_word t317;
C_word t318;
C_word t319;
C_word t320;
C_word t321;
C_word t322;
C_word t323;
C_word t324;
C_word t325;
C_word t326;
C_word t327;
C_word t328;
C_word t329;
C_word t330;
C_word t331;
C_word t332;
C_word t333;
C_word t334;
C_word t335;
C_word t336;
C_word t337;
C_word t338;
C_word t339;
C_word t340;
C_word t341;
C_word t342;
C_word t343;
C_word t344;
C_word t345;
C_word t346;
C_word t347;
C_word t348;
C_word t349;
C_word t350;
C_word t351;
C_word t352;
C_word t353;
C_word t354;
C_word t355;
C_word t356;
C_word t357;
C_word t358;
C_word t359;
C_word t360;
C_word t361;
C_word t362;
C_word t363;
C_word t364;
C_word t365;
C_word ab[944],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4890,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! make-irregex ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4893,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[2]+1 /* (set! irregex? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4899,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[3]+1 /* (set! irregex-dfa ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4925,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[4]+1 /* (set! irregex-dfa/search ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4931,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[5]+1 /* (set! irregex-dfa/extract ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4937,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[6]+1 /* (set! irregex-nfa ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4943,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[7]+1 /* (set! irregex-flags ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4949,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[8]+1 /* (set! irregex-submatches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4955,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[9]+1 /* (set! irregex-lengths ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4961,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[10]+1 /* (set! irregex-names ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4967,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[11]+1 /* (set! irregex-new-matches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4973,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[14]+1 /* (set! irregex-reset-matches! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4987,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[15]+1 /* (set! irregex-match-data? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5021,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[16]+1 /* (set! irregex-match-num-submatches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5074,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[17]+1 /* (set! irregex-match-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5092,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[18] /* (set! irregex-match-string-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5104,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[19] /* (set! irregex-match-start-index ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5110,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[20] /* (set! irregex-match-end-index ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5124,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[21] /* (set! irregex-match-start-index-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5138,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate(&lf[22] /* (set! irregex-match-end-index-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5152,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate(&lf[23] /* (set! irregex-match-index ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5166,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate(&lf[26] /* (set! irregex-match-valid-index? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5212,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[27]+1 /* (set! irregex-match-substring ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5244,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[29]+1 /* (set! irregex-match-start ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5287,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[30]+1 /* (set! irregex-match-end ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5310,tmp=(C_word)a,a+=2,tmp));
t27=(C_word)C_a_i_cons(&a,2,C_make_character(1114111),C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,C_make_character(57344),t27);
t29=(C_word)C_a_i_cons(&a,2,C_make_character(55295),t28);
t30=(C_word)C_a_i_cons(&a,2,C_make_character(0),t29);
t31=(C_word)C_a_i_cons(&a,2,lf[31],t30);
t32=C_mutate(&lf[32] /* (set! *all-chars* ...) */,t31);
t33=C_mutate(&lf[33] /* (set! string-scan-char ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5325,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate(&lf[34] /* (set! char-alphanumeric? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5540,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate(&lf[35] /* (set! string-cat-reverse ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5585,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate(&lf[38] /* (set! zero-to ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5642,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate(&lf[39] /* (set! take-up-to ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5681,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate(&lf[41] /* (set! find ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5724,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate(&lf[42] /* (set! find-tail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5736,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate(&lf[43] /* (set! last ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5768,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate(&lf[45] /* (set! any ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5810,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate(&lf[46] /* (set! every ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5859,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate(&lf[37] /* (set! fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5908,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate(&lf[47] /* (set! filter ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5938,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate(&lf[48] /* (set! bit-shr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6024,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate(&lf[50] /* (set! bit-shl ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6034,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate(&lf[51] /* (set! bit-ior ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6050,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate(&lf[52] /* (set! bit-and ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6097,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate(&lf[53] /* (set! flag-set? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6144,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate(&lf[54] /* (set! flag-join ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6154,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate(&lf[55] /* (set! flag-clear ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6163,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate(&lf[56] /* (set! symbol-list->flags ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6182,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[68]+1 /* (set! string->sre ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6282,tmp=(C_word)a,a+=2,tmp));
t54=(C_word)C_a_i_cons(&a,2,C_make_character(110),C_make_character(10));
t55=(C_word)C_a_i_cons(&a,2,C_make_character(114),C_make_character(13));
t56=(C_word)C_a_i_cons(&a,2,C_make_character(116),C_make_character(9));
t57=(C_word)C_a_i_cons(&a,2,C_make_character(97),C_make_character(7));
t58=(C_word)C_a_i_cons(&a,2,C_make_character(101),C_make_character(27));
t59=(C_word)C_a_i_cons(&a,2,C_make_character(102),C_make_character(12));
t60=(C_word)C_a_i_cons(&a,2,t59,C_SCHEME_END_OF_LIST);
t61=(C_word)C_a_i_cons(&a,2,t58,t60);
t62=(C_word)C_a_i_cons(&a,2,t57,t61);
t63=(C_word)C_a_i_cons(&a,2,t56,t62);
t64=(C_word)C_a_i_cons(&a,2,t55,t63);
t65=(C_word)C_a_i_cons(&a,2,t54,t64);
t66=C_mutate(&lf[131] /* (set! posix-escape-sequences ...) */,t65);
t67=C_mutate(&lf[69] /* (set! char-altcase ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9191,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate(&lf[132] /* (set! string-parse-hex-escape ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9233,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate(&lf[128] /* (set! high-char? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10025,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate(&lf[133] /* (set! utf8-start-char->length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10035,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate(&lf[74] /* (set! utf8-string-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10045,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate(&lf[168] /* (set! utf8-lowest-digit-of-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10270,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate(&lf[170] /* (set! char->utf8-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10330,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate(&lf[172] /* (set! unicode-range-helper ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10606,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate(&lf[174] /* (set! unicode-range-up-from ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10692,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate(&lf[175] /* (set! unicode-range-up-to ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10820,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate(&lf[176] /* (set! cset->utf8-pattern ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11304,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[178]+1 /* (set! irregex ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11754,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[179]+1 /* (set! string->irregex ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11775,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[180]+1 /* (set! sre->irregex ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11785,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate(&lf[103] /* (set! sre-empty? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11926,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate(&lf[237] /* (set! sre-any? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12054,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate(&lf[100] /* (set! sre-repeater? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12130,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate(&lf[231] /* (set! sre-searcher? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12186,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate(&lf[209] /* (set! sre-consumer? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12272,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate(&lf[227] /* (set! sre-has-submatchs? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12358,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate(&lf[182] /* (set! sre-count-submatches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12384,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate(&lf[71] /* (set! sre-sequence ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13479,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate(&lf[75] /* (set! sre-alternate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13504,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate(&lf[188] /* (set! sre-strip-submatches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13529,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate(&lf[208] /* (set! sre-names ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13644,tmp=(C_word)a,a+=2,tmp));
t92=C_mutate(&lf[239] /* (set! sre-sequence-names ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13874,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate(&lf[230] /* (set! sre-remove-initial-bos ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13910,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[240]+1 /* (set! irregex-search ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14027,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[241]+1 /* (set! irregex-search/matches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14073,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[245]+1 /* (set! irregex-match ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14232,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate(&lf[242] /* (set! dfa-init-state ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14299,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate(&lf[244] /* (set! dfa-next-state ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14305,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate(&lf[243] /* (set! dfa-final-state? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14315,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate(&lf[224] /* (set! dfa-match/longest ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14410,tmp=(C_word)a,a+=2,tmp));
t101=(C_word)C_a_i_cons(&a,2,lf[88],lf[32]);
t102=(C_word)C_a_i_string(&a,1,C_make_character(10));
t103=(C_word)C_a_i_cons(&a,2,t102,C_SCHEME_END_OF_LIST);
t104=(C_word)C_a_i_cons(&a,2,t103,C_SCHEME_END_OF_LIST);
t105=(C_word)C_a_i_cons(&a,2,lf[32],t104);
t106=(C_word)C_a_i_cons(&a,2,lf[203],t105);
t107=(C_word)C_a_i_cons(&a,2,lf[89],t106);
t108=(C_word)C_a_i_cons(&a,2,C_make_character(90),C_SCHEME_END_OF_LIST);
t109=(C_word)C_a_i_cons(&a,2,C_make_character(65),t108);
t110=(C_word)C_a_i_cons(&a,2,C_make_character(122),t109);
t111=(C_word)C_a_i_cons(&a,2,C_make_character(97),t110);
t112=(C_word)C_a_i_cons(&a,2,lf[31],t111);
t113=(C_word)C_a_i_cons(&a,2,lf[246],t112);
t114=(C_word)C_a_i_cons(&a,2,lf[247],lf[246]);
t115=(C_word)C_a_i_cons(&a,2,C_make_character(57),C_SCHEME_END_OF_LIST);
t116=(C_word)C_a_i_cons(&a,2,C_make_character(48),t115);
t117=(C_word)C_a_i_cons(&a,2,C_make_character(90),t116);
t118=(C_word)C_a_i_cons(&a,2,C_make_character(65),t117);
t119=(C_word)C_a_i_cons(&a,2,C_make_character(122),t118);
t120=(C_word)C_a_i_cons(&a,2,C_make_character(97),t119);
t121=(C_word)C_a_i_cons(&a,2,lf[31],t120);
t122=(C_word)C_a_i_cons(&a,2,lf[145],t121);
t123=(C_word)C_a_i_cons(&a,2,lf[248],lf[145]);
t124=(C_word)C_a_i_cons(&a,2,lf[249],lf[145]);
t125=(C_word)C_a_i_cons(&a,2,C_make_character(122),C_SCHEME_END_OF_LIST);
t126=(C_word)C_a_i_cons(&a,2,C_make_character(97),t125);
t127=(C_word)C_a_i_cons(&a,2,lf[31],t126);
t128=(C_word)C_a_i_cons(&a,2,lf[250],t127);
t129=(C_word)C_a_i_cons(&a,2,lf[251],lf[250]);
t130=(C_word)C_a_i_cons(&a,2,C_make_character(90),C_SCHEME_END_OF_LIST);
t131=(C_word)C_a_i_cons(&a,2,C_make_character(65),t130);
t132=(C_word)C_a_i_cons(&a,2,lf[31],t131);
t133=(C_word)C_a_i_cons(&a,2,lf[252],t132);
t134=(C_word)C_a_i_cons(&a,2,lf[253],lf[252]);
t135=(C_word)C_a_i_cons(&a,2,C_make_character(57),C_SCHEME_END_OF_LIST);
t136=(C_word)C_a_i_cons(&a,2,C_make_character(48),t135);
t137=(C_word)C_a_i_cons(&a,2,lf[31],t136);
t138=(C_word)C_a_i_cons(&a,2,lf[142],t137);
t139=(C_word)C_a_i_cons(&a,2,lf[254],lf[142]);
t140=(C_word)C_a_i_cons(&a,2,lf[255],lf[142]);
t141=(C_word)C_a_i_cons(&a,2,C_make_character(125),C_SCHEME_END_OF_LIST);
t142=(C_word)C_a_i_cons(&a,2,C_make_character(123),t141);
t143=(C_word)C_a_i_cons(&a,2,C_make_character(95),t142);
t144=(C_word)C_a_i_cons(&a,2,C_make_character(93),t143);
t145=(C_word)C_a_i_cons(&a,2,C_make_character(92),t144);
t146=(C_word)C_a_i_cons(&a,2,C_make_character(91),t145);
t147=(C_word)C_a_i_cons(&a,2,C_make_character(64),t146);
t148=(C_word)C_a_i_cons(&a,2,C_make_character(63),t147);
t149=(C_word)C_a_i_cons(&a,2,C_make_character(59),t148);
t150=(C_word)C_a_i_cons(&a,2,C_make_character(58),t149);
t151=(C_word)C_a_i_cons(&a,2,C_make_character(47),t150);
t152=(C_word)C_a_i_cons(&a,2,C_make_character(46),t151);
t153=(C_word)C_a_i_cons(&a,2,C_make_character(45),t152);
t154=(C_word)C_a_i_cons(&a,2,C_make_character(44),t153);
t155=(C_word)C_a_i_cons(&a,2,C_make_character(42),t154);
t156=(C_word)C_a_i_cons(&a,2,C_make_character(41),t155);
t157=(C_word)C_a_i_cons(&a,2,C_make_character(40),t156);
t158=(C_word)C_a_i_cons(&a,2,C_make_character(39),t157);
t159=(C_word)C_a_i_cons(&a,2,C_make_character(38),t158);
t160=(C_word)C_a_i_cons(&a,2,C_make_character(37),t159);
t161=(C_word)C_a_i_cons(&a,2,C_make_character(35),t160);
t162=(C_word)C_a_i_cons(&a,2,C_make_character(34),t161);
t163=(C_word)C_a_i_cons(&a,2,C_make_character(33),t162);
t164=(C_word)C_a_i_cons(&a,2,lf[70],t163);
t165=(C_word)C_a_i_cons(&a,2,lf[256],t164);
t166=(C_word)C_a_i_cons(&a,2,lf[257],lf[256]);
t167=(C_word)C_a_i_cons(&a,2,C_make_character(126),C_SCHEME_END_OF_LIST);
t168=(C_word)C_a_i_cons(&a,2,C_make_character(124),t167);
t169=(C_word)C_a_i_cons(&a,2,C_make_character(96),t168);
t170=(C_word)C_a_i_cons(&a,2,C_make_character(94),t169);
t171=(C_word)C_a_i_cons(&a,2,C_make_character(62),t170);
t172=(C_word)C_a_i_cons(&a,2,C_make_character(61),t171);
t173=(C_word)C_a_i_cons(&a,2,C_make_character(60),t172);
t174=(C_word)C_a_i_cons(&a,2,C_make_character(43),t173);
t175=(C_word)C_a_i_cons(&a,2,C_make_character(36),t174);
t176=(C_word)C_a_i_cons(&a,2,lf[256],t175);
t177=(C_word)C_a_i_cons(&a,2,lf[145],t176);
t178=(C_word)C_a_i_cons(&a,2,lf[70],t177);
t179=(C_word)C_a_i_cons(&a,2,lf[258],t178);
t180=(C_word)C_a_i_cons(&a,2,lf[259],lf[258]);
t181=(C_word)C_a_i_cons(&a,2,C_make_character(9),C_SCHEME_END_OF_LIST);
t182=(C_word)C_a_i_cons(&a,2,C_make_character(32),t181);
t183=(C_word)C_a_i_cons(&a,2,lf[70],t182);
t184=(C_word)C_a_i_cons(&a,2,lf[260],t183);
t185=(C_word)C_a_i_cons(&a,2,C_make_character(10),C_SCHEME_END_OF_LIST);
t186=(C_word)C_a_i_cons(&a,2,lf[260],t185);
t187=(C_word)C_a_i_cons(&a,2,lf[70],t186);
t188=(C_word)C_a_i_cons(&a,2,lf[261],t187);
t189=(C_word)C_a_i_cons(&a,2,lf[143],lf[261]);
t190=(C_word)C_a_i_cons(&a,2,lf[262],lf[261]);
t191=(C_word)C_a_i_cons(&a,2,lf[261],C_SCHEME_END_OF_LIST);
t192=(C_word)C_a_i_cons(&a,2,lf[258],t191);
t193=(C_word)C_a_i_cons(&a,2,lf[70],t192);
t194=(C_word)C_a_i_cons(&a,2,lf[263],t193);
t195=(C_word)C_a_i_cons(&a,2,lf[264],lf[263]);
t196=(C_word)C_a_i_cons(&a,2,C_make_character(31),C_SCHEME_END_OF_LIST);
t197=(C_word)C_a_i_cons(&a,2,C_make_character(0),t196);
t198=(C_word)C_a_i_cons(&a,2,lf[31],t197);
t199=(C_word)C_a_i_cons(&a,2,lf[265],t198);
t200=(C_word)C_a_i_cons(&a,2,lf[266],lf[265]);
t201=(C_word)C_a_i_cons(&a,2,C_make_character(70),C_SCHEME_END_OF_LIST);
t202=(C_word)C_a_i_cons(&a,2,C_make_character(65),t201);
t203=(C_word)C_a_i_cons(&a,2,C_make_character(102),t202);
t204=(C_word)C_a_i_cons(&a,2,C_make_character(97),t203);
t205=(C_word)C_a_i_cons(&a,2,lf[31],t204);
t206=(C_word)C_a_i_cons(&a,2,t205,C_SCHEME_END_OF_LIST);
t207=(C_word)C_a_i_cons(&a,2,lf[142],t206);
t208=(C_word)C_a_i_cons(&a,2,lf[70],t207);
t209=(C_word)C_a_i_cons(&a,2,lf[267],t208);
t210=(C_word)C_a_i_cons(&a,2,lf[268],lf[267]);
t211=(C_word)C_a_i_cons(&a,2,C_make_character(127),C_SCHEME_END_OF_LIST);
t212=(C_word)C_a_i_cons(&a,2,C_make_character(0),t211);
t213=(C_word)C_a_i_cons(&a,2,lf[31],t212);
t214=(C_word)C_a_i_cons(&a,2,lf[269],t213);
t215=(C_word)C_a_i_cons(&a,2,C_make_character(127),C_SCHEME_END_OF_LIST);
t216=(C_word)C_a_i_cons(&a,2,C_make_character(11),t215);
t217=(C_word)C_a_i_cons(&a,2,C_make_character(9),t216);
t218=(C_word)C_a_i_cons(&a,2,C_make_character(0),t217);
t219=(C_word)C_a_i_cons(&a,2,lf[31],t218);
t220=(C_word)C_a_i_cons(&a,2,lf[270],t219);
t221=(C_word)C_a_i_cons(&a,2,C_make_character(10),C_SCHEME_END_OF_LIST);
t222=(C_word)C_a_i_cons(&a,2,C_make_character(13),t221);
t223=(C_word)C_a_i_cons(&a,2,lf[82],t222);
t224=(C_word)C_a_i_cons(&a,2,C_make_character(13),C_SCHEME_END_OF_LIST);
t225=(C_word)C_a_i_cons(&a,2,C_make_character(10),t224);
t226=(C_word)C_a_i_cons(&a,2,lf[31],t225);
t227=(C_word)C_a_i_cons(&a,2,t226,C_SCHEME_END_OF_LIST);
t228=(C_word)C_a_i_cons(&a,2,t223,t227);
t229=(C_word)C_a_i_cons(&a,2,lf[70],t228);
t230=(C_word)C_a_i_cons(&a,2,lf[152],t229);
t231=(C_word)C_a_i_cons(&a,2,C_make_character(95),C_SCHEME_END_OF_LIST);
t232=(C_word)C_a_i_cons(&a,2,lf[145],t231);
t233=(C_word)C_a_i_cons(&a,2,lf[70],t232);
t234=(C_word)C_a_i_cons(&a,2,t233,C_SCHEME_END_OF_LIST);
t235=(C_word)C_a_i_cons(&a,2,lf[93],t234);
t236=(C_word)C_a_i_cons(&a,2,lf[147],C_SCHEME_END_OF_LIST);
t237=(C_word)C_a_i_cons(&a,2,t235,t236);
t238=(C_word)C_a_i_cons(&a,2,lf[148],t237);
t239=(C_word)C_a_i_cons(&a,2,lf[82],t238);
t240=(C_word)C_a_i_cons(&a,2,lf[189],t239);
t241=(C_word)C_a_i_cons(&a,2,C_make_character(193),C_SCHEME_END_OF_LIST);
t242=(C_word)C_a_i_cons(&a,2,C_make_character(128),t241);
t243=(C_word)C_a_i_cons(&a,2,lf[31],t242);
t244=(C_word)C_a_i_cons(&a,2,lf[271],t243);
t245=(C_word)C_a_i_cons(&a,2,C_make_character(223),C_SCHEME_END_OF_LIST);
t246=(C_word)C_a_i_cons(&a,2,C_make_character(194),t245);
t247=(C_word)C_a_i_cons(&a,2,lf[31],t246);
t248=(C_word)C_a_i_cons(&a,2,lf[271],C_SCHEME_END_OF_LIST);
t249=(C_word)C_a_i_cons(&a,2,t247,t248);
t250=(C_word)C_a_i_cons(&a,2,lf[82],t249);
t251=(C_word)C_a_i_cons(&a,2,lf[272],t250);
t252=(C_word)C_a_i_cons(&a,2,C_make_character(239),C_SCHEME_END_OF_LIST);
t253=(C_word)C_a_i_cons(&a,2,C_make_character(224),t252);
t254=(C_word)C_a_i_cons(&a,2,lf[31],t253);
t255=(C_word)C_a_i_cons(&a,2,lf[271],C_SCHEME_END_OF_LIST);
t256=(C_word)C_a_i_cons(&a,2,lf[271],t255);
t257=(C_word)C_a_i_cons(&a,2,t254,t256);
t258=(C_word)C_a_i_cons(&a,2,lf[82],t257);
t259=(C_word)C_a_i_cons(&a,2,lf[273],t258);
t260=(C_word)C_a_i_cons(&a,2,C_make_character(247),C_SCHEME_END_OF_LIST);
t261=(C_word)C_a_i_cons(&a,2,C_make_character(240),t260);
t262=(C_word)C_a_i_cons(&a,2,lf[31],t261);
t263=(C_word)C_a_i_cons(&a,2,lf[271],C_SCHEME_END_OF_LIST);
t264=(C_word)C_a_i_cons(&a,2,lf[271],t263);
t265=(C_word)C_a_i_cons(&a,2,lf[271],t264);
t266=(C_word)C_a_i_cons(&a,2,t262,t265);
t267=(C_word)C_a_i_cons(&a,2,lf[82],t266);
t268=(C_word)C_a_i_cons(&a,2,lf[274],t267);
t269=(C_word)C_a_i_cons(&a,2,lf[274],C_SCHEME_END_OF_LIST);
t270=(C_word)C_a_i_cons(&a,2,lf[273],t269);
t271=(C_word)C_a_i_cons(&a,2,lf[272],t270);
t272=(C_word)C_a_i_cons(&a,2,lf[269],t271);
t273=(C_word)C_a_i_cons(&a,2,lf[70],t272);
t274=(C_word)C_a_i_cons(&a,2,lf[234],t273);
t275=(C_word)C_a_i_cons(&a,2,lf[274],C_SCHEME_END_OF_LIST);
t276=(C_word)C_a_i_cons(&a,2,lf[273],t275);
t277=(C_word)C_a_i_cons(&a,2,lf[272],t276);
t278=(C_word)C_a_i_cons(&a,2,lf[270],t277);
t279=(C_word)C_a_i_cons(&a,2,lf[70],t278);
t280=(C_word)C_a_i_cons(&a,2,lf[235],t279);
t281=(C_word)C_a_i_cons(&a,2,t280,C_SCHEME_END_OF_LIST);
t282=(C_word)C_a_i_cons(&a,2,t274,t281);
t283=(C_word)C_a_i_cons(&a,2,t268,t282);
t284=(C_word)C_a_i_cons(&a,2,t259,t283);
t285=(C_word)C_a_i_cons(&a,2,t251,t284);
t286=(C_word)C_a_i_cons(&a,2,t244,t285);
t287=(C_word)C_a_i_cons(&a,2,t240,t286);
t288=(C_word)C_a_i_cons(&a,2,t230,t287);
t289=(C_word)C_a_i_cons(&a,2,t220,t288);
t290=(C_word)C_a_i_cons(&a,2,t214,t289);
t291=(C_word)C_a_i_cons(&a,2,t210,t290);
t292=(C_word)C_a_i_cons(&a,2,t209,t291);
t293=(C_word)C_a_i_cons(&a,2,t200,t292);
t294=(C_word)C_a_i_cons(&a,2,t199,t293);
t295=(C_word)C_a_i_cons(&a,2,t195,t294);
t296=(C_word)C_a_i_cons(&a,2,t194,t295);
t297=(C_word)C_a_i_cons(&a,2,t190,t296);
t298=(C_word)C_a_i_cons(&a,2,t189,t297);
t299=(C_word)C_a_i_cons(&a,2,t188,t298);
t300=(C_word)C_a_i_cons(&a,2,t184,t299);
t301=(C_word)C_a_i_cons(&a,2,t180,t300);
t302=(C_word)C_a_i_cons(&a,2,t179,t301);
t303=(C_word)C_a_i_cons(&a,2,t166,t302);
t304=(C_word)C_a_i_cons(&a,2,t165,t303);
t305=(C_word)C_a_i_cons(&a,2,t140,t304);
t306=(C_word)C_a_i_cons(&a,2,t139,t305);
t307=(C_word)C_a_i_cons(&a,2,t138,t306);
t308=(C_word)C_a_i_cons(&a,2,t134,t307);
t309=(C_word)C_a_i_cons(&a,2,t133,t308);
t310=(C_word)C_a_i_cons(&a,2,t129,t309);
t311=(C_word)C_a_i_cons(&a,2,t128,t310);
t312=(C_word)C_a_i_cons(&a,2,t124,t311);
t313=(C_word)C_a_i_cons(&a,2,t123,t312);
t314=(C_word)C_a_i_cons(&a,2,t122,t313);
t315=(C_word)C_a_i_cons(&a,2,t114,t314);
t316=(C_word)C_a_i_cons(&a,2,t113,t315);
t317=(C_word)C_a_i_cons(&a,2,t107,t316);
t318=(C_word)C_a_i_cons(&a,2,t101,t317);
t319=C_mutate(&lf[204] /* (set! sre-named-definitions ...) */,t318);
t320=C_mutate(&lf[226] /* (set! sre->nfa ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14517,tmp=(C_word)a,a+=2,tmp));
t321=C_mutate(&lf[225] /* (set! nfa->dfa ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15307,tmp=(C_word)a,a+=2,tmp));
t322=C_mutate(&lf[283] /* (set! nfa-join-transitions! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15604,tmp=(C_word)a,a+=2,tmp));
t323=C_mutate(&lf[287] /* (set! char-range ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16066,tmp=(C_word)a,a+=2,tmp));
t324=C_mutate(&lf[285] /* (set! split-char-range ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16078,tmp=(C_word)a,a+=2,tmp));
t325=C_mutate(&lf[286] /* (set! intersect-char-ranges ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16152,tmp=(C_word)a,a+=2,tmp));
t326=C_mutate(&lf[282] /* (set! nfa-closure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16268,tmp=(C_word)a,a+=2,tmp));
t327=C_mutate(&lf[284] /* (set! insert-sorted ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16349,tmp=(C_word)a,a+=2,tmp));
t328=C_mutate(&lf[181] /* (set! sre-cset->procedure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18713,tmp=(C_word)a,a+=2,tmp));
t329=C_mutate(&lf[138] /* (set! sre->cset ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18830,tmp=(C_word)a,a+=2,tmp));
t330=C_mutate(&lf[288] /* (set! cset-contains? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19111,tmp=(C_word)a,a+=2,tmp));
t331=C_mutate(&lf[294] /* (set! cset-range ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19149,tmp=(C_word)a,a+=2,tmp));
t332=C_mutate(&lf[295] /* (set! char-ranges-overlap? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19161,tmp=(C_word)a,a+=2,tmp));
t333=C_mutate(&lf[289] /* (set! cset-union ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19306,tmp=(C_word)a,a+=2,tmp));
t334=C_mutate(&lf[291] /* (set! cset-difference ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19393,tmp=(C_word)a,a+=2,tmp));
t335=C_mutate(&lf[290] /* (set! cset-intersection ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19514,tmp=(C_word)a,a+=2,tmp));
t336=C_mutate(&lf[137] /* (set! cset-complement ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19632,tmp=(C_word)a,a+=2,tmp));
t337=C_mutate(&lf[126] /* (set! cset-case-insensitive ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19642,tmp=(C_word)a,a+=2,tmp));
t338=C_mutate((C_word*)lf[296]+1 /* (set! irregex-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19807,tmp=(C_word)a,a+=2,tmp));
t339=C_mutate((C_word*)lf[297]+1 /* (set! irregex-replace ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19920,tmp=(C_word)a,a+=2,tmp));
t340=C_mutate((C_word*)lf[299]+1 /* (set! irregex-replace/all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19972,tmp=(C_word)a,a+=2,tmp));
t341=C_mutate((C_word*)lf[298]+1 /* (set! irregex-apply-match ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20028,tmp=(C_word)a,a+=2,tmp));
t342=C_mutate((C_word*)lf[304]+1 /* (set! regexp? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20210,tmp=(C_word)a,a+=2,tmp));
t343=C_mutate((C_word*)lf[305]+1 /* (set! regexp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20228,tmp=(C_word)a,a+=2,tmp));
t344=C_mutate(&lf[306] /* (set! unregexp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20331,tmp=(C_word)a,a+=2,tmp));
t345=C_mutate((C_word*)lf[307]+1 /* (set! string-match ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20352,tmp=(C_word)a,a+=2,tmp));
t346=C_mutate((C_word*)lf[308]+1 /* (set! string-match-positions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20398,tmp=(C_word)a,a+=2,tmp));
t347=C_mutate((C_word*)lf[309]+1 /* (set! string-search ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20460,tmp=(C_word)a,a+=2,tmp));
t348=C_mutate((C_word*)lf[310]+1 /* (set! string-search-positions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20572,tmp=(C_word)a,a+=2,tmp));
t349=*((C_word*)lf[40]+1);
t350=*((C_word*)lf[311]+1);
t351=*((C_word*)lf[310]+1);
t352=C_mutate((C_word*)lf[312]+1 /* (set! string-split-fields ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20692,a[2]=t349,a[3]=t351,a[4]=t350,tmp=(C_word)a,a+=5,tmp));
t353=*((C_word*)lf[311]+1);
t354=*((C_word*)lf[40]+1);
t355=*((C_word*)lf[36]+1);
t356=*((C_word*)lf[310]+1);
t357=C_mutate((C_word*)lf[318]+1 /* (set! string-substitute ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20874,a[2]=t356,a[3]=t354,a[4]=t353,tmp=(C_word)a,a+=5,tmp));
t358=*((C_word*)lf[318]+1);
t359=C_mutate((C_word*)lf[321]+1 /* (set! string-substitute* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21129,a[2]=t358,tmp=(C_word)a,a+=3,tmp));
t360=C_mutate((C_word*)lf[322]+1 /* (set! glob? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_21181,tmp=(C_word)a,a+=2,tmp));
t361=C_mutate((C_word*)lf[323]+1 /* (set! glob->regexp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_21266,tmp=(C_word)a,a+=2,tmp));
t362=*((C_word*)lf[309]+1);
t363=C_mutate((C_word*)lf[325]+1 /* (set! grep ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21543,a[2]=t362,tmp=(C_word)a,a+=3,tmp));
t364=C_mutate((C_word*)lf[326]+1 /* (set! regexp-escape ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_21583,tmp=(C_word)a,a+=2,tmp));
t365=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t365+1)))(2,t365,C_SCHEME_UNDEFINED);}

/* regexp-escape in k4888 */
static void C_ccall f_21583(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_21583,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[326]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21590,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 318  open-output-string */
t5=*((C_word*)lf[329]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k21588 in regexp-escape in k4888 */
static void C_ccall f_21590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21590,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21598,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_21598(t6,((C_word*)t0)[2],C_fix(0));}

/* loop in k21588 in regexp-escape in k4888 */
static void C_fcall f_21598(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21598,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
/* regex.scm: 321  get-output-string */
t3=*((C_word*)lf[327]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(63)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(42)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(43)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(94)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(36)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(40)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(41)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(91)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(93)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(124)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(125)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_21617,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 324  ##sys#write-char-0 */
t5=*((C_word*)lf[328]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(92),((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21630,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 328  ##sys#write-char-0 */
t5=*((C_word*)lf[328]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,(C_word)C_subchar(((C_word*)t0)[3],t2),((C_word*)t0)[4]);}}}

/* k21628 in loop in k21588 in regexp-escape in k4888 */
static void C_ccall f_21630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 329  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_21598(t3,((C_word*)t0)[2],t2);}

/* k21615 in loop in k21588 in regexp-escape in k4888 */
static void C_ccall f_21617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21620,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 325  ##sys#write-char-0 */
t3=*((C_word*)lf[328]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,(C_word)C_subchar(((C_word*)t0)[3],((C_word*)t0)[6]),((C_word*)t0)[2]);}

/* k21618 in k21615 in loop in k21588 in regexp-escape in k4888 */
static void C_ccall f_21620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 326  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_21598(t3,((C_word*)t0)[2],t2);}

/* grep in k4888 */
static void C_ccall f_21543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_21543,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[325]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21552,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_21552(t8,t1,t3);}

/* loop in grep in k4888 */
static void C_fcall f_21552(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21552,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21571,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 306  string-search */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k21569 in loop in grep in k4888 */
static void C_ccall f_21571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21571,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21578,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 307  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_21552(t3,t2,((C_word*)t0)[2]);}
else{
/* regex.scm: 308  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_21552(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k21576 in k21569 in loop in grep in k4888 */
static void C_ccall f_21578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21578,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* glob->regexp in k4888 */
static void C_ccall f_21266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_21266,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[323]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21277,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21281,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t6=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k21279 in glob->regexp in k4888 */
static void C_ccall f_21281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21281,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21283,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_21283(t5,((C_word*)t0)[2],t1);}

/* loop in k21279 in glob->regexp in k4888 */
static void C_fcall f_21283(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_21283,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
switch(t3){
case C_make_character(42):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21313,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21317,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 272  loop */
t18=t6;
t19=t4;
t1=t18;
t2=t19;
goto loop;
case C_make_character(63):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21330,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 273  loop */
t18=t5;
t19=t4;
t1=t18;
t2=t19;
goto loop;
case C_make_character(91):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21343,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21345,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_21345(t9,t5,t4);
default:
t5=(C_word)C_u_i_char_alphabeticp(t3);
t6=(C_truep(t5)?t5:(C_word)C_u_i_char_numericp(t3));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21523,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 291  loop */
t18=t7;
t19=t4;
t1=t18;
t2=t19;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21534,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21538,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 292  loop */
t18=t8;
t19=t4;
t1=t18;
t2=t19;
goto loop;}}}}

/* k21536 in loop in k21279 in glob->regexp in k4888 */
static void C_ccall f_21538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k21532 in loop in k21279 in glob->regexp in k4888 */
static void C_ccall f_21534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21534,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(92),t2));}

/* k21521 in loop in k21279 in glob->regexp in k4888 */
static void C_ccall f_21523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21523,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop2 in loop in k21279 in glob->regexp in k4888 */
static void C_fcall f_21345(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21345,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(C_make_character(93),t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21365,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
/* regex.scm: 280  loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_21283(t7,t5,t6);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(C_make_character(45),t6);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
t9=t5;
f_21375(t9,(C_word)C_i_pairp(t8));}
else{
t8=t5;
f_21375(t8,C_SCHEME_FALSE);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k21373 in loop2 in loop in k21279 in glob->regexp in k4888 */
static void C_fcall f_21375(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21375,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21390,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21394,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[5]);
/* regex.scm: 282  loop2 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_21345(t6,t4,t5);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t6=t2;
f_21404(t6,(C_word)C_eqp(C_make_character(45),t5));}
else{
t5=t2;
f_21404(t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_21404(t4,C_SCHEME_FALSE);}}}

/* k21402 in k21373 in loop2 in loop in k21279 in glob->regexp in k4888 */
static void C_fcall f_21404(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21404,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21427,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21431,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cdddr(((C_word*)t0)[5]);
/* regex.scm: 286  loop2 */
t7=((C_word*)((C_word*)t0)[3])[1];
f_21345(t7,t5,t6);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21452,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 288  loop2 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_21345(t5,t3,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* regex.scm: 290  error */
t2=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[323],lf[324],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}}

/* k21450 in k21402 in k21373 in loop2 in loop in k21279 in glob->regexp in k4888 */
static void C_ccall f_21452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21452,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k21429 in k21402 in k21373 in loop2 in loop in k21279 in glob->regexp in k4888 */
static void C_ccall f_21431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k21425 in k21402 in k21373 in loop2 in loop in k21279 in glob->regexp in k4888 */
static void C_ccall f_21427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21427,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,C_make_character(45),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k21392 in k21373 in loop2 in loop in k21279 in glob->regexp in k4888 */
static void C_ccall f_21394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k21388 in k21373 in loop2 in loop in k21279 in glob->regexp in k4888 */
static void C_ccall f_21390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21390,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(45),t2));}

/* k21363 in loop2 in loop in k21279 in glob->regexp in k4888 */
static void C_ccall f_21365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21365,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(93),t1));}

/* k21341 in loop in k21279 in glob->regexp in k4888 */
static void C_ccall f_21343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21343,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(91),t1));}

/* k21328 in loop in k21279 in glob->regexp in k4888 */
static void C_ccall f_21330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21330,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(46),t1));}

/* k21315 in loop in k21279 in glob->regexp in k4888 */
static void C_ccall f_21317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k21311 in loop in k21279 in glob->regexp in k4888 */
static void C_ccall f_21313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21313,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(42),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(46),t2));}

/* k21275 in glob->regexp in k4888 */
static void C_ccall f_21277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* glob? in k4888 */
static void C_ccall f_21181(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_21181,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[322]);
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=(C_word)C_u_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21194,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_21194(t9,t1,t5);}

/* loop in glob? in k4888 */
static void C_fcall f_21194(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21194,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(0),t2))){
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(t3,C_make_character(42));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_21213(t6,t4);}
else{
t6=(C_word)C_eqp(t3,C_make_character(93));
t7=t5;
f_21213(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,C_make_character(63))));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k21211 in loop in glob? in k4888 */
static void C_fcall f_21213(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(C_fix(0),((C_word*)t0)[5]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_subchar(((C_word*)t0)[3],t3);
t5=(C_word)C_eqp(C_make_character(92),t4);
t6=(C_word)C_i_not(t5);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 257  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_21194(t8,((C_word*)t0)[4],t7);}}}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 259  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_21194(t3,((C_word*)t0)[4],t2);}}

/* string-substitute* in k4888 */
static void C_ccall f_21129(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4rv,(void*)f_21129r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_21129r(t0,t1,t2,t3,t4);}}

static void C_ccall f_21129r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(7);
t5=(C_word)C_i_check_string_2(t2,lf[321]);
t6=(C_word)C_i_check_list_2(t3,lf[321]);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_FALSE);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21144,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_21144(t12,t1,t2,t3);}

/* loop in string-substitute* in k4888 */
static void C_fcall f_21144(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21144,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21161,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t4);
t7=(C_word)C_slot(t4,C_fix(1));
/* regex.scm: 242  string-substitute */
t8=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t6,t7,t2,((C_word*)t0)[2]);}}

/* k21159 in loop in string-substitute* in k4888 */
static void C_ccall f_21161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 242  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_21144(t3,((C_word*)t0)[2],t1,t2);}

/* string-substitute in k4888 */
static void C_ccall f_20874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+32)){
C_save_and_reclaim((void*)tr5rv,(void*)f_20874r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_20874r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_20874r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a=C_alloc(32);
t6=(C_word)C_i_check_string_2(t3,lf[318]);
t7=(C_word)C_i_check_string_2(t4,lf[318]);
t8=(C_word)C_notvemptyp(t5);
t9=(C_truep(t8)?(C_word)C_slot(t5,C_fix(0)):C_fix(1));
t10=(C_word)C_block_size(t3);
t11=(C_word)C_block_size(t4);
t12=(C_word)C_u_fixnum_difference(t10,C_fix(1));
t13=C_SCHEME_END_OF_LIST;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_fix(0);
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20895,a[2]=t16,a[3]=t14,tmp=(C_word)a,a+=4,tmp);
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_20910,a[2]=t4,a[3]=t10,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t17,a[7]=t12,tmp=(C_word)a,a+=8,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_21016,a[2]=((C_word*)t0)[2],a[3]=t11,a[4]=t14,a[5]=((C_word*)t0)[3],a[6]=t16,a[7]=t4,a[8]=((C_word*)t0)[4],a[9]=t18,a[10]=t20,a[11]=t17,a[12]=t9,a[13]=t2,tmp=(C_word)a,a+=14,tmp));
t22=((C_word*)t20)[1];
f_21016(t22,t1,C_fix(0),C_fix(1));}

/* loop in string-substitute in k4888 */
static void C_fcall f_21016(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21016,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_21020,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[3]))){
/* regex.scm: 213  string-search-positions */
t5=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[13],((C_word*)t0)[7],t2);}
else{
t5=t4;
f_21020(2,t5,C_SCHEME_FALSE);}}

/* k21018 in loop in string-substitute in k4888 */
static void C_ccall f_21020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21020,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_u_fixnum_difference(t4,t5);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
/* regex.scm: 218  ##sys#error */
t8=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[14],lf[318],lf[319],((C_word*)t0)[13]);}
else{
t8=(C_word)C_fixnump(((C_word*)t0)[12]);
t9=(C_word)C_i_not(t8);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[12]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_21060,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t12=(C_word)C_u_i_car(t2);
/* regex.scm: 222  substring */
t13=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t11,((C_word*)t0)[6],((C_word*)t0)[5],t12);}
else{
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_21078,a[2]=t3,a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 226  substring */
t12=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t11,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_21111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[6]);
/* regex.scm: 229  substring */
t4=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}

/* k21109 in k21018 in loop in string-substitute in k4888 */
static void C_ccall f_21111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21111,2,t0,t1);}
t2=f_20895(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21107,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 230  reverse */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k21105 in k21109 in k21018 in loop in string-substitute in k4888 */
static void C_ccall f_21107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 230  ##sys#fragments->string */
t2=*((C_word*)lf[320]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k21076 in k21018 in loop in string-substitute in k4888 */
static void C_ccall f_21078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21078,2,t0,t1);}
t2=f_20895(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 227  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_21016(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k21058 in k21018 in loop in string-substitute in k4888 */
static void C_ccall f_21060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21060,2,t0,t1);}
t2=f_20895(C_a_i(&a,3),((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21053,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 223  substitute */
t4=((C_word*)t0)[3];
f_20910(t4,t3,((C_word*)t0)[2]);}

/* k21051 in k21058 in k21018 in loop in string-substitute in k4888 */
static void C_ccall f_21053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 224  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_21016(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* substitute in string-substitute in k4888 */
static void C_fcall f_20910(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20910,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_20916,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_20916(t6,t1,C_fix(0),C_fix(0));}

/* loop in substitute in string-substitute in k4888 */
static void C_fcall f_20916(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_20916,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20930,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t4;
f_20930(2,t6,((C_word*)t0)[7]);}
else{
/* regex.scm: 199  substring */
t6=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[7],t2,((C_word*)t0)[5]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[7],t3);
t5=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t6=(C_word)C_eqp(t4,C_make_character(92));
if(C_truep(t6)){
t7=(C_word)C_subchar(((C_word*)t0)[7],t5);
t8=(C_word)C_eqp(C_make_character(92),t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:(C_word)C_u_i_char_numericp(t7));
if(C_truep(t9)){
t10=(C_word)C_fix((C_word)C_character_code(t7));
t11=(C_word)C_u_fixnum_difference(t10,C_fix(48));
t12=(C_word)C_u_i_list_ref(((C_word*)t0)[4],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_20983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t12,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t3,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* regex.scm: 206  substring */
t14=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t13,((C_word*)t0)[7],t2,t3);}
else{
t10=(C_word)C_u_fixnum_plus(t5,C_fix(1));
/* regex.scm: 209  loop */
t18=t1;
t19=t2;
t20=t10;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}
else{
/* regex.scm: 210  loop */
t18=t1;
t19=t2;
t20=t5;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}}

/* k20981 in loop in substitute in string-substitute in k4888 */
static void C_ccall f_20983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20983,2,t0,t1);}
t2=f_20895(C_a_i(&a,3),((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_20971,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[4]);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* regex.scm: 207  substring */
t6=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,((C_word*)t0)[2],t4,t5);}

/* k20969 in k20981 in loop in substitute in string-substitute in k4888 */
static void C_ccall f_20971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20971,2,t0,t1);}
t2=f_20895(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 208  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_20916(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k20928 in loop in substitute in string-substitute in k4888 */
static void C_ccall f_20930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20930,2,t0,t1);}
/* regex.scm: 199  push */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_20895(C_a_i(&a,3),((C_word*)t0)[2],t1));}

/* push in string-substitute in k4888 */
static C_word C_fcall f_20895(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(C_word)C_block_size(t1);
t5=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t4);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
return(t6);}

/* string-split-fields in k4888 */
static void C_ccall f_20692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4rv,(void*)f_20692r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_20692r(t0,t1,t2,t3,t4);}}

static void C_ccall f_20692r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(16);
t5=(C_word)C_i_check_string_2(t3,lf[312]);
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_greaterp(t6,C_fix(0));
t9=(C_truep(t8)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_TRUE);
t10=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t11=(C_truep(t10)?(C_word)C_slot(t4,C_fix(1)):C_fix(0));
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_20711,a[2]=t11,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_eqp(t9,lf[314]);
if(C_truep(t13)){
t14=t12;
f_20711(t14,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20810,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t7,tmp=(C_word)a,a+=6,tmp));}
else{
t14=(C_word)C_eqp(t9,lf[313]);
t15=t12;
f_20711(t15,(C_truep(t14)?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20830,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t7,tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20856,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}}

/* f_20856 in string-split-fields in k4888 */
static void C_ccall f_20856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_20856,4,t0,t1,t2,t3);}
/* regex.scm: 159  reverse */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}

/* f_20830 in string-split-fields in k4888 */
static void C_ccall f_20830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_20830,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=(C_word)C_a_i_cons(&a,2,lf[317],t2);
/* regex.scm: 157  reverse */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20855,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 158  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],t3,((C_word*)t0)[5]);}}

/* k20853 */
static void C_ccall f_20855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20855,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* regex.scm: 158  reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_20810 in string-split-fields in k4888 */
static void C_ccall f_20810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_20810,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[5]))){
/* regex.scm: 151  ##sys#error */
t4=*((C_word*)lf[315]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[312],lf[316],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* regex.scm: 153  reverse */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k20709 in string-split-fields in k4888 */
static void C_fcall f_20711(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20711,NULL,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[313]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[314]));
t4=(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20794,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20799,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_20719,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_20719(t8,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k20709 in string-split-fields in k4888 */
static void C_fcall f_20719(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20719,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_20723,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* regex.scm: 164  string-search-positions */
t5=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k20721 in loop in k20709 in string-split-fields in k4888 */
static void C_ccall f_20723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20723,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(t4,((C_word*)t0)[8]);
if(C_truep(t6)){
/* regex.scm: 171  fini */
t7=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20765,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t4,C_fix(2));
/* regex.scm: 172  fetch */
t10=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,((C_word*)t0)[4],t8,t9);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20784,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 173  fetch */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[4],t3,t4);}}
else{
/* regex.scm: 174  fini */
t2=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k20782 in k20721 in loop in k20709 in string-split-fields in k4888 */
static void C_ccall f_20784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20784,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 173  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_20719(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k20763 in k20721 in loop in k20709 in string-split-fields in k4888 */
static void C_ccall f_20765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20765,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 172  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_20719(t4,((C_word*)t0)[2],t2,t3);}

/* f_20799 in k20709 in string-split-fields in k4888 */
static void C_ccall f_20799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_20799,5,t0,t1,t2,t3,t4);}
/* regex.scm: 162  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* f_20794 in k20709 in string-split-fields in k4888 */
static void C_ccall f_20794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_20794,5,t0,t1,t2,t3,t4);}
/* regex.scm: 161  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* string-search-positions in k4888 */
static void C_ccall f_20572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_20572r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_20572r(t0,t1,t2,t3,t4);}}

static void C_ccall f_20572r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(11);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20574,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20638,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20647,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start44804512 */
t8=t7;
f_20647(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-range44814508 */
t10=t6;
f_20638(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body44784487 */
t12=t5;
f_20574(t12,t1,t8,t10);}}}

/* def-start4480 in string-search-positions in k4888 */
static void C_fcall f_20647(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20647,NULL,2,t0,t1);}
/* def-range44814508 */
t2=((C_word*)t0)[2];
f_20638(t2,t1,C_fix(0));}

/* def-range4481 in string-search-positions in k4888 */
static void C_fcall f_20638(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20638,NULL,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
/* body44784487 */
t4=((C_word*)t0)[2];
f_20574(t4,t1,t2,t3);}

/* body4478 in string-search-positions in k4888 */
static void C_fcall f_20574(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20574,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20578,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 123  unregexp */
f_20331(t4,((C_word*)t0)[2]);}

/* k20576 in body4478 in string-search-positions in k4888 */
static void C_ccall f_20578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20578,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20587,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20633,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[2]);
/* regex.scm: 125  min */
t6=*((C_word*)lf[211]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k20631 in k20576 in body4478 in string-search-positions in k4888 */
static void C_ccall f_20633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 125  irregex-search */
t2=*((C_word*)lf[240]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k20585 in k20576 in body4478 in string-search-positions in k4888 */
static void C_ccall f_20587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20587,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20597,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 126  irregex-match-num-submatches */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k20595 in k20585 in k20576 in body4478 in string-search-positions in k4888 */
static void C_ccall f_20597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20597,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20599,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_20599(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k20595 in k20585 in k20576 in body4478 in string-search-positions in k4888 */
static void C_fcall f_20599(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_20599,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=f_5110(C_a_i(&a,8),((C_word*)t0)[3],t2);
t6=f_5124(C_a_i(&a,8),((C_word*)t0)[3],t2);
t7=(C_word)C_a_i_list(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
/* regex.scm: 130  loop */
t10=t1;
t11=t4;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* string-search in k4888 */
static void C_ccall f_20460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_20460r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_20460r(t0,t1,t2,t3,t4);}}

static void C_ccall f_20460r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(11);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20462,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20518,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20527,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start44174449 */
t8=t7;
f_20527(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-range44184445 */
t10=t6;
f_20518(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body44154424 */
t12=t5;
f_20462(t12,t1,t8,t10);}}}

/* def-start4417 in string-search in k4888 */
static void C_fcall f_20527(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20527,NULL,2,t0,t1);}
/* def-range44184445 */
t2=((C_word*)t0)[2];
f_20518(t2,t1,C_fix(0));}

/* def-range4418 in string-search in k4888 */
static void C_fcall f_20518(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20518,NULL,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
/* body44154424 */
t4=((C_word*)t0)[2];
f_20462(t4,t1,t2,t3);}

/* body4415 in string-search in k4888 */
static void C_fcall f_20462(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20462,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20466,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 113  unregexp */
f_20331(t4,((C_word*)t0)[2]);}

/* k20464 in body4415 in string-search in k4888 */
static void C_ccall f_20466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20466,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20475,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[2]);
/* regex.scm: 115  min */
t6=*((C_word*)lf[211]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k20511 in k20464 in body4415 in string-search in k4888 */
static void C_ccall f_20513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 115  irregex-search */
t2=*((C_word*)lf[240]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k20473 in k20464 in body4415 in string-search in k4888 */
static void C_ccall f_20475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20475,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20485,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 116  irregex-match-num-submatches */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k20483 in k20473 in k20464 in body4415 in string-search in k4888 */
static void C_ccall f_20485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20485,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20487,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_20487(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k20483 in k20473 in k20464 in body4415 in string-search in k4888 */
static void C_fcall f_20487(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20487,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20509,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 120  irregex-match-substring */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k20507 in loop in k20483 in k20473 in k20464 in body4415 in string-search in k4888 */
static void C_ccall f_20509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20509,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 120  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_20487(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* string-match-positions in k4888 */
static void C_ccall f_20398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_20398,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20402,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 102  unregexp */
f_20331(t4,t2);}

/* k20400 in string-match-positions in k4888 */
static void C_ccall f_20402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20405,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 103  irregex-match */
t3=*((C_word*)lf[245]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}

/* k20403 in k20400 in string-match-positions in k4888 */
static void C_ccall f_20405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20405,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20415,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 104  irregex-match-num-submatches */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k20413 in k20403 in k20400 in string-match-positions in k4888 */
static void C_ccall f_20415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20415,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20417,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_20417(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k20413 in k20403 in k20400 in string-match-positions in k4888 */
static void C_fcall f_20417(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_20417,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
t5=(C_word)C_a_i_list(&a,2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,t3));}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=f_5110(C_a_i(&a,8),((C_word*)t0)[3],t2);
t6=f_5124(C_a_i(&a,8),((C_word*)t0)[3],t2);
t7=(C_word)C_a_i_list(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
/* regex.scm: 108  loop */
t12=t1;
t13=t4;
t14=t8;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* string-match in k4888 */
static void C_ccall f_20352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_20352,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20356,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 93   unregexp */
f_20331(t4,t2);}

/* k20354 in string-match in k4888 */
static void C_ccall f_20356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 94   irregex-match */
t3=*((C_word*)lf[245]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}

/* k20357 in k20354 in string-match in k4888 */
static void C_ccall f_20359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20359,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20369,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 95   irregex-match-num-submatches */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k20367 in k20357 in k20354 in string-match in k4888 */
static void C_ccall f_20369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20369,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20371,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_20371(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k20367 in k20357 in k20354 in string-match in k4888 */
static void C_fcall f_20371(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20371,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3));}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20396,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 99   irregex-match-substring */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k20394 in loop in k20367 in k20357 in k20354 in string-match in k4888 */
static void C_ccall f_20396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20396,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 99   loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_20371(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* unregexp in k4888 */
static void C_fcall f_20331(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20331,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20338,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 85   regexp? */
t4=*((C_word*)lf[304]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k20336 in unregexp in k4888 */
static void C_ccall f_20338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20338,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t3,C_fix(1)));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 86   irregex? */
t3=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k20345 in k20336 in unregexp in k4888 */
static void C_ccall f_20347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* regex.scm: 87   irregex */
t2=*((C_word*)lf[178]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* regexp in k4888 */
static void C_ccall f_20228(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_20228r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_20228r(t0,t1,t2,t3);}}

static void C_ccall f_20228r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20230,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20261,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20266,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20271,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-caseless42994333 */
t8=t7;
f_20271(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-extended43004329 */
t10=t6;
f_20266(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-utf843014324 */
t12=t5;
f_20261(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body42974307 */
t14=t4;
f_20230(t14,t1,t8,t10,t12);}}}}

/* def-caseless4299 in regexp in k4888 */
static void C_fcall f_20271(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20271,NULL,2,t0,t1);}
/* def-extended43004329 */
t2=((C_word*)t0)[2];
f_20266(t2,t1,C_SCHEME_FALSE);}

/* def-extended4300 in regexp in k4888 */
static void C_fcall f_20266(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20266,NULL,3,t0,t1,t2);}
/* def-utf843014324 */
t3=((C_word*)t0)[2];
f_20261(t3,t1,t2,C_SCHEME_FALSE);}

/* def-utf84301 in regexp in k4888 */
static void C_fcall f_20261(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20261,NULL,4,t0,t1,t2,t3);}
/* body42974307 */
t4=((C_word*)t0)[2];
f_20230(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body4297 in regexp in k4888 */
static void C_fcall f_20230(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20230,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20238,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_20242,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t9=(C_word)C_a_i_cons(&a,2,lf[57],((C_word*)t7)[1]);
t10=C_set_block_item(t7,0,t9);
t11=t8;
f_20242(t11,t10);}
else{
t9=t8;
f_20242(t9,C_SCHEME_UNDEFINED);}}

/* k20240 in body4297 in regexp in k4888 */
static void C_fcall f_20242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20242,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20245,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_cons(&a,2,lf[62],((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=t2;
f_20245(t5,t4);}
else{
t3=t2;
f_20245(t3,C_SCHEME_UNDEFINED);}}

/* k20243 in k20240 in body4297 in regexp in k4888 */
static void C_fcall f_20245(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20245,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20248,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_cons(&a,2,lf[65],((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=t2;
f_20248(t5,t4);}
else{
t3=t2;
f_20248(t3,C_SCHEME_UNDEFINED);}}

/* k20246 in k20243 in k20240 in body4297 in regexp in k4888 */
static void C_fcall f_20248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
C_apply(5,0,((C_word*)t0)[3],*((C_word*)lf[178]+1),((C_word*)t0)[2],t2);}

/* k20236 in body4297 in regexp in k4888 */
static void C_ccall f_20238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20238,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[305],t1));}

/* regexp? in k4888 */
static void C_ccall f_20210(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_20210,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[305]));}

/* irregex-apply-match in k4888 */
static void C_ccall f_20028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_20028,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20034,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_20034(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in irregex-apply-match in k4888 */
static void C_fcall f_20034(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_20034,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_integerp(t4))){
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20062,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_u_i_car(t2);
/* irregex-match-substring */
t8=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_closurep(t5))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20090,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_u_i_car(t2);
t9=t8;
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,((C_word*)t0)[2]);}
else{
t6=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t6))){
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_eqp(t7,lf[301]);
if(C_truep(t8)){
t9=(C_word)C_slot(t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20123,a[2]=t9,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20127,a[2]=((C_word*)t0)[2],a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-string */
t12=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[2]);}
else{
t9=(C_word)C_eqp(t7,lf[302]);
if(C_truep(t9)){
t10=(C_word)C_slot(t2,C_fix(1));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20152,a[2]=t10,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20156,a[2]=((C_word*)t0)[2],a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-string */
t13=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t0)[2]);}
else{
t10=(C_word)C_u_i_car(t2);
/* error */
t11=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[303],t10);}}}
else{
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_i_car(t2);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* lp4091 */
t27=t1;
t28=t7;
t29=t9;
t1=t27;
t2=t28;
t3=t29;
goto loop;}}}}}

/* k20154 in lp in irregex-apply-match in k4888 */
static void C_ccall f_20156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20160,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* irregex-match-end */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k20158 in k20154 in lp in irregex-apply-match in k4888 */
static void C_ccall f_20160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20168,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* irregex-match-string */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k20166 in k20158 in k20154 in lp in irregex-apply-match in k4888 */
static void C_ccall f_20168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fix((C_word)C_header_size(t1));
/* substring */
t3=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k20150 in lp in irregex-apply-match in k4888 */
static void C_ccall f_20152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20152,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* lp4091 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_20034(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k20125 in lp in irregex-apply-match in k4888 */
static void C_ccall f_20127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20131,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* irregex-match-start */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k20129 in k20125 in lp in irregex-apply-match in k4888 */
static void C_ccall f_20131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* substring */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

/* k20121 in lp in irregex-apply-match in k4888 */
static void C_ccall f_20123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20123,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* lp4091 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_20034(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k20088 in lp in irregex-apply-match in k4888 */
static void C_ccall f_20090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20090,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* lp4091 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_20034(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k20060 in lp in irregex-apply-match in k4888 */
static void C_ccall f_20062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20062,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[300]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[5]);
/* lp4091 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_20034(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* irregex-replace/all in k4888 */
static void C_ccall f_19972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_19972r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_19972r(t0,t1,t2,t3,t4);}}

static void C_ccall f_19972r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19978,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20005,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* irregex-fold */
t7=*((C_word*)lf[296]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t1,t2,t5,C_SCHEME_END_OF_LIST,t3,t6);}

/* a20004 in irregex-replace/all in k4888 */
static void C_ccall f_20005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_20005,4,t0,t1,t2,t3);}
t4=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[2]));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20016,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nequalp(t2,t4))){
t6=t5;
f_20016(t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20026,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* substring */
t7=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[2],t2,t4);}}

/* k20024 in a20004 in irregex-replace/all in k4888 */
static void C_ccall f_20026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20026,2,t0,t1);}
t2=((C_word*)t0)[3];
f_20016(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k20014 in a20004 in irregex-replace/all in k4888 */
static void C_fcall f_20016(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-cat-reverse */
f_5585(((C_word*)t0)[2],t1);}

/* a19977 in irregex-replace/all in k4888 */
static void C_ccall f_19978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_19978,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_19982,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* irregex-match-start */
t6=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,C_fix(0));}

/* k19980 in a19977 in irregex-replace/all in k4888 */
static void C_ccall f_19982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19989,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* irregex-apply-match */
t3=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k19987 in k19980 in a19977 in irregex-replace/all in k4888 */
static void C_ccall f_19989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19993,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[5],((C_word*)t0)[4]))){
t3=t2;
f_19993(t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20003,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* substring */
t4=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k20001 in k19987 in k19980 in a19977 in irregex-replace/all in k4888 */
static void C_ccall f_20003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20003,2,t0,t1);}
t2=((C_word*)t0)[3];
f_19993(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k19991 in k19987 in k19980 in a19977 in irregex-replace/all in k4888 */
static void C_fcall f_19993(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* irregex-replace in k4888 */
static void C_ccall f_19920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_19920r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_19920r(t0,t1,t2,t3,t4);}}

static void C_ccall f_19920r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19924,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19970,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* irregex */
t7=*((C_word*)lf[178]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k19968 in irregex-replace in k4888 */
static void C_ccall f_19970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* irregex-search */
t2=*((C_word*)lf[240]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k19922 in irregex-replace in k4888 */
static void C_ccall f_19924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19924,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19938,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19962,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* irregex-match-end */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_fix(0));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k19960 in k19922 in irregex-replace in k4888 */
static void C_ccall f_19962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
/* substring */
t3=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],((C_word*)t0)[3],t1,t2);}

/* k19936 in k19922 in irregex-replace in k4888 */
static void C_ccall f_19938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19942,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19946,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* irregex-apply-match */
t4=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k19944 in k19936 in k19922 in irregex-replace in k4888 */
static void C_ccall f_19946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19954,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19958,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-start */
t4=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_fix(0));}

/* k19956 in k19944 in k19936 in k19922 in irregex-replace in k4888 */
static void C_ccall f_19958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* substring */
t2=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

/* k19952 in k19944 in k19936 in k19922 in irregex-replace in k4888 */
static void C_ccall f_19954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19954,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k19940 in k19936 in k19922 in irregex-replace in k4888 */
static void C_ccall f_19942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19942,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* string-cat-reverse */
f_5585(((C_word*)t0)[2],t2);}

/* irregex-fold in k4888 */
static void C_ccall f_19807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr6r,(void*)f_19807r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_19807r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_19807r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19811,a[2]=t4,a[3]=t1,a[4]=t3,a[5]=t5,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* irregex */
t8=*((C_word*)lf[178]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k19809 in irregex-fold in k4888 */
static void C_ccall f_19811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_19814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* irregex-new-matches */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k19812 in k19809 in irregex-fold in k4888 */
static void C_ccall f_19814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19814,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_u_i_car(((C_word*)t0)[7]):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19917,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_19897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t5=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t6=t4;
f_19897(t6,(C_word)C_i_pairp(t5));}
else{
t5=t4;
f_19897(t5,C_SCHEME_FALSE);}}

/* k19895 in k19812 in k19809 in irregex-fold in k4888 */
static void C_fcall f_19897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19897,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_cadr(((C_word*)t0)[9]):C_fix(0));
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_19868,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[9]))){
t4=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t6=t3;
f_19868(t6,(C_word)C_i_pairp(t5));}
else{
t5=t3;
f_19868(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_19868(t4,C_SCHEME_FALSE);}}

/* k19866 in k19895 in k19812 in k19809 in irregex-fold in k4888 */
static void C_fcall f_19868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19868,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_caddr(((C_word*)t0)[10]):(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[9])));
t3=f_5104(((C_word*)t0)[8],((C_word*)t0)[9]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_19831,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=t5,a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_19831(t7,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k19866 in k19895 in k19812 in k19809 in irregex-fold in k4888 */
static void C_fcall f_19831(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19831,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[8]))){
/* finish4029 */
t4=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_19844,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* irregex-search/matches */
t5=*((C_word*)lf[241]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,((C_word*)t0)[8],((C_word*)t0)[5]);}}

/* k19842 in lp in k19866 in k19895 in k19812 in k19809 in irregex-fold in k4888 */
static void C_ccall f_19844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19844,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_19856,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* irregex-match-end */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_fix(0));}
else{
/* finish4029 */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k19854 in k19842 in lp in k19866 in k19895 in k19812 in k19809 in irregex-fold in k4888 */
static void C_ccall f_19856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19859,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* kons4019 */
t3=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k19857 in k19854 in k19842 in lp in k19866 in k19895 in k19812 in k19809 in irregex-fold in k4888 */
static void C_ccall f_19859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19862,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* irregex-reset-matches! */
t3=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k19860 in k19857 in k19854 in k19842 in lp in k19866 in k19895 in k19812 in k19809 in irregex-fold in k4888 */
static void C_ccall f_19862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp4045 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_19831(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_19917 in k19812 in k19809 in irregex-fold in k4888 */
static void C_ccall f_19917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_19917,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* cset-case-insensitive in k4888 */
static void C_ccall f_19642(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_19642,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19648,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_19648(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* lp in cset-case-insensitive in k4888 */
static void C_fcall f_19648(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19648,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19664,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_charp(t5))){
t6=(C_word)C_u_i_car(t2);
t7=t4;
f_19664(t7,(C_word)C_u_i_char_alphabeticp(t6));}
else{
t6=t4;
f_19664(t6,C_SCHEME_FALSE);}}}

/* k19662 in lp in cset-case-insensitive in k4888 */
static void C_fcall f_19664(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19664,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=f_9191(t2);
t4=(C_word)C_u_i_car(((C_word*)t0)[5]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[4]);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19684,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* cset-contains? */
f_19111(t7,t5,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19701,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_caar(((C_word*)t0)[5]);
if(C_truep((C_word)C_u_i_char_alphabeticp(t4))){
t5=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t6=t2;
f_19701(t6,(C_word)C_u_i_char_alphabeticp(t5));}
else{
t5=t2;
f_19701(t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_19701(t4,C_SCHEME_FALSE);}}}

/* k19699 in k19662 in lp in cset-case-insensitive in k4888 */
static void C_fcall f_19701(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19701,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19712,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19716,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,1,t5);
/* cset-union */
t7=lf[289];
f_19306(4,t7,t4,((C_word*)t0)[2],t6);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19759,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* cset-union */
t6=lf[289];
f_19306(4,t6,t3,((C_word*)t0)[2],t5);}}

/* k19757 in k19699 in k19662 in lp in cset-case-insensitive in k4888 */
static void C_ccall f_19759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3994 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_19648(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k19714 in k19699 in k19662 in lp in cset-case-insensitive in k4888 */
static void C_ccall f_19716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19716,2,t0,t1);}
t2=(C_word)C_u_i_caar(((C_word*)t0)[3]);
t3=f_9191(t2);
t4=(C_word)C_u_i_cdar(((C_word*)t0)[3]);
t5=f_9191(t4);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=(C_word)C_a_i_list(&a,1,t6);
/* cset-union */
t8=lf[289];
f_19306(4,t8,((C_word*)t0)[2],t1,t7);}

/* k19710 in k19699 in k19662 in lp in cset-case-insensitive in k4888 */
static void C_ccall f_19712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3994 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_19648(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k19682 in k19662 in lp in cset-case-insensitive in k4888 */
static void C_ccall f_19684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19684,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[6]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]));
/* lp3994 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_19648(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* cset-complement in k4888 */
static void C_fcall f_19632(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19632,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19640,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* sre->cset */
f_18830(t3,lf[32],C_SCHEME_END_OF_LIST);}

/* k19638 in cset-complement in k4888 */
static void C_ccall f_19640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-difference */
f_19393(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* cset-intersection in k4888 */
static void C_ccall f_19514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_19514,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19520,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_19520(t7,t1,t2,t3,C_SCHEME_END_OF_LIST);}

/* intersect in cset-intersection in k4888 */
static void C_fcall f_19520(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19520,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19530,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19622,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* find-tail */
f_5736(t5,t6,t2);}}

/* a19621 in intersect in cset-intersection in k4888 */
static void C_ccall f_19622(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_19622,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* char-ranges-overlap? */
f_19161(t1,t2,t3);}

/* k19528 in intersect in cset-intersection in k4888 */
static void C_ccall f_19530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19530,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19538,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19597,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(t1);
t5=f_19149(C_a_i(&a,3),t4);
t6=(C_word)C_u_i_car(((C_word*)t0)[4]);
t7=f_19149(C_a_i(&a,3),t6);
/* intersect-char-ranges */
f_16152(t3,t5,t7);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* intersect3947 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_19520(t3,((C_word*)t0)[2],((C_word*)t0)[3],t2,((C_word*)t0)[5]);}}

/* k19595 in k19528 in intersect in cset-intersection in k4888 */
static void C_ccall f_19597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a19537 in k19528 in intersect in cset-intersection in k4888 */
static void C_ccall f_19538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_19538,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_19542,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19589,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* take-up-to */
f_5681(t8,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k19587 in a19537 in k19528 in intersect in cset-intersection in k4888 */
static void C_ccall f_19589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k19540 in a19537 in k19528 in intersect in cset-intersection in k4888 */
static void C_ccall f_19542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19542,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[10])?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1):t1);
t3=(C_truep(((C_word*)t0)[9])?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2):t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_19551,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* cset-union */
t6=lf[289];
f_19306(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t5=t4;
f_19551(2,t5,((C_word*)t0)[2]);}}

/* k19549 in k19540 in a19537 in k19528 in intersect in cset-intersection in k4888 */
static void C_ccall f_19551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19554,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* cset-union */
t4=lf[289];
f_19306(4,t4,t2,t1,t3);}
else{
t3=t2;
f_19554(2,t3,t1);}}

/* k19552 in k19549 in k19540 in a19537 in k19528 in intersect in cset-intersection in k4888 */
static void C_ccall f_19554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19561,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* cset-union */
t4=lf[289];
f_19306(4,t4,t2,((C_word*)t0)[2],t3);}

/* k19559 in k19552 in k19549 in k19540 in a19537 in k19528 in intersect in cset-intersection in k4888 */
static void C_ccall f_19561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* intersect3947 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_19520(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cset-difference in k4888 */
static void C_fcall f_19393(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_19393,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep((C_word)C_u_i_car(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19416,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19500,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* find-tail */
f_5736(t4,t5,t2);}
else{
t4=(C_word)C_slot(t3,C_fix(1));
/* cset-difference */
t8=t1;
t9=t2;
t10=t4;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* a19499 in cset-difference in k4888 */
static void C_ccall f_19500(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_19500,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* char-ranges-overlap? */
f_19161(t1,t2,t3);}

/* k19414 in cset-difference in k4888 */
static void C_ccall f_19416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19416,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19424,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19475,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(t1);
t5=f_19149(C_a_i(&a,3),t4);
t6=(C_word)C_u_i_car(((C_word*)t0)[4]);
t7=f_19149(C_a_i(&a,3),t6);
/* intersect-char-ranges */
f_16152(t3,t5,t7);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* cset-difference */
f_19393(((C_word*)t0)[2],((C_word*)t0)[3],t2);}}

/* k19473 in k19414 in cset-difference in k4888 */
static void C_ccall f_19475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a19423 in k19414 in cset-difference in k4888 */
static void C_ccall f_19424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_19424,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_19428,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,a[5]=t1,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19467,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* take-up-to */
f_5681(t8,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k19465 in a19423 in k19414 in cset-difference in k4888 */
static void C_ccall f_19467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k19426 in a19423 in k19414 in cset-difference in k4888 */
static void C_ccall f_19428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19428,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[7])?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1):t1);
t3=(C_truep(((C_word*)t0)[6])?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2):t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19437,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* cset-union */
t6=lf[289];
f_19306(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t5=t4;
f_19437(2,t5,((C_word*)t0)[2]);}}

/* k19435 in k19426 in a19423 in k19414 in cset-difference in k4888 */
static void C_ccall f_19437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19440,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* cset-union */
t4=lf[289];
f_19306(4,t4,t2,t1,t3);}
else{
t3=t2;
f_19440(2,t3,t1);}}

/* k19438 in k19435 in k19426 in a19423 in k19414 in cset-difference in k4888 */
static void C_ccall f_19440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-difference */
f_19393(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cset-union in k4888 */
static void C_ccall f_19306(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_19306,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19316,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19383,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* find-tail */
f_5736(t4,t5,t2);}}

/* a19382 in cset-union in k4888 */
static void C_ccall f_19383(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_19383,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* char-ranges-overlap? */
f_19161(t1,t2,t3);}

/* k19314 in cset-union in k4888 */
static void C_ccall f_19316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19316,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19326,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19334,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19362,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* take-up-to */
f_5681(t4,((C_word*)t0)[2],t1);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* cset-union */
t5=lf[289];
f_19306(4,t5,((C_word*)t0)[3],t3,t4);}}

/* k19360 in k19314 in cset-union in k4888 */
static void C_ccall f_19362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k19332 in k19314 in cset-union in k4888 */
static void C_ccall f_19334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19334,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=f_19149(C_a_i(&a,3),t2);
t4=(C_word)C_u_i_car(((C_word*)t0)[3]);
t5=f_19149(C_a_i(&a,3),t4);
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_u_i_car(t5);
t8=(C_word)C_fixnum_less_or_equal_p(t6,t7);
t9=(C_truep(t8)?(C_word)C_u_i_car(t3):(C_word)C_u_i_car(t5));
t10=(C_word)C_slot(t3,C_fix(1));
t11=(C_word)C_slot(t5,C_fix(1));
t12=(C_word)C_fixnum_greater_or_equal_p(t10,t11);
t13=(C_truep(t12)?(C_word)C_slot(t3,C_fix(1)):(C_word)C_slot(t5,C_fix(1)));
t14=(C_word)C_a_i_cons(&a,2,t9,t13);
t15=(C_word)C_a_i_list(&a,1,t14);
/* cset-union */
t16=lf[289];
f_19306(4,t16,((C_word*)t0)[2],t1,t15);}

/* k19324 in k19314 in cset-union in k4888 */
static void C_ccall f_19326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* cset-union */
t3=lf[289];
f_19306(4,t3,((C_word*)t0)[2],t1,t2);}

/* char-ranges-overlap? in k4888 */
static void C_fcall f_19161(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_19161,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19177,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,t6))){
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t2,C_fix(1));
t9=t4;
f_19177(t9,(C_word)C_fixnum_less_or_equal_p(t7,t8));}
else{
t7=t4;
f_19177(t7,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t3))){
t5=(C_word)C_slot(t2,C_fix(1));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_less_or_equal_p(t3,t5));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}
else{
if(C_truep((C_word)C_i_pairp(t3))){
/* char-ranges-overlap? */
t12=t1;
t13=t3;
t14=t2;
t1=t12;
t2=t13;
t3=t14;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_eqvp(t2,t3));}}}

/* k19175 in char-ranges-overlap? in k4888 */
static void C_fcall f_19177(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t3))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(C_word)C_u_i_car(((C_word*)t0)[3]);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_less_or_equal_p(t4,t5));}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* cset-range in k4888 */
static C_word C_fcall f_19149(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_charp(t1);
return((C_truep(t2)?(C_word)C_a_i_cons(&a,2,t1,t1):t1));}

/* cset-contains? in k4888 */
static void C_fcall f_19111(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19111,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19117,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* find */
f_5724(t1,t4,t2);}

/* a19116 in cset-contains? in k4888 */
static void C_ccall f_19117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_19117,3,t0,t1,t2);}
t3=(C_word)C_i_eqvp(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,((C_word*)t0)[2]))){
t5=(C_word)C_slot(t2,C_fix(1));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t5));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* sre->cset in k4888 */
static void C_fcall f_18830(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18830,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_u_i_car(t3):C_SCHEME_FALSE);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18840,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_18840(t9,t1,t2,t5);}

/* lp in sre->cset in k4888 */
static void C_fcall f_18840(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_18840,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18843,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t5))){
if(C_truep(t3)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18869,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_u_i_car(t2);
/* string->list */
t8=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t6=(C_word)C_u_i_car(t2);
/* string->list */
t7=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[124]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18896,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18900,a[2]=t4,a[3]=t2,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_u_i_cadr(t2);
/* rec3825 */
t11=t4;
f_18843(3,t11,t9,t10);}
else{
t8=(C_word)C_eqp(t6,lf[192]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18925,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_u_i_cadr(t2);
/* rec3825 */
t11=t4;
f_18843(3,t11,t9,t10);}
else{
t9=(C_word)C_eqp(t6,lf[203]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18948,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18956,a[2]=t4,a[3]=t2,a[4]=t10,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_u_i_cadr(t2);
/* rec3825 */
t13=t4;
f_18843(3,t13,t11,t12);}
else{
t10=(C_word)C_eqp(t6,lf[31]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18977,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18987,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(C_word)C_slot(t2,C_fix(1));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13588,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=((C_word*)t15)[1];
f_13588(t17,t12,t13,C_SCHEME_END_OF_LIST);}
else{
t11=(C_word)C_eqp(t6,lf[70]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19004,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(C_word)C_u_i_cadr(t2);
/* rec3825 */
t14=t4;
f_18843(3,t14,t12,t13);}
else{
t12=(C_word)C_eqp(t6,lf[183]);
if(C_truep(t12)){
t13=(C_word)C_slot(t2,C_fix(1));
t14=f_13504(C_a_i(&a,3),t13);
/* lp3814 */
t43=t1;
t44=t14;
t45=C_SCHEME_FALSE;
t1=t43;
t2=t44;
t3=t45;
goto loop;}
else{
t13=(C_word)C_eqp(t6,lf[184]);
if(C_truep(t13)){
t14=(C_word)C_slot(t2,C_fix(1));
t15=f_13504(C_a_i(&a,3),t14);
/* lp3814 */
t43=t1;
t44=t15;
t45=C_SCHEME_TRUE;
t1=t43;
t2=t44;
t3=t45;
goto loop;}
else{
/* error */
t14=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[292],t2);}}}}}}}}}
else{
if(C_truep((C_word)C_charp(t2))){
t5=(C_word)C_a_i_string(&a,1,t2);
t6=(C_word)C_a_i_list(&a,1,t5);
/* rec3825 */
t7=t4;
f_18843(3,t7,t1,t6);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t5=(C_word)C_a_i_list(&a,1,t2);
/* rec3825 */
t6=t4;
f_18843(3,t6,t1,t5);}
else{
t5=(C_word)C_u_i_assq(t2,lf[204]);
if(C_truep(t5)){
t6=(C_word)C_slot(t5,C_fix(1));
/* rec3825 */
t7=t4;
f_18843(3,t7,t1,t6);}
else{
/* error */
t6=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[293],t2);}}}}}

/* k19002 in lp in sre->cset in k4888 */
static void C_ccall f_19004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19008,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k19006 in k19002 in lp in sre->cset in k4888 */
static void C_ccall f_19008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_5908(((C_word*)t0)[3],lf[289],((C_word*)t0)[2],t1);}

/* lp in lp in sre->cset in k4888 */
static void C_fcall f_13588(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_13588,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13611,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13615,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_u_i_car(t2);
/* string->list */
t8=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* lp2259 */
t12=t1;
t13=t5;
t14=t7;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}}

/* k13613 in lp in lp in sre->cset in k4888 */
static void C_ccall f_13615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k13609 in lp in lp in sre->cset in k4888 */
static void C_ccall f_13611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2259 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_13588(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k18985 in lp in sre->cset in k4888 */
static void C_ccall f_18987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18987,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18754,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_18754(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* lp in k18985 in lp in sre->cset in k4888 */
static void C_fcall f_18754(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_18754,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_u_i_cddr(t2);
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_u_i_cadr(t2);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
/* lp3793 */
t10=t1;
t11=t4;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k18975 in lp in sre->cset in k4888 */
static void C_ccall f_18977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
/* cset-case-insensitive */
t2=lf[126];
f_19642(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k18954 in lp in sre->cset in k4888 */
static void C_ccall f_18956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18960,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k18958 in k18954 in lp in sre->cset in k4888 */
static void C_ccall f_18960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_5908(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a18947 in lp in sre->cset in k4888 */
static void C_ccall f_18948(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_18948,4,t0,t1,t2,t3);}
/* cset-difference */
f_19393(t1,t3,t2);}

/* k18923 in lp in sre->cset in k4888 */
static void C_ccall f_18925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18929,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k18927 in k18923 in lp in sre->cset in k4888 */
static void C_ccall f_18929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_5908(((C_word*)t0)[3],lf[290],((C_word*)t0)[2],t1);}

/* k18898 in lp in sre->cset in k4888 */
static void C_ccall f_18900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18904,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k18902 in k18898 in lp in sre->cset in k4888 */
static void C_ccall f_18904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_5908(((C_word*)t0)[3],lf[289],((C_word*)t0)[2],t1);}

/* k18894 in lp in sre->cset in k4888 */
static void C_ccall f_18896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-complement */
f_19632(((C_word*)t0)[2],t1);}

/* k18867 in lp in sre->cset in k4888 */
static void C_ccall f_18869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-case-insensitive */
t2=lf[126];
f_19642(3,t2,((C_word*)t0)[2],t1);}

/* rec in lp in sre->cset in k4888 */
static void C_ccall f_18843(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_18843,3,t0,t1,t2);}
/* lp3814 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_18840(t3,t1,t2,((C_word*)t0)[2]);}

/* sre-cset->procedure in k4888 */
static void C_fcall f_18713(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18713,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18715,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));}

/* f_18715 in sre-cset->procedure in k4888 */
static void C_ccall f_18715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18715,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18722,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t7))){
t8=(C_word)C_subchar(t2,t3);
/* cset-contains? */
f_19111(t6,((C_word*)t0)[2],t8);}
else{
t8=t6;
f_18722(2,t8,C_SCHEME_FALSE);}}

/* k18720 */
static void C_ccall f_18722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18722,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* next3781 */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3786 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* insert-sorted in k4888 */
static void C_fcall f_16349(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_16349,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}
else{
t4=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_i_less_or_equalp(t2,t4))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_i_nequalp(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t3:(C_word)C_a_i_cons(&a,2,t2,t3)));}
else{
t5=(C_word)C_u_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16389,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* insert-sorted */
t11=t6;
t12=t2;
t13=t7;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* k16387 in insert-sorted in k4888 */
static void C_ccall f_16389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16389,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* nfa-closure in k4888 */
static void C_fcall f_16268(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16268,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16274,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_16274(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in nfa-closure in k4888 */
static void C_fcall f_16274(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_16274,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_memv(t4,t3))){
t5=(C_word)C_slot(t2,C_fix(1));
/* lp3069 */
t14=t1;
t15=t5;
t16=t3;
t1=t14;
t2=t15;
t3=t16;
goto loop;}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16301,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16313,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16321,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16323,tmp=(C_word)a,a+=2,tmp);
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_i_assv(t9,((C_word*)t0)[2]);
t11=(C_word)C_slot(t10,C_fix(1));
/* filter */
f_5938(t7,t8,t11);}}}

/* a16322 in lp in nfa-closure in k4888 */
static void C_ccall f_16323(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_16323,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[83],t3));}

/* k16319 in lp in nfa-closure in k4888 */
static void C_ccall f_16321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[281]+1),t1);}

/* k16311 in lp in nfa-closure in k4888 */
static void C_ccall f_16313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k16299 in lp in nfa-closure in k4888 */
static void C_ccall f_16301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16305,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* insert-sorted */
f_16349(t2,t3,((C_word*)t0)[2]);}

/* k16303 in k16299 in lp in nfa-closure in k4888 */
static void C_ccall f_16305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3069 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_16274(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* intersect-char-ranges in k4888 */
static void C_fcall f_16152(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_16152,NULL,3,t1,t2,t3);}
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_fixnum_greaterp(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16166,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* intersect-char-ranges */
t16=t6;
t17=t3;
t18=t2;
t1=t16;
t2=t17;
t3=t18;
goto loop;}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16185,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t6,t8))){
t11=(C_word)C_fix((C_word)C_character_code(t8));
t12=(C_word)C_a_i_minus(&a,2,t11,C_fix(1));
t13=(C_word)C_make_character((C_word)C_unfix(t12));
/* char-range */
t14=t10;
f_16185(t14,f_16066(C_a_i(&a,3),t6,t13));}
else{
t11=t10;
f_16185(t11,C_SCHEME_FALSE);}}}

/* k16183 in intersect-char-ranges in k4888 */
static void C_fcall f_16185(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16185,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16189,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],((C_word*)t0)[5]))){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t4=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
/* char-range */
t6=t2;
f_16189(t6,f_16066(C_a_i(&a,3),t5,((C_word*)t0)[4]));}
else{
t3=t2;
f_16189(t3,C_SCHEME_FALSE);}}

/* k16187 in k16183 in intersect-char-ranges in k4888 */
static void C_fcall f_16189(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16189,NULL,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_truep(t2)?((C_word*)t0)[6]:((C_word*)t0)[5]);
t4=f_16066(C_a_i(&a,3),((C_word*)t0)[4],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16197,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[6],((C_word*)t0)[5]))){
t6=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t7=(C_word)C_a_i_plus(&a,2,t6,C_fix(1));
t8=(C_word)C_make_character((C_word)C_unfix(t7));
/* char-range */
t9=t5;
f_16197(t9,f_16066(C_a_i(&a,3),t8,((C_word*)t0)[6]));}
else{
t6=t5;
f_16197(t6,C_SCHEME_FALSE);}}

/* k16195 in k16187 in k16183 in intersect-char-ranges in k4888 */
static void C_fcall f_16197(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16197,NULL,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k16164 in intersect-char-ranges in k4888 */
static void C_ccall f_16166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* reverse */
t2=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* split-char-range in k4888 */
static void C_fcall f_16078(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16078,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16086,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_eqvp(t3,t5))){
t6=t4;
f_16086(t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_fix((C_word)C_character_code(t3));
t8=(C_word)C_a_i_minus(&a,2,t7,C_fix(1));
t9=(C_word)C_make_character((C_word)C_unfix(t8));
/* char-range */
t10=t4;
f_16086(t10,f_16066(C_a_i(&a,3),t6,t9));}}

/* k16084 in split-char-range in k4888 */
static void C_fcall f_16086(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16086,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16090,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[2],t3))){
t4=t2;
f_16090(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[2]));
t5=(C_word)C_a_i_plus(&a,2,t4,C_fix(1));
t6=(C_word)C_make_character((C_word)C_unfix(t5));
t7=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* char-range */
t8=t2;
f_16090(t8,f_16066(C_a_i(&a,3),t6,t7));}}

/* k16088 in k16084 in split-char-range in k4888 */
static void C_fcall f_16090(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16090,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* char-range in k4888 */
static C_word C_fcall f_16066(C_word *a,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
t3=(C_word)C_i_eqvp(t1,t2);
return((C_truep(t3)?t1:(C_word)C_a_i_cons(&a,2,t1,t2)));}

/* nfa-join-transitions! in k4888 */
static void C_fcall f_15604(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15604,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15607,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_charp(t5))){
t6=(C_word)C_u_i_car(t3);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15635,a[2]=t8,a[3]=t2,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_15635(t10,t1,t2,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_u_i_caar(t3);
t7=(C_word)C_u_i_cdar(t3);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15813,a[2]=t6,a[3]=t7,a[4]=t9,a[5]=t4,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_15813(t11,t1,t2,C_SCHEME_END_OF_LIST);}}

/* lp in nfa-join-transitions! in k4888 */
static void C_fcall f_15813(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15813,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
t5=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t6=(C_word)C_a_i_list(&a,2,t4,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[6]));}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_15841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[7],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_charp(t5))){
t6=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t6))){
t7=(C_word)C_u_i_caar(t2);
t8=t4;
f_15841(t8,(C_word)C_fixnum_less_or_equal_p(t7,((C_word*)t0)[3]));}
else{
t7=t4;
f_15841(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_15841(t6,C_SCHEME_FALSE);}}}

/* k15839 in lp in nfa-join-transitions! in k4888 */
static void C_fcall f_15841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15841,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15846,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15885,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[9]);
t5=(C_word)C_u_i_caar(((C_word*)t0)[10]);
/* split-char-range */
f_16078(t3,t4,t5);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15899,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_caar(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_caaar(((C_word*)t0)[10]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,((C_word*)t0)[3]))){
t6=(C_word)C_u_i_cdaar(((C_word*)t0)[10]);
t7=t4;
f_15998(t7,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t6));}
else{
t6=t4;
f_15998(t6,C_SCHEME_FALSE);}}
else{
t4=t2;
f_15899(t4,C_SCHEME_FALSE);}}}

/* k15996 in k15839 in lp in nfa-join-transitions! in k4888 */
static void C_fcall f_15998(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_15899(t2,t1);}
else{
t2=(C_word)C_u_i_caaar(((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[3],t2))){
t3=(C_word)C_u_i_cdaar(((C_word*)t0)[4]);
t4=((C_word*)t0)[5];
f_15899(t4,(C_word)C_fixnum_less_or_equal_p(t3,((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[5];
f_15899(t3,C_SCHEME_FALSE);}}}

/* k15897 in k15839 in lp in nfa-join-transitions! in k4888 */
static void C_fcall f_15899(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15899,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15904,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15969,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
t5=(C_word)C_u_i_caar(((C_word*)t0)[8]);
/* intersect-char-ranges */
f_16152(t3,t4,t5);}
else{
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* lp2987 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_15813(t5,((C_word*)t0)[4],t2,t4);}}

/* k15967 in k15897 in k15839 in lp in nfa-join-transitions! in k4888 */
static void C_ccall f_15969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a15903 in k15897 in k15839 in lp in nfa-join-transitions! in k4888 */
static void C_ccall f_15904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_15904,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t8=(C_word)C_u_i_car(((C_word*)t0)[5]);
t9=(C_word)C_i_setslot(t8,C_fix(0),t4);
t10=(C_word)C_u_i_car(((C_word*)t0)[5]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_15957,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t7,a[5]=t6,a[6]=t2,a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[4],a[11]=t10,tmp=(C_word)a,a+=12,tmp);
t12=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* insert-sorted */
f_16349(t11,t12,t7);}

/* k15955 in a15903 in k15897 in k15839 in lp in nfa-join-transitions! in k4888 */
static void C_ccall f_15957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15957,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[11],C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15917,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t5=t3;
f_15917(t5,(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[2]));}
else{
t4=t3;
f_15917(t4,((C_word*)t0)[2]);}}

/* k15915 in k15955 in a15903 in k15897 in k15839 in lp in nfa-join-transitions! in k4888 */
static void C_fcall f_15917(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15917,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15920,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=t2;
f_15920(t4,(C_word)C_a_i_cons(&a,2,t3,t1));}
else{
t3=t2;
f_15920(t3,t1);}}

/* k15918 in k15915 in k15955 in a15903 in k15897 in k15839 in lp in nfa-join-transitions! in k4888 */
static void C_fcall f_15920(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15920,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15927,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* join2954 */
f_15607(t2,t1,((C_word*)t0)[2],t3);}

/* k15925 in k15918 in k15915 in k15955 in a15903 in k15897 in k15839 in lp in nfa-join-transitions! in k4888 */
static void C_ccall f_15927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* join2954 */
f_15607(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}

/* k15883 in k15839 in lp in nfa-join-transitions! in k4888 */
static void C_ccall f_15885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a15845 in k15839 in lp in nfa-join-transitions! in k4888 */
static void C_ccall f_15846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_15846,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15873,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t7=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
/* insert-sorted */
f_16349(t5,t6,t7);}

/* k15871 in a15845 in k15839 in lp in nfa-join-transitions! in k4888 */
static void C_ccall f_15873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15873,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[8],C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15857,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* join2954 */
f_15607(t3,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k15855 in k15871 in a15845 in k15839 in lp in nfa-join-transitions! in k4888 */
static void C_ccall f_15857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* join2954 */
f_15607(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}

/* lp in nfa-join-transitions! in k4888 */
static void C_fcall f_15635(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15635,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]));}
else{
t4=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[4],t4))){
t5=(C_word)C_u_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15670,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t8=(C_word)C_u_i_cdar(t2);
/* insert-sorted */
f_16349(t6,t7,t8);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15684,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_u_i_caaar(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t7,((C_word*)t0)[4]))){
t8=(C_word)C_u_i_cdaar(t2);
t9=t5;
f_15684(t9,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[4],t8));}
else{
t8=t5;
f_15684(t8,C_SCHEME_FALSE);}}
else{
t7=t5;
f_15684(t7,C_SCHEME_FALSE);}}}}

/* k15682 in lp in nfa-join-transitions! in k4888 */
static void C_fcall f_15684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15684,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15689,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15751,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* split-char-range */
f_16078(t3,t4,t5);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
/* lp2962 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_15635(t5,((C_word*)t0)[3],t2,t4);}}

/* k15749 in k15682 in lp in nfa-join-transitions! in k4888 */
static void C_ccall f_15751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a15688 in k15682 in lp in nfa-join-transitions! in k4888 */
static void C_ccall f_15689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_15689,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15739,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t6=(C_word)C_u_i_cdar(((C_word*)t0)[4]);
/* insert-sorted */
f_16349(t4,t5,t6);}

/* k15737 in a15688 in k15682 in lp in nfa-join-transitions! in k4888 */
static void C_ccall f_15739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15739,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15701,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15705,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=t4;
f_15705(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t4;
f_15705(t5,C_SCHEME_END_OF_LIST);}}

/* k15703 in k15737 in a15688 in k15682 in lp in nfa-join-transitions! in k4888 */
static void C_fcall f_15705(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15705,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15709,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=t2;
f_15709(t5,(C_word)C_a_i_list(&a,1,t4));}
else{
t3=t2;
f_15709(t3,C_SCHEME_END_OF_LIST);}}

/* k15707 in k15703 in k15737 in a15688 in k15682 in lp in nfa-join-transitions! in k4888 */
static void C_fcall f_15709(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}

/* k15699 in k15737 in a15688 in k15682 in lp in nfa-join-transitions! in k4888 */
static void C_ccall f_15701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15701,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k15668 in lp in nfa-join-transitions! in k4888 */
static void C_ccall f_15670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* join in nfa-join-transitions! in k4888 */
static void C_fcall f_15607(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15607,NULL,4,t1,t2,t3,t4);}
t5=t3;
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,t3,t4);
/* nfa-join-transitions! */
f_15604(t1,t2,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}}

/* nfa->dfa in k4888 */
static void C_fcall f_15307(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15307,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_u_i_car(t3):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15422,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_caar(t2);
t8=(C_word)C_a_i_list(&a,1,t7);
/* nfa-closure */
f_16268(t6,t2,t8);}

/* k15420 in nfa->dfa in k4888 */
static void C_ccall f_15422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15422,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_15320(t6,((C_word*)t0)[2],t2,C_fix(0),C_SCHEME_END_OF_LIST);}

/* lp in k15420 in nfa->dfa in k4888 */
static void C_fcall f_15320(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_15320,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15334,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_assoc(t5,t4))){
t6=(C_word)C_slot(t2,C_fix(1));
/* lp2871 */
t15=t1;
t16=t6;
t17=t3;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15353,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[3],a[8]=t6,tmp=(C_word)a,a+=9,tmp);
t8=((C_word*)t0)[2];
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15515,a[2]=t10,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_15515(t12,t7,C_SCHEME_END_OF_LIST,t6,C_SCHEME_END_OF_LIST);}}}

/* lp in lp in k15420 in nfa->dfa in k4888 */
static void C_fcall f_15515(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_15515,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15533,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t4);}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_i_assv(t5,((C_word*)t0)[3]);
t7=(C_truep(t6)?(C_word)C_slot(t6,C_fix(1)):C_SCHEME_END_OF_LIST);
t8=(C_word)C_slot(t3,C_fix(1));
/* lp2925 */
t17=t1;
t18=t7;
t19=t8;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}
else{
t5=(C_word)C_u_i_caar(t2);
t6=(C_word)C_eqp(lf[83],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t2,C_fix(1));
/* lp2925 */
t17=t1;
t18=t7;
t19=t3;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t7=(C_word)C_slot(t2,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15594,a[2]=t3,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_u_i_car(t2);
/* nfa-join-transitions! */
f_15604(t8,t4,t9);}}}

/* k15592 in lp in lp in k15420 in nfa->dfa in k4888 */
static void C_ccall f_15594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2925 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_15515(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a15532 in lp in lp in k15420 in nfa->dfa in k4888 */
static void C_ccall f_15533(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15533,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15545,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* nfa-closure */
f_16268(t4,((C_word*)t0)[2],t5);}

/* k15543 in a15532 in lp in lp in k15420 in nfa->dfa in k4888 */
static void C_ccall f_15545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15545,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k15351 in lp in k15420 in nfa->dfa in k4888 */
static void C_ccall f_15353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15353,2,t0,t1);}
t2=(C_word)C_i_memv(C_fix(0),((C_word*)t0)[8]);
t3=(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t4=(C_word)C_i_not(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_15365,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=t3,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t4)){
t6=t5;
f_15365(t6,t4);}
else{
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
t7=t5;
f_15365(t7,(C_word)C_i_lessp(t6,((C_word*)t0)[7]));}}

/* k15363 in k15351 in lp in k15420 in nfa->dfa in k4888 */
static void C_fcall f_15365(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15365,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15372,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15400,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[281]+1),((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k15398 in k15363 in k15351 in lp in k15420 in nfa->dfa in k4888 */
static void C_ccall f_15400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k15370 in k15363 in k15351 in lp in k15420 in nfa->dfa in k4888 */
static void C_ccall f_15372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15372,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15396,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t4=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k15394 in k15370 in k15363 in k15351 in lp in k15420 in nfa->dfa in k4888 */
static void C_ccall f_15396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15396,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15388,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t5=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k15386 in k15394 in k15370 in k15363 in k15351 in lp in k15420 in nfa->dfa in k4888 */
static void C_ccall f_15388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15388,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
/* lp2871 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_15320(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k15332 in lp in k15420 in nfa->dfa in k4888 */
static void C_ccall f_15334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15334,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15442,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15499,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[280]+1),t1);}

/* k15497 in k15332 in lp in k15420 in nfa->dfa in k4888 */
static void C_ccall f_15499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15503,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
/* zero-to */
f_5642(t2,t3);}

/* k15501 in k15497 in k15332 in lp in k15420 in nfa->dfa in k4888 */
static void C_ccall f_15503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[279]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[221]+1),((C_word*)t0)[2],t1);}

/* k15440 in k15332 in lp in k15420 in nfa->dfa in k4888 */
static void C_ccall f_15442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15444,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15459,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15461,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a15460 in k15440 in k15332 in lp in k15420 in nfa->dfa in k4888 */
static void C_ccall f_15461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15461,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15473,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15475,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cddr(t2);
/* map */
t7=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}

/* a15474 in a15460 in k15440 in k15332 in lp in k15420 in nfa->dfa in k4888 */
static void C_ccall f_15475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_15475,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_15444(((C_word*)t0)[2],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t3,t5));}

/* k15471 in a15460 in k15440 in k15332 in lp in k15420 in nfa->dfa in k4888 */
static void C_ccall f_15473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15473,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k15457 in k15440 in k15332 in lp in k15420 in nfa->dfa in k4888 */
static void C_ccall f_15459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->vector */
t2=*((C_word*)lf[278]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* renumber in k15440 in k15332 in lp in k15420 in nfa->dfa in k4888 */
static C_word C_fcall f_15444(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_i_assoc(t1,((C_word*)t0)[2]);
return((C_word)C_slot(t2,C_fix(1)));}

/* sre->nfa in k4888 */
static void C_fcall f_14517(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14517,NULL,3,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_i_pairp(t3);
t6=(C_truep(t5)?(C_word)C_u_i_car(t3):C_fix(0));
t7=(C_word)C_a_i_list(&a,1,C_fix(0));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14535,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=((C_word*)t10)[1];
f_14535(t12,t1,t4,C_fix(1),t6,t8);}

/* lp in sre->nfa in k4888 */
static void C_fcall f_14535(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word *a;
loop:
a=C_alloc(21);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_14535,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14538,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14552,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t5);}
else{
t8=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t8))){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14600,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14604,a[2]=t9,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_u_i_car(t2);
/* string->list */
t12=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}
else{
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_eqp(lf[83],t9);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14625,a[2]=t1,a[3]=t7,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_slot(t2,C_fix(1));
/* lp2677 */
t42=t11;
t43=t12;
t44=t3;
t45=t4;
t46=t5;
t1=t42;
t2=t43;
t3=t44;
t4=t45;
t5=t46;
goto loop;}
else{
t11=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_charp(t11))){
t12=(C_word)C_u_i_car(t2);
t13=f_9191(t12);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_14648,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t13,a[7]=t1,a[8]=t7,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14681,a[2]=t14,a[3]=t13,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6144(t15,t4,C_fix(2));}
else{
t12=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t12))){
t13=(C_word)C_u_i_car(t2);
t14=(C_word)C_u_i_assq(t13,lf[204]);
if(C_truep(t14)){
t15=(C_word)C_slot(t14,C_fix(1));
t16=(C_word)C_slot(t2,C_fix(1));
t17=(C_word)C_a_i_cons(&a,2,t15,t16);
/* lp2677 */
t42=t1;
t43=t17;
t44=t3;
t45=t4;
t46=t5;
t1=t42;
t2=t43;
t3=t44;
t4=t45;
t5=t46;
goto loop;}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_pairp(t13))){
t14=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_i_stringp(t14))){
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14758,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t16=(C_word)C_u_i_caar(t2);
/* string->list */
t17=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t15,t16);}
else{
t15=(C_word)C_u_i_caar(t2);
t16=(C_word)C_eqp(t15,lf[82]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t15,lf[185]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14781,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t19=(C_word)C_u_i_cdar(t2);
t20=(C_word)C_slot(t2,C_fix(1));
/* append */
t21=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t18,t19,t20);}
else{
t18=(C_word)C_eqp(t15,lf[183]);
t19=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_14798,a[2]=t7,a[3]=t15,a[4]=t5,a[5]=t3,a[6]=t4,a[7]=t6,a[8]=t1,a[9]=((C_word*)t0)[2],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t18)){
t20=t19;
f_14798(t20,t18);}
else{
t20=(C_word)C_eqp(t15,lf[184]);
if(C_truep(t20)){
t21=t19;
f_14798(t21,t20);}
else{
t21=(C_word)C_eqp(t15,lf[118]);
t22=t19;
f_14798(t22,(C_truep(t21)?t21:(C_word)C_eqp(t15,lf[119])));}}}}}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}}}}}}

/* k14796 in lp in sre->nfa in k4888 */
static void C_fcall f_14798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14798,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14801,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
/* lp2677 */
t4=((C_word*)((C_word*)t0)[9])[1];
f_14535(t4,t2,t3,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[31]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_14852,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[2],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_14852(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[203]);
if(C_truep(t4)){
t5=t3;
f_14852(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[3],lf[192]);
t6=t3;
f_14852(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[3],lf[124])));}}}}

/* k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_fcall f_14852(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14852,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_14855,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14940,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* flag-set? */
f_6144(t4,((C_word*)t0)[5],C_fix(2));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[70]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14949,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* lp2677 */
t5=((C_word*)((C_word*)t0)[7])[1];
f_14535(t5,t3,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[95]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15052,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* lp2677 */
t6=((C_word*)((C_word*)t0)[7])[1];
f_14535(t6,t4,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[2],lf[93]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[2],lf[91]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15112,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* lp2677 */
t8=((C_word*)((C_word*)t0)[7])[1];
f_14535(t8,t6,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[2],lf[76]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[2],lf[85]));
if(C_truep(t7)){
t8=(C_word)C_u_i_cdar(((C_word*)t0)[8]);
t9=f_13479(C_a_i(&a,3),t8);
t10=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
/* lp2677 */
t12=((C_word*)((C_word*)t0)[7])[1];
f_14535(t12,((C_word*)t0)[9],t11,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t8=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}

/* k15110 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_15112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15112,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15118,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15200,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* new-state-number2683 */
t4=((C_word*)t0)[2];
f_14538(t4,t3,t1);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k15198 in k15110 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_15200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2677 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_14535(t2,((C_word*)t0)[4],lf[277],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15116 in k15110 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_15118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15121,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15196,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2683 */
t5=((C_word*)t0)[2];
f_14538(t5,t4,t1);}

/* k15194 in k15116 in k15110 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_15196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2677 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14535(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15119 in k15116 in k15110 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_15121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15121,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15127,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_caar(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[91],t3);
if(C_truep(t4)){
t5=(C_word)C_u_i_car(t1);
t6=(C_word)C_u_i_caar(((C_word*)t0)[4]);
t7=(C_word)C_a_i_cons(&a,2,lf[83],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15176,a[2]=t5,a[3]=t2,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_u_i_cdar(t1);
/* ##sys#append */
t10=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,C_SCHEME_END_OF_LIST);}
else{
t5=t2;
f_15127(t5,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k15174 in k15119 in k15116 in k15110 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_15176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15176,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_15127(t3,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t2));}

/* k15125 in k15119 in k15116 in k15110 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_fcall f_15127(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15127,NULL,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_u_i_caar(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15146,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_cdar(((C_word*)t0)[4]);
/* ##sys#append */
t7=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k15144 in k15125 in k15119 in k15116 in k15110 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_15146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15146,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}

/* k15050 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_15052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15052,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15058,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15096,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2683 */
t5=((C_word*)t0)[2];
f_14538(t5,t4,t1);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k15094 in k15050 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_15096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2677 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14535(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15056 in k15050 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_15058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15058,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_caar(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15080,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_cdar(t1);
/* ##sys#append */
t7=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k15078 in k15056 in k15050 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_15080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15080,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}

/* k14947 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_cddar(((C_word*)t0)[4]);
t4=f_13504(C_a_i(&a,3),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15031,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2683 */
t7=((C_word*)t0)[5];
f_14538(t7,t6,t1);}
else{
t3=t2;
f_14952(2,t3,C_SCHEME_FALSE);}}

/* k15029 in k14947 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_15031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2677 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14535(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14950 in k14947 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14955,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_cadar(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15016,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2683 */
t6=((C_word*)t0)[5];
f_14538(t6,t5,t1);}
else{
t3=t2;
f_14955(2,t3,C_SCHEME_FALSE);}}

/* k15014 in k14950 in k14947 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_15016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2677 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14535(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14953 in k14950 in k14947 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14955,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14981,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* new-state-number2683 */
t3=((C_word*)t0)[2];
f_14538(t3,t2,t1);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14979 in k14953 in k14950 in k14947 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14981,2,t0,t1);}
t2=(C_word)C_u_i_caar(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_u_i_caar(((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[83],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t3,t6);
t8=(C_word)C_a_i_cons(&a,2,t1,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14969,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14973,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* take-up-to */
f_5681(t10,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k14971 in k14979 in k14953 in k14950 in k14947 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14977,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k14975 in k14971 in k14979 in k14953 in k14950 in k14947 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k14967 in k14979 in k14953 in k14950 in k14947 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14969,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k14938 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14940,2,t0,t1);}
/* sre->cset */
f_18830(((C_word*)t0)[3],((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,t1));}

/* k14853 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14855,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(t2,C_fix(1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14871,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* lp2677 */
t6=((C_word*)((C_word*)t0)[6])[1];
f_14535(t6,t4,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14882,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* lp2677 */
t6=((C_word*)((C_word*)t0)[6])[1];
f_14535(t6,t4,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k14880 in k14853 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14882,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14908,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14910,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a14909 in k14880 in k14853 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14910(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14910,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[31],t3,t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k14906 in k14880 in k14853 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14908,2,t0,t1);}
t2=f_13504(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2683 */
t5=((C_word*)t0)[2];
f_14538(t5,t4,((C_word*)t0)[4]);}

/* k14894 in k14906 in k14880 in k14853 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14900,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t3=lf[55];
f_6163(4,t3,t2,((C_word*)t0)[2],C_fix(2));}

/* k14898 in k14894 in k14906 in k14880 in k14853 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2677 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14535(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k14869 in k14853 in k14850 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14871,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* extend-state2684 */
t3=((C_word*)t0)[3];
f_14552(t3,((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,1,t2));}

/* k14799 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14804,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t4=(C_word)C_u_i_memq(t3,lf[275]);
t5=(C_truep(t4)?C_fix(2):C_fix(32));
t6=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t7=(C_word)C_u_i_memq(t6,lf[276]);
t8=(C_truep(t7)?lf[55]:lf[54]);
t9=t8;
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t2,((C_word*)t0)[2],t5);}

/* k14802 in k14799 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14804,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14818,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2683 */
t4=((C_word*)t0)[2];
f_14538(t4,t3,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14816 in k14802 in k14799 in k14796 in lp in sre->nfa in k4888 */
static void C_ccall f_14818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2677 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14535(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14779 in lp in sre->nfa in k4888 */
static void C_ccall f_14781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2677 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14535(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14756 in lp in sre->nfa in k4888 */
static void C_ccall f_14758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14758,2,t0,t1);}
t2=f_13504(C_a_i(&a,3),t1);
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* lp2677 */
t5=((C_word*)((C_word*)t0)[6])[1];
f_14535(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14679 in lp in sre->nfa in k4888 */
static void C_ccall f_14681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_eqvp(t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
f_14648(t4,(C_word)C_i_not(t3));}
else{
t2=((C_word*)t0)[2];
f_14648(t2,C_SCHEME_FALSE);}}

/* k14646 in lp in sre->nfa in k4888 */
static void C_fcall f_14648(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14648,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14655,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
/* lp2677 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_14535(t4,t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14670,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
/* lp2677 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_14535(t4,t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k14668 in k14646 in lp in sre->nfa in k4888 */
static void C_ccall f_14670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14670,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* extend-state2684 */
t3=((C_word*)t0)[3];
f_14552(t3,((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,1,t2));}

/* k14653 in k14646 in lp in sre->nfa in k4888 */
static void C_ccall f_14655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14655,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
/* extend-state2684 */
t3=((C_word*)t0)[4];
f_14552(t3,((C_word*)t0)[3],t1,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}

/* k14623 in lp in sre->nfa in k4888 */
static void C_ccall f_14625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14625,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* extend-state2684 */
t3=((C_word*)t0)[3];
f_14552(t3,((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,1,t2));}

/* k14602 in lp in sre->nfa in k4888 */
static void C_ccall f_14604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k14598 in lp in sre->nfa in k4888 */
static void C_ccall f_14600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2677 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14535(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* extend-state in lp in sre->nfa in k4888 */
static void C_fcall f_14552(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14552,NULL,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14567,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* new-state-number2683 */
t5=((C_word*)t0)[2];
f_14538(t5,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k14565 in extend-state in lp in sre->nfa in k4888 */
static void C_ccall f_14567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14573,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a14572 in k14565 in extend-state in lp in sre->nfa in k4888 */
static void C_ccall f_14573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14573,3,t0,t1,t2);}
t3=(C_word)C_u_i_caar(((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* k14569 in k14565 in extend-state in lp in sre->nfa in k4888 */
static void C_ccall f_14571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14571,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]));}

/* new-state-number in lp in sre->nfa in k4888 */
static void C_fcall f_14538(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14538,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_caar(t2);
t4=(C_word)C_a_i_plus(&a,2,C_fix(1),t3);
/* max */
t5=*((C_word*)lf[210]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}

/* dfa-match/longest in k4888 */
static void C_fcall f_14410(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14410,NULL,5,t1,t2,t3,t4,t5);}
t6=f_14299(t2);
t7=f_14299(t2);
t8=f_14315(t7);
t9=(C_truep(t8)?t4:C_SCHEME_FALSE);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14424,a[2]=t11,a[3]=t2,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_14424(t13,t1,t4,t6,t9);}

/* lp in dfa-match/longest in k4888 */
static void C_fcall f_14424(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14424,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_subchar(((C_word*)t0)[4],t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14437,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14462,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t3,C_fix(1));
/* find */
f_5724(t6,t7,t8);}}

/* a14461 in lp in dfa-match/longest in k4888 */
static void C_ccall f_14462(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14462,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_eqvp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,((C_word*)t0)[2]))){
t7=(C_word)C_u_i_cdar(t2);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t7));}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* k14435 in lp in dfa-match/longest in k4888 */
static void C_ccall f_14437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14437,2,t0,t1);}
if(C_truep(t1)){
t2=f_14305(((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t4=f_14315(t2);
t5=(C_truep(t4)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[4]);
/* lp2639 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_14424(t6,((C_word*)t0)[2],t3,t2,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* dfa-final-state? in k4888 */
static C_word C_fcall f_14315(C_word t1){
C_word tmp;
C_word t2;
return((C_word)C_u_i_car(t1));}

/* dfa-next-state in k4888 */
static C_word C_fcall f_14305(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
t3=(C_word)C_slot(t2,C_fix(1));
return((C_word)C_slot(t1,t3));}

/* dfa-init-state in k4888 */
static C_word C_fcall f_14299(C_word t1){
C_word tmp;
C_word t2;
return((C_word)C_slot(t1,C_fix(0)));}

/* irregex-match in k4888 */
static void C_ccall f_14232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_14232,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14236,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* irregex */
t5=*((C_word*)lf[178]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k14234 in irregex-match in k4888 */
static void C_ccall f_14236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14239,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* irregex-new-matches */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k14237 in k14234 in irregex-match in k4888 */
static void C_ccall f_14239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14239,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
t3=f_5104(t1,((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* irregex-dfa */
t5=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k14249 in k14237 in k14234 in irregex-match in k4888 */
static void C_ccall f_14251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14251,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14276,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* irregex-dfa */
t4=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14279,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* irregex-nfa */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k14277 in k14249 in k14237 in k14234 in irregex-match in k4888 */
static void C_ccall f_14279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14296,tmp=(C_word)a,a+=2,tmp);
/* matcher2571 */
t4=t1;
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4],t3);}

/* a14295 in k14277 in k14249 in k14237 in k14234 in irregex-match in k4888 */
static void C_ccall f_14296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14296,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k14280 in k14277 in k14249 in k14237 in k14234 in irregex-match in k4888 */
static void C_ccall f_14282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14282,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[4]))){
t2=f_5138(C_a_i(&a,8),((C_word*)t0)[3],C_fix(0),C_fix(0));
t3=f_5152(C_a_i(&a,8),((C_word*)t0)[3],C_fix(0),t1);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14274 in k14249 in k14237 in k14234 in irregex-match in k4888 */
static void C_ccall f_14276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* dfa-match/longest */
f_14410(((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k14252 in k14249 in k14237 in k14234 in irregex-match in k4888 */
static void C_ccall f_14254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14254,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[6]))){
t2=f_5138(C_a_i(&a,8),((C_word*)t0)[5],C_fix(0),C_fix(0));
t3=f_5152(C_a_i(&a,8),((C_word*)t0)[5],C_fix(0),t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14269,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14272,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* irregex-dfa/extract */
t6=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14270 in k14252 in k14249 in k14237 in k14234 in irregex-match in k4888 */
static void C_ccall f_14272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],C_fix(0),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14267 in k14252 in k14249 in k14237 in k14234 in irregex-match in k4888 */
static void C_ccall f_14269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* irregex-search/matches in k4888 */
static void C_ccall f_14073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_14073,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14080,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* irregex-dfa */
t8=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14080,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14193,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* irregex-flags */
t4=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14196,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* irregex-nfa */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k14194 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14196,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14201,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_14201(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k14194 in k14078 in irregex-search/matches in k4888 */
static void C_fcall f_14201(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14201,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,((C_word*)t0)[6]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14211,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14229,tmp=(C_word)a,a+=2,tmp);
/* matcher2515 */
t5=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t3,((C_word*)t0)[2],t2,((C_word*)t0)[5],t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a14228 in lp in k14194 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14229,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k14209 in lp in k14194 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14211,2,t0,t1);}
if(C_truep(t1)){
t2=f_5138(C_a_i(&a,8),((C_word*)t0)[5],C_fix(0),((C_word*)t0)[4]);
t3=f_5152(C_a_i(&a,8),((C_word*)t0)[5],C_fix(0),t1);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
/* lp2517 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_14201(t3,((C_word*)t0)[3],t2);}}

/* k14191 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* flag-set? */
f_6144(((C_word*)t0)[2],t1,C_fix(1));}

/* k14084 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14086,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14089,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* irregex-dfa */
t4=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14111,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14189,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* irregex-dfa/search */
t4=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}}

/* k14187 in k14084 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14189,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=f_14299(t1);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14331,a[2]=t7,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_14331(t9,((C_word*)t0)[2],t3,t5);}

/* lp in k14187 in k14084 in k14078 in irregex-search/matches in k4888 */
static void C_fcall f_14331(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14331,NULL,4,t0,t1,t2,t3);}
t4=f_14315(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[5]))){
t5=(C_word)C_subchar(((C_word*)t0)[4],t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14350,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14366,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t3,C_fix(1));
/* find */
f_5724(t6,t7,t8);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}

/* a14365 in lp in k14187 in k14084 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14366(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14366,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_eqvp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,((C_word*)t0)[2]))){
t7=(C_word)C_u_i_cdar(t2);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t7));}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* k14348 in lp in k14187 in k14084 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14350,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t3=f_14305(((C_word*)t0)[4],t1);
/* lp2604 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_14331(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14109 in k14084 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14111,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* irregex-lengths */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14183 in k14109 in k14084 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14185,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_slot(t2,C_fix(1)))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[8],t4);
/* max */
t6=*((C_word*)lf[210]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,((C_word*)t0)[2],t5);}
else{
t4=t3;
f_14120(2,t4,((C_word*)t0)[2]);}}

/* k14118 in k14183 in k14109 in k14084 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14120,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[8]);
t3=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14126,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* irregex-dfa */
t5=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}

/* k14124 in k14118 in k14183 in k14109 in k14084 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14126,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14131,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_14131(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k14124 in k14118 in k14183 in k14109 in k14084 in k14078 in irregex-search/matches in k4888 */
static void C_fcall f_14131(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14131,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,((C_word*)t0)[8]))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14141,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* dfa-match/longest */
f_14410(t3,((C_word*)t0)[3],((C_word*)t0)[6],t2,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k14139 in lp in k14124 in k14118 in k14183 in k14109 in k14084 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14141,2,t0,t1);}
if(C_truep(t1)){
t2=f_5138(C_a_i(&a,8),((C_word*)t0)[7],C_fix(0),((C_word*)t0)[6]);
t3=f_5152(C_a_i(&a,8),((C_word*)t0)[7],C_fix(0),t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14153,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14156,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* irregex-dfa/extract */
t6=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* lp2495 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_14131(t3,((C_word*)t0)[5],t2);}}

/* k14154 in k14139 in lp in k14124 in k14118 in k14183 in k14109 in k14084 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14151 in k14139 in lp in k14124 in k14118 in k14183 in k14109 in k14084 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k14106 in k14084 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* dfa-match/longest */
f_14410(((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14087 in k14084 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14089,2,t0,t1);}
if(C_truep(t1)){
t2=f_5138(C_a_i(&a,8),((C_word*)t0)[6],C_fix(0),((C_word*)t0)[5]);
t3=f_5152(C_a_i(&a,8),((C_word*)t0)[6],C_fix(0),t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14101,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14104,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* irregex-dfa/extract */
t6=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14102 in k14087 in k14084 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14099 in k14087 in k14084 in k14078 in irregex-search/matches in k4888 */
static void C_ccall f_14101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* irregex-search in k4888 */
static void C_ccall f_14027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_14027r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_14027r(t0,t1,t2,t3,t4);}}

static void C_ccall f_14027r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14031,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* irregex */
t6=*((C_word*)lf[178]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k14029 in irregex-search in k4888 */
static void C_ccall f_14031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14031,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_u_i_car(((C_word*)t0)[4]):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14049,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=t4;
f_14049(t6,(C_word)C_i_pairp(t5));}
else{
t5=t4;
f_14049(t5,C_SCHEME_FALSE);}}

/* k14047 in k14029 in irregex-search in k4888 */
static void C_fcall f_14049(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14049,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_cadr(((C_word*)t0)[6]):(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5])));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14040,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* irregex-new-matches */
t4=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k14038 in k14047 in k14029 in irregex-search in k4888 */
static void C_ccall f_14040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_5104(t1,((C_word*)t0)[6]);
/* irregex-search/matches */
t3=*((C_word*)lf[241]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* sre-remove-initial-bos in k4888 */
static void C_ccall f_13910(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13910,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[82]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13929,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_13929(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[185]);
if(C_truep(t6)){
t7=t5;
f_13929(t7,t6);}
else{
t7=(C_word)C_eqp(t3,lf[76]);
if(C_truep(t7)){
t8=t5;
f_13929(t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[91]);
t9=t5;
f_13929(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[93])));}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k13927 in sre-remove-initial-bos in k4888 */
static void C_fcall f_13929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13929,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t4=(C_word)C_eqp(lf[150],t3);
if(C_truep(t4)){
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
t6=(C_word)C_u_i_cddr(((C_word*)t0)[4]);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t5,t6));}
else{
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13967,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* sre-remove-initial-bos */
t8=lf[230];
f_13910(3,t8,t6,t7);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[70]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14000,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[230],t4);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}}}

/* k13998 in k13927 in sre-remove-initial-bos in k4888 */
static void C_ccall f_14000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14000,2,t0,t1);}
/* sre-alternate */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_13504(C_a_i(&a,3),t1));}

/* k13965 in k13927 in sre-remove-initial-bos in k4888 */
static void C_ccall f_13967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13967,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* sre-sequence-names in k4888 */
static void C_fcall f_13874(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13874,NULL,4,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13904,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_u_i_car(t2);
/* sre-count-submatches */
f_12384(t6,t7);}}

/* k13902 in sre-sequence-names in k4888 */
static void C_ccall f_13904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13904,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13896,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* sre-names */
f_13644(t3,t4,((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k13894 in k13902 in sre-sequence-names in k4888 */
static void C_ccall f_13896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre-sequence-names */
f_13874(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* sre-names in k4888 */
static void C_fcall f_13644(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_13644,NULL,4,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_eqp(t5,lf[76]);
if(C_truep(t6)){
t7=(C_word)C_slot(t2,C_fix(1));
t8=f_13479(C_a_i(&a,3),t7);
t9=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* sre-names */
t38=t1;
t39=t8;
t40=t9;
t41=t4;
t1=t38;
t2=t39;
t3=t40;
t4=t41;
goto loop;}
else{
t7=(C_word)C_eqp(t5,lf[85]);
if(C_truep(t7)){
t8=(C_word)C_u_i_cddr(t2);
t9=f_13479(C_a_i(&a,3),t8);
t10=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t11=(C_word)C_u_i_cadr(t2);
t12=(C_word)C_a_i_cons(&a,2,t11,t3);
t13=(C_word)C_a_i_cons(&a,2,t12,t4);
/* sre-names */
t38=t1;
t39=t9;
t40=t10;
t41=t13;
t1=t38;
t2=t39;
t3=t40;
t4=t41;
goto loop;}
else{
t8=(C_word)C_eqp(t5,lf[201]);
if(C_truep(t8)){
t9=(C_word)C_u_i_cdddr(t2);
t10=f_13479(C_a_i(&a,3),t9);
t11=(C_word)C_u_i_cadr(t2);
t12=(C_word)C_a_i_plus(&a,2,t3,t11);
/* sre-names */
t38=t1;
t39=t10;
t40=t12;
t41=t4;
t1=t38;
t2=t39;
t3=t40;
t4=t41;
goto loop;}
else{
t9=(C_word)C_eqp(t5,lf[82]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13742,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_13742(t11,t9);}
else{
t11=(C_word)C_eqp(t5,lf[185]);
if(C_truep(t11)){
t12=t10;
f_13742(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[70]);
if(C_truep(t12)){
t13=t10;
f_13742(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[91]);
if(C_truep(t13)){
t14=t10;
f_13742(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[93]);
if(C_truep(t14)){
t15=t10;
f_13742(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[95]);
if(C_truep(t15)){
t16=t10;
f_13742(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[92]);
if(C_truep(t16)){
t17=t10;
f_13742(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[96]);
if(C_truep(t17)){
t18=t10;
f_13742(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[183]);
if(C_truep(t18)){
t19=t10;
f_13742(t19,t18);}
else{
t19=(C_word)C_eqp(t5,lf[184]);
if(C_truep(t19)){
t20=t10;
f_13742(t20,t19);}
else{
t20=(C_word)C_eqp(t5,lf[196]);
if(C_truep(t20)){
t21=t10;
f_13742(t21,t20);}
else{
t21=(C_word)C_eqp(t5,lf[78]);
if(C_truep(t21)){
t22=t10;
f_13742(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[80]);
if(C_truep(t22)){
t23=t10;
f_13742(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[79]);
t24=t10;
f_13742(t24,(C_truep(t23)?t23:(C_word)C_eqp(t5,lf[81])));}}}}}}}}}}}}}}}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k13740 in sre-names in k4888 */
static void C_fcall f_13742(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* sre-sequence-names */
f_13874(((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[98]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[2],lf[99]));
if(C_truep(t3)){
t4=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
/* sre-sequence-names */
f_13874(((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[2],lf[97]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[2],lf[94]));
if(C_truep(t5)){
t6=(C_word)C_u_i_cdddr(((C_word*)t0)[6]);
/* sre-sequence-names */
f_13874(((C_word*)t0)[5],t6,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[3]);}}}}

/* sre-strip-submatches in k4888 */
static void C_ccall f_13529(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_13529,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[76]);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(1));
t6=f_13479(C_a_i(&a,3),t5);
/* sre-strip-submatches */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
c=3;
goto loop;}
else{
t5=(C_word)C_eqp(t3,lf[201]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cdddr(t2);
t7=f_13479(C_a_i(&a,3),t6);
/* sre-strip-submatches */
t11=t1;
t12=t7;
t1=t11;
t2=t12;
c=3;
goto loop;}
else{
/* map */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[188],t2);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* sre-alternate in k4888 */
static C_word C_fcall f_13504(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
if(C_truep((C_word)C_i_nullp(t1))){
return(lf[83]);}
else{
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_i_nullp(t2);
return((C_truep(t3)?(C_word)C_u_i_car(t1):(C_word)C_a_i_cons(&a,2,lf[70],t1)));}}

/* sre-sequence in k4888 */
static C_word C_fcall f_13479(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
if(C_truep((C_word)C_i_nullp(t1))){
return(lf[83]);}
else{
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_i_nullp(t2);
return((C_truep(t3)?(C_word)C_u_i_car(t1):(C_word)C_a_i_cons(&a,2,lf[82],t1)));}}

/* sre-count-submatches in k4888 */
static void C_fcall f_12384(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12384,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12390,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_12390(4,t6,t1,t2,C_fix(0));}

/* count in sre-count-submatches in k4888 */
static void C_ccall f_12390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12390,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12415,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(t4,lf[76]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[85]));
if(C_truep(t7)){
t8=t5;
f_12415(t8,C_fix(1));}
else{
t8=(C_word)C_eqp(t4,lf[201]);
if(C_truep(t8)){
t9=(C_word)C_u_i_cadr(t2);
t10=(C_word)C_u_i_caddr(t2);
t11=t5;
f_12415(t11,(C_word)C_a_i_plus(&a,2,t9,t10));}
else{
t9=t5;
f_12415(t9,C_fix(0));}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12413 in count in sre-count-submatches in k4888 */
static void C_fcall f_12415(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12415,NULL,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* fold */
f_5908(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2,t3);}

/* sre-has-submatchs? in k4888 */
static void C_ccall f_12358(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12358,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(lf[76],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_slot(t2,C_fix(1));
/* any */
f_5810(t1,lf[227],t5);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* sre-consumer? in k4888 */
static void C_ccall f_12272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12272,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[91]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[93]));
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(1));
t7=f_13479(C_a_i(&a,3),t6);
/* sre-any? */
t8=lf[237];
f_12054(3,t8,t1,t7);}
else{
t6=(C_word)C_eqp(t3,lf[82]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12311,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_12311(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[185]);
t9=t7;
f_12311(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[76])));}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(lf[151],t2));}}

/* k12309 in sre-consumer? in k4888 */
static void C_fcall f_12311(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12311,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12324,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* last */
f_5768(t3,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[70]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* every */
f_5859(((C_word*)t0)[3],lf[209],t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k12322 in k12309 in sre-consumer? in k4888 */
static void C_ccall f_12324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre-consumer? */
t2=lf[209];
f_12272(3,t2,((C_word*)t0)[2],t1);}

/* sre-searcher? in k4888 */
static void C_ccall f_12186(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12186,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[91]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[93]));
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(1));
t7=f_13479(C_a_i(&a,3),t6);
/* sre-any? */
t8=lf[237];
f_12054(3,t8,t1,t7);}
else{
t6=(C_word)C_eqp(t3,lf[82]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12225,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_12225(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[185]);
t9=t7;
f_12225(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[76])));}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(lf[150],t2));}}

/* k12223 in sre-searcher? in k4888 */
static void C_fcall f_12225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* sre-searcher? */
t4=lf[231];
f_12186(3,t4,((C_word*)t0)[3],t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[70]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* every */
f_5859(((C_word*)t0)[3],lf[231],t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* sre-repeater? in k4888 */
static C_word C_fcall f_12130(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_memq(t2,lf[238]);
if(C_truep(t3)){
return(t3);}
else{
t4=(C_word)C_u_i_car(t1);
if(C_truep((C_truep((C_word)C_eqp(t4,lf[76]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[82]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[185]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t5=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_cddr(t1);
if(C_truep((C_word)C_i_nullp(t6))){
t7=(C_word)C_u_i_cadr(t1);
t9=t7;
t1=t9;
goto loop;}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}}
else{
return(C_SCHEME_FALSE);}}

/* sre-any? in k4888 */
static void C_ccall f_12054(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12054,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,lf[88]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_eqp(t4,lf[82]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12079,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_12079(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[185]);
t8=t6;
f_12079(t8,(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[76])));}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k12077 in sre-any? in k4888 */
static void C_fcall f_12079(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* sre-any? */
t5=lf[237];
f_12054(3,t5,((C_word*)t0)[3],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[70]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* every */
f_5859(((C_word*)t0)[3],lf[237],t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* sre-empty? in k4888 */
static void C_ccall f_11926(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11926,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[91]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11945,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_11945(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[95]);
if(C_truep(t6)){
t7=t5;
f_11945(t7,t6);}
else{
t7=(C_word)C_eqp(t3,lf[78]);
if(C_truep(t7)){
t8=t5;
f_11945(t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[80]);
if(C_truep(t8)){
t9=t5;
f_11945(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[79]);
t10=t5;
f_11945(t10,(C_truep(t9)?t9:(C_word)C_eqp(t3,lf[81])));}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_memq(t2,lf[236]));}}

/* k11943 in sre-empty? in k4888 */
static void C_fcall f_11945(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11945,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[97]);
if(C_truep(t2)){
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t4=(C_word)C_i_numberp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_zerop(t6));}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[70]);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* any */
f_5810(((C_word*)t0)[4],lf[103],t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[185]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11994,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_11994(t6,t4);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[3],lf[82]);
if(C_truep(t6)){
t7=t5;
f_11994(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],lf[76]);
if(C_truep(t7)){
t8=t5;
f_11994(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[3],lf[93]);
t9=t5;
f_11994(t9,(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[3],lf[196])));}}}}}}}

/* k11992 in k11943 in sre-empty? in k4888 */
static void C_fcall f_11994(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* every */
f_5859(((C_word*)t0)[2],lf[103],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* sre->irregex in k4888 */
static void C_ccall f_11785(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_11785r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_11785r(t0,t1,t2,t3);}}

static void C_ccall f_11785r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11789,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* symbol-list->flags */
f_6182(t4,t3);}

/* k11787 in sre->irregex in k4888 */
static void C_ccall f_11789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11792,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=t1;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11472,a[2]=t4,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6144(t5,t4,C_fix(32));}

/* k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11476,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6144(t2,((C_word*)t0)[2],C_fix(2));}

/* k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11476,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11478,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_11478(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_fcall f_11478(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11478,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11481,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[118]);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
t9=f_13479(C_a_i(&a,3),t8);
/* adjust1526 */
t32=t1;
t33=t9;
t34=C_SCHEME_TRUE;
t35=t4;
t1=t32;
t2=t33;
t3=t34;
t4=t35;
goto loop;}
else{
t8=(C_word)C_eqp(t6,lf[119]);
if(C_truep(t8)){
t9=(C_word)C_slot(t2,C_fix(1));
t10=f_13479(C_a_i(&a,3),t9);
/* adjust1526 */
t32=t1;
t33=t10;
t34=C_SCHEME_FALSE;
t35=t4;
t1=t32;
t2=t33;
t3=t34;
t4=t35;
goto loop;}
else{
t9=(C_word)C_eqp(t6,lf[183]);
if(C_truep(t9)){
t10=(C_word)C_u_i_car(t2);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11545,a[2]=t10,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11547,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_slot(t2,C_fix(1));
/* map */
t14=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t11,t12,t13);}
else{
t10=(C_word)C_eqp(t6,lf[184]);
if(C_truep(t10)){
t11=(C_word)C_u_i_car(t2);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11572,a[2]=t11,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11574,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_slot(t2,C_fix(1));
/* map */
t15=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t13,t14);}
else{
t11=(C_word)C_eqp(t6,lf[31]);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11591,a[2]=t5,a[3]=t6,a[4]=t2,a[5]=t1,a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t11)){
t13=t12;
f_11591(t13,t11);}
else{
t13=(C_word)C_eqp(t6,lf[124]);
if(C_truep(t13)){
t14=t12;
f_11591(t14,t13);}
else{
t14=(C_word)C_eqp(t6,lf[192]);
t15=t12;
f_11591(t15,(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[203])));}}}}}}}
else{
t6=t2;
t7=(C_word)C_eqp(t6,lf[88]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[234]);}
else{
t8=(C_word)C_eqp(t6,lf[89]);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[235]);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11732,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
if(C_truep((C_word)C_charp(t2))){
/* high-char? */
t10=lf[128];
f_10025(3,t10,t9,t2);}
else{
t10=t9;
f_11732(2,t10,C_SCHEME_FALSE);}}
else{
t10=t9;
f_11732(2,t10,C_SCHEME_FALSE);}}}}}

/* k11730 in adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11732,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11739,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11743,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* char->utf8-list */
f_10330(t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k11741 in k11730 in adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[173]+1),t1);}

/* k11737 in k11730 in adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11739,2,t0,t1);}
/* sre-sequence */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_13479(C_a_i(&a,3),t1));}

/* k11589 in adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_fcall f_11591(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11591,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11600,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* sre->cset */
f_18830(t3,((C_word*)t0)[4],(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]));}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[91]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=f_13479(C_a_i(&a,3),t3);
t5=(C_word)C_eqp(t4,lf[88]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[232]);}
else{
t6=(C_word)C_eqp(t4,lf[89]);
if(C_truep(t6)){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[233]);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11676,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* map */
t9=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}}}
else{
t3=(C_word)C_u_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11695,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* map */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}}

/* k11693 in k11589 in adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11695,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11674 in k11589 in adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11676,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[91],t1));}

/* k11598 in k11589 in adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11606,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11621,tmp=(C_word)a,a+=2,tmp);
/* any */
f_5810(t2,t3,t1);}

/* a11620 in k11598 in k11589 in adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11621(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11621,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11631,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(t2);
/* high-char? */
t5=lf[128];
f_10025(3,t5,t3,t4);}
else{
/* high-char? */
t3=lf[128];
f_10025(3,t3,t1,t2);}}

/* k11629 in a11620 in k11598 in k11589 in adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* high-char? */
t3=lf[128];
f_10025(3,t3,((C_word*)t0)[3],t2);}}

/* k11604 in k11598 in k11589 in adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11606,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11616,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* cset->utf8-pattern */
f_11304(t2,((C_word*)t0)[3]);}
else{
/* cset->utf8-pattern */
f_11304(((C_word*)t0)[4],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k11614 in k11604 in k11598 in k11589 in adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11616,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[183],t1));}

/* a11573 in adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11574(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11574,3,t0,t1,t2);}
/* adjust1526 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11478(t3,t1,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k11570 in adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11572,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a11546 in adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11547,3,t0,t1,t2);}
/* adjust1526 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11478(t3,t1,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k11543 in adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11545,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* rec in adjust in k11474 in k11470 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11481,3,t0,t1,t2);}
/* adjust1526 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_11478(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* sre-searcher? */
t3=lf[231];
f_12186(3,t3,t2,t1);}

/* k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11798,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
/* sre-remove-initial-bos */
t3=lf[230];
f_13910(3,t3,t2,((C_word*)t0)[4]);}
else{
t3=t2;
f_11798(2,t3,((C_word*)t0)[4]);}}

/* k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11801,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_u_i_memq(lf[228],((C_word*)t0)[2]))){
t3=t2;
f_11801(t3,C_fix(1));}
else{
t3=(C_word)C_u_i_memq(lf[229],((C_word*)t0)[2]);
t4=t2;
f_11801(t4,(C_truep(t3)?C_fix(50):C_fix(10)));}}

/* k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_11801(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11801,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11804,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_11804(2,t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11875,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[88],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[91],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[82],t7);
/* sre->nfa */
f_14517(t3,t8,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}}

/* k11873 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11875,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(t1);
t3=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],t2);
/* nfa->dfa */
f_15307(((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,1,t3));}
else{
t2=((C_word*)t0)[2];
f_11804(2,t2,C_SCHEME_FALSE);}}

/* k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
/* sre->nfa */
f_14517(t2,((C_word*)t0)[7],(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t3=t2;
f_11807(2,t3,C_SCHEME_FALSE);}}

/* k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[2],t3);
/* nfa->dfa */
f_15307(t2,t1,(C_word)C_a_i_list(&a,1,t4));}
else{
t3=t2;
f_11810(2,t3,C_SCHEME_FALSE);}}

/* k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
t3=((C_word*)t0)[7];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16405,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_16405(t7,t2,t3,C_fix(1),C_SCHEME_FALSE);}
else{
t3=t2;
f_11813(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_11813(2,t3,C_SCHEME_FALSE);}}

/* lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_16405(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16405,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16729,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* sre-has-submatchs? */
t6=lf[227];
f_12358(3,t6,t5,t2);}

/* k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16729,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(t2,lf[185]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,lf[82]));
if(C_truep(t4)){
t5=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
t6=f_13479(C_a_i(&a,3),t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16456,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* lp3099 */
t9=((C_word*)((C_word*)t0)[3])[1];
f_16405(t9,t7,t8,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t5=(C_word)C_eqp(t2,lf[70]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
t7=f_13504(C_a_i(&a,3),t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16549,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* lp3099 */
t10=((C_word*)((C_word*)t0)[3])[1];
f_16405(t10,t8,t9,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t6=(C_word)C_eqp(t2,lf[91]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[93]));
if(C_truep(t7)){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16599,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t11,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t14=f_13479(C_a_i(&a,3),t13);
/* lp3099 */
t15=((C_word*)((C_word*)t0)[3])[1];
f_16405(t15,t12,t14,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t8=(C_word)C_eqp(t2,lf[95]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16655,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t11=f_13479(C_a_i(&a,3),t10);
/* lp3099 */
t12=((C_word*)((C_word*)t0)[3])[1];
f_16405(t12,t9,t11,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t9=(C_word)C_eqp(t2,lf[76]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16680,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t12=f_13479(C_a_i(&a,3),t11);
t13=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
/* lp3099 */
t14=((C_word*)((C_word*)t0)[3])[1];
f_16405(t14,t10,t12,t13,C_SCHEME_TRUE);}
else{
t10=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* error */
t11=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,((C_word*)t0)[5],lf[222],t10);}}}}}}
else{
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[223],((C_word*)t0)[6]);}}
else{
t2=((C_word*)t0)[2];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16423,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16432,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* sre->nfa */
f_14517(t4,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16419,tmp=(C_word)a,a+=2,tmp));}}}

/* f_16419 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16419,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t4);}

/* k16430 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* nfa->dfa */
f_15307(((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k16421 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16423,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16424,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_16424 in k16421 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16424,6,t0,t1,t2,t3,t4,t5);}
/* dfa-match/longest */
f_14410(t1,((C_word*)t0)[2],t2,t3,t4);}

/* k16678 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16680,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16681,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_16681 in k16678 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16681,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16685,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* match-one3235 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k16683 */
static void C_ccall f_16685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16688,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t1))){
t3=f_5138(C_a_i(&a,8),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
/* irregex-match-end-index-set! */
t4=t2;
f_16688(t4,f_5152(C_a_i(&a,8),((C_word*)t0)[4],((C_word*)t0)[3],t1));}
else{
t3=t2;
f_16688(t3,C_SCHEME_UNDEFINED);}}

/* k16686 in k16683 */
static void C_fcall f_16688(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k16653 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16655,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16656,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_16656 in k16653 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16656,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16660,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* match-once3220 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k16658 */
static void C_ccall f_16660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k16597 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16599,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16601,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t4=(C_word)C_u_i_car(((C_word*)t0)[3]);
t5=(C_word)C_eqp(lf[91],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?((C_word*)((C_word*)t0)[4])[1]:(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16624,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp)));}

/* f_16624 in k16597 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16624,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16628,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* match-once3196 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k16626 */
static void C_ccall f_16628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* match-all3197 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_16601 in k16597 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16601,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16605,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* match-once3196 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k16603 */
static void C_ccall f_16605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_lessp(((C_word*)t0)[7],t1):C_SCHEME_FALSE);
if(C_truep(t2)){
/* match-all3197 */
t3=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[7]);}}

/* k16547 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16552,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16574,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* sre-count-submatches */
f_12384(t3,t4);}

/* k16572 in k16547 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16574,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],t1);
/* lp3099 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_16405(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k16550 in k16547 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16552,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16553,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_16553 in k16550 in k16547 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16553,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16557,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* match-first3178 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k16555 */
static void C_ccall f_16557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_eqvp(t1,((C_word*)t0)[7]))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* match-rest3180 */
t2=((C_word*)t0)[5];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2]);}}

/* k16454 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16459,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16525,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* sre-count-submatches */
f_12384(t3,t4);}

/* k16523 in k16454 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16525,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],t1);
/* lp3099 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_16405(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k16457 in k16454 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16459,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16460,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_16460 in k16457 in k16454 in k16727 in lp in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16460,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_16466,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t4,a[8]=t3,tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_16466(t9,t1,t4,C_SCHEME_FALSE);}

/* lp */
static void C_fcall f_16466(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16466,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[8]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_16476,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* match-left3140 */
t5=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[4],((C_word*)t0)[8],t2,((C_word*)t0)[3]);}}

/* k16474 in lp */
static void C_ccall f_16476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16479,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
if(C_truep((C_word)C_i_eqvp(t1,((C_word*)t0)[7]))){
/* match-right3142 */
t3=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[9],((C_word*)t0)[2]);}
else{
t3=t2;
f_16479(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_16479(2,t3,C_SCHEME_FALSE);}}

/* k16477 in k16474 in lp */
static void C_ccall f_16479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16479,2,t0,t1);}
if(C_truep((C_word)C_i_eqvp(t1,((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_i_not(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:(C_truep(t1)?(C_word)C_i_greaterp(t1,((C_word*)t0)[3]):C_SCHEME_FALSE));
t5=(C_truep(t4)?t1:((C_word*)t0)[3]);
/* lp3150 */
t6=((C_word*)((C_word*)t0)[2])[1];
f_16466(t6,((C_word*)t0)[5],t2,t5);}}

/* k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* sre-count-submatches */
f_12384(t2,((C_word*)t0)[8]);}

/* k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* sre-names */
f_13644(t2,((C_word*)t0)[9],C_fix(1),C_SCHEME_END_OF_LIST);}

/* k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11819,2,t0,t1);}
t2=((C_word*)t0)[10];
t3=(C_word)C_a_i_list(&a,1,t1);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12447,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=t4;
f_12447(2,t5,(C_word)C_u_i_car(t3));}
else{
/* sre-names */
f_13644(t4,t2,C_fix(1),C_SCHEME_END_OF_LIST);}}

/* k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_12450,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13468,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* sre-count-submatches */
f_12384(t3,((C_word*)t0)[2]);}

/* k13466 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_13468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13468,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,C_fix(1),t1);
/* make-vector */
t3=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12457,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12459,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_12459(t6,t2,((C_word*)t0)[2],C_fix(1),C_fix(0),C_fix(0),*((C_word*)lf[221]+1));}

/* lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_12459(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12459,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12462,a[2]=t6,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t8))){
/* grow1939 */
t9=t7;
f_12462(t9,t1,C_fix(1));}
else{
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_eqp(t9,lf[31]);
t11=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_12504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t6,a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[4],a[10]=t9,a[11]=t1,a[12]=t7,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t10)){
t12=t11;
f_12504(t12,t10);}
else{
t12=(C_word)C_eqp(t9,lf[124]);
if(C_truep(t12)){
t13=t11;
f_12504(t13,t12);}
else{
t13=(C_word)C_eqp(t9,lf[192]);
t14=t11;
f_12504(t14,(C_truep(t13)?t13:(C_word)C_eqp(t9,lf[203])));}}}}
else{
if(C_truep((C_word)C_charp(t2))){
/* grow1939 */
t8=t7;
f_12462(t8,t1,C_fix(1));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t8=(C_word)C_fix((C_word)C_header_size(t2));
/* grow1939 */
t9=t7;
f_12462(t9,t1,t8);}
else{
t8=t2;
if(C_truep((C_truep((C_word)C_eqp(t8,lf[88]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t8,lf[89]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* grow1939 */
t9=t7;
f_12462(t9,t1,C_fix(1));}
else{
t9=t2;
if(C_truep((C_truep((C_word)C_eqp(t9,lf[83]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[150]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[151]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[159]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[160]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[148]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[147]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[149]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[219]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))))))){
/* return1931 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,t4,t5);}
else{
t10=(C_word)C_u_i_assq(t2,lf[204]);
if(C_truep(t10)){
t11=(C_word)C_slot(t10,C_fix(1));
/* lp1925 */
t20=t1;
t21=t11;
t22=t3;
t23=t4;
t24=t5;
t25=t6;
t1=t20;
t2=t21;
t3=t22;
t4=t23;
t5=t24;
t6=t25;
goto loop;}
else{
/* error */
t11=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[220],t2);}}}}}}}

/* k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_12504(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12504,NULL,2,t0,t1);}
if(C_truep(t1)){
/* grow1939 */
t2=((C_word*)t0)[12];
f_12462(t2,((C_word*)t0)[11],C_fix(1));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[193]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12520,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* string->sre */
t5=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[82]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[4],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_12533(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[10],lf[185]);
if(C_truep(t5)){
t6=t4;
f_12533(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[10],lf[183]);
if(C_truep(t6)){
t7=t4;
f_12533(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[10],lf[184]);
t8=t4;
f_12533(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[10],lf[196])));}}}}}}

/* k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_12533(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12533,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12542,a[2]=((C_word*)t0)[7],a[3]=t4,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_12542(t6,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_fix(0),C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[70]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12624,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_12624(t7,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE,C_fix(0));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[77]);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12709,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_12709(t7,t5);}
else{
t7=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t8=t6;
f_12709(t8,(C_word)C_i_nullp(t7));}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[201]);
if(C_truep(t4)){
t5=(C_word)C_u_i_cdddr(((C_word*)t0)[11]);
t6=f_13479(C_a_i(&a,3),t5);
t7=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
t8=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],t7);
/* lp1925 */
t9=((C_word*)((C_word*)t0)[7])[1];
f_12459(t9,((C_word*)t0)[6],t6,t8,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[76]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[85]));
if(C_truep(t6)){
t7=(C_word)C_u_i_car(((C_word*)t0)[11]);
t8=(C_word)C_eqp(lf[76],t7);
t9=(C_truep(t8)?(C_word)C_slot(((C_word*)t0)[11],C_fix(1)):(C_word)C_u_i_cddr(((C_word*)t0)[11]));
t10=f_13479(C_a_i(&a,3),t9);
t11=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12880,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* lp1925 */
t13=((C_word*)((C_word*)t0)[7])[1];
f_12459(t13,((C_word*)t0)[6],t10,t11,((C_word*)t0)[10],((C_word*)t0)[9],t12);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[155]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[154]));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12920,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_numberp(t10))){
t11=t9;
f_12920(2,t11,(C_word)C_u_i_cadr(((C_word*)t0)[11]));}
else{
t11=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
t12=(C_word)C_u_i_assq(t11,((C_word*)t0)[2]);
if(C_truep(t12)){
t13=t9;
f_12920(2,t13,(C_word)C_slot(t12,C_fix(1)));}
else{
t13=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
/* error */
t14=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t9,lf[214],t13);}}}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[91]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[92]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13033,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t13=f_13479(C_a_i(&a,3),t12);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13042,tmp=(C_word)a,a+=2,tmp);
/* lp1925 */
t15=((C_word*)((C_word*)t0)[7])[1];
f_12459(t15,t11,t13,((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[9],t14);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[97]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[94]));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13062,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t14=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_numberp(t14))){
t15=(C_word)C_u_i_caddr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_numberp(t15))){
t16=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
t17=(C_word)C_u_i_caddr(((C_word*)t0)[11]);
t18=t13;
f_13062(t18,(C_word)C_i_greaterp(t16,t17));}
else{
t16=t13;
f_13062(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_13062(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[93]);
if(C_truep(t13)){
t14=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t15=f_13479(C_a_i(&a,3),t14);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13206,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* lp1925 */
t17=((C_word*)((C_word*)t0)[7])[1];
f_12459(t17,((C_word*)t0)[6],t15,((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[9],t16);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[95]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[4],lf[96]));
if(C_truep(t15)){
t16=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t17=f_13479(C_a_i(&a,3),t16);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13236,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* lp1925 */
t19=((C_word*)((C_word*)t0)[7])[1];
f_12459(t19,((C_word*)t0)[6],t17,((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[9],t18);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[98]);
t17=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13263,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t16)){
t18=t17;
f_13263(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[217]);
if(C_truep(t18)){
t19=t17;
f_13263(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[99]);
t20=t17;
f_13263(t20,(C_truep(t19)?t19:(C_word)C_eqp(((C_word*)t0)[4],lf[218])));}}}}}}}}}}}}}

/* k13261 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_13263(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13263,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_u_i_car(((C_word*)t0)[9]);
t4=(C_word)C_u_i_memq(t3,lf[215]);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_u_i_cadr(((C_word*)t0)[9]));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13290,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
/* ##sys#append */
t8=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[78]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13313,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_13313(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[2],lf[79]);
if(C_truep(t4)){
t5=t3;
f_13313(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[80]);
t6=t3;
f_13313(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[2],lf[81])));}}}}

/* k13311 in k13261 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_13313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* return1931 */
t2=((C_word*)t0)[6];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[216],((C_word*)t0)[2]);}}

/* k13288 in k13261 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_13290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13290,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[97],t3);
/* lp1925 */
t5=((C_word*)((C_word*)t0)[7])[1];
f_12459(t5,((C_word*)t0)[6],t4,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a13235 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_13236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13236,4,t0,t1,t2,t3);}
t4=(C_truep(((C_word*)t0)[4])?(C_truep(t3)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t3):C_SCHEME_FALSE):C_SCHEME_FALSE);
/* return1931 */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}

/* a13205 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_13206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13206,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],t2);
/* return1931 */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,C_SCHEME_FALSE);}

/* k13060 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_13062(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13062,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=t2;
f_13065(t3,t1);}
else{
t3=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t4=t2;
f_13065(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_caddr(((C_word*)t0)[4])));}}

/* k13063 in k13060 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_13065(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13065,NULL,2,t0,t1);}
if(C_truep(t1)){
/* return1931 */
t2=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_u_i_caddr(((C_word*)t0)[4]))){
t2=(C_word)C_u_i_cdddr(((C_word*)t0)[4]);
t3=f_13479(C_a_i(&a,3),t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13083,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lp1925 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_12459(t5,((C_word*)t0)[7],t3,((C_word*)t0)[2],C_fix(0),C_fix(0),t4);}
else{
t2=(C_word)C_u_i_cdddr(((C_word*)t0)[4]);
t3=f_13479(C_a_i(&a,3),t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13130,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lp1925 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_12459(t5,((C_word*)t0)[7],t3,((C_word*)t0)[2],C_fix(0),C_fix(0),t4);}}}

/* a13129 in k13063 in k13060 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_13130(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13130,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_times(&a,2,t4,t2);
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],t5);
/* return1931 */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,C_SCHEME_FALSE);}

/* a13082 in k13063 in k13060 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_13083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13083,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_times(&a,2,t4,t2);
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13095,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t3)){
t8=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t9=(C_word)C_a_i_times(&a,2,t8,t3);
t10=t7;
f_13095(t10,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t9));}
else{
t8=t7;
f_13095(t8,C_SCHEME_FALSE);}}
else{
t8=t7;
f_13095(t8,C_SCHEME_FALSE);}}

/* k13093 in a13082 in k13063 in k13060 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_13095(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* return1931 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a13041 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_13042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13042,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* k13031 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_13033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* return1931 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k12918 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12920,2,t0,t1);}
t2=(C_word)C_i_integerp(t1);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_12929(t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12983,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
/* < */
C_lessp(5,0,t5,C_fix(0),t1,t6);}}

/* k12981 in k12918 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_12929(t2,(C_word)C_i_not(t1));}

/* k12927 in k12918 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_12929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12929,NULL,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[8],lf[212],((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_slot(((C_word*)t0)[6],((C_word*)t0)[5]))){
t2=(C_word)C_slot(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t3);
t7=(C_truep(((C_word*)t0)[3])?(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],t5):C_SCHEME_FALSE):C_SCHEME_FALSE);
/* return1931 */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[8],t6,t7);}
else{
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[8],lf[213],((C_word*)t0)[7]);}}}

/* a12879 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12880,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
/* return1931 */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}

/* k12707 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_12709(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12709,NULL,2,t0,t1);}
if(C_truep(t1)){
/* return1931 */
t2=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12715,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* sre-count-submatches */
f_12384(t2,t3);}}

/* k12713 in k12707 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* sre-count-submatches */
f_12384(t2,t3);}

/* k12716 in k12713 in k12707 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12718,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_i_numberp(t2);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t3)){
t5=t4;
f_12800(t5,t3);}
else{
t5=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t6=t4;
f_12800(t6,(C_word)C_i_symbolp(t5));}}

/* k12798 in k12716 in k12713 in k12707 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_12800(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12800,NULL,2,t0,t1);}
t2=(C_truep(t1)?lf[83]:(C_word)C_u_i_cadr(((C_word*)t0)[10]));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12727,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* lp1925 */
t4=((C_word*)((C_word*)t0)[6])[1];
f_12459(t4,((C_word*)t0)[4],t2,((C_word*)t0)[9],((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a12726 in k12798 in k12716 in k12713 in k12707 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12727,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* lp1925 */
t7=((C_word*)((C_word*)t0)[3])[1];
f_12459(t7,t1,t4,t5,C_fix(0),C_fix(0),t6);}

/* a12740 in a12726 in k12798 in k12716 in k12713 in k12707 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12741,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_cdddr(((C_word*)t0)[9]);
t5=(C_word)C_i_pairp(t4);
t6=(C_truep(t5)?(C_word)C_u_i_cadddr(((C_word*)t0)[9]):lf[83]);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12753,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* + */
C_plus(5,0,t7,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12751 in a12740 in a12726 in k12798 in k12716 in k12713 in k12707 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12755,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* lp1925 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_12459(t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_fix(0),C_fix(0),t2);}

/* a12754 in k12751 in a12740 in a12726 in k12798 in k12716 in k12713 in k12707 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12755,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12784,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* min */
t5=*((C_word*)lf[211]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k12782 in a12754 in k12751 in a12740 in a12726 in k12798 in k12716 in k12713 in k12707 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12784,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12767,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(((C_word*)t0)[3])){
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12780,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* max */
t5=*((C_word*)lf[210]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=t3;
f_12767(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_12767(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_12767(t4,C_SCHEME_FALSE);}}

/* k12778 in k12782 in a12754 in k12751 in a12740 in a12726 in k12798 in k12716 in k12713 in k12707 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12780,2,t0,t1);}
t2=((C_word*)t0)[3];
f_12767(t2,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t1));}

/* k12765 in k12782 in a12754 in k12751 in a12740 in a12726 in k12798 in k12716 in k12713 in k12707 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_12767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* return1931 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp2 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_12624(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12624,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],t4);
t7=(C_truep(((C_word*)t0)[5])?(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],t5):C_SCHEME_FALSE):C_SCHEME_FALSE);
/* return1931 */
t8=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t6,t7);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12657,a[2]=t4,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* lp1925 */
t8=((C_word*)((C_word*)t0)[2])[1];
f_12459(t8,t1,t6,t3,C_fix(0),C_fix(0),t7);}}

/* a12656 in lp2 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12657,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12690,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* sre-count-submatches */
f_12384(t5,t6);}

/* k12688 in a12656 in lp2 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12690,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12673,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
/* min */
t4=*((C_word*)lf[211]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=t3;
f_12673(2,t4,((C_word*)t0)[2]);}}

/* k12671 in k12688 in a12656 in lp2 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12677,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(((C_word*)t0)[2])){
/* max */
t3=*((C_word*)lf[210]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
f_12677(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_12677(2,t3,C_SCHEME_FALSE);}}

/* k12675 in k12671 in k12688 in a12656 in lp2 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp22014 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_12624(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp2 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_12542(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12542,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],t4);
t7=(C_truep(((C_word*)t0)[5])?(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],t5):C_SCHEME_FALSE):C_SCHEME_FALSE);
/* return1931 */
t8=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t6,t7);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12575,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* lp1925 */
t8=((C_word*)((C_word*)t0)[2])[1];
f_12459(t8,t1,t6,t3,C_fix(0),C_fix(0),t7);}}

/* a12574 in lp2 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12575,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12605,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* sre-count-submatches */
f_12384(t5,t6);}

/* k12603 in a12574 in lp2 in k12531 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12605,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t4=(C_truep(((C_word*)t0)[6])?(C_truep(((C_word*)t0)[5])?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]):C_SCHEME_FALSE):C_SCHEME_FALSE);
/* lp21994 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_12542(t5,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}

/* k12518 in k12502 in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp1925 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_12459(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* grow in lp in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_12462(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12462,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t2);
t4=(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],t2):C_SCHEME_FALSE);
/* return1931 */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_12457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12457,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[11],C_fix(0),t1);
t3=((C_word*)t0)[11];
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11825,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11841,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_truep(((C_word*)t0)[2])?C_fix(1):C_SCHEME_FALSE);
/* flag-join */
t7=lf[54];
f_6154(4,t7,t5,C_fix(0),t6);}

/* k11839 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11848,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* sre-consumer? */
t3=lf[209];
f_12272(3,t3,t2,((C_word*)t0)[2]);}

/* k11846 in k11839 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?C_fix(2):C_SCHEME_FALSE);
/* flag-join */
t3=lf[54];
f_6154(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11825,2,t0,t1);}
if(C_truep(((C_word*)t0)[10])){
/* make-irregex */
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_4893(C_a_i(&a,10),((C_word*)t0)[10],((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_FALSE,t1,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11834,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16736,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18695,a[2]=t3,a[3]=t4,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t9=(C_word)C_slot(t4,C_fix(1));
t10=t8;
f_18695(t10,(C_word)C_i_pairp(t9));}
else{
t9=t8;
f_18695(t9,C_SCHEME_FALSE);}}}

/* k18693 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_18695(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_16736(2,t2,(C_word)C_u_i_cadr(((C_word*)t0)[3]));}
else{
/* sre-names */
f_13644(((C_word*)t0)[4],((C_word*)t0)[2],C_fix(1),C_SCHEME_END_OF_LIST);}}

/* k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16736,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?(C_word)C_u_i_car(((C_word*)t0)[4]):C_fix(0));
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16745,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16748,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_16748(t9,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1),t4,t5);}

/* lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_16748(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16748,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16751,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16774,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_u_i_car(t2);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16782,a[2]=t9,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* flag-set? */
f_6144(t10,t4,C_fix(2));}
else{
t8=(C_word)C_u_i_car(t2);
t9=(C_word)C_eqp(t8,lf[124]);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_16794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t4,a[8]=t2,a[9]=t5,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t9)){
t11=t10;
f_16794(t11,t9);}
else{
t11=(C_word)C_eqp(t8,lf[203]);
if(C_truep(t11)){
t12=t10;
f_16794(t12,t11);}
else{
t12=(C_word)C_eqp(t8,lf[192]);
t13=t10;
f_16794(t13,(C_truep(t12)?t12:(C_word)C_eqp(t8,lf[31])));}}}}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t7=t2;
t8=(C_word)C_eqp(t7,lf[88]);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18208,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t9=(C_word)C_eqp(t7,lf[89]);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18236,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t10=(C_word)C_eqp(t7,lf[150]);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18278,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t11=(C_word)C_eqp(t7,lf[159]);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18298,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t12=(C_word)C_eqp(t7,lf[148]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18332,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t13=(C_word)C_eqp(t7,lf[151]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18390,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t14=(C_word)C_eqp(t7,lf[160]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18414,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t15=(C_word)C_eqp(t7,lf[147]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18448,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t16=(C_word)C_eqp(t7,lf[149]);
if(C_truep(t16)){
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18506,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t17=(C_word)C_eqp(t7,lf[83]);
if(C_truep(t17)){
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t5);}
else{
t18=(C_word)C_u_i_assq(t2,lf[204]);
if(C_truep(t18)){
t19=(C_word)C_slot(t18,C_fix(1));
/* rec3275 */
t20=t6;
f_16751(t20,t1,t19);}
else{
/* error */
t19=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t1,lf[205],t2);}}}}}}}}}}}}
else{
if(C_truep((C_word)C_charp(t2))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18602,a[2]=t2,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6144(t7,t4,C_fix(2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18683,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t8=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* error */
t7=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,lf[207],t2);}}}}}

/* k18681 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18683,2,t0,t1);}
t2=f_13479(C_a_i(&a,3),t1);
/* rec3275 */
t3=((C_word*)t0)[3];
f_16751(t3,((C_word*)t0)[2],t2);}

/* k18600 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18602,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp)));}

/* f_18635 in k18600 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18635,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18642,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t7))){
t8=(C_word)C_subchar(t2,t3);
t9=t6;
f_18642(t9,(C_word)C_i_eqvp(((C_word*)t0)[2],t8));}
else{
t8=t6;
f_18642(t8,C_SCHEME_FALSE);}}

/* k18640 */
static void C_fcall f_18642(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18642,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* next3267 */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3766 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* f_18603 in k18600 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18603,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18610,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t7))){
t8=(C_word)C_subchar(t2,t3);
/* char-ci=? */
t9=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,((C_word*)t0)[2],t8);}
else{
t8=t6;
f_18610(2,t8,C_SCHEME_FALSE);}}

/* k18608 */
static void C_ccall f_18610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18610,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* next3267 */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3759 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* f_18506 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18506,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18513,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_zerop(t3))){
t7=t6;
f_18513(t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t7))){
t8=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t9=(C_word)C_subchar(t2,t8);
t10=f_5540(t9);
if(C_truep(t10)){
t11=(C_word)C_subchar(t2,t3);
/* char-alphanumeric? */
t12=t6;
f_18513(t12,f_5540(t11));}
else{
t11=(C_word)C_subchar(t2,t3);
t12=f_5540(t11);
t13=t6;
f_18513(t13,(C_word)C_i_not(t12));}}
else{
t8=t6;
f_18513(t8,C_SCHEME_FALSE);}}}

/* k18511 */
static void C_fcall f_18513(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3267 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3748 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_18448 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18448,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18455,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
t8=(C_word)C_i_greater_or_equalp(t3,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18467,a[2]=t6,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t8)){
t10=t9;
f_18467(t10,t8);}
else{
t10=(C_word)C_subchar(t2,t3);
t11=f_5540(t10);
t12=t9;
f_18467(t12,(C_word)C_i_not(t11));}}

/* k18465 */
static void C_fcall f_18467(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18467,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_greaterp(((C_word*)t0)[4],C_fix(0)))){
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* char-alphanumeric? */
t4=((C_word*)t0)[2];
f_18455(t4,f_5540(t3));}
else{
t2=((C_word*)t0)[2];
f_18455(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_18455(t2,C_SCHEME_FALSE);}}

/* k18453 */
static void C_fcall f_18455(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3267 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3733 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_18414 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18414,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_fix((C_word)C_header_size(t2));
t7=(C_word)C_i_greater_or_equalp(t3,t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18424,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=t8;
f_18424(t9,t7);}
else{
t9=(C_word)C_subchar(t2,t3);
t10=t8;
f_18424(t10,(C_word)C_eqp(C_make_character(10),t9));}}

/* k18422 */
static void C_fcall f_18424(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3267 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3722 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_18390 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18390,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_greater_or_equalp(t3,t6))){
/* next3267 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t5);}
else{
/* fail3717 */
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t1);}}

/* f_18332 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18332,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18339,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_i_zerop(t3);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18351,a[2]=t6,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t7)){
t9=t8;
f_18351(t9,t7);}
else{
t9=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t10=(C_word)C_subchar(t2,t9);
t11=f_5540(t10);
t12=t8;
f_18351(t12,(C_word)C_i_not(t11));}}

/* k18349 */
static void C_fcall f_18351(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
if(C_truep((C_word)C_i_lessp(((C_word*)t0)[3],t2))){
t3=(C_word)C_subchar(((C_word*)t0)[4],((C_word*)t0)[3]);
/* char-alphanumeric? */
t4=((C_word*)t0)[2];
f_18339(t4,f_5540(t3));}
else{
t3=((C_word*)t0)[2];
f_18339(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_18339(t2,C_SCHEME_FALSE);}}

/* k18337 */
static void C_fcall f_18339(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3267 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3702 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_18298 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18298,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_zerop(t3);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18308,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_18308(t8,t6);}
else{
t8=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t9=(C_word)C_subchar(t2,t8);
t10=t7;
f_18308(t10,(C_word)C_eqp(C_make_character(10),t9));}}

/* k18306 */
static void C_fcall f_18308(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3267 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3691 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_18278 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18278(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18278,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_zerop(t3))){
/* next3267 */
t6=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t3,t4,t5);}
else{
/* fail3686 */
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}}

/* f_18236 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18236,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18243,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t7))){
t8=(C_word)C_subchar(t2,t3);
t9=(C_word)C_eqp(C_make_character(10),t8);
t10=t6;
f_18243(t10,(C_word)C_i_not(t9));}
else{
t8=t6;
f_18243(t8,C_SCHEME_FALSE);}}

/* k18241 */
static void C_fcall f_18243(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18243,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* next3267 */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3679 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* f_18208 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18208,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_lessp(t3,t6))){
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* next3267 */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t1,t2,t7,t4,t5);}
else{
/* fail3674 */
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t1);}}

/* k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_16794(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16794,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16801,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16805,a[2]=((C_word*)t0)[8],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* flag-set? */
f_6144(t3,((C_word*)t0)[7],C_fix(2));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[70]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t4=(C_word)C_i_length(t3);
switch(t4){
case C_fix(0):
t5=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16821,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t5=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* rec3275 */
t6=((C_word*)t0)[5];
f_16751(t6,((C_word*)t0)[10],t5);
default:
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16841,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* rec3275 */
t7=((C_word*)t0)[5];
f_16751(t7,t5,t6);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[183]);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=f_13479(C_a_i(&a,3),t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16900,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t7=lf[55];
f_6163(4,t7,t6,((C_word*)t0)[7],C_fix(2));}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[184]);
if(C_truep(t4)){
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t6=f_13479(C_a_i(&a,3),t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16921,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* flag-join */
t8=lf[54];
f_6154(4,t8,t7,((C_word*)t0)[7],C_fix(2));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[118]);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t7=f_13479(C_a_i(&a,3),t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16942,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* flag-join */
t9=lf[54];
f_6154(4,t9,t8,((C_word*)t0)[7],C_fix(32));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[119]);
if(C_truep(t6)){
t7=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t8=f_13479(C_a_i(&a,3),t7);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16963,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t10=lf[55];
f_6163(4,t10,t9,((C_word*)t0)[7],C_fix(32));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[82]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[6],lf[185]));
if(C_truep(t8)){
t9=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t10=(C_word)C_i_length(t9);
switch(t10){
case C_fix(0):
t11=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,((C_word*)t0)[9]);
case C_fix(1):
t11=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* rec3275 */
t12=((C_word*)t0)[5];
f_16751(t12,((C_word*)t0)[10],t11);
default:
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17001,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t12=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t13=f_13479(C_a_i(&a,3),t12);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17020,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=t13,a[5]=t11,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t15=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* sre-count-submatches */
f_12384(t14,t15);}}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[95]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17041,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t12=f_13479(C_a_i(&a,3),t11);
/* rec3275 */
t13=((C_word*)t0)[5];
f_16751(t13,t10,t12);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[96]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17069,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t13=f_13479(C_a_i(&a,3),t12);
/* rec3275 */
t14=((C_word*)t0)[5];
f_16751(t14,t11,t13);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[91]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17100,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t13=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t14=f_13479(C_a_i(&a,3),t13);
/* sre-empty? */
t15=lf[103];
f_11926(3,t15,t12,t14);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[92]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17158,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t14=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t15=f_13479(C_a_i(&a,3),t14);
/* sre-empty? */
t16=lf[103];
f_11926(3,t16,t13,t15);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[93]);
if(C_truep(t13)){
t14=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t15=f_13479(C_a_i(&a,3),t14);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17221,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t15,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t17=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t18=f_13479(C_a_i(&a,3),t17);
t19=(C_word)C_a_i_list(&a,2,lf[91],t18);
/* rec3275 */
t20=((C_word*)t0)[5];
f_16751(t20,t16,t19);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[98]);
if(C_truep(t14)){
t15=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t16=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_17270,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],a[4]=t15,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
/* ##sys#append */
t19=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t17,t18,C_SCHEME_END_OF_LIST);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[6],lf[99]);
if(C_truep(t15)){
t16=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17303,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],a[4]=t16,tmp=(C_word)a,a+=5,tmp);
t18=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
/* ##sys#append */
t19=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t17,t18,C_SCHEME_END_OF_LIST);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[6],lf[97]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(((C_word*)t0)[6],lf[94]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_17322,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t19=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_numberp(t19))){
t20=(C_word)C_u_i_caddr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_numberp(t20))){
t21=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t22=(C_word)C_u_i_caddr(((C_word*)t0)[8]);
t23=t18;
f_17322(t23,(C_word)C_i_greaterp(t21,t22));}
else{
t21=t18;
f_17322(t21,C_SCHEME_FALSE);}}
else{
t20=t18;
f_17322(t20,C_SCHEME_FALSE);}}
else{
t18=(C_word)C_eqp(((C_word*)t0)[6],lf[189]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17509,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t21=(C_word)C_a_i_cons(&a,2,lf[147],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t22=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t19,t20,t21);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[6],lf[190]);
if(C_truep(t19)){
t20=(C_word)C_a_i_cons(&a,2,lf[191],C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,lf[145],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[70],t21);
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17574,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],a[4]=t22,tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* ##sys#append */
t25=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t23,t24,C_SCHEME_END_OF_LIST);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[6],lf[193]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17599,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t22=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* string->sre */
t23=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t23+1)))(3,t23,t21,t22);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[6],lf[78]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17612,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t23=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t24=f_13479(C_a_i(&a,3),t23);
t25=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17635,tmp=(C_word)a,a+=2,tmp);
/* lp3262 */
t26=((C_word*)((C_word*)t0)[3])[1];
f_16748(t26,t22,t24,((C_word*)t0)[4],((C_word*)t0)[7],t25);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[6],lf[79]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17649,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t24=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t25=f_13479(C_a_i(&a,3),t24);
t26=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17672,tmp=(C_word)a,a+=2,tmp);
/* lp3262 */
t27=((C_word*)((C_word*)t0)[3])[1];
f_16748(t27,t23,t25,((C_word*)t0)[4],((C_word*)t0)[7],t26);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[6],lf[80]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17686,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t26=(C_word)C_a_i_cons(&a,2,lf[194],t25);
t27=f_13479(C_a_i(&a,3),t26);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17717,tmp=(C_word)a,a+=2,tmp);
/* lp3262 */
t29=((C_word*)((C_word*)t0)[3])[1];
f_16748(t29,t24,t27,((C_word*)t0)[4],((C_word*)t0)[7],t28);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[6],lf[81]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17735,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t26=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t27=(C_word)C_a_i_cons(&a,2,lf[195],t26);
t28=f_13479(C_a_i(&a,3),t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17766,tmp=(C_word)a,a+=2,tmp);
/* lp3262 */
t30=((C_word*)((C_word*)t0)[3])[1];
f_16748(t30,t25,t28,((C_word*)t0)[4],((C_word*)t0)[7],t29);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[6],lf[196]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17784,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t27=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t28=f_13479(C_a_i(&a,3),t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17807,tmp=(C_word)a,a+=2,tmp);
/* lp3262 */
t30=((C_word*)((C_word*)t0)[3])[1];
f_16748(t30,t26,t28,((C_word*)t0)[4],((C_word*)t0)[7],t29);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[6],lf[77]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_17821,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t28=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* sre-count-submatches */
f_12384(t27,t28);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[6],lf[155]);
t28=(C_truep(t27)?t27:(C_word)C_eqp(((C_word*)t0)[6],lf[154]));
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_17963,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t30=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_numberp(t30))){
t31=t29;
f_17963(2,t31,(C_word)C_u_i_cadr(((C_word*)t0)[8]));}
else{
t31=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t32=(C_word)C_u_i_assq(t31,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(t32)){
t33=t29;
f_17963(2,t33,(C_word)C_slot(t32,C_fix(1)));}
else{
t33=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* error */
t34=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t29,lf[200],t33);}}}
else{
t29=(C_word)C_eqp(((C_word*)t0)[6],lf[201]);
if(C_truep(t29)){
t30=(C_word)C_u_i_cdddr(((C_word*)t0)[8]);
t31=f_13479(C_a_i(&a,3),t30);
t32=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t33=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t32);
/* lp3262 */
t34=((C_word*)((C_word*)t0)[3])[1];
f_16748(t34,((C_word*)t0)[10],t31,t33,((C_word*)t0)[7],((C_word*)t0)[9]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[6],lf[76]);
if(C_truep(t30)){
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18090,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t32=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t33=f_13479(C_a_i(&a,3),t32);
t34=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t35=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18120,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lp3262 */
t36=((C_word*)((C_word*)t0)[3])[1];
f_16748(t36,t31,t33,t34,((C_word*)t0)[7],t35);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[6],lf[85]);
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18160,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t33=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
/* ##sys#append */
t34=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t32,t33,C_SCHEME_END_OF_LIST);}
else{
/* error */
t32=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t32+1)))(4,t32,((C_word*)t0)[10],lf[202],((C_word*)t0)[8]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k18158 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18160,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[76],t1);
/* rec3275 */
t3=((C_word*)t0)[3];
f_16751(t3,((C_word*)t0)[2],t2);}

/* a18119 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18120,6,t0,t1,t2,t3,t4,t5);}
t6=f_5124(C_a_i(&a,8),t4,((C_word*)t0)[3]);
t7=f_5152(C_a_i(&a,8),t4,((C_word*)t0)[3],t3);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18132,a[2]=t5,a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* next3267 */
t9=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,t2,t3,t4,t8);}

/* a18131 in a18119 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18132,2,t0,t1);}
t2=f_5152(C_a_i(&a,8),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
/* fail3642 */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k18088 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18090,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18091,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_18091 in k18088 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18091,6,t0,t1,t2,t3,t4,t5);}
t6=f_5110(C_a_i(&a,8),t4,((C_word*)t0)[3]);
t7=f_5138(C_a_i(&a,8),t4,((C_word*)t0)[3],t3);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18103,a[2]=t5,a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* body3638 */
t9=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,t2,t3,t4,t8);}

/* a18102 */
static void C_ccall f_18103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18103,2,t0,t1);}
t2=f_5138(C_a_i(&a,8),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
/* fail3653 */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k17961 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17963,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(t2,lf[154]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18019,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_18019(2,t5,t3);}
else{
/* flag-set? */
f_6144(t4,((C_word*)t0)[2],C_fix(2));}}

/* k18017 in k17961 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_18019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18019,2,t0,t1);}
t2=(C_truep(t1)?*((C_word*)lf[198]+1):*((C_word*)lf[199]+1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17967,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_17967 in k18017 in k17961 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17967,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_17971,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t4,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* irregex-match-substring */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t4,((C_word*)t0)[2]);}

/* k17969 */
static void C_ccall f_17971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17971,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_fix((C_word)C_header_size(t1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17989,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
if(C_truep((C_word)C_i_less_or_equalp(t4,t6))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18005,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* substring */
t8=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[5],((C_word*)t0)[8],t4);}
else{
t7=t5;
f_17989(2,t7,C_SCHEME_FALSE);}}
else{
/* fail3630 */
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}

/* k18003 in k17969 */
static void C_ccall f_18005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compare3609 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k17987 in k17969 */
static void C_ccall f_17989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3267 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3630 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* k17819 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_17824,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[8]);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],t1);
/* lp3262 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_16748(t5,t2,t3,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k17822 in k17819 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_17827,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cdddr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17922,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_caddr(((C_word*)t0)[9]);
/* sre-count-submatches */
f_12384(t6,t7);}
else{
t4=t2;
f_17827(2,t4,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17931,tmp=(C_word)a,a+=2,tmp));}}

/* f_17931 in k17822 in k17819 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17931,6,t0,t1,t2,t3,t4,t5);}
/* fail3560 */
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k17924 in k17822 in k17819 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* + */
C_plus(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k17920 in k17822 in k17819 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3262 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_16748(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17825 in k17822 in k17819 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17827,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_i_numberp(t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_17836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t3)){
t5=t4;
f_17836(t5,t3);}
else{
t5=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t6=t4;
f_17836(t6,(C_word)C_i_symbolp(t5));}}

/* k17834 in k17825 in k17822 in k17819 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_17836(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17836,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17839,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
t5=(C_word)C_u_i_assq(t4,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=t2;
f_17839(2,t6,(C_word)C_slot(t5,C_fix(1)));}
else{
/* error */
t6=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,lf[197],((C_word*)t0)[6]);}}
else{
t4=t2;
f_17839(2,t4,(C_word)C_u_i_cadr(((C_word*)t0)[6]));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17882,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* lp3262 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_16748(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k17880 in k17834 in k17825 in k17822 in k17819 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17882,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17883,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_17883 in k17880 in k17834 in k17825 in k17822 in k17819 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17883,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17889,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* test3594 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17888 */
static void C_ccall f_17889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17889,2,t0,t1);}
/* fail3556 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17837 in k17834 in k17825 in k17822 in k17819 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17839,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp));}

/* f_17840 in k17837 in k17834 in k17825 in k17822 in k17819 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17840,6,t0,t1,t2,t3,t4,t5);}
t6=f_5124(C_a_i(&a,8),t4,((C_word*)t0)[4]);
if(C_truep(t6)){
/* pass3554 */
t7=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t5);}
else{
/* fail3556 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t5);}}

/* a17806 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17807,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k17782 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17784,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17785,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_17785 in k17782 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17785,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17789,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17800,tmp=(C_word)a,a+=2,tmp);
/* once3536 */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,t2,t3,t4,t7);}

/* a17799 */
static void C_ccall f_17800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17800,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k17787 */
static void C_ccall f_17789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3267 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3546 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* a17765 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17766,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k17733 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17735,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17736,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_17736 in k17733 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17736,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17753,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17757,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* substring */
t8=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(0),t3);}

/* k17755 */
static void C_ccall f_17757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17759,tmp=(C_word)a,a+=2,tmp);
/* check3523 */
t3=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2],t2);}

/* a17758 in k17755 */
static void C_ccall f_17759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17759,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k17751 */
static void C_ccall f_17753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[7],t1))){
/* fail3533 */
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
/* next3267 */
t2=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* a17716 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17717,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k17684 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17686,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17687,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_17687 in k17684 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17687(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17687,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17704,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17708,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* substring */
t8=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(0),t3);}

/* k17706 */
static void C_ccall f_17708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17710,tmp=(C_word)a,a+=2,tmp);
/* check3510 */
t3=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2],t2);}

/* a17709 in k17706 */
static void C_ccall f_17710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17710,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k17702 */
static void C_ccall f_17704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[7],t1))){
/* next3267 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3520 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* a17671 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17672,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k17647 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17649,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17650,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_17650 in k17647 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17650,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17657,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17665,tmp=(C_word)a,a+=2,tmp);
/* check3497 */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,t2,t3,t4,t7);}

/* a17664 */
static void C_ccall f_17665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17665,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k17655 */
static void C_ccall f_17657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* fail3507 */
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
/* next3267 */
t2=((C_word*)t0)[5];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* a17634 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17635,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k17610 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17612,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17613,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_17613 in k17610 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17613,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17620,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17628,tmp=(C_word)a,a+=2,tmp);
/* check3484 */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,t2,t3,t4,t7);}

/* a17627 */
static void C_ccall f_17628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17628,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k17618 */
static void C_ccall f_17620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3267 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3494 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* k17597 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* rec3275 */
t2=((C_word*)t0)[3];
f_16751(t2,((C_word*)t0)[2],t1);}

/* k17572 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17574,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[70],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[192],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[93],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[147],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[148],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[82],t10);
/* rec3275 */
t12=((C_word*)t0)[3];
f_16751(t12,((C_word*)t0)[2],t11);}

/* k17507 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17509,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[148],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[82],t2);
/* rec3275 */
t4=((C_word*)t0)[3];
f_16751(t4,((C_word*)t0)[2],t3);}

/* k17320 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_17322(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17322,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_17325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=t2;
f_17325(t3,t1);}
else{
t3=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t4=t2;
f_17325(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_caddr(((C_word*)t0)[7])));}}

/* k17323 in k17320 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_17325(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17325,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17326,tmp=(C_word)a,a+=2,tmp));}
else{
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
t5=(C_word)C_eqp(lf[97],t4);
t6=(C_truep(t5)?lf[95]:lf[96]);
t7=(C_word)C_u_i_car(((C_word*)t0)[7]);
t8=(C_word)C_eqp(lf[97],t7);
t9=(C_truep(t8)?lf[91]:lf[92]);
t10=(C_word)C_u_i_cdddr(((C_word*)t0)[7]);
t11=f_13479(C_a_i(&a,3),t10);
t12=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_17348,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=t11,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[8],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* sre-strip-submatches */
t13=lf[188];
f_13529(3,t13,t12,t11);}}

/* k17346 in k17323 in k17320 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_17351,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[12],((C_word*)t0)[6]))){
t3=t2;
f_17351(2,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17398,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17414,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[6],((C_word*)t0)[12]);
/* zero-to */
f_5642(t4,t5);}}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
/* rec3275 */
t5=((C_word*)t0)[2];
f_16751(t5,t2,t4);}}

/* k17412 in k17346 in k17323 in k17320 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_5908(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a17397 in k17346 in k17323 in k17320 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_17398,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
/* lp3262 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_16748(t6,t1,t5,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k17349 in k17346 in k17323 in k17320 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17351,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(((C_word*)t0)[8]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17368,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17372,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17378,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17383,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[8],C_fix(1));
/* zero-to */
f_5642(t5,t6);}}

/* k17381 in k17349 in k17346 in k17323 in k17320 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a17377 in k17349 in k17346 in k17323 in k17320 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17378(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_17378,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k17370 in k17349 in k17346 in k17323 in k17320 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17372,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t3=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k17366 in k17349 in k17346 in k17323 in k17320 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17368,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[82],t1);
/* lp3262 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_16748(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_17326 in k17323 in k17320 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17326,6,t0,t1,t2,t3,t4,t5);}
/* fail3441 */
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k17301 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17303,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[97],t3);
/* rec3275 */
t5=((C_word*)t0)[3];
f_16751(t5,((C_word*)t0)[2],t4);}

/* k17268 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17270,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[97],t3);
/* rec3275 */
t5=((C_word*)t0)[3];
f_16751(t5,((C_word*)t0)[2],t4);}

/* k17219 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3262 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_16748(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k17156 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17158,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],lf[187],((C_word*)t0)[6]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17165,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t6=f_13479(C_a_i(&a,3),t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17182,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* lp3262 */
t8=((C_word*)((C_word*)t0)[4])[1];
f_16748(t8,t4,t6,((C_word*)t0)[3],((C_word*)t0)[2],t7);}}

/* a17181 in k17156 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17182,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17188,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* next3267 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17187 in a17181 in k17156 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17188,2,t0,t1);}
/* body3389 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17163 in k17156 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17165,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));}

/* f_17166 in k17163 in k17156 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17166,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17172,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* next3267 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17171 */
static void C_ccall f_17172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17172,2,t0,t1);}
/* body3389 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17098 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17100,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],lf[186],((C_word*)t0)[6]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17107,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t6=f_13479(C_a_i(&a,3),t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17124,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* lp3262 */
t8=((C_word*)((C_word*)t0)[4])[1];
f_16748(t8,t4,t6,((C_word*)t0)[3],((C_word*)t0)[2],t7);}}

/* a17123 in k17098 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17124,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17130,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* body3366 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17129 in a17123 in k17098 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17130,2,t0,t1);}
/* next3267 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17105 in k17098 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17107,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17108,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_17108 in k17105 in k17098 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17108,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17114,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* body3366 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17113 */
static void C_ccall f_17114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17114,2,t0,t1);}
/* next3267 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17067 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17069,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17070,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_17070 in k17067 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17070,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17076,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* next3267 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17075 */
static void C_ccall f_17076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17076,2,t0,t1);}
/* body3351 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17039 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17041,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17042,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_17042 in k17039 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17042,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17048,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* body3343 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17047 */
static void C_ccall f_17048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17048,2,t0,t1);}
/* next3267 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17018 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17020,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],t1);
/* lp3262 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_16748(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k16999 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_17001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* lp3262 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_16748(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k16961 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3262 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_16748(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k16940 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3262 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_16748(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k16919 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3262 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_16748(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k16898 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3262 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_16748(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k16839 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16844,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
t4=f_13504(C_a_i(&a,3),t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* sre-count-submatches */
f_12384(t5,t6);}

/* k16865 in k16839 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16867,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],t1);
/* lp3262 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_16748(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k16842 in k16839 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16844,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16845,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_16845 in k16842 in k16839 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16845,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16851,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* first3317 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a16850 */
static void C_ccall f_16851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16851,2,t0,t1);}
/* rest3319 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_16821 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16821,6,t0,t1,t2,t3,t4,t5);}
/* fail3314 */
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k16803 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16805,2,t0,t1);}
/* sre->cset */
f_18830(((C_word*)t0)[3],((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,t1));}

/* k16799 in k16792 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre-cset->procedure */
f_18713(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k16780 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16782,2,t0,t1);}
/* sre->cset */
f_18830(((C_word*)t0)[3],((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,t1));}

/* k16772 in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre-cset->procedure */
f_18713(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* rec in lp in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_fcall f_16751(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16751,NULL,3,t0,t1,t2);}
/* lp3262 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_16748(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a16744 in k16734 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_16745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16745,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k11832 in k11823 in k12455 in k12448 in k12445 in k11817 in k11814 in k11811 in k11808 in k11805 in k11802 in k11799 in k11796 in k11793 in k11790 in k11787 in sre->irregex in k4888 */
static void C_ccall f_11834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11834,2,t0,t1);}
/* make-irregex */
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_4893(C_a_i(&a,10),C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* string->irregex in k4888 */
static void C_ccall f_11775(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_11775r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_11775r(t0,t1,t2,t3);}}

static void C_ccall f_11775r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11783,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[68]+1),t2,t3);}

/* k11781 in string->irregex in k4888 */
static void C_ccall f_11783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[3],*((C_word*)lf[180]+1),t1,((C_word*)t0)[2]);}

/* irregex in k4888 */
static void C_ccall f_11754(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_11754r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_11754r(t0,t1,t2,t3);}}

static void C_ccall f_11754r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11761,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* irregex? */
t5=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k11759 in irregex in k4888 */
static void C_ccall f_11761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
C_apply(5,0,((C_word*)t0)[4],*((C_word*)lf[179]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_apply(5,0,((C_word*)t0)[4],*((C_word*)lf[180]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}}

/* cset->utf8-pattern in k4888 */
static void C_fcall f_11304(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11304,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11310,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_11310(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* lp in cset->utf8-pattern in k4888 */
static void C_fcall f_11310(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11310,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11324,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11328,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* reverse */
t7=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_charp(t5))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11358,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_u_i_car(t2);
/* high-char? */
t8=lf[128];
f_10025(3,t8,t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11398,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_u_i_caar(t2);
/* high-char? */
t8=lf[128];
f_10025(3,t8,t6,t7);}}}

/* k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_11401(2,t3,t1);}
else{
t3=(C_word)C_u_i_cdar(((C_word*)t0)[6]);
/* high-char? */
t4=lf[128];
f_10025(3,t4,t2,t3);}}

/* k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11401,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11416,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t5=(C_word)C_u_i_cdar(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10463,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* char->utf8-list */
f_10330(t6,t4);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_i_cdar(((C_word*)t0)[6]);
t4=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* lp1501 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_11310(t7,((C_word*)t0)[3],t2,((C_word*)t0)[5],t6);}}

/* k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_10463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10466,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* char->utf8-list */
f_10330(t2,((C_word*)t0)[2]);}

/* k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_10466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10466,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(C_word)C_i_length(t1);
if(C_truep((C_word)C_i_nequalp(t2,t3))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10492,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_10492(t7,((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t4=((C_word*)t0)[3];
t5=t1;
t6=(C_word)C_i_length(t4);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10959,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
t10=(C_word)C_u_i_car(t4);
t11=(C_word)C_i_less_or_equalp(t10,C_fix(127));
t12=(C_truep(t11)?C_fix(127):C_fix(255));
t13=(C_word)C_make_character((C_word)C_unfix(t12));
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t9,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[31],t15);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11165,a[2]=t6,a[3]=t7,a[4]=t5,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11167,tmp=(C_word)a,a+=2,tmp);
t19=(C_word)C_slot(t4,C_fix(1));
/* map */
t20=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t17,t18,t19);}}

/* a11166 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11167(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11167,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[31],t4));}

/* k11163 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11165,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=f_13479(C_a_i(&a,3),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10967,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11059,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11141,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11145,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_length(((C_word*)t0)[4]);
/* - */
C_minus(5,0,t8,t9,((C_word*)t0)[2],C_fix(1));}

/* k11143 in k11163 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* zero-to */
f_5642(((C_word*)t0)[2],t1);}

/* k11139 in k11163 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11058 in k11163 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11059,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11133,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11137,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* + */
C_plus(5,0,t4,t2,((C_word*)t0)[2],C_fix(1));}

/* k11135 in a11058 in k11163 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utf8-lowest-digit-of-length */
f_10270(((C_word*)t0)[2],t1);}

/* k11131 in a11058 in k11163 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11133,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11129,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* + */
C_plus(5,0,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* k11127 in k11131 in a11058 in k11163 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
switch(t1){
case C_fix(1):
t2=((C_word*)t0)[2];
f_11125(2,t2,C_fix(127));
case C_fix(2):
t2=((C_word*)t0)[2];
f_11125(2,t2,C_fix(223));
case C_fix(3):
t2=((C_word*)t0)[2];
f_11125(2,t2,C_fix(239));
case C_fix(4):
t2=((C_word*)t0)[2];
f_11125(2,t2,C_fix(247));
default:
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[177],t1);}}

/* k11123 in k11131 in a11058 in k11163 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11125,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[31],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11075,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11077,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11101,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* zero-to */
f_5642(t8,t9);}

/* k11099 in k11123 in k11131 in a11058 in k11163 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11076 in k11123 in k11131 in a11058 in k11163 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11077(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11077,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[31],t4));}

/* k11073 in k11123 in k11131 in a11058 in k11163 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11075,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* sre-sequence */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_13479(C_a_i(&a,3),t2));}

/* k10965 in k11163 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_10967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11041,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=f_10035(t5);
/* utf8-lowest-digit-of-length */
f_10270(t2,t6);}

/* k11039 in k10965 in k11163 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11041,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[31],t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10989,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* map */
t12=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t9,t10,t11);}

/* a10988 in k11039 in k10965 in k11163 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_10989(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10989,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[31],t4));}

/* k10985 in k11039 in k10965 in k11163 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_10987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10987,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=f_13479(C_a_i(&a,3),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* append */
t5=*((C_word*)lf[125]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k10957 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_10959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10959,2,t0,t1);}
t2=f_13504(C_a_i(&a,3),t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10487,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* unicode-range-up-to */
f_10820(t3,((C_word*)t0)[2]);}

/* k10485 in k10957 in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_10487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10487,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* sre-alternate */
t3=((C_word*)t0)[2];
f_11416(2,t3,f_13504(C_a_i(&a,3),t2));}

/* lp in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_fcall f_10492(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10492,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_i_nequalp(t4,t5))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10520,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_slot(t3,C_fix(1));
/* lp1387 */
t17=t8;
t18=t9;
t19=t10;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_a_i_plus(&a,2,t6,C_fix(1));
t8=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_i_nequalp(t7,t8))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10549,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* unicode-range-up-from */
f_10692(t9,t2);}
else{
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10564,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* unicode-range-up-from */
f_10692(t9,t2);}}}}

/* k10562 in lp in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_10564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10564,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_a_i_plus(&a,2,t4,C_fix(1));
t6=(C_word)C_make_character((C_word)C_unfix(t5));
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_a_i_minus(&a,2,t7,C_fix(1));
t9=(C_word)C_make_character((C_word)C_unfix(t8));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11242,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_eqp(t6,t9);
if(C_truep(t11)){
t12=t10;
f_11242(t12,t6);}
else{
t12=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t6,t12);
t14=t10;
f_11242(t14,(C_word)C_a_i_cons(&a,2,lf[31],t13));}}

/* k11240 in k10562 in lp in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_fcall f_11242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11242,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11246,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11248,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a11247 in k11240 in k10562 in lp in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11248(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11248,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[31],t4));}

/* k11244 in k11240 in k10562 in lp in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11246,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=f_13479(C_a_i(&a,3),t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10572,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* unicode-range-up-to */
f_10820(t4,((C_word*)t0)[2]);}

/* k10570 in k11244 in k11240 in k10562 in lp in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_10572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10572,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
/* sre-alternate */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_13504(C_a_i(&a,3),t2));}

/* k10547 in lp in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_10549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10553,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* unicode-range-up-to */
f_10820(t2,((C_word*)t0)[2]);}

/* k10551 in k10547 in lp in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_10553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10553,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* sre-alternate */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_13504(C_a_i(&a,3),t2));}

/* k10518 in lp in k10464 in k10461 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_10520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10520,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* sre-sequence */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_13479(C_a_i(&a,3),t2));}

/* k11414 in k11399 in k11396 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11416,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* lp1501 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_11310(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k11356 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11358,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
/* lp1501 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_11310(t5,((C_word*)t0)[3],t2,t4,((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* lp1501 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_11310(t5,((C_word*)t0)[3],t2,((C_word*)t0)[5],t4);}}

/* k11326 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11332,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
t3=t2;
f_11332(t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11346,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k11344 in k11326 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11346,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[31],t1);
t3=((C_word*)t0)[2];
f_11332(t3,(C_word)C_a_i_list(&a,1,t2));}

/* k11330 in k11326 in lp in cset->utf8-pattern in k4888 */
static void C_fcall f_11332(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11322 in lp in cset->utf8-pattern in k4888 */
static void C_ccall f_11324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11324,2,t0,t1);}
/* sre-alternate */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_13504(C_a_i(&a,3),t1));}

/* unicode-range-up-to in k4888 */
static void C_fcall f_10820(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10820,NULL,2,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10840,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10842,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10938,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* reverse */
t9=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k10936 in unicode-range-up-to in k4888 */
static void C_ccall f_10938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10938,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10886,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10890,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10922,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10930,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* reverse */
t8=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k10928 in k10936 in unicode-range-up-to in k4888 */
static void C_ccall f_10930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(1));
/* reverse */
t3=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k10920 in k10936 in unicode-range-up-to in k4888 */
static void C_ccall f_10922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[173]+1),t1);}

/* k10888 in k10936 in unicode-range-up-to in k4888 */
static void C_ccall f_10890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10918,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* last */
f_5768(t2,((C_word*)t0)[2]);}

/* k10916 in k10888 in k10936 in unicode-range-up-to in k4888 */
static void C_ccall f_10918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10918,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=(C_word)C_a_i_cons(&a,2,lf[31],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* append */
t7=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k10884 in k10936 in unicode-range-up-to in k4888 */
static void C_ccall f_10886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10886,2,t0,t1);}
t2=f_13479(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* unicode-range-helper */
f_10606(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t3);}

/* a10841 in unicode-range-up-to in k4888 */
static void C_ccall f_10842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10842,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,C_make_character(128),t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[31],t7));}

/* k10838 in unicode-range-up-to in k4888 */
static void C_ccall f_10840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10840,2,t0,t1);}
t2=f_13504(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
/* sre-sequence */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_13479(C_a_i(&a,3),t3));}

/* unicode-range-up-from in k4888 */
static void C_fcall f_10692(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10692,NULL,2,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10712,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10714,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10810,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* reverse */
t9=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k10808 in unicode-range-up-from in k4888 */
static void C_ccall f_10810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10810,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10758,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10762,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10794,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10802,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* reverse */
t8=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k10800 in k10808 in unicode-range-up-from in k4888 */
static void C_ccall f_10802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(1));
/* reverse */
t3=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k10792 in k10808 in unicode-range-up-from in k4888 */
static void C_ccall f_10794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[173]+1),t1);}

/* k10760 in k10808 in unicode-range-up-from in k4888 */
static void C_ccall f_10762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10790,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* last */
f_5768(t2,((C_word*)t0)[2]);}

/* k10788 in k10760 in k10808 in unicode-range-up-from in k4888 */
static void C_ccall f_10790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10790,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[31],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* append */
t7=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k10756 in k10808 in unicode-range-up-from in k4888 */
static void C_ccall f_10758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10758,2,t0,t1);}
t2=f_13479(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* unicode-range-helper */
f_10606(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t3);}

/* a10713 in unicode-range-up-from in k4888 */
static void C_ccall f_10714(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10714,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
t4=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[31],t7));}

/* k10710 in unicode-range-up-from in k4888 */
static void C_ccall f_10712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10712,2,t0,t1);}
t2=f_13504(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
/* sre-sequence */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_13479(C_a_i(&a,3),t3));}

/* unicode-range-helper in k4888 */
static void C_fcall f_10606(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10606,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t3))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_a_i_cons(&a,2,t7,t4);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10636,a[2]=t8,a[3]=t6,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10640,a[2]=t2,a[3]=t3,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* map */
t11=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,*((C_word*)lf[173]+1),t4);}}

/* k10638 in unicode-range-helper in k4888 */
static void C_ccall f_10640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10648,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* one1402 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k10646 in k10638 in unicode-range-helper in k4888 */
static void C_ccall f_10648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10652,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10656,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10658,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* map */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a10657 in k10646 in k10638 in unicode-range-helper in k4888 */
static void C_ccall f_10658(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10658,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[31],t4));}

/* k10654 in k10646 in k10638 in unicode-range-helper in k4888 */
static void C_ccall f_10656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10650 in k10646 in k10638 in unicode-range-helper in k4888 */
static void C_ccall f_10652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10652,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10634 in unicode-range-helper in k4888 */
static void C_ccall f_10636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10636,2,t0,t1);}
t2=f_13479(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[6]);
/* unicode-range-helper */
f_10606(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* char->utf8-list in k4888 */
static void C_fcall f_10330(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10330,NULL,2,t1,t2);}
t3=(C_word)C_fix((C_word)C_character_code(t2));
if(C_truep((C_word)C_i_less_or_equalp(t3,C_fix(127)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,1,t3));}
else{
if(C_truep((C_word)C_i_less_or_equalp(t3,C_fix(2047)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10356,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10368,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_6024(t5,t3,C_fix(6));}
else{
if(C_truep((C_word)C_i_less_or_equalp(t3,C_fix(65535)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10381,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10405,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_6024(t5,t3,C_fix(12));}
else{
if(C_truep((C_word)C_i_less_or_equalp(t3,C_fix(2097151)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10418,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10454,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_6024(t5,t3,C_fix(18));}
else{
/* error */
t4=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[171],t3);}}}}}

/* k10452 in char->utf8-list in k4888 */
static void C_ccall f_10454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6050(((C_word*)t0)[2],C_fix(240),t1);}

/* k10416 in char->utf8-list in k4888 */
static void C_ccall f_10418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10422,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10446,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10450,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_6024(t4,((C_word*)t0)[2],C_fix(12));}

/* k10448 in k10416 in char->utf8-list in k4888 */
static void C_ccall f_10450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-and */
f_6097(((C_word*)t0)[2],t1,C_fix(63));}

/* k10444 in k10416 in char->utf8-list in k4888 */
static void C_ccall f_10446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6050(((C_word*)t0)[2],C_fix(128),t1);}

/* k10420 in k10416 in char->utf8-list in k4888 */
static void C_ccall f_10422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10426,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10438,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10442,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_6024(t4,((C_word*)t0)[2],C_fix(6));}

/* k10440 in k10420 in k10416 in char->utf8-list in k4888 */
static void C_ccall f_10442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-and */
f_6097(((C_word*)t0)[2],t1,C_fix(63));}

/* k10436 in k10420 in k10416 in char->utf8-list in k4888 */
static void C_ccall f_10438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6050(((C_word*)t0)[2],C_fix(128),t1);}

/* k10424 in k10420 in k10416 in char->utf8-list in k4888 */
static void C_ccall f_10426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10430,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10434,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* bit-and */
f_6097(t3,((C_word*)t0)[2],C_fix(63));}

/* k10432 in k10424 in k10420 in k10416 in char->utf8-list in k4888 */
static void C_ccall f_10434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6050(((C_word*)t0)[2],C_fix(128),t1);}

/* k10428 in k10424 in k10420 in k10416 in char->utf8-list in k4888 */
static void C_ccall f_10430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10430,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10403 in char->utf8-list in k4888 */
static void C_ccall f_10405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6050(((C_word*)t0)[2],C_fix(224),t1);}

/* k10379 in char->utf8-list in k4888 */
static void C_ccall f_10381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10385,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10397,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10401,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* bit-shr */
f_6024(t4,((C_word*)t0)[2],C_fix(6));}

/* k10399 in k10379 in char->utf8-list in k4888 */
static void C_ccall f_10401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-and */
f_6097(((C_word*)t0)[2],t1,C_fix(63));}

/* k10395 in k10379 in char->utf8-list in k4888 */
static void C_ccall f_10397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6050(((C_word*)t0)[2],C_fix(128),t1);}

/* k10383 in k10379 in char->utf8-list in k4888 */
static void C_ccall f_10385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10389,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10393,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* bit-and */
f_6097(t3,((C_word*)t0)[2],C_fix(63));}

/* k10391 in k10383 in k10379 in char->utf8-list in k4888 */
static void C_ccall f_10393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6050(((C_word*)t0)[2],C_fix(128),t1);}

/* k10387 in k10383 in k10379 in char->utf8-list in k4888 */
static void C_ccall f_10389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10389,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10366 in char->utf8-list in k4888 */
static void C_ccall f_10368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6050(((C_word*)t0)[2],C_fix(192),t1);}

/* k10354 in char->utf8-list in k4888 */
static void C_ccall f_10356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10360,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10364,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* bit-and */
f_6097(t3,((C_word*)t0)[2],C_fix(63));}

/* k10362 in k10354 in char->utf8-list in k4888 */
static void C_ccall f_10364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6050(((C_word*)t0)[2],C_fix(128),t1);}

/* k10358 in k10354 in char->utf8-list in k4888 */
static void C_ccall f_10360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10360,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* utf8-lowest-digit-of-length in k4888 */
static void C_fcall f_10270(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10270,NULL,2,t1,t2);}
t3=t2;
switch(t3){
case C_fix(1):
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));
case C_fix(2):
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(192));
case C_fix(3):
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(224));
case C_fix(4):
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(240));
default:
/* error */
t4=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[169],t2);}}

/* utf8-string-ref in k4888 */
static void C_fcall f_10045(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10045,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10048,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=t4;
switch(t6){
case C_fix(1):
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_subchar(t2,t3));
case C_fix(2):
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10082,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10098,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=f_10048(t5,t3);
/* bit-and */
f_6097(t8,t9,C_fix(31));
case C_fix(3):
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10115,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10119,a[2]=t5,a[3]=t3,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10151,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=f_10048(t5,t3);
/* bit-and */
f_6097(t9,t10,C_fix(15));
case C_fix(4):
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10168,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10172,a[2]=t5,a[3]=t3,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10220,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=f_10048(t5,t3);
/* bit-and */
f_6097(t9,t10,C_fix(7));
default:
/* error */
t7=*((C_word*)lf[24]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,lf[167],t2,t4,t3);}}

/* k10218 in utf8-string-ref in k4888 */
static void C_ccall f_10220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_6034(((C_word*)t0)[2],t1,C_fix(18));}

/* k10170 in utf8-string-ref in k4888 */
static void C_ccall f_10172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10208,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t5=f_10048(((C_word*)t0)[2],t4);
/* bit-and */
f_6097(t3,t5,C_fix(63));}

/* k10206 in k10170 in utf8-string-ref in k4888 */
static void C_ccall f_10208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_6034(((C_word*)t0)[2],t1,C_fix(12));}

/* k10174 in k10170 in utf8-string-ref in k4888 */
static void C_ccall f_10176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10196,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(2));
t5=f_10048(((C_word*)t0)[2],t4);
/* bit-and */
f_6097(t3,t5,C_fix(63));}

/* k10194 in k10174 in k10170 in utf8-string-ref in k4888 */
static void C_ccall f_10196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_6034(((C_word*)t0)[2],t1,C_fix(6));}

/* k10178 in k10174 in k10170 in utf8-string-ref in k4888 */
static void C_ccall f_10180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10184,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(3));
t4=f_10048(((C_word*)t0)[2],t3);
/* bit-and */
f_6097(t2,t4,C_fix(63));}

/* k10182 in k10178 in k10174 in k10170 in utf8-string-ref in k4888 */
static void C_ccall f_10184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* + */
C_plus(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10166 in utf8-string-ref in k4888 */
static void C_ccall f_10168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_make_character((C_word)C_unfix(t1)));}

/* k10149 in utf8-string-ref in k4888 */
static void C_ccall f_10151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_6034(((C_word*)t0)[2],t1,C_fix(12));}

/* k10117 in utf8-string-ref in k4888 */
static void C_ccall f_10119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10139,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t5=f_10048(((C_word*)t0)[2],t4);
/* bit-and */
f_6097(t3,t5,C_fix(63));}

/* k10137 in k10117 in utf8-string-ref in k4888 */
static void C_ccall f_10139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_6034(((C_word*)t0)[2],t1,C_fix(6));}

/* k10121 in k10117 in utf8-string-ref in k4888 */
static void C_ccall f_10123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10127,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(2));
t4=f_10048(((C_word*)t0)[2],t3);
/* bit-and */
f_6097(t2,t4,C_fix(63));}

/* k10125 in k10121 in k10117 in utf8-string-ref in k4888 */
static void C_ccall f_10127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* + */
C_plus(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10113 in utf8-string-ref in k4888 */
static void C_ccall f_10115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_make_character((C_word)C_unfix(t1)));}

/* k10096 in utf8-string-ref in k4888 */
static void C_ccall f_10098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-shl */
f_6034(((C_word*)t0)[2],t1,C_fix(6));}

/* k10080 in utf8-string-ref in k4888 */
static void C_ccall f_10082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10086,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t4=f_10048(((C_word*)t0)[2],t3);
/* bit-and */
f_6097(t2,t4,C_fix(63));}

/* k10084 in k10080 in utf8-string-ref in k4888 */
static void C_ccall f_10086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10086,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_make_character((C_word)C_unfix(t2)));}

/* byte in utf8-string-ref in k4888 */
static C_word C_fcall f_10048(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
return((C_word)C_fix((C_word)C_character_code(t2)));}

/* utf8-start-char->length in k4888 */
static C_word C_fcall f_10035(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_fix((C_word)C_character_code(t1));
return((C_word)C_slot(lf[166],t2));}

/* high-char? in k4888 */
static void C_ccall f_10025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10025,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_character_code(t2));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_less_or_equalp(C_fix(128),t3));}

/* string-parse-hex-escape in k4888 */
static void C_fcall f_9233(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9233,NULL,4,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_greater_or_equalp(t3,t4))){
/* error */
t5=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[161],t2,t3);}
else{
t5=(C_word)C_subchar(t2,t3);
t6=(C_word)C_eqp(C_make_character(123),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9252,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t9=t2;
t10=(C_word)C_a_i_list(&a,1,t8);
t11=(C_word)C_fix((C_word)C_header_size(t9));
t12=(C_word)C_i_pairp(t10);
t13=(C_truep(t12)?(C_word)C_u_i_car(t10):C_fix(0));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5383,a[2]=t15,a[3]=t9,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t17=((C_word*)t15)[1];
f_5383(t17,t7,t13);}
else{
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
if(C_truep((C_word)C_i_greater_or_equalp(t7,t4))){
/* error */
t8=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[164],t2,t3);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9300,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_a_i_plus(&a,2,t3,C_fix(2));
/* substring */
t10=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t8,t2,t3,t9);}}}}

/* k9298 in string-parse-hex-escape in k4888 */
static void C_ccall f_9300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9303,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* string->number */
C_string_to_number(4,0,t2,t1,C_fix(16));}

/* k9301 in k9298 in string-parse-hex-escape in k4888 */
static void C_ccall f_9303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9303,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(2));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}
else{
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],lf[165],((C_word*)t0)[2]);}}

/* scan in string-parse-hex-escape in k4888 */
static void C_fcall f_5383(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5383,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(C_make_character(125),t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* scan206 */
t7=t1;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}}

/* k9250 in string-parse-hex-escape in k4888 */
static void C_ccall f_9252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9252,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9264,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* substring */
t5=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[2],t4,t1);}
else{
/* error */
t3=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],lf[163],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k9262 in k9250 in string-parse-hex-escape in k4888 */
static void C_ccall f_9264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9267,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* string->number */
C_string_to_number(4,0,t2,t1,C_fix(16));}

/* k9265 in k9262 in k9250 in string-parse-hex-escape in k4888 */
static void C_ccall f_9267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9267,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]));}
else{
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],lf[162],((C_word*)t0)[2]);}}

/* char-altcase in k4888 */
static C_word C_fcall f_9191(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_u_i_char_upper_casep(t1);
return((C_truep(t2)?(C_word)C_u_i_char_downcase(t1):(C_word)C_u_i_char_upcase(t1)));}

/* string->sre in k4888 */
static void C_ccall f_6282(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6282r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6282r(t0,t1,t2,t3);}}

static void C_ccall f_6282r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6289,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* symbol-list->flags */
f_6182(t5,t3);}

/* k6287 in string->sre in k4888 */
static void C_ccall f_6289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6289,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6294,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6294(t5,((C_word*)t0)[2],C_fix(0),C_fix(0),t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* lp in k6287 in string->sre in k4888 */
static void C_fcall f_6294(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word t180;
C_word t181;
C_word t182;
C_word t183;
C_word t184;
C_word t185;
C_word t186;
C_word t187;
C_word t188;
C_word t189;
C_word t190;
C_word t191;
C_word t192;
C_word t193;
C_word t194;
C_word t195;
C_word t196;
C_word t197;
C_word t198;
C_word t199;
C_word t200;
C_word t201;
C_word t202;
C_word t203;
C_word t204;
C_word t205;
C_word t206;
C_word t207;
C_word t208;
C_word t209;
C_word t210;
C_word t211;
C_word t212;
C_word t213;
C_word t214;
C_word t215;
C_word t216;
C_word t217;
C_word t218;
C_word t219;
C_word *a;
loop:
a=C_alloc(78);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6294,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6297,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6327,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6347,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t5,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6367,a[2]=t4,a[3]=t2,a[4]=t7,a[5]=((C_word*)t0)[4],a[6]=t8,a[7]=t5,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6439,a[2]=t9,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6739,a[2]=t9,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[3]))){
if(C_truep((C_word)C_i_pairp(t6))){
/* error */
t13=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[87],((C_word*)t0)[4]);}
else{
/* collect/terms580 */
t13=t11;
f_6439(t13,t1);}}
else{
t13=(C_word)C_subchar(((C_word*)t0)[4],t2);
switch(t13){
case C_make_character(46):
t14=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t15=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6804,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=t15,a[6]=t14,a[7]=t1,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* flag-set? */
f_6144(t16,t4,C_fix(8));
case C_make_character(63):
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6813,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* collect/single579 */
t15=t10;
f_6367(t15,t14);
default:
t14=(C_word)C_eqp(t13,C_make_character(43));
t15=(C_truep(t14)?t14:(C_word)C_eqp(t13,C_make_character(42)));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7010,a[2]=t13,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* collect/single579 */
t17=t10;
f_6367(t17,t16);}
else{
switch(t13){
case C_make_character(40):
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
if(C_truep((C_word)C_i_greater_or_equalp(t16,((C_word*)t0)[3]))){
/* error */
t17=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t1,lf[105],((C_word*)t0)[4]);}
else{
t17=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t18=(C_word)C_subchar(((C_word*)t0)[4],t17);
t19=(C_word)C_eqp(C_make_character(63),t18);
if(C_truep(t19)){
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
if(C_truep((C_word)C_i_greater_or_equalp(t20,((C_word*)t0)[3]))){
/* error */
t21=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t1,lf[106],((C_word*)t0)[4]);}
else{
t21=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t22=(C_word)C_subchar(((C_word*)t0)[4],t21);
switch(t22){
case C_make_character(35):
t23=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7122,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
/* string-scan-char */
f_5325(t23,((C_word*)t0)[4],C_make_character(41),(C_word)C_a_i_list(&a,1,t24));
case C_make_character(58):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7162,a[2]=t12,a[3]=t24,a[4]=t23,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t26=lf[55];
f_6163(4,t26,t25,t4,C_fix(1));
case C_make_character(61):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7187,a[2]=t12,a[3]=t24,a[4]=t23,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t26=lf[55];
f_6163(4,t26,t25,t4,C_fix(1));
case C_make_character(33):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7212,a[2]=t12,a[3]=t24,a[4]=t23,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t26=lf[55];
f_6163(4,t26,t25,t4,C_fix(1));
case C_make_character(60):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
if(C_truep((C_word)C_i_greater_or_equalp(t23,((C_word*)t0)[3]))){
/* error */
t24=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t24+1)))(4,t24,t1,lf[109],((C_word*)t0)[4]);}
else{
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(C_word)C_subchar(((C_word*)t0)[4],t24);
switch(t25){
case C_make_character(61):
t26=(C_word)C_a_i_plus(&a,2,t2,C_fix(4));
t27=(C_word)C_a_i_plus(&a,2,t2,C_fix(4));
t28=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7255,a[2]=t12,a[3]=t27,a[4]=t26,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t29=lf[55];
f_6163(4,t29,t28,t4,C_fix(1));
case C_make_character(33):
t26=(C_word)C_a_i_plus(&a,2,t2,C_fix(4));
t27=(C_word)C_a_i_plus(&a,2,t2,C_fix(4));
t28=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7280,a[2]=t12,a[3]=t27,a[4]=t26,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t29=lf[55];
f_6163(4,t29,t28,t4,C_fix(1));
default:
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7287,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t27=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t28=(C_word)C_subchar(((C_word*)t0)[4],t27);
if(C_truep((C_word)C_u_i_char_alphabeticp(t28))){
t29=(C_word)C_a_i_plus(&a,2,t2,C_fix(4));
/* string-scan-char */
f_5325(t26,((C_word*)t0)[4],C_make_character(62),(C_word)C_a_i_list(&a,1,t29));}
else{
t29=t26;
f_7287(2,t29,C_SCHEME_FALSE);}}}
case C_make_character(62):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7379,a[2]=t12,a[3]=t24,a[4]=t23,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t26=lf[55];
f_6163(4,t26,t25,t4,C_fix(1));
case C_make_character(40):
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
if(C_truep((C_word)C_i_greater_or_equalp(t23,((C_word*)t0)[3]))){
/* error */
t24=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t24+1)))(4,t24,t1,lf[114],((C_word*)t0)[4]);}
else{
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t25=(C_word)C_subchar(((C_word*)t0)[4],t24);
if(C_truep((C_word)C_u_i_char_numericp(t25))){
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7407,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t27=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
/* string-scan-char */
f_5325(t26,((C_word*)t0)[4],C_make_character(41),(C_word)C_a_i_list(&a,1,t27));}
else{
t26=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
t27=(C_word)C_subchar(((C_word*)t0)[4],t26);
if(C_truep((C_word)C_u_i_char_alphabeticp(t27))){
t28=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7467,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t29=(C_word)C_a_i_plus(&a,2,t2,C_fix(3));
/* string-scan-char */
f_5325(t28,((C_word*)t0)[4],C_make_character(41),(C_word)C_a_i_list(&a,1,t29));}
else{
t28=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t29=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t30=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7524,a[2]=t12,a[3]=t29,a[4]=t28,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-clear */
t31=lf[55];
f_6163(4,t31,t30,t4,C_fix(1));}}}
case C_make_character(123):
/* error */
t23=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t1,lf[117],((C_word*)t0)[4]);
default:
t23=t4;
t24=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7566,a[2]=t9,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t26,a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[3],a[9]=t23,tmp=(C_word)a,a+=10,tmp));
t28=((C_word*)t26)[1];
f_7566(t28,t1,t24,t4,C_SCHEME_FALSE);}}}
else{
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t21=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7097,a[2]=t12,a[3]=t21,a[4]=t20,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* flag-join */
t23=lf[54];
f_6154(4,t23,t22,t4,C_fix(1));}}
case C_make_character(41):
if(C_truep((C_word)C_i_nullp(t6))){
/* error */
t16=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,lf[122],((C_word*)t0)[4]);}
else{
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t17=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t18=(C_word)C_u_i_caar(t6);
t19=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7832,a[2]=t18,a[3]=t17,a[4]=t16,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* collect/terms580 */
t20=t11;
f_6439(t20,t19);}
case C_make_character(91):
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7847,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7871,a[2]=t16,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t18=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t19=((C_word*)t0)[4];
t20=t4;
t21=(C_word)C_fix((C_word)C_header_size(t19));
t22=(C_word)C_subchar(t19,t18);
t23=(C_word)C_eqp(C_make_character(94),t22);
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9344,a[2]=t17,a[3]=t18,a[4]=t20,a[5]=t23,a[6]=t19,a[7]=t21,tmp=(C_word)a,a+=8,tmp);
/* flag-set? */
f_6144(t24,t20,C_fix(32));
case C_make_character(123):
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t17=(C_word)C_i_greater_or_equalp(t16,((C_word*)t0)[3]);
t18=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7890,a[2]=t10,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[2],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t17)){
t19=t18;
f_7890(t19,t17);}
else{
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t20=(C_word)C_subchar(((C_word*)t0)[4],t19);
t21=(C_word)C_u_i_char_numericp(t20);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8071,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t21)){
t23=t22;
f_8071(t23,t21);}
else{
t23=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t24=(C_word)C_subchar(((C_word*)t0)[4],t23);
t25=t22;
f_8071(t25,(C_word)C_eqp(C_make_character(44),t24));}}
case C_make_character(92):
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
if(C_truep((C_word)C_i_greater_or_equalp(t16,((C_word*)t0)[3]))){
/* error */
t17=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t1,lf[141],((C_word*)t0)[4]);}
else{
t17=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t18=(C_word)C_subchar(((C_word*)t0)[4],t17);
switch(t18){
case C_make_character(100):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8137,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8141,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6347(t23,t22);
case C_make_character(68):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,lf[142],C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[124],t21);
t23=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8170,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t22,tmp=(C_word)a,a+=9,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8174,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t25=t9;
f_6347(t25,t24);
case C_make_character(115):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8203,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8207,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6347(t23,t22);
case C_make_character(83):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,lf[143],C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[124],t21);
t23=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8236,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t22,tmp=(C_word)a,a+=9,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8240,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t25=t9;
f_6347(t25,t24);
case C_make_character(119):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,lf[144],C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,t21,C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[145],t22);
t24=(C_word)C_a_i_cons(&a,2,lf[70],t23);
t25=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8273,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t24,tmp=(C_word)a,a+=9,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8277,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t27=t9;
f_6347(t27,t26);
case C_make_character(87):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,lf[146],C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,t21,C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[145],t22);
t24=(C_word)C_a_i_cons(&a,2,lf[70],t23);
t25=(C_word)C_a_i_cons(&a,2,t24,C_SCHEME_END_OF_LIST);
t26=(C_word)C_a_i_cons(&a,2,lf[124],t25);
t27=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8318,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t26,tmp=(C_word)a,a+=9,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8322,a[2]=t27,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t29=t9;
f_6347(t29,t28);
case C_make_character(98):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,lf[147],C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[148],t21);
t23=(C_word)C_a_i_cons(&a,2,lf[70],t22);
t24=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8371,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t23,tmp=(C_word)a,a+=9,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8375,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t26=t9;
f_6347(t26,t25);
case C_make_character(66):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8408,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8412,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6347(t23,t22);
case C_make_character(65):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8437,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8441,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6347(t23,t22);
case C_make_character(90):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_cons(&a,2,C_make_character(10),C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[95],t21);
t23=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8474,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t22,tmp=(C_word)a,a+=9,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8478,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t25=t9;
f_6347(t25,t24);
case C_make_character(122):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8507,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8511,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6347(t23,t22);
case C_make_character(82):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8536,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8540,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6347(t23,t22);
case C_make_character(75):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8565,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8569,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6347(t23,t22);
case C_make_character(60):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8594,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8598,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6347(t23,t22);
case C_make_character(62):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8623,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8627,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t23=t9;
f_6347(t23,t22);
case C_make_character(120):
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8638,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8666,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
/* string-parse-hex-escape */
f_9233(t20,((C_word*)t0)[4],t21,((C_word*)t0)[3]);
case C_make_character(107):
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_subchar(((C_word*)t0)[4],t19);
if(C_truep((C_truep((C_word)C_i_eqvp(t20,C_make_character(60)))?C_SCHEME_TRUE:(C_truep((C_word)C_i_eqvp(t20,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_i_eqvp(t20,C_make_character(39)))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t21=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8691,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t9,a[5]=t6,a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
switch(t20){
case C_make_character(60):
t22=t21;
f_8691(t22,C_make_character(62));
case C_make_character(123):
t22=t21;
f_8691(t22,C_make_character(125));
case C_make_character(40):
t22=t21;
f_8691(t22,C_make_character(41));
default:
t22=(C_word)C_eqp(t20,C_make_character(91));
t23=t21;
f_8691(t23,(C_truep(t22)?C_make_character(93):t20));}}
else{
/* error */
t21=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t1,lf[157],((C_word*)t0)[4]);}
case C_make_character(81):
t19=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8775,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t4,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect578 */
t20=t9;
f_6347(t20,t19);
default:
if(C_truep((C_word)C_u_i_char_numericp(t18))){
t19=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8889,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t9,a[5]=t6,a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=((C_word*)t0)[4];
t22=(C_word)C_a_i_list(&a,1,t20);
t23=(C_word)C_fix((C_word)C_header_size(t21));
t24=(C_word)C_i_pairp(t22);
t25=(C_truep(t24)?(C_word)C_u_i_car(t22):C_fix(0));
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5441,a[2]=t27,a[3]=t21,a[4]=t23,tmp=(C_word)a,a+=5,tmp));
t29=((C_word*)t27)[1];
f_5441(t29,t19,t25);}
else{
if(C_truep((C_word)C_u_i_char_alphabeticp(t18))){
t19=(C_word)C_i_assv(t18,lf[131]);
if(C_truep(t19)){
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t21=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t22=(C_word)C_slot(t19,C_fix(1));
t23=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8981,a[2]=t6,a[3]=t4,a[4]=t21,a[5]=t20,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t22,tmp=(C_word)a,a+=9,tmp);
/* collect578 */
t24=t9;
f_6347(t24,t23);}
else{
/* error */
t20=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t20+1)))(5,t20,t1,lf[158],((C_word*)t0)[4],t18);}}
else{
t19=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t20=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8999,a[2]=t6,a[3]=t4,a[4]=t20,a[5]=t19,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* collect578 */
t22=t9;
f_6347(t22,t21);}}}}
case C_make_character(124):
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t17=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9032,a[2]=t6,a[3]=t4,a[4]=t17,a[5]=t16,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* collect578 */
t19=t9;
f_6347(t19,t18);
case C_make_character(94):
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9063,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* flag-set? */
f_6144(t16,t4,C_fix(4));
case C_make_character(36):
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9094,a[2]=t9,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* flag-set? */
f_6144(t16,t4,C_fix(4));
case C_make_character(32):
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9106,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t6,a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* flag-set? */
f_6144(t16,t4,C_fix(16));
case C_make_character(35):
t16=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9140,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t9,a[7]=t6,a[8]=t4,a[9]=t1,a[10]=((C_word*)t0)[2],a[11]=((C_word*)t0)[3],tmp=(C_word)a,a+=12,tmp);
/* flag-set? */
f_6144(t16,t4,C_fix(16));
default:
t16=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* lp569 */
t214=t1;
t215=t16;
t216=t3;
t217=t4;
t218=t5;
t219=t6;
t1=t214;
t2=t215;
t3=t216;
t4=t217;
t5=t218;
t6=t219;
goto loop;}}}}}

/* k9138 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9140,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9143,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
/* string-scan-char */
f_5325(t2,((C_word*)t0)[4],C_make_character(10),(C_word)C_a_i_list(&a,1,t3));}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
/* lp569 */
t3=((C_word*)((C_word*)t0)[10])[1];
f_6294(t3,((C_word*)t0)[9],t2,((C_word*)t0)[3],((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k9141 in k9138 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9143,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_a_i_minus(&a,2,((C_word*)t0)[7],C_fix(1)));
t3=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9161,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* collect578 */
t6=((C_word*)t0)[2];
f_6347(t6,t5);}

/* k9159 in k9141 in k9138 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6294(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9104 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9106,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9121,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* collect578 */
t5=((C_word*)t0)[4];
f_6347(t5,t4);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
/* lp569 */
t3=((C_word*)((C_word*)t0)[8])[1];
f_6294(t3,((C_word*)t0)[7],t2,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k9119 in k9104 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6294(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9092 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9094,2,t0,t1);}
t2=(C_truep(t1)?lf[160]:lf[151]);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9091,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect578 */
t6=((C_word*)t0)[2];
f_6347(t6,t5);}

/* k9089 in k9092 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9091,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k9061 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9063,2,t0,t1);}
t2=(C_truep(t1)?lf[159]:lf[150]);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9060,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect578 */
t6=((C_word*)t0)[2];
f_6347(t6,t5);}

/* k9058 in k9061 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9060,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k9030 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9032,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[70],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8997 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6294(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8979 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8981,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* scan in lp in k6287 in string->sre in k4888 */
static void C_fcall f_5441(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5441,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_word)C_u_i_char_numericp(t3))){
t4=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* scan226 */
t6=t1;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}}

/* k8887 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8889,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* flag-set? */
f_6144(t3,((C_word*)t0)[6],C_fix(2));}

/* k8930 in k8887 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8932,2,t0,t1);}
t2=(C_truep(t1)?lf[154]:lf[155]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8921,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8925,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* substring */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[2],t5,((C_word*)t0)[7]);}

/* k8923 in k8930 in k8887 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k8919 in k8930 in k8887 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8921,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8909,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8913,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t6=((C_word*)t0)[2];
f_6347(t6,t5);}

/* k8911 in k8919 in k8930 in k8887 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8907 in k8919 in k8930 in k8887 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8909,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_6294(t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8773 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8775,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8784,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_8784(t6,((C_word*)t0)[2],t2);}

/* lp2 in k8773 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_8784(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(29);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8784,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[9]))){
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(2));
/* lp569 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_6294(t4,t1,t2,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(C_make_character(92),t3);
if(C_truep(t4)){
t5=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
if(C_truep((C_word)C_i_greater_or_equalp(t5,((C_word*)t0)[9]))){
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(2));
/* lp569 */
t8=((C_word*)((C_word*)t0)[7])[1];
f_6294(t8,t1,t6,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_subchar(((C_word*)t0)[3],t6);
t8=(C_word)C_eqp(C_make_character(69),t7);
if(C_truep(t8)){
t9=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t10=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8846,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t10,a[5]=t9,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t12=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(2));
/* substring */
t13=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t11,((C_word*)t0)[3],t12,t2);}
else{
t9=(C_word)C_a_i_plus(&a,2,t2,C_fix(2));
/* lp21014 */
t19=t1;
t20=t9;
t1=t19;
t2=t20;
goto loop;}}}
else{
t5=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* lp21014 */
t19=t1;
t20=t5;
t1=t19;
t2=t20;
goto loop;}}}

/* k8844 in lp2 in k8773 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8846,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[8]);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8689 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_8691(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8691,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(2));
/* string-scan-char */
f_5325(t2,((C_word*)t0)[3],t1,(C_word)C_a_i_list(&a,1,t3));}

/* k8692 in k8689 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8697,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(3));
/* substring */
t4=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[3],t3,t1);}
else{
t3=t2;
f_8697(2,t3,C_SCHEME_FALSE);}}

/* k8695 in k8692 in k8689 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8747,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* flag-set? */
f_6144(t2,((C_word*)t0)[5],C_fix(2));}

/* k8745 in k8695 in k8692 in k8689 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8747,2,t0,t1);}
t2=(C_truep(t1)?lf[154]:lf[155]);
t3=((C_word*)t0)[9];
if(C_truep(t3)){
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8744,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* string->symbol */
t7=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[3]);}
else{
/* error */
t4=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[7],lf[156],((C_word*)t0)[2]);}}

/* k8742 in k8745 in k8695 in k8692 in k8689 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8744,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8732,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8736,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t6=((C_word*)t0)[2];
f_6347(t6,t5);}

/* k8734 in k8742 in k8745 in k8695 in k8692 in k8689 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8730 in k8742 in k8745 in k8695 in k8692 in k8689 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8732,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8664 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8637 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8638,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t5=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8658,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8662,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* collect578 */
t8=((C_word*)t0)[2];
f_6347(t8,t7);}

/* k8660 in a8637 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8656 in a8637 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8658,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8625 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8621 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8623,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[147],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8596 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8592 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8594,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[148],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8567 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8563 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8565,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[153],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8538 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8534 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8536,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[152],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8509 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8505 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8507,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[151],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8476 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8472 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8474,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[151],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
/* lp569 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_6294(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k8439 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8435 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8437,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[150],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8410 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8406 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8408,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[149],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8373 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8369 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8371,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8320 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8316 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8318,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8275 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8271 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8273,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8238 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8234 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8236,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8205 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8201 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8203,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[143],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8172 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8168 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8170,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8139 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8135 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8137,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[142],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8069 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_8071(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7890(t2,(C_word)C_i_not(t1));}

/* k7888 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_7890(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7890,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[10],C_fix(1));
/* lp569 */
t3=((C_word*)((C_word*)t0)[9])[1];
f_6294(t3,((C_word*)t0)[8],t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7900,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* collect/single579 */
t3=((C_word*)t0)[2];
f_6367(t3,t2);}}

/* k7898 in k7888 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7900,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_slot(t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* string-scan-char */
f_5325(t4,((C_word*)t0)[2],C_make_character(125),(C_word)C_a_i_list(&a,1,t5));}

/* k7907 in k7898 in k7888 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7912,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8053,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* substring */
t5=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[2],t4,t1);}

/* k8051 in k7907 in k7898 in k7888 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8053,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(t1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5482,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5482(t6,((C_word*)t0)[2],C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* lp in k8051 in k7907 in k7898 in k7888 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_5482(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(20);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5482,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5485,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[3]))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5506,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* collect257 */
t7=t5;
f_5485(t7,t6);}
else{
t6=(C_word)C_subchar(((C_word*)t0)[4],t2);
t7=(C_word)C_eqp(C_make_character(44),t6);
if(C_truep(t7)){
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5527,a[2]=t9,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* collect257 */
t11=t5;
f_5485(t11,t10);}
else{
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* lp245 */
t14=t1;
t15=t8;
t16=t3;
t17=t4;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}}}

/* k5525 in lp in k8051 in k7907 in k7898 in k7888 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_5527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp245 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5482(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5504 in lp in k8051 in k7907 in k7898 in k7888 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* reverse */
t2=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* collect in lp in k8051 in k7907 in k7898 in k7888 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_5485(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5485,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5493,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* substring */
t3=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5491 in collect in lp in k8051 in k7907 in k7898 in k7888 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5493,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7910 in k7907 in k7898 in k7888 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_car(t1);
/* string->number */
C_string_to_number(3,0,t2,t3);}

/* k7913 in k7910 in k7907 in k7898 in k7888 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7915,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
/* string->number */
C_string_to_number(3,0,t3,t5);}
else{
t5=t3;
f_7921(2,t5,C_SCHEME_FALSE);}}

/* k7919 in k7913 in k7910 in k7907 in k7898 in k7888 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7921,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[98],t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7950,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t9=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
if(C_truep(t1)){
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[97],t7);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7984,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t10=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[99],t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8019,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t9=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}}

/* k8017 in k7919 in k7913 in k7910 in k7907 in k7898 in k7888 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_8019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8019,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7982 in k7919 in k7913 in k7910 in k7907 in k7898 in k7888 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7984,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7948 in k7919 in k7913 in k7910 in k7907 in k7898 in k7888 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7950,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9344,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9346,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
if(C_truep(((C_word*)t0)[5])){
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10016,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6144(t6,((C_word*)t0)[4],C_fix(4));}
else{
/* go1134 */
t5=((C_word*)t3)[1];
f_9346(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* k10014 in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_10016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[140]:C_SCHEME_END_OF_LIST);
/* go1134 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9346(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_9346(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word *a;
loop:
a=C_alloc(24);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9346,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[8]))){
/* error */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[123]);}
else{
t5=(C_word)C_subchar(((C_word*)t0)[7],t2);
switch(t5){
case C_make_character(93):
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(C_word)C_a_i_cons(&a,2,C_make_character(93),t3);
/* go1134 */
t39=t1;
t40=t8;
t41=t9;
t42=t4;
t1=t39;
t2=t40;
t3=t41;
t4=t42;
goto loop;}
else{
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9385,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* flag-set? */
f_6144(t8,((C_word*)t0)[3],C_fix(2));}
case C_make_character(45):
t6=(C_word)C_i_nequalp(t2,((C_word*)t0)[2]);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9496,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t5,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t6)){
t8=t7;
f_9496(t8,t6);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9648,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_i_nequalp(t2,t9))){
t10=(C_word)C_subchar(((C_word*)t0)[7],((C_word*)t0)[2]);
t11=t8;
f_9648(t11,(C_word)C_eqp(C_make_character(94),t10));}
else{
t10=t8;
f_9648(t10,C_SCHEME_FALSE);}}
case C_make_character(91):
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_subchar(((C_word*)t0)[7],t6);
t8=(C_word)C_eqp(C_make_character(94),t7);
t9=(C_truep(t8)?(C_word)C_a_i_plus(&a,2,t2,C_fix(2)):(C_word)C_a_i_plus(&a,2,t2,C_fix(1)));
t10=(C_word)C_subchar(((C_word*)t0)[7],t9);
t11=(C_word)C_eqp(t10,C_make_character(58));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9700,a[2]=t9,a[3]=t8,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t13=(C_word)C_a_i_plus(&a,2,t9,C_fix(1));
/* string-scan-char */
f_5325(t12,((C_word*)t0)[7],C_make_character(58),(C_word)C_a_i_list(&a,1,t13));}
else{
t12=(C_word)C_eqp(t10,C_make_character(61));
t13=(C_truep(t12)?t12:(C_word)C_eqp(t10,C_make_character(46)));
if(C_truep(t13)){
/* error */
t14=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[139],((C_word*)t0)[7]);}
else{
t14=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t15=(C_word)C_a_i_cons(&a,2,C_make_character(91),t3);
/* go1134 */
t39=t1;
t40=t14;
t41=t15;
t42=t4;
t1=t39;
t2=t40;
t3=t41;
t4=t42;
goto loop;}}
case C_make_character(92):
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_subchar(((C_word*)t0)[7],t6);
t8=(C_word)C_eqp(t7,C_make_character(100));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9833,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],a[4]=t7,a[5]=t3,a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t8)){
t10=t9;
f_9833(t10,t8);}
else{
t10=(C_word)C_eqp(t7,C_make_character(68));
if(C_truep(t10)){
t11=t9;
f_9833(t11,t10);}
else{
t11=(C_word)C_eqp(t7,C_make_character(115));
if(C_truep(t11)){
t12=t9;
f_9833(t12,t11);}
else{
t12=(C_word)C_eqp(t7,C_make_character(83));
if(C_truep(t12)){
t13=t9;
f_9833(t13,t12);}
else{
t13=(C_word)C_eqp(t7,C_make_character(119));
t14=t9;
f_9833(t14,(C_truep(t13)?t13:(C_word)C_eqp(t7,C_make_character(87))));}}}}
default:
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9963,a[2]=((C_word*)t0)[7],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[4])){
t7=(C_word)C_fix((C_word)C_character_code(t5));
/* <= */
C_less_or_equal_p(5,0,t6,C_fix(128),t7,C_fix(255));}
else{
t7=t6;
f_9963(2,t7,C_SCHEME_FALSE);}}}}

/* k9961 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9963,2,t0,t1);}
if(C_truep(t1)){
t2=f_10035(((C_word*)t0)[8]);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9981,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* utf8-string-ref */
f_10045(t4,((C_word*)t0)[2],((C_word*)t0)[7],t2);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[6]);
/* go1134 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_9346(t4,((C_word*)t0)[4],t2,t3,((C_word*)t0)[3]);}}

/* k9979 in k9961 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9981,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* go1134 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9346(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k9831 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_9833(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9833,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9836,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9863,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_string(&a,2,C_make_character(92),((C_word*)t0)[4]);
/* string->sre */
t5=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],C_make_character(120));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9878,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9890,a[2]=t3,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(2));
/* string-parse-hex-escape */
f_9233(t4,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}
else{
t3=(C_word)C_i_assv(((C_word*)t0)[4],lf[131]);
t4=(C_truep(t3)?(C_word)C_slot(t3,C_fix(1)):((C_word*)t0)[4]);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(2));
t6=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[9],C_fix(1));
t7=(C_word)C_subchar(((C_word*)t0)[3],t6);
t8=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
/* go1134 */
t10=((C_word*)((C_word*)t0)[8])[1];
f_9346(t10,((C_word*)t0)[7],t5,t9,((C_word*)t0)[6]);}}}

/* k9888 in k9831 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9877 in k9831 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9878,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
/* go1134 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_9346(t5,t1,t3,t4,((C_word*)t0)[2]);}

/* k9861 in k9831 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre->cset */
f_18830(((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k9834 in k9831 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9836,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9847,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9859,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* filter */
f_5938(t4,*((C_word*)lf[136]+1),t1);}

/* k9857 in k9834 in k9831 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9845 in k9834 in k9831 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9851,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9855,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* filter */
f_5938(t3,*((C_word*)lf[135]+1),((C_word*)t0)[2]);}

/* k9853 in k9845 in k9834 in k9831 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9849 in k9845 in k9834 in k9831 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* go1134 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_9346(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9698 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9700,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
t4=t3;
f_9709(t4,t2);}
else{
t4=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
t5=(C_word)C_subchar(((C_word*)t0)[7],t4);
t6=(C_word)C_eqp(C_make_character(93),t5);
t7=t3;
f_9709(t7,(C_word)C_i_not(t6));}}

/* k9707 in k9698 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_9709(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9709,NULL,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[9],lf[134],((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9715,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9748,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9752,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
/* substring */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[8],t5,((C_word*)t0)[7]);}}

/* k9750 in k9707 in k9698 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9746 in k9707 in k9698 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre->cset */
f_18830(((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k9713 in k9707 in k9698 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9718,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
/* cset-complement */
f_19632(t2,t1);}
else{
t3=t2;
f_9718(2,t3,t1);}}

/* k9716 in k9713 in k9707 in k9698 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9718,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9729,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9741,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* filter */
f_5938(t4,*((C_word*)lf[136]+1),t1);}

/* k9739 in k9716 in k9713 in k9707 in k9698 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9727 in k9716 in k9713 in k9707 in k9698 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9733,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9737,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* filter */
f_5938(t3,*((C_word*)lf[135]+1),((C_word*)t0)[2]);}

/* k9735 in k9727 in k9716 in k9713 in k9707 in k9698 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9731 in k9727 in k9716 in k9713 in k9707 in k9698 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* go1134 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_9346(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9646 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_9648(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9648,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_9496(t2,t1);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_subchar(((C_word*)t0)[2],t2);
t4=((C_word*)t0)[4];
f_9496(t4,(C_word)C_eqp(C_make_character(93),t3));}}

/* k9494 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_9496(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9496,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
/* go1134 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_9346(t4,((C_word*)t0)[6],t2,t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[8]))){
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[6],lf[129]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[8]);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[10],C_fix(1));
t4=(C_word)C_subchar(((C_word*)t0)[4],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9527,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(C_make_character(92),t4);
t7=(C_truep(t6)?(C_word)C_i_assv(t4,lf[131]):C_SCHEME_FALSE);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9559,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
t9=(C_word)C_slot(t7,C_fix(1));
t10=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[10],C_fix(3));
t11=t8;
f_9559(2,t11,(C_word)C_a_i_list(&a,2,t9,t10));}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9576,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t8,a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_eqp(C_make_character(92),t4);
if(C_truep(t10)){
t11=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[10],C_fix(2));
t12=(C_word)C_subchar(((C_word*)t0)[4],t11);
t13=t9;
f_9576(t13,(C_word)C_eqp(t12,C_make_character(120)));}
else{
t11=t9;
f_9576(t11,C_SCHEME_FALSE);}}}}}

/* k9574 in k9494 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_9576(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9576,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(3));
/* string-parse-hex-escape */
f_9233(((C_word*)t0)[6],((C_word*)t0)[5],t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9589,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[3]));
/* <= */
C_less_or_equal_p(5,0,t2,C_fix(128),t3,C_fix(255));}
else{
t3=t2;
f_9589(2,t3,C_SCHEME_FALSE);}}}

/* k9587 in k9574 in k9494 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9589,2,t0,t1);}
if(C_truep(t1)){
t2=f_10035(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9599,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* utf8-string-ref */
f_10045(t3,((C_word*)t0)[2],t4,t2);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(2));
t3=((C_word*)t0)[4];
f_9559(2,t3,(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t2));}}

/* k9597 in k9587 in k9574 in k9494 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9603,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* + */
C_plus(5,0,t2,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}

/* k9601 in k9597 in k9587 in k9574 in k9494 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9603,2,t0,t1);}
t2=((C_word*)t0)[3];
f_9559(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k9557 in k9494 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9526 in k9494 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9527,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[5]))){
/* error */
t4=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[130],((C_word*)t0)[5],t2);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
/* go1134 */
t7=((C_word*)((C_word*)t0)[2])[1];
f_9346(t7,t1,t3,t4,t6);}}

/* k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
/* filter */
f_5938(t2,lf[128],((C_word*)t0)[2]);}
else{
t3=t2;
f_9388(2,t3,C_SCHEME_END_OF_LIST);}}

/* k9386 in k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9391,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5987,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5987(t7,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_9391(2,t3,((C_word*)t0)[2]);}}

/* lp in k9386 in k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_5987(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5987,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6008,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6011,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_car(t2);
/* pred446 */
t8=lf[128];
f_10025(3,t8,t6,t7);}}

/* k6009 in lp in k9386 in k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6011,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6008(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_6008(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k6006 in lp in k9386 in k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_6008(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp449 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5987(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9389 in k9386 in k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9398,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9456,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9460,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9464,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* reverse */
t7=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t1);}
else{
t4=t3;
f_9411(t4,C_SCHEME_END_OF_LIST);}}

/* k9462 in k9389 in k9386 in k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9464,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[3])?lf[126]:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9468,tmp=(C_word)a,a+=2,tmp));
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t1);}

/* f_9468 in k9462 in k9389 in k9386 in k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9468,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9458 in k9389 in k9386 in k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9454 in k9389 in k9386 in k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9456,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
f_9411(t3,(C_word)C_a_i_list(&a,1,t2));}

/* k9409 in k9389 in k9386 in k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_9411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9411,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9415,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9421,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9439,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t5=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}
else{
/* reverse */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}}
else{
t3=t2;
f_9415(t3,C_SCHEME_END_OF_LIST);}}

/* k9437 in k9409 in k9389 in k9386 in k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-case-insensitive */
t2=lf[126];
f_19642(3,t2,((C_word*)t0)[2],t1);}

/* k9419 in k9409 in k9389 in k9386 in k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9432,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18795,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_18795(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* lp in k9419 in k9409 in k9389 in k9386 in k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_18795(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_18795,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_cdar(t2);
t6=(C_word)C_u_i_caar(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
t8=(C_word)C_a_i_cons(&a,2,t5,t7);
/* lp3803 */
t10=t1;
t11=t4;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k9430 in k9419 in k9409 in k9389 in k9386 in k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9432,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[31],t1);
t3=((C_word*)t0)[2];
f_9415(t3,(C_word)C_a_i_list(&a,1,t2));}

/* k9413 in k9409 in k9389 in k9386 in k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_9415(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[125]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9396 in k9389 in k9386 in k9383 in go in k9342 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_9398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9398,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_a_i_cons(&a,2,lf[124],t1):f_13504(C_a_i(&a,3),t1));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}

/* k7869 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7846 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7847,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t5=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect578 */
t7=((C_word*)t0)[2];
f_6347(t7,t6);}

/* k7865 in a7846 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7867,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7830 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7832,2,t0,t1);}
t2=(C_word)C_u_i_cdar(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* lp569 */
t5=((C_word*)((C_word*)t0)[6])[1];
f_6294(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t4);}

/* k7095 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7101,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save581 */
t3=((C_word*)t0)[2];
f_6739(t3,t2);}

/* k7099 in k7095 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6294(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* lp2 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_7566(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
loop:
a=C_alloc(28);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7566,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7569,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7578,a[2]=((C_word*)t0)[9],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[8]))){
/* error */
t7=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[120],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t7=(C_word)C_subchar(((C_word*)t0)[7],t2);
switch(t7){
case C_make_character(105):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7627,a[2]=t4,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* join832 */
t10=t5;
f_7569(t10,t9,C_fix(2));
case C_make_character(109):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7644,a[2]=t4,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* join832 */
t10=t5;
f_7569(t10,t9,C_fix(4));
case C_make_character(120):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7661,a[2]=t4,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* join832 */
t10=t5;
f_7569(t10,t9,C_fix(16));
case C_make_character(117):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7681,a[2]=t4,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* join832 */
t10=t5;
f_7569(t10,t9,C_fix(32));
case C_make_character(45):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(C_word)C_i_not(t4);
/* lp2820 */
t26=t1;
t27=t8;
t28=t3;
t29=t9;
t1=t26;
t2=t27;
t3=t28;
t4=t29;
goto loop;
case C_make_character(41):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7726,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t9,a[5]=t8,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7730,a[2]=t10,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* collect578 */
t12=((C_word*)t0)[2];
f_6347(t12,t11);
case C_make_character(58):
t8=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t9=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7751,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t9,a[5]=t8,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* new-res833 */
t11=t6;
f_7578(t11,t10,C_SCHEME_END_OF_LIST);
default:
/* error */
t8=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,lf[121],((C_word*)t0)[7]);}}}

/* k7749 in lp2 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7763,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* collect578 */
t3=((C_word*)t0)[2];
f_6347(t3,t2);}

/* k7761 in k7749 in lp2 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7763,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
/* lp569 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_6294(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k7728 in lp2 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* new-res833 */
t2=((C_word*)t0)[3];
f_7578(t2,((C_word*)t0)[2],t1);}

/* k7724 in lp2 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6294(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7679 in lp2 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2820 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7566(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7659 in lp2 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2820 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7566(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7642 in lp2 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2820 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7566(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7625 in lp2 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2820 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7566(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* new-res in lp2 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_7578(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7578,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7582,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6144(t3,((C_word*)t0)[2],C_fix(32));}

/* k7580 in new-res in lp2 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7585,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6144(t2,((C_word*)t0)[2],C_fix(32));}

/* k7583 in k7580 in new-res in lp2 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7585,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
t3=(C_truep(t1)?lf[118]:lf[119]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]));}}

/* join in lp2 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_7569(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7569,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[3])?lf[55]:lf[54]);
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[2],t2);}

/* k7522 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7528,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save581 */
t3=((C_word*)t0)[2];
f_6739(t3,t2);}

/* k7526 in k7522 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6294(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[116],t1);}

/* k7465 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7470,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7501,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(3));
/* substring */
t5=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[2],t4,t1);}

/* k7499 in k7465 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7468 in k7465 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7470,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7485,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* flag-clear */
t5=lf[55];
f_6163(4,t5,t4,((C_word*)t0)[2],C_fix(1));}

/* k7483 in k7468 in k7465 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7485,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[77],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7493,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* save581 */
t5=((C_word*)t0)[2];
f_6739(t5,t4);}

/* k7491 in k7483 in k7468 in k7465 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6294(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7405 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7450,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(3));
/* substring */
t5=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[3],t4,t1);}

/* k7448 in k7405 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k7408 in k7405 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7410,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7434,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* flag-clear */
t6=lf[55];
f_6163(4,t6,t5,((C_word*)t0)[3],C_fix(1));}
else{
/* error */
t3=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],lf[115],((C_word*)t0)[2]);}}

/* k7432 in k7408 in k7405 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7434,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[77],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7442,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* save581 */
t5=((C_word*)t0)[2];
f_6739(t5,t4);}

/* k7440 in k7432 in k7408 in k7405 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6294(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7377 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7383,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save581 */
t3=((C_word*)t0)[2];
f_6739(t3,t2);}

/* k7381 in k7377 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6294(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[113],t1);}

/* k7285 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7287,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7305,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* flag-clear */
t5=lf[55];
f_6163(4,t5,t4,((C_word*)t0)[2],C_fix(1));}
else{
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],lf[112],((C_word*)t0)[3]);}}

/* k7303 in k7285 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7317,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7325,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(3));
/* substring */
t5=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k7323 in k7303 in k7285 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7315 in k7303 in k7285 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7317,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[85],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7313,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* save581 */
t5=((C_word*)t0)[2];
f_6739(t5,t4);}

/* k7311 in k7315 in k7303 in k7285 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6294(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7278 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7284,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save581 */
t3=((C_word*)t0)[2];
f_6739(t3,t2);}

/* k7282 in k7278 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6294(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[111],t1);}

/* k7253 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7259,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save581 */
t3=((C_word*)t0)[2];
f_6739(t3,t2);}

/* k7257 in k7253 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6294(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[110],t1);}

/* k7210 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7216,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save581 */
t3=((C_word*)t0)[2];
f_6739(t3,t2);}

/* k7214 in k7210 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6294(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[108],t1);}

/* k7185 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7191,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save581 */
t3=((C_word*)t0)[2];
f_6739(t3,t2);}

/* k7189 in k7185 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6294(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[107],t1);}

/* k7160 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7166,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save581 */
t3=((C_word*)t0)[2];
f_6739(t3,t2);}

/* k7164 in k7160 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_6294(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* k7120 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7122,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,t1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7137,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* collect578 */
t5=((C_word*)t0)[2];
f_6347(t5,t4);}

/* k7135 in k7120 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp569 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6294(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7008 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7010,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7016,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_a_i_string(&a,1,((C_word*)t0)[2]);
/* string->symbol */
t5=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k7014 in k7008 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7016,2,t0,t1);}
t2=f_12130(((C_word*)t0)[9]);
if(C_truep(t2)){
/* error */
t3=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],lf[101],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* sre-empty? */
t4=lf[103];
f_11926(3,t4,t3,((C_word*)t0)[9]);}}

/* k7029 in k7014 in k7008 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_7031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7031,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[10],lf[102],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
/* lp569 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_6294(t7,((C_word*)t0)[10],t2,t3,((C_word*)t0)[3],t6,((C_word*)t0)[2]);}}

/* k6811 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6813,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* error */
t2=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[7],lf[90],((C_word*)t0)[6],t1);}
else{
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[91]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6867,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t10=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_eqp(t6,lf[93]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6892,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t11=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,C_SCHEME_END_OF_LIST);}
else{
t9=(C_word)C_eqp(t6,lf[95]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6909,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t12=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,C_SCHEME_END_OF_LIST);}
else{
t10=(C_word)C_eqp(t6,lf[97]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6926,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t13=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,C_SCHEME_END_OF_LIST);}
else{
t11=(C_word)C_eqp(t6,lf[98]);
if(C_truep(t11)){
t12=(C_word)C_u_i_cadr(t2);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6951,a[2]=t5,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t15=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(t6,lf[99]);
if(C_truep(t12)){
t13=(C_word)C_u_i_cadr(t2);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6980,a[2]=t5,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_u_i_cddr(t2);
/* ##sys#append */
t16=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t14,t15,C_SCHEME_END_OF_LIST);}
else{
t13=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t14=t5;
f_6844(t14,(C_word)C_a_i_cons(&a,2,lf[95],t13));}}}}}}}
else{
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=t5;
f_6844(t7,(C_word)C_a_i_cons(&a,2,lf[95],t6));}}}

/* k6978 in k6811 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6980,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_6844(t4,(C_word)C_a_i_cons(&a,2,lf[94],t3));}

/* k6949 in k6811 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6951,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_6844(t3,(C_word)C_a_i_cons(&a,2,lf[94],t2));}

/* k6924 in k6811 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6926,2,t0,t1);}
t2=((C_word*)t0)[2];
f_6844(t2,(C_word)C_a_i_cons(&a,2,lf[94],t1));}

/* k6907 in k6811 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6909,2,t0,t1);}
t2=((C_word*)t0)[2];
f_6844(t2,(C_word)C_a_i_cons(&a,2,lf[96],t1));}

/* k6890 in k6811 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6892,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1);
t3=(C_word)C_a_i_cons(&a,2,C_fix(1),t2);
t4=((C_word*)t0)[2];
f_6844(t4,(C_word)C_a_i_cons(&a,2,lf[94],t3));}

/* k6865 in k6811 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6867,2,t0,t1);}
t2=((C_word*)t0)[2];
f_6844(t2,(C_word)C_a_i_cons(&a,2,lf[92],t1));}

/* k6842 in k6811 in lp in k6287 in string->sre in k4888 */
static void C_fcall f_6844(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6844,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* lp569 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_6294(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k6802 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6804,2,t0,t1);}
t2=(C_truep(t1)?lf[88]:lf[89]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6801,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect578 */
t4=((C_word*)t0)[2];
f_6347(t4,t3);}

/* k6799 in k6802 in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6801,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp569 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_6294(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* save in lp in k6287 in string->sre in k4888 */
static void C_fcall f_6739(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6739,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6751,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* collect578 */
t3=((C_word*)t0)[2];
f_6347(t3,t2);}

/* k6749 in save in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6751,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]));}

/* collect/terms in lp in k6287 in string->sre in k4888 */
static void C_fcall f_6439(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6439,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6443,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* collect578 */
t3=((C_word*)t0)[2];
f_6347(t3,t2);}

/* k6441 in collect/terms in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6446,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6737,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* last */
f_5768(t3,t1);}
else{
t3=t2;
f_6446(t3,C_SCHEME_FALSE);}}

/* k6735 in k6441 in collect/terms in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6446(t2,(C_word)C_u_i_memq(t1,lf[86]));}

/* k6444 in k6441 in collect/terms in lp in k6287 in string->sre in k4888 */
static void C_fcall f_6446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6446,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6449,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6699,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t4=(C_word)C_u_i_car(t1);
t5=t3;
f_6699(t5,(C_word)C_eqp(lf[85],t4));}
else{
t4=t3;
f_6699(t4,C_SCHEME_FALSE);}}

/* k6697 in k6444 in k6441 in collect/terms in lp in k6287 in string->sre in k4888 */
static void C_fcall f_6699(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6699,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6710,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* reverse */
t3=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
if(C_truep(((C_word*)t0)[2])){
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_6449(t3,(C_word)C_a_i_list(&a,1,t2));}
else{
t2=((C_word*)t0)[4];
f_6449(t2,C_SCHEME_FALSE);}}}

/* k6708 in k6697 in k6444 in k6441 in collect/terms in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6710,2,t0,t1);}
t2=(C_word)C_u_i_cadr(t1);
t3=((C_word*)t0)[2];
f_6449(t3,(C_word)C_a_i_list(&a,2,lf[85],t2));}

/* k6447 in k6444 in k6441 in collect/terms in lp in k6287 in string->sre in k4888 */
static void C_fcall f_6449(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6449,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6452,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(lf[85],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6681,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6692,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}
else{
t3=t2;
f_6452(2,t3,((C_word*)t0)[2]);}}

/* k6690 in k6447 in k6444 in k6441 in collect/terms in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(1));
/* reverse */
t3=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k6679 in k6447 in k6444 in k6441 in collect/terms in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cddr(t1);
/* reverse */
t3=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k6450 in k6447 in k6444 in k6441 in collect/terms in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6452,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6457,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6457(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* lp in k6450 in k6447 in k6444 in k6441 in collect/terms in lp in k6287 in string->sre in k4888 */
static void C_fcall f_6457(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6457,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6460,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t6=f_6460(C_a_i(&a,6),t5);
t7=f_13504(C_a_i(&a,3),t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6621,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6144(t8,((C_word*)t0)[3],C_fix(1));}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(lf[70],t6);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
t9=f_6460(C_a_i(&a,6),t5);
/* lp636 */
t17=t1;
t18=t8;
t19=C_SCHEME_END_OF_LIST;
t20=t9;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t3);
/* lp636 */
t17=t1;
t18=t8;
t19=t10;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}

/* k6619 in lp in k6450 in k6447 in k6444 in k6441 in collect/terms in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6621,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_list(&a,2,lf[76],((C_word*)t0)[4]):((C_word*)t0)[4]);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(lf[77],t3);
if(C_truep(t4)){
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_truep((C_word)C_eqp(t5,lf[78]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,lf[79]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,lf[80]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,lf[81]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(lf[82],t6);
if(C_truep(t7)){
t8=(C_word)C_u_i_cadr(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6526,a[2]=((C_word*)t0)[2],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_u_i_cddr(t2);
/* sre-sequence */
t12=t9;
f_6526(t12,f_13479(C_a_i(&a,3),t11));}
else{
t11=t9;
f_6526(t11,lf[83]);}}
else{
t8=(C_word)C_u_i_cadadr(t2);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6559,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_u_i_cddadr(t2);
/* sre-sequence */
t12=t9;
f_6559(t12,f_13479(C_a_i(&a,3),t11));}
else{
t11=t9;
f_6559(t11,lf[83]);}}}}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[83]);}}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],((C_word*)t0)[3],t5);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6557 in k6619 in lp in k6450 in k6447 in k6444 in k6441 in collect/terms in lp in k6287 in string->sre in k4888 */
static void C_fcall f_6559(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6559,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_u_i_cddr(((C_word*)t0)[4]):C_SCHEME_END_OF_LIST);
t5=f_13504(C_a_i(&a,3),t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t1,t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[77],t8));}

/* k6524 in k6619 in lp in k6450 in k6447 in k6444 in k6441 in collect/terms in lp in k6287 in string->sre in k4888 */
static void C_fcall f_6526(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6526,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[77],t3));}

/* shift in lp in k6450 in k6447 in k6444 in k6441 in collect/terms in lp in k6287 in string->sre in k4888 */
static C_word C_fcall f_6460(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
t1=f_13479(C_a_i(&a,3),((C_word*)t0)[3]);
return((C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* collect/single in lp in k6287 in string->sre in k4888 */
static void C_fcall f_6367(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6367,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6371,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* flag-set? */
f_6144(t2,((C_word*)t0)[2],C_fix(32));}

/* k6369 in collect/single in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6374,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_truep(t1)?(C_word)C_i_greaterp(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1));
t5=((C_word*)t0)[4];
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10235,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_10235(t9,t2,t4);}
else{
t4=t2;
f_6374(2,t4,(C_word)C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1)));}}

/* lp in k6369 in collect/single in lp in k6287 in string->sre in k4888 */
static void C_fcall f_10235(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10235,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_i_lessp(t4,C_fix(128));
t6=(C_truep(t5)?t5:(C_word)C_i_greater_or_equalp(t4,C_fix(192)));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t2);}
else{
t7=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
/* lp1334 */
t9=t1;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}}

/* k6372 in k6369 in collect/single in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6374,2,t0,t1);}
if(C_truep((C_word)C_i_lessp(t1,((C_word*)t0)[9]))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6383,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6411,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[2],t1);
/* utf8-string-ref */
f_10045(t3,((C_word*)t0)[5],t1,t4);}
else{
t4=t3;
f_6411(2,t4,(C_word)C_subchar(((C_word*)t0)[5],t1));}}}

/* k6409 in k6372 in k6369 in collect/single in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cased-char576 */
t2=((C_word*)t0)[3];
f_6297(3,t2,((C_word*)t0)[2],t1);}

/* k6381 in k6372 in k6369 in collect/single in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6383,2,t0,t1);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[7],((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6403,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6407,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* substring */
t4=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* k6405 in k6381 in k6372 in k6369 in collect/single in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cased-string577 */
t2=((C_word*)t0)[3];
f_6327(t2,((C_word*)t0)[2],t1);}

/* k6401 in k6381 in k6372 in k6369 in collect/single in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6403,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* collect in lp in k6287 in string->sre in k4888 */
static void C_fcall f_6347(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6347,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[6],((C_word*)t0)[5]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6361,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6365,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* substring */
t4=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}}

/* k6363 in collect in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cased-string577 */
t2=((C_word*)t0)[3];
f_6327(t2,((C_word*)t0)[2],t1);}

/* k6359 in collect in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6361,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* cased-string in lp in k6287 in string->sre in k4888 */
static void C_fcall f_6327(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6327,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6334,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* flag-set? */
f_6144(t3,((C_word*)t0)[2],C_fix(2));}

/* k6332 in cased-string in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6334,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6341,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6345,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t4=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k6343 in k6332 in cased-string in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6339 in k6332 in cased-string in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6341,2,t0,t1);}
/* sre-sequence */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_13479(C_a_i(&a,3),t1));}

/* cased-char in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6297(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6297,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6322,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* flag-set? */
f_6144(t3,((C_word*)t0)[2],C_fix(2));}

/* k6320 in cased-char in lp in k6287 in string->sre in k4888 */
static void C_ccall f_6322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6322,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_char_alphabeticp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=f_9191(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[70],t5));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* symbol-list->flags in k4888 */
static void C_fcall f_6182(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6182,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6188,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6188(t6,t1,t2,C_fix(0));}

/* lp in symbol-list->flags in k4888 */
static void C_fcall f_6188(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6188,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6206,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6213,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_eqp(t6,lf[57]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6219,a[2]=t6,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t8)){
t10=t9;
f_6219(t10,t8);}
else{
t10=(C_word)C_eqp(t6,lf[66]);
t11=t9;
f_6219(t11,(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[67])));}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6217 in lp in symbol-list->flags in k4888 */
static void C_fcall f_6219(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_6213(t2,C_fix(2));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[58]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[2],lf[59]));
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_6213(t4,C_fix(4));}
else{
t4=(C_word)C_eqp(((C_word*)t0)[2],lf[60]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[2],lf[61]));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
f_6213(t6,C_fix(8));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[2],lf[62]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[2],lf[63]));
if(C_truep(t7)){
t8=((C_word*)t0)[3];
f_6213(t8,C_fix(16));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[2],lf[64]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[2],lf[65]));
t10=((C_word*)t0)[3];
f_6213(t10,(C_truep(t9)?C_fix(32):C_SCHEME_FALSE));}}}}}

/* k6211 in lp in symbol-list->flags in k4888 */
static void C_fcall f_6213(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* flag-join */
t2=lf[54];
f_6154(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6204 in lp in symbol-list->flags in k4888 */
static void C_ccall f_6206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp512 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6188(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* flag-clear in k4888 */
static void C_ccall f_6163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6163,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_minus(&a,2,C_fix(65535),t3);
/* bit-and */
f_6097(t1,t2,t4);}

/* flag-join in k4888 */
static void C_ccall f_6154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6154,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* bit-ior */
f_6050(t1,t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* flag-set? in k4888 */
static void C_fcall f_6144(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6144,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6152,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* bit-and */
f_6097(t4,t2,t3);}

/* k6150 in flag-set? in k4888 */
static void C_ccall f_6152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_nequalp(((C_word*)t0)[2],t1));}

/* bit-and in k4888 */
static void C_fcall f_6097(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6097,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_zerop(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
if(C_truep((C_word)C_i_zerop(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
t4=(C_word)C_i_oddp(t2);
t5=(C_truep(t4)?(C_word)C_i_oddp(t3):C_SCHEME_FALSE);
t6=(C_truep(t5)?C_fix(1):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6125,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6129,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
C_quotient(4,0,t8,t2,C_fix(2));}}}

/* k6127 in bit-and in k4888 */
static void C_ccall f_6129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6133,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_quotient(4,0,t2,((C_word*)t0)[2],C_fix(2));}

/* k6131 in k6127 in bit-and in k4888 */
static void C_ccall f_6133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-and */
f_6097(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6123 in bit-and in k4888 */
static void C_ccall f_6125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6125,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,C_fix(2),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t2));}

/* bit-ior in k4888 */
static void C_fcall f_6050(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6050,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_zerop(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_zerop(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_oddp(t2);
t5=(C_truep(t4)?t4:(C_word)C_i_oddp(t3));
t6=(C_truep(t5)?C_fix(1):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6078,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6082,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
C_quotient(4,0,t8,t2,C_fix(2));}}}

/* k6080 in bit-ior in k4888 */
static void C_ccall f_6082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6086,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_quotient(4,0,t2,((C_word*)t0)[2],C_fix(2));}

/* k6084 in k6080 in bit-ior in k4888 */
static void C_ccall f_6086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_6050(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6076 in bit-ior in k4888 */
static void C_ccall f_6078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6078,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,C_fix(2),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t2));}

/* bit-shl in k4888 */
static void C_fcall f_6034(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6034,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6042,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expt */
t5=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(2),t3);}

/* k6040 in bit-shl in k4888 */
static void C_ccall f_6042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6042,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_times(&a,2,((C_word*)t0)[2],t1));}

/* bit-shr in k4888 */
static void C_fcall f_6024(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6024,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6032,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expt */
t5=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(2),t3);}

/* k6030 in bit-shr in k4888 */
static void C_ccall f_6032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_quotient(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* filter in k4888 */
static void C_fcall f_5938(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5938,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5944,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5944(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in filter in k4888 */
static void C_fcall f_5944(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5944,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5965,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5968,a[2]=t3,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_car(t2);
/* pred435 */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}}

/* k5966 in lp in filter in k4888 */
static void C_ccall f_5968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5968,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_5965(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_5965(t2,((C_word*)t0)[2]);}}

/* k5963 in lp in filter in k4888 */
static void C_fcall f_5965(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp438 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5944(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fold in k4888 */
static void C_fcall f_5908(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5908,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5914,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5914(t8,t1,t4,t3);}

/* lp in fold in k4888 */
static void C_fcall f_5914(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5914,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5932,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* kons423 */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t3);}}

/* k5930 in lp in fold in k4888 */
static void C_ccall f_5932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp427 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5914(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* every in k4888 */
static void C_fcall f_5859(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5859,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t3,C_fix(1));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5879,a[2]=t8,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_5879(t10,t1,t5,t6);}}

/* lp in every in k4888 */
static void C_fcall f_5879(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5879,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
/* pred404 */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5895,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* pred404 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k5893 in lp in every in k4888 */
static void C_ccall f_5895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* lp413 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5879(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* any in k4888 */
static void C_fcall f_5810(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5810,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_slot(t3,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5830,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5830(t9,t1,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* lp in any in k4888 */
static void C_fcall f_5830(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5830,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
/* pred385 */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5843,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* pred385 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k5841 in lp in any in k4888 */
static void C_ccall f_5843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* lp390 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5830(t4,((C_word*)t0)[4],t2,t3);}}

/* last in k4888 */
static void C_fcall f_5768(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5768,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5783,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_5783(t2));}
else{
/* error */
t3=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[44],t2);}}

/* lp in last in k4888 */
static C_word C_fcall f_5783(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
t2=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}
else{
return((C_word)C_u_i_car(t1));}}

/* find-tail in k4888 */
static void C_fcall f_5736(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5736,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5742,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5742(t7,t1,t3);}

/* lp in find-tail in k4888 */
static void C_fcall f_5742(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5742,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5755,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* pred359 */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}

/* k5753 in lp in find-tail in k4888 */
static void C_ccall f_5755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* lp362 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5742(t3,((C_word*)t0)[4],t2);}}

/* find in k4888 */
static void C_fcall f_5724(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5724,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5728,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* find-tail */
f_5736(t4,t2,t3);}

/* k5726 in find in k4888 */
static void C_ccall f_5728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_u_i_car(t1):C_SCHEME_FALSE));}

/* take-up-to in k4888 */
static void C_fcall f_5681(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5681,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5687,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5687(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* lp in take-up-to in k4888 */
static void C_fcall f_5687(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5687,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5694,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_eqp(t2,((C_word*)t0)[2]);
t6=t4;
f_5694(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_5694(t5,C_SCHEME_FALSE);}}

/* k5692 in lp in take-up-to in k4888 */
static void C_fcall f_5694(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5694,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
/* lp335 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5687(t5,((C_word*)t0)[2],t2,t4);}
else{
/* reverse */
t2=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* zero-to in k4888 */
static void C_fcall f_5642(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5642,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5658,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5658(t7,t1,t3,C_SCHEME_END_OF_LIST);}}

/* lp in zero-to in k4888 */
static void C_fcall f_5658(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5658,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_zerop(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,C_fix(0),t3));}
else{
t4=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* lp324 */
t7=t1;
t8=t4;
t9=t5;
t1=t7;
t2=t8;
t3=t9;
goto loop;}}

/* string-cat-reverse in k4888 */
static void C_fcall f_5585(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5585,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5593,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5595,tmp=(C_word)a,a+=2,tmp);
/* fold */
f_5908(t3,t4,C_fix(0),t2);}

/* a5594 in string-cat-reverse in k4888 */
static void C_ccall f_5595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5595,4,t0,t1,t2,t3);}
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_plus(&a,2,t4,t3));}

/* k5591 in string-cat-reverse in k4888 */
static void C_ccall f_5593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5593,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5609,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* make-string */
t5=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}

/* k5607 in k5591 in string-cat-reverse in k4888 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5612,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5614,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5614(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k5607 in k5591 in string-cat-reverse in k4888 */
static void C_fcall f_5614(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5614,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_fix((C_word)C_header_size(t4));
t6=(C_word)C_a_i_minus(&a,2,t2,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5633,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=((C_word*)t0)[2];
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5558,a[2]=t10,a[3]=t8,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_5558(t12,t7,C_fix(0),t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* doloop278 in lp in k5607 in k5591 in string-cat-reverse in k4888 */
static void C_fcall f_5558(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5558,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_greater_or_equalp(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_subchar(((C_word*)t0)[4],t2);
t5=(C_word)C_setsubchar(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* k5631 in lp in k5607 in k5591 in string-cat-reverse in k4888 */
static void C_ccall f_5633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* lp304 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5614(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5610 in k5607 in k5591 in string-cat-reverse in k4888 */
static void C_ccall f_5612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-alphanumeric? in k4888 */
static C_word C_fcall f_5540(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_u_i_char_alphabeticp(t1);
return((C_truep(t2)?t2:(C_word)C_u_i_char_numericp(t1)));}

/* string-scan-char in k4888 */
static void C_fcall f_5325(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5325,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fix((C_word)C_header_size(t2));
t6=(C_word)C_i_pairp(t4);
t7=(C_truep(t6)?(C_word)C_u_i_car(t4):C_fix(0));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5338,a[2]=t9,a[3]=t3,a[4]=t2,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_5338(t11,t1,t7);}

/* scan in string-scan-char in k4888 */
static void C_fcall f_5338(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5338,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[4],t2);
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[3],t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
/* scan186 */
t6=t1;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}}

/* irregex-match-end in k4888 */
static void C_ccall f_5310(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5310r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5310r(t0,t1,t2,t3);}}

static void C_ccall f_5310r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5318,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-index */
f_5166(t4,t2,t3);}

/* k5316 in irregex-match-end in k4888 */
static void C_ccall f_5318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5318,2,t0,t1);}
/* irregex-match-valid-index? */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_5212(C_a_i(&a,16),((C_word*)t0)[2],t1));}

/* irregex-match-start in k4888 */
static void C_ccall f_5287(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5287r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5287r(t0,t1,t2,t3);}}

static void C_ccall f_5287r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5291,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-index */
f_5166(t4,t2,t3);}

/* k5289 in irregex-match-start in k4888 */
static void C_ccall f_5291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5291,2,t0,t1);}
t2=f_5212(C_a_i(&a,16),((C_word*)t0)[3],t1);
if(C_truep(t2)){
t3=(C_word)C_a_i_times(&a,2,t1,C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,C_fix(3),t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_slot(((C_word*)t0)[3],t4));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* irregex-match-substring in k4888 */
static void C_ccall f_5244(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5244r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5244r(t0,t1,t2,t3);}}

static void C_ccall f_5244r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5248,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-index */
f_5166(t4,t2,t3);}

/* k5246 in irregex-match-substring in k4888 */
static void C_ccall f_5248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5248,2,t0,t1);}
t2=f_5212(C_a_i(&a,16),((C_word*)t0)[3],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* irregex-match-string */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k5259 in k5246 in irregex-match-substring in k4888 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5261,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,((C_word*)t0)[4],C_fix(2));
t3=(C_word)C_a_i_plus(&a,2,C_fix(3),t2);
t4=(C_word)C_slot(((C_word*)t0)[3],t3);
t5=(C_word)C_a_i_times(&a,2,((C_word*)t0)[4],C_fix(2));
t6=(C_word)C_a_i_plus(&a,2,C_fix(4),t5);
t7=(C_word)C_slot(((C_word*)t0)[3],t6);
/* substring */
t8=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[2],t1,t4,t7);}

/* irregex-match-valid-index? in k4888 */
static C_word C_fcall f_5212(C_word *a,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t3=(C_word)C_a_i_times(&a,2,t2,C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,C_fix(3),t3);
t5=(C_word)C_fix((C_word)C_header_size(t1));
if(C_truep((C_word)C_i_lessp(t4,t5))){
t6=(C_word)C_a_i_times(&a,2,t2,C_fix(2));
t7=(C_word)C_a_i_plus(&a,2,C_fix(4),t6);
return((C_word)C_slot(t1,t7));}
else{
return(C_SCHEME_FALSE);}}

/* irregex-match-index in k4888 */
static void C_fcall f_5166(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5166,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_i_numberp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u_i_car(t3));}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_u_i_assq(t5,t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_slot(t7,C_fix(1)));}
else{
t8=(C_word)C_u_i_car(t3);
/* error */
t9=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t1,lf[25],t8);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}}

/* irregex-match-end-index-set! in k4888 */
static C_word C_fcall f_5152(C_word *a,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_a_i_times(&a,2,t2,C_fix(2));
t5=(C_word)C_a_i_plus(&a,2,C_fix(4),t4);
return((C_word)C_i_setslot(t1,t5,t3));}

/* irregex-match-start-index-set! in k4888 */
static C_word C_fcall f_5138(C_word *a,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_a_i_times(&a,2,t2,C_fix(2));
t5=(C_word)C_a_i_plus(&a,2,C_fix(3),t4);
return((C_word)C_i_setslot(t1,t5,t3));}

/* irregex-match-end-index in k4888 */
static C_word C_fcall f_5124(C_word *a,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_a_i_times(&a,2,t2,C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,C_fix(4),t3);
return((C_word)C_slot(t1,t4));}

/* irregex-match-start-index in k4888 */
static C_word C_fcall f_5110(C_word *a,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_a_i_times(&a,2,t2,C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,C_fix(3),t3);
return((C_word)C_slot(t1,t4));}

/* irregex-match-string-set! in k4888 */
static C_word C_fcall f_5104(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)C_i_setslot(t1,C_fix(1),t2));}

/* irregex-match-string in k4888 */
static void C_ccall f_5092(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5092,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* irregex-match-num-submatches in k4888 */
static void C_ccall f_5074(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5074,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5082,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=(C_word)C_a_i_minus(&a,2,t4,C_fix(3));
C_quotient(4,0,t3,t5,C_fix(2));}

/* k5080 in irregex-match-num-submatches in k4888 */
static void C_ccall f_5082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5082,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_minus(&a,2,t1,C_fix(1)));}

/* irregex-match-data? in k4888 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5021,3,t0,t1,t2);}
if(C_truep((C_word)C_i_vectorp(t2))){
t3=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_greater_or_equalp(t3,C_fix(5)))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(lf[12],t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* irregex-reset-matches! in k4888 */
static void C_ccall f_4987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4987,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(t2));
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4997,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4997(t8,t1,t4);}

/* doloop74 in irregex-reset-matches! in k4888 */
static void C_fcall f_4997(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4997,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(3)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[3],t2,C_SCHEME_FALSE);
t4=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t6=t1;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* irregex-new-matches in k4888 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4973,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4981,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* irregex-submatches */
t4=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4979 in irregex-new-matches in k4888 */
static void C_ccall f_4981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4985,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* irregex-names */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4983 in k4979 in irregex-new-matches in k4888 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4985,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5051,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_plus(&a,2,C_fix(1),t3);
t6=(C_word)C_a_i_times(&a,2,C_fix(2),t5);
t7=(C_word)C_a_i_plus(&a,2,t6,C_fix(3));
/* make-vector */
t8=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,t7,C_SCHEME_FALSE);}

/* k5049 in k4983 in k4979 in irregex-new-matches in k4888 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(t1,C_fix(0),lf[12]);
t3=(C_word)C_i_set_i_slot(t1,C_fix(1),C_SCHEME_FALSE);
t4=(C_word)C_i_setslot(t1,C_fix(2),((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* irregex-names in k4888 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4967,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(8)));}

/* irregex-lengths in k4888 */
static void C_ccall f_4961(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4961,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(7)));}

/* irregex-submatches in k4888 */
static void C_ccall f_4955(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4955,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(6)));}

/* irregex-flags in k4888 */
static void C_ccall f_4949(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4949,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(5)));}

/* irregex-nfa in k4888 */
static void C_ccall f_4943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4943,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(4)));}

/* irregex-dfa/extract in k4888 */
static void C_ccall f_4937(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4937,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* irregex-dfa/search in k4888 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4931,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* irregex-dfa in k4888 */
static void C_ccall f_4925(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4925,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* irregex? in k4888 */
static void C_ccall f_4899(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4899,3,t0,t1,t2);}
if(C_truep((C_word)C_i_vectorp(t2))){
t3=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_nequalp(C_fix(9),t3))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(lf[1],t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* make-irregex in k4888 */
static C_word C_fcall f_4893(C_word *a,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
return((C_word)C_a_i_vector(&a,9,lf[1],t1,t2,t3,t4,t5,t6,t7,t8));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[1080] = {
{"toplevel:regex_scm",(void*)C_regex_toplevel},
{"f_4890:regex_scm",(void*)f_4890},
{"f_21583:regex_scm",(void*)f_21583},
{"f_21590:regex_scm",(void*)f_21590},
{"f_21598:regex_scm",(void*)f_21598},
{"f_21630:regex_scm",(void*)f_21630},
{"f_21617:regex_scm",(void*)f_21617},
{"f_21620:regex_scm",(void*)f_21620},
{"f_21543:regex_scm",(void*)f_21543},
{"f_21552:regex_scm",(void*)f_21552},
{"f_21571:regex_scm",(void*)f_21571},
{"f_21578:regex_scm",(void*)f_21578},
{"f_21266:regex_scm",(void*)f_21266},
{"f_21281:regex_scm",(void*)f_21281},
{"f_21283:regex_scm",(void*)f_21283},
{"f_21538:regex_scm",(void*)f_21538},
{"f_21534:regex_scm",(void*)f_21534},
{"f_21523:regex_scm",(void*)f_21523},
{"f_21345:regex_scm",(void*)f_21345},
{"f_21375:regex_scm",(void*)f_21375},
{"f_21404:regex_scm",(void*)f_21404},
{"f_21452:regex_scm",(void*)f_21452},
{"f_21431:regex_scm",(void*)f_21431},
{"f_21427:regex_scm",(void*)f_21427},
{"f_21394:regex_scm",(void*)f_21394},
{"f_21390:regex_scm",(void*)f_21390},
{"f_21365:regex_scm",(void*)f_21365},
{"f_21343:regex_scm",(void*)f_21343},
{"f_21330:regex_scm",(void*)f_21330},
{"f_21317:regex_scm",(void*)f_21317},
{"f_21313:regex_scm",(void*)f_21313},
{"f_21277:regex_scm",(void*)f_21277},
{"f_21181:regex_scm",(void*)f_21181},
{"f_21194:regex_scm",(void*)f_21194},
{"f_21213:regex_scm",(void*)f_21213},
{"f_21129:regex_scm",(void*)f_21129},
{"f_21144:regex_scm",(void*)f_21144},
{"f_21161:regex_scm",(void*)f_21161},
{"f_20874:regex_scm",(void*)f_20874},
{"f_21016:regex_scm",(void*)f_21016},
{"f_21020:regex_scm",(void*)f_21020},
{"f_21111:regex_scm",(void*)f_21111},
{"f_21107:regex_scm",(void*)f_21107},
{"f_21078:regex_scm",(void*)f_21078},
{"f_21060:regex_scm",(void*)f_21060},
{"f_21053:regex_scm",(void*)f_21053},
{"f_20910:regex_scm",(void*)f_20910},
{"f_20916:regex_scm",(void*)f_20916},
{"f_20983:regex_scm",(void*)f_20983},
{"f_20971:regex_scm",(void*)f_20971},
{"f_20930:regex_scm",(void*)f_20930},
{"f_20895:regex_scm",(void*)f_20895},
{"f_20692:regex_scm",(void*)f_20692},
{"f_20856:regex_scm",(void*)f_20856},
{"f_20830:regex_scm",(void*)f_20830},
{"f_20855:regex_scm",(void*)f_20855},
{"f_20810:regex_scm",(void*)f_20810},
{"f_20711:regex_scm",(void*)f_20711},
{"f_20719:regex_scm",(void*)f_20719},
{"f_20723:regex_scm",(void*)f_20723},
{"f_20784:regex_scm",(void*)f_20784},
{"f_20765:regex_scm",(void*)f_20765},
{"f_20799:regex_scm",(void*)f_20799},
{"f_20794:regex_scm",(void*)f_20794},
{"f_20572:regex_scm",(void*)f_20572},
{"f_20647:regex_scm",(void*)f_20647},
{"f_20638:regex_scm",(void*)f_20638},
{"f_20574:regex_scm",(void*)f_20574},
{"f_20578:regex_scm",(void*)f_20578},
{"f_20633:regex_scm",(void*)f_20633},
{"f_20587:regex_scm",(void*)f_20587},
{"f_20597:regex_scm",(void*)f_20597},
{"f_20599:regex_scm",(void*)f_20599},
{"f_20460:regex_scm",(void*)f_20460},
{"f_20527:regex_scm",(void*)f_20527},
{"f_20518:regex_scm",(void*)f_20518},
{"f_20462:regex_scm",(void*)f_20462},
{"f_20466:regex_scm",(void*)f_20466},
{"f_20513:regex_scm",(void*)f_20513},
{"f_20475:regex_scm",(void*)f_20475},
{"f_20485:regex_scm",(void*)f_20485},
{"f_20487:regex_scm",(void*)f_20487},
{"f_20509:regex_scm",(void*)f_20509},
{"f_20398:regex_scm",(void*)f_20398},
{"f_20402:regex_scm",(void*)f_20402},
{"f_20405:regex_scm",(void*)f_20405},
{"f_20415:regex_scm",(void*)f_20415},
{"f_20417:regex_scm",(void*)f_20417},
{"f_20352:regex_scm",(void*)f_20352},
{"f_20356:regex_scm",(void*)f_20356},
{"f_20359:regex_scm",(void*)f_20359},
{"f_20369:regex_scm",(void*)f_20369},
{"f_20371:regex_scm",(void*)f_20371},
{"f_20396:regex_scm",(void*)f_20396},
{"f_20331:regex_scm",(void*)f_20331},
{"f_20338:regex_scm",(void*)f_20338},
{"f_20347:regex_scm",(void*)f_20347},
{"f_20228:regex_scm",(void*)f_20228},
{"f_20271:regex_scm",(void*)f_20271},
{"f_20266:regex_scm",(void*)f_20266},
{"f_20261:regex_scm",(void*)f_20261},
{"f_20230:regex_scm",(void*)f_20230},
{"f_20242:regex_scm",(void*)f_20242},
{"f_20245:regex_scm",(void*)f_20245},
{"f_20248:regex_scm",(void*)f_20248},
{"f_20238:regex_scm",(void*)f_20238},
{"f_20210:regex_scm",(void*)f_20210},
{"f_20028:regex_scm",(void*)f_20028},
{"f_20034:regex_scm",(void*)f_20034},
{"f_20156:regex_scm",(void*)f_20156},
{"f_20160:regex_scm",(void*)f_20160},
{"f_20168:regex_scm",(void*)f_20168},
{"f_20152:regex_scm",(void*)f_20152},
{"f_20127:regex_scm",(void*)f_20127},
{"f_20131:regex_scm",(void*)f_20131},
{"f_20123:regex_scm",(void*)f_20123},
{"f_20090:regex_scm",(void*)f_20090},
{"f_20062:regex_scm",(void*)f_20062},
{"f_19972:regex_scm",(void*)f_19972},
{"f_20005:regex_scm",(void*)f_20005},
{"f_20026:regex_scm",(void*)f_20026},
{"f_20016:regex_scm",(void*)f_20016},
{"f_19978:regex_scm",(void*)f_19978},
{"f_19982:regex_scm",(void*)f_19982},
{"f_19989:regex_scm",(void*)f_19989},
{"f_20003:regex_scm",(void*)f_20003},
{"f_19993:regex_scm",(void*)f_19993},
{"f_19920:regex_scm",(void*)f_19920},
{"f_19970:regex_scm",(void*)f_19970},
{"f_19924:regex_scm",(void*)f_19924},
{"f_19962:regex_scm",(void*)f_19962},
{"f_19938:regex_scm",(void*)f_19938},
{"f_19946:regex_scm",(void*)f_19946},
{"f_19958:regex_scm",(void*)f_19958},
{"f_19954:regex_scm",(void*)f_19954},
{"f_19942:regex_scm",(void*)f_19942},
{"f_19807:regex_scm",(void*)f_19807},
{"f_19811:regex_scm",(void*)f_19811},
{"f_19814:regex_scm",(void*)f_19814},
{"f_19897:regex_scm",(void*)f_19897},
{"f_19868:regex_scm",(void*)f_19868},
{"f_19831:regex_scm",(void*)f_19831},
{"f_19844:regex_scm",(void*)f_19844},
{"f_19856:regex_scm",(void*)f_19856},
{"f_19859:regex_scm",(void*)f_19859},
{"f_19862:regex_scm",(void*)f_19862},
{"f_19917:regex_scm",(void*)f_19917},
{"f_19642:regex_scm",(void*)f_19642},
{"f_19648:regex_scm",(void*)f_19648},
{"f_19664:regex_scm",(void*)f_19664},
{"f_19701:regex_scm",(void*)f_19701},
{"f_19759:regex_scm",(void*)f_19759},
{"f_19716:regex_scm",(void*)f_19716},
{"f_19712:regex_scm",(void*)f_19712},
{"f_19684:regex_scm",(void*)f_19684},
{"f_19632:regex_scm",(void*)f_19632},
{"f_19640:regex_scm",(void*)f_19640},
{"f_19514:regex_scm",(void*)f_19514},
{"f_19520:regex_scm",(void*)f_19520},
{"f_19622:regex_scm",(void*)f_19622},
{"f_19530:regex_scm",(void*)f_19530},
{"f_19597:regex_scm",(void*)f_19597},
{"f_19538:regex_scm",(void*)f_19538},
{"f_19589:regex_scm",(void*)f_19589},
{"f_19542:regex_scm",(void*)f_19542},
{"f_19551:regex_scm",(void*)f_19551},
{"f_19554:regex_scm",(void*)f_19554},
{"f_19561:regex_scm",(void*)f_19561},
{"f_19393:regex_scm",(void*)f_19393},
{"f_19500:regex_scm",(void*)f_19500},
{"f_19416:regex_scm",(void*)f_19416},
{"f_19475:regex_scm",(void*)f_19475},
{"f_19424:regex_scm",(void*)f_19424},
{"f_19467:regex_scm",(void*)f_19467},
{"f_19428:regex_scm",(void*)f_19428},
{"f_19437:regex_scm",(void*)f_19437},
{"f_19440:regex_scm",(void*)f_19440},
{"f_19306:regex_scm",(void*)f_19306},
{"f_19383:regex_scm",(void*)f_19383},
{"f_19316:regex_scm",(void*)f_19316},
{"f_19362:regex_scm",(void*)f_19362},
{"f_19334:regex_scm",(void*)f_19334},
{"f_19326:regex_scm",(void*)f_19326},
{"f_19161:regex_scm",(void*)f_19161},
{"f_19177:regex_scm",(void*)f_19177},
{"f_19149:regex_scm",(void*)f_19149},
{"f_19111:regex_scm",(void*)f_19111},
{"f_19117:regex_scm",(void*)f_19117},
{"f_18830:regex_scm",(void*)f_18830},
{"f_18840:regex_scm",(void*)f_18840},
{"f_19004:regex_scm",(void*)f_19004},
{"f_19008:regex_scm",(void*)f_19008},
{"f_13588:regex_scm",(void*)f_13588},
{"f_13615:regex_scm",(void*)f_13615},
{"f_13611:regex_scm",(void*)f_13611},
{"f_18987:regex_scm",(void*)f_18987},
{"f_18754:regex_scm",(void*)f_18754},
{"f_18977:regex_scm",(void*)f_18977},
{"f_18956:regex_scm",(void*)f_18956},
{"f_18960:regex_scm",(void*)f_18960},
{"f_18948:regex_scm",(void*)f_18948},
{"f_18925:regex_scm",(void*)f_18925},
{"f_18929:regex_scm",(void*)f_18929},
{"f_18900:regex_scm",(void*)f_18900},
{"f_18904:regex_scm",(void*)f_18904},
{"f_18896:regex_scm",(void*)f_18896},
{"f_18869:regex_scm",(void*)f_18869},
{"f_18843:regex_scm",(void*)f_18843},
{"f_18713:regex_scm",(void*)f_18713},
{"f_18715:regex_scm",(void*)f_18715},
{"f_18722:regex_scm",(void*)f_18722},
{"f_16349:regex_scm",(void*)f_16349},
{"f_16389:regex_scm",(void*)f_16389},
{"f_16268:regex_scm",(void*)f_16268},
{"f_16274:regex_scm",(void*)f_16274},
{"f_16323:regex_scm",(void*)f_16323},
{"f_16321:regex_scm",(void*)f_16321},
{"f_16313:regex_scm",(void*)f_16313},
{"f_16301:regex_scm",(void*)f_16301},
{"f_16305:regex_scm",(void*)f_16305},
{"f_16152:regex_scm",(void*)f_16152},
{"f_16185:regex_scm",(void*)f_16185},
{"f_16189:regex_scm",(void*)f_16189},
{"f_16197:regex_scm",(void*)f_16197},
{"f_16166:regex_scm",(void*)f_16166},
{"f_16078:regex_scm",(void*)f_16078},
{"f_16086:regex_scm",(void*)f_16086},
{"f_16090:regex_scm",(void*)f_16090},
{"f_16066:regex_scm",(void*)f_16066},
{"f_15604:regex_scm",(void*)f_15604},
{"f_15813:regex_scm",(void*)f_15813},
{"f_15841:regex_scm",(void*)f_15841},
{"f_15998:regex_scm",(void*)f_15998},
{"f_15899:regex_scm",(void*)f_15899},
{"f_15969:regex_scm",(void*)f_15969},
{"f_15904:regex_scm",(void*)f_15904},
{"f_15957:regex_scm",(void*)f_15957},
{"f_15917:regex_scm",(void*)f_15917},
{"f_15920:regex_scm",(void*)f_15920},
{"f_15927:regex_scm",(void*)f_15927},
{"f_15885:regex_scm",(void*)f_15885},
{"f_15846:regex_scm",(void*)f_15846},
{"f_15873:regex_scm",(void*)f_15873},
{"f_15857:regex_scm",(void*)f_15857},
{"f_15635:regex_scm",(void*)f_15635},
{"f_15684:regex_scm",(void*)f_15684},
{"f_15751:regex_scm",(void*)f_15751},
{"f_15689:regex_scm",(void*)f_15689},
{"f_15739:regex_scm",(void*)f_15739},
{"f_15705:regex_scm",(void*)f_15705},
{"f_15709:regex_scm",(void*)f_15709},
{"f_15701:regex_scm",(void*)f_15701},
{"f_15670:regex_scm",(void*)f_15670},
{"f_15607:regex_scm",(void*)f_15607},
{"f_15307:regex_scm",(void*)f_15307},
{"f_15422:regex_scm",(void*)f_15422},
{"f_15320:regex_scm",(void*)f_15320},
{"f_15515:regex_scm",(void*)f_15515},
{"f_15594:regex_scm",(void*)f_15594},
{"f_15533:regex_scm",(void*)f_15533},
{"f_15545:regex_scm",(void*)f_15545},
{"f_15353:regex_scm",(void*)f_15353},
{"f_15365:regex_scm",(void*)f_15365},
{"f_15400:regex_scm",(void*)f_15400},
{"f_15372:regex_scm",(void*)f_15372},
{"f_15396:regex_scm",(void*)f_15396},
{"f_15388:regex_scm",(void*)f_15388},
{"f_15334:regex_scm",(void*)f_15334},
{"f_15499:regex_scm",(void*)f_15499},
{"f_15503:regex_scm",(void*)f_15503},
{"f_15442:regex_scm",(void*)f_15442},
{"f_15461:regex_scm",(void*)f_15461},
{"f_15475:regex_scm",(void*)f_15475},
{"f_15473:regex_scm",(void*)f_15473},
{"f_15459:regex_scm",(void*)f_15459},
{"f_15444:regex_scm",(void*)f_15444},
{"f_14517:regex_scm",(void*)f_14517},
{"f_14535:regex_scm",(void*)f_14535},
{"f_14798:regex_scm",(void*)f_14798},
{"f_14852:regex_scm",(void*)f_14852},
{"f_15112:regex_scm",(void*)f_15112},
{"f_15200:regex_scm",(void*)f_15200},
{"f_15118:regex_scm",(void*)f_15118},
{"f_15196:regex_scm",(void*)f_15196},
{"f_15121:regex_scm",(void*)f_15121},
{"f_15176:regex_scm",(void*)f_15176},
{"f_15127:regex_scm",(void*)f_15127},
{"f_15146:regex_scm",(void*)f_15146},
{"f_15052:regex_scm",(void*)f_15052},
{"f_15096:regex_scm",(void*)f_15096},
{"f_15058:regex_scm",(void*)f_15058},
{"f_15080:regex_scm",(void*)f_15080},
{"f_14949:regex_scm",(void*)f_14949},
{"f_15031:regex_scm",(void*)f_15031},
{"f_14952:regex_scm",(void*)f_14952},
{"f_15016:regex_scm",(void*)f_15016},
{"f_14955:regex_scm",(void*)f_14955},
{"f_14981:regex_scm",(void*)f_14981},
{"f_14973:regex_scm",(void*)f_14973},
{"f_14977:regex_scm",(void*)f_14977},
{"f_14969:regex_scm",(void*)f_14969},
{"f_14940:regex_scm",(void*)f_14940},
{"f_14855:regex_scm",(void*)f_14855},
{"f_14882:regex_scm",(void*)f_14882},
{"f_14910:regex_scm",(void*)f_14910},
{"f_14908:regex_scm",(void*)f_14908},
{"f_14896:regex_scm",(void*)f_14896},
{"f_14900:regex_scm",(void*)f_14900},
{"f_14871:regex_scm",(void*)f_14871},
{"f_14801:regex_scm",(void*)f_14801},
{"f_14804:regex_scm",(void*)f_14804},
{"f_14818:regex_scm",(void*)f_14818},
{"f_14781:regex_scm",(void*)f_14781},
{"f_14758:regex_scm",(void*)f_14758},
{"f_14681:regex_scm",(void*)f_14681},
{"f_14648:regex_scm",(void*)f_14648},
{"f_14670:regex_scm",(void*)f_14670},
{"f_14655:regex_scm",(void*)f_14655},
{"f_14625:regex_scm",(void*)f_14625},
{"f_14604:regex_scm",(void*)f_14604},
{"f_14600:regex_scm",(void*)f_14600},
{"f_14552:regex_scm",(void*)f_14552},
{"f_14567:regex_scm",(void*)f_14567},
{"f_14573:regex_scm",(void*)f_14573},
{"f_14571:regex_scm",(void*)f_14571},
{"f_14538:regex_scm",(void*)f_14538},
{"f_14410:regex_scm",(void*)f_14410},
{"f_14424:regex_scm",(void*)f_14424},
{"f_14462:regex_scm",(void*)f_14462},
{"f_14437:regex_scm",(void*)f_14437},
{"f_14315:regex_scm",(void*)f_14315},
{"f_14305:regex_scm",(void*)f_14305},
{"f_14299:regex_scm",(void*)f_14299},
{"f_14232:regex_scm",(void*)f_14232},
{"f_14236:regex_scm",(void*)f_14236},
{"f_14239:regex_scm",(void*)f_14239},
{"f_14251:regex_scm",(void*)f_14251},
{"f_14279:regex_scm",(void*)f_14279},
{"f_14296:regex_scm",(void*)f_14296},
{"f_14282:regex_scm",(void*)f_14282},
{"f_14276:regex_scm",(void*)f_14276},
{"f_14254:regex_scm",(void*)f_14254},
{"f_14272:regex_scm",(void*)f_14272},
{"f_14269:regex_scm",(void*)f_14269},
{"f_14073:regex_scm",(void*)f_14073},
{"f_14080:regex_scm",(void*)f_14080},
{"f_14196:regex_scm",(void*)f_14196},
{"f_14201:regex_scm",(void*)f_14201},
{"f_14229:regex_scm",(void*)f_14229},
{"f_14211:regex_scm",(void*)f_14211},
{"f_14193:regex_scm",(void*)f_14193},
{"f_14086:regex_scm",(void*)f_14086},
{"f_14189:regex_scm",(void*)f_14189},
{"f_14331:regex_scm",(void*)f_14331},
{"f_14366:regex_scm",(void*)f_14366},
{"f_14350:regex_scm",(void*)f_14350},
{"f_14111:regex_scm",(void*)f_14111},
{"f_14185:regex_scm",(void*)f_14185},
{"f_14120:regex_scm",(void*)f_14120},
{"f_14126:regex_scm",(void*)f_14126},
{"f_14131:regex_scm",(void*)f_14131},
{"f_14141:regex_scm",(void*)f_14141},
{"f_14156:regex_scm",(void*)f_14156},
{"f_14153:regex_scm",(void*)f_14153},
{"f_14108:regex_scm",(void*)f_14108},
{"f_14089:regex_scm",(void*)f_14089},
{"f_14104:regex_scm",(void*)f_14104},
{"f_14101:regex_scm",(void*)f_14101},
{"f_14027:regex_scm",(void*)f_14027},
{"f_14031:regex_scm",(void*)f_14031},
{"f_14049:regex_scm",(void*)f_14049},
{"f_14040:regex_scm",(void*)f_14040},
{"f_13910:regex_scm",(void*)f_13910},
{"f_13929:regex_scm",(void*)f_13929},
{"f_14000:regex_scm",(void*)f_14000},
{"f_13967:regex_scm",(void*)f_13967},
{"f_13874:regex_scm",(void*)f_13874},
{"f_13904:regex_scm",(void*)f_13904},
{"f_13896:regex_scm",(void*)f_13896},
{"f_13644:regex_scm",(void*)f_13644},
{"f_13742:regex_scm",(void*)f_13742},
{"f_13529:regex_scm",(void*)f_13529},
{"f_13504:regex_scm",(void*)f_13504},
{"f_13479:regex_scm",(void*)f_13479},
{"f_12384:regex_scm",(void*)f_12384},
{"f_12390:regex_scm",(void*)f_12390},
{"f_12415:regex_scm",(void*)f_12415},
{"f_12358:regex_scm",(void*)f_12358},
{"f_12272:regex_scm",(void*)f_12272},
{"f_12311:regex_scm",(void*)f_12311},
{"f_12324:regex_scm",(void*)f_12324},
{"f_12186:regex_scm",(void*)f_12186},
{"f_12225:regex_scm",(void*)f_12225},
{"f_12130:regex_scm",(void*)f_12130},
{"f_12054:regex_scm",(void*)f_12054},
{"f_12079:regex_scm",(void*)f_12079},
{"f_11926:regex_scm",(void*)f_11926},
{"f_11945:regex_scm",(void*)f_11945},
{"f_11994:regex_scm",(void*)f_11994},
{"f_11785:regex_scm",(void*)f_11785},
{"f_11789:regex_scm",(void*)f_11789},
{"f_11472:regex_scm",(void*)f_11472},
{"f_11476:regex_scm",(void*)f_11476},
{"f_11478:regex_scm",(void*)f_11478},
{"f_11732:regex_scm",(void*)f_11732},
{"f_11743:regex_scm",(void*)f_11743},
{"f_11739:regex_scm",(void*)f_11739},
{"f_11591:regex_scm",(void*)f_11591},
{"f_11695:regex_scm",(void*)f_11695},
{"f_11676:regex_scm",(void*)f_11676},
{"f_11600:regex_scm",(void*)f_11600},
{"f_11621:regex_scm",(void*)f_11621},
{"f_11631:regex_scm",(void*)f_11631},
{"f_11606:regex_scm",(void*)f_11606},
{"f_11616:regex_scm",(void*)f_11616},
{"f_11574:regex_scm",(void*)f_11574},
{"f_11572:regex_scm",(void*)f_11572},
{"f_11547:regex_scm",(void*)f_11547},
{"f_11545:regex_scm",(void*)f_11545},
{"f_11481:regex_scm",(void*)f_11481},
{"f_11792:regex_scm",(void*)f_11792},
{"f_11795:regex_scm",(void*)f_11795},
{"f_11798:regex_scm",(void*)f_11798},
{"f_11801:regex_scm",(void*)f_11801},
{"f_11875:regex_scm",(void*)f_11875},
{"f_11804:regex_scm",(void*)f_11804},
{"f_11807:regex_scm",(void*)f_11807},
{"f_11810:regex_scm",(void*)f_11810},
{"f_16405:regex_scm",(void*)f_16405},
{"f_16729:regex_scm",(void*)f_16729},
{"f_16419:regex_scm",(void*)f_16419},
{"f_16432:regex_scm",(void*)f_16432},
{"f_16423:regex_scm",(void*)f_16423},
{"f_16424:regex_scm",(void*)f_16424},
{"f_16680:regex_scm",(void*)f_16680},
{"f_16681:regex_scm",(void*)f_16681},
{"f_16685:regex_scm",(void*)f_16685},
{"f_16688:regex_scm",(void*)f_16688},
{"f_16655:regex_scm",(void*)f_16655},
{"f_16656:regex_scm",(void*)f_16656},
{"f_16660:regex_scm",(void*)f_16660},
{"f_16599:regex_scm",(void*)f_16599},
{"f_16624:regex_scm",(void*)f_16624},
{"f_16628:regex_scm",(void*)f_16628},
{"f_16601:regex_scm",(void*)f_16601},
{"f_16605:regex_scm",(void*)f_16605},
{"f_16549:regex_scm",(void*)f_16549},
{"f_16574:regex_scm",(void*)f_16574},
{"f_16552:regex_scm",(void*)f_16552},
{"f_16553:regex_scm",(void*)f_16553},
{"f_16557:regex_scm",(void*)f_16557},
{"f_16456:regex_scm",(void*)f_16456},
{"f_16525:regex_scm",(void*)f_16525},
{"f_16459:regex_scm",(void*)f_16459},
{"f_16460:regex_scm",(void*)f_16460},
{"f_16466:regex_scm",(void*)f_16466},
{"f_16476:regex_scm",(void*)f_16476},
{"f_16479:regex_scm",(void*)f_16479},
{"f_11813:regex_scm",(void*)f_11813},
{"f_11816:regex_scm",(void*)f_11816},
{"f_11819:regex_scm",(void*)f_11819},
{"f_12447:regex_scm",(void*)f_12447},
{"f_13468:regex_scm",(void*)f_13468},
{"f_12450:regex_scm",(void*)f_12450},
{"f_12459:regex_scm",(void*)f_12459},
{"f_12504:regex_scm",(void*)f_12504},
{"f_12533:regex_scm",(void*)f_12533},
{"f_13263:regex_scm",(void*)f_13263},
{"f_13313:regex_scm",(void*)f_13313},
{"f_13290:regex_scm",(void*)f_13290},
{"f_13236:regex_scm",(void*)f_13236},
{"f_13206:regex_scm",(void*)f_13206},
{"f_13062:regex_scm",(void*)f_13062},
{"f_13065:regex_scm",(void*)f_13065},
{"f_13130:regex_scm",(void*)f_13130},
{"f_13083:regex_scm",(void*)f_13083},
{"f_13095:regex_scm",(void*)f_13095},
{"f_13042:regex_scm",(void*)f_13042},
{"f_13033:regex_scm",(void*)f_13033},
{"f_12920:regex_scm",(void*)f_12920},
{"f_12983:regex_scm",(void*)f_12983},
{"f_12929:regex_scm",(void*)f_12929},
{"f_12880:regex_scm",(void*)f_12880},
{"f_12709:regex_scm",(void*)f_12709},
{"f_12715:regex_scm",(void*)f_12715},
{"f_12718:regex_scm",(void*)f_12718},
{"f_12800:regex_scm",(void*)f_12800},
{"f_12727:regex_scm",(void*)f_12727},
{"f_12741:regex_scm",(void*)f_12741},
{"f_12753:regex_scm",(void*)f_12753},
{"f_12755:regex_scm",(void*)f_12755},
{"f_12784:regex_scm",(void*)f_12784},
{"f_12780:regex_scm",(void*)f_12780},
{"f_12767:regex_scm",(void*)f_12767},
{"f_12624:regex_scm",(void*)f_12624},
{"f_12657:regex_scm",(void*)f_12657},
{"f_12690:regex_scm",(void*)f_12690},
{"f_12673:regex_scm",(void*)f_12673},
{"f_12677:regex_scm",(void*)f_12677},
{"f_12542:regex_scm",(void*)f_12542},
{"f_12575:regex_scm",(void*)f_12575},
{"f_12605:regex_scm",(void*)f_12605},
{"f_12520:regex_scm",(void*)f_12520},
{"f_12462:regex_scm",(void*)f_12462},
{"f_12457:regex_scm",(void*)f_12457},
{"f_11841:regex_scm",(void*)f_11841},
{"f_11848:regex_scm",(void*)f_11848},
{"f_11825:regex_scm",(void*)f_11825},
{"f_18695:regex_scm",(void*)f_18695},
{"f_16736:regex_scm",(void*)f_16736},
{"f_16748:regex_scm",(void*)f_16748},
{"f_18683:regex_scm",(void*)f_18683},
{"f_18602:regex_scm",(void*)f_18602},
{"f_18635:regex_scm",(void*)f_18635},
{"f_18642:regex_scm",(void*)f_18642},
{"f_18603:regex_scm",(void*)f_18603},
{"f_18610:regex_scm",(void*)f_18610},
{"f_18506:regex_scm",(void*)f_18506},
{"f_18513:regex_scm",(void*)f_18513},
{"f_18448:regex_scm",(void*)f_18448},
{"f_18467:regex_scm",(void*)f_18467},
{"f_18455:regex_scm",(void*)f_18455},
{"f_18414:regex_scm",(void*)f_18414},
{"f_18424:regex_scm",(void*)f_18424},
{"f_18390:regex_scm",(void*)f_18390},
{"f_18332:regex_scm",(void*)f_18332},
{"f_18351:regex_scm",(void*)f_18351},
{"f_18339:regex_scm",(void*)f_18339},
{"f_18298:regex_scm",(void*)f_18298},
{"f_18308:regex_scm",(void*)f_18308},
{"f_18278:regex_scm",(void*)f_18278},
{"f_18236:regex_scm",(void*)f_18236},
{"f_18243:regex_scm",(void*)f_18243},
{"f_18208:regex_scm",(void*)f_18208},
{"f_16794:regex_scm",(void*)f_16794},
{"f_18160:regex_scm",(void*)f_18160},
{"f_18120:regex_scm",(void*)f_18120},
{"f_18132:regex_scm",(void*)f_18132},
{"f_18090:regex_scm",(void*)f_18090},
{"f_18091:regex_scm",(void*)f_18091},
{"f_18103:regex_scm",(void*)f_18103},
{"f_17963:regex_scm",(void*)f_17963},
{"f_18019:regex_scm",(void*)f_18019},
{"f_17967:regex_scm",(void*)f_17967},
{"f_17971:regex_scm",(void*)f_17971},
{"f_18005:regex_scm",(void*)f_18005},
{"f_17989:regex_scm",(void*)f_17989},
{"f_17821:regex_scm",(void*)f_17821},
{"f_17824:regex_scm",(void*)f_17824},
{"f_17931:regex_scm",(void*)f_17931},
{"f_17926:regex_scm",(void*)f_17926},
{"f_17922:regex_scm",(void*)f_17922},
{"f_17827:regex_scm",(void*)f_17827},
{"f_17836:regex_scm",(void*)f_17836},
{"f_17882:regex_scm",(void*)f_17882},
{"f_17883:regex_scm",(void*)f_17883},
{"f_17889:regex_scm",(void*)f_17889},
{"f_17839:regex_scm",(void*)f_17839},
{"f_17840:regex_scm",(void*)f_17840},
{"f_17807:regex_scm",(void*)f_17807},
{"f_17784:regex_scm",(void*)f_17784},
{"f_17785:regex_scm",(void*)f_17785},
{"f_17800:regex_scm",(void*)f_17800},
{"f_17789:regex_scm",(void*)f_17789},
{"f_17766:regex_scm",(void*)f_17766},
{"f_17735:regex_scm",(void*)f_17735},
{"f_17736:regex_scm",(void*)f_17736},
{"f_17757:regex_scm",(void*)f_17757},
{"f_17759:regex_scm",(void*)f_17759},
{"f_17753:regex_scm",(void*)f_17753},
{"f_17717:regex_scm",(void*)f_17717},
{"f_17686:regex_scm",(void*)f_17686},
{"f_17687:regex_scm",(void*)f_17687},
{"f_17708:regex_scm",(void*)f_17708},
{"f_17710:regex_scm",(void*)f_17710},
{"f_17704:regex_scm",(void*)f_17704},
{"f_17672:regex_scm",(void*)f_17672},
{"f_17649:regex_scm",(void*)f_17649},
{"f_17650:regex_scm",(void*)f_17650},
{"f_17665:regex_scm",(void*)f_17665},
{"f_17657:regex_scm",(void*)f_17657},
{"f_17635:regex_scm",(void*)f_17635},
{"f_17612:regex_scm",(void*)f_17612},
{"f_17613:regex_scm",(void*)f_17613},
{"f_17628:regex_scm",(void*)f_17628},
{"f_17620:regex_scm",(void*)f_17620},
{"f_17599:regex_scm",(void*)f_17599},
{"f_17574:regex_scm",(void*)f_17574},
{"f_17509:regex_scm",(void*)f_17509},
{"f_17322:regex_scm",(void*)f_17322},
{"f_17325:regex_scm",(void*)f_17325},
{"f_17348:regex_scm",(void*)f_17348},
{"f_17414:regex_scm",(void*)f_17414},
{"f_17398:regex_scm",(void*)f_17398},
{"f_17351:regex_scm",(void*)f_17351},
{"f_17383:regex_scm",(void*)f_17383},
{"f_17378:regex_scm",(void*)f_17378},
{"f_17372:regex_scm",(void*)f_17372},
{"f_17368:regex_scm",(void*)f_17368},
{"f_17326:regex_scm",(void*)f_17326},
{"f_17303:regex_scm",(void*)f_17303},
{"f_17270:regex_scm",(void*)f_17270},
{"f_17221:regex_scm",(void*)f_17221},
{"f_17158:regex_scm",(void*)f_17158},
{"f_17182:regex_scm",(void*)f_17182},
{"f_17188:regex_scm",(void*)f_17188},
{"f_17165:regex_scm",(void*)f_17165},
{"f_17166:regex_scm",(void*)f_17166},
{"f_17172:regex_scm",(void*)f_17172},
{"f_17100:regex_scm",(void*)f_17100},
{"f_17124:regex_scm",(void*)f_17124},
{"f_17130:regex_scm",(void*)f_17130},
{"f_17107:regex_scm",(void*)f_17107},
{"f_17108:regex_scm",(void*)f_17108},
{"f_17114:regex_scm",(void*)f_17114},
{"f_17069:regex_scm",(void*)f_17069},
{"f_17070:regex_scm",(void*)f_17070},
{"f_17076:regex_scm",(void*)f_17076},
{"f_17041:regex_scm",(void*)f_17041},
{"f_17042:regex_scm",(void*)f_17042},
{"f_17048:regex_scm",(void*)f_17048},
{"f_17020:regex_scm",(void*)f_17020},
{"f_17001:regex_scm",(void*)f_17001},
{"f_16963:regex_scm",(void*)f_16963},
{"f_16942:regex_scm",(void*)f_16942},
{"f_16921:regex_scm",(void*)f_16921},
{"f_16900:regex_scm",(void*)f_16900},
{"f_16841:regex_scm",(void*)f_16841},
{"f_16867:regex_scm",(void*)f_16867},
{"f_16844:regex_scm",(void*)f_16844},
{"f_16845:regex_scm",(void*)f_16845},
{"f_16851:regex_scm",(void*)f_16851},
{"f_16821:regex_scm",(void*)f_16821},
{"f_16805:regex_scm",(void*)f_16805},
{"f_16801:regex_scm",(void*)f_16801},
{"f_16782:regex_scm",(void*)f_16782},
{"f_16774:regex_scm",(void*)f_16774},
{"f_16751:regex_scm",(void*)f_16751},
{"f_16745:regex_scm",(void*)f_16745},
{"f_11834:regex_scm",(void*)f_11834},
{"f_11775:regex_scm",(void*)f_11775},
{"f_11783:regex_scm",(void*)f_11783},
{"f_11754:regex_scm",(void*)f_11754},
{"f_11761:regex_scm",(void*)f_11761},
{"f_11304:regex_scm",(void*)f_11304},
{"f_11310:regex_scm",(void*)f_11310},
{"f_11398:regex_scm",(void*)f_11398},
{"f_11401:regex_scm",(void*)f_11401},
{"f_10463:regex_scm",(void*)f_10463},
{"f_10466:regex_scm",(void*)f_10466},
{"f_11167:regex_scm",(void*)f_11167},
{"f_11165:regex_scm",(void*)f_11165},
{"f_11145:regex_scm",(void*)f_11145},
{"f_11141:regex_scm",(void*)f_11141},
{"f_11059:regex_scm",(void*)f_11059},
{"f_11137:regex_scm",(void*)f_11137},
{"f_11133:regex_scm",(void*)f_11133},
{"f_11129:regex_scm",(void*)f_11129},
{"f_11125:regex_scm",(void*)f_11125},
{"f_11101:regex_scm",(void*)f_11101},
{"f_11077:regex_scm",(void*)f_11077},
{"f_11075:regex_scm",(void*)f_11075},
{"f_10967:regex_scm",(void*)f_10967},
{"f_11041:regex_scm",(void*)f_11041},
{"f_10989:regex_scm",(void*)f_10989},
{"f_10987:regex_scm",(void*)f_10987},
{"f_10959:regex_scm",(void*)f_10959},
{"f_10487:regex_scm",(void*)f_10487},
{"f_10492:regex_scm",(void*)f_10492},
{"f_10564:regex_scm",(void*)f_10564},
{"f_11242:regex_scm",(void*)f_11242},
{"f_11248:regex_scm",(void*)f_11248},
{"f_11246:regex_scm",(void*)f_11246},
{"f_10572:regex_scm",(void*)f_10572},
{"f_10549:regex_scm",(void*)f_10549},
{"f_10553:regex_scm",(void*)f_10553},
{"f_10520:regex_scm",(void*)f_10520},
{"f_11416:regex_scm",(void*)f_11416},
{"f_11358:regex_scm",(void*)f_11358},
{"f_11328:regex_scm",(void*)f_11328},
{"f_11346:regex_scm",(void*)f_11346},
{"f_11332:regex_scm",(void*)f_11332},
{"f_11324:regex_scm",(void*)f_11324},
{"f_10820:regex_scm",(void*)f_10820},
{"f_10938:regex_scm",(void*)f_10938},
{"f_10930:regex_scm",(void*)f_10930},
{"f_10922:regex_scm",(void*)f_10922},
{"f_10890:regex_scm",(void*)f_10890},
{"f_10918:regex_scm",(void*)f_10918},
{"f_10886:regex_scm",(void*)f_10886},
{"f_10842:regex_scm",(void*)f_10842},
{"f_10840:regex_scm",(void*)f_10840},
{"f_10692:regex_scm",(void*)f_10692},
{"f_10810:regex_scm",(void*)f_10810},
{"f_10802:regex_scm",(void*)f_10802},
{"f_10794:regex_scm",(void*)f_10794},
{"f_10762:regex_scm",(void*)f_10762},
{"f_10790:regex_scm",(void*)f_10790},
{"f_10758:regex_scm",(void*)f_10758},
{"f_10714:regex_scm",(void*)f_10714},
{"f_10712:regex_scm",(void*)f_10712},
{"f_10606:regex_scm",(void*)f_10606},
{"f_10640:regex_scm",(void*)f_10640},
{"f_10648:regex_scm",(void*)f_10648},
{"f_10658:regex_scm",(void*)f_10658},
{"f_10656:regex_scm",(void*)f_10656},
{"f_10652:regex_scm",(void*)f_10652},
{"f_10636:regex_scm",(void*)f_10636},
{"f_10330:regex_scm",(void*)f_10330},
{"f_10454:regex_scm",(void*)f_10454},
{"f_10418:regex_scm",(void*)f_10418},
{"f_10450:regex_scm",(void*)f_10450},
{"f_10446:regex_scm",(void*)f_10446},
{"f_10422:regex_scm",(void*)f_10422},
{"f_10442:regex_scm",(void*)f_10442},
{"f_10438:regex_scm",(void*)f_10438},
{"f_10426:regex_scm",(void*)f_10426},
{"f_10434:regex_scm",(void*)f_10434},
{"f_10430:regex_scm",(void*)f_10430},
{"f_10405:regex_scm",(void*)f_10405},
{"f_10381:regex_scm",(void*)f_10381},
{"f_10401:regex_scm",(void*)f_10401},
{"f_10397:regex_scm",(void*)f_10397},
{"f_10385:regex_scm",(void*)f_10385},
{"f_10393:regex_scm",(void*)f_10393},
{"f_10389:regex_scm",(void*)f_10389},
{"f_10368:regex_scm",(void*)f_10368},
{"f_10356:regex_scm",(void*)f_10356},
{"f_10364:regex_scm",(void*)f_10364},
{"f_10360:regex_scm",(void*)f_10360},
{"f_10270:regex_scm",(void*)f_10270},
{"f_10045:regex_scm",(void*)f_10045},
{"f_10220:regex_scm",(void*)f_10220},
{"f_10172:regex_scm",(void*)f_10172},
{"f_10208:regex_scm",(void*)f_10208},
{"f_10176:regex_scm",(void*)f_10176},
{"f_10196:regex_scm",(void*)f_10196},
{"f_10180:regex_scm",(void*)f_10180},
{"f_10184:regex_scm",(void*)f_10184},
{"f_10168:regex_scm",(void*)f_10168},
{"f_10151:regex_scm",(void*)f_10151},
{"f_10119:regex_scm",(void*)f_10119},
{"f_10139:regex_scm",(void*)f_10139},
{"f_10123:regex_scm",(void*)f_10123},
{"f_10127:regex_scm",(void*)f_10127},
{"f_10115:regex_scm",(void*)f_10115},
{"f_10098:regex_scm",(void*)f_10098},
{"f_10082:regex_scm",(void*)f_10082},
{"f_10086:regex_scm",(void*)f_10086},
{"f_10048:regex_scm",(void*)f_10048},
{"f_10035:regex_scm",(void*)f_10035},
{"f_10025:regex_scm",(void*)f_10025},
{"f_9233:regex_scm",(void*)f_9233},
{"f_9300:regex_scm",(void*)f_9300},
{"f_9303:regex_scm",(void*)f_9303},
{"f_5383:regex_scm",(void*)f_5383},
{"f_9252:regex_scm",(void*)f_9252},
{"f_9264:regex_scm",(void*)f_9264},
{"f_9267:regex_scm",(void*)f_9267},
{"f_9191:regex_scm",(void*)f_9191},
{"f_6282:regex_scm",(void*)f_6282},
{"f_6289:regex_scm",(void*)f_6289},
{"f_6294:regex_scm",(void*)f_6294},
{"f_9140:regex_scm",(void*)f_9140},
{"f_9143:regex_scm",(void*)f_9143},
{"f_9161:regex_scm",(void*)f_9161},
{"f_9106:regex_scm",(void*)f_9106},
{"f_9121:regex_scm",(void*)f_9121},
{"f_9094:regex_scm",(void*)f_9094},
{"f_9091:regex_scm",(void*)f_9091},
{"f_9063:regex_scm",(void*)f_9063},
{"f_9060:regex_scm",(void*)f_9060},
{"f_9032:regex_scm",(void*)f_9032},
{"f_8999:regex_scm",(void*)f_8999},
{"f_8981:regex_scm",(void*)f_8981},
{"f_5441:regex_scm",(void*)f_5441},
{"f_8889:regex_scm",(void*)f_8889},
{"f_8932:regex_scm",(void*)f_8932},
{"f_8925:regex_scm",(void*)f_8925},
{"f_8921:regex_scm",(void*)f_8921},
{"f_8913:regex_scm",(void*)f_8913},
{"f_8909:regex_scm",(void*)f_8909},
{"f_8775:regex_scm",(void*)f_8775},
{"f_8784:regex_scm",(void*)f_8784},
{"f_8846:regex_scm",(void*)f_8846},
{"f_8691:regex_scm",(void*)f_8691},
{"f_8694:regex_scm",(void*)f_8694},
{"f_8697:regex_scm",(void*)f_8697},
{"f_8747:regex_scm",(void*)f_8747},
{"f_8744:regex_scm",(void*)f_8744},
{"f_8736:regex_scm",(void*)f_8736},
{"f_8732:regex_scm",(void*)f_8732},
{"f_8666:regex_scm",(void*)f_8666},
{"f_8638:regex_scm",(void*)f_8638},
{"f_8662:regex_scm",(void*)f_8662},
{"f_8658:regex_scm",(void*)f_8658},
{"f_8627:regex_scm",(void*)f_8627},
{"f_8623:regex_scm",(void*)f_8623},
{"f_8598:regex_scm",(void*)f_8598},
{"f_8594:regex_scm",(void*)f_8594},
{"f_8569:regex_scm",(void*)f_8569},
{"f_8565:regex_scm",(void*)f_8565},
{"f_8540:regex_scm",(void*)f_8540},
{"f_8536:regex_scm",(void*)f_8536},
{"f_8511:regex_scm",(void*)f_8511},
{"f_8507:regex_scm",(void*)f_8507},
{"f_8478:regex_scm",(void*)f_8478},
{"f_8474:regex_scm",(void*)f_8474},
{"f_8441:regex_scm",(void*)f_8441},
{"f_8437:regex_scm",(void*)f_8437},
{"f_8412:regex_scm",(void*)f_8412},
{"f_8408:regex_scm",(void*)f_8408},
{"f_8375:regex_scm",(void*)f_8375},
{"f_8371:regex_scm",(void*)f_8371},
{"f_8322:regex_scm",(void*)f_8322},
{"f_8318:regex_scm",(void*)f_8318},
{"f_8277:regex_scm",(void*)f_8277},
{"f_8273:regex_scm",(void*)f_8273},
{"f_8240:regex_scm",(void*)f_8240},
{"f_8236:regex_scm",(void*)f_8236},
{"f_8207:regex_scm",(void*)f_8207},
{"f_8203:regex_scm",(void*)f_8203},
{"f_8174:regex_scm",(void*)f_8174},
{"f_8170:regex_scm",(void*)f_8170},
{"f_8141:regex_scm",(void*)f_8141},
{"f_8137:regex_scm",(void*)f_8137},
{"f_8071:regex_scm",(void*)f_8071},
{"f_7890:regex_scm",(void*)f_7890},
{"f_7900:regex_scm",(void*)f_7900},
{"f_7909:regex_scm",(void*)f_7909},
{"f_8053:regex_scm",(void*)f_8053},
{"f_5482:regex_scm",(void*)f_5482},
{"f_5527:regex_scm",(void*)f_5527},
{"f_5506:regex_scm",(void*)f_5506},
{"f_5485:regex_scm",(void*)f_5485},
{"f_5493:regex_scm",(void*)f_5493},
{"f_7912:regex_scm",(void*)f_7912},
{"f_7915:regex_scm",(void*)f_7915},
{"f_7921:regex_scm",(void*)f_7921},
{"f_8019:regex_scm",(void*)f_8019},
{"f_7984:regex_scm",(void*)f_7984},
{"f_7950:regex_scm",(void*)f_7950},
{"f_9344:regex_scm",(void*)f_9344},
{"f_10016:regex_scm",(void*)f_10016},
{"f_9346:regex_scm",(void*)f_9346},
{"f_9963:regex_scm",(void*)f_9963},
{"f_9981:regex_scm",(void*)f_9981},
{"f_9833:regex_scm",(void*)f_9833},
{"f_9890:regex_scm",(void*)f_9890},
{"f_9878:regex_scm",(void*)f_9878},
{"f_9863:regex_scm",(void*)f_9863},
{"f_9836:regex_scm",(void*)f_9836},
{"f_9859:regex_scm",(void*)f_9859},
{"f_9847:regex_scm",(void*)f_9847},
{"f_9855:regex_scm",(void*)f_9855},
{"f_9851:regex_scm",(void*)f_9851},
{"f_9700:regex_scm",(void*)f_9700},
{"f_9709:regex_scm",(void*)f_9709},
{"f_9752:regex_scm",(void*)f_9752},
{"f_9748:regex_scm",(void*)f_9748},
{"f_9715:regex_scm",(void*)f_9715},
{"f_9718:regex_scm",(void*)f_9718},
{"f_9741:regex_scm",(void*)f_9741},
{"f_9729:regex_scm",(void*)f_9729},
{"f_9737:regex_scm",(void*)f_9737},
{"f_9733:regex_scm",(void*)f_9733},
{"f_9648:regex_scm",(void*)f_9648},
{"f_9496:regex_scm",(void*)f_9496},
{"f_9576:regex_scm",(void*)f_9576},
{"f_9589:regex_scm",(void*)f_9589},
{"f_9599:regex_scm",(void*)f_9599},
{"f_9603:regex_scm",(void*)f_9603},
{"f_9559:regex_scm",(void*)f_9559},
{"f_9527:regex_scm",(void*)f_9527},
{"f_9385:regex_scm",(void*)f_9385},
{"f_9388:regex_scm",(void*)f_9388},
{"f_5987:regex_scm",(void*)f_5987},
{"f_6011:regex_scm",(void*)f_6011},
{"f_6008:regex_scm",(void*)f_6008},
{"f_9391:regex_scm",(void*)f_9391},
{"f_9464:regex_scm",(void*)f_9464},
{"f_9468:regex_scm",(void*)f_9468},
{"f_9460:regex_scm",(void*)f_9460},
{"f_9456:regex_scm",(void*)f_9456},
{"f_9411:regex_scm",(void*)f_9411},
{"f_9439:regex_scm",(void*)f_9439},
{"f_9421:regex_scm",(void*)f_9421},
{"f_18795:regex_scm",(void*)f_18795},
{"f_9432:regex_scm",(void*)f_9432},
{"f_9415:regex_scm",(void*)f_9415},
{"f_9398:regex_scm",(void*)f_9398},
{"f_7871:regex_scm",(void*)f_7871},
{"f_7847:regex_scm",(void*)f_7847},
{"f_7867:regex_scm",(void*)f_7867},
{"f_7832:regex_scm",(void*)f_7832},
{"f_7097:regex_scm",(void*)f_7097},
{"f_7101:regex_scm",(void*)f_7101},
{"f_7566:regex_scm",(void*)f_7566},
{"f_7751:regex_scm",(void*)f_7751},
{"f_7763:regex_scm",(void*)f_7763},
{"f_7730:regex_scm",(void*)f_7730},
{"f_7726:regex_scm",(void*)f_7726},
{"f_7681:regex_scm",(void*)f_7681},
{"f_7661:regex_scm",(void*)f_7661},
{"f_7644:regex_scm",(void*)f_7644},
{"f_7627:regex_scm",(void*)f_7627},
{"f_7578:regex_scm",(void*)f_7578},
{"f_7582:regex_scm",(void*)f_7582},
{"f_7585:regex_scm",(void*)f_7585},
{"f_7569:regex_scm",(void*)f_7569},
{"f_7524:regex_scm",(void*)f_7524},
{"f_7528:regex_scm",(void*)f_7528},
{"f_7467:regex_scm",(void*)f_7467},
{"f_7501:regex_scm",(void*)f_7501},
{"f_7470:regex_scm",(void*)f_7470},
{"f_7485:regex_scm",(void*)f_7485},
{"f_7493:regex_scm",(void*)f_7493},
{"f_7407:regex_scm",(void*)f_7407},
{"f_7450:regex_scm",(void*)f_7450},
{"f_7410:regex_scm",(void*)f_7410},
{"f_7434:regex_scm",(void*)f_7434},
{"f_7442:regex_scm",(void*)f_7442},
{"f_7379:regex_scm",(void*)f_7379},
{"f_7383:regex_scm",(void*)f_7383},
{"f_7287:regex_scm",(void*)f_7287},
{"f_7305:regex_scm",(void*)f_7305},
{"f_7325:regex_scm",(void*)f_7325},
{"f_7317:regex_scm",(void*)f_7317},
{"f_7313:regex_scm",(void*)f_7313},
{"f_7280:regex_scm",(void*)f_7280},
{"f_7284:regex_scm",(void*)f_7284},
{"f_7255:regex_scm",(void*)f_7255},
{"f_7259:regex_scm",(void*)f_7259},
{"f_7212:regex_scm",(void*)f_7212},
{"f_7216:regex_scm",(void*)f_7216},
{"f_7187:regex_scm",(void*)f_7187},
{"f_7191:regex_scm",(void*)f_7191},
{"f_7162:regex_scm",(void*)f_7162},
{"f_7166:regex_scm",(void*)f_7166},
{"f_7122:regex_scm",(void*)f_7122},
{"f_7137:regex_scm",(void*)f_7137},
{"f_7010:regex_scm",(void*)f_7010},
{"f_7016:regex_scm",(void*)f_7016},
{"f_7031:regex_scm",(void*)f_7031},
{"f_6813:regex_scm",(void*)f_6813},
{"f_6980:regex_scm",(void*)f_6980},
{"f_6951:regex_scm",(void*)f_6951},
{"f_6926:regex_scm",(void*)f_6926},
{"f_6909:regex_scm",(void*)f_6909},
{"f_6892:regex_scm",(void*)f_6892},
{"f_6867:regex_scm",(void*)f_6867},
{"f_6844:regex_scm",(void*)f_6844},
{"f_6804:regex_scm",(void*)f_6804},
{"f_6801:regex_scm",(void*)f_6801},
{"f_6739:regex_scm",(void*)f_6739},
{"f_6751:regex_scm",(void*)f_6751},
{"f_6439:regex_scm",(void*)f_6439},
{"f_6443:regex_scm",(void*)f_6443},
{"f_6737:regex_scm",(void*)f_6737},
{"f_6446:regex_scm",(void*)f_6446},
{"f_6699:regex_scm",(void*)f_6699},
{"f_6710:regex_scm",(void*)f_6710},
{"f_6449:regex_scm",(void*)f_6449},
{"f_6692:regex_scm",(void*)f_6692},
{"f_6681:regex_scm",(void*)f_6681},
{"f_6452:regex_scm",(void*)f_6452},
{"f_6457:regex_scm",(void*)f_6457},
{"f_6621:regex_scm",(void*)f_6621},
{"f_6559:regex_scm",(void*)f_6559},
{"f_6526:regex_scm",(void*)f_6526},
{"f_6460:regex_scm",(void*)f_6460},
{"f_6367:regex_scm",(void*)f_6367},
{"f_6371:regex_scm",(void*)f_6371},
{"f_10235:regex_scm",(void*)f_10235},
{"f_6374:regex_scm",(void*)f_6374},
{"f_6411:regex_scm",(void*)f_6411},
{"f_6383:regex_scm",(void*)f_6383},
{"f_6407:regex_scm",(void*)f_6407},
{"f_6403:regex_scm",(void*)f_6403},
{"f_6347:regex_scm",(void*)f_6347},
{"f_6365:regex_scm",(void*)f_6365},
{"f_6361:regex_scm",(void*)f_6361},
{"f_6327:regex_scm",(void*)f_6327},
{"f_6334:regex_scm",(void*)f_6334},
{"f_6345:regex_scm",(void*)f_6345},
{"f_6341:regex_scm",(void*)f_6341},
{"f_6297:regex_scm",(void*)f_6297},
{"f_6322:regex_scm",(void*)f_6322},
{"f_6182:regex_scm",(void*)f_6182},
{"f_6188:regex_scm",(void*)f_6188},
{"f_6219:regex_scm",(void*)f_6219},
{"f_6213:regex_scm",(void*)f_6213},
{"f_6206:regex_scm",(void*)f_6206},
{"f_6163:regex_scm",(void*)f_6163},
{"f_6154:regex_scm",(void*)f_6154},
{"f_6144:regex_scm",(void*)f_6144},
{"f_6152:regex_scm",(void*)f_6152},
{"f_6097:regex_scm",(void*)f_6097},
{"f_6129:regex_scm",(void*)f_6129},
{"f_6133:regex_scm",(void*)f_6133},
{"f_6125:regex_scm",(void*)f_6125},
{"f_6050:regex_scm",(void*)f_6050},
{"f_6082:regex_scm",(void*)f_6082},
{"f_6086:regex_scm",(void*)f_6086},
{"f_6078:regex_scm",(void*)f_6078},
{"f_6034:regex_scm",(void*)f_6034},
{"f_6042:regex_scm",(void*)f_6042},
{"f_6024:regex_scm",(void*)f_6024},
{"f_6032:regex_scm",(void*)f_6032},
{"f_5938:regex_scm",(void*)f_5938},
{"f_5944:regex_scm",(void*)f_5944},
{"f_5968:regex_scm",(void*)f_5968},
{"f_5965:regex_scm",(void*)f_5965},
{"f_5908:regex_scm",(void*)f_5908},
{"f_5914:regex_scm",(void*)f_5914},
{"f_5932:regex_scm",(void*)f_5932},
{"f_5859:regex_scm",(void*)f_5859},
{"f_5879:regex_scm",(void*)f_5879},
{"f_5895:regex_scm",(void*)f_5895},
{"f_5810:regex_scm",(void*)f_5810},
{"f_5830:regex_scm",(void*)f_5830},
{"f_5843:regex_scm",(void*)f_5843},
{"f_5768:regex_scm",(void*)f_5768},
{"f_5783:regex_scm",(void*)f_5783},
{"f_5736:regex_scm",(void*)f_5736},
{"f_5742:regex_scm",(void*)f_5742},
{"f_5755:regex_scm",(void*)f_5755},
{"f_5724:regex_scm",(void*)f_5724},
{"f_5728:regex_scm",(void*)f_5728},
{"f_5681:regex_scm",(void*)f_5681},
{"f_5687:regex_scm",(void*)f_5687},
{"f_5694:regex_scm",(void*)f_5694},
{"f_5642:regex_scm",(void*)f_5642},
{"f_5658:regex_scm",(void*)f_5658},
{"f_5585:regex_scm",(void*)f_5585},
{"f_5595:regex_scm",(void*)f_5595},
{"f_5593:regex_scm",(void*)f_5593},
{"f_5609:regex_scm",(void*)f_5609},
{"f_5614:regex_scm",(void*)f_5614},
{"f_5558:regex_scm",(void*)f_5558},
{"f_5633:regex_scm",(void*)f_5633},
{"f_5612:regex_scm",(void*)f_5612},
{"f_5540:regex_scm",(void*)f_5540},
{"f_5325:regex_scm",(void*)f_5325},
{"f_5338:regex_scm",(void*)f_5338},
{"f_5310:regex_scm",(void*)f_5310},
{"f_5318:regex_scm",(void*)f_5318},
{"f_5287:regex_scm",(void*)f_5287},
{"f_5291:regex_scm",(void*)f_5291},
{"f_5244:regex_scm",(void*)f_5244},
{"f_5248:regex_scm",(void*)f_5248},
{"f_5261:regex_scm",(void*)f_5261},
{"f_5212:regex_scm",(void*)f_5212},
{"f_5166:regex_scm",(void*)f_5166},
{"f_5152:regex_scm",(void*)f_5152},
{"f_5138:regex_scm",(void*)f_5138},
{"f_5124:regex_scm",(void*)f_5124},
{"f_5110:regex_scm",(void*)f_5110},
{"f_5104:regex_scm",(void*)f_5104},
{"f_5092:regex_scm",(void*)f_5092},
{"f_5074:regex_scm",(void*)f_5074},
{"f_5082:regex_scm",(void*)f_5082},
{"f_5021:regex_scm",(void*)f_5021},
{"f_4987:regex_scm",(void*)f_4987},
{"f_4997:regex_scm",(void*)f_4997},
{"f_4973:regex_scm",(void*)f_4973},
{"f_4981:regex_scm",(void*)f_4981},
{"f_4985:regex_scm",(void*)f_4985},
{"f_5051:regex_scm",(void*)f_5051},
{"f_4967:regex_scm",(void*)f_4967},
{"f_4961:regex_scm",(void*)f_4961},
{"f_4955:regex_scm",(void*)f_4955},
{"f_4949:regex_scm",(void*)f_4949},
{"f_4943:regex_scm",(void*)f_4943},
{"f_4937:regex_scm",(void*)f_4937},
{"f_4931:regex_scm",(void*)f_4931},
{"f_4925:regex_scm",(void*)f_4925},
{"f_4899:regex_scm",(void*)f_4899},
{"f_4893:regex_scm",(void*)f_4893},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
