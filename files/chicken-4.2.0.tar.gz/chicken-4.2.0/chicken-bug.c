/* Generated from chicken-bug.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:29
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: chicken-bug.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -output-file chicken-bug.c
   used units: library eval data_structures ports extras srfi_69 srfi_13 posix tcp data_structures utils extras
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[149];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_348)
static void C_ccall f_348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_351)
static void C_ccall f_351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_354)
static void C_ccall f_354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_357)
static void C_ccall f_357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_360)
static void C_ccall f_360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_363)
static void C_ccall f_363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_366)
static void C_ccall f_366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_369)
static void C_ccall f_369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_372)
static void C_ccall f_372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_375)
static void C_ccall f_375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_378)
static void C_ccall f_378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_381)
static void C_ccall f_381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1177)
static void C_ccall f_1177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1189)
static void C_fcall f_1189(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1199)
static void C_ccall f_1199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1220)
static void C_ccall f_1220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1226)
static void C_ccall f_1226(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1284)
static void C_ccall f_1284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1280)
static void C_ccall f_1280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1268)
static void C_ccall f_1268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1264)
static void C_ccall f_1264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1248)
static void C_ccall f_1248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1254)
static void C_ccall f_1254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1257)
static void C_ccall f_1257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1202)
static void C_ccall f_1202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1205)
static void C_ccall f_1205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1156)
static void C_ccall f_1156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1166)
static void C_ccall f_1166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1169)
static void C_ccall f_1169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1087)
static void C_ccall f_1087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1102)
static void C_ccall f_1102(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1144)
static void C_ccall f_1144(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1144)
static void C_ccall f_1144r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1150)
static void C_ccall f_1150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1138)
static void C_ccall f_1138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1108)
static void C_ccall f_1108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1124)
static void C_ccall f_1124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1100)
static void C_ccall f_1100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1091)
static void C_ccall f_1091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1001)
static void C_ccall f_1001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1033)
static void C_ccall f_1033(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1063)
static void C_ccall f_1063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1075)
static void C_ccall f_1075(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1075)
static void C_ccall f_1075r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1081)
static void C_ccall f_1081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1069)
static void C_ccall f_1069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1039)
static void C_ccall f_1039(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1045)
static void C_ccall f_1045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1052)
static void C_ccall f_1052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1005)
static void C_ccall f_1005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1021)
static void C_ccall f_1021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_995)
static void C_ccall f_995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_795)
static void C_ccall f_795(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_806)
static void C_fcall f_806(C_word t0,C_word t1) C_noret;
C_noret_decl(f_938)
static void C_ccall f_938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_817)
static void C_fcall f_817(C_word t0,C_word t1) C_noret;
C_noret_decl(f_821)
static void C_ccall f_821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_853)
static void C_ccall f_853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_825)
static void C_ccall f_825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_845)
static void C_ccall f_845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_829)
static void C_ccall f_829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_837)
static void C_ccall f_837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_833)
static void C_ccall f_833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_754)
static void C_ccall f_754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_779)
static void C_ccall f_779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_772)
static void C_ccall f_772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_764)
static void C_ccall f_764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_767)
static void C_ccall f_767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_630)
static void C_ccall f_630(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_711)
static void C_ccall f_711(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_752)
static void C_ccall f_752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_748)
static void C_ccall f_748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_727)
static void C_ccall f_727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_723)
static void C_ccall f_723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_634)
static void C_ccall f_634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_709)
static void C_ccall f_709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_705)
static void C_ccall f_705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_637)
static void C_fcall f_637(C_word t0,C_word t1) C_noret;
C_noret_decl(f_640)
static void C_ccall f_640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_701)
static void C_ccall f_701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_643)
static void C_ccall f_643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_693)
static void C_ccall f_693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_697)
static void C_ccall f_697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_668)
static void C_ccall f_668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_672)
static void C_ccall f_672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_678)
static void C_ccall f_678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_682)
static void C_ccall f_682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_676)
static void C_ccall f_676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_658)
static void C_ccall f_658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_611)
static void C_ccall f_611(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_615)
static void C_ccall f_615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_592)
static void C_ccall f_592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_609)
static void C_ccall f_609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_602)
static void C_ccall f_602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_596)
static void C_ccall f_596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_583)
static void C_ccall f_583(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_587)
static void C_ccall f_587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_397)
static void C_ccall f_397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_401)
static void C_ccall f_401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_404)
static void C_ccall f_404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_581)
static void C_ccall f_581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_577)
static void C_ccall f_577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_407)
static void C_ccall f_407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_573)
static void C_ccall f_573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_410)
static void C_ccall f_410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_413)
static void C_ccall f_413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_569)
static void C_ccall f_569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_416)
static void C_ccall f_416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_565)
static void C_ccall f_565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_419)
static void C_ccall f_419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_561)
static void C_ccall f_561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_422)
static void C_ccall f_422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_557)
static void C_ccall f_557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_425)
static void C_ccall f_425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_553)
static void C_ccall f_553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_428)
static void C_ccall f_428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_549)
static void C_ccall f_549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_431)
static void C_ccall f_431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_434)
static void C_ccall f_434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_437)
static void C_ccall f_437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_545)
static void C_ccall f_545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_541)
static void C_ccall f_541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_537)
static void C_ccall f_537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_504)
static void C_ccall f_504(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_508)
static void C_ccall f_508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_513)
static void C_ccall f_513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_521)
static void C_ccall f_521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_440)
static void C_ccall f_440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_443)
static void C_ccall f_443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_502)
static void C_ccall f_502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_488)
static void C_ccall f_488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_490)
static void C_ccall f_490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_498)
static void C_ccall f_498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_446)
static void C_ccall f_446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_449)
static void C_ccall f_449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_484)
static void C_ccall f_484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_458)
static void C_ccall f_458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_461)
static void C_ccall f_461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_466)
static void C_ccall f_466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_474)
static void C_ccall f_474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_452)
static void C_ccall f_452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_387)
static void C_ccall f_387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1189)
static void C_fcall trf_1189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1189(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1189(t0,t1,t2);}

C_noret_decl(trf_806)
static void C_fcall trf_806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_806(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_806(t0,t1);}

C_noret_decl(trf_817)
static void C_fcall trf_817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_817(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_817(t0,t1);}

C_noret_decl(trf_637)
static void C_fcall trf_637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_637(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_637(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(666)){
C_save(t1);
C_rereclaim2(666*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,149);
lf[0]=C_h_intern(&lf[0],7,"user-id");
lf[1]=C_h_intern(&lf[1],16,"user-information");
lf[2]=C_h_intern(&lf[2],15,"current-user-id");
lf[3]=C_h_intern(&lf[3],12,"collect-info");
lf[4]=C_h_intern(&lf[4],7,"newline");
lf[5]=C_h_intern(&lf[5],7,"display");
lf[6]=C_h_intern(&lf[6],8,"read-all");
lf[7]=C_h_intern(&lf[7],20,"with-input-from-pipe");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\013gcc -v 2>&1");
lf[9]=C_h_intern(&lf[9],5,"print");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\0000CC seems to be gcc, trying to obtain version...\012");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\003gcc");
lf[12]=C_h_intern(&lf[12],8,"feature\077");
lf[13]=C_h_intern(&lf[13],4,"unix");
lf[14]=C_h_intern(&lf[14],17,"\003syspeek-c-string");
lf[15]=C_h_intern(&lf[15],20,"with-input-from-file");
lf[16]=C_h_intern(&lf[16],13,"make-pathname");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-config.h");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\024\012\012chicken-config.h:\012");
lf[19]=C_h_intern(&lf[19],6,"printf");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[21]=C_h_intern(&lf[21],11,"make-string");
lf[22]=C_h_intern(&lf[22],12,"\003sysfor-each");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[24]=C_h_intern(&lf[24],4,"chop");
lf[25]=C_h_intern(&lf[25],4,"sort");
lf[26]=C_h_intern(&lf[26],8,"string<\077");
lf[27]=C_h_intern(&lf[27],7,"\003sysmap");
lf[28]=C_h_intern(&lf[28],15,"keyword->string");
lf[29]=C_h_intern(&lf[29],12,"\003sysfeatures");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\024Include path:\011~s~%~%");
lf[32]=C_h_intern(&lf[32],21,"\003sysinclude-pathnames");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\020Home directory:\011");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[35]=C_h_intern(&lf[35],12,"chicken-home");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN version is:\012");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[38]=C_h_intern(&lf[38],15,"chicken-version");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\021\011build platform:\011");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[41]=C_h_intern(&lf[41],14,"build-platform");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\023\011software version:\011");
lf[43]=C_h_intern(&lf[43],16,"software-version");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\020\011software type:\011");
lf[45]=C_h_intern(&lf[45],13,"software-type");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\017\011machine type:\011");
lf[47]=C_h_intern(&lf[47],12,"machine-type");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\022Host information:\012");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\030User information:\011~s~%~%");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\006Date:\011");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[52]=C_h_intern(&lf[52],15,"seconds->string");
lf[53]=C_h_intern(&lf[53],15,"current-seconds");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\0002This is a bug report generated by chicken-bug(1).\012");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\0004\012--------------------------------------------------\012");
lf[56]=C_h_intern(&lf[56],5,"usage");
lf[57]=C_h_intern(&lf[57],4,"exit");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\0017usage: chicken-bug [FILENAME ...]\012\012  -help  -h            show this message"
"\012  -to-stdout           write bug report to standard output\012  -                 "
"   read description from standard input\012\012Generates a bug report file from user i"
"nput or alternatively\012from the contents of files given on the command line.\012");
lf[59]=C_h_intern(&lf[59],10,"user-input");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\001VThis is the CHICKEN bug report generator. Please enter a detailed\012descripti"
"on of the problem you have encountered and enter CTRL-D (EOF)\012once you have fini"
"shed. Press CTRL-C to abort the program. You can\012also pass the description from "
"a file (just abort now and re-invoke\012\042chicken-bug\042 with one or more input files "
"given on the command-line)\012");
lf[61]=C_h_intern(&lf[61],13,"\003systty-port\077");
lf[62]=C_h_intern(&lf[62],18,"current-input-port");
lf[63]=C_h_intern(&lf[63],7,"justify");
lf[64]=C_h_intern(&lf[64],13,"string-append");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[66]=C_h_intern(&lf[66],4,"main");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[68]=C_h_intern(&lf[68],8,"try-mail");
lf[69]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014mx10.gnu.org\376\003\000\000\002\376B\000\000\014mx20.gnu.org\376\377\016");
lf[70]=C_h_intern(&lf[70],21,"with-output-to-string");
lf[71]=C_h_intern(&lf[71],12,"mail-headers");
lf[72]=C_h_intern(&lf[72],7,"sprintf");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\033chicken-bug-report.~a-~a-~a");
lf[74]=C_h_intern(&lf[74],19,"seconds->local-time");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\017\012\012User input:\012\012");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\012-to-stdout");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\016\012\012File added: ");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000!one of the following addresses:\012\012");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000Ochicken-janitors@nongnu.org\012chicken-hackers@nongnu.org\012chicken-users@nongnu"
".org");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000G\012Could not send mail automatically!\012\012A bug report has been written to `");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\025\047.  Please send it to");
lf[88]=C_h_intern(&lf[88],19,"with-output-to-file");
lf[89]=C_h_intern(&lf[89],9,"send-mail");
lf[90]=C_h_intern(&lf[90],13,"mail-date-str");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\006 +0000");
lf[95]=C_h_intern(&lf[95],10,"string-pad");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jan ");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\005 Feb ");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\005 Mar ");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\005 Apr ");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\005 May ");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jun ");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jul ");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\005 Aug ");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\005 Sep ");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\005 Oct ");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\005 Nov ");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\005 Dec ");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\005Sun, ");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\005Mon, ");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\005Tue, ");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\005Wed, ");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\005Thu, ");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\005Fri, ");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\005Sat, ");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\006Date: ");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000;From: \042chicken-bug user\042 <chicken-bug-command@callcc.org>\015\012");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\0006To: \042Chicken Janitors\042 <chicken-janitors@nongnu.org>\015\012");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000)Subject: Automated chicken-bug output -- ");
lf[120]=C_h_intern(&lf[120],17,"seconds->utc-time");
lf[121]=C_h_intern(&lf[121],9,"mail-read");
lf[122]=C_h_intern(&lf[122],9,"substring");
lf[123]=C_h_intern(&lf[123],9,"condition");
lf[124]=C_h_intern(&lf[124],17,"close-output-port");
lf[125]=C_h_intern(&lf[125],16,"close-input-port");
lf[126]=C_h_intern(&lf[126],9,"read-line");
lf[127]=C_h_intern(&lf[127],22,"with-exception-handler");
lf[128]=C_h_intern(&lf[128],30,"call-with-current-continuation");
lf[129]=C_h_intern(&lf[129],10,"mail-write");
lf[130]=C_h_intern(&lf[130],10,"mail-check");
lf[131]=C_h_intern(&lf[131],4,"add1");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\010 failed.");
lf[133]=C_h_intern(&lf[133],11,"tcp-connect");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000Vok.\012\012Bug report successfully mailed to the Chicken maintainers.\012Thank you v"
"ery much!\012\012");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\004QUIT");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\004\015\012\015\012");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\005\015\012.\015\012");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\006DATA\015\012");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\047RCPT TO:<chicken-janitors@nongnu.org>\015\012");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000,MAIL FROM:<chicken-bug-command@callcc.org>\015\012");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\021HELO callcc.org\015\012");
lf[142]=C_h_intern(&lf[142],6,"print*");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\016connecting to ");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\007, try #");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[146]=C_h_intern(&lf[146],7,"call/cc");
lf[147]=C_h_intern(&lf[147],25,"\003sysimplicit-exit-handler");
lf[148]=C_h_intern(&lf[148],22,"command-line-arguments");
C_register_lf2(lf,149,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_348,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k346 */
static void C_ccall f_348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_351,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k349 in k346 */
static void C_ccall f_351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_354,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k352 in k349 in k346 */
static void C_ccall f_354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_357,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k355 in k352 in k349 in k346 */
static void C_ccall f_357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_360,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_363,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_366,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_369,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_372,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_375,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_378,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_381,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_381,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! user-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_387,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! collect-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_397,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[56]+1 /* (set! usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_583,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[59]+1 /* (set! user-input ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_592,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[63]+1 /* (set! justify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_611,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[66]+1 /* (set! main ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_630,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[68]+1 /* (set! try-mail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_754,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[90]+1 /* (set! mail-date-str ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_795,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[71]+1 /* (set! mail-headers ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_983,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[121]+1 /* (set! mail-read ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1001,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[129]+1 /* (set! mail-write ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1087,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[130]+1 /* (set! mail-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1156,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[89]+1 /* (set! send-mail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1177,tmp=(C_word)a,a+=2,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1291,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1301,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 264  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[148]))(2,*((C_word*)lf[148]+1),t16);}

/* k1299 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 264  main */
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),((C_word*)t0)[2],t1);}

/* k1289 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1297,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[147]))(2,*((C_word*)lf[147]+1),t3);}

/* k1295 in k1289 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1292 in k1289 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1177,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1183,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 242  call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[146]+1)))(3,*((C_word*)lf[146]+1),t1,t6);}

/* a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1183,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_1189(t6,t1,C_fix(1));}

/* doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_fcall f_1189(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1189,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(3)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1199,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* chicken-bug.scm: 246  print* */
((C_proc7)C_retrieve_proc(*((C_word*)lf[142]+1)))(7,*((C_word*)lf[142]+1),t3,lf[143],((C_word*)t0)[6],lf[144],t2,lf[145]);}}

/* k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1202,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1214,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1220,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1226,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-bug.scm: 249  call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[128]+1)))(3,*((C_word*)lf[128]+1),t1,t4);}

/* a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1226(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1226,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1288,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 251  mail-read */
((C_proc4)C_retrieve_symbol_proc(lf[121]))(4,*((C_word*)lf[121]+1),t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k1286 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 251  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[130]))(7,*((C_word*)lf[130]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(220),((C_word*)t0)[2]);}

/* k1228 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1284,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 252  mail-write */
((C_proc5)C_retrieve_symbol_proc(lf[129]))(5,*((C_word*)lf[129]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[141]);}

/* k1282 in k1228 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 252  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[130]))(7,*((C_word*)lf[130]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1231 in k1228 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1280,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 253  mail-write */
((C_proc5)C_retrieve_symbol_proc(lf[129]))(5,*((C_word*)lf[129]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[140]);}

/* k1278 in k1231 in k1228 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 253  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[130]))(7,*((C_word*)lf[130]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1234 in k1231 in k1228 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1276,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 254  mail-write */
((C_proc5)C_retrieve_symbol_proc(lf[129]))(5,*((C_word*)lf[129]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[139]);}

/* k1274 in k1234 in k1231 in k1228 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 254  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[130]))(7,*((C_word*)lf[130]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1237 in k1234 in k1231 in k1228 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1272,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 255  mail-write */
((C_proc5)C_retrieve_symbol_proc(lf[129]))(5,*((C_word*)lf[129]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[138]);}

/* k1270 in k1237 in k1234 in k1231 in k1228 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 255  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[130]))(7,*((C_word*)lf[130]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(354),((C_word*)t0)[2]);}

/* k1240 in k1237 in k1234 in k1231 in k1228 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1245,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1264,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1268,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 256  string-append */
((C_proc7)C_retrieve_proc(*((C_word*)lf[64]+1)))(7,*((C_word*)lf[64]+1),t4,((C_word*)t0)[4],((C_word*)t0)[3],lf[136],((C_word*)t0)[2],lf[137]);}

/* k1266 in k1240 in k1237 in k1234 in k1231 in k1228 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 256  mail-write */
((C_proc5)C_retrieve_symbol_proc(lf[129]))(5,*((C_word*)lf[129]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1262 in k1240 in k1237 in k1234 in k1231 in k1228 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 256  mail-check */
((C_proc7)C_retrieve_symbol_proc(lf[130]))(7,*((C_word*)lf[130]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1243 in k1240 in k1237 in k1234 in k1231 in k1228 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 257  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t2,lf[135],((C_word*)t0)[3]);}

/* k1246 in k1243 in k1240 in k1237 in k1234 in k1231 in k1228 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1251,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 258  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[125]+1)))(3,*((C_word*)lf[125]+1),t2,((C_word*)t0)[2]);}

/* k1249 in k1246 in k1243 in k1240 in k1237 in k1234 in k1231 in k1228 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1254,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 259  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[124]+1)))(3,*((C_word*)lf[124]+1),t2,((C_word*)t0)[2]);}

/* k1252 in k1249 in k1246 in k1243 in k1240 in k1237 in k1234 in k1231 in k1228 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 260  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,lf[134]);}

/* k1255 in k1252 in k1249 in k1246 in k1243 in k1240 in k1237 in k1234 in k1231 in k1228 in a1225 in a1219 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 261  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* a1213 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1214,2,t0,t1);}
/* chicken-bug.scm: 248  tcp-connect */
((C_proc4)C_retrieve_symbol_proc(lf[133]))(4,*((C_word*)lf[133]+1),t1,((C_word*)t0)[2],C_fix(25));}

/* k1200 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 262  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,lf[132]);}

/* k1203 in k1200 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1212,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 244  add1 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[131]+1)))(3,*((C_word*)lf[131]+1),t2,((C_word*)t0)[2]);}

/* k1210 in k1203 in k1200 in k1197 in doloop278 in a1182 in send-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1189(t2,((C_word*)t0)[2],t1);}

/* mail-check in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_1156,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t4)?(C_word)C_i_nequalp(t4,t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1166,a[2]=t3,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 237  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[125]+1)))(3,*((C_word*)lf[125]+1),t8,t2);}}

/* k1164 in mail-check in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 238  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[124]+1)))(3,*((C_word*)lf[124]+1),t2,((C_word*)t0)[2]);}

/* k1167 in k1164 in mail-check in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 239  k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* mail-write in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1087,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1091,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1100,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1102,a[2]=t4,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[128]+1)))(3,*((C_word*)lf[128]+1),t6,t7);}

/* a1101 in mail-write in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1102(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1102,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1108,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1132,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[127]))(4,*((C_word*)lf[127]+1),t1,t3,t4);}

/* a1131 in a1101 in mail-write in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1138,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1144,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1143 in a1131 in a1101 in mail-write in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1144(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1144r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1144r(t0,t1,t2);}}

static void C_ccall f_1144r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1150,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k227232 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1149 in a1143 in a1131 in a1101 in mail-write in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1150,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1137 in a1131 in a1101 in mail-write in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1138,2,t0,t1);}
/* chicken-bug.scm: 227  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1107 in a1101 in mail-write in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1108,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1114,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* k227232 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1113 in a1107 in a1101 in mail-write in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1114,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[4],lf[123]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1121,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 228  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[125]+1)))(3,*((C_word*)lf[125]+1),t4,((C_word*)t0)[2]);}

/* k1119 in a1113 in a1107 in a1101 in mail-write in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1124,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 228  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[124]+1)))(3,*((C_word*)lf[124]+1),t2,((C_word*)t0)[2]);}

/* k1122 in k1119 in a1113 in a1107 in a1101 in mail-write in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k1098 in mail-write in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1089 in mail-write in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-bug.scm: 230  mail-read */
((C_proc4)C_retrieve_symbol_proc(lf[121]))(4,*((C_word*)lf[121]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* mail-read in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1001,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1005,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1031,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1033,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[128]+1)))(3,*((C_word*)lf[128]+1),t5,t6);}

/* a1032 in mail-read in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1033(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1033,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1039,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1063,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[127]))(4,*((C_word*)lf[127]+1),t1,t3,t4);}

/* a1062 in a1032 in mail-read in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1069,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1075,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1074 in a1062 in a1032 in mail-read in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1075(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1075r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1075r(t0,t1,t2);}}

static void C_ccall f_1075r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1081,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k181186 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1080 in a1074 in a1062 in a1032 in mail-read in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1081,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1068 in a1062 in a1032 in mail-read in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1069,2,t0,t1);}
/* chicken-bug.scm: 218  read-line */
((C_proc3)C_retrieve_symbol_proc(lf[126]))(3,*((C_word*)lf[126]+1),t1,((C_word*)t0)[2]);}

/* a1038 in a1032 in mail-read in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1039(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1039,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1045,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* k181186 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1044 in a1038 in a1032 in mail-read in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1045,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[4],lf[123]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1052,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 219  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[125]+1)))(3,*((C_word*)lf[125]+1),t4,((C_word*)t0)[2]);}

/* k1050 in a1044 in a1038 in a1032 in mail-read in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1055,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 219  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[124]+1)))(3,*((C_word*)lf[124]+1),t2,((C_word*)t0)[2]);}

/* k1053 in k1050 in a1044 in a1038 in a1032 in mail-read in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k1029 in mail-read in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1003 in mail-read in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1005,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(t1,C_fix(0));
if(C_truep((C_word)C_u_i_char_numericp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1021,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 222  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[122]+1)))(5,*((C_word*)lf[122]+1),t3,t1,C_fix(0),C_fix(3));}
else{
/* chicken-bug.scm: 223  mail-read */
((C_proc4)C_retrieve_symbol_proc(lf[121]))(4,*((C_word*)lf[121]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1019 in k1003 in mail-read in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_1021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 222  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* mail-headers in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_991,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_995,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_999,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 212  current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[53]))(2,*((C_word*)lf[53]+1),t4);}

/* k997 in mail-headers in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 212  seconds->utc-time */
((C_proc3)C_retrieve_symbol_proc(lf[120]))(3,*((C_word*)lf[120]+1),((C_word*)t0)[2],t1);}

/* k993 in mail-headers in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 212  mail-date-str */
((C_proc3)C_retrieve_symbol_proc(lf[90]))(3,*((C_word*)lf[90]+1),((C_word*)t0)[2],t1);}

/* k989 in mail-headers in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 211  string-append */
((C_proc8)C_retrieve_proc(*((C_word*)lf[64]+1)))(8,*((C_word*)lf[64]+1),((C_word*)t0)[2],lf[115],t1,lf[116],lf[117],lf[118],lf[119]);}

/* mail-date-str in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_795(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_795,3,t0,t1,t2);}
t3=(C_word)C_i_vector_ref(t2,C_fix(6));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_806,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_806(t5,lf[108]);
case C_fix(1):
t5=t4;
f_806(t5,lf[109]);
case C_fix(2):
t5=t4;
f_806(t5,lf[110]);
case C_fix(3):
t5=t4;
f_806(t5,lf[111]);
case C_fix(4):
t5=t4;
f_806(t5,lf[112]);
case C_fix(5):
t5=t4;
f_806(t5,lf[113]);
default:
t5=(C_word)C_eqp(t3,C_fix(6));
t6=t4;
f_806(t6,(C_truep(t5)?lf[114]:C_SCHEME_UNDEFINED));}}

/* k804 in mail-date-str in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_fcall f_806(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_806,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_810,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_938,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(3));
/* chicken-bug.scm: 187  number->string */
C_number_to_string(3,0,t3,t4);}

/* k936 in k804 in mail-date-str in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 187  string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[95]))(5,*((C_word*)lf[95]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k808 in k804 in mail-date-str in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_810,2,t0,t1);}
t2=(C_word)C_i_vector_ref(((C_word*)t0)[4],C_fix(4));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_817,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
switch(t2){
case C_fix(0):
t4=t3;
f_817(t4,lf[96]);
case C_fix(1):
t4=t3;
f_817(t4,lf[97]);
case C_fix(2):
t4=t3;
f_817(t4,lf[98]);
case C_fix(3):
t4=t3;
f_817(t4,lf[99]);
case C_fix(4):
t4=t3;
f_817(t4,lf[100]);
case C_fix(5):
t4=t3;
f_817(t4,lf[101]);
case C_fix(6):
t4=t3;
f_817(t4,lf[102]);
case C_fix(7):
t4=t3;
f_817(t4,lf[103]);
case C_fix(8):
t4=t3;
f_817(t4,lf[104]);
case C_fix(9):
t4=t3;
f_817(t4,lf[105]);
case C_fix(10):
t4=t3;
f_817(t4,lf[106]);
default:
t4=(C_word)C_eqp(t2,C_fix(11));
t5=t3;
f_817(t5,(C_truep(t4)?lf[107]:C_SCHEME_UNDEFINED));}}

/* k815 in k808 in k804 in mail-date-str in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_fcall f_817(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_817,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_821,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(5));
t4=(C_word)C_a_i_plus(&a,2,C_fix(1900),t3);
/* chicken-bug.scm: 201  number->string */
C_number_to_string(3,0,t2,t4);}

/* k819 in k815 in k808 in k804 in mail-date-str in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_825,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_853,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(2));
/* chicken-bug.scm: 203  number->string */
C_number_to_string(3,0,t3,t4);}

/* k851 in k819 in k815 in k808 in k804 in mail-date-str in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 203  string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[95]))(5,*((C_word*)lf[95]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k823 in k819 in k815 in k808 in k804 in mail-date-str in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_829,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_845,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(1));
/* chicken-bug.scm: 205  number->string */
C_number_to_string(3,0,t3,t4);}

/* k843 in k823 in k819 in k815 in k808 in k804 in mail-date-str in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 205  string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[95]))(5,*((C_word*)lf[95]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k827 in k823 in k819 in k815 in k808 in k804 in mail-date-str in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_833,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_837,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* chicken-bug.scm: 207  number->string */
C_number_to_string(3,0,t3,t4);}

/* k835 in k827 in k823 in k819 in k815 in k808 in k804 in mail-date-str in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 207  string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[95]))(5,*((C_word*)lf[95]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k831 in k827 in k823 in k819 in k815 in k808 in k804 in mail-date-str in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 178  string-append */
((C_proc13)C_retrieve_proc(*((C_word*)lf[64]+1)))(13,*((C_word*)lf[64]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[91],((C_word*)t0)[3],lf[92],((C_word*)t0)[2],lf[93],t1,lf[94]);}

/* try-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_754,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_764,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_772,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 170  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),t6,t3,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_779,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_i_car(t2);
/* chicken-bug.scm: 174  send-mail */
((C_proc6)C_retrieve_symbol_proc(lf[89]))(6,*((C_word*)lf[89]+1),t6,t7,t5,t4,t3);}}

/* k777 in try-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-bug.scm: 175  try-mail */
((C_proc6)C_retrieve_symbol_proc(lf[68]))(6,*((C_word*)lf[68]+1),((C_word*)t0)[6],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a771 in try-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_772,2,t0,t1);}
/* chicken-bug.scm: 171  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t1,((C_word*)t0)[2]);}

/* k762 in try-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_767,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 172  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[9]+1)))(5,*((C_word*)lf[9]+1),t2,lf[86],((C_word*)t0)[2],lf[87]);}

/* k765 in k762 in try-mail in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 173  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[9]+1)))(4,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[84],lf[85]);}

/* main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_630(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_630,3,t0,t1,t2);}
t3=lf[67];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_634,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_711,a[2]=t8,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* for-each */
t11=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,t2);}

/* a710 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_711(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_711,3,t0,t1,t2);}
if(C_truep((C_word)C_i_string_equal_p(lf[76],t2))){
t3=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_723,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_727,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 124  user-input */
((C_proc2)C_retrieve_symbol_proc(lf[59]))(2,*((C_word*)lf[59]+1),t5);}
else{
t3=t2;
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[78]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[79]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[80]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
/* chicken-bug.scm: 126  usage */
((C_proc3)C_retrieve_symbol_proc(lf[56]))(3,*((C_word*)lf[56]+1),t1,C_fix(0));}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[81],t2))){
t4=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_748,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_752,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 135  read-all */
((C_proc3)C_retrieve_symbol_proc(lf[6]))(3,*((C_word*)lf[6]+1),t6,t2);}}}}

/* k750 in a710 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 132  string-append */
((C_proc7)C_retrieve_proc(*((C_word*)lf[64]+1)))(7,*((C_word*)lf[64]+1),((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],lf[82],((C_word*)t0)[2],lf[83],t1);}

/* k746 in a710 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k725 in a710 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 124  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[77],t1);}

/* k721 in a710 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k632 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_637,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=t2;
f_637(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_705,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_709,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 138  user-input */
((C_proc2)C_retrieve_symbol_proc(lf[59]))(2,*((C_word*)lf[59]+1),t4);}}

/* k707 in k632 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 138  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[75],t1);}

/* k703 in k632 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_637(t3,t2);}

/* k635 in k632 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_fcall f_637(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_637,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 139  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[4]+1)))(2,*((C_word*)lf[4]+1),t2);}

/* k638 in k635 in k632 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_701,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 140  current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[53]))(2,*((C_word*)lf[53]+1),t3);}

/* k699 in k638 in k635 in k632 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 140  seconds->local-time */
((C_proc3)C_retrieve_symbol_proc(lf[74]))(3,*((C_word*)lf[74]+1),((C_word*)t0)[2],t1);}

/* k641 in k638 in k635 in k632 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_643,2,t0,t1);}
t2=(C_word)C_i_vector_ref(t1,C_fix(3));
t3=(C_word)C_i_vector_ref(t1,C_fix(4));
t4=(C_word)C_i_vector_ref(t1,C_fix(5));
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_658,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 146  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t5,((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1900),t4);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_693,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 150  justify */
((C_proc3)C_retrieve_symbol_proc(lf[63]))(3,*((C_word*)lf[63]+1),t7,t3);}}

/* k691 in k641 in k638 in k635 in k632 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_697,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 150  justify */
((C_proc3)C_retrieve_symbol_proc(lf[63]))(3,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2]);}

/* k695 in k691 in k641 in k638 in k635 in k632 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 150  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[72]))(6,*((C_word*)lf[72]+1),((C_word*)t0)[4],lf[73],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k666 in k641 in k638 in k635 in k632 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_672,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 151  mail-headers */
((C_proc2)C_retrieve_symbol_proc(lf[71]))(2,*((C_word*)lf[71]+1),t2);}

/* k670 in k666 in k641 in k638 in k635 in k632 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_676,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_678,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 152  with-output-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),t2,t3);}

/* a677 in k670 in k666 in k641 in k638 in k635 in k632 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_682,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 154  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k680 in a677 in k670 in k666 in k641 in k638 in k635 in k632 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 155  collect-info */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* k674 in k670 in k666 in k641 in k638 in k635 in k632 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 148  try-mail */
((C_proc6)C_retrieve_symbol_proc(lf[68]))(6,*((C_word*)lf[68]+1),((C_word*)t0)[4],lf[69],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k656 in k641 in k638 in k635 in k632 in main in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 147  collect-info */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* justify in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_611(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_611,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_615,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 111  number->string */
C_number_to_string(3,0,t3,t2);}

/* k613 in justify in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(1)))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* chicken-bug.scm: 114  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[2],lf[65],t1);}}

/* user-input in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_596,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_602,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_609,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 98   current-input-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[62]+1)))(2,*((C_word*)lf[62]+1),t4);}

/* k607 in user-input in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 98   ##sys#tty-port? */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),((C_word*)t0)[2],t1);}

/* k600 in user-input in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-bug.scm: 99   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[60]);}
else{
t2=((C_word*)t0)[2];
f_596(2,t2,C_SCHEME_UNDEFINED);}}

/* k594 in user-input in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 108  read-all */
((C_proc2)C_retrieve_symbol_proc(lf[6]))(2,*((C_word*)lf[6]+1),((C_word*)t0)[2]);}

/* usage in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_583(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_583,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_587,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 83   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t3,lf[58]);}

/* k585 in usage in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 95   exit */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_401,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 49   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,lf[55]);}

/* k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_404,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 50   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,lf[54]);}

/* k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_407,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_577,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_581,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 51   current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[53]))(2,*((C_word*)lf[53]+1),t4);}

/* k579 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 51   seconds->string */
((C_proc3)C_retrieve_symbol_proc(lf[52]))(3,*((C_word*)lf[52]+1),((C_word*)t0)[2],t1);}

/* k575 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 51   print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[9]+1)))(5,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[50],t1,lf[51]);}

/* k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_410,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_573,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 52   user-id */
((C_proc2)C_retrieve_symbol_proc(lf[0]))(2,*((C_word*)lf[0]+1),t3);}

/* k571 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 52   printf */
((C_proc4)C_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),((C_word*)t0)[2],lf[49],t1);}

/* k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_413,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 53   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,lf[48]);}

/* k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_416,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_569,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 54   machine-type */
((C_proc2)C_retrieve_symbol_proc(lf[47]))(2,*((C_word*)lf[47]+1),t3);}

/* k567 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 54   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[9]+1)))(4,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[46],t1);}

/* k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_419,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_565,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 55   software-type */
((C_proc2)C_retrieve_symbol_proc(lf[45]))(2,*((C_word*)lf[45]+1),t3);}

/* k563 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 55   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[9]+1)))(4,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[44],t1);}

/* k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_422,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_561,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 56   software-version */
((C_proc2)C_retrieve_symbol_proc(lf[43]))(2,*((C_word*)lf[43]+1),t3);}

/* k559 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 56   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[9]+1)))(4,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[42],t1);}

/* k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_425,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_557,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 57   build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[41]))(2,*((C_word*)lf[41]+1),t3);}

/* k555 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 57   print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[9]+1)))(5,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[39],t1,lf[40]);}

/* k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_428,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_553,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 58   chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t3,C_SCHEME_TRUE);}

/* k551 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 58   print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[9]+1)))(5,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[36],t1,lf[37]);}

/* k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_431,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_549,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 59   chicken-home */
((C_proc2)C_retrieve_symbol_proc(lf[35]))(2,*((C_word*)lf[35]+1),t3);}

/* k547 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 59   print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[9]+1)))(5,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[33],t1,lf[34]);}

/* k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_434,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 60   printf */
((C_proc4)C_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),t2,lf[31],C_retrieve(lf[32]));}

/* k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_437,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 61   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,lf[30]);}

/* k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_440,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_504,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_537,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_541,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_545,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_retrieve(lf[28]),C_retrieve(lf[29]));}

/* k543 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 69   sort */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1,*((C_word*)lf[26]+1));}

/* k539 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 69   chop */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),((C_word*)t0)[2],t1,C_fix(5));}

/* k535 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a503 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_504(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_504,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_508,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 64   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[5]+1)))(3,*((C_word*)lf[5]+1),t3,lf[23]);}

/* k506 in a503 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_513,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a512 in k506 in a503 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_513,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_521,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(C_fix(16),t4);
t6=(C_word)C_i_fixnum_max(C_fix(1),t5);
/* chicken-bug.scm: 67   make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[21]+1)))(4,*((C_word*)lf[21]+1),t3,t6,C_make_character(32));}

/* k519 in a512 in k506 in a503 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 67   printf */
((C_proc5)C_retrieve_symbol_proc(lf[19]))(5,*((C_word*)lf[19]+1),((C_word*)t0)[3],lf[20],((C_word*)t0)[2],t1);}

/* k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_443,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 70   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,lf[18]);}

/* k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_446,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_488,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_502,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}

/* k500 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 71   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[16]))(4,*((C_word*)lf[16]+1),((C_word*)t0)[2],t1,lf[17]);}

/* k486 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_490,tmp=(C_word)a,a+=2,tmp);
/* chicken-bug.scm: 71   with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[15]))(4,*((C_word*)lf[15]+1),((C_word*)t0)[2],t1,t2);}

/* a489 in k486 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_498,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 73   read-all */
((C_proc2)C_retrieve_symbol_proc(lf[6]))(2,*((C_word*)lf[6]+1),t2);}

/* k496 in a489 in k486 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 73   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[5]+1)))(3,*((C_word*)lf[5]+1),((C_word*)t0)[2],t1);}

/* k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_449,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 74   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[4]+1)))(2,*((C_word*)lf[4]+1),t2);}

/* k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_452,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_458,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_484,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}

/* k482 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(t1,lf[11]))){
/* chicken-bug.scm: 75   feature? */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),((C_word*)t0)[2],lf[13]);}
else{
t2=((C_word*)t0)[2];
f_458(2,t2,C_SCHEME_FALSE);}}

/* k456 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_458,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_461,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 76   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,lf[10]);}
else{
t2=((C_word*)t0)[2];
f_452(2,t2,C_SCHEME_UNDEFINED);}}

/* k459 in k456 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_466,tmp=(C_word)a,a+=2,tmp);
/* chicken-bug.scm: 77   with-input-from-pipe */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),((C_word*)t0)[2],lf[8],t2);}

/* a465 in k459 in k456 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_474,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 79   read-all */
((C_proc2)C_retrieve_symbol_proc(lf[6]))(2,*((C_word*)lf[6]+1),t2);}

/* k472 in a465 in k459 in k456 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 79   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[5]+1)))(3,*((C_word*)lf[5]+1),((C_word*)t0)[2],t1);}

/* k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in collect-info in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 80   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[4]+1)))(2,*((C_word*)lf[4]+1),((C_word*)t0)[2]);}

/* user-id in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_395,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 46   current-user-id */
((C_proc2)C_retrieve_symbol_proc(lf[2]))(2,*((C_word*)lf[2]+1),t2);}

/* k393 in user-id in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 in k352 in k349 in k346 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 46   user-information */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[169] = {
{"toplevel:chicken_bug_scm",(void*)C_toplevel},
{"f_348:chicken_bug_scm",(void*)f_348},
{"f_351:chicken_bug_scm",(void*)f_351},
{"f_354:chicken_bug_scm",(void*)f_354},
{"f_357:chicken_bug_scm",(void*)f_357},
{"f_360:chicken_bug_scm",(void*)f_360},
{"f_363:chicken_bug_scm",(void*)f_363},
{"f_366:chicken_bug_scm",(void*)f_366},
{"f_369:chicken_bug_scm",(void*)f_369},
{"f_372:chicken_bug_scm",(void*)f_372},
{"f_375:chicken_bug_scm",(void*)f_375},
{"f_378:chicken_bug_scm",(void*)f_378},
{"f_381:chicken_bug_scm",(void*)f_381},
{"f_1301:chicken_bug_scm",(void*)f_1301},
{"f_1291:chicken_bug_scm",(void*)f_1291},
{"f_1297:chicken_bug_scm",(void*)f_1297},
{"f_1294:chicken_bug_scm",(void*)f_1294},
{"f_1177:chicken_bug_scm",(void*)f_1177},
{"f_1183:chicken_bug_scm",(void*)f_1183},
{"f_1189:chicken_bug_scm",(void*)f_1189},
{"f_1199:chicken_bug_scm",(void*)f_1199},
{"f_1220:chicken_bug_scm",(void*)f_1220},
{"f_1226:chicken_bug_scm",(void*)f_1226},
{"f_1288:chicken_bug_scm",(void*)f_1288},
{"f_1230:chicken_bug_scm",(void*)f_1230},
{"f_1284:chicken_bug_scm",(void*)f_1284},
{"f_1233:chicken_bug_scm",(void*)f_1233},
{"f_1280:chicken_bug_scm",(void*)f_1280},
{"f_1236:chicken_bug_scm",(void*)f_1236},
{"f_1276:chicken_bug_scm",(void*)f_1276},
{"f_1239:chicken_bug_scm",(void*)f_1239},
{"f_1272:chicken_bug_scm",(void*)f_1272},
{"f_1242:chicken_bug_scm",(void*)f_1242},
{"f_1268:chicken_bug_scm",(void*)f_1268},
{"f_1264:chicken_bug_scm",(void*)f_1264},
{"f_1245:chicken_bug_scm",(void*)f_1245},
{"f_1248:chicken_bug_scm",(void*)f_1248},
{"f_1251:chicken_bug_scm",(void*)f_1251},
{"f_1254:chicken_bug_scm",(void*)f_1254},
{"f_1257:chicken_bug_scm",(void*)f_1257},
{"f_1214:chicken_bug_scm",(void*)f_1214},
{"f_1202:chicken_bug_scm",(void*)f_1202},
{"f_1205:chicken_bug_scm",(void*)f_1205},
{"f_1212:chicken_bug_scm",(void*)f_1212},
{"f_1156:chicken_bug_scm",(void*)f_1156},
{"f_1166:chicken_bug_scm",(void*)f_1166},
{"f_1169:chicken_bug_scm",(void*)f_1169},
{"f_1087:chicken_bug_scm",(void*)f_1087},
{"f_1102:chicken_bug_scm",(void*)f_1102},
{"f_1132:chicken_bug_scm",(void*)f_1132},
{"f_1144:chicken_bug_scm",(void*)f_1144},
{"f_1150:chicken_bug_scm",(void*)f_1150},
{"f_1138:chicken_bug_scm",(void*)f_1138},
{"f_1108:chicken_bug_scm",(void*)f_1108},
{"f_1114:chicken_bug_scm",(void*)f_1114},
{"f_1121:chicken_bug_scm",(void*)f_1121},
{"f_1124:chicken_bug_scm",(void*)f_1124},
{"f_1100:chicken_bug_scm",(void*)f_1100},
{"f_1091:chicken_bug_scm",(void*)f_1091},
{"f_1001:chicken_bug_scm",(void*)f_1001},
{"f_1033:chicken_bug_scm",(void*)f_1033},
{"f_1063:chicken_bug_scm",(void*)f_1063},
{"f_1075:chicken_bug_scm",(void*)f_1075},
{"f_1081:chicken_bug_scm",(void*)f_1081},
{"f_1069:chicken_bug_scm",(void*)f_1069},
{"f_1039:chicken_bug_scm",(void*)f_1039},
{"f_1045:chicken_bug_scm",(void*)f_1045},
{"f_1052:chicken_bug_scm",(void*)f_1052},
{"f_1055:chicken_bug_scm",(void*)f_1055},
{"f_1031:chicken_bug_scm",(void*)f_1031},
{"f_1005:chicken_bug_scm",(void*)f_1005},
{"f_1021:chicken_bug_scm",(void*)f_1021},
{"f_983:chicken_bug_scm",(void*)f_983},
{"f_999:chicken_bug_scm",(void*)f_999},
{"f_995:chicken_bug_scm",(void*)f_995},
{"f_991:chicken_bug_scm",(void*)f_991},
{"f_795:chicken_bug_scm",(void*)f_795},
{"f_806:chicken_bug_scm",(void*)f_806},
{"f_938:chicken_bug_scm",(void*)f_938},
{"f_810:chicken_bug_scm",(void*)f_810},
{"f_817:chicken_bug_scm",(void*)f_817},
{"f_821:chicken_bug_scm",(void*)f_821},
{"f_853:chicken_bug_scm",(void*)f_853},
{"f_825:chicken_bug_scm",(void*)f_825},
{"f_845:chicken_bug_scm",(void*)f_845},
{"f_829:chicken_bug_scm",(void*)f_829},
{"f_837:chicken_bug_scm",(void*)f_837},
{"f_833:chicken_bug_scm",(void*)f_833},
{"f_754:chicken_bug_scm",(void*)f_754},
{"f_779:chicken_bug_scm",(void*)f_779},
{"f_772:chicken_bug_scm",(void*)f_772},
{"f_764:chicken_bug_scm",(void*)f_764},
{"f_767:chicken_bug_scm",(void*)f_767},
{"f_630:chicken_bug_scm",(void*)f_630},
{"f_711:chicken_bug_scm",(void*)f_711},
{"f_752:chicken_bug_scm",(void*)f_752},
{"f_748:chicken_bug_scm",(void*)f_748},
{"f_727:chicken_bug_scm",(void*)f_727},
{"f_723:chicken_bug_scm",(void*)f_723},
{"f_634:chicken_bug_scm",(void*)f_634},
{"f_709:chicken_bug_scm",(void*)f_709},
{"f_705:chicken_bug_scm",(void*)f_705},
{"f_637:chicken_bug_scm",(void*)f_637},
{"f_640:chicken_bug_scm",(void*)f_640},
{"f_701:chicken_bug_scm",(void*)f_701},
{"f_643:chicken_bug_scm",(void*)f_643},
{"f_693:chicken_bug_scm",(void*)f_693},
{"f_697:chicken_bug_scm",(void*)f_697},
{"f_668:chicken_bug_scm",(void*)f_668},
{"f_672:chicken_bug_scm",(void*)f_672},
{"f_678:chicken_bug_scm",(void*)f_678},
{"f_682:chicken_bug_scm",(void*)f_682},
{"f_676:chicken_bug_scm",(void*)f_676},
{"f_658:chicken_bug_scm",(void*)f_658},
{"f_611:chicken_bug_scm",(void*)f_611},
{"f_615:chicken_bug_scm",(void*)f_615},
{"f_592:chicken_bug_scm",(void*)f_592},
{"f_609:chicken_bug_scm",(void*)f_609},
{"f_602:chicken_bug_scm",(void*)f_602},
{"f_596:chicken_bug_scm",(void*)f_596},
{"f_583:chicken_bug_scm",(void*)f_583},
{"f_587:chicken_bug_scm",(void*)f_587},
{"f_397:chicken_bug_scm",(void*)f_397},
{"f_401:chicken_bug_scm",(void*)f_401},
{"f_404:chicken_bug_scm",(void*)f_404},
{"f_581:chicken_bug_scm",(void*)f_581},
{"f_577:chicken_bug_scm",(void*)f_577},
{"f_407:chicken_bug_scm",(void*)f_407},
{"f_573:chicken_bug_scm",(void*)f_573},
{"f_410:chicken_bug_scm",(void*)f_410},
{"f_413:chicken_bug_scm",(void*)f_413},
{"f_569:chicken_bug_scm",(void*)f_569},
{"f_416:chicken_bug_scm",(void*)f_416},
{"f_565:chicken_bug_scm",(void*)f_565},
{"f_419:chicken_bug_scm",(void*)f_419},
{"f_561:chicken_bug_scm",(void*)f_561},
{"f_422:chicken_bug_scm",(void*)f_422},
{"f_557:chicken_bug_scm",(void*)f_557},
{"f_425:chicken_bug_scm",(void*)f_425},
{"f_553:chicken_bug_scm",(void*)f_553},
{"f_428:chicken_bug_scm",(void*)f_428},
{"f_549:chicken_bug_scm",(void*)f_549},
{"f_431:chicken_bug_scm",(void*)f_431},
{"f_434:chicken_bug_scm",(void*)f_434},
{"f_437:chicken_bug_scm",(void*)f_437},
{"f_545:chicken_bug_scm",(void*)f_545},
{"f_541:chicken_bug_scm",(void*)f_541},
{"f_537:chicken_bug_scm",(void*)f_537},
{"f_504:chicken_bug_scm",(void*)f_504},
{"f_508:chicken_bug_scm",(void*)f_508},
{"f_513:chicken_bug_scm",(void*)f_513},
{"f_521:chicken_bug_scm",(void*)f_521},
{"f_440:chicken_bug_scm",(void*)f_440},
{"f_443:chicken_bug_scm",(void*)f_443},
{"f_502:chicken_bug_scm",(void*)f_502},
{"f_488:chicken_bug_scm",(void*)f_488},
{"f_490:chicken_bug_scm",(void*)f_490},
{"f_498:chicken_bug_scm",(void*)f_498},
{"f_446:chicken_bug_scm",(void*)f_446},
{"f_449:chicken_bug_scm",(void*)f_449},
{"f_484:chicken_bug_scm",(void*)f_484},
{"f_458:chicken_bug_scm",(void*)f_458},
{"f_461:chicken_bug_scm",(void*)f_461},
{"f_466:chicken_bug_scm",(void*)f_466},
{"f_474:chicken_bug_scm",(void*)f_474},
{"f_452:chicken_bug_scm",(void*)f_452},
{"f_387:chicken_bug_scm",(void*)f_387},
{"f_395:chicken_bug_scm",(void*)f_395},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
