/* Generated from srfi-69.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:27
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: srfi-69.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file usrfi-69.c -extend ./private-namespace.scm
   unit: srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[112];
static double C_possibly_force_alignment;


C_noret_decl(C_srfi_69_toplevel)
C_externexport void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5636)
static void C_ccall f_5636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5648)
static void C_ccall f_5648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5705)
static void C_fcall f_5705(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5663)
static void C_fcall f_5663(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5746)
static void C_ccall f_5746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5616)
static void C_ccall f_5616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5592)
static void C_ccall f_5592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5580)
static void C_ccall f_5580(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5587)
static void C_ccall f_5587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5575)
static void C_ccall f_5575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5502)
static void C_fcall f_5502(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5514)
static void C_fcall f_5514(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5530)
static void C_fcall f_5530(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5558)
static void C_ccall f_5558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5453)
static void C_fcall f_5453(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5465)
static void C_fcall f_5465(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5475)
static void C_ccall f_5475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5388)
static void C_ccall f_5388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5403)
static void C_fcall f_5403(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5419)
static void C_fcall f_5419(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5323)
static void C_ccall f_5323(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5338)
static void C_fcall f_5338(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5354)
static void C_fcall f_5354(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5294)
static void C_ccall f_5294(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5294)
static void C_ccall f_5294r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5301)
static void C_ccall f_5301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5304)
static void C_ccall f_5304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5221)
static void C_ccall f_5221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5236)
static void C_fcall f_5236(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5252)
static void C_fcall f_5252(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5219)
static void C_ccall f_5219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5193)
static void C_ccall f_5193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5128)
static void C_fcall f_5128(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5140)
static void C_fcall f_5140(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5163)
static void C_fcall f_5163(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5150)
static void C_ccall f_5150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_ccall f_5112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5023)
static void C_ccall f_5023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5037)
static void C_fcall f_5037(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5063)
static void C_fcall f_5063(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5082)
static void C_ccall f_5082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4968)
static void C_fcall f_4968(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4921)
static C_word C_fcall f_4921(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4793)
static void C_ccall f_4793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_fcall f_4848(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4808)
static C_word C_fcall f_4808(C_word t0,C_word t1);
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4687)
static void C_ccall f_4687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4741)
static void C_fcall f_4741(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4702)
static C_word C_fcall f_4702(C_word t0,C_word t1);
C_noret_decl(f_4474)
static void C_ccall f_4474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4630)
static void C_fcall f_4630(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4583)
static void C_fcall f_4583(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4613)
static void C_ccall f_4613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4534)
static void C_fcall f_4534(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4255)
static void C_fcall f_4255(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4425)
static void C_fcall f_4425(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4280)
static void C_ccall f_4280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4368)
static void C_fcall f_4368(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4401)
static void C_ccall f_4401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4404)
static void C_ccall f_4404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4378)
static void C_ccall f_4378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4309)
static void C_fcall f_4309(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4210)
static void C_fcall f_4210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4193)
static void C_fcall f_4193(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3970)
static void C_fcall f_3970(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4157)
static void C_fcall f_4157(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_fcall f_4096(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4136)
static void C_ccall f_4136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4033)
static void C_fcall f_4033(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4061)
static void C_ccall f_4061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3847)
static void C_fcall f_3847(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3857)
static void C_ccall f_3857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3862)
static void C_fcall f_3862(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3924)
static void C_fcall f_3924(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3918)
static void C_ccall f_3918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3831)
static void C_ccall f_3831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_fcall f_3754(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3777)
static void C_fcall f_3777(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3793)
static void C_ccall f_3793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3646)
static void C_ccall f_3646(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3283)
static void C_ccall f_3283(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3283)
static void C_ccall f_3283r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3636)
static void C_ccall f_3636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3639)
static void C_ccall f_3639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3361)
static void C_fcall f_3361(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3364)
static void C_fcall f_3364(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3367)
static void C_fcall f_3367(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_fcall f_3402(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3524)
static void C_ccall f_3524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3413)
static void C_fcall f_3413(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3380)
static void C_fcall f_3380(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3285)
static C_word C_fcall f_3285(C_word t0);
C_noret_decl(f_3259)
static void C_fcall f_3259(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3229)
static void C_fcall f_3229(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3235)
static C_word C_fcall f_3235(C_word t0,C_word t1);
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3170)
static void C_fcall f_3170(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3161)
static void C_fcall f_3161(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3142)
static void C_fcall f_3142(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3048)
static void C_fcall f_3048(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3039)
static void C_fcall f_3039(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3020)
static void C_fcall f_3020(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_fcall f_2607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_fcall f_2706(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_fcall f_2675(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2691)
static void C_fcall f_2691(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2610)
static void C_fcall f_2610(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2627)
static void C_fcall f_2627(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2259)
static void C_ccall f_2259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2147)
static void C_ccall f_2147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_fcall f_2051(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_5705)
static void C_fcall trf_5705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5705(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5705(t0,t1,t2);}

C_noret_decl(trf_5663)
static void C_fcall trf_5663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5663(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5663(t0,t1,t2);}

C_noret_decl(trf_5502)
static void C_fcall trf_5502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5502(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5502(t0,t1,t2,t3);}

C_noret_decl(trf_5514)
static void C_fcall trf_5514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5514(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5514(t0,t1,t2,t3);}

C_noret_decl(trf_5530)
static void C_fcall trf_5530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5530(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5530(t0,t1,t2,t3);}

C_noret_decl(trf_5453)
static void C_fcall trf_5453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5453(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5453(t0,t1,t2);}

C_noret_decl(trf_5465)
static void C_fcall trf_5465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5465(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5465(t0,t1,t2);}

C_noret_decl(trf_5403)
static void C_fcall trf_5403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5403(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5403(t0,t1,t2,t3);}

C_noret_decl(trf_5419)
static void C_fcall trf_5419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5419(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5419(t0,t1,t2,t3);}

C_noret_decl(trf_5338)
static void C_fcall trf_5338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5338(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5338(t0,t1,t2,t3);}

C_noret_decl(trf_5354)
static void C_fcall trf_5354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5354(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5354(t0,t1,t2,t3);}

C_noret_decl(trf_5236)
static void C_fcall trf_5236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5236(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5236(t0,t1,t2,t3);}

C_noret_decl(trf_5252)
static void C_fcall trf_5252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5252(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5252(t0,t1,t2,t3);}

C_noret_decl(trf_5128)
static void C_fcall trf_5128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5128(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5128(t0,t1,t2);}

C_noret_decl(trf_5140)
static void C_fcall trf_5140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5140(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5140(t0,t1,t2);}

C_noret_decl(trf_5163)
static void C_fcall trf_5163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5163(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5163(t0,t1,t2);}

C_noret_decl(trf_5037)
static void C_fcall trf_5037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5037(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5037(t0,t1,t2);}

C_noret_decl(trf_5063)
static void C_fcall trf_5063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5063(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5063(t0,t1,t2,t3);}

C_noret_decl(trf_4968)
static void C_fcall trf_4968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4968(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4968(t0,t1,t2,t3);}

C_noret_decl(trf_4848)
static void C_fcall trf_4848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4848(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4848(t0,t1,t2);}

C_noret_decl(trf_4741)
static void C_fcall trf_4741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4741(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4741(t0,t1,t2);}

C_noret_decl(trf_4630)
static void C_fcall trf_4630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4630(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4630(t0,t1);}

C_noret_decl(trf_4583)
static void C_fcall trf_4583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4583(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4583(t0,t1,t2);}

C_noret_decl(trf_4534)
static void C_fcall trf_4534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4534(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4534(t0,t1,t2);}

C_noret_decl(trf_4255)
static void C_fcall trf_4255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4255(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4255(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4425)
static void C_fcall trf_4425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4425(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4425(t0,t1);}

C_noret_decl(trf_4368)
static void C_fcall trf_4368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4368(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4368(t0,t1,t2);}

C_noret_decl(trf_4309)
static void C_fcall trf_4309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4309(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4309(t0,t1,t2);}

C_noret_decl(trf_4210)
static void C_fcall trf_4210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4210(t0,t1);}

C_noret_decl(trf_4193)
static void C_fcall trf_4193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4193(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4193(t0,t1,t2);}

C_noret_decl(trf_3970)
static void C_fcall trf_3970(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3970(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3970(t0,t1,t2,t3);}

C_noret_decl(trf_4157)
static void C_fcall trf_4157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4157(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4157(t0,t1);}

C_noret_decl(trf_4096)
static void C_fcall trf_4096(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4096(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4096(t0,t1,t2);}

C_noret_decl(trf_4033)
static void C_fcall trf_4033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4033(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4033(t0,t1,t2);}

C_noret_decl(trf_3847)
static void C_fcall trf_3847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3847(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3847(t0,t1,t2);}

C_noret_decl(trf_3862)
static void C_fcall trf_3862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3862(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3862(t0,t1,t2);}

C_noret_decl(trf_3924)
static void C_fcall trf_3924(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3924(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3924(t0,t1,t2);}

C_noret_decl(trf_3754)
static void C_fcall trf_3754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3754(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3754(t0,t1,t2);}

C_noret_decl(trf_3777)
static void C_fcall trf_3777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3777(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3777(t0,t1,t2);}

C_noret_decl(trf_3361)
static void C_fcall trf_3361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3361(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3361(t0,t1);}

C_noret_decl(trf_3364)
static void C_fcall trf_3364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3364(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3364(t0,t1);}

C_noret_decl(trf_3367)
static void C_fcall trf_3367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3367(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3367(t0,t1);}

C_noret_decl(trf_3402)
static void C_fcall trf_3402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3402(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3402(t0,t1,t2);}

C_noret_decl(trf_3413)
static void C_fcall trf_3413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3413(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3413(t0,t1,t2);}

C_noret_decl(trf_3380)
static void C_fcall trf_3380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3380(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3380(t0,t1);}

C_noret_decl(trf_3259)
static void C_fcall trf_3259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3259(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_3259(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_3229)
static void C_fcall trf_3229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3229(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3229(t0,t1,t2);}

C_noret_decl(trf_3170)
static void C_fcall trf_3170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3170(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3170(t0,t1);}

C_noret_decl(trf_3161)
static void C_fcall trf_3161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3161(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3161(t0,t1,t2);}

C_noret_decl(trf_3142)
static void C_fcall trf_3142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3142(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3142(t0,t1,t2,t3);}

C_noret_decl(trf_3048)
static void C_fcall trf_3048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3048(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3048(t0,t1);}

C_noret_decl(trf_3039)
static void C_fcall trf_3039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3039(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3039(t0,t1,t2);}

C_noret_decl(trf_3020)
static void C_fcall trf_3020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3020(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3020(t0,t1,t2,t3);}

C_noret_decl(trf_2607)
static void C_fcall trf_2607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2607(t0,t1);}

C_noret_decl(trf_2706)
static void C_fcall trf_2706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2706(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2706(t0,t1,t2,t3);}

C_noret_decl(trf_2675)
static void C_fcall trf_2675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2675(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2675(t0,t1,t2,t3);}

C_noret_decl(trf_2691)
static void C_fcall trf_2691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2691(t0,t1);}

C_noret_decl(trf_2610)
static void C_fcall trf_2610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2610(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2610(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2627)
static void C_fcall trf_2627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2627(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2627(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2051)
static void C_fcall trf_2051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2051(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2051(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_69_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(923)){
C_save(t1);
C_rereclaim2(923*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,112);
lf[0]=C_h_intern(&lf[0],20,"\003sysnumber-hash-hook");
lf[2]=C_h_intern(&lf[2],11,"number-hash");
lf[3]=C_h_intern(&lf[3],15,"\003syssignal-hook");
lf[4]=C_h_intern(&lf[4],5,"\000type");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid number");
lf[6]=C_h_intern(&lf[6],15,"object-uid-hash");
lf[7]=C_h_intern(&lf[7],11,"symbol-hash");
lf[8]=C_h_intern(&lf[8],17,"\003syscheck-keyword");
lf[9]=C_h_intern(&lf[9],11,"\000type-error");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a keyword");
lf[11]=C_h_intern(&lf[11],8,"keyword\077");
lf[12]=C_h_intern(&lf[12],12,"keyword-hash");
lf[13]=C_h_intern(&lf[13],8,"eq\077-hash");
lf[14]=C_h_intern(&lf[14],16,"hash-by-identity");
lf[15]=C_h_intern(&lf[15],9,"eqv\077-hash");
lf[16]=C_h_intern(&lf[16],11,"input-port\077");
lf[17]=C_h_intern(&lf[17],11,"equal\077-hash");
lf[18]=C_h_intern(&lf[18],4,"hash");
lf[19]=C_h_intern(&lf[19],11,"string-hash");
lf[20]=C_h_intern(&lf[20],13,"\003syssubstring");
lf[21]=C_h_intern(&lf[21],15,"\003syscheck-range");
lf[22]=C_h_intern(&lf[22],14,"string-ci-hash");
lf[23]=C_h_intern(&lf[23],14,"string-hash-ci");
lf[25]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\0013\376\003\000\000\002\376\377\001\000\000\002i\376\003\000\000\002\376\377\001\000\000\004\325\376\003\000\000\002\376\377\001\000\000\011\255\376\003\000\000\002\376\377\001\000\000\023]\376\003\000\000\002\376\377\001\000\000&\303\376\003\000\000\002\376\377\001"
"\000\000M\215\376\003\000\000\002\376\377\001\000\000\233\035\376\003\000\000\002\376\377\001\000\0016\077\376\003\000\000\002\376\377\001\000\002l\201\376\003\000\000\002\376\377\001\000\004\331\005\376\003\000\000\002\376\377\001\000\011\262\025\376\003\000\000\002\376\377\001\000\023dA\376\003\000\000"
"\002\376\377\001\000&\310\205\376\003\000\000\002\376\377\001\000M\221\037\376\003\000\000\002\376\377\001\000\233\042I\376\003\000\000\002\376\377\001\0016D\277\376\003\000\000\002\376\377\001\002l\211\207\376\003\000\000\002\376\377\001\004\331\023\027\376\003\000\000\002\376\377\001\011\262&1"
"\376\003\000\000\002\376\377\001\023dLq\376\003\000\000\002\376\377\001&\310\230\373\376\003\000\000\002\376\377\001\077\377\377\377\376\377\016");
lf[27]=C_h_intern(&lf[27],11,"make-vector");
lf[29]=C_h_intern(&lf[29],10,"hash-table");
lf[30]=C_h_intern(&lf[30],3,"eq\077");
lf[31]=C_h_intern(&lf[31],4,"eqv\077");
lf[32]=C_h_intern(&lf[32],6,"equal\077");
lf[33]=C_h_intern(&lf[33],8,"string=\077");
lf[34]=C_h_intern(&lf[34],11,"string-ci=\077");
lf[35]=C_h_intern(&lf[35],1,"=");
lf[36]=C_h_intern(&lf[36],15,"make-hash-table");
lf[37]=C_decode_literal(C_heaptop,"\376U0.5\000");
lf[38]=C_decode_literal(C_heaptop,"\376U0.8\000");
lf[39]=C_h_intern(&lf[39],7,"warning");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\033user test without user hash");
lf[41]=C_h_intern(&lf[41],5,"error");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\036min-load greater than max-load");
lf[43]=C_h_intern(&lf[43],5,"\000test");
lf[44]=C_h_intern(&lf[44],17,"\003syscheck-closure");
lf[45]=C_h_intern(&lf[45],5,"\000hash");
lf[46]=C_h_intern(&lf[46],5,"\000size");
lf[47]=C_h_intern(&lf[47],19,"hash-table-max-size");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[49]=C_h_intern(&lf[49],8,"\000initial");
lf[50]=C_h_intern(&lf[50],9,"\000min-load");
lf[51]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[52]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid min-load");
lf[54]=C_h_intern(&lf[54],17,"\003syscheck-inexact");
lf[55]=C_h_intern(&lf[55],9,"\000max-load");
lf[56]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[57]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid max-load");
lf[59]=C_h_intern(&lf[59],10,"\000weak-keys");
lf[60]=C_h_intern(&lf[60],12,"\000weak-values");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\017unknown keyword");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\025missing keyword value");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[65]=C_h_intern(&lf[65],11,"hash-table\077");
lf[66]=C_h_intern(&lf[66],15,"hash-table-size");
lf[67]=C_h_intern(&lf[67],31,"hash-table-equivalence-function");
lf[68]=C_h_intern(&lf[68],24,"hash-table-hash-function");
lf[69]=C_h_intern(&lf[69],19,"hash-table-min-load");
lf[70]=C_h_intern(&lf[70],19,"hash-table-max-load");
lf[71]=C_h_intern(&lf[71],20,"hash-table-weak-keys");
lf[72]=C_h_intern(&lf[72],22,"hash-table-weak-values");
lf[73]=C_h_intern(&lf[73],23,"hash-table-has-initial\077");
lf[74]=C_h_intern(&lf[74],18,"hash-table-initial");
lf[75]=C_h_intern(&lf[75],18,"hash-table-resize!");
lf[77]=C_h_intern(&lf[77],15,"hash-table-copy");
lf[78]=C_h_intern(&lf[78],18,"hash-table-update!");
lf[79]=C_h_intern(&lf[79],5,"floor");
lf[80]=C_h_intern(&lf[80],13,"\000access-error");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[82]=C_h_intern(&lf[82],8,"identity");
lf[84]=C_h_intern(&lf[84],26,"hash-table-update!/default");
lf[85]=C_h_intern(&lf[85],15,"hash-table-set!");
lf[86]=C_h_intern(&lf[86],19,"\003sysundefined-value");
lf[87]=C_h_intern(&lf[87],14,"hash-table-ref");
lf[88]=C_h_intern(&lf[88],22,"hash-table-ref/default");
lf[89]=C_h_intern(&lf[89],18,"hash-table-exists\077");
lf[90]=C_h_intern(&lf[90],18,"hash-table-delete!");
lf[91]=C_h_intern(&lf[91],18,"hash-table-remove!");
lf[92]=C_h_intern(&lf[92],17,"hash-table-clear!");
lf[93]=C_h_intern(&lf[93],12,"vector-fill!");
lf[95]=C_h_intern(&lf[95],17,"hash-table-merge!");
lf[96]=C_h_intern(&lf[96],16,"hash-table-merge");
lf[97]=C_h_intern(&lf[97],17,"hash-table->alist");
lf[98]=C_h_intern(&lf[98],17,"alist->hash-table");
lf[99]=C_h_intern(&lf[99],12,"\003sysfor-each");
lf[100]=C_h_intern(&lf[100],15,"hash-table-keys");
lf[101]=C_h_intern(&lf[101],17,"hash-table-values");
lf[104]=C_h_intern(&lf[104],15,"hash-table-fold");
lf[105]=C_h_intern(&lf[105],19,"hash-table-for-each");
lf[106]=C_h_intern(&lf[106],15,"hash-table-walk");
lf[107]=C_h_intern(&lf[107],14,"hash-table-map");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[109]=C_h_intern(&lf[109],18,"getter-with-setter");
lf[110]=C_h_intern(&lf[110],17,"register-feature!");
lf[111]=C_h_intern(&lf[111],7,"srfi-69");
C_register_lf2(lf,112,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2030,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 65   register-feature! */
t3=*((C_word*)lf[110]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[111]);}

/* k2028 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word ab[81],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2030,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! number-hash-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2032,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[2]+1 /* (set! number-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2038,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[6]+1 /* (set! object-uid-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2167,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[7]+1 /* (set! symbol-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2208,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[8]+1 /* (set! check-keyword ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2252,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[12]+1 /* (set! keyword-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2278,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[13]+1 /* (set! eq?-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2382,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[14]+1 /* (set! hash-by-identity ...) */,*((C_word*)lf[13]+1));
t10=C_mutate((C_word*)lf[15]+1 /* (set! eqv?-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2566,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[1] /* (set! *equal?-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2607,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[17]+1 /* (set! equal?-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2941,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[18]+1 /* (set! hash ...) */,*((C_word*)lf[17]+1));
t14=C_mutate((C_word*)lf[19]+1 /* (set! string-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2983,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[22]+1 /* (set! string-ci-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3105,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[23]+1 /* (set! string-hash-ci ...) */,*((C_word*)lf[22]+1));
t17=C_mutate(&lf[24] /* (set! constant883 ...) */,lf[25]);
t18=C_mutate(&lf[26] /* (set! hash-table-canonical-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3229,tmp=(C_word)a,a+=2,tmp));
t19=*((C_word*)lf[27]+1);
t20=C_mutate(&lf[28] /* (set! *make-hash-table ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3259,a[2]=t19,tmp=(C_word)a,a+=3,tmp));
t21=*((C_word*)lf[30]+1);
t22=*((C_word*)lf[31]+1);
t23=*((C_word*)lf[32]+1);
t24=*((C_word*)lf[33]+1);
t25=*((C_word*)lf[34]+1);
t26=*((C_word*)lf[35]+1);
t27=C_mutate((C_word*)lf[36]+1 /* (set! make-hash-table ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3283,a[2]=t26,a[3]=t25,a[4]=t24,a[5]=t23,a[6]=t22,a[7]=t21,tmp=(C_word)a,a+=8,tmp));
t28=C_mutate((C_word*)lf[65]+1 /* (set! hash-table? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3646,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[66]+1 /* (set! hash-table-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3652,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[67]+1 /* (set! hash-table-equivalence-function ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3661,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[68]+1 /* (set! hash-table-hash-function ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3670,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[69]+1 /* (set! hash-table-min-load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3679,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[70]+1 /* (set! hash-table-max-load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3688,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[71]+1 /* (set! hash-table-weak-keys ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3697,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[72]+1 /* (set! hash-table-weak-values ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3706,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[73]+1 /* (set! hash-table-has-initial? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3715,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[74]+1 /* (set! hash-table-initial ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3727,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[75]+1 /* (set! hash-table-resize! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3821,tmp=(C_word)a,a+=2,tmp));
t39=*((C_word*)lf[27]+1);
t40=C_mutate(&lf[76] /* (set! *hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3847,a[2]=t39,tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[77]+1 /* (set! hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3959,tmp=(C_word)a,a+=2,tmp));
t42=*((C_word*)lf[30]+1);
t43=C_mutate((C_word*)lf[78]+1 /* (set! hash-table-update! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3968,a[2]=t42,tmp=(C_word)a,a+=3,tmp));
t44=*((C_word*)lf[30]+1);
t45=C_mutate(&lf[83] /* (set! *hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4255,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[84]+1 /* (set! hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4462,tmp=(C_word)a,a+=2,tmp));
t47=*((C_word*)lf[30]+1);
t48=C_mutate((C_word*)lf[85]+1 /* (set! hash-table-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4474,a[2]=t47,tmp=(C_word)a,a+=3,tmp));
t49=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4669,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t50=*((C_word*)lf[30]+1);
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5626,a[2]=t50,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 808  getter-with-setter */
t52=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t52+1)))(4,t52,t49,t51,*((C_word*)lf[85]+1));}

/* a5625 in k2028 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5626r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5626r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5626r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(11);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5746,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp):(C_word)C_slot(t4,C_fix(0)));
t7=(C_word)C_i_check_structure_2(t2,lf[29],lf[87]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5636,a[2]=t1,a[3]=t3,a[4]=t6,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 815  ##sys#check-closure */
t9=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t6,lf[87]);}

/* k5634 in a5625 in k2028 */
static void C_ccall f_5636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5636,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(4));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_block_size(t2);
/* srfi-69.scm: 819  hash */
t7=t4;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[3],t6);}

/* k5646 in k5634 in a5625 in k2028 */
static void C_ccall f_5648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5648,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5663,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5663(t7,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5705,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5705(t7,((C_word*)t0)[2],t3);}}

/* loop in k5646 in k5634 in a5625 in k2028 */
static void C_fcall f_5705(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5705,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 832  def */
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5724,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 834  test */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k5722 in loop in k5646 in k5634 in a5625 in k2028 */
static void C_ccall f_5724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 836  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5705(t3,((C_word*)t0)[5],t2);}}

/* loop in k5646 in k5634 in a5625 in k2028 */
static void C_fcall f_5663(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5663,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 824  def */
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 828  loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* f_5746 in a5625 in k2028 */
static void C_ccall f_5746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5746,2,t0,t1);}
/* srfi-69.scm: 811  ##sys#signal-hook */
t2=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[80],lf[87],lf[108],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4667 in k2028 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[40],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4669,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! hash-table-ref ...) */,t1);
t3=*((C_word*)lf[30]+1);
t4=C_mutate((C_word*)lf[88]+1 /* (set! hash-table-ref/default ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4671,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=*((C_word*)lf[30]+1);
t6=C_mutate((C_word*)lf[89]+1 /* (set! hash-table-exists? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4777,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[30]+1);
t8=C_mutate((C_word*)lf[90]+1 /* (set! hash-table-delete! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4885,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[91]+1 /* (set! hash-table-remove! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5016,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[92]+1 /* (set! hash-table-clear! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5112,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[94] /* (set! *hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5128,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[95]+1 /* (set! hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5193,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[96]+1 /* (set! hash-table-merge ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5205,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[97]+1 /* (set! hash-table->alist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5221,tmp=(C_word)a,a+=2,tmp));
t15=*((C_word*)lf[36]+1);
t16=C_mutate((C_word*)lf[98]+1 /* (set! alist->hash-table ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5294,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[100]+1 /* (set! hash-table-keys ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5323,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[101]+1 /* (set! hash-table-values ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5388,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[102] /* (set! *hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5453,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[103] /* (set! *hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5502,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[104]+1 /* (set! hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5568,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[105]+1 /* (set! hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5580,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[106]+1 /* (set! hash-table-walk ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5592,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[107]+1 /* (set! hash-table-map ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5604,tmp=(C_word)a,a+=2,tmp));
t25=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,C_SCHEME_UNDEFINED);}

/* hash-table-map in k4667 in k2028 */
static void C_ccall f_5604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5604,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[107]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5611,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1088 ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[107]);}

/* k5609 in hash-table-map in k4667 in k2028 */
static void C_ccall f_5611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5616,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 1089 *hash-table-fold */
f_5502(((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* a5615 in k5609 in hash-table-map in k4667 in k2028 */
static void C_ccall f_5616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5616,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5624,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 1089 func */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}

/* k5622 in a5615 in k5609 in hash-table-map in k4667 in k2028 */
static void C_ccall f_5624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5624,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* hash-table-walk in k4667 in k2028 */
static void C_ccall f_5592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5592,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[106]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5599,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1083 ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[106]);}

/* k5597 in hash-table-walk in k4667 in k2028 */
static void C_ccall f_5599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1084 *hash-table-for-each */
f_5453(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-for-each in k4667 in k2028 */
static void C_ccall f_5580(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5580,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[105]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5587,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1078 ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[105]);}

/* k5585 in hash-table-for-each in k4667 in k2028 */
static void C_ccall f_5587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1079 *hash-table-for-each */
f_5453(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-fold in k4667 in k2028 */
static void C_ccall f_5568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5568,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[29],lf[104]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5575,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 1073 ##sys#check-closure */
t7=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[104]);}

/* k5573 in hash-table-fold in k4667 in k2028 */
static void C_ccall f_5575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1074 *hash-table-fold */
f_5502(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* *hash-table-fold in k4667 in k2028 */
static void C_fcall f_5502(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5502,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5514,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_5514(t10,t1,C_fix(0),t4);}

/* loop in *hash-table-fold in k4667 in k2028 */
static void C_fcall f_5514(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5514,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5530,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5530(t8,t1,t4,t3);}}

/* fold2 in loop in *hash-table-fold in k4667 in k2028 */
static void C_fcall f_5530(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5530,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 1066 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5514(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5558,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 1069 func */
t9=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t6,t7,t8,t3);}}

/* k5556 in fold2 in loop in *hash-table-fold in k4667 in k2028 */
static void C_ccall f_5558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1068 fold2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5530(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* *hash-table-for-each in k4667 in k2028 */
static void C_fcall f_5453(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5453,NULL,3,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5465,a[2]=t4,a[3]=t3,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5465(t9,t1,C_fix(0));}

/* doloop1888 in *hash-table-for-each in k4667 in k2028 */
static void C_fcall f_5465(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5465,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5475,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5484,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* srfi-69.scm: 1053 ##sys#for-each */
t6=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a5483 in doloop1888 in *hash-table-for-each in k4667 in k2028 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5484,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 1054 proc */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k5473 in doloop1888 in *hash-table-for-each in k4667 in k2028 */
static void C_ccall f_5475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5465(t3,((C_word*)t0)[2],t2);}

/* hash-table-values in k4667 in k2028 */
static void C_ccall f_5388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5388,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[101]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5403,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_5403(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-values in k4667 in k2028 */
static void C_fcall f_5403(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5403,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5419,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5419(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-values in k4667 in k2028 */
static void C_fcall f_5419(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5419,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 1036 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5403(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 1037 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* hash-table-keys in k4667 in k2028 */
static void C_ccall f_5323(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5323,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[100]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5338,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_5338(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-keys in k4667 in k2028 */
static void C_fcall f_5338(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5338,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5354,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5354(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-keys in k4667 in k2028 */
static void C_fcall f_5354(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5354,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 1021 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5338(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 1022 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* alist->hash-table in k4667 in k2028 */
static void C_ccall f_5294(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5294r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5294r(t0,t1,t2,t3);}}

static void C_ccall f_5294r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_list_2(t2,lf[98]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5301,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t5,((C_word*)t0)[2],t3);}

/* k5299 in alist->hash-table in k4667 in k2028 */
static void C_ccall f_5301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5304,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5306,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5305 in k5299 in alist->hash-table in k4667 in k2028 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5306,3,t0,t1,t2);}
t3=(C_word)C_i_check_pair_2(t2,lf[98]);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 1005 *hash-table-update!/default */
t6=lf[83];
f_4255(t6,t1,((C_word*)t0)[2],t4,*((C_word*)lf[82]+1),t5);}

/* k5302 in k5299 in alist->hash-table in k4667 in k2028 */
static void C_ccall f_5304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table->alist in k4667 in k2028 */
static void C_ccall f_5221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5221,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[97]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5236,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_5236(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table->alist in k4667 in k2028 */
static void C_fcall f_5236(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5236,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5252,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5252(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table->alist in k4667 in k2028 */
static void C_fcall f_5252(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5252,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 992  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5236(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_slot(t5,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* srfi-69.scm: 993  loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* hash-table-merge in k4667 in k2028 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5205,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[96]);
t5=(C_word)C_i_check_structure_2(t3,lf[29],lf[96]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5219,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 978  *hash-table-copy */
t7=lf[76];
f_3847(t7,t6,t2);}

/* k5217 in hash-table-merge in k4667 in k2028 */
static void C_ccall f_5219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 978  *hash-table-merge! */
f_5128(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* hash-table-merge! in k4667 in k2028 */
static void C_ccall f_5193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5193,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[95]);
t5=(C_word)C_i_check_structure_2(t3,lf[29],lf[95]);
/* srfi-69.scm: 973  *hash-table-merge! */
f_5128(t1,t2,t3);}

/* *hash-table-merge! in k4667 in k2028 */
static void C_fcall f_5128(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5128,NULL,3,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5140,a[2]=t4,a[3]=t7,a[4]=t2,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5140(t9,t1,C_fix(0));}

/* doloop1743 in *hash-table-merge! in k4667 in k2028 */
static void C_fcall f_5140(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5140,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5150,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5163,a[2]=((C_word*)t0)[4],a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5163(t8,t3,t4);}}

/* doloop1752 in doloop1743 in *hash-table-merge! in k4667 in k2028 */
static void C_fcall f_5163(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5163,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5176,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 968  *hash-table-update!/default */
t7=lf[83];
f_4255(t7,t4,((C_word*)t0)[2],t5,*((C_word*)lf[82]+1),t6);}}

/* k5174 in doloop1752 in doloop1743 in *hash-table-merge! in k4667 in k2028 */
static void C_ccall f_5176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5163(t3,((C_word*)t0)[2],t2);}

/* k5148 in doloop1743 in *hash-table-merge! in k4667 in k2028 */
static void C_ccall f_5150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5140(t3,((C_word*)t0)[2],t2);}

/* hash-table-clear! in k4667 in k2028 */
static void C_ccall f_5112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5112,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[92]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5119,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 955  vector-fill! */
t6=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k5117 in hash-table-clear! in k4667 in k2028 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_fix(0)));}

/* hash-table-remove! in k4667 in k2028 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5016,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[91]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5023,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 932  ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[91]);}

/* k5021 in hash-table-remove! in k4667 in k2028 */
static void C_ccall f_5023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5023,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_block_size(t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5037,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_5037(t10,((C_word*)t0)[2],C_fix(0));}

/* doloop1698 in k5021 in hash-table-remove! in k4667 in k2028 */
static void C_fcall f_5037(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5037,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)((C_word*)t0)[5])[1]));}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5050,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5063,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5063(t8,t3,C_SCHEME_FALSE,t4);}}

/* loop in doloop1698 in k5021 in hash-table-remove! in k4667 in k2028 */
static void C_fcall f_5063(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5063,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5082,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t5,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 942  func */
t9=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}}

/* k5080 in loop in doloop1698 in k5021 in hash-table-remove! in k4667 in k2028 */
static void C_ccall f_5082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_i_setslot(((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8]):(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[8]));
t3=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 949  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5063(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k5048 in doloop1698 in k5021 in hash-table-remove! in k4667 in k2028 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5037(t3,((C_word*)t0)[2],t2);}

/* hash-table-delete! in k4667 in k2028 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4885,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[90]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4901,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 896  hash */
t9=t7;
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t3,t6);}

/* k4899 in hash-table-delete! in k4667 in k2028 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4901,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[5],t1);
t6=(C_word)C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4921,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,f_4921(t7,C_SCHEME_FALSE,t5));}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4968,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_4968(t10,((C_word*)t0)[2],C_SCHEME_FALSE,t5);}}

/* loop in k4899 in hash-table-delete! in k4667 in k2028 */
static void C_fcall f_4968(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4968,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4987,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t5,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
/* srfi-69.scm: 919  test */
t8=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k4985 in loop in k4899 in hash-table-delete! in k4667 in k2028 */
static void C_ccall f_4987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[10])?(C_word)C_i_setslot(((C_word*)t0)[10],C_fix(1),((C_word*)t0)[9]):(C_word)C_i_setslot(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]));
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 926  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4968(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[9]);}}

/* loop in k4899 in hash-table-delete! in k4667 in k2028 */
static C_word C_fcall f_4921(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
if(C_truep((C_word)C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[6],t5);
if(C_truep(t6)){
t7=(C_truep(t1)?(C_word)C_i_setslot(t1,C_fix(1),t4):(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t4));
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]);
return(C_SCHEME_TRUE);}
else{
t10=t2;
t11=t4;
t1=t10;
t2=t11;
goto loop;}}}

/* hash-table-exists? in k4667 in k2028 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4777,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[89]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(3));
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4793,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t6,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_block_size(t5);
/* srfi-69.scm: 872  hash */
t10=t7;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t3,t9);}

/* k4791 in hash-table-exists? in k4667 in k2028 */
static void C_ccall f_4793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4793,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],t1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4808,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4808(t4,t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4848(t7,((C_word*)t0)[2],t3);}}

/* loop in k4791 in hash-table-exists? in k4667 in k2028 */
static void C_fcall f_4848(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4848,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4861,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 884  test */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4859 in loop in k4791 in hash-table-exists? in k4667 in k2028 */
static void C_ccall f_4861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 885  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4848(t3,((C_word*)t0)[4],t2);}}

/* loop in k4791 in hash-table-exists? in k4667 in k2028 */
static C_word C_fcall f_4808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* hash-table-ref/default in k4667 in k2028 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4671,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[29],lf[88]);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(3));
t8=(C_word)C_slot(t2,C_fix(4));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4687,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t6,a[6]=t7,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_block_size(t6);
/* srfi-69.scm: 846  hash */
t11=t8;
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t3,t10);}

/* k4685 in hash-table-ref/default in k4667 in k2028 */
static void C_ccall f_4687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4687,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4702,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4702(t4,t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4741,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4741(t7,((C_word*)t0)[2],t3);}}

/* loop in k4685 in hash-table-ref/default in k4667 in k2028 */
static void C_fcall f_4741(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4741,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4757,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 861  test */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4755 in loop in k4685 in hash-table-ref/default in k4667 in k2028 */
static void C_ccall f_4757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 863  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4741(t3,((C_word*)t0)[5],t2);}}

/* loop in k4685 in hash-table-ref/default in k4667 in k2028 */
static C_word C_fcall f_4702(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return((C_word)C_slot(t2,C_fix(1)));}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* hash-table-set! in k2028 */
static void C_ccall f_4474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4474,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[29],lf[85]);
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_u_fixnum_plus(t6,C_fix(1));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(5));
t11=(C_word)C_slot(t8,C_fix(6));
t12=(C_word)C_block_size(t9);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4657,a[2]=t11,a[3]=t12,a[4]=t9,a[5]=t8,a[6]=t7,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[2],a[10]=t1,a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t14=(C_word)C_a_i_times(&a,2,t12,t10);
/* srfi-69.scm: 636  floor */
t15=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t13,t14);}

/* k4655 in hash-table-set! in k2028 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4657,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4649,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-69.scm: 637  floor */
t5=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4647 in k4655 in hash-table-set! in k2028 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4649,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4502,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(1073741823)))){
t5=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],((C_word*)t0)[6]);
t6=t4;
f_4630(t6,(C_truep(t5)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[6],t2):C_SCHEME_FALSE));}
else{
t5=t4;
f_4630(t5,C_SCHEME_FALSE);}}

/* k4628 in k4647 in k4655 in hash-table-set! in k2028 */
static void C_fcall f_4630(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 640  hash-table-resize! */
t2=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_4502(2,t2,C_SCHEME_UNDEFINED);}}

/* k4500 in k4647 in k4655 in hash-table-set! in k2028 */
static void C_ccall f_4502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4502,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm: 780  hash */
t7=t2;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[4],t5);}

/* k4515 in k4500 in k4647 in k4655 in hash-table-set! in k2028 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4517,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4523,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4534,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp));
t8=((C_word*)t6)[1];
f_4534(t8,t3,t2);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4583,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp));
t8=((C_word*)t6)[1];
f_4583(t8,t3,t2);}}

/* loop in k4515 in k4500 in k4647 in k4655 in hash-table-set! in k2028 */
static void C_fcall f_4583(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4583,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
t5=(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(2),((C_word*)t0)[4]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4613,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[9],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 800  test */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[10],t5);}}

/* k4611 in loop in k4515 in k4500 in k4647 in k4655 in hash-table-set! in k2028 */
static void C_ccall f_4613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4]));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 802  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4583(t3,((C_word*)t0)[6],t2);}}

/* loop in k4515 in k4500 in k4647 in k4655 in hash-table-set! in k2028 */
static void C_fcall f_4534(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4534,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[7]);
t5=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[9],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(t3,C_fix(1),((C_word*)t0)[8]));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 792  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k4521 in k4515 in k4500 in k4647 in k4655 in hash-table-set! in k2028 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[86]+1));}

/* hash-table-update!/default in k2028 */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4462,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_structure_2(t2,lf[29],lf[84]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4469,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 767  ##sys#check-closure */
t8=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t4,lf[84]);}

/* k4467 in hash-table-update!/default in k2028 */
static void C_ccall f_4469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 768  *hash-table-update!/default */
t2=lf[83];
f_4255(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* *hash-table-update!/default in k2028 */
static void C_fcall f_4255(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4255,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_u_fixnum_plus(t6,C_fix(1));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(5));
t11=(C_word)C_slot(t8,C_fix(6));
t12=(C_word)C_block_size(t9);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4452,a[2]=t11,a[3]=t12,a[4]=t9,a[5]=t8,a[6]=t1,a[7]=t5,a[8]=t4,a[9]=t7,a[10]=t3,a[11]=((C_word*)t0)[2],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t14=(C_word)C_a_i_times(&a,2,t12,t10);
/* srfi-69.scm: 636  floor */
t15=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t13,t14);}

/* k4450 in *hash-table-update!/default in k2028 */
static void C_ccall f_4452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4452,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4444,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-69.scm: 637  floor */
t5=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4442 in k4450 in *hash-table-update!/default in k2028 */
static void C_ccall f_4444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4444,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4280,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4425,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(1073741823)))){
t5=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],((C_word*)t0)[9]);
t6=t4;
f_4425(t6,(C_truep(t5)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[9],t2):C_SCHEME_FALSE));}
else{
t5=t4;
f_4425(t5,C_SCHEME_FALSE);}}

/* k4423 in k4442 in k4450 in *hash-table-update!/default in k2028 */
static void C_fcall f_4425(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 640  hash-table-resize! */
t2=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_4280(2,t2,C_SCHEME_UNDEFINED);}}

/* k4278 in k4442 in k4450 in *hash-table-update!/default in k2028 */
static void C_ccall f_4280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4280,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm: 735  hash */
t7=t2;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k4293 in k4278 in k4442 in k4450 in *hash-table-update!/default in k2028 */
static void C_ccall f_4295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4295,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],t1);
t3=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4309,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_4309(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4368,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_4368(t7,((C_word*)t0)[2],t2);}}

/* loop in k4293 in k4278 in k4442 in k4450 in *hash-table-update!/default in k2028 */
static void C_fcall f_4368(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4368,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4378,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 754  func */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4401,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 759  test */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k4399 in loop in k4293 in k4278 in k4442 in k4450 in *hash-table-update!/default in k2028 */
static void C_ccall f_4401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4401,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4404,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 760  func */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 763  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4368(t3,((C_word*)t0)[5],t2);}}

/* k4402 in k4399 in loop in k4293 in k4278 in k4442 in k4450 in *hash-table-update!/default in k2028 */
static void C_ccall f_4404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4376 in loop in k4293 in k4278 in k4442 in k4450 in *hash-table-update!/default in k2028 */
static void C_ccall f_4378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4378,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* loop in k4293 in k4278 in k4442 in k4450 in *hash-table-update!/default in k2028 */
static void C_fcall f_4309(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4309,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4319,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 741  func */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4345,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 747  func */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 750  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k4343 in loop in k4293 in k4278 in k4442 in k4450 in *hash-table-update!/default in k2028 */
static void C_ccall f_4345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4317 in loop in k4293 in k4278 in k4442 in k4450 in *hash-table-update!/default in k2028 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4319,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* hash-table-update! in k2028 */
static void C_ccall f_3968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_3968r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3968r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3968r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3970,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4193,a[2]=t5,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4210,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-func12671357 */
t8=t7;
f_4210(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-thunk12681344 */
t10=t6;
f_4193(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body12651274 */
t12=t5;
f_3970(t12,t1,t8,t10);}}}

/* def-func1267 in hash-table-update! in k2028 */
static void C_fcall f_4210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4210,NULL,2,t0,t1);}
/* def-thunk12681344 */
t2=((C_word*)t0)[2];
f_4193(t2,t1,*((C_word*)lf[82]+1));}

/* def-thunk1268 in hash-table-update! in k2028 */
static void C_fcall f_4193(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4193,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(9));
t4=(C_truep(t3)?t3:(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4205,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
/* body12651274 */
t5=((C_word*)t0)[2];
f_3970(t5,t1,t2,t4);}

/* f_4205 in def-thunk1268 in hash-table-update! in k2028 */
static void C_ccall f_4205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4205,2,t0,t1);}
/* srfi-69.scm: 684  ##sys#signal-hook */
t2=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[80],lf[78],lf[81],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* body1265 in hash-table-update! in k2028 */
static void C_fcall f_3970(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3970,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(((C_word*)t0)[4],lf[29],lf[78]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3977,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 688  ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[78]);}

/* k3975 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 689  ##sys#check-closure */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[78]);}

/* k3978 in k3975 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_3980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3980,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(2));
t3=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t4=((C_word*)t0)[7];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_slot(t4,C_fix(5));
t7=(C_word)C_slot(t4,C_fix(6));
t8=(C_word)C_block_size(t5);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4184,a[2]=t7,a[3]=t8,a[4]=t5,a[5]=t4,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t3,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
t10=(C_word)C_a_i_times(&a,2,t8,t6);
/* srfi-69.scm: 636  floor */
t11=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}

/* k4182 in k3978 in k3975 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4184,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4176,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-69.scm: 637  floor */
t5=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4174 in k4182 in k3978 in k3975 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4176,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4004,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4157,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(1073741823)))){
t5=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],((C_word*)t0)[9]);
t6=t4;
f_4157(t6,(C_truep(t5)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[9],t2):C_SCHEME_FALSE));}
else{
t5=t4;
f_4157(t5,C_SCHEME_FALSE);}}

/* k4155 in k4174 in k4182 in k3978 in k3975 in body1265 in hash-table-update! in k2028 */
static void C_fcall f_4157(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 640  hash-table-resize! */
t2=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_4004(2,t2,C_SCHEME_UNDEFINED);}}

/* k4002 in k4174 in k4182 in k3978 in k3975 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4004,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm: 696  hash */
t7=t2;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k4017 in k4002 in k4174 in k4182 in k3978 in k3975 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],t1);
t3=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4033,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_4033(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4096,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_4096(t7,((C_word*)t0)[2],t2);}}

/* loop in k4017 in k4002 in k4174 in k4182 in k3978 in k3975 in body1265 in hash-table-update! in k2028 */
static void C_fcall f_4096(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4096,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4106,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4124,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 715  thunk */
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4133,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 720  test */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k4131 in loop in k4017 in k4002 in k4174 in k4182 in k3978 in k3975 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4133,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4136,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 721  func */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 724  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4096(t3,((C_word*)t0)[5],t2);}}

/* k4134 in k4131 in loop in k4017 in k4002 in k4174 in k4182 in k3978 in k3975 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4122 in loop in k4017 in k4002 in k4174 in k4182 in k3978 in k3975 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 715  func */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4104 in loop in k4017 in k4002 in k4174 in k4182 in k3978 in k3975 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4106,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* loop in k4017 in k4002 in k4174 in k4182 in k3978 in k3975 in body1265 in hash-table-update! in k2028 */
static void C_fcall f_4033(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4033,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4043,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4061,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 702  thunk */
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4073,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 708  func */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 711  loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}}}

/* k4071 in loop in k4017 in k4002 in k4174 in k4182 in k3978 in k3975 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4059 in loop in k4017 in k4002 in k4174 in k4182 in k3978 in k3975 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 702  func */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4041 in loop in k4017 in k4002 in k4174 in k4182 in k3978 in k3975 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4043,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* hash-table-copy in k2028 */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3959,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[77]);
/* srfi-69.scm: 669  *hash-table-copy */
t4=lf[76];
f_3847(t4,t1,t2);}

/* *hash-table-copy in k2028 */
static void C_fcall f_3847(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3847,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3857,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 649  make-vector */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,C_SCHEME_END_OF_LIST);}

/* k3855 in *hash-table-copy in k2028 */
static void C_ccall f_3857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3857,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3862,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3862(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop1219 in k3855 in *hash-table-copy in k2028 */
static void C_fcall f_3862(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3862,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(4));
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(6));
t8=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t9=(C_word)C_slot(((C_word*)t0)[5],C_fix(8));
t10=(C_word)C_slot(((C_word*)t0)[5],C_fix(9));
/* srfi-69.scm: 652  *make-hash-table */
t11=lf[28];
f_3259(t11,t1,t3,t4,t5,t6,t7,t10,(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3918,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3924,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_3924(t8,t3,t4);}}

/* copy-loop in doloop1219 in k3855 in *hash-table-copy in k2028 */
static void C_fcall f_3924(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3924,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3945,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 665  copy-loop */
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k3943 in copy-loop in doloop1219 in k3855 in *hash-table-copy in k2028 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3945,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3916 in doloop1219 in k3855 in *hash-table-copy in k2028 */
static void C_ccall f_3918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3862(t4,((C_word*)t0)[2],t3);}

/* hash-table-resize! in k2028 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3821,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_times(t4,C_fix(2));
t6=(C_word)C_i_fixnum_min(C_fix(1073741823),t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3828,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 624  hash-table-canonical-length */
f_3229(t7,lf[24],t6);}

/* k3826 in hash-table-resize! in k2028 */
static void C_ccall f_3828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 625  make-vector */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_SCHEME_END_OF_LIST);}

/* k3829 in k3826 in hash-table-resize! in k2028 */
static void C_ccall f_3831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3834,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t5);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3754,a[2]=t7,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t9,a[7]=t6,tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_3754(t11,t2,C_fix(0));}

/* doloop1160 in k3829 in k3826 in hash-table-resize! in k2028 */
static void C_fcall f_3754(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3754,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3764,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3777(t8,t3,t4);}}

/* loop in doloop1160 in k3829 in k3826 in hash-table-resize! in k2028 */
static void C_fcall f_3777(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3777,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3793,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 615  hash */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,((C_word*)t0)[2]);}}

/* k3791 in loop in doloop1160 in k3829 in k3826 in hash-table-resize! in k2028 */
static void C_ccall f_3793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3793,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_slot(((C_word*)t0)[5],t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[5],t1,t5);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 618  loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3777(t8,((C_word*)t0)[2],t7);}

/* k3762 in doloop1160 in k3829 in k3826 in hash-table-resize! in k2028 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3754(t3,((C_word*)t0)[2],t2);}

/* k3832 in k3829 in k3826 in hash-table-resize! in k2028 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]));}

/* hash-table-initial in k2028 */
static void C_ccall f_3727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3727,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[74]);
t4=(C_word)C_slot(t2,C_fix(9));
if(C_truep(t4)){
/* srfi-69.scm: 602  thunk */
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* hash-table-has-initial? in k2028 */
static void C_ccall f_3715(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3715,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[73]);
t4=(C_word)C_slot(t2,C_fix(9));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* hash-table-weak-values in k2028 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3706,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[72]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(8)));}

/* hash-table-weak-keys in k2028 */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3697,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[71]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(7)));}

/* hash-table-max-load in k2028 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3688,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[70]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* hash-table-min-load in k2028 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3679,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[69]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(5)));}

/* hash-table-hash-function in k2028 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3670,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[68]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(4)));}

/* hash-table-equivalence-function in k2028 */
static void C_ccall f_3661(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3661,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[67]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* hash-table-size in k2028 */
static void C_ccall f_3652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3652,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[66]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(2)));}

/* hash-table? in k2028 */
static void C_ccall f_3646(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3646,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[29]));}

/* make-hash-table in k2028 */
static void C_ccall f_3283(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+41)){
C_save_and_reclaim((void*)tr2r,(void*)f_3283r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3283r(t0,t1,t2);}}

static void C_ccall f_3283r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(41);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[32]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(307);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=lf[37];
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=lf[38];
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3361,a[2]=t4,a[3]=t2,a[4]=t17,a[5]=t12,a[6]=t16,a[7]=t14,a[8]=t8,a[9]=t6,a[10]=t1,a[11]=t10,tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t4)[1]))){
t19=t18;
f_3361(t19,C_SCHEME_UNDEFINED);}
else{
t19=(C_word)C_u_i_car(((C_word*)t4)[1]);
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3636,a[2]=t4,a[3]=t19,a[4]=t6,a[5]=t18,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 481  keyword? */
t21=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t21+1)))(3,t21,t20,t19);}}

/* k3634 in make-hash-table in k2028 */
static void C_ccall f_3636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3636,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3361(t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3639,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 482  ##sys#check-closure */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[36]);}}

/* k3637 in k3634 in make-hash-table in k2028 */
static void C_ccall f_3639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3361(t5,t4);}

/* k3359 in make-hash-table in k2028 */
static void C_fcall f_3361(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3361,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_3364(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3616,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 487  keyword? */
t5=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k3614 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3616,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3364(t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3619,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 488  ##sys#check-closure */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[36]);}}

/* k3617 in k3614 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3364(t5,t4);}

/* k3362 in k3359 in make-hash-table in k2028 */
static void C_fcall f_3364(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3364,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_3367(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 493  keyword? */
t5=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k3582 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3584,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3367(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[36]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3590,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)t0)[4]))){
t4=t3;
f_3590(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 496  error */
t4=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[36],lf[64],((C_word*)t0)[4]);}}}

/* k3588 in k3582 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[47]+1),((C_word*)t0)[5]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_3367(t6,t5);}

/* k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_fcall f_3367(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3367,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3370,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3402,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t4,a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3402(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_fcall f_3402(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3402,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3413,a[2]=((C_word*)t0)[9],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3423,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* srfi-69.scm: 506  keyword? */
t6=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}

/* k3421 in loop in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3423,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[12],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=t3;
f_3429(2,t4,(C_word)C_u_i_car(t2));}
else{
/* srfi-69.scm: 510  invarg-err */
t4=((C_word*)t0)[2];
f_3413(t4,t3,lf[62]);}}
else{
/* srfi-69.scm: 542  invarg-err */
t2=((C_word*)t0)[2];
f_3413(t2,((C_word*)t0)[10],lf[63]);}}

/* k3427 in k3421 in loop in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3432,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[43]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3445,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 513  ##sys#check-closure */
t5=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t1,lf[36]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[45]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3455,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 516  ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t1,lf[36]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[46]);
if(C_truep(t5)){
t6=(C_word)C_i_check_exact_2(t1,lf[36]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3468,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),t1))){
t8=t7;
f_3468(2,t8,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 521  error */
t8=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[36],lf[48],t1);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[49]);
if(C_truep(t6)){
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3486,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t8=t2;
f_3432(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[9],lf[50]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3496,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 526  ##sys#check-inexact */
t9=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t1,lf[36]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[9],lf[55]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3521,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 531  ##sys#check-inexact */
t10=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t1,lf[36]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[59]);
if(C_truep(t9)){
t10=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t11=C_SCHEME_UNDEFINED;
t12=t2;
f_3432(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[60]);
if(C_truep(t10)){
t11=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t12=C_SCHEME_UNDEFINED;
t13=t2;
f_3432(2,t13,t12);}
else{
/* srfi-69.scm: 540  invarg-err */
t11=((C_word*)t0)[2];
f_3413(t11,t2,lf[61]);}}}}}}}}}

/* k3519 in k3427 in k3421 in loop in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_flonum_lessp(lf[56],((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[3],lf[57]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_3524(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 533  error */
t5=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[36],lf[58],((C_word*)t0)[3]);}}

/* k3522 in k3519 in k3427 in k3421 in loop in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3432(2,t3,t2);}

/* k3494 in k3427 in k3421 in loop in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_flonum_lessp(lf[51],((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[3],lf[52]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_3499(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 528  error */
t5=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[36],lf[53],((C_word*)t0)[3]);}}

/* k3497 in k3494 in k3427 in k3421 in loop in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3432(2,t3,t2);}

/* f_3486 in k3427 in k3421 in loop in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3486,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3466 in k3427 in k3421 in loop in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[47]+1),((C_word*)t0)[4]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_3432(2,t4,t3);}

/* k3453 in k3427 in k3421 in loop in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3432(2,t3,t2);}

/* k3443 in k3427 in k3421 in loop in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3432(2,t3,t2);}

/* k3430 in k3427 in k3421 in loop in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 541  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3402(t3,((C_word*)t0)[2],t2);}

/* invarg-err in loop in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_fcall f_3413(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3413,NULL,3,t0,t1,t2);}
/* srfi-69.scm: 505  error */
t3=*((C_word*)lf[41]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[36],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3368 in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_flonum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* srfi-69.scm: 545  error */
t3=*((C_word*)lf[41]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[36],lf[42],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t2;
f_3373(2,t3,C_SCHEME_UNDEFINED);}}

/* k3371 in k3368 in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm: 547  hash-table-canonical-length */
f_3229(t2,lf[24],((C_word*)((C_word*)t0)[9])[1]);}

/* k3375 in k3371 in k3368 in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3377,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3380,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t4=t3;
f_3380(t4,C_SCHEME_UNDEFINED);}
else{
t4=f_3285(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=t3;
f_3380(t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3393,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 554  warning */
t6=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,lf[36],lf[40]);}}}

/* k3391 in k3375 in k3371 in k3368 in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[17]+1));
t3=((C_word*)t0)[2];
f_3380(t3,t2);}

/* k3378 in k3375 in k3371 in k3368 in k3365 in k3362 in k3359 in make-hash-table in k2028 */
static void C_fcall f_3380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 557  *make-hash-table */
t2=lf[28];
f_3259(t2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* hash-for-test in make-hash-table in k2028 */
static C_word C_fcall f_3285(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t1=(C_word)C_eqp(((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t2=(C_truep(t1)?t1:(C_word)C_eqp(*((C_word*)lf[30]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t2)){
return(*((C_word*)lf[13]+1));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)((C_word*)t0)[7])[1]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(*((C_word*)lf[31]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t4)){
return(*((C_word*)lf[15]+1));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],((C_word*)((C_word*)t0)[7])[1]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(*((C_word*)lf[32]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t6)){
return(*((C_word*)lf[17]+1));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(*((C_word*)lf[33]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t8)){
return(*((C_word*)lf[19]+1));}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)((C_word*)t0)[7])[1]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(*((C_word*)lf[34]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t10)){
return(*((C_word*)lf[23]+1));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)((C_word*)t0)[7])[1]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(*((C_word*)lf[35]+1),((C_word*)((C_word*)t0)[7])[1]));
return((C_truep(t12)?*((C_word*)lf[2]+1):C_SCHEME_FALSE));}}}}}}

/* *make-hash-table in k2028 */
static void C_fcall f_3259(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3259,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3263,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t8))){
/* srfi-69.scm: 429  make-vector */
t10=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t4,C_SCHEME_END_OF_LIST);}
else{
t10=t9;
f_3263(2,t10,(C_word)C_u_i_car(t8));}}

/* k3261 in *make-hash-table in k2028 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3263,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,10,lf[29],t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]));}

/* hash-table-canonical-length in k2028 */
static void C_fcall f_3229(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3229,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3235,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3235(t4,t2));}

/* loop in hash-table-canonical-length in k2028 */
static C_word C_fcall f_3235(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t3));
if(C_truep(t5)){
return(t2);}
else{
t7=t3;
t1=t7;
goto loop;}}

/* string-ci-hash in k2028 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_3105r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3105r(t0,t1,t2,t3);}}

static void C_ccall f_3105r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(14);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_check_string_2(t2,lf[22]);
t9=(C_word)C_i_check_exact_2(t5,lf[22]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3121,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t7))){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3142,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3161,a[2]=t11,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3170,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-start824841 */
t14=t13;
f_3170(t14,t10);}
else{
t14=(C_word)C_u_i_car(t7);
t15=(C_word)C_slot(t7,C_fix(1));
if(C_truep((C_word)C_i_nullp(t15))){
/* def-end825837 */
t16=t12;
f_3161(t16,t10,t14);}
else{
t16=(C_word)C_u_i_car(t15);
t17=(C_word)C_slot(t15,C_fix(1));
/* body822830 */
t18=t11;
f_3142(t18,t10,t14,t16);}}}
else{
t11=t10;
f_3121(2,t11,t2);}}

/* def-start824 in string-ci-hash in k2028 */
static void C_fcall f_3170(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3170,NULL,2,t0,t1);}
/* def-end825837 */
t2=((C_word*)t0)[2];
f_3161(t2,t1,C_fix(0));}

/* def-end825 in string-ci-hash in k2028 */
static void C_fcall f_3161(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3161,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(((C_word*)t0)[3]);
/* body822830 */
t4=((C_word*)t0)[2];
f_3142(t4,t1,t2,t3);}

/* body822 in string-ci-hash in k2028 */
static void C_fcall f_3142(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3142,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3146,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(((C_word*)t0)[2]);
/* srfi-69.scm: 377  ##sys#check-range */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,t2,C_fix(0),t5,lf[23]);}

/* k3144 in body822 in string-ci-hash in k2028 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* srfi-69.scm: 378  ##sys#check-range */
t4=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[2],C_fix(0),t3,lf[23]);}

/* k3147 in k3144 in body822 in string-ci-hash in k2028 */
static void C_ccall f_3149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 379  ##sys#substring */
t2=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3119 in string-ci-hash in k2028 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_hash_string_ci(t1);
t3=(C_word)C_fixnum_lessp(t2,C_fix(0));
t4=(C_truep(t3)?(C_word)C_u_fixnum_negate(t2):t2);
t5=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_modulo(t5,((C_word*)t0)[2]));}

/* string-hash in k2028 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_2983r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2983r(t0,t1,t2,t3);}}

static void C_ccall f_2983r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(14);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_check_string_2(t2,lf[19]);
t9=(C_word)C_i_check_exact_2(t5,lf[19]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2999,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t7))){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3020,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3039,a[2]=t11,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3048,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-start745762 */
t14=t13;
f_3048(t14,t10);}
else{
t14=(C_word)C_u_i_car(t7);
t15=(C_word)C_slot(t7,C_fix(1));
if(C_truep((C_word)C_i_nullp(t15))){
/* def-end746758 */
t16=t12;
f_3039(t16,t10,t14);}
else{
t16=(C_word)C_u_i_car(t15);
t17=(C_word)C_slot(t15,C_fix(1));
/* body743751 */
t18=t11;
f_3020(t18,t10,t14,t16);}}}
else{
t11=t10;
f_2999(2,t11,t2);}}

/* def-start745 in string-hash in k2028 */
static void C_fcall f_3048(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3048,NULL,2,t0,t1);}
/* def-end746758 */
t2=((C_word*)t0)[2];
f_3039(t2,t1,C_fix(0));}

/* def-end746 in string-hash in k2028 */
static void C_fcall f_3039(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3039,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(((C_word*)t0)[3]);
/* body743751 */
t4=((C_word*)t0)[2];
f_3020(t4,t1,t2,t3);}

/* body743 in string-hash in k2028 */
static void C_fcall f_3020(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3020,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3024,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(((C_word*)t0)[2]);
/* srfi-69.scm: 365  ##sys#check-range */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,t2,C_fix(0),t5,lf[19]);}

/* k3022 in body743 in string-hash in k2028 */
static void C_ccall f_3024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* srfi-69.scm: 366  ##sys#check-range */
t4=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[2],C_fix(0),t3,lf[19]);}

/* k3025 in k3022 in body743 in string-hash in k2028 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 367  ##sys#substring */
t2=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2997 in string-hash in k2028 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_hash_string(t1);
t3=(C_word)C_fixnum_lessp(t2,C_fix(0));
t4=(C_truep(t3)?(C_word)C_u_fixnum_negate(t2):t2);
t5=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_modulo(t5,((C_word*)t0)[2]));}

/* equal?-hash in k2028 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2941r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2941r(t0,t1,t2,t3);}}

static void C_ccall f_2941r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[18]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2951,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 353  *equal?-hash */
f_2607(t7,t2);}

/* k2949 in equal?-hash in k2028 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* *equal?-hash in k2028 */
static void C_fcall f_2607(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2607,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2610,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2675,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2706,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
/* srfi-69.scm: 349  recursive-hash */
t12=((C_word*)t8)[1];
f_2706(t12,t1,t2,C_fix(0));}

/* recursive-hash in *equal?-hash in k2028 */
static void C_fcall f_2706(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2706,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(4)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(99));}
else{
if(C_truep((C_word)C_fixnump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(256));
case C_SCHEME_FALSE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_hash_string(t5));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t4=t2;
if(C_truep((C_word)C_i_flonump(t4))){
t5=(C_word)C_subbyte(t4,C_fix(7));
t6=(C_word)C_subbyte(t4,C_fix(6));
t7=(C_word)C_subbyte(t4,C_fix(5));
t8=(C_word)C_subbyte(t4,C_fix(4));
t9=(C_word)C_subbyte(t4,C_fix(3));
t10=(C_word)C_subbyte(t4,C_fix(2));
t11=(C_word)C_subbyte(t4,C_fix(1));
t12=(C_word)C_subbyte(t4,C_fix(0));
t13=(C_word)C_fixnum_shift_left(t12,C_fix(1));
t14=(C_word)C_u_fixnum_plus(t11,t13);
t15=(C_word)C_fixnum_shift_left(t14,C_fix(1));
t16=(C_word)C_u_fixnum_plus(t10,t15);
t17=(C_word)C_fixnum_shift_left(t16,C_fix(1));
t18=(C_word)C_u_fixnum_plus(t9,t17);
t19=(C_word)C_fixnum_shift_left(t18,C_fix(1));
t20=(C_word)C_u_fixnum_plus(t8,t19);
t21=(C_word)C_fixnum_shift_left(t20,C_fix(1));
t22=(C_word)C_u_fixnum_plus(t7,t21);
t23=(C_word)C_fixnum_shift_left(t22,C_fix(1));
t24=(C_word)C_u_fixnum_plus(t6,t23);
t25=(C_word)C_fixnum_shift_left(t24,C_fix(1));
t26=(C_word)C_u_fixnum_plus(t5,t25);
t27=t1;
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,(C_word)C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2843,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 165  ##sys#number-hash-hook */
t6=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}
else{
t4=t2;
if(C_truep((C_word)C_blockp(t4))){
t5=t2;
if(C_truep((C_word)C_byteblockp(t5))){
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_hash_string(t6));}
else{
if(C_truep((C_word)C_i_listp(t2))){
t6=t2;
t7=(C_word)C_i_length(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2869,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(t6,C_fix(0));
/* srfi-69.scm: 285  recursive-atomic-hash */
t10=((C_word*)((C_word*)t0)[3])[1];
f_2675(t10,t8,t9,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=t2;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2898,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_slot(t6,C_fix(0));
/* srfi-69.scm: 288  recursive-atomic-hash */
t9=((C_word*)((C_word*)t0)[3])[1];
f_2675(t9,t7,t8,t3);}
else{
t6=t2;
if(C_truep((C_word)C_portp(t6))){
t7=t2;
t8=(C_word)C_peek_fixnum(t7,C_fix(0));
t9=(C_word)C_fixnum_shift_left(t8,C_fix(4));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2919,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 293  input-port? */
t11=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t7);}
else{
t7=t2;
if(C_truep((C_word)C_specialp(t7))){
t8=t2;
t9=(C_word)C_peek_fixnum(t8,C_fix(0));
/* srfi-69.scm: 298  vector-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_2610(t10,t1,t8,t9,t3,C_fix(1));}
else{
t8=t2;
/* srfi-69.scm: 301  vector-hash */
t9=((C_word*)((C_word*)t0)[2])[1];
f_2610(t9,t1,t8,C_fix(0),t3,C_fix(0));}}}}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(262));}}}}}}}}}}

/* k2917 in recursive-hash in *equal?-hash in k2028 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?C_fix(260):C_fix(261));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t2));}

/* k2896 in recursive-hash in *equal?-hash in k2028 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2898,2,t0,t1);}
t2=(C_word)C_fixnum_shift_left(t1,C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2890,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 289  recursive-atomic-hash */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2675(t5,t3,t4,((C_word*)t0)[2]);}

/* k2888 in k2896 in recursive-hash in *equal?-hash in k2028 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t1));}

/* k2867 in recursive-hash in *equal?-hash in k2028 */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t1));}

/* k2841 in recursive-hash in *equal?-hash in k2028 */
static void C_ccall f_2843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fix(t1));}

/* recursive-atomic-hash in *equal?-hash in k2028 */
static void C_fcall f_2675(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2675,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_i_not((C_word)C_blockp(t4));
t6=(C_truep(t5)?t5:(C_word)C_i_symbolp(t4));
t7=(C_truep(t6)?t6:(C_word)C_i_numberp(t4));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2691,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t7)){
t9=t8;
f_2691(t9,t7);}
else{
t9=t2;
t10=t8;
f_2691(t10,(C_word)C_byteblockp(t9));}}

/* k2689 in recursive-atomic-hash in *equal?-hash in k2028 */
static void C_fcall f_2691(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 323  recursive-hash */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2706(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(99));}}

/* vector-hash in *equal?-hash in k2028 */
static void C_fcall f_2610(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2610,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(t6,t3);
t8=(C_word)C_i_fixnum_min(C_fix(4),t6);
t9=(C_word)C_u_fixnum_difference(t8,t5);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2627,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_2627(t13,t1,t7,t5,t9);}

/* loop in vector-hash in *equal?-hash in k2028 */
static void C_fcall f_2627(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2627,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_word)C_fixnum_shift_left(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2661,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],t3);
t9=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 315  recursive-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_2706(t10,t7,t8,t9);}}

/* k2659 in loop in vector-hash in *equal?-hash in k2028 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 313  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2627(t6,((C_word*)t0)[2],t3,t4,t5);}

/* eqv?-hash in k2028 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2566r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2566r(t0,t1,t2,t3);}}

static void C_ccall f_2566r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[15]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2576,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t8=t7;
f_2576(2,t8,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t8=t7;
f_2576(2,t8,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t8=t7;
f_2576(2,t8,C_fix(256));
case C_SCHEME_FALSE:
t8=t7;
f_2576(2,t8,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t8=t7;
f_2576(2,t8,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t8=t7;
f_2576(2,t8,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t8=(C_word)C_slot(t2,C_fix(1));
t9=t7;
f_2576(2,t9,(C_word)C_hash_string(t8));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_flonump(t2))){
t8=(C_word)C_subbyte(t2,C_fix(7));
t9=(C_word)C_subbyte(t2,C_fix(6));
t10=(C_word)C_subbyte(t2,C_fix(5));
t11=(C_word)C_subbyte(t2,C_fix(4));
t12=(C_word)C_subbyte(t2,C_fix(3));
t13=(C_word)C_subbyte(t2,C_fix(2));
t14=(C_word)C_subbyte(t2,C_fix(1));
t15=(C_word)C_subbyte(t2,C_fix(0));
t16=(C_word)C_fixnum_shift_left(t15,C_fix(1));
t17=(C_word)C_u_fixnum_plus(t14,t16);
t18=(C_word)C_fixnum_shift_left(t17,C_fix(1));
t19=(C_word)C_u_fixnum_plus(t13,t18);
t20=(C_word)C_fixnum_shift_left(t19,C_fix(1));
t21=(C_word)C_u_fixnum_plus(t12,t20);
t22=(C_word)C_fixnum_shift_left(t21,C_fix(1));
t23=(C_word)C_u_fixnum_plus(t11,t22);
t24=(C_word)C_fixnum_shift_left(t23,C_fix(1));
t25=(C_word)C_u_fixnum_plus(t10,t24);
t26=(C_word)C_fixnum_shift_left(t25,C_fix(1));
t27=(C_word)C_u_fixnum_plus(t9,t26);
t28=(C_word)C_fixnum_shift_left(t27,C_fix(1));
t29=(C_word)C_u_fixnum_plus(t8,t28);
t30=t7;
f_2576(2,t30,(C_word)C_fixnum_times(C_fix(331804471),t29));}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2555,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 165  ##sys#number-hash-hook */
t9=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}
else{
if(C_truep((C_word)C_blockp(t2))){
/* srfi-69.scm: 184  *equal?-hash */
f_2607(t7,t2);}
else{
t8=t7;
f_2576(2,t8,C_fix(262));}}}}}}}}}

/* k2553 in eqv?-hash in k2028 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2576(2,t2,(C_word)C_fix(t1));}

/* k2574 in eqv?-hash in k2028 */
static void C_ccall f_2576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* eq?-hash in k2028 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2382r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2382r(t0,t1,t2,t3);}}

static void C_ccall f_2382r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[13]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2392,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t8=t7;
f_2392(2,t8,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t8=t7;
f_2392(2,t8,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t8=t7;
f_2392(2,t8,C_fix(256));
case C_SCHEME_FALSE:
t8=t7;
f_2392(2,t8,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t8=t7;
f_2392(2,t8,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t8=t7;
f_2392(2,t8,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t8=(C_word)C_slot(t2,C_fix(1));
t9=t7;
f_2392(2,t9,(C_word)C_hash_string(t8));}
else{
if(C_truep((C_word)C_blockp(t2))){
/* srfi-69.scm: 184  *equal?-hash */
f_2607(t7,t2);}
else{
t8=t7;
f_2392(2,t8,C_fix(262));}}}}}}}}

/* k2390 in eq?-hash in k2028 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* keyword-hash in k2028 */
static void C_ccall f_2278(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2278r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2278r(t0,t1,t2,t3);}}

static void C_ccall f_2278r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2285,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 220  ##sys#check-keyword */
t7=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,lf[12]);}

/* k2283 in keyword-hash in k2028 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[12]);
t3=((C_word*)t0)[3];
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_hash_string(t4);
t6=(C_word)C_fixnum_lessp(t5,C_fix(0));
t7=(C_truep(t6)?(C_word)C_u_fixnum_negate(t5):t5);
t8=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_fixnum_modulo(t8,((C_word*)t0)[4]));}

/* ##sys#check-keyword in k2028 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2252r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2252r(t0,t1,t2,t3);}}

static void C_ccall f_2252r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2259,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 207  keyword? */
t5=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2257 in ##sys#check-keyword in k2028 */
static void C_ccall f_2259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_slot(((C_word*)t0)[3],C_fix(0)));
/* srfi-69.scm: 208  ##sys#signal-hook */
t4=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[9],t3,lf[10],((C_word*)t0)[2]);}}

/* symbol-hash in k2028 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2208r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2208r(t0,t1,t2,t3);}}

static void C_ccall f_2208r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_symbol_2(t2,lf[7]);
t7=(C_word)C_i_check_exact_2(t5,lf[7]);
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_hash_string(t9);
t11=(C_word)C_fixnum_lessp(t10,C_fix(0));
t12=(C_truep(t11)?(C_word)C_u_fixnum_negate(t10):t10);
t13=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_fixnum_modulo(t13,t5));}

/* object-uid-hash in k2028 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2167r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2167r(t0,t1,t2,t3);}}

static void C_ccall f_2167r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[6]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2177,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 184  *equal?-hash */
f_2607(t7,t2);}

/* k2175 in object-uid-hash in k2028 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* number-hash in k2028 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2038r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2038r(t0,t1,t2,t3);}}

static void C_ccall f_2038r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2045,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_numberp(t2))){
t7=t6;
f_2045(2,t7,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 173  ##sys#signal-hook */
t7=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[4],lf[2],lf[5],t2);}}

/* k2043 in number-hash in k2028 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2045,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[2]);
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2051,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t3))){
t5=t4;
f_2051(t5,t3);}
else{
if(C_truep((C_word)C_i_flonump(t3))){
t5=(C_word)C_subbyte(t3,C_fix(7));
t6=(C_word)C_subbyte(t3,C_fix(6));
t7=(C_word)C_subbyte(t3,C_fix(5));
t8=(C_word)C_subbyte(t3,C_fix(4));
t9=(C_word)C_subbyte(t3,C_fix(3));
t10=(C_word)C_subbyte(t3,C_fix(2));
t11=(C_word)C_subbyte(t3,C_fix(1));
t12=(C_word)C_subbyte(t3,C_fix(0));
t13=(C_word)C_fixnum_shift_left(t12,C_fix(1));
t14=(C_word)C_u_fixnum_plus(t11,t13);
t15=(C_word)C_fixnum_shift_left(t14,C_fix(1));
t16=(C_word)C_u_fixnum_plus(t10,t15);
t17=(C_word)C_fixnum_shift_left(t16,C_fix(1));
t18=(C_word)C_u_fixnum_plus(t9,t17);
t19=(C_word)C_fixnum_shift_left(t18,C_fix(1));
t20=(C_word)C_u_fixnum_plus(t8,t19);
t21=(C_word)C_fixnum_shift_left(t20,C_fix(1));
t22=(C_word)C_u_fixnum_plus(t7,t21);
t23=(C_word)C_fixnum_shift_left(t22,C_fix(1));
t24=(C_word)C_u_fixnum_plus(t6,t23);
t25=(C_word)C_fixnum_shift_left(t24,C_fix(1));
t26=(C_word)C_u_fixnum_plus(t5,t25);
t27=t4;
f_2051(t27,(C_word)C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2147,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 165  ##sys#number-hash-hook */
t6=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}}

/* k2145 in k2043 in number-hash in k2028 */
static void C_ccall f_2147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2051(t2,(C_word)C_fix(t1));}

/* k2049 in k2043 in number-hash in k2028 */
static void C_fcall f_2051(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_u_fixnum_negate(t1):t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}

/* ##sys#number-hash-hook in k2028 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2032,3,t0,t1,t2);}
/* srfi-69.scm: 161  *equal?-hash */
f_2607(t1,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[222] = {
{"toplevel:srfi_69_scm",(void*)C_srfi_69_toplevel},
{"f_2030:srfi_69_scm",(void*)f_2030},
{"f_5626:srfi_69_scm",(void*)f_5626},
{"f_5636:srfi_69_scm",(void*)f_5636},
{"f_5648:srfi_69_scm",(void*)f_5648},
{"f_5705:srfi_69_scm",(void*)f_5705},
{"f_5724:srfi_69_scm",(void*)f_5724},
{"f_5663:srfi_69_scm",(void*)f_5663},
{"f_5746:srfi_69_scm",(void*)f_5746},
{"f_4669:srfi_69_scm",(void*)f_4669},
{"f_5604:srfi_69_scm",(void*)f_5604},
{"f_5611:srfi_69_scm",(void*)f_5611},
{"f_5616:srfi_69_scm",(void*)f_5616},
{"f_5624:srfi_69_scm",(void*)f_5624},
{"f_5592:srfi_69_scm",(void*)f_5592},
{"f_5599:srfi_69_scm",(void*)f_5599},
{"f_5580:srfi_69_scm",(void*)f_5580},
{"f_5587:srfi_69_scm",(void*)f_5587},
{"f_5568:srfi_69_scm",(void*)f_5568},
{"f_5575:srfi_69_scm",(void*)f_5575},
{"f_5502:srfi_69_scm",(void*)f_5502},
{"f_5514:srfi_69_scm",(void*)f_5514},
{"f_5530:srfi_69_scm",(void*)f_5530},
{"f_5558:srfi_69_scm",(void*)f_5558},
{"f_5453:srfi_69_scm",(void*)f_5453},
{"f_5465:srfi_69_scm",(void*)f_5465},
{"f_5484:srfi_69_scm",(void*)f_5484},
{"f_5475:srfi_69_scm",(void*)f_5475},
{"f_5388:srfi_69_scm",(void*)f_5388},
{"f_5403:srfi_69_scm",(void*)f_5403},
{"f_5419:srfi_69_scm",(void*)f_5419},
{"f_5323:srfi_69_scm",(void*)f_5323},
{"f_5338:srfi_69_scm",(void*)f_5338},
{"f_5354:srfi_69_scm",(void*)f_5354},
{"f_5294:srfi_69_scm",(void*)f_5294},
{"f_5301:srfi_69_scm",(void*)f_5301},
{"f_5306:srfi_69_scm",(void*)f_5306},
{"f_5304:srfi_69_scm",(void*)f_5304},
{"f_5221:srfi_69_scm",(void*)f_5221},
{"f_5236:srfi_69_scm",(void*)f_5236},
{"f_5252:srfi_69_scm",(void*)f_5252},
{"f_5205:srfi_69_scm",(void*)f_5205},
{"f_5219:srfi_69_scm",(void*)f_5219},
{"f_5193:srfi_69_scm",(void*)f_5193},
{"f_5128:srfi_69_scm",(void*)f_5128},
{"f_5140:srfi_69_scm",(void*)f_5140},
{"f_5163:srfi_69_scm",(void*)f_5163},
{"f_5176:srfi_69_scm",(void*)f_5176},
{"f_5150:srfi_69_scm",(void*)f_5150},
{"f_5112:srfi_69_scm",(void*)f_5112},
{"f_5119:srfi_69_scm",(void*)f_5119},
{"f_5016:srfi_69_scm",(void*)f_5016},
{"f_5023:srfi_69_scm",(void*)f_5023},
{"f_5037:srfi_69_scm",(void*)f_5037},
{"f_5063:srfi_69_scm",(void*)f_5063},
{"f_5082:srfi_69_scm",(void*)f_5082},
{"f_5050:srfi_69_scm",(void*)f_5050},
{"f_4885:srfi_69_scm",(void*)f_4885},
{"f_4901:srfi_69_scm",(void*)f_4901},
{"f_4968:srfi_69_scm",(void*)f_4968},
{"f_4987:srfi_69_scm",(void*)f_4987},
{"f_4921:srfi_69_scm",(void*)f_4921},
{"f_4777:srfi_69_scm",(void*)f_4777},
{"f_4793:srfi_69_scm",(void*)f_4793},
{"f_4848:srfi_69_scm",(void*)f_4848},
{"f_4861:srfi_69_scm",(void*)f_4861},
{"f_4808:srfi_69_scm",(void*)f_4808},
{"f_4671:srfi_69_scm",(void*)f_4671},
{"f_4687:srfi_69_scm",(void*)f_4687},
{"f_4741:srfi_69_scm",(void*)f_4741},
{"f_4757:srfi_69_scm",(void*)f_4757},
{"f_4702:srfi_69_scm",(void*)f_4702},
{"f_4474:srfi_69_scm",(void*)f_4474},
{"f_4657:srfi_69_scm",(void*)f_4657},
{"f_4649:srfi_69_scm",(void*)f_4649},
{"f_4630:srfi_69_scm",(void*)f_4630},
{"f_4502:srfi_69_scm",(void*)f_4502},
{"f_4517:srfi_69_scm",(void*)f_4517},
{"f_4583:srfi_69_scm",(void*)f_4583},
{"f_4613:srfi_69_scm",(void*)f_4613},
{"f_4534:srfi_69_scm",(void*)f_4534},
{"f_4523:srfi_69_scm",(void*)f_4523},
{"f_4462:srfi_69_scm",(void*)f_4462},
{"f_4469:srfi_69_scm",(void*)f_4469},
{"f_4255:srfi_69_scm",(void*)f_4255},
{"f_4452:srfi_69_scm",(void*)f_4452},
{"f_4444:srfi_69_scm",(void*)f_4444},
{"f_4425:srfi_69_scm",(void*)f_4425},
{"f_4280:srfi_69_scm",(void*)f_4280},
{"f_4295:srfi_69_scm",(void*)f_4295},
{"f_4368:srfi_69_scm",(void*)f_4368},
{"f_4401:srfi_69_scm",(void*)f_4401},
{"f_4404:srfi_69_scm",(void*)f_4404},
{"f_4378:srfi_69_scm",(void*)f_4378},
{"f_4309:srfi_69_scm",(void*)f_4309},
{"f_4345:srfi_69_scm",(void*)f_4345},
{"f_4319:srfi_69_scm",(void*)f_4319},
{"f_3968:srfi_69_scm",(void*)f_3968},
{"f_4210:srfi_69_scm",(void*)f_4210},
{"f_4193:srfi_69_scm",(void*)f_4193},
{"f_4205:srfi_69_scm",(void*)f_4205},
{"f_3970:srfi_69_scm",(void*)f_3970},
{"f_3977:srfi_69_scm",(void*)f_3977},
{"f_3980:srfi_69_scm",(void*)f_3980},
{"f_4184:srfi_69_scm",(void*)f_4184},
{"f_4176:srfi_69_scm",(void*)f_4176},
{"f_4157:srfi_69_scm",(void*)f_4157},
{"f_4004:srfi_69_scm",(void*)f_4004},
{"f_4019:srfi_69_scm",(void*)f_4019},
{"f_4096:srfi_69_scm",(void*)f_4096},
{"f_4133:srfi_69_scm",(void*)f_4133},
{"f_4136:srfi_69_scm",(void*)f_4136},
{"f_4124:srfi_69_scm",(void*)f_4124},
{"f_4106:srfi_69_scm",(void*)f_4106},
{"f_4033:srfi_69_scm",(void*)f_4033},
{"f_4073:srfi_69_scm",(void*)f_4073},
{"f_4061:srfi_69_scm",(void*)f_4061},
{"f_4043:srfi_69_scm",(void*)f_4043},
{"f_3959:srfi_69_scm",(void*)f_3959},
{"f_3847:srfi_69_scm",(void*)f_3847},
{"f_3857:srfi_69_scm",(void*)f_3857},
{"f_3862:srfi_69_scm",(void*)f_3862},
{"f_3924:srfi_69_scm",(void*)f_3924},
{"f_3945:srfi_69_scm",(void*)f_3945},
{"f_3918:srfi_69_scm",(void*)f_3918},
{"f_3821:srfi_69_scm",(void*)f_3821},
{"f_3828:srfi_69_scm",(void*)f_3828},
{"f_3831:srfi_69_scm",(void*)f_3831},
{"f_3754:srfi_69_scm",(void*)f_3754},
{"f_3777:srfi_69_scm",(void*)f_3777},
{"f_3793:srfi_69_scm",(void*)f_3793},
{"f_3764:srfi_69_scm",(void*)f_3764},
{"f_3834:srfi_69_scm",(void*)f_3834},
{"f_3727:srfi_69_scm",(void*)f_3727},
{"f_3715:srfi_69_scm",(void*)f_3715},
{"f_3706:srfi_69_scm",(void*)f_3706},
{"f_3697:srfi_69_scm",(void*)f_3697},
{"f_3688:srfi_69_scm",(void*)f_3688},
{"f_3679:srfi_69_scm",(void*)f_3679},
{"f_3670:srfi_69_scm",(void*)f_3670},
{"f_3661:srfi_69_scm",(void*)f_3661},
{"f_3652:srfi_69_scm",(void*)f_3652},
{"f_3646:srfi_69_scm",(void*)f_3646},
{"f_3283:srfi_69_scm",(void*)f_3283},
{"f_3636:srfi_69_scm",(void*)f_3636},
{"f_3639:srfi_69_scm",(void*)f_3639},
{"f_3361:srfi_69_scm",(void*)f_3361},
{"f_3616:srfi_69_scm",(void*)f_3616},
{"f_3619:srfi_69_scm",(void*)f_3619},
{"f_3364:srfi_69_scm",(void*)f_3364},
{"f_3584:srfi_69_scm",(void*)f_3584},
{"f_3590:srfi_69_scm",(void*)f_3590},
{"f_3367:srfi_69_scm",(void*)f_3367},
{"f_3402:srfi_69_scm",(void*)f_3402},
{"f_3423:srfi_69_scm",(void*)f_3423},
{"f_3429:srfi_69_scm",(void*)f_3429},
{"f_3521:srfi_69_scm",(void*)f_3521},
{"f_3524:srfi_69_scm",(void*)f_3524},
{"f_3496:srfi_69_scm",(void*)f_3496},
{"f_3499:srfi_69_scm",(void*)f_3499},
{"f_3486:srfi_69_scm",(void*)f_3486},
{"f_3468:srfi_69_scm",(void*)f_3468},
{"f_3455:srfi_69_scm",(void*)f_3455},
{"f_3445:srfi_69_scm",(void*)f_3445},
{"f_3432:srfi_69_scm",(void*)f_3432},
{"f_3413:srfi_69_scm",(void*)f_3413},
{"f_3370:srfi_69_scm",(void*)f_3370},
{"f_3373:srfi_69_scm",(void*)f_3373},
{"f_3377:srfi_69_scm",(void*)f_3377},
{"f_3393:srfi_69_scm",(void*)f_3393},
{"f_3380:srfi_69_scm",(void*)f_3380},
{"f_3285:srfi_69_scm",(void*)f_3285},
{"f_3259:srfi_69_scm",(void*)f_3259},
{"f_3263:srfi_69_scm",(void*)f_3263},
{"f_3229:srfi_69_scm",(void*)f_3229},
{"f_3235:srfi_69_scm",(void*)f_3235},
{"f_3105:srfi_69_scm",(void*)f_3105},
{"f_3170:srfi_69_scm",(void*)f_3170},
{"f_3161:srfi_69_scm",(void*)f_3161},
{"f_3142:srfi_69_scm",(void*)f_3142},
{"f_3146:srfi_69_scm",(void*)f_3146},
{"f_3149:srfi_69_scm",(void*)f_3149},
{"f_3121:srfi_69_scm",(void*)f_3121},
{"f_2983:srfi_69_scm",(void*)f_2983},
{"f_3048:srfi_69_scm",(void*)f_3048},
{"f_3039:srfi_69_scm",(void*)f_3039},
{"f_3020:srfi_69_scm",(void*)f_3020},
{"f_3024:srfi_69_scm",(void*)f_3024},
{"f_3027:srfi_69_scm",(void*)f_3027},
{"f_2999:srfi_69_scm",(void*)f_2999},
{"f_2941:srfi_69_scm",(void*)f_2941},
{"f_2951:srfi_69_scm",(void*)f_2951},
{"f_2607:srfi_69_scm",(void*)f_2607},
{"f_2706:srfi_69_scm",(void*)f_2706},
{"f_2919:srfi_69_scm",(void*)f_2919},
{"f_2898:srfi_69_scm",(void*)f_2898},
{"f_2890:srfi_69_scm",(void*)f_2890},
{"f_2869:srfi_69_scm",(void*)f_2869},
{"f_2843:srfi_69_scm",(void*)f_2843},
{"f_2675:srfi_69_scm",(void*)f_2675},
{"f_2691:srfi_69_scm",(void*)f_2691},
{"f_2610:srfi_69_scm",(void*)f_2610},
{"f_2627:srfi_69_scm",(void*)f_2627},
{"f_2661:srfi_69_scm",(void*)f_2661},
{"f_2566:srfi_69_scm",(void*)f_2566},
{"f_2555:srfi_69_scm",(void*)f_2555},
{"f_2576:srfi_69_scm",(void*)f_2576},
{"f_2382:srfi_69_scm",(void*)f_2382},
{"f_2392:srfi_69_scm",(void*)f_2392},
{"f_2278:srfi_69_scm",(void*)f_2278},
{"f_2285:srfi_69_scm",(void*)f_2285},
{"f_2252:srfi_69_scm",(void*)f_2252},
{"f_2259:srfi_69_scm",(void*)f_2259},
{"f_2208:srfi_69_scm",(void*)f_2208},
{"f_2167:srfi_69_scm",(void*)f_2167},
{"f_2177:srfi_69_scm",(void*)f_2177},
{"f_2038:srfi_69_scm",(void*)f_2038},
{"f_2045:srfi_69_scm",(void*)f_2045},
{"f_2147:srfi_69_scm",(void*)f_2147},
{"f_2051:srfi_69_scm",(void*)f_2051},
{"f_2032:srfi_69_scm",(void*)f_2032},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
