/* Generated from csc.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:28
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: csc.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -output-file csc.c
   used units: library eval data_structures ports extras srfi_69 data_structures ports srfi_1 srfi_13 utils files extras
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[371];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_904)
static void C_ccall f_904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_907)
static void C_ccall f_907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_910)
static void C_ccall f_910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_913)
static void C_ccall f_913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_916)
static void C_ccall f_916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_919)
static void C_ccall f_919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_922)
static void C_ccall f_922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_925)
static void C_ccall f_925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_928)
static void C_ccall f_928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_931)
static void C_ccall f_931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_934)
static void C_ccall f_934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_937)
static void C_ccall f_937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_940)
static void C_ccall f_940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3737)
static void C_ccall f_3737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_956)
static void C_fcall f_956(C_word t0,C_word t1) C_noret;
C_noret_decl(f_973)
static void C_ccall f_973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_977)
static void C_ccall f_977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3705)
static void C_ccall f_3705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3701)
static void C_ccall f_3701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1012)
static void C_ccall f_1012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3669)
static void C_ccall f_3669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1020)
static void C_ccall f_1020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3646)
static void C_ccall f_3646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1028)
static void C_ccall f_1028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3633)
static void C_ccall f_3633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1032)
static void C_ccall f_1032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1064)
static void C_ccall f_1064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1068)
static void C_ccall f_1068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3612)
static void C_ccall f_3612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3602)
static void C_ccall f_3602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1078)
static void C_ccall f_1078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1104)
static void C_ccall f_1104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1108)
static void C_ccall f_1108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3580)
static void C_ccall f_3580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1116)
static void C_fcall f_1116(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3547)
static void C_ccall f_3547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3535)
static void C_ccall f_3535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1124)
static void C_fcall f_1124(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3503)
static void C_ccall f_3503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1141)
static void C_fcall f_1141(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1149)
static void C_ccall f_1149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3479)
static void C_ccall f_3479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3461)
static void C_ccall f_3461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3428)
static void C_ccall f_3428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1154)
static void C_fcall f_1154(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3407)
static void C_ccall f_3407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1252)
static void C_fcall f_1252(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_fcall f_2001(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2242)
static void C_fcall f_2242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2245)
static void C_fcall f_2245(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_fcall f_2248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static void C_fcall f_2299(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2308)
static void C_fcall f_2308(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2575)
static void C_ccall f_2575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2534)
static void C_fcall f_2534(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2490)
static void C_ccall f_2490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_fcall f_2386(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2417)
static void C_ccall f_2417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2157)
static void C_ccall f_2157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2114)
static void C_ccall f_2114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1924)
static void C_ccall f_1924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_fcall f_1882(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1679)
static void C_fcall f_1679(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1639)
static void C_ccall f_1639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_fcall f_1624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1604)
static void C_ccall f_1604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static void C_ccall f_1531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1484)
static void C_ccall f_1484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1263)
static void C_ccall f_1263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1267)
static void C_ccall f_1267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1408)
static void C_ccall f_1408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1411)
static void C_ccall f_1411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1414)
static void C_ccall f_1414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1417)
static void C_ccall f_1417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1270)
static void C_ccall f_1270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1371)
static void C_fcall f_1371(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1381)
static void C_ccall f_1381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1374)
static void C_fcall f_1374(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2761)
static void C_fcall f_2761(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1333)
static void C_ccall f_1333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1273)
static void C_ccall f_1273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2804)
static void C_ccall f_2804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1319)
static void C_ccall f_1319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2918)
static void C_fcall f_2918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2931)
static void C_ccall f_2931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2909)
static void C_ccall f_2909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1223)
static void C_fcall f_1223(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1228)
static void C_ccall f_1228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1232)
static void C_ccall f_1232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1184)
static void C_fcall f_1184(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1202)
static void C_ccall f_1202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1177)
static void C_fcall f_1177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1182)
static void C_ccall f_1182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3397)
static void C_ccall f_3397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3403)
static void C_ccall f_3403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3400)
static void C_ccall f_3400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3385)
static void C_ccall f_3385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3350)
static void C_fcall f_3350(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3278)
static void C_fcall f_3278(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3308)
static void C_fcall f_3308(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_fcall f_3176(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3191)
static void C_ccall f_3191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3124)
static void C_fcall f_3124(C_word t0) C_noret;
C_noret_decl(f_3170)
static void C_ccall f_3170(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3170)
static void C_ccall f_3170r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_fcall f_3027(C_word t0) C_noret;
C_noret_decl(f_3031)
static void C_ccall f_3031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3042)
static void C_fcall f_3042(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3083)
static void C_fcall f_3083(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3087)
static void C_fcall f_3087(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2875)
static void C_fcall f_2875(C_word t0) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_987)
static void C_fcall f_987(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_958)
static void C_fcall f_958(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_969)
static void C_ccall f_969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_962)
static void C_ccall f_962(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_956)
static void C_fcall trf_956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_956(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_956(t0,t1);}

C_noret_decl(trf_1116)
static void C_fcall trf_1116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1116(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1116(t0,t1);}

C_noret_decl(trf_1124)
static void C_fcall trf_1124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1124(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1124(t0,t1);}

C_noret_decl(trf_1141)
static void C_fcall trf_1141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1141(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1141(t0,t1);}

C_noret_decl(trf_1154)
static void C_fcall trf_1154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1154(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1154(t0,t1);}

C_noret_decl(trf_1252)
static void C_fcall trf_1252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1252(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1252(t0,t1,t2);}

C_noret_decl(trf_2001)
static void C_fcall trf_2001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2001(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2001(t0,t1);}

C_noret_decl(trf_2242)
static void C_fcall trf_2242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2242(t0,t1);}

C_noret_decl(trf_2245)
static void C_fcall trf_2245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2245(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2245(t0,t1);}

C_noret_decl(trf_2248)
static void C_fcall trf_2248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2248(t0,t1);}

C_noret_decl(trf_2299)
static void C_fcall trf_2299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2299(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2299(t0,t1);}

C_noret_decl(trf_2308)
static void C_fcall trf_2308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2308(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2308(t0,t1);}

C_noret_decl(trf_2534)
static void C_fcall trf_2534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2534(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2534(t0,t1);}

C_noret_decl(trf_2386)
static void C_fcall trf_2386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2386(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2386(t0,t1);}

C_noret_decl(trf_1882)
static void C_fcall trf_1882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1882(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1882(t0,t1);}

C_noret_decl(trf_1679)
static void C_fcall trf_1679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1679(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1679(t0,t1);}

C_noret_decl(trf_1624)
static void C_fcall trf_1624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1624(t0,t1);}

C_noret_decl(trf_1371)
static void C_fcall trf_1371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1371(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1371(t0,t1);}

C_noret_decl(trf_1374)
static void C_fcall trf_1374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1374(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1374(t0,t1);}

C_noret_decl(trf_2761)
static void C_fcall trf_2761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2761(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2761(t0,t1);}

C_noret_decl(trf_2918)
static void C_fcall trf_2918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2918(t0,t1);}

C_noret_decl(trf_1223)
static void C_fcall trf_1223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1223(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1223(t0,t1);}

C_noret_decl(trf_1184)
static void C_fcall trf_1184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1184(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1184(t0,t1,t2,t3);}

C_noret_decl(trf_1177)
static void C_fcall trf_1177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1177(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1177(t0,t1);}

C_noret_decl(trf_3350)
static void C_fcall trf_3350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3350(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3350(t0,t1);}

C_noret_decl(trf_3278)
static void C_fcall trf_3278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3278(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3278(t0,t1,t2);}

C_noret_decl(trf_3308)
static void C_fcall trf_3308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3308(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3308(t0,t1);}

C_noret_decl(trf_3176)
static void C_fcall trf_3176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3176(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3176(t0,t1);}

C_noret_decl(trf_3124)
static void C_fcall trf_3124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3124(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3124(t0);}

C_noret_decl(trf_3027)
static void C_fcall trf_3027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3027(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3027(t0);}

C_noret_decl(trf_3042)
static void C_fcall trf_3042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3042(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3042(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3083)
static void C_fcall trf_3083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3083(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3083(t0,t1);}

C_noret_decl(trf_3087)
static void C_fcall trf_3087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3087(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3087(t0,t1);}

C_noret_decl(trf_2875)
static void C_fcall trf_2875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2875(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2875(t0);}

C_noret_decl(trf_987)
static void C_fcall trf_987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_987(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_987(t0,t1,t2,t3);}

C_noret_decl(trf_958)
static void C_fcall trf_958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_958(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_958(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2603)){
C_save(t1);
C_rereclaim2(2603*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,371);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],7,"mingw32");
lf[4]=C_h_intern(&lf[4],4,"msvc");
lf[6]=C_h_intern(&lf[6],6,"macosx");
lf[10]=C_h_intern(&lf[10],4,"exit");
lf[11]=C_h_intern(&lf[11],7,"fprintf");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\011csc: ~\077~%");
lf[13]=C_h_intern(&lf[13],18,"current-error-port");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[20]=C_h_intern(&lf[20],13,"make-pathname");
lf[22]=C_h_intern(&lf[22],2,"qs");
lf[23]=C_h_intern(&lf[23],18,"normalize-pathname");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\003obj");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\005-out:");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\003-Fo");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[46]=C_h_intern(&lf[46],26,"\003sysload-dynamic-extension");
lf[47]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[48]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-fPIC\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014/usr/include\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[104]=C_h_intern(&lf[104],18,"string-intersperse");
lf[105]=C_h_intern(&lf[105],7,"\003sysmap");
lf[107]=C_h_intern(&lf[107],6,"append");
lf[109]=C_h_intern(&lf[109],7,"reverse");
lf[110]=C_h_intern(&lf[110],6,"static");
lf[111]=C_h_intern(&lf[111],14,"static-options");
lf[112]=C_h_intern(&lf[112],21,"extension-information");
lf[113]=C_h_intern(&lf[113],15,"repository-path");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\010 -static");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[117]=C_h_intern(&lf[117],13,"string-append");
lf[119]=C_h_intern(&lf[119],9,"\003syserror");
lf[121]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000#\376\377\016");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[124]=C_h_intern(&lf[124],17,"string-translate*");
lf[125]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\001\042\376B\000\000\002\134\042\376\377\016");
lf[126]=C_h_intern(&lf[126],16,"\003syslist->string");
lf[127]=C_h_intern(&lf[127],5,"cons*");
lf[128]=C_h_intern(&lf[128],16,"\003sysstring->list");
lf[129]=C_h_intern(&lf[129],10,"string-any");
lf[132]=C_h_intern(&lf[132],6,"printf");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000C\012Error: shell command terminated with non-zero exit status ~S: ~A~%");
lf[134]=C_h_intern(&lf[134],6,"system");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[137]=C_h_intern(&lf[137],5,"print");
lf[139]=C_h_intern(&lf[139],11,"delete-file");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\003rm ");
lf[141]=C_h_intern(&lf[141],25,"\003sysimplicit-exit-handler");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000#not enough arguments to option `~A\047");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\013-dynamiclib");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\007-bundle");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\004-dll");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\007-shared");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-DC_SHARED\376\377\016");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-shared");
lf[150]=C_h_intern(&lf[150],12,"\003sysfor-each");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000+install_name_tool -change libchicken.dylib ");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\020libchicken.dylib");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[156]=C_h_intern(&lf[156],17,"\003syspeek-c-string");
lf[157]=C_h_intern(&lf[157],15,"*windows-shell*");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\004move");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\002mv");
lf[160]=C_h_intern(&lf[160],7,"sprintf");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\010~A ~A ~A");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\004.old");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000TWarning: output file will overwrite source file `~A\047 - renaming source to `"
"~A.old\047~%");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[165]=C_h_intern(&lf[165],26,"pathname-replace-extension");
lf[166]=C_h_intern(&lf[166],4,"last");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\031no source files specified");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-to-stdout\376\377\016");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\014-output-file");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\010-dynamic");
lf[175]=C_h_intern(&lf[175],7,"newline");
lf[176]=C_h_intern(&lf[176],6,"print*");
lf[177]=C_h_intern(&lf[177],5,"-help");
lf[178]=C_h_intern(&lf[178],6,"--help");
lf[179]=C_h_intern(&lf[179],7,"display");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\0471Usage: csc FILENAME | OPTION ...\012\012  `csc\047 is a driver program for the CHICK"
"EN compiler. Files given on the\012  command line are translated, compiled or linke"
"d as needed.\012\012  FILENAME is a Scheme source file name with optional extension or"
" a\012  C/C++/Objective-C source, object or library file name with extension. OPTIO"
"N\012  may be one of the following:\012\012  General options:\012\012    -h  -help             "
"         display this text and exit\012    -v                             show inte"
"rmediate compilation stages\012    -vv  -verbose                  display informati"
"on about translation\012                                    progress\012    -vvv      "
"                     display information about all compilation\012                 "
"                   stages\012    -V  -version                   display Scheme comp"
"iler version and exit\012    -release                       display release number "
"and exit\012\012  File and pathname options:\012\012    -o -output-file FILENAME       speci"
"fies target executable name\012    -I -include-path PATHNAME      specifies alterna"
"tive path for included\012                                    files\012    -to-stdout "
"                    write compiler to stdout (implies -t)\012    -s -shared -dynami"
"c            generate dynamically loadable shared object\012                       "
"             file\012\012  Language options:\012\012    -D  -DSYMBOL  -feature SYMBOL  regis"
"ter feature identifier\012    -c++                           compile via a C++ sour"
"ce file (.cpp) \012    -objc                          compile via Objective-C sourc"
"e file (.m)\012\012  Syntax related options:\012\012    -i -case-insensitive           don\047t"
" preserve case of read symbols    \012    -k  -keyword-style STYLE       enable alt"
"ernative keyword-syntax\012                                    (prefix, suffix or n"
"one)\012        -no-parentheses-synonyms   disables list delimiter synonyms\012       "
" -no-symbol-escape          disables support for escaped symbols\012        -r5rs-s"
"yntax               disables the Chicken extensions to\012                         "
"           R5RS syntax\012    -compile-syntax                macros are made availa"
"ble at run-time\012    -j -emit-import-library MODULE write compile-time module inf"
"ormation into\012                                    separate file\012    -J -emit-all"
"-import-libraries  emit import-libraries for all defined modules\012    -no-compile"
"r-syntax            disable expansion of compiler-macros\012\012  Translation options:"
"\012\012    -x  -explicit-use              do not use units `library\047 and `eval\047 by\012  "
"                                  default\012    -P  -check-syntax              sto"
"p compilation after macro-expansion\012    -A  -analyze-only              stop comp"
"ilation after first analysis pass\012\012  Debugging options:\012\012    -w  -no-warnings   "
"            disable warnings\012    -disable-warning CLASS         disable specific"
" class of warnings\012    -d0 -d1 -d2 -debug-level NUMBER\012                         "
"          set level of available debugging information\012    -no-trace            "
"          disable rudimentary debugging information\012    -profile                "
"       executable emits profiling information \012    -accumulate-profile          "
"  executable emits profiling information in\012                                    "
"append mode\012    -profile-name FILENAME         name of the generated profile inf"
"ormation\012                                    file\012    -S  -scrutinize           "
"     perform local flow analysis\012    -types FILENAME                load additio"
"nal type database\012\012  Optimization options:\012\012    -O -O1 -O2 -O3 -O4 -optimize-lev"
"el NUMBER\012                                   enable certain sets of optimization"
" options\012    -optimize-leaf-routines        enable leaf routine optimization\012   "
" -N  -no-usual-integrations     standard procedures may be redefined\012    -u  -un"
"safe                    disable safety checks\012    -local                        "
" assume globals are only modified in current\012                                   "
" file\012    -b  -block                     enable block-compilation\012    -disable-i"
"nterrupts            disable interrupts in compiled code\012    -f  -fixnum-arithme"
"tic         assume all numbers are fixnums\012    -Ob  -benchmark-mode           eq"
"uivalent to \047-block -optimize-level 4\012                                    -debug"
"-level 0 -fixnum-arithmetic\012                                    -lambda-lift -in"
"line -disable-interrupts\047\012    -lambda-lift                   perform lambda-lift"
"ing\012    -unsafe-libraries              link with unsafe runtime system\012    -disa"
"ble-stack-overflow-checks disables detection of stack-overflows\012    -inline     "
"                   enable inlining\012    -inline-limit                  set inlini"
"ng threshold\012    -inline-global                 enable cross-module inlining\012   "
" -n -emit-inline-file FILENAME  generate file with globally inlinable\012          "
"                          procedures (implies -inline -local)\012    -consult-inlin"
"e-file FILENAME  explicitly load inline file\012    -no-argc-checks                "
"disable argument count checks\012    -no-bound-checks               disable bound v"
"ariable checks\012    -no-procedure-checks           disable procedure call checks\012"
"    -no-procedure-checks-for-usual-bindings\012                                   d"
"isable procedure call checks only for usual\012                                    "
"bindings\012\012  Configuration options:\012\012    -unit NAME                     compile f"
"ile as a library unit\012    -uses NAME                     declare library unit as"
" used.\012    -heap-size NUMBER              specifies heap-size of compiled execut"
"able\012    -heap-initial-size NUMBER      specifies heap-size at startup time\012    "
"-heap-growth PERCENTAGE        specifies growth-rate of expanding heap\012    -heap"
"-shrinkage PERCENTAGE     specifies shrink-rate of contracting heap\012    -nursery"
" NUMBER  -stack-size NUMBER\012                                   specifies nursery"
" size of compiled\012                                   executable\012    -X -extend F"
"ILENAME            load file before compilation commences\012    -prelude EXPRESSIO"
"N            add expression to beginning of source file\012    -postlude EXPRESSION"
"           add expression to end of source file\012    -prologue FILENAME          "
"   include file before main source file\012    -epilogue FILENAME             inclu"
"de file after main source file\012\012    -e  -embedded                  compile as em"
"bedded\012                                    (don\047t generate `main()\047)\012    -W  -wi"
"ndows                   compile as Windows GUI application\012    -R  -require-exte"
"nsion NAME    require extension and import in compiled\012                         "
"           code\012    -dll -library                  compile multiple units into a"
" dynamic\012                                    library\012\012  Options to other passes:"
"\012\012    -C OPTION                      pass option to C compiler\012    -L OPTION    "
"                  pass option to linker\012    -I<DIR>                        pass "
"\134\042-I<DIR>\134\042 to C compiler\012                                    (add include path)"
"\012    -L<DIR>                        pass \134\042-L<DIR>\134\042 to linker\012                 "
"                   (add library path)\012    -k                             keep in"
"termediate files\012    -c                             stop after compilation to ob"
"ject files\012    -t                             stop after translation to C\012    -c"
"c COMPILER                   select other C compiler than the default\012    -cxx C"
"OMPILER                  select other C++ compiler than the default\012    -ld COMP"
"ILER                   select other linker than the default \012    -lLIBNAME      "
"                link with given library\012                                    (`li"
"bLIBNAME\047 on UNIX,\012                                     `LIBNAME.lib\047 on Windows"
")\012    -static-libs                   link with static CHICKEN libraries\012    -sta"
"tic                        generate completely statically linked\012               "
"                     executable\012    -static-extension NAME         link extensio"
"n NAME statically\012                                    (if available)\012    -F<DIR>"
"                        pass \134\042-F<DIR>\134\042 to C compiler\012                         "
"           (add framework header path on Mac OS X)\012    -framework NAME          "
"      passed to linker on Mac OS X\012    -rpath PATHNAME                add direct"
"ory to runtime library search path\012    -Wl,...                        pass linke"
"r options\012    -strip                         strip resulting binary\012\012  Inquiry o"
"ptions:\012\012    -home                          show home-directory (where support f"
"iles go)\012    -cflags                        show required C-compiler flags and e"
"xit\012    -ldflags                       show required linker flags and exit\012    -"
"libs                          show required libraries and exit\012    -cc-name     "
"                  show name of default C compiler used\012    -cxx-name            "
"          show name of default C++ compiler used\012    -ld-name                   "
"    show name of default linker used\012    -dry-run                       just sho"
"w commands executed, don\047t run them\012                                    (implies"
" `-v\047)\012\012  Obscure options:\012\012    -debug MODES                   display debugging"
" output for the given modes\012    -compiler PATHNAME             use other compile"
"r than default `chicken\047\012    -disable-c-syntax-checks       disable syntax check"
"s of C code fragments\012    -raw                           do not generate implici"
"t init- and exit code\012    -emit-external-prototypes-first\012                      "
"             emit prototypes for callbacks before foreign\012                      "
"              declarations\012    -ignore-repository             do not refer to re"
"pository for extensions\012    -keep-shadowed-macros          do not remove shadowe"
"d macro\012    -host                          compile for host when configured for\012"
"                                    cross-compiling\012\012  Options can be collapsed "
"if unambiguous, so\012\012    -vkfO\012\012  is the same as\012\012    -v -k -fixnum-arithmetic -o"
"ptimize\012\012  The contents of the environment variable CSC_OPTIONS are implicitly p"
"assed to\012  every invocation of `csc\047.\012");
lf[181]=C_h_intern(&lf[181],8,"-release");
lf[182]=C_h_intern(&lf[182],15,"chicken-version");
lf[183]=C_h_intern(&lf[183],8,"-version");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\011 -version");
lf[185]=C_h_intern(&lf[185],4,"-c++");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[187]=C_h_intern(&lf[187],5,"-objc");
lf[188]=C_h_intern(&lf[188],7,"-static");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[191]=C_h_intern(&lf[191],12,"-static-libs");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[194]=C_h_intern(&lf[194],7,"-cflags");
lf[195]=C_h_intern(&lf[195],8,"-ldflags");
lf[196]=C_h_intern(&lf[196],8,"-cc-name");
lf[197]=C_h_intern(&lf[197],9,"-cxx-name");
lf[198]=C_h_intern(&lf[198],8,"-ld-name");
lf[199]=C_h_intern(&lf[199],5,"-home");
lf[200]=C_h_intern(&lf[200],5,"-libs");
lf[201]=C_h_intern(&lf[201],2,"-v");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\010-VERBOSE");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\002-Q");
lf[207]=C_h_intern(&lf[207],3,"-v2");
lf[208]=C_h_intern(&lf[208],8,"-verbose");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[210]=C_h_intern(&lf[210],3,"-v3");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\010-VERBOSE");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\002-Q");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[216]=C_h_intern(&lf[216],2,"-w");
lf[217]=C_h_intern(&lf[217],12,"-no-warnings");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\002-w");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\014-no-warnings");
lf[220]=C_h_intern(&lf[220],2,"-A");
lf[221]=C_h_intern(&lf[221],13,"-analyze-only");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\015-analyze-only");
lf[223]=C_h_intern(&lf[223],2,"-P");
lf[224]=C_h_intern(&lf[224],13,"-check-syntax");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\015-check-syntax");
lf[226]=C_h_intern(&lf[226],2,"-k");
lf[227]=C_h_intern(&lf[227],2,"-c");
lf[228]=C_h_intern(&lf[228],2,"-t");
lf[229]=C_h_intern(&lf[229],2,"-e");
lf[230]=C_h_intern(&lf[230],9,"-embedded");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\014-DC_EMBEDDED");
lf[232]=C_h_intern(&lf[232],18,"-require-extension");
lf[233]=C_h_intern(&lf[233],2,"-R");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[235]=C_h_intern(&lf[235],17,"-static-extension");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\021-static-extension");
lf[237]=C_h_intern(&lf[237],8,"-windows");
lf[238]=C_h_intern(&lf[238],2,"-W");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\017-DC_WINDOWS_GUI");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\012-lkernel32");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\010-luser32");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\007-lgdi32");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\011-mwindows");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\017-DC_WINDOWS_GUI");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\014kernel32.lib");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\012user32.lib");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\011gdi32.lib");
lf[248]=C_h_intern(&lf[248],10,"-framework");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\012-framework");
lf[250]=C_h_intern(&lf[250],2,"-o");
lf[251]=C_h_intern(&lf[251],2,"-O");
lf[252]=C_h_intern(&lf[252],3,"-O1");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[255]=C_h_intern(&lf[255],3,"-O2");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[258]=C_h_intern(&lf[258],3,"-O3");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\0013");
lf[261]=C_h_intern(&lf[261],3,"-O4");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\0014");
lf[264]=C_h_intern(&lf[264],3,"-d0");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[267]=C_h_intern(&lf[267],3,"-d1");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[270]=C_h_intern(&lf[270],3,"-d2");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[273]=C_h_intern(&lf[273],8,"-dry-run");
lf[274]=C_h_intern(&lf[274],2,"-s");
lf[275]=C_h_intern(&lf[275],4,"-dll");
lf[276]=C_h_intern(&lf[276],8,"-library");
lf[277]=C_h_intern(&lf[277],9,"-compiler");
lf[278]=C_h_intern(&lf[278],3,"-cc");
lf[279]=C_h_intern(&lf[279],4,"-cxx");
lf[280]=C_h_intern(&lf[280],3,"-ld");
lf[281]=C_h_intern(&lf[281],2,"-I");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[283]=C_h_intern(&lf[283],2,"-C");
lf[284]=C_h_intern(&lf[284],12,"string-split");
lf[285]=C_h_intern(&lf[285],6,"-strip");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[287]=C_h_intern(&lf[287],2,"-L");
lf[288]=C_h_intern(&lf[288],17,"-unsafe-libraries");
lf[289]=C_h_intern(&lf[289],6,"-rpath");
lf[290]=C_h_intern(&lf[290],3,"gnu");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\006-Wl,-R");
lf[292]=C_h_intern(&lf[292],14,"build-platform");
lf[293]=C_h_intern(&lf[293],5,"-host");
lf[294]=C_h_intern(&lf[294],1,"-");
lf[295]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001-\376\377\016");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[297]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-s\376\003\000\000\002\376B\000\000\007-shared\376\377\016\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\002-S\376\003\000\000\002\376B\000\000\013-scrutinize\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-P\376\003\000\000\002\376B\000\000\015-check-syntax\376\377\016\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\002-V\376\003\000\000\002\376B\000\000\010-version\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003-Ob\376\003\000\000\002\376B\000\000\017-benchmark-mode\376\377\016"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-f\376\003\000\000\002\376B\000\000\022-fixnum-arithmetic\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-D\376\003\000\000\002\376B\000\000\010-feat"
"ure\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-K\376\003\000\000\002\376B\000\000\016"
"-keyword-style\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-X\376\003\000\000\002\376B\000\000\007-extend\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-N\376\003\000\000\002\376B\000\000"
"\026-no-usual-integrations\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-J\376\003\000\000\002\376B\000\000\032-emit-all-import-libraries\376"
"\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-x\376\003\000\000\002\376B\000\000\015-explicit-use\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-u\376\003\000\000\002\376B\000\000\007-unsafe\376"
"\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-j\376\003\000\000\002\376B\000\000\024-emit-import-library\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-n\376\003\000\000\002\376B\000\000\021-"
"emit-inline-file\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-b\376\003\000\000\002\376B\000\000\006-block\376\377\016\376\377\016");
lf[298]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015-explicit-use\376\003\000\000\002\376\001\000\000\011-no-trace\376\003\000\000\002\376\001\000\000\014-no-warnings\376\003\000\000\002\376\001\000\000\026-no-us"
"ual-integrations\376\003\000\000\002\376\001\000\000\027-optimize-leaf-routines\376\003\000\000\002\376\001\000\000\007-unsafe\376\003\000\000\002\376\001\000\000\006-blo"
"ck\376\003\000\000\002\376\001\000\000\023-disable-interrupts\376\003\000\000\002\376\001\000\000\022-fixnum-arithmetic\376\003\000\000\002\376\001\000\000\012-to-stdout\376"
"\003\000\000\002\376\001\000\000\010-profile\376\003\000\000\002\376\001\000\000\004-raw\376\003\000\000\002\376\001\000\000\023-accumulate-profile\376\003\000\000\002\376\001\000\000\015-check-syn"
"tax\376\003\000\000\002\376\001\000\000\021-case-insensitive\376\003\000\000\002\376\001\000\000\017-benchmark-mode\376\003\000\000\002\376\001\000\000\007-shared\376\003\000\000\002\376\001\000"
"\000\017-compile-syntax\376\003\000\000\002\376\001\000\000\017-no-lambda-info\376\003\000\000\002\376\001\000\000\014-lambda-lift\376\003\000\000\002\376\001\000\000\010-dynam"
"ic\376\003\000\000\002\376\001\000\000\036-disable-stack-overflow-checks\376\003\000\000\002\376\001\000\000\006-local\376\003\000\000\002\376\001\000\000\037-emit-extern"
"al-prototypes-first\376\003\000\000\002\376\001\000\000\007-inline\376\003\000\000\002\376\001\000\000\010-release\376\003\000\000\002\376\001\000\000\013-scrutinize\376\003\000\000\002"
"\376\001\000\000\015-analyze-only\376\003\000\000\002\376\001\000\000\025-keep-shadowed-macros\376\003\000\000\002\376\001\000\000\016-inline-global\376\003\000\000\002\376\001"
"\000\000\022-ignore-repository\376\003\000\000\002\376\001\000\000\021-no-symbol-escape\376\003\000\000\002\376\001\000\000\030-no-parentheses-synony"
"ms\376\003\000\000\002\376\001\000\000\014-r5rs-syntax\376\003\000\000\002\376\001\000\000\017-no-argc-checks\376\003\000\000\002\376\001\000\000\020-no-bound-checks\376\003\000\000\002"
"\376\001\000\000\024-no-procedure-checks\376\003\000\000\002\376\001\000\000\023-no-compiler-syntax\376\003\000\000\002\376\001\000\000\032-emit-all-import"
"-libraries\376\003\000\000\002\376\001\000\000\013-setup-mode\376\003\000\000\002\376\001\000\000\047-no-procedure-checks-for-usual-bindings"
"\376\377\016");
lf[299]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006-debug\376\003\000\000\002\376\001\000\000\014-output-file\376\003\000\000\002\376\001\000\000\012-heap-size\376\003\000\000\002\376\001\000\000\010-nursery\376\003\000\000"
"\002\376\001\000\000\013-stack-size\376\003\000\000\002\376\001\000\000\011-compiler\376\003\000\000\002\376\001\000\000\005-unit\376\003\000\000\002\376\001\000\000\005-uses\376\003\000\000\002\376\001\000\000\016-key"
"word-style\376\003\000\000\002\376\001\000\000\017-optimize-level\376\003\000\000\002\376\001\000\000\015-include-path\376\003\000\000\002\376\001\000\000\016-database-si"
"ze\376\003\000\000\002\376\001\000\000\007-extend\376\003\000\000\002\376\001\000\000\010-prelude\376\003\000\000\002\376\001\000\000\011-postlude\376\003\000\000\002\376\001\000\000\011-prologue\376\003\000\000\002"
"\376\001\000\000\011-epilogue\376\003\000\000\002\376\001\000\000\015-inline-limit\376\003\000\000\002\376\001\000\000\015-profile-name\376\003\000\000\002\376\001\000\000\020-disable-w"
"arning\376\003\000\000\002\376\001\000\000\021-emit-inline-file\376\003\000\000\002\376\001\000\000\006-types\376\003\000\000\002\376\001\000\000\010-feature\376\003\000\000\002\376\001\000\000\014-de"
"bug-level\376\003\000\000\002\376\001\000\000\014-heap-growth\376\003\000\000\002\376\001\000\000\017-heap-shrinkage\376\003\000\000\002\376\001\000\000\022-heap-initial-"
"size\376\003\000\000\002\376\001\000\000\024-consult-inline-file\376\003\000\000\002\376\001\000\000\024-emit-import-library\376\003\000\000\002\376\001\000\000\021-stati"
"c-extension\376\377\016");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[301]=C_h_intern(&lf[301],9,"substring");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[304]=C_h_intern(&lf[304],15,"lset-difference");
lf[305]=C_h_intern(&lf[305],6,"char=\077");
lf[306]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000P\376\003\000\000\002\376\377\012\000\000H\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000f\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000E\376\003\000"
"\000\002\376\377\012\000\000N\376\003\000\000\002\376\377\012\000\000x\376\003\000\000\002\376\377\012\000\000u\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000A\376\003\000\000\002\376"
"\377\012\000\000O\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000W\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000c\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000g\376\003\000\000\002\376\377\012\000"
"\000S\376\377\016");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\004-Wl,");
lf[309]=C_h_intern(&lf[309],18,"decompose-pathname");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\001h");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\001C");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\002cc");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\003cxx");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\003hpp");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\001M");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\002mm");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\030file `~A\047 does not exist");
lf[322]=C_h_intern(&lf[322],12,"file-exists\077");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\002-:");
lf[325]=C_h_intern(&lf[325],15,"-optimize-level");
lf[326]=C_h_intern(&lf[326],15,"-benchmark-mode");
lf[327]=C_h_intern(&lf[327],10,"-to-stdout");
lf[328]=C_h_intern(&lf[328],7,"-unsafe");
lf[329]=C_h_intern(&lf[329],7,"-shared");
lf[330]=C_h_intern(&lf[330],8,"-dynamic");
lf[331]=C_h_intern(&lf[331],14,"string->symbol");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[333]=C_h_intern(&lf[333],24,"get-environment-variable");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\013CSC_OPTIONS");
lf[335]=C_h_intern(&lf[335],4,"conc");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\011-LIBPATH:");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\007 -Wl,-R");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\007include");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\014libuchicken.");
lf[348]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-luchicken\376\377\016");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[352]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\011-lchicken\376\377\016");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\023libuchicken-static.");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\014libuchicken.");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\022libchicken-static.");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\005share");
lf[365]=C_h_intern(&lf[365],22,"command-line-arguments");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[367]=C_h_intern(&lf[367],4,"hpux");
lf[368]=C_h_intern(&lf[368],4,"hppa");
lf[369]=C_h_intern(&lf[369],12,"machine-type");
lf[370]=C_h_intern(&lf[370],16,"software-version");
C_register_lf2(lf,371,create_ptable());
t2=C_mutate(&lf[0] /* (set! c196 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_904,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k902 */
static void C_ccall f_904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_907,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k905 in k902 */
static void C_ccall f_907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_910,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k908 in k905 in k902 */
static void C_ccall f_910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_913,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k911 in k908 in k905 in k902 */
static void C_ccall f_913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_916,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_919,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_922,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_925,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_928,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_931,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_934,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_937,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_940,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3737,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 61   build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[292]))(2,*((C_word*)lf[292]+1),t2);}

/* k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3737,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[2]);
t3=C_mutate(&lf[3] /* (set! mingw ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3733,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 62   build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[292]))(2,*((C_word*)lf[292]+1),t4);}

/* k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3733,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[4]);
t3=C_mutate(&lf[5] /* (set! msvc ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3729,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 63   software-version */
((C_proc2)C_retrieve_symbol_proc(lf[370]))(2,*((C_word*)lf[370]+1),t4);}

/* k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3729,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[6]);
t3=C_mutate(&lf[7] /* (set! osx ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_956,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3725,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 64   software-version */
((C_proc2)C_retrieve_symbol_proc(lf[370]))(2,*((C_word*)lf[370]+1),t5);}

/* k3723 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3725,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[367]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 65   machine-type */
((C_proc2)C_retrieve_symbol_proc(lf[369]))(2,*((C_word*)lf[369]+1),t3);}
else{
t3=((C_word*)t0)[2];
f_956(t3,C_SCHEME_FALSE);}}

/* k3719 in k3723 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_956(t2,(C_word)C_eqp(t1,lf[368]));}

/* k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_956(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_956,NULL,2,t0,t1);}
t2=C_mutate(&lf[8] /* (set! hpux-hppa ...) */,t1);
t3=C_mutate(&lf[9] /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_958,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_973,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 71   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[333]))(3,*((C_word*)lf[333]+1),t4,lf[366]);}

/* k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_973,2,t0,t1);}
t2=C_mutate(&lf[14] /* (set! chicken-prefix ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_977,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 72   command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[365]))(2,*((C_word*)lf[365]+1),t3);}

/* k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_977,2,t0,t1);}
t2=C_mutate(&lf[15] /* (set! arguments ...) */,t1);
t3=(C_word)C_i_member(lf[16],C_retrieve2(lf[15],"arguments"));
t4=C_mutate(&lf[17] /* (set! host-mode ...) */,t3);
t5=(C_word)C_fudge(C_fix(39));
t6=C_mutate(&lf[18] /* (set! cross-chicken ...) */,t5);
t7=C_mutate(&lf[19] /* (set! prefix ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_987,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[21] /* (set! quotewrap ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1000,tmp=(C_word)a,a+=2,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1012,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3701,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3705,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t12=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t12=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_TARGET_SHARE_HOME),C_fix(0));}}

/* k3703 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   prefix */
f_987(((C_word*)t0)[2],lf[363],lf[364],t1);}

/* k3699 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 85   quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_1000(3,t2,((C_word*)t0)[2],t1);}

/* k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1012,2,t0,t1);}
t2=C_mutate(&lf[24] /* (set! home ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1016,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3679,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3683,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3687,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_BIN_HOME),C_fix(0));}}

/* k3685 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3691,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k3689 in k3685 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 91   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[20]))(4,*((C_word*)lf[20]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3681 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 90   prefix */
f_987(((C_word*)t0)[2],lf[361],lf[362],t1);}

/* k3677 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_1000(3,t2,((C_word*)t0)[2],t1);}

/* k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1016,2,t0,t1);}
t2=C_mutate(&lf[25] /* (set! translator ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1020,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3669,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}

/* k3667 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 95   quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_1000(3,t2,((C_word*)t0)[2],t1);}

/* k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1020,2,t0,t1);}
t2=C_mutate(&lf[26] /* (set! compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1024,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3659,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}

/* k3657 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 96   quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_1000(3,t2,((C_word*)t0)[2],t1);}

/* k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1024,2,t0,t1);}
t2=C_mutate(&lf[27] /* (set! c++-compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1028,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3646,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=t4;
f_3646(2,t5,lf[360]);}
else{
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}}

/* k3644 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 97   quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_1000(3,t2,((C_word*)t0)[2],t1);}

/* k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1028,2,t0,t1);}
t2=C_mutate(&lf[28] /* (set! linker ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1032,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3633,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=t4;
f_3633(2,t5,lf[359]);}
else{
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}}

/* k3631 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 98   quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_1000(3,t2,((C_word*)t0)[2],t1);}

/* k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1032,2,t0,t1);}
t2=C_mutate(&lf[29] /* (set! c++-linker ...) */,t1);
t3=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[30]:lf[31]);
t4=C_mutate(&lf[32] /* (set! object-extension ...) */,t3);
t5=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[33]:lf[34]);
t6=C_mutate(&lf[35] /* (set! library-extension ...) */,t5);
t7=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[36]:lf[37]);
t8=C_mutate(&lf[38] /* (set! link-output-flag ...) */,t7);
t9=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[39]:lf[40]);
t10=C_mutate(&lf[41] /* (set! executable-extension ...) */,t9);
t11=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[42]:lf[43]);
t12=C_mutate(&lf[44] /* (set! compile-output-flag ...) */,t11);
t13=C_mutate(&lf[45] /* (set! shared-library-extension ...) */,C_retrieve(lf[46]));
t14=(C_truep(C_retrieve2(lf[3],"mingw"))?C_retrieve2(lf[3],"mingw"):C_retrieve2(lf[5],"msvc"));
t15=(C_truep(t14)?lf[47]:lf[48]);
t16=C_mutate(&lf[49] /* (set! pic-options ...) */,t15);
t17=C_mutate(&lf[50] /* (set! windows-shell ...) */,C_mk_bool(C_WINDOWS_SHELL));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1064,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[357]:lf[358]);
/* csc.scm: 110  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t18,t19,C_retrieve2(lf[35],"library-extension"));}

/* k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1064,2,t0,t1);}
t2=C_mutate(&lf[51] /* (set! default-library ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1068,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[355]:lf[356]);
/* csc.scm: 113  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t3,t4,C_retrieve2(lf[35],"library-extension"));}

/* k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1068,2,t0,t1);}
t2=C_mutate(&lf[52] /* (set! default-unsafe-library ...) */,t1);
t3=C_mutate(&lf[53] /* (set! cleanup-filename ...) */,C_retrieve2(lf[21],"quotewrap"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1073,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3612,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_CFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}}

/* k3610 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 119  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[284]))(3,*((C_word*)lf[284]+1),((C_word*)t0)[2],t1);}

/* k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1073,2,t0,t1);}
t2=C_mutate(&lf[54] /* (set! default-compilation-optimization-options ...) */,t1);
t3=C_mutate(&lf[55] /* (set! best-compilation-optimization-options ...) */,C_retrieve2(lf[54],"default-compilation-optimization-options"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1078,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3602,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LDFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_LDFLAGS),C_fix(0));}}

/* k3600 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 121  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[284]))(3,*((C_word*)lf[284]+1),((C_word*)t0)[2],t1);}

/* k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1078,2,t0,t1);}
t2=C_mutate(&lf[56] /* (set! default-linking-optimization-options ...) */,t1);
t3=C_mutate(&lf[57] /* (set! best-linking-optimization-options ...) */,C_retrieve2(lf[56],"default-linking-optimization-options"));
t4=lf[58] /* scheme-files */ =C_SCHEME_END_OF_LIST;;
t5=lf[59] /* c-files */ =C_SCHEME_END_OF_LIST;;
t6=lf[60] /* generated-c-files */ =C_SCHEME_END_OF_LIST;;
t7=lf[61] /* object-files */ =C_SCHEME_END_OF_LIST;;
t8=lf[62] /* generated-object-files */ =C_SCHEME_END_OF_LIST;;
t9=lf[63] /* cpp-mode */ =C_SCHEME_FALSE;;
t10=lf[64] /* objc-mode */ =C_SCHEME_FALSE;;
t11=lf[65] /* embedded */ =C_SCHEME_FALSE;;
t12=lf[66] /* inquiry-only */ =C_SCHEME_FALSE;;
t13=lf[67] /* show-cflags */ =C_SCHEME_FALSE;;
t14=lf[68] /* show-ldflags */ =C_SCHEME_FALSE;;
t15=lf[69] /* show-libs */ =C_SCHEME_FALSE;;
t16=lf[70] /* dry-run */ =C_SCHEME_FALSE;;
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1104,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t18=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_mpointer(&a,(void*)C_INSTALL_MORE_STATIC_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t18=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_mpointer(&a,(void*)C_TARGET_MORE_STATIC_LIBS),C_fix(0));}}

/* k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1104,2,t0,t1);}
t2=C_mutate(&lf[71] /* (set! extra-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1108,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_MORE_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}}

/* k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1108,2,t0,t1);}
t2=C_mutate(&lf[72] /* (set! extra-shared-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3564,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3568,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3572,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3576,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3574 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3580,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 198  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,lf[354],C_retrieve2(lf[51],"default-library"));}

/* k3578 in k3574 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 196  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3570 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 195  prefix */
f_987(((C_word*)t0)[2],C_retrieve2(lf[51],"default-library"),lf[353],t1);}

/* k3566 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 194  quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_1000(3,t2,((C_word*)t0)[2],t1);}

/* k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3564,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[73] /* (set! default-library-files ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1116,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3560,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 200  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t5,lf[351],C_retrieve2(lf[35],"library-extension"));}
else{
t5=t4;
f_1116(t5,lf[352]);}}

/* k3558 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3560,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1116(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_1116(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1116,NULL,2,t0,t1);}
t2=C_mutate(&lf[74] /* (set! default-shared-library-files ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3535,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3539,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3543,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3541 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3547,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 208  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,lf[350],C_retrieve2(lf[52],"default-unsafe-library"));}

/* k3545 in k3541 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 206  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3537 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 205  prefix */
f_987(((C_word*)t0)[2],C_retrieve2(lf[52],"default-unsafe-library"),lf[349],t1);}

/* k3533 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 204  quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_1000(3,t2,((C_word*)t0)[2],t1);}

/* k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[75] /* (set! unsafe-library-files ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1124,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3527,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 210  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t5,lf[347],C_retrieve2(lf[35],"library-extension"));}
else{
t5=t4;
f_1124(t5,lf[348]);}}

/* k3525 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3527,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1124(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_1124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1124,NULL,2,t0,t1);}
t2=C_mutate(&lf[76] /* (set! unsafe-shared-library-files ...) */,t1);
t3=C_mutate(&lf[77] /* (set! gui-library-files ...) */,C_retrieve2(lf[73],"default-library-files"));
t4=C_mutate(&lf[78] /* (set! gui-shared-library-files ...) */,C_retrieve2(lf[74],"default-shared-library-files"));
t5=C_mutate(&lf[79] /* (set! library-files ...) */,C_retrieve2(lf[73],"default-library-files"));
t6=C_mutate(&lf[80] /* (set! shared-library-files ...) */,C_retrieve2(lf[74],"default-shared-library-files"));
t7=lf[81] /* translate-options */ =C_SCHEME_END_OF_LIST;;
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1133,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3514,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t10=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t10=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_TARGET_INCLUDE_HOME),C_fix(0));}}

/* k3512 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 220  prefix */
f_987(((C_word*)t0)[2],lf[345],lf[346],t1);}

/* k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1133,2,t0,t1);}
t2=(C_word)C_i_member(t1,lf[82]);
t3=(C_truep(t2)?C_SCHEME_FALSE:t1);
t4=C_mutate(&lf[83] /* (set! include-dir ...) */,t3);
t5=lf[84] /* compile-options */ =C_SCHEME_END_OF_LIST;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1141,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[83],"include-dir"))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3499,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3503,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 227  quotewrap */
t9=C_retrieve2(lf[21],"quotewrap");
f_1000(3,t9,t8,C_retrieve2(lf[83],"include-dir"));}
else{
t7=t6;
f_1141(t7,C_SCHEME_END_OF_LIST);}}

/* k3501 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 227  conc */
((C_proc4)C_retrieve_symbol_proc(lf[335]))(4,*((C_word*)lf[335]+1),((C_word*)t0)[2],lf[344],t1);}

/* k3497 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3499,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1141(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_1141(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1141,NULL,2,t0,t1);}
t2=C_mutate(&lf[85] /* (set! builtin-compile-options ...) */,t1);
t3=C_mutate(&lf[86] /* (set! compilation-optimization-options ...) */,C_retrieve2(lf[54],"default-compilation-optimization-options"));
t4=C_mutate(&lf[87] /* (set! linking-optimization-options ...) */,C_retrieve2(lf[56],"default-linking-optimization-options"));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1149,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3486,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3484 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 235  prefix */
f_987(((C_word*)t0)[2],lf[342],lf[343],t1);}

/* k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1149,2,t0,t1);}
t2=C_mutate(&lf[88] /* (set! library-dir ...) */,t1);
t3=lf[89] /* link-options */ =C_SCHEME_END_OF_LIST;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1154,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[7],"osx"))?C_retrieve2(lf[7],"osx"):(C_truep(C_retrieve2(lf[8],"hpux-hppa"))?C_retrieve2(lf[8],"hpux-hppa"):C_retrieve2(lf[3],"mingw")));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3428,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3432,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 243  quotewrap */
t8=C_retrieve2(lf[21],"quotewrap");
f_1000(3,t8,t7,C_retrieve2(lf[88],"library-dir"));}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3442,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3446,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 245  quotewrap */
t8=C_retrieve2(lf[21],"quotewrap");
f_1000(3,t8,t7,C_retrieve2(lf[88],"library-dir"));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3453,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3479,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 248  quotewrap */
t8=C_retrieve2(lf[21],"quotewrap");
f_1000(3,t8,t7,C_retrieve2(lf[88],"library-dir"));}}}

/* k3477 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 248  conc */
((C_proc4)C_retrieve_symbol_proc(lf[335]))(4,*((C_word*)lf[335]+1),((C_word*)t0)[2],lf[341],t1);}

/* k3451 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3457,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3461,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3465,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3469,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}

/* k3467 in k3451 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 249  prefix */
f_987(((C_word*)t0)[2],lf[339],lf[340],t1);}

/* k3463 in k3451 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 249  quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_1000(3,t2,((C_word*)t0)[2],t1);}

/* k3459 in k3451 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 249  conc */
((C_proc4)C_retrieve_symbol_proc(lf[335]))(4,*((C_word*)lf[335]+1),((C_word*)t0)[2],lf[338],t1);}

/* k3455 in k3451 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3457,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1154(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k3444 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 245  conc */
((C_proc4)C_retrieve_symbol_proc(lf[335]))(4,*((C_word*)lf[335]+1),((C_word*)t0)[2],lf[337],t1);}

/* k3440 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1154(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k3430 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 243  conc */
((C_proc4)C_retrieve_symbol_proc(lf[335]))(4,*((C_word*)lf[335]+1),((C_word*)t0)[2],lf[336],t1);}

/* k3426 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3428,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1154(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_1154(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1154,NULL,2,t0,t1);}
t2=C_mutate(&lf[90] /* (set! builtin-link-options ...) */,t1);
t3=lf[91] /* target-filename */ =C_SCHEME_FALSE;;
t4=lf[92] /* verbose */ =C_SCHEME_FALSE;;
t5=lf[93] /* keep-files */ =C_SCHEME_FALSE;;
t6=lf[94] /* translate-only */ =C_SCHEME_FALSE;;
t7=lf[95] /* compile-only */ =C_SCHEME_FALSE;;
t8=lf[96] /* to-stdout */ =C_SCHEME_FALSE;;
t9=lf[97] /* shared */ =C_SCHEME_FALSE;;
t10=lf[98] /* static */ =C_SCHEME_FALSE;;
t11=lf[99] /* static-libs */ =C_SCHEME_FALSE;;
t12=lf[100] /* static-extensions */ =C_SCHEME_END_OF_LIST;;
t13=lf[101] /* required-extensions */ =C_SCHEME_END_OF_LIST;;
t14=lf[102] /* gui */ =C_SCHEME_FALSE;;
t15=C_mutate(&lf[103] /* (set! compiler-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2875,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[108] /* (set! static-extension-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3027,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[114] /* (set! linker-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3124,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[118] /* (set! linker-libraries ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3176,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[120] /* (set! constant711 ...) */,lf[121]);
t20=C_mutate(&lf[106] /* (set! quote-option ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3325,tmp=(C_word)a,a+=2,tmp));
t21=lf[130] /* last-exit-code */ =C_SCHEME_FALSE;;
t22=C_mutate(&lf[131] /* (set! $system ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3350,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate(&lf[138] /* (set! $delete-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3381,tmp=(C_word)a,a+=2,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3407,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3411,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3415,a[2]=t26,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 941  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[333]))(3,*((C_word*)lf[333]+1),t27,lf[334]);}

/* k3413 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[332]);
/* csc.scm: 941  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[284]))(3,*((C_word*)lf[284]+1),((C_word*)t0)[2],t2);}

/* k3409 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 941  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[15],"arguments"));}

/* k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1177,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1184,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1223,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1252,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1252(t8,((C_word*)t0)[2],t1);}

/* loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_1252(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1252,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1263,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 494  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[84],"compile-options"),C_retrieve2(lf[85],"builtin-compile-options"));}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1450,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* csc.scm: 540  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[331]+1)))(3,*((C_word*)lf[331]+1),t7,t3);}}

/* k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1453,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[177]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t1,lf[178]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1465,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 271  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[179]+1)))(3,*((C_word*)lf[179]+1),t5,lf[180]);}
else{
t5=(C_word)C_eqp(t1,lf[181]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1477,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1484,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 546  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[182]))(2,*((C_word*)lf[182]+1),t7);}
else{
t6=(C_word)C_eqp(t1,lf[183]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1493,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1500,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 549  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[160]))(4,*((C_word*)lf[160]+1),t8,C_retrieve2(lf[25],"translator"),lf[184]);}
else{
t7=(C_word)C_eqp(t1,lf[185]);
if(C_truep(t7)){
t8=lf[63] /* cpp-mode */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[186],C_retrieve2(lf[84],"compile-options"));
t10=C_mutate(&lf[84] /* (set! compile-options ...) */,t9);
t11=t2;
f_1453(2,t11,t10);}
else{
t9=t2;
f_1453(2,t9,C_SCHEME_UNDEFINED);}}
else{
t8=(C_word)C_eqp(t1,lf[187]);
if(C_truep(t8)){
t9=lf[64] /* objc-mode */ =C_SCHEME_TRUE;;
t10=t2;
f_1453(2,t10,t9);}
else{
t9=(C_word)C_eqp(t1,lf[188]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1531,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 557  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t10,lf[189],lf[190],C_retrieve2(lf[81],"translate-options"));}
else{
t10=(C_word)C_eqp(t1,lf[191]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1542,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 560  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t11,lf[192],lf[193],C_retrieve2(lf[81],"translate-options"));}
else{
t11=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t11)){
t12=lf[66] /* inquiry-only */ =C_SCHEME_TRUE;;
t13=lf[67] /* show-cflags */ =C_SCHEME_TRUE;;
t14=t2;
f_1453(2,t14,t13);}
else{
t12=(C_word)C_eqp(t1,lf[195]);
if(C_truep(t12)){
t13=lf[66] /* inquiry-only */ =C_SCHEME_TRUE;;
t14=lf[68] /* show-ldflags */ =C_SCHEME_TRUE;;
t15=t2;
f_1453(2,t15,t14);}
else{
t13=(C_word)C_eqp(t1,lf[196]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1568,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 568  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[137]+1)))(3,*((C_word*)lf[137]+1),t14,C_retrieve2(lf[26],"compiler"));}
else{
t14=(C_word)C_eqp(t1,lf[197]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1580,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 569  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[137]+1)))(3,*((C_word*)lf[137]+1),t15,C_retrieve2(lf[27],"c++-compiler"));}
else{
t15=(C_word)C_eqp(t1,lf[198]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1592,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 570  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[137]+1)))(3,*((C_word*)lf[137]+1),t16,C_retrieve2(lf[28],"linker"));}
else{
t16=(C_word)C_eqp(t1,lf[199]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1604,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 571  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[137]+1)))(3,*((C_word*)lf[137]+1),t17,C_retrieve2(lf[24],"home"));}
else{
t17=(C_word)C_eqp(t1,lf[200]);
if(C_truep(t17)){
t18=lf[66] /* inquiry-only */ =C_SCHEME_TRUE;;
t19=lf[69] /* show-libs */ =C_SCHEME_TRUE;;
t20=t2;
f_1453(2,t20,t19);}
else{
t18=(C_word)C_eqp(t1,lf[201]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_i_numberp(C_retrieve2(lf[92],"verbose"));
t21=(C_truep(t20)?(C_word)C_i_not(C_retrieve2(lf[5],"msvc")):C_SCHEME_FALSE);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1639,a[2]=t19,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 577  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t22,lf[205],lf[206],C_retrieve2(lf[84],"compile-options"));}
else{
t22=t19;
f_1624(t22,C_SCHEME_UNDEFINED);}}
else{
t19=(C_word)C_eqp(t1,lf[207]);
t20=(C_truep(t19)?t19:(C_word)C_eqp(t1,lf[208]));
if(C_truep(t20)){
t21=lf[92] /* verbose */ =C_SCHEME_TRUE;;
/* csc.scm: 585  t-options */
f_1177(t2,(C_word)C_a_i_list(&a,1,lf[209]));}
else{
t21=(C_word)C_eqp(t1,lf[210]);
if(C_truep(t21)){
t22=lf[92] /* verbose */ =C_SCHEME_TRUE;;
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1676,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 588  t-options */
f_1177(t23,(C_word)C_a_i_list(&a,1,lf[215]));}
else{
t22=(C_word)C_eqp(t1,lf[216]);
t23=(C_truep(t22)?t22:(C_word)C_eqp(t1,lf[217]));
if(C_truep(t23)){
t24=(C_word)C_a_i_cons(&a,2,lf[218],C_retrieve2(lf[84],"compile-options"));
t25=C_mutate(&lf[84] /* (set! compile-options ...) */,t24);
/* csc.scm: 594  t-options */
f_1177(t2,(C_word)C_a_i_list(&a,1,lf[219]));}
else{
t24=(C_word)C_eqp(t1,lf[220]);
t25=(C_truep(t24)?t24:(C_word)C_eqp(t1,lf[221]));
if(C_truep(t25)){
t26=lf[94] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm: 597  t-options */
f_1177(t2,(C_word)C_a_i_list(&a,1,lf[222]));}
else{
t26=(C_word)C_eqp(t1,lf[223]);
t27=(C_truep(t26)?t26:(C_word)C_eqp(t1,lf[224]));
if(C_truep(t27)){
t28=lf[94] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm: 600  t-options */
f_1177(t2,(C_word)C_a_i_list(&a,1,lf[225]));}
else{
t28=(C_word)C_eqp(t1,lf[226]);
if(C_truep(t28)){
t29=lf[93] /* keep-files */ =C_SCHEME_TRUE;;
t30=t2;
f_1453(2,t30,t29);}
else{
t29=(C_word)C_eqp(t1,lf[227]);
if(C_truep(t29)){
t30=lf[95] /* compile-only */ =C_SCHEME_TRUE;;
t31=t2;
f_1453(2,t31,t30);}
else{
t30=(C_word)C_eqp(t1,lf[228]);
if(C_truep(t30)){
t31=lf[94] /* translate-only */ =C_SCHEME_TRUE;;
t32=t2;
f_1453(2,t32,t31);}
else{
t31=(C_word)C_eqp(t1,lf[229]);
t32=(C_truep(t31)?t31:(C_word)C_eqp(t1,lf[230]));
if(C_truep(t32)){
t33=lf[65] /* embedded */ =C_SCHEME_TRUE;;
t34=(C_word)C_a_i_cons(&a,2,lf[231],C_retrieve2(lf[84],"compile-options"));
t35=C_mutate(&lf[84] /* (set! compile-options ...) */,t34);
t36=t2;
f_1453(2,t36,t35);}
else{
t33=(C_word)C_eqp(t1,lf[232]);
t34=(C_truep(t33)?t33:(C_word)C_eqp(t1,lf[233]));
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1783,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 608  check */
f_1184(t35,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t35=(C_word)C_eqp(t1,lf[235]);
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1815,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 613  check */
f_1184(t36,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t36=(C_word)C_eqp(t1,lf[237]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t1,lf[238]));
if(C_truep(t37)){
t38=lf[102] /* gui */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[3],"mingw"))){
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1855,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 622  cons* */
((C_proc7)C_retrieve_symbol_proc(lf[127]))(7,*((C_word*)lf[127]+1),t39,lf[240],lf[241],lf[242],lf[243],C_retrieve2(lf[89],"link-options"));}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1866,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 627  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[127]))(6,*((C_word*)lf[127]+1),t39,lf[245],lf[246],lf[247],C_retrieve2(lf[89],"link-options"));}
else{
t39=t2;
f_1453(2,t39,C_SCHEME_UNDEFINED);}}}
else{
t38=(C_word)C_eqp(t1,lf[248]);
if(C_truep(t38)){
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1879,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 630  check */
f_1184(t39,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t39=(C_word)C_eqp(t1,lf[250]);
if(C_truep(t39)){
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1903,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 635  check */
f_1184(t40,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t40=(C_word)C_eqp(t1,lf[251]);
t41=(C_truep(t40)?t40:(C_word)C_eqp(t1,lf[252]));
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1924,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 639  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t42,lf[253],lf[254],((C_word*)((C_word*)t0)[6])[1]);}
else{
t42=(C_word)C_eqp(t1,lf[255]);
if(C_truep(t42)){
t43=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1934,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 640  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t43,lf[256],lf[257],((C_word*)((C_word*)t0)[6])[1]);}
else{
t43=(C_word)C_eqp(t1,lf[258]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1944,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 641  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t44,lf[259],lf[260],((C_word*)((C_word*)t0)[6])[1]);}
else{
t44=(C_word)C_eqp(t1,lf[261]);
if(C_truep(t44)){
t45=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1954,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 642  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t45,lf[262],lf[263],((C_word*)((C_word*)t0)[6])[1]);}
else{
t45=(C_word)C_eqp(t1,lf[264]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1964,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 643  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t46,lf[265],lf[266],((C_word*)((C_word*)t0)[6])[1]);}
else{
t46=(C_word)C_eqp(t1,lf[267]);
if(C_truep(t46)){
t47=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1974,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 644  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t47,lf[268],lf[269],((C_word*)((C_word*)t0)[6])[1]);}
else{
t47=(C_word)C_eqp(t1,lf[270]);
if(C_truep(t47)){
t48=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1984,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 645  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t48,lf[271],lf[272],((C_word*)((C_word*)t0)[6])[1]);}
else{
t48=(C_word)C_eqp(t1,lf[273]);
if(C_truep(t48)){
t49=lf[92] /* verbose */ =C_SCHEME_TRUE;;
t50=lf[70] /* dry-run */ =C_SCHEME_TRUE;;
t51=t2;
f_1453(2,t51,t50);}
else{
t49=(C_word)C_eqp(t1,lf[274]);
t50=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t49)){
t51=t50;
f_2001(t51,t49);}
else{
t51=(C_word)C_eqp(t1,lf[329]);
t52=t50;
f_2001(t52,(C_truep(t51)?t51:(C_word)C_eqp(t1,lf[330])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_2001(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2001,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 650  shared-build */
f_1223(((C_word*)t0)[7],C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[275]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[6],lf[276]));
if(C_truep(t3)){
/* csc.scm: 652  shared-build */
f_1223(((C_word*)t0)[7],C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[277]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2025,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 654  check */
f_1184(t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[278]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2042,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 658  check */
f_1184(t6,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[279]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2059,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 662  check */
f_1184(t7,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[280]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2076,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 666  check */
f_1184(t8,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[6],lf[281]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 670  check */
f_1184(t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[283]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2114,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 673  check */
f_1184(t10,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[285]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2140,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,lf[286]);
/* csc.scm: 677  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t11,C_retrieve2(lf[89],"link-options"),t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[287]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2153,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 679  check */
f_1184(t12,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[288]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2178,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 683  t-options */
f_1177(t13,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[289]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2189,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 687  check */
f_1184(t14,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[293]);
if(C_truep(t14)){
t15=((C_word*)t0)[7];
f_1453(2,t15,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[6],lf[294]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2235,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 693  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[20]))(5,*((C_word*)lf[20]+1),t16,C_SCHEME_FALSE,lf[296],C_retrieve2(lf[41],"executable-extension"));}
else{
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2242,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t17=((C_word*)t0)[6];
if(C_truep((C_truep((C_word)C_eqp(t17,lf[328]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t17,lf[326]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t18=(C_word)C_eqp(((C_word*)t0)[6],lf[326]);
if(C_truep(t18)){
t19=C_mutate(&lf[79] /* (set! library-files ...) */,C_retrieve2(lf[75],"unsafe-library-files"));
t20=C_mutate(&lf[80] /* (set! shared-library-files ...) */,C_retrieve2(lf[76],"unsafe-shared-library-files"));
t21=t16;
f_2242(t21,t20);}
else{
t19=t16;
f_2242(t19,C_SCHEME_UNDEFINED);}}
else{
t18=t16;
f_2242(t18,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}}}}

/* k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_2242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2242,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[327]);
if(C_truep(t3)){
t4=lf[96] /* to-stdout */ =C_SCHEME_TRUE;;
t5=lf[94] /* translate-only */ =C_SCHEME_TRUE;;
t6=t2;
f_2245(t6,t5);}
else{
t4=t2;
f_2245(t4,C_SCHEME_UNDEFINED);}}

/* k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_2245(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2245,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[7];
if(C_truep((C_truep((C_word)C_eqp(t3,lf[325]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[326]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=C_mutate(&lf[86] /* (set! compilation-optimization-options ...) */,C_retrieve2(lf[55],"best-compilation-optimization-options"));
t5=C_mutate(&lf[87] /* (set! linking-optimization-options ...) */,C_retrieve2(lf[57],"best-linking-optimization-options"));
t6=t2;
f_2248(t6,t5);}
else{
t4=t2;
f_2248(t4,C_SCHEME_UNDEFINED);}}

/* k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_2248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2248,NULL,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[7],lf[297]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[6])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=((C_word*)t0)[5];
f_1453(2,t6,t5);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],lf[298]))){
/* csc.scm: 707  t-options */
f_1177(((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],lf[299]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2280,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 709  check */
f_1184(t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2299,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_greaterp(t4,C_fix(2)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2630,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 714  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[301]+1)))(5,*((C_word*)lf[301]+1),t5,((C_word*)t0)[3],C_fix(0),C_fix(2));}
else{
t5=t3;
f_2299(t5,C_SCHEME_FALSE);}}}}}

/* k2628 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2299(t2,(C_word)C_i_string_equal_p(lf[324],t1));}

/* k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_2299(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2299,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 715  t-options */
f_1177(((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t3,C_fix(1)))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],C_fix(0));
t5=t2;
f_2308(t5,(C_word)C_eqp(C_make_character(45),t4));}
else{
t4=t2;
f_2308(t4,C_SCHEME_FALSE);}}}

/* k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_2308(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2308,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_eqp(C_make_character(108),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2318,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 719  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t4,C_retrieve2(lf[89],"link-options"),t5);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_eqp(C_make_character(76),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2332,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 721  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t6,C_retrieve2(lf[89],"link-options"),t7);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t7=(C_word)C_eqp(C_make_character(73),t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 723  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t8,C_retrieve2(lf[84],"compile-options"),t9);}
else{
t8=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t9=(C_word)C_eqp(C_make_character(68),t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2363,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 725  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[301]+1)))(4,*((C_word*)lf[301]+1),t10,((C_word*)t0)[6],C_fix(2));}
else{
t10=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t11=(C_word)C_eqp(C_make_character(70),t10);
if(C_truep(t11)){
if(C_truep(C_retrieve2(lf[7],"osx"))){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t13=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 728  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t12,C_retrieve2(lf[84],"compile-options"),t13);}
else{
t12=((C_word*)t0)[5];
f_1453(2,t12,C_SCHEME_UNDEFINED);}}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t13,C_fix(3)))){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2455,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 729  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[301]+1)))(5,*((C_word*)lf[301]+1),t14,((C_word*)t0)[6],C_fix(0),C_fix(4));}
else{
t14=t12;
f_2386(t14,C_SCHEME_FALSE);}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2485,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 738  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[322]))(3,*((C_word*)lf[322]+1),t2,((C_word*)t0)[6]);}}

/* k2483 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2485,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2490,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2496,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2593,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 755  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,((C_word*)t0)[4],lf[323]);}}

/* k2591 in k2483 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 756  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[322]))(3,*((C_word*)lf[322]+1),t2,t1);}

/* k2597 in k2591 in k2483 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2599,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_1453(2,t4,t3);}
else{
/* csc.scm: 758  quit */
f_958(((C_word*)t0)[3],lf[321],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a2495 in k2483 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2496,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep(t5)){
t6=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t6,lf[310]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t6,lf[311]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2521,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 742  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t7,C_retrieve2(lf[59],"c-files"),t8);}
else{
t7=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t7,lf[312]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[313]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[314]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[315]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[316]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2534,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[317],C_retrieve2(lf[84],"compile-options"));
t10=C_mutate(&lf[84] /* (set! compile-options ...) */,t9);
t11=t8;
f_2534(t11,t10);}
else{
t9=t8;
f_2534(t9,C_SCHEME_UNDEFINED);}}
else{
t8=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t8,lf[318]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[319]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[320]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t9=lf[64] /* objc-mode */ =C_SCHEME_TRUE;;
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2558,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 749  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t10,C_retrieve2(lf[59],"c-files"),t11);}
else{
t9=(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[32],"object-extension"));
t10=(C_truep(t9)?t9:(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[35],"library-extension")));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2575,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 752  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t11,C_retrieve2(lf[61],"object-files"),t12);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2583,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 753  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t11,C_retrieve2(lf[58],"scheme-files"),t12);}}}}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2507,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 740  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t6,C_retrieve2(lf[58],"scheme-files"),t7);}}

/* k2505 in a2495 in k2483 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[58] /* (set! scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2581 in a2495 in k2483 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[58] /* (set! scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2573 in a2495 in k2483 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61] /* (set! object-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2556 in a2495 in k2483 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[59] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2532 in a2495 in k2483 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_2534(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2534,NULL,2,t0,t1);}
t2=lf[63] /* cpp-mode */ =C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2539,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 746  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[59],"c-files"),t4);}

/* k2537 in k2532 in a2495 in k2483 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[59] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2519 in a2495 in k2483 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[59] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a2489 in k2483 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2490,2,t0,t1);}
/* csc.scm: 739  decompose-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[309]))(3,*((C_word*)lf[309]+1),t1,((C_word*)t0)[2]);}

/* k2453 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2386(t2,(C_word)C_i_string_equal_p(lf[308],t1));}

/* k2384 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_2386(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2386,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2390,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* csc.scm: 730  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t2,C_retrieve2(lf[89],"link-options"),t3);}
else{
t2=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2438,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* string->list */
t4=C_retrieve(lf[128]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
/* csc.scm: 737  quit */
f_958(((C_word*)t0)[5],lf[307],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}}

/* k2436 in k2384 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2438,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2434,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 733  lset-difference */
((C_proc5)C_retrieve_symbol_proc(lf[304]))(5,*((C_word*)lf[304]+1),t3,*((C_word*)lf[305]+1),t2,lf[306]);}

/* k2432 in k2436 in k2384 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2434,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2413,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2417,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2419,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}
else{
/* csc.scm: 736  quit */
f_958(((C_word*)t0)[4],lf[303],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a2418 in k2432 in k2436 in k2384 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2419,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* csc.scm: 735  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t1,lf[302],t3);}

/* k2415 in k2432 in k2436 in k2384 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 735  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k2411 in k2432 in k2436 in k2384 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k2388 in k2384 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k2374 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k2361 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
/* csc.scm: 725  t-options */
f_1177(((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,lf[300],t1));}

/* k2344 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k2330 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k2316 in k2306 in k2297 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k2278 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2280,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2286,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 711  string->number */
C_string_to_number(3,0,t3,t2);}

/* k2284 in k2278 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2289,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 712  t-options */
f_1177(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k2287 in k2284 in k2278 in k2246 in k2243 in k2240 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_1453(2,t4,t3);}

/* k2233 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2235,2,t0,t1);}
t2=C_mutate(&lf[91] /* (set! target-filename ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 694  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[58],"scheme-files"),lf[295]);}

/* k2237 in k2233 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[58] /* (set! scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k2187 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2219,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 688  build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[292]))(2,*((C_word*)lf[292]+1),t2);}

/* k2217 in k2187 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2219,2,t0,t1);}
t2=(C_word)C_eqp(lf[290],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2199,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2211,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 689  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t4,lf[291],t5);}
else{
t3=((C_word*)t0)[2];
f_1453(2,t3,C_SCHEME_UNDEFINED);}}

/* k2209 in k2217 in k2187 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2211,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* csc.scm: 689  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[89],"link-options"),t2);}

/* k2197 in k2217 in k2187 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1453(2,t5,t4);}

/* k2176 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[79] /* (set! library-files ...) */,C_retrieve2(lf[75],"unsafe-library-files"));
t3=C_mutate(&lf[80] /* (set! shared-library-files ...) */,C_retrieve2(lf[76],"unsafe-shared-library-files"));
t4=((C_word*)t0)[2];
f_1453(2,t4,t3);}

/* k2151 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2165,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 680  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[284]))(3,*((C_word*)lf[284]+1),t3,t4);}

/* k2163 in k2151 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 680  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[89],"link-options"),t1);}

/* k2155 in k2151 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1453(2,t5,t4);}

/* k2138 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k2112 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2118,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2126,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 674  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[284]))(3,*((C_word*)lf[284]+1),t3,t4);}

/* k2124 in k2112 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 674  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[84],"compile-options"),t1);}

/* k2116 in k2112 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1453(2,t5,t4);}

/* k2091 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2097,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 671  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t2,lf[282],t3,t4);}

/* k2095 in k2091 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k2074 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[28] /* (set! linker ...) */,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_1453(2,t6,t5);}

/* k2057 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[27] /* (set! c++-compiler ...) */,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_1453(2,t6,t5);}

/* k2040 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[26] /* (set! compiler ...) */,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_1453(2,t6,t5);}

/* k2023 in k1999 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[25] /* (set! translator ...) */,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_1453(2,t6,t5);}

/* k1982 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k1972 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k1962 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k1952 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k1942 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k1932 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k1922 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k1901 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=C_mutate(&lf[91] /* (set! target-filename ...) */,t2);
t6=((C_word*)t0)[2];
f_1453(2,t6,t5);}

/* k1877 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1890,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 632  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t3,lf[249],t4,C_retrieve2(lf[89],"link-options"));}
else{
t3=t2;
f_1882(t3,C_SCHEME_UNDEFINED);}}

/* k1888 in k1877 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1882(t3,t2);}

/* k1880 in k1877 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_1882(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_1453(2,t4,t3);}

/* k1864 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1866,2,t0,t1);}
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[244],C_retrieve2(lf[84],"compile-options"));
t4=C_mutate(&lf[84] /* (set! compile-options ...) */,t3);
t5=((C_word*)t0)[2];
f_1453(2,t5,t4);}

/* k1853 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[239],C_retrieve2(lf[84],"compile-options"));
t4=C_mutate(&lf[84] /* (set! compile-options ...) */,t3);
t5=((C_word*)t0)[2];
f_1453(2,t5,t4);}

/* k1813 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* csc.scm: 614  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t2,C_retrieve2(lf[100],"static-extensions"),t4);}

/* k1817 in k1813 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1819,2,t0,t1);}
t2=C_mutate(&lf[100] /* (set! static-extensions ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1822,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 615  t-options */
f_1177(t3,(C_word)C_a_i_list(&a,2,lf[236],t4));}

/* k1820 in k1817 in k1813 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_1453(2,t4,t3);}

/* k1781 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* csc.scm: 609  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t2,C_retrieve2(lf[101],"required-extensions"),t4);}

/* k1785 in k1781 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1787,2,t0,t1);}
t2=C_mutate(&lf[101] /* (set! required-extensions ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 610  t-options */
f_1177(t3,(C_word)C_a_i_list(&a,2,lf[234],t4));}

/* k1788 in k1785 in k1781 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_1453(2,t4,t3);}

/* k1674 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1679,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t3=t2;
f_1679(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1694,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 590  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t3,lf[213],lf[214],C_retrieve2(lf[84],"compile-options"));}}

/* k1692 in k1674 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1679(t3,t2);}

/* k1677 in k1674 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_1679(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1679,NULL,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[211]:lf[212]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve2(lf[89],"link-options"));
t4=C_mutate(&lf[89] /* (set! link-options ...) */,t3);
t5=((C_word*)t0)[2];
f_1453(2,t5,t4);}

/* k1637 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1639,2,t0,t1);}
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[203]:lf[204]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[89],"link-options"));
t5=C_mutate(&lf[89] /* (set! link-options ...) */,t4);
t6=((C_word*)t0)[2];
f_1624(t6,t5);}

/* k1622 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_1624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1624,NULL,2,t0,t1);}
if(C_truep(C_retrieve2(lf[92],"verbose"))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1630,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 580  t-options */
f_1177(t2,(C_word)C_a_i_list(&a,1,lf[202]));}
else{
t2=lf[92] /* verbose */ =C_SCHEME_TRUE;;
t3=((C_word*)t0)[3];
f_1453(2,t3,t2);}}

/* k1628 in k1622 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=lf[92] /* verbose */ =C_fix(2);;
t3=((C_word*)t0)[2];
f_1453(2,t3,t2);}

/* k1602 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 571  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_fix(0));}

/* k1590 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 570  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_fix(0));}

/* k1578 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 569  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_fix(0));}

/* k1566 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 568  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_fix(0));}

/* k1540 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[81] /* (set! translate-options ...) */,t1);
t3=lf[99] /* static-libs */ =C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];
f_1453(2,t4,t3);}

/* k1529 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[81] /* (set! translate-options ...) */,t1);
t3=lf[98] /* static */ =C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];
f_1453(2,t4,t3);}

/* k1498 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 549  system */
((C_proc3)C_retrieve_symbol_proc(lf[134]))(3,*((C_word*)lf[134]+1),((C_word*)t0)[2],t1);}

/* k1491 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 550  exit */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),((C_word*)t0)[2]);}

/* k1482 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 546  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[137]+1)))(3,*((C_word*)lf[137]+1),((C_word*)t0)[2],t1);}

/* k1475 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 547  exit */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),((C_word*)t0)[2]);}

/* k1463 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 544  exit */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),((C_word*)t0)[2]);}

/* k1451 in k1448 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 759  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1252(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1263,2,t0,t1);}
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1267,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 495  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[89],"link-options"),C_retrieve2(lf[90],"builtin-link-options"));}

/* k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1267,2,t0,t1);}
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1270,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[66],"inquiry-only"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1408,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[67],"show-cflags"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1441,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 498  compiler-options */
f_2875(t5);}
else{
t5=t4;
f_1408(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1270(2,t4,C_SCHEME_UNDEFINED);}}

/* k1439 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 498  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[176]+1)))(4,*((C_word*)lf[176]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k1406 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1411,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[68],"show-ldflags"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1434,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 499  linker-options */
f_3124(t3);}
else{
t3=t2;
f_1411(2,t3,C_SCHEME_UNDEFINED);}}

/* k1432 in k1406 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 499  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[176]+1)))(4,*((C_word*)lf[176]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k1409 in k1406 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1414,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[69],"show-libs"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1427,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 500  linker-libraries */
f_3176(t3,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}
else{
t3=t2;
f_1414(2,t3,C_SCHEME_UNDEFINED);}}

/* k1425 in k1409 in k1406 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 500  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[176]+1)))(4,*((C_word*)lf[176]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k1412 in k1409 in k1406 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1417,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 501  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[175]+1)))(2,*((C_word*)lf[175]+1),t2);}

/* k1415 in k1412 in k1409 in k1406 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 502  exit */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),((C_word*)t0)[2]);}

/* k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1273,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(C_retrieve2(lf[58],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1333,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_nullp(C_retrieve2(lf[59],"c-files"));
t5=(C_truep(t4)?(C_word)C_i_nullp(C_retrieve2(lf[61],"object-files")):C_SCHEME_FALSE);
if(C_truep(t5)){
/* csc.scm: 509  quit */
f_958(t3,lf[167],C_SCHEME_END_OF_LIST);}
else{
t6=t3;
f_1333(2,t6,C_SCHEME_UNDEFINED);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1371,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[97],"shared"))?(C_word)C_i_not(C_retrieve2(lf[65],"embedded")):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[174],C_retrieve2(lf[81],"translate-options"));
t6=C_mutate(&lf[81] /* (set! translate-options ...) */,t5);
t7=t3;
f_1371(t7,t6);}
else{
t5=t3;
f_1371(t5,C_SCHEME_UNDEFINED);}}}

/* k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_1371(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1371,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1374,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[91],"target-filename"))){
t3=t2;
f_1374(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1381,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[97],"shared"))){
t4=(C_word)C_i_car(C_retrieve2(lf[58],"scheme-files"));
/* csc.scm: 522  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[165]))(4,*((C_word*)lf[165]+1),t3,t4,C_retrieve2(lf[45],"shared-library-extension"));}
else{
t4=(C_word)C_i_car(C_retrieve2(lf[58],"scheme-files"));
/* csc.scm: 523  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[165]))(4,*((C_word*)lf[165]+1),t3,t4,C_retrieve2(lf[41],"executable-extension"));}}}

/* k1379 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[91] /* (set! target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_1374(t3,t2);}

/* k1372 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_1374(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1374,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2700,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2708,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[58],"scheme-files"));}

/* a2707 in k1372 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2708,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2712,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(C_retrieve2(lf[58],"scheme-files"));
t5=(C_word)C_i_nequalp(C_fix(1),t4);
t6=(C_truep(t5)?C_retrieve2(lf[91],"target-filename"):t2);
t7=(C_truep(C_retrieve2(lf[63],"cpp-mode"))?lf[171]:(C_truep(C_retrieve2(lf[64],"objc-mode"))?lf[172]:lf[173]));
/* csc.scm: 767  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[165]))(4,*((C_word*)lf[165]+1),t3,t6,t7);}

/* k2710 in a2707 in k1372 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2715,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2741,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2745,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2749,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2753,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 777  cleanup-filename */
((C_proc3)C_retrieve2_symbol_proc(lf[53],"cleanup-filename"))(3,lf[53],t6,((C_word*)t0)[2]);}

/* k2751 in k2710 in a2707 in k1372 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2757,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2761,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[96],"to-stdout"))){
t4=t3;
f_2761(t4,lf[169]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2780,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 781  cleanup-filename */
((C_proc3)C_retrieve2_symbol_proc(lf[53],"cleanup-filename"))(3,lf[53],t4,((C_word*)t0)[2]);}}

/* k2778 in k2751 in k2710 in a2707 in k1372 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2780,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
f_2761(t3,(C_word)C_a_i_cons(&a,2,lf[170],t2));}

/* k2759 in k2751 in k2710 in a2707 in k1372 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_2761(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2761,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2765,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2769,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 782  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[81],"translate-options"),C_SCHEME_END_OF_LIST);}

/* k2767 in k2759 in k2751 in k2710 in a2707 in k1372 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[106],"quote-option"),t1);}

/* k2763 in k2759 in k2751 in k2710 in a2707 in k1372 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 778  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2755 in k2751 in k2710 in a2707 in k1372 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 777  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),((C_word*)t0)[3],C_retrieve2(lf[25],"translator"),((C_word*)t0)[2],t1);}

/* k2747 in k2710 in a2707 in k1372 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 776  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[104]))(4,*((C_word*)lf[104]+1),((C_word*)t0)[2],t1,lf[168]);}

/* k2743 in k2710 in a2707 in k1372 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 775  $system */
f_3350(((C_word*)t0)[2],t1);}

/* k2739 in k2710 in a2707 in k1372 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2715(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 784  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k2713 in k2710 in a2707 in k1372 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 785  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t2,t3,C_retrieve2(lf[59],"c-files"));}

/* k2717 in k2713 in k2710 in a2707 in k1372 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2719,2,t0,t1);}
t2=C_mutate(&lf[59] /* (set! c-files ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2723,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 786  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,t4,C_retrieve2(lf[60],"generated-c-files"));}

/* k2721 in k2717 in k2713 in k2710 in a2707 in k1372 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60] /* (set! generated-c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2698 in k1372 in k1369 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[93],"keep-files"))){
t2=((C_word*)t0)[2];
f_1273(2,t2,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[138],"$delete-file"),C_SCHEME_END_OF_LIST);}}

/* k1331 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_nullp(C_retrieve2(lf[59],"c-files"));
t4=(C_truep(t3)?C_retrieve2(lf[61],"object-files"):C_retrieve2(lf[59],"c-files"));
/* csc.scm: 510  last */
((C_proc3)C_retrieve_symbol_proc(lf[166]))(3,*((C_word*)lf[166]+1),t2,t4);}

/* k1334 in k1331 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1336,2,t0,t1);}
if(C_truep(C_retrieve2(lf[91],"target-filename"))){
t2=((C_word*)t0)[2];
f_1273(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1343,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[97],"shared"))){
/* csc.scm: 514  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[165]))(4,*((C_word*)lf[165]+1),t2,t1,C_retrieve2(lf[45],"shared-library-extension"));}
else{
/* csc.scm: 515  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[165]))(4,*((C_word*)lf[165]+1),t2,t1,C_retrieve2(lf[41],"executable-extension"));}}}

/* k1341 in k1334 in k1331 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[91] /* (set! target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_1273(2,t3,t2);}

/* k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1273,2,t0,t1);}
if(C_truep(C_retrieve2(lf[94],"translate-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1279,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2804,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2820,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_retrieve2(lf[59],"c-files"));}}

/* a2819 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2820,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2824,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 797  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[165]))(4,*((C_word*)lf[165]+1),t3,t2,C_retrieve2(lf[32],"object-extension"));}

/* k2822 in a2819 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2827,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2845,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2849,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[63],"cpp-mode"))?C_retrieve2(lf[27],"c++-compiler"):C_retrieve2(lf[26],"compiler"));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2861,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 803  cleanup-filename */
((C_proc3)C_retrieve2_symbol_proc(lf[53],"cleanup-filename"))(3,lf[53],t6,((C_word*)t0)[2]);}

/* k2859 in k2822 in a2819 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2865,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2873,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 804  cleanup-filename */
((C_proc3)C_retrieve2_symbol_proc(lf[53],"cleanup-filename"))(3,lf[53],t3,((C_word*)t0)[2]);}

/* k2871 in k2859 in k2822 in a2819 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 804  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),((C_word*)t0)[2],C_retrieve2(lf[44],"compile-output-flag"),t1);}

/* k2863 in k2859 in k2822 in a2819 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2869,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 806  compiler-options */
f_2875(t2);}

/* k2867 in k2863 in k2859 in k2822 in a2819 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2869,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[164],t1);
/* csc.scm: 800  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),((C_word*)t0)[2],t2);}

/* k2847 in k2822 in a2819 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 799  $system */
f_3350(((C_word*)t0)[2],t1);}

/* k2843 in k2822 in a2819 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2827(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 807  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k2825 in k2822 in a2819 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2827,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_retrieve2(lf[62],"generated-object-files"));
t3=C_mutate(&lf[62] /* (set! generated-object-files ...) */,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2802 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2808,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2818,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 811  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[109]+1)))(3,*((C_word*)lf[109]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2816 in k2802 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 811  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[61],"object-files"));}

/* k2806 in k2802 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61] /* (set! object-files ...) */,t1);
if(C_truep(C_retrieve2(lf[93],"keep-files"))){
t3=((C_word*)t0)[2];
f_1279(2,t3,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t3=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[138],"$delete-file"),C_retrieve2(lf[60],"generated-c-files"));}}

/* k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1279,2,t0,t1);}
if(C_truep(C_retrieve2(lf[95],"compile-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1285,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_member(C_retrieve2(lf[91],"target-filename"),C_retrieve2(lf[58],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1294,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 529  printf */
((C_proc5)C_retrieve_symbol_proc(lf[132]))(5,*((C_word*)lf[132]+1),t3,lf[163],C_retrieve2(lf[91],"target-filename"),C_retrieve2(lf[91],"target-filename"));}
else{
t3=t2;
f_1285(2,t3,C_SCHEME_UNDEFINED);}}}

/* k1292 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1307,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1311,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve(lf[157]))?lf[158]:lf[159]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1319,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 533  quotewrap */
t6=C_retrieve2(lf[21],"quotewrap");
f_1000(3,t6,t5,C_retrieve2(lf[91],"target-filename"));}

/* k1317 in k1292 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1323,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1327,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 534  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t3,C_retrieve2(lf[91],"target-filename"),lf[162]);}

/* k1325 in k1317 in k1292 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 534  quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_1000(3,t2,((C_word*)t0)[2],t1);}

/* k1321 in k1317 in k1292 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 531  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[160]))(6,*((C_word*)lf[160]+1),((C_word*)t0)[4],lf[161],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1309 in k1292 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 531  $system */
f_3350(((C_word*)t0)[2],t1);}

/* k1305 in k1292 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_1285(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 535  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1285,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2900,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3009,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3013,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3015,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3021,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t5,t6,t7);}

/* a3020 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3021(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3021r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3021r(t0,t1,t2);}}

static void C_ccall f_3021r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a3014 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3015,2,t0,t1);}
/* csc.scm: 828  static-extension-info */
f_3027(t1);}

/* k3011 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 827  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[61],"object-files"),t1);}

/* k3007 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[53],"cleanup-filename"),t1);}

/* k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2903,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 829  cleanup-filename */
((C_proc3)C_retrieve2_symbol_proc(lf[53],"cleanup-filename"))(3,lf[53],t2,C_retrieve2(lf[91],"target-filename"));}

/* k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2906,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2973,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2977,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2981,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_truep(C_retrieve2(lf[63],"cpp-mode"))?C_retrieve2(lf[29],"c++-linker"):C_retrieve2(lf[28],"linker"));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2989,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2997,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 837  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t8,C_retrieve2(lf[38],"link-output-flag"),t1);}

/* k2995 in k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 838  linker-options */
f_3124(t2);}

/* k2999 in k2995 in k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 839  linker-libraries */
f_3176(t2,(C_word)C_a_i_list(&a,1,C_SCHEME_FALSE));}

/* k3003 in k2999 in k2995 in k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3005,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],t1);
/* csc.scm: 835  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2987 in k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 833  cons* */
((C_proc4)C_retrieve_symbol_proc(lf[127]))(4,*((C_word*)lf[127]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2979 in k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 832  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),((C_word*)t0)[2],t1);}

/* k2975 in k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 831  $system */
f_3350(((C_word*)t0)[2],t1);}

/* k2971 in k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2906(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 840  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k2904 in k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2909,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2918,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t4=(C_word)C_i_not(C_retrieve2(lf[18],"cross-chicken"));
t5=t3;
f_2918(t5,(C_truep(t4)?t4:C_retrieve2(lf[17],"host-mode")));}
else{
t4=t3;
f_2918(t4,C_SCHEME_FALSE);}}

/* k2916 in k2904 in k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_2918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2918,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2931,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2935,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2939,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2943,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2947,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2951,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
/* ##sys#peek-c-string */
t8=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t8=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}
else{
t2=((C_word*)t0)[3];
f_2909(2,t2,C_SCHEME_UNDEFINED);}}

/* k2949 in k2916 in k2904 in k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 847  prefix */
f_987(((C_word*)t0)[2],lf[154],lf[155],t1);}

/* k2945 in k2916 in k2904 in k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 846  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[20]))(4,*((C_word*)lf[20]+1),((C_word*)t0)[2],t1,lf[153]);}

/* k2941 in k2916 in k2904 in k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 845  quotewrap */
t2=C_retrieve2(lf[21],"quotewrap");
f_1000(3,t2,((C_word*)t0)[2],t1);}

/* k2937 in k2916 in k2904 in k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 843  string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[117]+1)))(6,*((C_word*)lf[117]+1),((C_word*)t0)[3],lf[151],t1,lf[152],((C_word*)t0)[2]);}

/* k2933 in k2916 in k2904 in k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 842  $system */
f_3350(((C_word*)t0)[2],t1);}

/* k2929 in k2916 in k2904 in k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2909(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 854  exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_retrieve2(lf[130],"last-exit-code"));}}

/* k2907 in k2904 in k2901 in k2898 in k1283 in k1277 in k1271 in k1268 in k1265 in k1261 in loop in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[93],"keep-files"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[138],"$delete-file"),C_retrieve2(lf[62],"generated-object-files"));}}

/* shared-build in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_1223(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1223,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1228,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 482  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t3,lf[148],lf[149],C_retrieve2(lf[81],"translate-options"));}

/* k1226 in shared-build in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1228,2,t0,t1);}
t2=C_mutate(&lf[81] /* (set! translate-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 483  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[107]+1)))(5,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[49],"pic-options"),lf[147],C_retrieve2(lf[84],"compile-options"));}

/* k1230 in k1226 in shared-build in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1232,2,t0,t1);}
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=(C_truep(C_retrieve2(lf[7],"osx"))?(C_truep(((C_word*)t0)[3])?lf[143]:lf[144]):(C_truep(C_retrieve2(lf[5],"msvc"))?lf[145]:lf[146]));
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[89],"link-options"));
t5=C_mutate(&lf[89] /* (set! link-options ...) */,t4);
t6=lf[97] /* shared */ =C_SCHEME_TRUE;;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* check in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_1184(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1184,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1202,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t7=t6;
f_1202(2,t7,C_fix(1));}
else{
t7=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_1202(2,t8,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t8=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t4);}}}

/* k1200 in check in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1202,2,t0,t1);}
if(C_truep((C_word)C_i_greater_or_equalp(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 479  quit */
f_958(((C_word*)t0)[3],lf[142],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* t-options in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_1177(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1177,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1182,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 475  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[81],"translate-options"),t2);}

/* k1180 in t-options in k3405 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[81] /* (set! translate-options ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3395 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3400,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3403,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[141]))(2,*((C_word*)lf[141]+1),t3);}

/* k3401 in k3395 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3398 in k3395 in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* $delete-file in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3381,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3385,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[92],"verbose"))){
/* csc.scm: 935  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[137]+1)))(4,*((C_word*)lf[137]+1),t3,lf[140],t2);}
else{
t4=t3;
f_3385(2,t4,C_SCHEME_UNDEFINED);}}

/* k3383 in $delete-file in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[70],"dry-run"))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 936  delete-file */
((C_proc3)C_retrieve_symbol_proc(lf[139]))(3,*((C_word*)lf[139]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* $system in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_3350(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3350,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3354,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[92],"verbose"))){
/* csc.scm: 921  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[137]+1)))(3,*((C_word*)lf[137]+1),t3,t2);}
else{
t4=t3;
f_3354(2,t4,C_SCHEME_UNDEFINED);}}

/* k3352 in $system in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3357,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[50],"windows-shell"))){
/* csc.scm: 923  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[117]+1)))(5,*((C_word*)lf[117]+1),t2,lf[135],((C_word*)t0)[2],lf[136]);}
else{
t3=t2;
f_3357(2,t3,((C_word*)t0)[2]);}}

/* k3355 in k3352 in $system in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3361,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[70],"dry-run"))){
t3=t2;
f_3361(2,t3,C_fix(0));}
else{
/* csc.scm: 928  system */
((C_proc3)C_retrieve_symbol_proc(lf[134]))(3,*((C_word*)lf[134]+1),t2,t1);}}

/* k3359 in k3355 in k3352 in $system in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3361,2,t0,t1);}
t2=C_mutate(&lf[130] /* (set! last-exit-code ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3364,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_zerop(C_retrieve2(lf[130],"last-exit-code")))){
t4=t3;
f_3364(2,t4,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 930  printf */
((C_proc5)C_retrieve_symbol_proc(lf[132]))(5,*((C_word*)lf[132]+1),t3,lf[133],C_retrieve2(lf[130],"last-exit-code"),((C_word*)t0)[2]);}}

/* k3362 in k3359 in k3355 in k3352 in $system in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve2(lf[130],"last-exit-code"));}

/* quote-option in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3325(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3325,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3332,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3337,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 912  string-any */
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),t3,t4,t2);}

/* a3336 in quote-option in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3337,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_whitespacep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,lf[120])));}

/* k3330 in quote-option in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3332,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3258,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3272,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3276,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t9=C_retrieve(lf[128]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k3274 in k3330 in quote-option in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3276,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3278,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3278(t5,((C_word*)t0)[2],t1);}

/* fold in k3274 in k3330 in quote-option in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_3278(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3278,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_memq(t3,lf[120]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3301,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* csc.scm: 903  fold */
t9=t4;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3308,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_whitespacep(t3))){
t5=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t6=t4;
f_3308(t6,t5);}
else{
t5=t4;
f_3308(t5,C_SCHEME_UNDEFINED);}}}}

/* k3306 in fold in k3274 in k3330 in quote-option in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_3308(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3308,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3315,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csc.scm: 906  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3278(t4,t2,t3);}

/* k3313 in k3306 in fold in k3274 in k3330 in quote-option in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3315,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3299 in fold in k3274 in k3330 in quote-option in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 903  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),((C_word*)t0)[3],C_make_character(92),((C_word*)t0)[2],t1);}

/* k3270 in k3330 in quote-option in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=C_retrieve(lf[126]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3256 in k3330 in quote-option in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3258,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3268,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 908  string-translate* */
((C_proc4)C_retrieve_symbol_proc(lf[124]))(4,*((C_word*)lf[124]+1),t2,t1,lf[125]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k3266 in k3256 in k3330 in quote-option in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 908  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[117]+1)))(5,*((C_word*)lf[117]+1),((C_word*)t0)[2],lf[122],t1,lf[123]);}

/* linker-libraries in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_3176(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3176,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3180,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_3180(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_3180(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k3178 in linker-libraries in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3187,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3191,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3222,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3228,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t3,t4,t5);}
else{
t4=t3;
f_3191(2,t4,C_SCHEME_END_OF_LIST);}}

/* a3227 in k3178 in linker-libraries in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3228r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3228r(t0,t1,t2);}}

static void C_ccall f_3228r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a3221 in k3178 in linker-libraries in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3222,2,t0,t1);}
/* csc.scm: 883  static-extension-info */
f_3027(t1);}

/* k3189 in k3178 in linker-libraries in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3191,2,t0,t1);}
t2=C_retrieve2(lf[98],"static");
t3=(C_truep(t2)?t2:C_retrieve2(lf[99],"static-libs"));
t4=(C_truep(t3)?(C_truep(C_retrieve2(lf[102],"gui"))?C_retrieve2(lf[77],"gui-library-files"):C_retrieve2(lf[79],"library-files")):(C_truep(C_retrieve2(lf[102],"gui"))?C_retrieve2(lf[78],"gui-shared-library-files"):C_retrieve2(lf[80],"shared-library-files")));
t5=C_retrieve2(lf[98],"static");
t6=(C_truep(t5)?t5:C_retrieve2(lf[99],"static-libs"));
t7=(C_truep(t6)?(C_word)C_a_i_list(&a,1,C_retrieve2(lf[71],"extra-libraries")):(C_word)C_a_i_list(&a,1,C_retrieve2(lf[72],"extra-shared-libraries")));
/* csc.scm: 882  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[107]+1)))(5,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1,t4,t7);}

/* k3185 in k3178 in linker-libraries in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 881  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),((C_word*)t0)[2],t1);}

/* linker-options in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_3124(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3124,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3132,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3158,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3162,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3164,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3170,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a3169 in linker-options in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3170(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3170r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3170r(t0,t1,t2);}}

static void C_ccall f_3170r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(1)));}

/* a3163 in linker-options in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3164,2,t0,t1);}
/* csc.scm: 877  static-extension-info */
f_3027(t1);}

/* k3160 in linker-options in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 876  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[107]+1)))(5,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[87],"linking-optimization-options"),C_retrieve2(lf[89],"link-options"),t1);}

/* k3156 in linker-options in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 875  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),((C_word*)t0)[2],t1);}

/* k3130 in linker-options in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(C_retrieve2(lf[98],"static"))?(C_truep(C_retrieve2(lf[3],"mingw"))?C_SCHEME_FALSE:(C_truep(C_retrieve2(lf[5],"msvc"))?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve2(lf[7],"osx")))):C_SCHEME_FALSE);
t3=(C_truep(t2)?lf[115]:lf[116]);
/* csc.scm: 874  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),((C_word*)t0)[2],t1,t3);}

/* static-extension-info in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_3027(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3027,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3031,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 858  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[113]))(2,*((C_word*)lf[113]+1),t2);}

/* k3029 in static-extension-info in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3031,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_pairp(C_retrieve2(lf[100],"static-extensions")):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3042,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3042(t6,((C_word*)t0)[2],C_retrieve2(lf[100],"static-extensions"),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
/* csc.scm: 871  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* loop in k3029 in static-extension-info in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_3042(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3042,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3056,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 862  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[109]+1)))(3,*((C_word*)lf[109]+1),t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3063,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
/* csc.scm: 863  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[112]))(3,*((C_word*)lf[112]+1),t5,t6);}}

/* k3061 in loop in k3029 in static-extension-info in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3063,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[110],t1);
t3=(C_word)C_i_assq(lf[111],t1);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3083,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3101,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* csc.scm: 868  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[20]))(4,*((C_word*)lf[20]+1),t6,((C_word*)t0)[2],t7);}
else{
t6=t5;
f_3083(t6,((C_word*)t0)[3]);}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* csc.scm: 870  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3042(t3,((C_word*)t0)[5],t2,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k3099 in k3061 in loop in k3029 in static-extension-info in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3101,2,t0,t1);}
t2=((C_word*)t0)[3];
f_3083(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k3081 in k3061 in loop in k3029 in static-extension-info in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_3083(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3083,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3087,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=t2;
f_3087(t4,(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]));}
else{
t3=t2;
f_3087(t3,((C_word*)t0)[2]);}}

/* k3085 in k3081 in k3061 in loop in k3029 in static-extension-info in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_3087(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 867  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3042(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3054 in loop in k3029 in static-extension-info in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3060,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 862  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[109]+1)))(3,*((C_word*)lf[109]+1),t2,((C_word*)t0)[2]);}

/* k3058 in k3054 in loop in k3029 in static-extension-info in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_3060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 862  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* compiler-options in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_2875(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2875,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2883,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2887,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve2(lf[98],"static");
t5=(C_truep(t4)?t4:C_retrieve2(lf[99],"static-libs"));
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_END_OF_LIST);
/* csc.scm: 817  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[107]+1)))(5,*((C_word*)lf[107]+1),t3,t6,C_retrieve2(lf[86],"compilation-optimization-options"),C_retrieve2(lf[84],"compile-options"));}

/* k2885 in compiler-options in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[106],"quote-option"),t1);}

/* k2881 in compiler-options in k1152 in k1147 in k1139 in k1131 in k1122 in k3529 in k1114 in k3562 in k1106 in k1102 in k1076 in k1071 in k1066 in k1062 in k1030 in k1026 in k1022 in k1018 in k1014 in k1010 in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 815  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),((C_word*)t0)[2],t1);}

/* quotewrap in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1000,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1008,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 82   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t3,t2);}

/* k1006 in quotewrap in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_1008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 82   qs */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),((C_word*)t0)[2],t1);}

/* prefix in k975 in k971 in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_987(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_987,NULL,4,t1,t2,t3,t4);}
if(C_truep(C_retrieve2(lf[14],"chicken-prefix"))){
t5=(C_word)C_a_i_list(&a,2,C_retrieve2(lf[14],"chicken-prefix"),t3);
/* csc.scm: 78   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[20]))(4,*((C_word*)lf[20]+1),t1,t5,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* quit in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_fcall f_958(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_958,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_962,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_969,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 68   current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[13]))(2,*((C_word*)lf[13]+1),t5);}

/* k967 in quit in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 68   fprintf */
((C_proc6)C_retrieve_symbol_proc(lf[11]))(6,*((C_word*)lf[11]+1),((C_word*)t0)[4],t1,lf[12],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k960 in quit in k954 in k3727 in k3731 in k3735 in k938 in k935 in k932 in k929 in k926 in k923 in k920 in k917 in k914 in k911 in k908 in k905 in k902 */
static void C_ccall f_962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 69   exit */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[308] = {
{"toplevel:csc_scm",(void*)C_toplevel},
{"f_904:csc_scm",(void*)f_904},
{"f_907:csc_scm",(void*)f_907},
{"f_910:csc_scm",(void*)f_910},
{"f_913:csc_scm",(void*)f_913},
{"f_916:csc_scm",(void*)f_916},
{"f_919:csc_scm",(void*)f_919},
{"f_922:csc_scm",(void*)f_922},
{"f_925:csc_scm",(void*)f_925},
{"f_928:csc_scm",(void*)f_928},
{"f_931:csc_scm",(void*)f_931},
{"f_934:csc_scm",(void*)f_934},
{"f_937:csc_scm",(void*)f_937},
{"f_940:csc_scm",(void*)f_940},
{"f_3737:csc_scm",(void*)f_3737},
{"f_3733:csc_scm",(void*)f_3733},
{"f_3729:csc_scm",(void*)f_3729},
{"f_3725:csc_scm",(void*)f_3725},
{"f_3721:csc_scm",(void*)f_3721},
{"f_956:csc_scm",(void*)f_956},
{"f_973:csc_scm",(void*)f_973},
{"f_977:csc_scm",(void*)f_977},
{"f_3705:csc_scm",(void*)f_3705},
{"f_3701:csc_scm",(void*)f_3701},
{"f_1012:csc_scm",(void*)f_1012},
{"f_3687:csc_scm",(void*)f_3687},
{"f_3691:csc_scm",(void*)f_3691},
{"f_3683:csc_scm",(void*)f_3683},
{"f_3679:csc_scm",(void*)f_3679},
{"f_1016:csc_scm",(void*)f_1016},
{"f_3669:csc_scm",(void*)f_3669},
{"f_1020:csc_scm",(void*)f_1020},
{"f_3659:csc_scm",(void*)f_3659},
{"f_1024:csc_scm",(void*)f_1024},
{"f_3646:csc_scm",(void*)f_3646},
{"f_1028:csc_scm",(void*)f_1028},
{"f_3633:csc_scm",(void*)f_3633},
{"f_1032:csc_scm",(void*)f_1032},
{"f_1064:csc_scm",(void*)f_1064},
{"f_1068:csc_scm",(void*)f_1068},
{"f_3612:csc_scm",(void*)f_3612},
{"f_1073:csc_scm",(void*)f_1073},
{"f_3602:csc_scm",(void*)f_3602},
{"f_1078:csc_scm",(void*)f_1078},
{"f_1104:csc_scm",(void*)f_1104},
{"f_1108:csc_scm",(void*)f_1108},
{"f_3576:csc_scm",(void*)f_3576},
{"f_3580:csc_scm",(void*)f_3580},
{"f_3572:csc_scm",(void*)f_3572},
{"f_3568:csc_scm",(void*)f_3568},
{"f_3564:csc_scm",(void*)f_3564},
{"f_3560:csc_scm",(void*)f_3560},
{"f_1116:csc_scm",(void*)f_1116},
{"f_3543:csc_scm",(void*)f_3543},
{"f_3547:csc_scm",(void*)f_3547},
{"f_3539:csc_scm",(void*)f_3539},
{"f_3535:csc_scm",(void*)f_3535},
{"f_3531:csc_scm",(void*)f_3531},
{"f_3527:csc_scm",(void*)f_3527},
{"f_1124:csc_scm",(void*)f_1124},
{"f_3514:csc_scm",(void*)f_3514},
{"f_1133:csc_scm",(void*)f_1133},
{"f_3503:csc_scm",(void*)f_3503},
{"f_3499:csc_scm",(void*)f_3499},
{"f_1141:csc_scm",(void*)f_1141},
{"f_3486:csc_scm",(void*)f_3486},
{"f_1149:csc_scm",(void*)f_1149},
{"f_3479:csc_scm",(void*)f_3479},
{"f_3453:csc_scm",(void*)f_3453},
{"f_3469:csc_scm",(void*)f_3469},
{"f_3465:csc_scm",(void*)f_3465},
{"f_3461:csc_scm",(void*)f_3461},
{"f_3457:csc_scm",(void*)f_3457},
{"f_3446:csc_scm",(void*)f_3446},
{"f_3442:csc_scm",(void*)f_3442},
{"f_3432:csc_scm",(void*)f_3432},
{"f_3428:csc_scm",(void*)f_3428},
{"f_1154:csc_scm",(void*)f_1154},
{"f_3415:csc_scm",(void*)f_3415},
{"f_3411:csc_scm",(void*)f_3411},
{"f_3407:csc_scm",(void*)f_3407},
{"f_1252:csc_scm",(void*)f_1252},
{"f_1450:csc_scm",(void*)f_1450},
{"f_2001:csc_scm",(void*)f_2001},
{"f_2242:csc_scm",(void*)f_2242},
{"f_2245:csc_scm",(void*)f_2245},
{"f_2248:csc_scm",(void*)f_2248},
{"f_2630:csc_scm",(void*)f_2630},
{"f_2299:csc_scm",(void*)f_2299},
{"f_2308:csc_scm",(void*)f_2308},
{"f_2485:csc_scm",(void*)f_2485},
{"f_2593:csc_scm",(void*)f_2593},
{"f_2599:csc_scm",(void*)f_2599},
{"f_2496:csc_scm",(void*)f_2496},
{"f_2507:csc_scm",(void*)f_2507},
{"f_2583:csc_scm",(void*)f_2583},
{"f_2575:csc_scm",(void*)f_2575},
{"f_2558:csc_scm",(void*)f_2558},
{"f_2534:csc_scm",(void*)f_2534},
{"f_2539:csc_scm",(void*)f_2539},
{"f_2521:csc_scm",(void*)f_2521},
{"f_2490:csc_scm",(void*)f_2490},
{"f_2455:csc_scm",(void*)f_2455},
{"f_2386:csc_scm",(void*)f_2386},
{"f_2438:csc_scm",(void*)f_2438},
{"f_2434:csc_scm",(void*)f_2434},
{"f_2419:csc_scm",(void*)f_2419},
{"f_2417:csc_scm",(void*)f_2417},
{"f_2413:csc_scm",(void*)f_2413},
{"f_2390:csc_scm",(void*)f_2390},
{"f_2376:csc_scm",(void*)f_2376},
{"f_2363:csc_scm",(void*)f_2363},
{"f_2346:csc_scm",(void*)f_2346},
{"f_2332:csc_scm",(void*)f_2332},
{"f_2318:csc_scm",(void*)f_2318},
{"f_2280:csc_scm",(void*)f_2280},
{"f_2286:csc_scm",(void*)f_2286},
{"f_2289:csc_scm",(void*)f_2289},
{"f_2235:csc_scm",(void*)f_2235},
{"f_2239:csc_scm",(void*)f_2239},
{"f_2189:csc_scm",(void*)f_2189},
{"f_2219:csc_scm",(void*)f_2219},
{"f_2211:csc_scm",(void*)f_2211},
{"f_2199:csc_scm",(void*)f_2199},
{"f_2178:csc_scm",(void*)f_2178},
{"f_2153:csc_scm",(void*)f_2153},
{"f_2165:csc_scm",(void*)f_2165},
{"f_2157:csc_scm",(void*)f_2157},
{"f_2140:csc_scm",(void*)f_2140},
{"f_2114:csc_scm",(void*)f_2114},
{"f_2126:csc_scm",(void*)f_2126},
{"f_2118:csc_scm",(void*)f_2118},
{"f_2093:csc_scm",(void*)f_2093},
{"f_2097:csc_scm",(void*)f_2097},
{"f_2076:csc_scm",(void*)f_2076},
{"f_2059:csc_scm",(void*)f_2059},
{"f_2042:csc_scm",(void*)f_2042},
{"f_2025:csc_scm",(void*)f_2025},
{"f_1984:csc_scm",(void*)f_1984},
{"f_1974:csc_scm",(void*)f_1974},
{"f_1964:csc_scm",(void*)f_1964},
{"f_1954:csc_scm",(void*)f_1954},
{"f_1944:csc_scm",(void*)f_1944},
{"f_1934:csc_scm",(void*)f_1934},
{"f_1924:csc_scm",(void*)f_1924},
{"f_1903:csc_scm",(void*)f_1903},
{"f_1879:csc_scm",(void*)f_1879},
{"f_1890:csc_scm",(void*)f_1890},
{"f_1882:csc_scm",(void*)f_1882},
{"f_1866:csc_scm",(void*)f_1866},
{"f_1855:csc_scm",(void*)f_1855},
{"f_1815:csc_scm",(void*)f_1815},
{"f_1819:csc_scm",(void*)f_1819},
{"f_1822:csc_scm",(void*)f_1822},
{"f_1783:csc_scm",(void*)f_1783},
{"f_1787:csc_scm",(void*)f_1787},
{"f_1790:csc_scm",(void*)f_1790},
{"f_1676:csc_scm",(void*)f_1676},
{"f_1694:csc_scm",(void*)f_1694},
{"f_1679:csc_scm",(void*)f_1679},
{"f_1639:csc_scm",(void*)f_1639},
{"f_1624:csc_scm",(void*)f_1624},
{"f_1630:csc_scm",(void*)f_1630},
{"f_1604:csc_scm",(void*)f_1604},
{"f_1592:csc_scm",(void*)f_1592},
{"f_1580:csc_scm",(void*)f_1580},
{"f_1568:csc_scm",(void*)f_1568},
{"f_1542:csc_scm",(void*)f_1542},
{"f_1531:csc_scm",(void*)f_1531},
{"f_1500:csc_scm",(void*)f_1500},
{"f_1493:csc_scm",(void*)f_1493},
{"f_1484:csc_scm",(void*)f_1484},
{"f_1477:csc_scm",(void*)f_1477},
{"f_1465:csc_scm",(void*)f_1465},
{"f_1453:csc_scm",(void*)f_1453},
{"f_1263:csc_scm",(void*)f_1263},
{"f_1267:csc_scm",(void*)f_1267},
{"f_1441:csc_scm",(void*)f_1441},
{"f_1408:csc_scm",(void*)f_1408},
{"f_1434:csc_scm",(void*)f_1434},
{"f_1411:csc_scm",(void*)f_1411},
{"f_1427:csc_scm",(void*)f_1427},
{"f_1414:csc_scm",(void*)f_1414},
{"f_1417:csc_scm",(void*)f_1417},
{"f_1270:csc_scm",(void*)f_1270},
{"f_1371:csc_scm",(void*)f_1371},
{"f_1381:csc_scm",(void*)f_1381},
{"f_1374:csc_scm",(void*)f_1374},
{"f_2708:csc_scm",(void*)f_2708},
{"f_2712:csc_scm",(void*)f_2712},
{"f_2753:csc_scm",(void*)f_2753},
{"f_2780:csc_scm",(void*)f_2780},
{"f_2761:csc_scm",(void*)f_2761},
{"f_2769:csc_scm",(void*)f_2769},
{"f_2765:csc_scm",(void*)f_2765},
{"f_2757:csc_scm",(void*)f_2757},
{"f_2749:csc_scm",(void*)f_2749},
{"f_2745:csc_scm",(void*)f_2745},
{"f_2741:csc_scm",(void*)f_2741},
{"f_2715:csc_scm",(void*)f_2715},
{"f_2719:csc_scm",(void*)f_2719},
{"f_2723:csc_scm",(void*)f_2723},
{"f_2700:csc_scm",(void*)f_2700},
{"f_1333:csc_scm",(void*)f_1333},
{"f_1336:csc_scm",(void*)f_1336},
{"f_1343:csc_scm",(void*)f_1343},
{"f_1273:csc_scm",(void*)f_1273},
{"f_2820:csc_scm",(void*)f_2820},
{"f_2824:csc_scm",(void*)f_2824},
{"f_2861:csc_scm",(void*)f_2861},
{"f_2873:csc_scm",(void*)f_2873},
{"f_2865:csc_scm",(void*)f_2865},
{"f_2869:csc_scm",(void*)f_2869},
{"f_2849:csc_scm",(void*)f_2849},
{"f_2845:csc_scm",(void*)f_2845},
{"f_2827:csc_scm",(void*)f_2827},
{"f_2804:csc_scm",(void*)f_2804},
{"f_2818:csc_scm",(void*)f_2818},
{"f_2808:csc_scm",(void*)f_2808},
{"f_1279:csc_scm",(void*)f_1279},
{"f_1294:csc_scm",(void*)f_1294},
{"f_1319:csc_scm",(void*)f_1319},
{"f_1327:csc_scm",(void*)f_1327},
{"f_1323:csc_scm",(void*)f_1323},
{"f_1311:csc_scm",(void*)f_1311},
{"f_1307:csc_scm",(void*)f_1307},
{"f_1285:csc_scm",(void*)f_1285},
{"f_3021:csc_scm",(void*)f_3021},
{"f_3015:csc_scm",(void*)f_3015},
{"f_3013:csc_scm",(void*)f_3013},
{"f_3009:csc_scm",(void*)f_3009},
{"f_2900:csc_scm",(void*)f_2900},
{"f_2903:csc_scm",(void*)f_2903},
{"f_2997:csc_scm",(void*)f_2997},
{"f_3001:csc_scm",(void*)f_3001},
{"f_3005:csc_scm",(void*)f_3005},
{"f_2989:csc_scm",(void*)f_2989},
{"f_2981:csc_scm",(void*)f_2981},
{"f_2977:csc_scm",(void*)f_2977},
{"f_2973:csc_scm",(void*)f_2973},
{"f_2906:csc_scm",(void*)f_2906},
{"f_2918:csc_scm",(void*)f_2918},
{"f_2951:csc_scm",(void*)f_2951},
{"f_2947:csc_scm",(void*)f_2947},
{"f_2943:csc_scm",(void*)f_2943},
{"f_2939:csc_scm",(void*)f_2939},
{"f_2935:csc_scm",(void*)f_2935},
{"f_2931:csc_scm",(void*)f_2931},
{"f_2909:csc_scm",(void*)f_2909},
{"f_1223:csc_scm",(void*)f_1223},
{"f_1228:csc_scm",(void*)f_1228},
{"f_1232:csc_scm",(void*)f_1232},
{"f_1184:csc_scm",(void*)f_1184},
{"f_1202:csc_scm",(void*)f_1202},
{"f_1177:csc_scm",(void*)f_1177},
{"f_1182:csc_scm",(void*)f_1182},
{"f_3397:csc_scm",(void*)f_3397},
{"f_3403:csc_scm",(void*)f_3403},
{"f_3400:csc_scm",(void*)f_3400},
{"f_3381:csc_scm",(void*)f_3381},
{"f_3385:csc_scm",(void*)f_3385},
{"f_3350:csc_scm",(void*)f_3350},
{"f_3354:csc_scm",(void*)f_3354},
{"f_3357:csc_scm",(void*)f_3357},
{"f_3361:csc_scm",(void*)f_3361},
{"f_3364:csc_scm",(void*)f_3364},
{"f_3325:csc_scm",(void*)f_3325},
{"f_3337:csc_scm",(void*)f_3337},
{"f_3332:csc_scm",(void*)f_3332},
{"f_3276:csc_scm",(void*)f_3276},
{"f_3278:csc_scm",(void*)f_3278},
{"f_3308:csc_scm",(void*)f_3308},
{"f_3315:csc_scm",(void*)f_3315},
{"f_3301:csc_scm",(void*)f_3301},
{"f_3272:csc_scm",(void*)f_3272},
{"f_3258:csc_scm",(void*)f_3258},
{"f_3268:csc_scm",(void*)f_3268},
{"f_3176:csc_scm",(void*)f_3176},
{"f_3180:csc_scm",(void*)f_3180},
{"f_3228:csc_scm",(void*)f_3228},
{"f_3222:csc_scm",(void*)f_3222},
{"f_3191:csc_scm",(void*)f_3191},
{"f_3187:csc_scm",(void*)f_3187},
{"f_3124:csc_scm",(void*)f_3124},
{"f_3170:csc_scm",(void*)f_3170},
{"f_3164:csc_scm",(void*)f_3164},
{"f_3162:csc_scm",(void*)f_3162},
{"f_3158:csc_scm",(void*)f_3158},
{"f_3132:csc_scm",(void*)f_3132},
{"f_3027:csc_scm",(void*)f_3027},
{"f_3031:csc_scm",(void*)f_3031},
{"f_3042:csc_scm",(void*)f_3042},
{"f_3063:csc_scm",(void*)f_3063},
{"f_3101:csc_scm",(void*)f_3101},
{"f_3083:csc_scm",(void*)f_3083},
{"f_3087:csc_scm",(void*)f_3087},
{"f_3056:csc_scm",(void*)f_3056},
{"f_3060:csc_scm",(void*)f_3060},
{"f_2875:csc_scm",(void*)f_2875},
{"f_2887:csc_scm",(void*)f_2887},
{"f_2883:csc_scm",(void*)f_2883},
{"f_1000:csc_scm",(void*)f_1000},
{"f_1008:csc_scm",(void*)f_1008},
{"f_987:csc_scm",(void*)f_987},
{"f_958:csc_scm",(void*)f_958},
{"f_969:csc_scm",(void*)f_969},
{"f_962:csc_scm",(void*)f_962},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
