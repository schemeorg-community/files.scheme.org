/* Generated from setup-download.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:28
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: setup-download.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature chicken-compile-shared -dynamic -emit-import-library setup-download -ignore-repository -output-file setup-download.c
   used units: library eval data_structures ports extras srfi_69 extras regex posix utils srfi_1 data_structures tcp srfi_13 files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[180];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,34),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,100,32,102,115,116,114,49,57,48,32,97,114,103,115,49,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,40),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,103,101,116,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,57),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,101,120,105,115,116,105,110,103,45,118,101,114,115,105,111,110,32,101,103,103,50,48,56,32,118,101,114,115,105,111,110,50,48,57,32,118,115,50,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,63),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,119,104,101,110,45,110,111,45,115,117,99,104,45,118,101,114,115,105,111,110,45,119,97,114,110,105,110,103,32,101,103,103,50,49,55,32,118,101,114,115,105,111,110,50,49,56,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,20),40,98,111,100,121,50,53,50,32,118,101,114,115,105,111,110,50,54,50,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,100,101,115,116,105,110,97,116,105,111,110,50,53,53,32,37,118,101,114,115,105,111,110,50,53,48,50,56,52,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,118,101,114,115,105,111,110,50,53,52,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,59),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,108,111,99,97,108,32,101,103,103,50,52,49,32,100,105,114,50,52,50,32,46,32,116,109,112,50,52,48,50,52,51,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,7),40,97,49,50,51,53,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,7),40,97,49,50,57,51,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,13),40,97,49,50,56,55,32,101,120,51,51,49,41,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,7),40,97,49,51,48,56,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,7),40,97,49,51,50,48,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,20),40,97,49,51,49,52,32,46,32,97,114,103,115,51,50,53,51,51,55,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,7),40,97,49,51,48,50,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,15),40,97,49,50,56,49,32,107,51,50,52,51,50,57,41,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,17),40,97,49,50,53,54,32,114,101,116,117,114,110,51,50,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,37),40,97,49,50,52,49,32,108,111,99,51,48,54,51,48,55,51,49,50,32,118,101,114,115,105,111,110,51,48,56,51,48,57,51,49,51,41,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,14),40,97,49,50,50,57,32,101,103,103,51,48,51,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,103,97,116,104,101,114,45,101,103,103,45,105,110,102,111,114,109,97,116,105,111,110,32,100,105,114,50,57,57,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,66),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,109,97,107,101,45,115,118,110,45,108,115,45,99,109,100,32,117,97,114,103,51,52,55,32,112,97,114,103,51,52,56,32,112,110,97,109,51,52,57,32,116,109,112,51,52,54,51,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,97,49,52,55,53,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,37),40,97,49,53,48,51,32,102,105,108,101,100,105,114,52,55,52,52,55,53,52,56,49,32,118,101,114,52,55,54,52,55,55,52,56,50,41,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,12),40,97,49,53,52,54,32,102,52,54,52,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,59),40,98,111,100,121,52,51,53,32,118,101,114,115,105,111,110,52,52,55,32,100,101,115,116,105,110,97,116,105,111,110,52,52,56,32,117,115,101,114,110,97,109,101,52,52,57,32,112,97,115,115,119,111,114,100,52,53,48,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,67),40,100,101,102,45,112,97,115,115,119,111,114,100,52,52,48,32,37,118,101,114,115,105,111,110,52,51,49,53,48,51,32,37,100,101,115,116,105,110,97,116,105,111,110,52,51,50,53,48,52,32,37,117,115,101,114,110,97,109,101,52,51,51,53,48,53,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,51),40,100,101,102,45,117,115,101,114,110,97,109,101,52,51,57,32,37,118,101,114,115,105,111,110,52,51,49,53,48,57,32,37,100,101,115,116,105,110,97,116,105,111,110,52,51,50,53,49,48,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,100,101,115,116,105,110,97,116,105,111,110,52,51,56,32,37,118,101,114,115,105,111,110,52,51,49,53,49,52,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,118,101,114,115,105,111,110,52,51,55,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,115,118,110,32,101,103,103,52,50,50,32,114,101,112,111,52,50,51,32,46,32,116,109,112,52,50,49,52,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,7),40,97,49,55,50,49,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,49,57,51,51,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,7),40,97,50,48,55,54,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,20),40,103,101,116,45,102,105,108,101,115,32,102,105,108,101,115,55,51,56,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,20),40,103,101,116,45,99,104,117,110,107,115,32,100,97,116,97,55,57,54,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,7),40,97,49,56,55,55,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,7),40,97,49,56,56,48,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,7),40,97,49,56,56,51,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,7),40,97,49,56,56,54,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,32),40,97,49,57,51,57,32,105,110,54,57,51,54,57,52,54,57,56,32,111,117,116,54,57,53,54,57,54,54,57,57,41};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,49),40,97,49,55,50,55,32,104,111,115,116,53,56,57,53,57,48,53,57,55,32,112,111,114,116,53,57,49,53,57,50,53,57,56,32,108,111,99,110,53,57,51,53,57,52,53,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,44),40,98,111,100,121,53,54,53,32,118,101,114,115,105,111,110,53,55,54,32,100,101,115,116,105,110,97,116,105,111,110,53,55,55,32,116,101,115,116,115,53,55,56,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,48),40,100,101,102,45,116,101,115,116,115,53,54,57,32,37,118,101,114,115,105,111,110,53,54,50,54,50,48,32,37,100,101,115,116,105,110,97,116,105,111,110,53,54,51,54,50,49,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,100,101,115,116,105,110,97,116,105,111,110,53,54,56,32,37,118,101,114,115,105,111,110,53,54,50,54,50,53,41,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,118,101,114,115,105,111,110,53,54,55,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,104,116,116,112,32,101,103,103,53,53,51,32,117,114,108,53,53,52,32,46,32,116,109,112,53,53,50,53,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,50,50,51,49,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,7),40,97,50,50,51,54,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,50,50,55,53,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,80),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,114,101,116,114,105,101,118,101,45,101,120,116,101,110,115,105,111,110,32,110,97,109,101,56,49,50,32,116,114,97,110,115,112,111,114,116,56,49,51,32,108,111,99,97,116,105,111,110,56,49,52,32,46,32,116,109,112,56,49,49,56,49,53,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,7),40,97,50,50,57,53,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,18),40,97,49,48,57,52,32,103,50,51,48,50,51,49,50,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,12),40,97,49,51,55,55,32,115,51,57,55,41,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,33),40,98,111,100,121,51,55,57,32,117,115,101,114,110,97,109,101,51,56,57,32,112,97,115,115,119,111,114,100,51,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,112,97,115,115,119,111,114,100,51,56,50,32,37,117,115,101,114,110,97,109,101,51,55,55,52,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,117,115,101,114,110,97,109,101,51,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,50,51,48,48,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,7),40,97,50,51,50,52,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,69),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,105,115,116,45,101,120,116,101,110,115,105,111,110,115,32,116,114,97,110,115,112,111,114,116,56,54,52,32,108,111,99,97,116,105,111,110,56,54,53,32,46,32,116,109,112,56,54,51,56,54,54,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_954)
static void C_ccall f_954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_957)
static void C_ccall f_957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_960)
static void C_ccall f_960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_966)
static void C_ccall f_966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_969)
static void C_ccall f_969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_972)
static void C_ccall f_972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_978)
static void C_ccall f_978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_981)
static void C_ccall f_981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_984)
static void C_ccall f_984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_987)
static void C_ccall f_987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_990)
static void C_ccall f_990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_993)
static void C_ccall f_993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_996)
static void C_ccall f_996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1005)
static void C_ccall f_1005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1032)
static void C_ccall f_1032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1402)
static void C_fcall f_1402(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1397)
static void C_fcall f_1397(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1356)
static void C_fcall f_1356(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1360)
static void C_ccall f_1360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1363)
static void C_ccall f_1363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1366)
static void C_ccall f_1366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1103)
static void C_ccall f_1103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1095)
static void C_ccall f_1095(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1093)
static void C_ccall f_1093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1779)
static void C_fcall f_1779(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_fcall f_1774(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1769)
static void C_fcall f_1769(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1713)
static void C_fcall f_1713(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1738)
static void C_ccall f_1738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_fcall f_2139(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1965)
static void C_ccall f_1965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_fcall f_2113(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2135)
static void C_ccall f_2135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2126)
static void C_fcall f_2126(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2101)
static void C_ccall f_2101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_fcall f_2176(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2206)
static void C_ccall f_2206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1971)
static void C_fcall f_1971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1979)
static void C_fcall f_1979(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1983)
static void C_ccall f_1983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1989)
static void C_fcall f_1989(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1665)
static void C_ccall f_1665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1583)
static void C_fcall f_1583(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_fcall f_1578(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1573)
static void C_fcall f_1573(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1568)
static void C_fcall f_1568(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1452)
static void C_fcall f_1452(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1561)
static void C_ccall f_1561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1547)
static void C_ccall f_1547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1545)
static void C_ccall f_1545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1534)
static void C_ccall f_1534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_ccall f_1511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1514)
static void C_ccall f_1514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1476)
static void C_ccall f_1476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_fcall f_1327(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1331)
static void C_ccall f_1331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1221)
static void C_ccall f_1221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1225)
static void C_ccall f_1225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1246)
static void C_ccall f_1246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1252)
static void C_ccall f_1252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1257)
static void C_ccall f_1257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1265)
static void C_ccall f_1265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1298)
static void C_ccall f_1298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1280)
static void C_ccall f_1280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1105)
static void C_ccall f_1105(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1105)
static void C_ccall f_1105r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1173)
static void C_fcall f_1173(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1168)
static void C_fcall f_1168(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1107)
static void C_fcall f_1107(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1154)
static void C_ccall f_1154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1160)
static void C_ccall f_1160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1167)
static void C_ccall f_1167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1130)
static void C_ccall f_1130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1148)
static void C_ccall f_1148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1139)
static void C_ccall f_1139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1127)
static void C_ccall f_1127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1076)
static void C_fcall f_1076(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1049)
static void C_fcall f_1049(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1065)
static void C_ccall f_1065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1034)
static void C_fcall f_1034(C_word t0) C_noret;
C_noret_decl(f_1038)
static void C_ccall f_1038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1044)
static void C_ccall f_1044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1012)
static void C_fcall f_1012(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1019)
static void C_ccall f_1019(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1402)
static void C_fcall trf_1402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1402(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1402(t0,t1);}

C_noret_decl(trf_1397)
static void C_fcall trf_1397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1397(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1397(t0,t1,t2);}

C_noret_decl(trf_1356)
static void C_fcall trf_1356(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1356(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1356(t0,t1,t2,t3);}

C_noret_decl(trf_1779)
static void C_fcall trf_1779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1779(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1779(t0,t1);}

C_noret_decl(trf_1774)
static void C_fcall trf_1774(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1774(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1774(t0,t1,t2);}

C_noret_decl(trf_1769)
static void C_fcall trf_1769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1769(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1769(t0,t1,t2,t3);}

C_noret_decl(trf_1713)
static void C_fcall trf_1713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1713(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1713(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2139)
static void C_fcall trf_2139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2139(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2139(t0,t1);}

C_noret_decl(trf_2113)
static void C_fcall trf_2113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2113(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2113(t0,t1);}

C_noret_decl(trf_2126)
static void C_fcall trf_2126(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2126(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2126(t0,t1);}

C_noret_decl(trf_2176)
static void C_fcall trf_2176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2176(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2176(t0,t1,t2);}

C_noret_decl(trf_1971)
static void C_fcall trf_1971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1971(t0,t1);}

C_noret_decl(trf_1979)
static void C_fcall trf_1979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1979(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1979(t0,t1,t2);}

C_noret_decl(trf_1989)
static void C_fcall trf_1989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1989(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1989(t0,t1);}

C_noret_decl(trf_1583)
static void C_fcall trf_1583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1583(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1583(t0,t1);}

C_noret_decl(trf_1578)
static void C_fcall trf_1578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1578(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1578(t0,t1,t2);}

C_noret_decl(trf_1573)
static void C_fcall trf_1573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1573(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1573(t0,t1,t2,t3);}

C_noret_decl(trf_1568)
static void C_fcall trf_1568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1568(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1568(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1452)
static void C_fcall trf_1452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1452(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1452(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1327)
static void C_fcall trf_1327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1327(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1327(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1173)
static void C_fcall trf_1173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1173(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1173(t0,t1);}

C_noret_decl(trf_1168)
static void C_fcall trf_1168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1168(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1168(t0,t1,t2);}

C_noret_decl(trf_1107)
static void C_fcall trf_1107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1107(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1107(t0,t1,t2);}

C_noret_decl(trf_1076)
static void C_fcall trf_1076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1076(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1076(t0,t1,t2);}

C_noret_decl(trf_1049)
static void C_fcall trf_1049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1049(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1049(t0,t1,t2,t3);}

C_noret_decl(trf_1034)
static void C_fcall trf_1034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1034(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_1034(t0);}

C_noret_decl(trf_1012)
static void C_fcall trf_1012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1012(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1012(t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(850)){
C_save(t1);
C_rereclaim2(850*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,180);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[5]=C_h_intern(&lf[5],12,"flush-output");
lf[6]=C_h_intern(&lf[6],7,"fprintf");
lf[7]=C_h_intern(&lf[7],18,"current-error-port");
lf[8]=C_h_intern(&lf[8],19,"current-output-port");
lf[9]=C_h_intern(&lf[9],34,"setup-download#temporary-directory");
lf[11]=C_h_intern(&lf[11],36,"setup-api#create-temporary-directory");
lf[13]=C_h_intern(&lf[13],5,"error");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\021version not found");
lf[15]=C_h_intern(&lf[15],4,"sort");
lf[16]=C_h_intern(&lf[16],20,"setup-api#version>=\077");
lf[18]=C_h_intern(&lf[18],7,"warning");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000-extension has no such version - using default");
lf[20]=C_h_intern(&lf[20],31,"setup-download#locate-egg/local");
lf[21]=C_h_intern(&lf[21],13,"make-pathname");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[24]=C_h_intern(&lf[24],10,"directory\077");
lf[25]=C_h_intern(&lf[25],12,"file-exists\077");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[27]=C_h_intern(&lf[27],9,"directory");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\004tags");
lf[29]=C_h_intern(&lf[29],9,"\003syserror");
lf[30]=C_h_intern(&lf[30],37,"setup-download#gather-egg-information");
lf[31]=C_h_intern(&lf[31],7,"version");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000.extension has syntactically invalid .meta file");
lf[33]=C_h_intern(&lf[33],20,"with-input-from-file");
lf[34]=C_h_intern(&lf[34],4,"read");
lf[35]=C_h_intern(&lf[35],22,"with-exception-handler");
lf[36]=C_h_intern(&lf[36],30,"call-with-current-continuation");
lf[37]=C_h_intern(&lf[37],14,"string->symbol");
lf[38]=C_h_intern(&lf[38],7,"call/cc");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[40]=C_h_intern(&lf[40],10,"filter-map");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\004 -R ");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[44]=C_h_intern(&lf[44],4,"conc");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\007svn ls ");
lf[46]=C_h_intern(&lf[46],2,"qs");
lf[47]=C_h_intern(&lf[47],15,"\003sysget-keyword");
lf[48]=C_h_intern(&lf[48],11,"\000recursive\077");
lf[49]=C_h_intern(&lf[49],29,"setup-download#locate-egg/svn");
lf[50]=C_h_intern(&lf[50],13,"string-append");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\005tags/");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\006trunk/");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[58]=C_h_intern(&lf[58],6,"system");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\005 1>&2");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\013svn export ");
lf[63]=C_h_intern(&lf[63],13,"string-search");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\016^tags/([^/]+)/");
lf[65]=C_h_intern(&lf[65],20,"with-input-from-pipe");
lf[66]=C_h_intern(&lf[66],10,"read-lines");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\047checking available versions ...~%  ~a~%");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[74]=C_h_intern(&lf[74],30,"setup-download#locate-egg/http");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\020not a valid port");
lf[77]=C_h_intern(&lf[77],12,"string-match");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000#(http://)\077([^/:]+)(:([^:/]+))\077(/.+)");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[80]=C_h_intern(&lf[80],11,"tcp-connect");
lf[81]=C_h_intern(&lf[81],5,"abort");
lf[82]=C_h_intern(&lf[82],24,"make-composite-condition");
lf[83]=C_h_intern(&lf[83],23,"make-property-condition");
lf[84]=C_h_intern(&lf[84],20,"setup-download-error");
lf[85]=C_h_intern(&lf[85],3,"exn");
lf[86]=C_h_intern(&lf[86],7,"message");
lf[87]=C_h_intern(&lf[87],9,"arguments");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\011[Server] ");
lf[89]=C_h_intern(&lf[89],7,"reverse");
lf[90]=C_h_intern(&lf[90],17,"close-output-port");
lf[91]=C_h_intern(&lf[91],16,"close-input-port");
lf[92]=C_h_intern(&lf[92],16,"create-directory");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[94]=C_h_intern(&lf[94],7,"display");
lf[95]=C_h_intern(&lf[95],19,"with-output-to-file");
lf[96]=C_h_intern(&lf[96],20,"\003sysread-string/port");
lf[97]=C_h_intern(&lf[97],9,"read-line");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[99]=C_h_intern(&lf[99],14,"string-suffix\077");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\0001invalid file name - possibly corrupt transmission");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\023reading files ...~%");
lf[103]=C_h_intern(&lf[103],17,"open-input-string");
lf[104]=C_h_intern(&lf[104],26,"string-concatenate-reverse");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\024reading chunks ...~%");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~%");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000$[Tt]ransfer-[Ee]ncoding:\134s*chunked.*");
lf[108]=C_h_intern(&lf[108],12,"string-null\077");
lf[109]=C_h_intern(&lf[109],6,"signal");
lf[110]=C_h_intern(&lf[110],10,"http-fetch");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid response from server");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\003200");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~%");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\034HTTP/[0-9.]+\134s+([0-9]+)\134s+.*");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\026reading response ...~%");
lf[116]=C_h_intern(&lf[116],5,"\000port");
lf[117]=C_h_intern(&lf[117],7,"\000accept");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\003*/*");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\004GET ");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\011 HTTP/1.1");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\014Connection: ");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\014User-Agent: ");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\010Accept: ");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\006Host: ");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\020Content-length: ");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[133]=C_h_intern(&lf[133],15,"\000content-length");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\005close");
lf[136]=C_h_intern(&lf[136],11,"\000connection");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\023requesting ~s ...~%");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000$connecting to host ~s, port ~a ...~%");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\012&tests=yes");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\006\077name=");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\011&version=");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[144]=C_h_intern(&lf[144],33,"setup-download#retrieve-extension");
lf[145]=C_h_intern(&lf[145],5,"local");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000)destination for transport `local\047 ignored");
lf[147]=C_h_intern(&lf[147],3,"svn");
lf[148]=C_h_intern(&lf[148],4,"http");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000/cannot retrieve extension unsupported transport");
lf[150]=C_h_intern(&lf[150],16,"\003sysdynamic-wind");
lf[151]=C_h_intern(&lf[151],6,"\000tests");
lf[152]=C_h_intern(&lf[152],9,"\000password");
lf[153]=C_h_intern(&lf[153],9,"\000username");
lf[154]=C_h_intern(&lf[154],12,"\000destination");
lf[155]=C_h_intern(&lf[155],6,"\000quiet");
lf[156]=C_h_intern(&lf[156],8,"\000version");
lf[157]=C_h_intern(&lf[157],30,"setup-download#list-extensions");
lf[158]=C_h_intern(&lf[158],18,"string-concatenate");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[160]=C_h_intern(&lf[160],7,"\003sysmap");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[162]=C_h_intern(&lf[162],12,"string-chomp");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\047listing extension directory ...~%  ~a~%");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000.cannot list extensions - unsupported transport");
lf[172]=C_h_intern(&lf[172],14,"make-parameter");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-install ");
lf[174]=C_h_intern(&lf[174],15,"chicken-version");
lf[175]=C_h_intern(&lf[175],17,"tcp-write-timeout");
lf[176]=C_h_intern(&lf[176],16,"tcp-read-timeout");
lf[177]=C_h_intern(&lf[177],19,"tcp-connect-timeout");
lf[178]=C_h_intern(&lf[178],11,"\003sysrequire");
lf[179]=C_h_intern(&lf[179],9,"setup-api");
C_register_lf2(lf,180,create_ptable());
t2=C_mutate(&lf[0] /* (set! c297 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_951,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k949 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_954,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k952 in k949 */
static void C_ccall f_954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_957,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k955 in k952 in k949 */
static void C_ccall f_957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_960,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k958 in k955 in k952 in k949 */
static void C_ccall f_960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_963,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_966,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_969,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_972,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_975,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_978,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_981,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_984,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_987,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_990,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_993,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_996,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[178]))(3,*((C_word*)lf[178]+1),t2,lf[179]);}

/* k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_999,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 45   tcp-connect-timeout */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t2,C_fix(10000));}

/* k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1002,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 46   tcp-read-timeout */
((C_proc3)C_retrieve_symbol_proc(lf[176]))(3,*((C_word*)lf[176]+1),t2,C_fix(20000));}

/* k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1005,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 47   tcp-write-timeout */
((C_proc3)C_retrieve_symbol_proc(lf[175]))(3,*((C_word*)lf[175]+1),t2,C_fix(20000));}

/* k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1005,2,t0,t1);}
t2=lf[2] /* setup-download#*quiet* */ =C_SCHEME_FALSE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1010,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2332,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 51   chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[174]))(2,*((C_word*)lf[174]+1),t4);}

/* k2330 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 51   conc */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[173],t1);}

/* k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1010,2,t0,t1);}
t2=C_mutate(&lf[3] /* (set! setup-download#*chicken-install-user-agent* ...) */,t1);
t3=C_mutate(&lf[4] /* (set! setup-download#d ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1012,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1032,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 58   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t4,C_SCHEME_FALSE);}

/* k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1032,2,t0,t1);}
t2=C_mutate((C_word*)lf[9]+1 /* (set! setup-download#temporary-directory ...) */,t1);
t3=C_mutate(&lf[10] /* (set! setup-download#get-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1034,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[12] /* (set! setup-download#existing-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1049,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[17] /* (set! setup-download#when-no-such-version-warning ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1076,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[20]+1 /* (set! setup-download#locate-egg/local ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1105,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[30]+1 /* (set! setup-download#gather-egg-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1221,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[41] /* (set! setup-download#make-svn-ls-cmd ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1327,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[49]+1 /* (set! setup-download#locate-egg/svn ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1450,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[74]+1 /* (set! setup-download#locate-egg/http ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1711,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[144]+1 /* (set! setup-download#retrieve-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2208,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[157]+1 /* (set! setup-download#list-extensions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2281,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}

/* setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2281r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2281r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2281r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2285,a[2]=t4,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t5,lf[155],t4);}

/* k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[153],((C_word*)t0)[2]);}

/* k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2291,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[152],((C_word*)t0)[2]);}

/* k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2291,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2296,a[2]=t3,a[3]=t5,a[4]=((C_word)li51),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2301,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li57),tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2325,a[2]=t5,a[3]=t3,a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[150]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a2324 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2325,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2300 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[18],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2301,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=(C_word)C_eqp(t2,lf[145]);
if(C_truep(t3)){
t4=t1;
t5=((C_word*)t0)[4];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1093,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1095,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1103,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 79   directory */
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t8,t5);}
else{
t4=(C_word)C_eqp(t2,lf[147]);
if(C_truep(t4)){
t5=t1;
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1356,a[2]=t6,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1397,a[2]=t8,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1402,a[2]=t9,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-username381405 */
t11=t10;
f_1402(t11,t5);}
else{
t11=(C_word)C_i_car(t7);
t12=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-password382401 */
t13=t9;
f_1397(t13,t5,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body379388 */
t15=t8;
f_1356(t15,t5,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t5,lf[0],t14);}}}}
else{
/* setup-download.scm: 303  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t1,lf[171],((C_word*)t0)[5]);}}}

/* def-username381 in a2300 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1402(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1402,NULL,2,t0,t1);}
/* def-password382401 */
t2=((C_word*)t0)[2];
f_1397(t2,t1,C_SCHEME_FALSE);}

/* def-password382 in a2300 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1397(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1397,NULL,3,t0,t1,t2);}
/* body379388 */
t3=((C_word*)t0)[2];
f_1356(t3,t1,t2,C_SCHEME_FALSE);}

/* body379 in a2300 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1356(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1356,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1360,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
/* setup-download.scm: 120  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t4,lf[168],t2,lf[169]);}
else{
t5=t4;
f_1360(2,t5,lf[170]);}}

/* k1358 in body379 in a2300 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1363,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* setup-download.scm: 121  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t2,lf[165],((C_word*)t0)[2],lf[166]);}
else{
t3=t2;
f_1363(2,t3,lf[167]);}}

/* k1361 in k1358 in body379 in a2300 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1366,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 122  make-svn-ls-cmd */
f_1327(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1364 in k1361 in k1358 in body379 in a2300 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1369,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 123  d */
f_1012(t2,lf[164],(C_word)C_a_i_list(&a,1,t1));}

/* k1367 in k1364 in k1361 in k1358 in body379 in a2300 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1376,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1378,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1390,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 126  with-input-from-pipe */
((C_proc4)C_retrieve_symbol_proc(lf[65]))(4,*((C_word*)lf[65]+1),t4,((C_word*)t0)[2],C_retrieve(lf[66]));}

/* k1388 in k1367 in k1364 in k1361 in k1358 in body379 in a2300 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1377 in k1367 in k1364 in k1361 in k1358 in body379 in a2300 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1378,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1386,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 125  string-chomp */
((C_proc4)C_retrieve_symbol_proc(lf[162]))(4,*((C_word*)lf[162]+1),t3,t2,lf[163]);}

/* k1384 in a1377 in k1367 in k1364 in k1361 in k1358 in body379 in a2300 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 125  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),((C_word*)t0)[2],t1,lf[161]);}

/* k1374 in k1367 in k1364 in k1361 in k1358 in body379 in a2300 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 124  string-concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[158]))(3,*((C_word*)lf[158]+1),((C_word*)t0)[2],t1);}

/* k1101 in a2300 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1094 in a2300 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1095(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1095,3,t0,t1,t2);}
/* string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t1,t2,lf[159]);}

/* k1091 in a2300 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 79   string-concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[158]))(3,*((C_word*)lf[158]+1),((C_word*)t0)[2],t1);}

/* a2295 in k2289 in k2286 in k2283 in setup-download#list-extensions in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2296,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* setup-download#retrieve-extension in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_2208r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2208r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2208r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2212,a[2]=t5,a[3]=t1,a[4]=t4,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t6,lf[156],t5);}

/* k2210 in setup-download#retrieve-extension in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[155],((C_word*)t0)[2]);}

/* k2213 in k2210 in setup-download#retrieve-extension in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2218,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[154],((C_word*)t0)[2]);}

/* k2216 in k2213 in k2210 in setup-download#retrieve-extension in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[153],((C_word*)t0)[2]);}

/* k2219 in k2216 in k2213 in k2210 in setup-download#retrieve-extension in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[152],((C_word*)t0)[2]);}

/* k2222 in k2219 in k2216 in k2213 in k2210 in setup-download#retrieve-extension in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2227,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[151],((C_word*)t0)[2]);}

/* k2225 in k2222 in k2219 in k2216 in k2213 in k2210 in setup-download#retrieve-extension in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2227,2,t0,t1);}
t2=((C_word*)t0)[10];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2232,a[2]=t3,a[3]=t5,a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2237,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li48),tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2276,a[2]=t5,a[3]=t3,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[150]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a2275 in k2225 in k2222 in k2219 in k2216 in k2213 in k2210 in setup-download#retrieve-extension in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2276,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2236 in k2225 in k2222 in k2219 in k2216 in k2213 in k2210 in setup-download#retrieve-extension in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2237,2,t0,t1);}
t2=((C_word*)t0)[9];
t3=(C_word)C_eqp(t2,lf[145]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2247,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
/* setup-download.scm: 286  warning */
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t4,lf[146]);}
else{
t5=t4;
f_2247(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_eqp(t2,lf[147]);
if(C_truep(t4)){
/* setup-download.scm: 289  locate-egg/svn */
((C_proc8)C_retrieve_symbol_proc(lf[49]))(8,*((C_word*)lf[49]+1),t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t5=(C_word)C_eqp(t2,lf[148]);
if(C_truep(t5)){
/* setup-download.scm: 291  locate-egg/http */
((C_proc7)C_retrieve_symbol_proc(lf[74]))(7,*((C_word*)lf[74]+1),t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
/* setup-download.scm: 293  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t1,lf[149],((C_word*)t0)[9]);}}}}

/* k2245 in a2236 in k2225 in k2222 in k2219 in k2216 in k2213 in k2210 in setup-download#retrieve-extension in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 287  locate-egg/local */
((C_proc6)C_retrieve_symbol_proc(lf[20]))(6,*((C_word*)lf[20]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2231 in k2225 in k2222 in k2219 in k2216 in k2213 in k2210 in setup-download#retrieve-extension in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2232,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_1711r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1711r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1711r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1713,a[2]=t2,a[3]=t3,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1769,a[2]=t5,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1774,a[2]=t6,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1779,a[2]=t7,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-version567628 */
t9=t8;
f_1779(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-destination568624 */
t11=t7;
f_1774(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-tests569619 */
t13=t6;
f_1769(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body565575 */
t15=t5;
f_1713(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-version567 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1779(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1779,NULL,2,t0,t1);}
/* def-destination568624 */
t2=((C_word*)t0)[2];
f_1774(t2,t1,C_SCHEME_FALSE);}

/* def-destination568 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1774(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1774,NULL,3,t0,t1,t2);}
/* def-tests569619 */
t3=((C_word*)t0)[2];
f_1769(t3,t1,t2,C_SCHEME_FALSE);}

/* def-tests569 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1769(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1769,NULL,4,t0,t1,t2,t3);}
/* body565575 */
t4=((C_word*)t0)[2];
f_1713(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1713(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1713,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1717,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t6=t5;
f_1717(2,t6,t3);}
else{
/* setup-download.scm: 165  get-temporary-directory */
f_1034(t5);}}

/* k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1722,a[2]=((C_word*)t0)[6],a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1728,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word)li41),tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1728,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1732,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1758,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
/* setup-download.scm: 170  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t6,lf[142],((C_word*)t0)[5]);}
else{
t7=t6;
f_1758(2,t7,lf[143]);}}

/* k1756 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?lf[139]:lf[140]);
/* setup-download.scm: 167  string-append */
((C_proc7)C_retrieve_proc(*((C_word*)lf[50]+1)))(7,*((C_word*)lf[50]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[141],((C_word*)t0)[2],t1,t2);}

/* k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1735,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* setup-download.scm: 172  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1751,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 173  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t3,t1);}

/* k1749 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1738(2,t2,C_SCHEME_UNDEFINED);}
else{
/* setup-download.scm: 173  create-directory */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1741,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
t6=((C_word*)t0)[5];
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1929,a[2]=t2,a[3]=t5,a[4]=t6,a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* setup-download.scm: 213  d */
f_1012(t7,lf[138],(C_word)C_a_i_list(&a,2,t3,t4));}

/* k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1934,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1940,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word)li40),tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1940,4,t0,t1,t2,t3);}
t4=t2;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t5,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* setup-download.scm: 215  d */
f_1012(t6,lf[137],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}

/* k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[31],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1947,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2146,a[2]=((C_word*)t0)[8],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,4,lf[116],((C_word*)t0)[4],lf[117],lf[118]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1864,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1887,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t5,lf[116],t4,t6);}

/* a1886 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1887,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(80));}

/* k1862 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1884,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t2,lf[136],((C_word*)t0)[2],t3);}

/* a1883 in k1862 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[135]);}

/* k1865 in k1862 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1881,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t2,lf[117],((C_word*)t0)[2],t3);}

/* a1880 in k1865 in k1862 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[134]);}

/* k1868 in k1865 in k1862 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1878,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t2,lf[133],((C_word*)t0)[2],t3);}

/* a1877 in k1868 in k1865 in k1862 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1878,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* k1871 in k1868 in k1865 in k1862 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 193  conc */
((C_proc24)C_retrieve_symbol_proc(lf[44]))(24,*((C_word*)lf[44]+1),((C_word*)t0)[7],lf[119],((C_word*)t0)[6],lf[120],lf[121],lf[122],((C_word*)t0)[5],lf[123],lf[124],C_retrieve2(lf[3],"setup-download#*chicken-install-user-agent*"),lf[125],lf[126],((C_word*)t0)[4],lf[127],lf[128],((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],lf[129],lf[130],t1,lf[131],lf[132]);}

/* k2144 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 216  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[94]+1)))(4,*((C_word*)lf[94]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 219  flush-output */
((C_proc3)C_retrieve_proc(*((C_word*)lf[5]+1)))(3,*((C_word*)lf[5]+1),t2,((C_word*)t0)[5]);}

/* k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 220  d */
f_1012(t2,lf[115],C_SCHEME_END_OF_LIST);}

/* k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1953,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1956,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* setup-download.scm: 222  read-line */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),t4,((C_word*)((C_word*)t0)[4])[1]);}

/* k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1959,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=t1;
if(C_truep((C_word)C_i_stringp(t3))){
/* setup-download.scm: 204  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t2,lf[114],t3);}
else{
t4=t2;
f_1959(2,t4,C_SCHEME_FALSE);}}

/* k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1962,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* setup-download.scm: 224  d */
f_1012(t2,lf[113],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1965,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t4);
t6=t3;
f_2139(t6,(C_word)C_i_string_equal_p(lf[112],t5));}
else{
t5=t3;
f_2139(t5,C_SCHEME_FALSE);}}

/* k2137 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_2139(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2139,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1965(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1850,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1854,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 181  make-property-condition */
((C_proc7)C_retrieve_symbol_proc(lf[83]))(7,*((C_word*)lf[83]+1),t4,lf[85],lf[86],lf[111],lf[87],t2);}}

/* k1852 in k2137 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1858,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 185  make-property-condition */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,lf[110]);}

/* k1856 in k1852 in k2137 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 180  make-composite-condition */
((C_proc4)C_retrieve_symbol_proc(lf[82]))(4,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1848 in k2137 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 179  signal */
((C_proc3)C_retrieve_symbol_proc(lf[109]))(3,*((C_word*)lf[109]+1),((C_word*)t0)[2],t1);}

/* k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word)li35),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2113(t6,t2);}

/* loop in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_2113(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2113,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2117,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 229  read-line */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2115 in loop in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2123,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 230  string-null? */
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),t2,t1);}

/* k2121 in k2115 in loop in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2123,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2126,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2135,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
/* setup-download.scm: 210  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t3,lf[107],t4);}}

/* k2133 in k2121 in k2115 in loop in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_2126(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_2126(t2,C_SCHEME_UNDEFINED);}}

/* k2124 in k2121 in k2115 in loop in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_2126(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2126,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2129,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 232  d */
f_1012(t2,lf[106],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* k2127 in k2124 in k2121 in k2115 in loop in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 233  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2113(t2,((C_word*)t0)[2]);}

/* k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2101,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 235  d */
f_1012(t3,lf[105],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1971(t3,C_SCHEME_UNDEFINED);}}

/* k2099 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2176,a[2]=t3,a[3]=t5,a[4]=((C_word)li34),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2176(t7,t2,C_SCHEME_END_OF_LIST);}

/* get-chunks in k2099 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_2176(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2176,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2206,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 274  read-line */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),t4,((C_word*)t0)[2]);}

/* k2204 in get-chunks in k2099 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 274  string->number */
C_string_to_number(4,0,((C_word*)t0)[2],t1,C_fix(16));}

/* k2178 in get-chunks in k2099 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2180,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* setup-download.scm: 276  string-concatenate-reverse */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* read-string/port */
t3=C_retrieve(lf[96]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}}

/* k2190 in k2178 in get-chunks in k2099 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 278  read-line */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),t2,((C_word*)t0)[2]);}

/* k2193 in k2190 in k2178 in get-chunks in k2099 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2195,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* setup-download.scm: 279  get-chunks */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2176(t3,((C_word*)t0)[2],t2);}

/* k2102 in k2099 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2107,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 237  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[91]+1)))(3,*((C_word*)lf[91]+1),t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k2105 in k2102 in k2099 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 238  open-input-string */
((C_proc3)C_retrieve_symbol_proc(lf[103]))(3,*((C_word*)lf[103]+1),t2,((C_word*)t0)[2]);}

/* k2109 in k2105 in k2102 in k2099 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1971(t3,t2);}

/* k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1971,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 239  d */
f_1012(t2,lf[102],C_SCHEME_END_OF_LIST);}

/* k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1974,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1979,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li33),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1979(t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1979(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1979,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* setup-download.scm: 241  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_car(t1);
t4=t2;
f_1989(t4,(C_word)C_eqp(lf[13],t3));}
else{
t3=t2;
f_1989(t3,C_SCHEME_FALSE);}}

/* k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1989(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1989,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_i_cddr(((C_word*)t0)[8]);
t4=((C_word*)t0)[7];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2156,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2160,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2168,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 268  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t7,lf[88],t2);}
else{
t2=(C_word)C_eofp(((C_word*)t0)[8]);
t3=(C_truep(t2)?t2:(C_word)C_i_not(((C_word*)t0)[8]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2012,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 245  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[91]+1)))(3,*((C_word*)lf[91]+1),t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[8]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2033,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* setup-download.scm: 250  string-suffix? */
((C_proc4)C_retrieve_symbol_proc(lf[99]))(4,*((C_word*)lf[99]+1),t4,lf[100],((C_word*)t0)[8]);}
else{
/* setup-download.scm: 249  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[7],lf[101],((C_word*)t0)[8]);}}}}

/* k2031 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2033,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2036,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* setup-download.scm: 251  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* setup-download.scm: 256  d */
f_1012(t2,lf[98],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}}

/* k2050 in k2031 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* setup-download.scm: 257  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2053 in k2050 in k2031 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2058,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* setup-download.scm: 258  read-line */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2056 in k2053 in k2050 in k2031 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2061,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* read-string/port */
t3=C_retrieve(lf[96]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2059 in k2056 in k2053 in k2050 in k2031 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2075,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 260  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t3,((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2073 in k2059 in k2056 in k2053 in k2050 in k2031 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2077,a[2]=((C_word*)t0)[3],a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 260  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],t1,t2);}

/* a2076 in k2073 in k2059 in k2056 in k2053 in k2050 in k2031 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2077,2,t0,t1);}
/* display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[94]+1)))(3,*((C_word*)lf[94]+1),t1,((C_word*)t0)[2]);}

/* k2062 in k2059 in k2056 in k2053 in k2050 in k2031 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2064,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* setup-download.scm: 261  get-files */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1979(t3,((C_word*)t0)[2],t2);}

/* k2034 in k2031 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* setup-download.scm: 252  d */
f_1012(t2,lf[93],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* k2037 in k2034 in k2031 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2042,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2049,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 253  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2047 in k2037 in k2034 in k2031 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 253  create-directory */
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t1);}

/* k2040 in k2037 in k2034 in k2031 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 254  get-files */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1979(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2010 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2015,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 246  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[90]+1)))(3,*((C_word*)lf[90]+1),t2,((C_word*)t0)[2]);}

/* k2013 in k2010 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 247  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[89]+1)))(3,*((C_word*)lf[89]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2166 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 266  make-property-condition */
((C_proc7)C_retrieve_symbol_proc(lf[83]))(7,*((C_word*)lf[83]+1),((C_word*)t0)[3],lf[85],lf[86],t1,lf[87],((C_word*)t0)[2]);}

/* k2158 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2164,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 270  make-property-condition */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,lf[84]);}

/* k2162 in k2158 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 265  make-composite-condition */
((C_proc4)C_retrieve_symbol_proc(lf[82]))(4,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2154 in k1987 in k1981 in get-files in k1972 in k1969 in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in a1939 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_2156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 264  abort */
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),((C_word*)t0)[2],t1);}

/* a1933 in k1927 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1934,2,t0,t1);}
/* setup-download.scm: 214  tcp-connect */
((C_proc4)C_retrieve_symbol_proc(lf[80]))(4,*((C_word*)lf[80]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1739 in k1736 in k1733 in k1730 in a1727 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[4];
t3=(C_truep(t2)?t2:lf[79]);
/* setup-download.scm: 176  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a1721 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1722,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1665,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 155  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t3,lf[78],t2);}

/* k1663 in a1721 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1665,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(t1):((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1676,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(t1)?(C_word)C_i_cadddr(t1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1689,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_list_ref(t1,C_fix(4));
/* setup-download.scm: 159  string->number */
C_string_to_number(3,0,t5,t6);}
else{
t5=t3;
f_1676(2,t5,C_fix(80));}}

/* k1687 in k1663 in a1721 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1676(2,t2,t1);}
else{
t2=(C_word)C_i_list_ref(((C_word*)t0)[2],C_fix(4));
/* setup-download.scm: 160  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[76],t2);}}

/* k1674 in k1663 in a1721 in k1715 in body565 in setup-download#locate-egg/http in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_list_ref(((C_word*)t0)[4],C_fix(5)):lf[75]);
/* setup-download.scm: 156  values */
C_values(5,0,((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_1450r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1450r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1450r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1452,a[2]=t3,a[3]=t2,a[4]=((C_word)li24),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1568,a[2]=t5,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1573,a[2]=t6,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1578,a[2]=t7,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1583,a[2]=t8,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-version437517 */
t10=t9;
f_1583(t10,t1);}
else{
t10=(C_word)C_i_car(t4);
t11=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-destination438513 */
t12=t8;
f_1578(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* def-username439508 */
t14=t7;
f_1573(t14,t1,t10,t12);}
else{
t14=(C_word)C_i_car(t13);
t15=(C_word)C_i_cdr(t13);
if(C_truep((C_word)C_i_nullp(t15))){
/* def-password440502 */
t16=t6;
f_1568(t16,t1,t10,t12,t14);}
else{
t16=(C_word)C_i_car(t15);
t17=(C_word)C_i_cdr(t15);
if(C_truep((C_word)C_i_nullp(t17))){
/* body435446 */
t18=t5;
f_1452(t18,t1,t10,t12,t14,t16);}
else{
/* ##sys#error */
t18=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t1,lf[0],t17);}}}}}}

/* def-version437 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1583(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1583,NULL,2,t0,t1);}
/* def-destination438513 */
t2=((C_word*)t0)[2];
f_1578(t2,t1,C_SCHEME_FALSE);}

/* def-destination438 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1578(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1578,NULL,3,t0,t1,t2);}
/* def-username439508 */
t3=((C_word*)t0)[2];
f_1573(t3,t1,t2,C_SCHEME_FALSE);}

/* def-username439 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1573(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1573,NULL,4,t0,t1,t2,t3);}
/* def-password440502 */
t4=((C_word*)t0)[2];
f_1568(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* def-password440 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1568(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1568,NULL,5,t0,t1,t2,t3,t4);}
/* body435446 */
t5=((C_word*)t0)[2];
f_1452(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1452(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1452,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1456,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
/* setup-download.scm: 129  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t6,lf[71],t4,lf[72]);}
else{
t7=t6;
f_1456(2,t7,lf[73]);}}

/* k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1459,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* setup-download.scm: 130  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t2,lf[68],((C_word*)t0)[2],lf[69]);}
else{
t3=t2;
f_1459(2,t3,lf[70]);}}

/* k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1561,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 131  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t3,((C_word*)t0)[4],((C_word*)t0)[7]);}

/* k1559 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1561,2,t0,t1);}
/* setup-download.scm: 131  make-svn-ls-cmd */
f_1327(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,2,lf[48],C_SCHEME_TRUE));}

/* k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1465,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* setup-download.scm: 132  d */
f_1012(t2,lf[67],(C_word)C_a_i_list(&a,1,t1));}

/* k1463 in k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1468,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* setup-download.scm: 133  with-input-from-pipe */
((C_proc4)C_retrieve_symbol_proc(lf[65]))(4,*((C_word*)lf[65]+1),t2,((C_word*)t0)[2],C_retrieve(lf[66]));}

/* k1466 in k1463 in k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1545,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1547,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 136  filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),t3,t4,t1);}

/* a1546 in k1466 in k1463 in k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1547,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1551,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 137  string-search */
((C_proc4)C_retrieve_symbol_proc(lf[63]))(4,*((C_word*)lf[63]+1),t3,lf[64],t2);}

/* k1549 in a1546 in k1466 in k1463 in k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_cadr(t1):C_SCHEME_FALSE));}

/* k1543 in k1466 in k1463 in k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 134  existing-version */
f_1049(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1476,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t1,a[6]=((C_word)li21),tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1504,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li22),tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1503 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1504,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1508,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1538,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t7=t6;
f_1538(2,t7,t5);}
else{
/* setup-download.scm: 147  get-temporary-directory */
f_1034(t6);}}

/* k1536 in a1503 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 147  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1506 in a1503 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1511,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1534,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 148  conc */
((C_proc7)C_retrieve_symbol_proc(lf[44]))(7,*((C_word*)lf[44]+1),t3,((C_word*)t0)[4],C_make_character(47),((C_word*)t0)[3],C_make_character(47),((C_word*)t0)[2]);}

/* k1532 in k1506 in a1503 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_truep(C_retrieve2(lf[2],"setup-download#*quiet*"))?lf[60]:lf[61]);
/* setup-download.scm: 116  conc */
((C_proc15)C_retrieve_symbol_proc(lf[44]))(15,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[62],t2,C_make_character(32),t3,C_make_character(32),C_make_character(34),t1,C_make_character(34),C_make_character(32),C_make_character(34),t4,C_make_character(34),t5);}

/* k1509 in k1506 in a1503 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1514,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 149  d */
f_1012(t2,lf[59],(C_word)C_a_i_list(&a,1,t1));}

/* k1512 in k1509 in k1506 in a1503 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1530,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 150  system */
((C_proc3)C_retrieve_symbol_proc(lf[58]))(3,*((C_word*)lf[58]+1),t2,((C_word*)t0)[2]);}

/* k1528 in k1512 in k1509 in k1506 in a1503 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
/* setup-download.scm: 151  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* setup-download.scm: 152  values */
C_values(4,0,((C_word*)t0)[4],C_SCHEME_FALSE,lf[57]);}}

/* a1475 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1476,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1487,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 141  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t2,lf[51],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1490,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 143  when-no-such-version-warning */
f_1076(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k1488 in a1475 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_member(lf[52],((C_word*)t0)[3]))){
/* setup-download.scm: 145  values */
C_values(4,0,((C_word*)t0)[2],lf[53],lf[54]);}
else{
/* setup-download.scm: 146  values */
C_values(4,0,((C_word*)t0)[2],lf[55],lf[56]);}}

/* k1485 in a1475 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in body435 in setup-download#locate-egg/svn in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 141  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* setup-download#make-svn-ls-cmd in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1327(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1327,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1331,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t6,lf[48],t5);}

/* k1329 in setup-download#make-svn-ls-cmd in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1331,2,t0,t1);}
t2=(C_truep(t1)?lf[42]:lf[43]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1342,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 113  qs */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,((C_word*)t0)[2]);}

/* k1340 in k1329 in setup-download#make-svn-ls-cmd in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 113  conc */
((C_proc8)C_retrieve_symbol_proc(lf[44]))(8,*((C_word*)lf[44]+1),((C_word*)t0)[5],lf[45],((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1221,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1225,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 95   directory */
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t3,t2);}

/* k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1230,a[2]=((C_word*)t0)[3],a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 96   filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),((C_word*)t0)[2],t2,t1);}

/* a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1230,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1236,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1242,a[2]=t2,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1241 in a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1242,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1246,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 99   make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[21]))(5,*((C_word*)lf[21]+1),t4,t2,((C_word*)t0)[2],lf[39]);}

/* k1244 in a1241 in a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1252,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 100  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t2,t1);}

/* k1250 in k1244 in a1241 in a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1252,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1257,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 101  call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1256 in k1250 in k1244 in a1241 in a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1257,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* setup-download.scm: 103  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[37]+1)))(3,*((C_word*)lf[37]+1),t3,((C_word*)t0)[3]);}

/* k1263 in a1256 in k1250 in k1244 in a1241 in a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1265,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[31],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1277,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1280,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li15),tmp=(C_word)a,a+=6,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t4,t5);}

/* a1281 in k1263 in a1256 in k1250 in k1244 in a1241 in a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1282(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1282,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1288,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li10),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1303,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[35]))(4,*((C_word*)lf[35]+1),t1,t3,t4);}

/* a1302 in a1281 in k1263 in a1256 in k1250 in k1244 in a1241 in a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[3],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[2],a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1314 in a1302 in a1281 in k1263 in a1256 in k1250 in k1244 in a1241 in a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1315r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1315r(t0,t1,t2);}}

static void C_ccall f_1315r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1321,a[2]=t2,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
/* k324329 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1320 in a1314 in a1302 in a1281 in k1263 in a1256 in k1250 in k1244 in a1241 in a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1321,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1308 in a1302 in a1281 in k1263 in a1256 in k1250 in k1244 in a1241 in a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1309,2,t0,t1);}
/* setup-download.scm: 109  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t1,((C_word*)t0)[2],*((C_word*)lf[34]+1));}

/* a1287 in a1281 in k1263 in a1256 in k1250 in k1244 in a1241 in a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1288,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li9),tmp=(C_word)a,a+=5,tmp);
/* k324329 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1293 in a1287 in a1281 in k1263 in a1256 in k1250 in k1244 in a1241 in a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1298,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 107  warning */
((C_proc4)C_retrieve_symbol_proc(lf[18]))(4,*((C_word*)lf[18]+1),t2,lf[32],((C_word*)t0)[2]);}

/* k1296 in a1293 in a1287 in a1281 in k1263 in a1256 in k1250 in k1244 in a1241 in a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 108  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1278 in k1263 in a1256 in k1250 in k1244 in a1241 in a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1275 in k1263 in a1256 in k1250 in k1244 in a1241 in a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1277,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* a1235 in a1229 in k1223 in setup-download#gather-egg-information in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1236,2,t0,t1);}
/* setup-download.scm: 98   locate-egg/local */
((C_proc4)C_retrieve_symbol_proc(lf[20]))(4,*((C_word*)lf[20]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-download#locate-egg/local in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1105(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_1105r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1105r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1105r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1107,a[2]=t3,a[3]=t2,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1168,a[2]=t5,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1173,a[2]=t6,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-version254287 */
t8=t7;
f_1173(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-destination255283 */
t10=t6;
f_1168(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body252261 */
t12=t5;
f_1107(t12,t1,t8);}
else{
/* ##sys#error */
t12=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-version254 in setup-download#locate-egg/local in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1173(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1173,NULL,2,t0,t1);}
/* def-destination255283 */
t2=((C_word*)t0)[2];
f_1168(t2,t1,C_SCHEME_FALSE);}

/* def-destination255 in setup-download#locate-egg/local in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1168(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1168,NULL,3,t0,t1,t2);}
/* body252261 */
t3=((C_word*)t0)[2];
f_1107(t3,t1,t2);}

/* body252 in setup-download#locate-egg/local in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1107(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1107,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1111,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 82   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t3,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1109 in body252 in setup-download#locate-egg/local in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1114,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 83   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t2,t1,lf[28]);}

/* k1112 in k1109 in body252 in setup-download#locate-egg/local in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1154,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 84   file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t3,t1);}

/* k1152 in k1112 in k1109 in body252 in setup-download#locate-egg/local in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1154,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 84   directory? */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_1117(2,t2,C_SCHEME_FALSE);}}

/* k1158 in k1152 in k1112 in k1109 in body252 in setup-download#locate-egg/local in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1160,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1167,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 85   directory */
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_1117(2,t2,C_SCHEME_FALSE);}}

/* k1165 in k1158 in k1152 in k1112 in k1109 in body252 in setup-download#locate-egg/local in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 85   existing-version */
f_1049(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1115 in k1112 in k1109 in body252 in setup-download#locate-egg/local in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1117,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1127,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 87   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t2,((C_word*)t0)[5],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 88   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t2,((C_word*)t0)[4],lf[26]);}}

/* k1128 in k1115 in k1112 in k1109 in body252 in setup-download#locate-egg/local in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1133,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 89   when-no-such-version-warning */
f_1076(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1131 in k1128 in k1115 in k1112 in k1109 in body252 in setup-download#locate-egg/local in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1148,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 90   file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t3,((C_word*)t0)[3]);}

/* k1146 in k1131 in k1128 in k1115 in k1112 in k1109 in body252 in setup-download#locate-egg/local in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-download.scm: 90   directory? */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1139(2,t2,C_SCHEME_FALSE);}}

/* k1137 in k1131 in k1128 in k1115 in k1112 in k1109 in body252 in setup-download#locate-egg/local in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-download.scm: 91   values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],lf[22]);}
else{
/* setup-download.scm: 92   values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[2],lf[23]);}}

/* k1125 in k1115 in k1112 in k1109 in body252 in setup-download#locate-egg/local in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 87   values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* setup-download#when-no-such-version-warning in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1076(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1076,NULL,3,t1,t2,t3);}
if(C_truep(t3)){
/* setup-download.scm: 76   warning */
((C_proc5)C_retrieve_symbol_proc(lf[18]))(5,*((C_word*)lf[18]+1),t1,lf[19],t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setup-download#existing-version in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1049(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1049,NULL,4,t1,t2,t3,t4);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_member(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
/* setup-download.scm: 70   error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[13]+1)))(5,*((C_word*)lf[13]+1),t1,lf[14],t2,t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1065,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 71   sort */
((C_proc4)C_retrieve_symbol_proc(lf[15]))(4,*((C_word*)lf[15]+1),t5,t4,C_retrieve(lf[16]));}}

/* k1063 in setup-download#existing-version in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_pairp(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_car(t1):C_SCHEME_FALSE));}

/* setup-download#get-temporary-directory in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1034(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1034,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1038,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 61   temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[9]))(2,*((C_word*)lf[9]+1),t2);}

/* k1036 in setup-download#get-temporary-directory in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1038,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1044,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 62   setup-api#create-temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[11]))(2,*((C_word*)lf[11]+1),t2);}}

/* k1042 in k1036 in setup-download#get-temporary-directory in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1047,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 63   temporary-directory */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t2,t1);}

/* k1045 in k1042 in k1036 in setup-download#get-temporary-directory in k1030 in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-download#d in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_fcall f_1012(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1012,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1016,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[2],"setup-download#*quiet*"))){
/* setup-download.scm: 54   current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t4);}
else{
/* setup-download.scm: 54   current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[8]+1)))(2,*((C_word*)lf[8]+1),t4);}}

/* k1014 in setup-download#d in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1019,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t2,C_retrieve(lf[6]),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1017 in k1014 in setup-download#d in k1008 in k1003 in k1000 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 */
static void C_ccall f_1019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 56   flush-output */
((C_proc3)C_retrieve_proc(*((C_word*)lf[5]+1)))(3,*((C_word*)lf[5]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[209] = {
{"toplevel:setup_download_scm",(void*)C_toplevel},
{"f_951:setup_download_scm",(void*)f_951},
{"f_954:setup_download_scm",(void*)f_954},
{"f_957:setup_download_scm",(void*)f_957},
{"f_960:setup_download_scm",(void*)f_960},
{"f_963:setup_download_scm",(void*)f_963},
{"f_966:setup_download_scm",(void*)f_966},
{"f_969:setup_download_scm",(void*)f_969},
{"f_972:setup_download_scm",(void*)f_972},
{"f_975:setup_download_scm",(void*)f_975},
{"f_978:setup_download_scm",(void*)f_978},
{"f_981:setup_download_scm",(void*)f_981},
{"f_984:setup_download_scm",(void*)f_984},
{"f_987:setup_download_scm",(void*)f_987},
{"f_990:setup_download_scm",(void*)f_990},
{"f_993:setup_download_scm",(void*)f_993},
{"f_996:setup_download_scm",(void*)f_996},
{"f_999:setup_download_scm",(void*)f_999},
{"f_1002:setup_download_scm",(void*)f_1002},
{"f_1005:setup_download_scm",(void*)f_1005},
{"f_2332:setup_download_scm",(void*)f_2332},
{"f_1010:setup_download_scm",(void*)f_1010},
{"f_1032:setup_download_scm",(void*)f_1032},
{"f_2281:setup_download_scm",(void*)f_2281},
{"f_2285:setup_download_scm",(void*)f_2285},
{"f_2288:setup_download_scm",(void*)f_2288},
{"f_2291:setup_download_scm",(void*)f_2291},
{"f_2325:setup_download_scm",(void*)f_2325},
{"f_2301:setup_download_scm",(void*)f_2301},
{"f_1402:setup_download_scm",(void*)f_1402},
{"f_1397:setup_download_scm",(void*)f_1397},
{"f_1356:setup_download_scm",(void*)f_1356},
{"f_1360:setup_download_scm",(void*)f_1360},
{"f_1363:setup_download_scm",(void*)f_1363},
{"f_1366:setup_download_scm",(void*)f_1366},
{"f_1369:setup_download_scm",(void*)f_1369},
{"f_1390:setup_download_scm",(void*)f_1390},
{"f_1378:setup_download_scm",(void*)f_1378},
{"f_1386:setup_download_scm",(void*)f_1386},
{"f_1376:setup_download_scm",(void*)f_1376},
{"f_1103:setup_download_scm",(void*)f_1103},
{"f_1095:setup_download_scm",(void*)f_1095},
{"f_1093:setup_download_scm",(void*)f_1093},
{"f_2296:setup_download_scm",(void*)f_2296},
{"f_2208:setup_download_scm",(void*)f_2208},
{"f_2212:setup_download_scm",(void*)f_2212},
{"f_2215:setup_download_scm",(void*)f_2215},
{"f_2218:setup_download_scm",(void*)f_2218},
{"f_2221:setup_download_scm",(void*)f_2221},
{"f_2224:setup_download_scm",(void*)f_2224},
{"f_2227:setup_download_scm",(void*)f_2227},
{"f_2276:setup_download_scm",(void*)f_2276},
{"f_2237:setup_download_scm",(void*)f_2237},
{"f_2247:setup_download_scm",(void*)f_2247},
{"f_2232:setup_download_scm",(void*)f_2232},
{"f_1711:setup_download_scm",(void*)f_1711},
{"f_1779:setup_download_scm",(void*)f_1779},
{"f_1774:setup_download_scm",(void*)f_1774},
{"f_1769:setup_download_scm",(void*)f_1769},
{"f_1713:setup_download_scm",(void*)f_1713},
{"f_1717:setup_download_scm",(void*)f_1717},
{"f_1728:setup_download_scm",(void*)f_1728},
{"f_1758:setup_download_scm",(void*)f_1758},
{"f_1732:setup_download_scm",(void*)f_1732},
{"f_1735:setup_download_scm",(void*)f_1735},
{"f_1751:setup_download_scm",(void*)f_1751},
{"f_1738:setup_download_scm",(void*)f_1738},
{"f_1929:setup_download_scm",(void*)f_1929},
{"f_1940:setup_download_scm",(void*)f_1940},
{"f_1944:setup_download_scm",(void*)f_1944},
{"f_1887:setup_download_scm",(void*)f_1887},
{"f_1864:setup_download_scm",(void*)f_1864},
{"f_1884:setup_download_scm",(void*)f_1884},
{"f_1867:setup_download_scm",(void*)f_1867},
{"f_1881:setup_download_scm",(void*)f_1881},
{"f_1870:setup_download_scm",(void*)f_1870},
{"f_1878:setup_download_scm",(void*)f_1878},
{"f_1873:setup_download_scm",(void*)f_1873},
{"f_2146:setup_download_scm",(void*)f_2146},
{"f_1947:setup_download_scm",(void*)f_1947},
{"f_1950:setup_download_scm",(void*)f_1950},
{"f_1953:setup_download_scm",(void*)f_1953},
{"f_1956:setup_download_scm",(void*)f_1956},
{"f_1959:setup_download_scm",(void*)f_1959},
{"f_1962:setup_download_scm",(void*)f_1962},
{"f_2139:setup_download_scm",(void*)f_2139},
{"f_1854:setup_download_scm",(void*)f_1854},
{"f_1858:setup_download_scm",(void*)f_1858},
{"f_1850:setup_download_scm",(void*)f_1850},
{"f_1965:setup_download_scm",(void*)f_1965},
{"f_2113:setup_download_scm",(void*)f_2113},
{"f_2117:setup_download_scm",(void*)f_2117},
{"f_2123:setup_download_scm",(void*)f_2123},
{"f_2135:setup_download_scm",(void*)f_2135},
{"f_2126:setup_download_scm",(void*)f_2126},
{"f_2129:setup_download_scm",(void*)f_2129},
{"f_1968:setup_download_scm",(void*)f_1968},
{"f_2101:setup_download_scm",(void*)f_2101},
{"f_2176:setup_download_scm",(void*)f_2176},
{"f_2206:setup_download_scm",(void*)f_2206},
{"f_2180:setup_download_scm",(void*)f_2180},
{"f_2192:setup_download_scm",(void*)f_2192},
{"f_2195:setup_download_scm",(void*)f_2195},
{"f_2104:setup_download_scm",(void*)f_2104},
{"f_2107:setup_download_scm",(void*)f_2107},
{"f_2111:setup_download_scm",(void*)f_2111},
{"f_1971:setup_download_scm",(void*)f_1971},
{"f_1974:setup_download_scm",(void*)f_1974},
{"f_1979:setup_download_scm",(void*)f_1979},
{"f_1983:setup_download_scm",(void*)f_1983},
{"f_1989:setup_download_scm",(void*)f_1989},
{"f_2033:setup_download_scm",(void*)f_2033},
{"f_2052:setup_download_scm",(void*)f_2052},
{"f_2055:setup_download_scm",(void*)f_2055},
{"f_2058:setup_download_scm",(void*)f_2058},
{"f_2061:setup_download_scm",(void*)f_2061},
{"f_2075:setup_download_scm",(void*)f_2075},
{"f_2077:setup_download_scm",(void*)f_2077},
{"f_2064:setup_download_scm",(void*)f_2064},
{"f_2036:setup_download_scm",(void*)f_2036},
{"f_2039:setup_download_scm",(void*)f_2039},
{"f_2049:setup_download_scm",(void*)f_2049},
{"f_2042:setup_download_scm",(void*)f_2042},
{"f_2012:setup_download_scm",(void*)f_2012},
{"f_2015:setup_download_scm",(void*)f_2015},
{"f_2168:setup_download_scm",(void*)f_2168},
{"f_2160:setup_download_scm",(void*)f_2160},
{"f_2164:setup_download_scm",(void*)f_2164},
{"f_2156:setup_download_scm",(void*)f_2156},
{"f_1934:setup_download_scm",(void*)f_1934},
{"f_1741:setup_download_scm",(void*)f_1741},
{"f_1722:setup_download_scm",(void*)f_1722},
{"f_1665:setup_download_scm",(void*)f_1665},
{"f_1689:setup_download_scm",(void*)f_1689},
{"f_1676:setup_download_scm",(void*)f_1676},
{"f_1450:setup_download_scm",(void*)f_1450},
{"f_1583:setup_download_scm",(void*)f_1583},
{"f_1578:setup_download_scm",(void*)f_1578},
{"f_1573:setup_download_scm",(void*)f_1573},
{"f_1568:setup_download_scm",(void*)f_1568},
{"f_1452:setup_download_scm",(void*)f_1452},
{"f_1456:setup_download_scm",(void*)f_1456},
{"f_1459:setup_download_scm",(void*)f_1459},
{"f_1561:setup_download_scm",(void*)f_1561},
{"f_1462:setup_download_scm",(void*)f_1462},
{"f_1465:setup_download_scm",(void*)f_1465},
{"f_1468:setup_download_scm",(void*)f_1468},
{"f_1547:setup_download_scm",(void*)f_1547},
{"f_1551:setup_download_scm",(void*)f_1551},
{"f_1545:setup_download_scm",(void*)f_1545},
{"f_1471:setup_download_scm",(void*)f_1471},
{"f_1504:setup_download_scm",(void*)f_1504},
{"f_1538:setup_download_scm",(void*)f_1538},
{"f_1508:setup_download_scm",(void*)f_1508},
{"f_1534:setup_download_scm",(void*)f_1534},
{"f_1511:setup_download_scm",(void*)f_1511},
{"f_1514:setup_download_scm",(void*)f_1514},
{"f_1530:setup_download_scm",(void*)f_1530},
{"f_1476:setup_download_scm",(void*)f_1476},
{"f_1490:setup_download_scm",(void*)f_1490},
{"f_1487:setup_download_scm",(void*)f_1487},
{"f_1327:setup_download_scm",(void*)f_1327},
{"f_1331:setup_download_scm",(void*)f_1331},
{"f_1342:setup_download_scm",(void*)f_1342},
{"f_1221:setup_download_scm",(void*)f_1221},
{"f_1225:setup_download_scm",(void*)f_1225},
{"f_1230:setup_download_scm",(void*)f_1230},
{"f_1242:setup_download_scm",(void*)f_1242},
{"f_1246:setup_download_scm",(void*)f_1246},
{"f_1252:setup_download_scm",(void*)f_1252},
{"f_1257:setup_download_scm",(void*)f_1257},
{"f_1265:setup_download_scm",(void*)f_1265},
{"f_1282:setup_download_scm",(void*)f_1282},
{"f_1303:setup_download_scm",(void*)f_1303},
{"f_1315:setup_download_scm",(void*)f_1315},
{"f_1321:setup_download_scm",(void*)f_1321},
{"f_1309:setup_download_scm",(void*)f_1309},
{"f_1288:setup_download_scm",(void*)f_1288},
{"f_1294:setup_download_scm",(void*)f_1294},
{"f_1298:setup_download_scm",(void*)f_1298},
{"f_1280:setup_download_scm",(void*)f_1280},
{"f_1277:setup_download_scm",(void*)f_1277},
{"f_1236:setup_download_scm",(void*)f_1236},
{"f_1105:setup_download_scm",(void*)f_1105},
{"f_1173:setup_download_scm",(void*)f_1173},
{"f_1168:setup_download_scm",(void*)f_1168},
{"f_1107:setup_download_scm",(void*)f_1107},
{"f_1111:setup_download_scm",(void*)f_1111},
{"f_1114:setup_download_scm",(void*)f_1114},
{"f_1154:setup_download_scm",(void*)f_1154},
{"f_1160:setup_download_scm",(void*)f_1160},
{"f_1167:setup_download_scm",(void*)f_1167},
{"f_1117:setup_download_scm",(void*)f_1117},
{"f_1130:setup_download_scm",(void*)f_1130},
{"f_1133:setup_download_scm",(void*)f_1133},
{"f_1148:setup_download_scm",(void*)f_1148},
{"f_1139:setup_download_scm",(void*)f_1139},
{"f_1127:setup_download_scm",(void*)f_1127},
{"f_1076:setup_download_scm",(void*)f_1076},
{"f_1049:setup_download_scm",(void*)f_1049},
{"f_1065:setup_download_scm",(void*)f_1065},
{"f_1034:setup_download_scm",(void*)f_1034},
{"f_1038:setup_download_scm",(void*)f_1038},
{"f_1044:setup_download_scm",(void*)f_1044},
{"f_1047:setup_download_scm",(void*)f_1047},
{"f_1012:setup_download_scm",(void*)f_1012},
{"f_1016:setup_download_scm",(void*)f_1016},
{"f_1019:setup_download_scm",(void*)f_1019},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
