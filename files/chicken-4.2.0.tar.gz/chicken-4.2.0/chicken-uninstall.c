/* Generated from chicken-uninstall.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-09-21 21:28
   Version 4.0.1 - SVN rev. 14292
   linux-unix-gnu-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-12 on galinha (Linux)
   command line: chicken-uninstall.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -ignore-repository -output-file chicken-uninstall.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 posix data_structures utils ports regex srfi_13 files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[55];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_357)
static void C_ccall f_357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_360)
static void C_ccall f_360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_363)
static void C_ccall f_363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_366)
static void C_ccall f_366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_369)
static void C_ccall f_369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_372)
static void C_ccall f_372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_375)
static void C_ccall f_375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_378)
static void C_ccall f_378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_381)
static void C_ccall f_381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_384)
static void C_ccall f_384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_387)
static void C_ccall f_387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_390)
static void C_ccall f_390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_393)
static void C_ccall f_393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_396)
static void C_ccall f_396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_399)
static void C_ccall f_399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_785)
static void C_ccall f_785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_582)
static void C_fcall f_582(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_617)
static void C_fcall f_617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_678)
static void C_fcall f_678(C_word t0,C_word t1) C_noret;
C_noret_decl(f_725)
static void C_ccall f_725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_687)
static void C_ccall f_687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_721)
static void C_ccall f_721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_710)
static void C_ccall f_710(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_704)
static void C_ccall f_704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_700)
static void C_ccall f_700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_665)
static void C_ccall f_665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_639)
static void C_ccall f_639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_632)
static void C_ccall f_632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_596)
static void C_ccall f_596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_435)
static void C_ccall f_435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_431)
static void C_ccall f_431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_427)
static void C_ccall f_427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_406)
static void C_ccall f_406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_419)
static void C_ccall f_419(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_417)
static void C_ccall f_417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_413)
static void C_ccall f_413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_528)
static void C_ccall f_528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_455)
static void C_ccall f_455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_482)
static void C_ccall f_482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_512)
static void C_ccall f_512(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_512)
static void C_ccall f_512r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_518)
static void C_ccall f_518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_488)
static void C_ccall f_488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_506)
static void C_ccall f_506(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_504)
static void C_ccall f_504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_500)
static void C_ccall f_500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_496)
static void C_ccall f_496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_461)
static void C_ccall f_461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_467)
static void C_ccall f_467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_441)
static void C_ccall f_441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_453)
static void C_ccall f_453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_543)
static void C_ccall f_543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_548)
static void C_ccall f_548(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_552)
static void C_ccall f_552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_775)
static void C_ccall f_775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_781)
static void C_ccall f_781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_778)
static void C_ccall f_778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_566)
static void C_fcall f_566(C_word t0,C_word t1) C_noret;
C_noret_decl(f_570)
static void C_ccall f_570(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_582)
static void C_fcall trf_582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_582(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_582(t0,t1,t2,t3);}

C_noret_decl(trf_617)
static void C_fcall trf_617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_617(t0,t1);}

C_noret_decl(trf_678)
static void C_fcall trf_678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_678(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_678(t0,t1);}

C_noret_decl(trf_566)
static void C_fcall trf_566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_566(t0,t1);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(342)){
C_save(t1);
C_rereclaim2(342*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,55);
lf[2]=C_h_intern(&lf[2],4,"exit");
lf[3]=C_h_intern(&lf[3],5,"print");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\001#usage: chicken-uninstall [OPTION | PATTERN] ...\012\012  -h   -help              "
"      show this message and exit\012  -v   -version                 show version an"
"d exit\012       -force                   don\047t ask, delete whatever matches\012  -s  "
" -sudo                    use sudo(1) for deleting files");
lf[5]=C_h_intern(&lf[5],25,"\003sysimplicit-exit-handler");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\022nothing to remove.");
lf[7]=C_h_intern(&lf[7],26,"setup-api#remove-extension");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\011removing ");
lf[9]=C_h_intern(&lf[9],12,"\003sysfor-each");
lf[10]=C_h_intern(&lf[10],7,"aborted");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\010aborted.");
lf[12]=C_h_intern(&lf[12],6,"signal");
lf[13]=C_h_intern(&lf[13],20,"setup-api#yes-or-no\077");
lf[14]=C_h_intern(&lf[14],8,"\000default");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[16]=C_h_intern(&lf[16],18,"string-concatenate");
lf[17]=C_h_intern(&lf[17],6,"append");
lf[18]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000+About to delete the following extensions:\012\012\376\377\016");
lf[19]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\030\012Do you want to proceed\077\376\377\016");
lf[20]=C_h_intern(&lf[20],13,"string-append");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[23]=C_h_intern(&lf[23],7,"\003sysmap");
lf[24]=C_h_intern(&lf[24],22,"with-exception-handler");
lf[25]=C_h_intern(&lf[25],30,"call-with-current-continuation");
lf[26]=C_h_intern(&lf[26],17,"delete-duplicates");
lf[27]=C_h_intern(&lf[27],8,"string=\077");
lf[28]=C_h_intern(&lf[28],11,"concatenate");
lf[29]=C_h_intern(&lf[29],4,"grep");
lf[30]=C_h_intern(&lf[30],13,"pathname-file");
lf[31]=C_h_intern(&lf[31],4,"glob");
lf[32]=C_h_intern(&lf[32],13,"make-pathname");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[35]=C_h_intern(&lf[35],15,"repository-path");
lf[36]=C_h_intern(&lf[36],7,"reverse");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[40]=C_h_intern(&lf[40],15,"chicken-version");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\006-force");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\005-sudo");
lf[44]=C_h_intern(&lf[44],22,"setup-api#sudo-install");
lf[45]=C_h_intern(&lf[45],17,"lset-intersection");
lf[46]=C_h_intern(&lf[46],3,"eq\077");
lf[47]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\377\016");
lf[48]=C_h_intern(&lf[48],16,"\003sysstring->list");
lf[49]=C_h_intern(&lf[49],9,"substring");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[52]=C_h_intern(&lf[52],22,"command-line-arguments");
lf[53]=C_h_intern(&lf[53],11,"\003sysrequire");
lf[54]=C_h_intern(&lf[54],9,"setup-api");
C_register_lf2(lf,55,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_357,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k355 */
static void C_ccall f_357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_360,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k358 in k355 */
static void C_ccall f_360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_363,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k361 in k358 in k355 */
static void C_ccall f_363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_366,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k364 in k361 in k358 in k355 */
static void C_ccall f_366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_369,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_372,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_375,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_378,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_381,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_384,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_387,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_390,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_393,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_396,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_399,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[53]))(3,*((C_word*)lf[53]+1),t2,lf[54]);}

/* k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_399,2,t0,t1);}
t2=lf[0] /* main#*force* */ =C_SCHEME_FALSE;;
t3=C_mutate(&lf[1] /* (set! main#usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_566,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_775,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_785,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 117  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[52]))(2,*((C_word*)lf[52]+1),t5);}

/* k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_785,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_582,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_582(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_fcall f_582(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_582,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_596,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* chicken-uninstall.scm: 92   usage */
f_566(t4,C_fix(1));}
else{
/* chicken-uninstall.scm: 92   reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t4,t3);}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_equal_p(t4,lf[37]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_617,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_617(t7,t5);}
else{
t7=(C_word)C_i_string_equal_p(t4,lf[50]);
t8=t6;
f_617(t8,(C_truep(t7)?t7:(C_word)C_i_string_equal_p(t4,lf[51])));}}}

/* k615 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_fcall f_617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_617,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-uninstall.scm: 97   usage */
f_566(((C_word*)t0)[6],C_fix(0));}
else{
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[38]);
t3=(C_truep(t2)?t2:(C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[39]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_632,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_639,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 99   chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[40]))(2,*((C_word*)lf[40]+1),t5);}
else{
if(C_truep((C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[41]))){
t4=lf[0] /* main#*force* */ =C_SCHEME_TRUE;;
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-uninstall.scm: 103  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_582(t6,((C_word*)t0)[6],t5,((C_word*)t0)[2]);}
else{
t4=(C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[42]);
t5=(C_truep(t4)?t4:(C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[43]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-uninstall.scm: 105  setup-api#sudo-install */
((C_proc3)C_retrieve_symbol_proc(lf[44]))(3,*((C_word*)lf[44]+1),t6,C_SCHEME_TRUE);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_678,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_i_string_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_positivep(t7))){
t8=(C_word)C_i_string_ref(((C_word*)t0)[5],C_fix(0));
t9=t6;
f_678(t9,(C_word)C_eqp(C_make_character(45),t8));}
else{
t8=t6;
f_678(t8,C_SCHEME_FALSE);}}}}}}

/* k676 in k615 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_fcall f_678(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_678,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_725,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 110  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[49]+1)))(4,*((C_word*)lf[49]+1),t4,((C_word*)t0)[6],C_fix(1));}
else{
/* chicken-uninstall.scm: 114  usage */
f_566(((C_word*)t0)[4],C_fix(1));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[3]);
/* chicken-uninstall.scm: 115  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_582(t4,((C_word*)t0)[4],t2,t3);}}

/* k723 in k676 in k615 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[48]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k685 in k676 in k615 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_721,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-uninstall.scm: 111  lset-intersection */
((C_proc5)C_retrieve_symbol_proc(lf[45]))(5,*((C_word*)lf[45]+1),t2,*((C_word*)lf[46]+1),lf[47],t1);}

/* k719 in k685 in k676 in k615 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_721,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_700,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_704,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_710,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
/* chicken-uninstall.scm: 113  usage */
f_566(((C_word*)t0)[5],C_fix(1));}}

/* a709 in k719 in k685 in k676 in k615 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_710(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_710,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k702 in k719 in k685 in k676 in k615 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-uninstall.scm: 112  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[2],t1,t2);}

/* k698 in k719 in k685 in k676 in k615 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 112  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_582(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k663 in k615 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-uninstall.scm: 106  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_582(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k637 in k615 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 99   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),((C_word*)t0)[2],t1);}

/* k630 in k615 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 100  exit */
((C_proc3)C_retrieve_symbol_proc(lf[2]))(3,*((C_word*)lf[2]+1),((C_word*)t0)[2],C_fix(0));}

/* k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_596,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_528,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_406,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_427,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_431,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_435,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 42   repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[35]))(2,*((C_word*)lf[35]+1),t7);}

/* k433 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 42   make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],t1,lf[33],lf[34]);}

/* k429 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 42   glob */
((C_proc3)C_retrieve_symbol_proc(lf[31]))(3,*((C_word*)lf[31]+1),((C_word*)t0)[2],t1);}

/* k425 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[30]),t1);}

/* k404 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_413,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_417,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_419,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a418 in k404 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_419(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_419,3,t0,t1,t2);}
/* grep */
((C_proc4)C_retrieve_symbol_proc(lf[29]))(4,*((C_word*)lf[29]+1),t1,t2,((C_word*)t0)[2]);}

/* k415 in k404 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 44   concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),((C_word*)t0)[2],t1);}

/* k411 in k404 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 43   delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[26]))(4,*((C_word*)lf[26]+1),((C_word*)t0)[2],t1,*((C_word*)lf[27]+1));}

/* k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_528,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* chicken-uninstall.scm: 67   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),((C_word*)t0)[3],lf[6]);}
else{
t2=C_retrieve2(lf[0],"main#*force*");
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_543,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_543(2,t4,t2);}
else{
t4=(C_word)C_i_equalp(t1,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_543(2,t5,t4);}
else{
t5=t1;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_453,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_455,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[25]+1)))(3,*((C_word*)lf[25]+1),t6,t7);}}}}

/* a454 in k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_455,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_461,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_482,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t1,t3,t4);}

/* a481 in a454 in k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_488,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_512,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a511 in a481 in a454 in k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_512(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_512r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_512r(t0,t1,t2);}}

static void C_ccall f_512r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_518,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k212218 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a517 in a511 in a481 in a454 in k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_518,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a487 in a481 in a454 in k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_496,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_500,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_504,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_506,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a505 in a487 in a481 in a454 in k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_506(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_506,3,t0,t1,t2);}
/* string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[20]+1)))(5,*((C_word*)lf[20]+1),t1,lf[21],t2,lf[22]);}

/* k502 in a487 in a481 in a454 in k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 58   append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[17]+1)))(5,*((C_word*)lf[17]+1),((C_word*)t0)[2],lf[18],t1,lf[19]);}

/* k498 in a487 in a481 in a454 in k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 57   string-concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),((C_word*)t0)[2],t1);}

/* k494 in a487 in a481 in a454 in k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 56   setup-api#yes-or-no? */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),((C_word*)t0)[2],t1,lf[14],lf[15]);}

/* a460 in a454 in k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_461,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_467,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k212218 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a466 in a460 in a454 in k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_467,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[10]);
if(C_truep(t2)){
t3=t1;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_441,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 48   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),t4,lf[11]);}
else{
/* chicken-uninstall.scm: 55   signal */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),t1,((C_word*)t0)[2]);}}

/* k439 in a466 in a460 in a454 in k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 49   exit */
((C_proc3)C_retrieve_symbol_proc(lf[2]))(3,*((C_word*)lf[2]+1),((C_word*)t0)[2],C_fix(1));}

/* k451 in k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k541 in k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_543,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_548,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a547 in k541 in k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_548(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_548,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_552,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-uninstall.scm: 71   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t3,lf[8],t2);}

/* k550 in a547 in k541 in k526 in k594 in loop in k783 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 72   setup-api#remove-extension */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k773 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_778,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_781,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[5]))(2,*((C_word*)lf[5]+1),t3);}

/* k779 in k773 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k776 in k773 in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#usage in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_fcall f_566(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_566,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_570,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-uninstall.scm: 76   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),t3,lf[4]);}

/* k568 in main#usage in k397 in k394 in k391 in k388 in k385 in k382 in k379 in k376 in k373 in k370 in k367 in k364 in k361 in k358 in k355 */
static void C_ccall f_570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 85   exit */
((C_proc3)C_retrieve_symbol_proc(lf[2]))(3,*((C_word*)lf[2]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[60] = {
{"toplevel:chicken_uninstall_scm",(void*)C_toplevel},
{"f_357:chicken_uninstall_scm",(void*)f_357},
{"f_360:chicken_uninstall_scm",(void*)f_360},
{"f_363:chicken_uninstall_scm",(void*)f_363},
{"f_366:chicken_uninstall_scm",(void*)f_366},
{"f_369:chicken_uninstall_scm",(void*)f_369},
{"f_372:chicken_uninstall_scm",(void*)f_372},
{"f_375:chicken_uninstall_scm",(void*)f_375},
{"f_378:chicken_uninstall_scm",(void*)f_378},
{"f_381:chicken_uninstall_scm",(void*)f_381},
{"f_384:chicken_uninstall_scm",(void*)f_384},
{"f_387:chicken_uninstall_scm",(void*)f_387},
{"f_390:chicken_uninstall_scm",(void*)f_390},
{"f_393:chicken_uninstall_scm",(void*)f_393},
{"f_396:chicken_uninstall_scm",(void*)f_396},
{"f_399:chicken_uninstall_scm",(void*)f_399},
{"f_785:chicken_uninstall_scm",(void*)f_785},
{"f_582:chicken_uninstall_scm",(void*)f_582},
{"f_617:chicken_uninstall_scm",(void*)f_617},
{"f_678:chicken_uninstall_scm",(void*)f_678},
{"f_725:chicken_uninstall_scm",(void*)f_725},
{"f_687:chicken_uninstall_scm",(void*)f_687},
{"f_721:chicken_uninstall_scm",(void*)f_721},
{"f_710:chicken_uninstall_scm",(void*)f_710},
{"f_704:chicken_uninstall_scm",(void*)f_704},
{"f_700:chicken_uninstall_scm",(void*)f_700},
{"f_665:chicken_uninstall_scm",(void*)f_665},
{"f_639:chicken_uninstall_scm",(void*)f_639},
{"f_632:chicken_uninstall_scm",(void*)f_632},
{"f_596:chicken_uninstall_scm",(void*)f_596},
{"f_435:chicken_uninstall_scm",(void*)f_435},
{"f_431:chicken_uninstall_scm",(void*)f_431},
{"f_427:chicken_uninstall_scm",(void*)f_427},
{"f_406:chicken_uninstall_scm",(void*)f_406},
{"f_419:chicken_uninstall_scm",(void*)f_419},
{"f_417:chicken_uninstall_scm",(void*)f_417},
{"f_413:chicken_uninstall_scm",(void*)f_413},
{"f_528:chicken_uninstall_scm",(void*)f_528},
{"f_455:chicken_uninstall_scm",(void*)f_455},
{"f_482:chicken_uninstall_scm",(void*)f_482},
{"f_512:chicken_uninstall_scm",(void*)f_512},
{"f_518:chicken_uninstall_scm",(void*)f_518},
{"f_488:chicken_uninstall_scm",(void*)f_488},
{"f_506:chicken_uninstall_scm",(void*)f_506},
{"f_504:chicken_uninstall_scm",(void*)f_504},
{"f_500:chicken_uninstall_scm",(void*)f_500},
{"f_496:chicken_uninstall_scm",(void*)f_496},
{"f_461:chicken_uninstall_scm",(void*)f_461},
{"f_467:chicken_uninstall_scm",(void*)f_467},
{"f_441:chicken_uninstall_scm",(void*)f_441},
{"f_453:chicken_uninstall_scm",(void*)f_453},
{"f_543:chicken_uninstall_scm",(void*)f_543},
{"f_548:chicken_uninstall_scm",(void*)f_548},
{"f_552:chicken_uninstall_scm",(void*)f_552},
{"f_775:chicken_uninstall_scm",(void*)f_775},
{"f_781:chicken_uninstall_scm",(void*)f_781},
{"f_778:chicken_uninstall_scm",(void*)f_778},
{"f_566:chicken_uninstall_scm",(void*)f_566},
{"f_570:chicken_uninstall_scm",(void*)f_570},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
