#define C_BUILD_TAG "compiled 2015-08-04 on yves.more-magic.net (Linux)"
