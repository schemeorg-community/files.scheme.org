/* Generated from unboxing.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:53
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: unboxing.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file unboxing.c
   unit: unboxing
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[230];
static double C_possibly_force_alignment;


C_noret_decl(C_unboxing_toplevel)
C_externexport void C_ccall C_unboxing_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_872)
static void C_ccall f_872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_875)
static void C_ccall f_875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2697)
static void C_ccall f_2697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2703)
static void C_ccall f_2703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2736)
static void C_ccall f_2736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2751)
static void C_ccall f_2751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2790)
static void C_ccall f_2790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2793)
static void C_ccall f_2793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2811)
static void C_ccall f_2811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2835)
static void C_ccall f_2835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_895)
static void C_ccall f_895(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_899)
static void C_ccall f_899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2656)
static void C_ccall f_2656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2665)
static void C_ccall f_2665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2671)
static void C_ccall f_2671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_901)
static void C_fcall f_901(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_fcall f_1977(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2014)
static void C_fcall f_2014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2605)
static void C_ccall f_2605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2598)
static void C_fcall f_2598(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2580)
static void C_fcall f_2580(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2569)
static void C_ccall f_2569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2492)
static void C_fcall f_2492(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2449)
static void C_ccall f_2449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2135)
static void C_ccall f_2135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_fcall f_2195(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2203)
static void C_fcall f_2203(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2210)
static void C_fcall f_2210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2072)
static void C_ccall f_2072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2053)
static void C_ccall f_2053(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1807)
static void C_fcall f_1807(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_fcall f_1856(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1681)
static void C_fcall f_1681(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_ccall f_1716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_fcall f_1555(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1523)
static void C_fcall f_1523(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1527)
static void C_ccall f_1527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1533)
static void C_ccall f_1533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1107)
static void C_fcall f_1107(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1118)
static void C_ccall f_1118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1130)
static void C_fcall f_1130(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1352)
static void C_fcall f_1352(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1455)
static void C_ccall f_1455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_fcall f_1440(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1407)
static void C_ccall f_1407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1154)
static void C_ccall f_1154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1174)
static void C_ccall f_1174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1039)
static void C_fcall f_1039(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1049)
static void C_fcall f_1049(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1061)
static void C_fcall f_1061(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1064)
static void C_ccall f_1064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1052)
static void C_ccall f_1052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1033)
static void C_fcall f_1033(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1011)
static void C_fcall f_1011(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_990)
static C_word C_fcall f_990(C_word t0,C_word t1);
C_noret_decl(f_928)
static void C_fcall f_928(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_988)
static void C_ccall f_988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_980)
static void C_ccall f_980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_984)
static void C_ccall f_984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_fcall f_939(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_973)
static void C_ccall f_973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_904)
static void C_fcall f_904(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_926)
static void C_ccall f_926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_877)
static void C_ccall f_877(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_877)
static void C_ccall f_877r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_887)
static void C_ccall f_887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_890)
static void C_ccall f_890(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_901)
static void C_fcall trf_901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_901(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_901(t0,t1,t2,t3);}

C_noret_decl(trf_1977)
static void C_fcall trf_1977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1977(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1977(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2014)
static void C_fcall trf_2014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2014(t0,t1);}

C_noret_decl(trf_2598)
static void C_fcall trf_2598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2598(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2598(t0,t1,t2);}

C_noret_decl(trf_2580)
static void C_fcall trf_2580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2580(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2580(t0,t1,t2);}

C_noret_decl(trf_2492)
static void C_fcall trf_2492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2492(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2492(t0,t1,t2,t3);}

C_noret_decl(trf_2195)
static void C_fcall trf_2195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2195(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2195(t0,t1,t2);}

C_noret_decl(trf_2203)
static void C_fcall trf_2203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2203(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2203(t0,t1,t2);}

C_noret_decl(trf_2210)
static void C_fcall trf_2210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2210(t0,t1);}

C_noret_decl(trf_1807)
static void C_fcall trf_1807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1807(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1807(t0,t1,t2);}

C_noret_decl(trf_1856)
static void C_fcall trf_1856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1856(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1856(t0,t1,t2,t3);}

C_noret_decl(trf_1681)
static void C_fcall trf_1681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1681(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1681(t0,t1,t2);}

C_noret_decl(trf_1555)
static void C_fcall trf_1555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1555(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1555(t0,t1,t2);}

C_noret_decl(trf_1523)
static void C_fcall trf_1523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1523(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1523(t0,t1,t2,t3);}

C_noret_decl(trf_1107)
static void C_fcall trf_1107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1107(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_1107(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_1130)
static void C_fcall trf_1130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1130(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1130(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1352)
static void C_fcall trf_1352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1352(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1352(t0,t1);}

C_noret_decl(trf_1440)
static void C_fcall trf_1440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1440(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1440(t0,t1);}

C_noret_decl(trf_1039)
static void C_fcall trf_1039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1039(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1039(t0,t1,t2,t3);}

C_noret_decl(trf_1049)
static void C_fcall trf_1049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1049(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1049(t0,t1);}

C_noret_decl(trf_1061)
static void C_fcall trf_1061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1061(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1061(t0,t1);}

C_noret_decl(trf_1033)
static void C_fcall trf_1033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1033(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1033(t0,t1,t2);}

C_noret_decl(trf_1011)
static void C_fcall trf_1011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1011(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1011(t0,t1,t2);}

C_noret_decl(trf_928)
static void C_fcall trf_928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_928(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_928(t0,t1,t2,t3);}

C_noret_decl(trf_939)
static void C_fcall trf_939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_939(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_939(t0,t1,t2);}

C_noret_decl(trf_904)
static void C_fcall trf_904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_904(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_904(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_unboxing_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_unboxing_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("unboxing_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2127)){
C_save(t1);
C_rereclaim2(2127*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,230);
lf[0]=C_h_intern(&lf[0],1,"d");
lf[1]=C_h_intern(&lf[1],19,"\003sysstandard-output");
lf[2]=C_h_intern(&lf[2],19,"\003syswrite-char/port");
lf[3]=C_h_intern(&lf[3],7,"fprintf");
lf[4]=C_h_intern(&lf[4],7,"display");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\010[debug] ");
lf[6]=C_h_intern(&lf[6],26,"\010compilerperform-unboxing!");
lf[7]=C_h_intern(&lf[7],19,"\003sysundefined-value");
lf[8]=C_h_intern(&lf[8],10,"alist-cons");
lf[9]=C_h_intern(&lf[9],6,"gensym");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\002tu");
lf[11]=C_h_intern(&lf[11],9,"alist-ref");
lf[12]=C_h_intern(&lf[12],3,"eq\077");
lf[13]=C_h_intern(&lf[13],19,"\010compilercopy-node!");
lf[14]=C_h_intern(&lf[14],4,"node");
lf[15]=C_h_intern(&lf[15],19,"\004coreinline_unboxed");
lf[16]=C_h_intern(&lf[16],16,"\004corelet_unboxed");
lf[17]=C_h_intern(&lf[17],6,"flonum");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\014C_a_i_flonum");
lf[19]=C_h_intern(&lf[19],16,"\004coreunboxed_ref");
lf[20]=C_h_intern(&lf[20],20,"\004coreinline_allocate");
lf[21]=C_h_intern(&lf[21],7,"pointer");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\016C_a_i_mpointer");
lf[23]=C_h_intern(&lf[23],4,"char");
lf[24]=C_h_intern(&lf[24],6,"fixnum");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\020C_make_character");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\005C_fix");
lf[27]=C_h_intern(&lf[27],11,"\004coreinline");
lf[28]=C_h_intern(&lf[28],4,"bool");
lf[29]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\011C_mk_bool\376\377\016");
lf[30]=C_h_intern(&lf[30],1,"*");
lf[31]=C_h_intern(&lf[31],13,"\010compilerbomb");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000&unboxed type `*\047 not allowed as result");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\024invalid unboxed type");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\002tu");
lf[35]=C_h_intern(&lf[35],7,"reverse");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\020C_character_code");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\007C_unfix");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\022C_flonum_magnitude");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\021C_pointer_address");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\007C_truep");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\004C_id");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\035invalid unboxed argument type");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\002tu");
lf[44]=C_h_intern(&lf[44],19,"\003syshash-table-set!");
lf[45]=C_h_intern(&lf[45],18,"\003syshash-table-ref");
lf[46]=C_h_intern(&lf[46],18,"\010compilersymbolify");
lf[47]=C_h_intern(&lf[47],20,"node-parameters-set!");
lf[48]=C_h_intern(&lf[48],15,"node-class-set!");
lf[49]=C_h_intern(&lf[49],3,"let");
lf[50]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003let\376\003\000\000\002\376\001\000\000\020\004corelet_unboxed\376\377\016");
lf[51]=C_h_intern(&lf[51],3,"any");
lf[52]=C_h_intern(&lf[52],14,"\004coreundefined");
lf[53]=C_h_intern(&lf[53],11,"\004corelambda");
lf[54]=C_h_intern(&lf[54],18,"\004coredirect_lambda");
lf[55]=C_h_intern(&lf[55],4,"cons");
lf[56]=C_h_intern(&lf[56],7,"\003sysmap");
lf[57]=C_h_intern(&lf[57],30,"\010compilerdecompose-lambda-list");
lf[58]=C_h_intern(&lf[58],13,"\004corevariable");
lf[59]=C_h_intern(&lf[59],7,"\003sysget");
lf[60]=C_h_intern(&lf[60],19,"\010compilerunboxed-op");
lf[61]=C_h_intern(&lf[61],4,"set!");
lf[62]=C_h_intern(&lf[62],17,"\004coreunboxed_set!");
lf[63]=C_h_intern(&lf[63],5,"quote");
lf[64]=C_h_intern(&lf[64],2,"if");
lf[65]=C_h_intern(&lf[65],9,"\004corecond");
lf[66]=C_h_intern(&lf[66],11,"\004coreswitch");
lf[67]=C_h_intern(&lf[67],4,"none");
lf[68]=C_h_intern(&lf[68],9,"\004corecall");
lf[69]=C_h_intern(&lf[69],16,"\004coredirect_call");
lf[70]=C_h_intern(&lf[70],12,"\003sysfor-each");
lf[71]=C_h_intern(&lf[71],9,"\004coreproc");
lf[72]=C_h_intern(&lf[72],15,"\004coreglobal-ref");
lf[73]=C_h_intern(&lf[73],15,"\004coreinline_ref");
lf[74]=C_h_intern(&lf[74],19,"\004coreinline_loc_ref");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[76]=C_h_intern(&lf[76],23,"\003syshash-table-for-each");
lf[77]=C_h_intern(&lf[77],18,"\010compilerdebugging");
lf[78]=C_h_intern(&lf[78],1,"x");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\021unboxed rewrites:");
lf[80]=C_h_intern(&lf[80],11,"make-vector");
lf[81]=C_h_intern(&lf[81],28,"\010compilerregister-unboxed-op");
lf[82]=C_h_intern(&lf[82],8,"\003sysput!");
lf[83]=C_h_intern(&lf[83],15,"C_null_pointerp");
lf[84]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\377\016");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\024C_ub_i_null_pointerp");
lf[86]=C_h_intern(&lf[86],21,"C_u_i_pointer_f64_set");
lf[87]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\026C_ub_i_pointer_f64_ref");
lf[89]=C_h_intern(&lf[89],21,"C_u_i_pointer_f32_set");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\026C_ub_i_pointer_f32_ref");
lf[92]=C_h_intern(&lf[92],21,"C_u_i_pointer_s32_set");
lf[93]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\006fixnum\376\377\016");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\026C_ub_i_pointer_s32_ref");
lf[95]=C_h_intern(&lf[95],21,"C_u_i_pointer_u32_set");
lf[96]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\006fixnum\376\377\016");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\026C_ub_i_pointer_u32_ref");
lf[98]=C_h_intern(&lf[98],21,"C_u_i_pointer_s16_set");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\006fixnum\376\377\016");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\026C_ub_i_pointer_s16_ref");
lf[101]=C_h_intern(&lf[101],21,"C_u_i_pointer_u16_set");
lf[102]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\006fixnum\376\377\016");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\026C_ub_i_pointer_u16_ref");
lf[104]=C_h_intern(&lf[104],20,"C_u_i_pointer_s8_set");
lf[105]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\006fixnum\376\377\016");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\025C_ub_i_pointer_s8_ref");
lf[107]=C_h_intern(&lf[107],20,"C_u_i_pointer_u8_set");
lf[108]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\006fixnum\376\377\016");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\025C_ub_i_pointer_u8_ref");
lf[110]=C_h_intern(&lf[110],21,"C_u_i_pointer_f64_ref");
lf[111]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\377\016");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\026C_ub_i_pointer_f64_ref");
lf[113]=C_h_intern(&lf[113],21,"C_u_i_pointer_f32_ref");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\377\016");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\026C_ub_i_pointer_f32_ref");
lf[116]=C_h_intern(&lf[116],21,"C_u_i_pointer_s32_ref");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\377\016");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\026C_ub_i_pointer_s32_ref");
lf[119]=C_h_intern(&lf[119],21,"C_u_i_pointer_u32_ref");
lf[120]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\377\016");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\026C_ub_i_pointer_u32_ref");
lf[122]=C_h_intern(&lf[122],21,"C_u_i_pointer_s16_ref");
lf[123]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\377\016");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\026C_ub_i_pointer_s16_ref");
lf[125]=C_h_intern(&lf[125],21,"C_u_i_pointer_u16_ref");
lf[126]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\377\016");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\026C_ub_i_pointer_u16_ref");
lf[128]=C_h_intern(&lf[128],20,"C_u_i_pointer_s8_ref");
lf[129]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\377\016");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\025C_ub_i_pointer_s8_ref");
lf[131]=C_h_intern(&lf[131],20,"C_u_i_pointer_u8_ref");
lf[132]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\377\016");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\025C_ub_i_pointer_u8_ref");
lf[134]=C_h_intern(&lf[134],13,"C_pointer_eqp");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\007pointer\376\377\016");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\022C_ub_i_pointer_eqp");
lf[137]=C_h_intern(&lf[137],19,"C_a_u_i_pointer_inc");
lf[138]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\006fixnum\376\377\016");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\022C_ub_i_pointer_inc");
lf[140]=C_h_intern(&lf[140],24,"C_flonum_less_or_equal_p");
lf[141]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\035C_ub_i_flonum_less_or_equal_p");
lf[143]=C_h_intern(&lf[143],27,"C_flonum_greater_or_equal_p");
lf[144]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000 C_ub_i_flonum_greater_or_equal_p");
lf[146]=C_h_intern(&lf[146],14,"C_flonum_lessp");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\023C_ub_i_flonum_lessp");
lf[149]=C_h_intern(&lf[149],17,"C_flonum_greaterp");
lf[150]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\026C_ub_i_flonum_greaterp");
lf[152]=C_h_intern(&lf[152],15,"C_flonum_equalp");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\024C_ub_i_flonum_equalp");
lf[155]=C_h_intern(&lf[155],16,"C_u_i_fpintegerp");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\021C_ub_i_fpintegerp");
lf[158]=C_h_intern(&lf[158],19,"C_a_i_f64vector_ref");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\006fixnum\376\377\016");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\024C_ub_i_f64vector_ref");
lf[161]=C_h_intern(&lf[161],19,"C_a_i_f32vector_ref");
lf[162]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\006fixnum\376\377\016");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\024C_ub_i_f32vector_ref");
lf[164]=C_h_intern(&lf[164],19,"C_u_i_f64vector_set");
lf[165]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\024C_ub_i_f64vector_set");
lf[167]=C_h_intern(&lf[167],19,"C_u_i_f32vector_set");
lf[168]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\024C_ub_i_f32vector_set");
lf[170]=C_h_intern(&lf[170],18,"C_a_i_flonum_round");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\007C_round");
lf[173]=C_h_intern(&lf[173],18,"C_a_i_flonum_floor");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\007C_floor");
lf[176]=C_h_intern(&lf[176],20,"C_a_i_flonum_ceiling");
lf[177]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ceil");
lf[179]=C_h_intern(&lf[179],21,"C_a_i_flonum_truncate");
lf[180]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\007C_trunc");
lf[182]=C_h_intern(&lf[182],16,"C_a_i_flonum_abs");
lf[183]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fabs");
lf[185]=C_h_intern(&lf[185],17,"C_a_i_flonum_sqrt");
lf[186]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\006C_sqrt");
lf[188]=C_h_intern(&lf[188],16,"C_a_i_flonum_log");
lf[189]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\005C_log");
lf[191]=C_h_intern(&lf[191],17,"C_a_i_flonum_expt");
lf[192]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\005C_pow");
lf[194]=C_h_intern(&lf[194],16,"C_a_i_flonum_exp");
lf[195]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\005C_exp");
lf[197]=C_h_intern(&lf[197],18,"C_a_i_flonum_atan2");
lf[198]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\007C_atan2");
lf[200]=C_h_intern(&lf[200],17,"C_a_i_flonum_atan");
lf[201]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\006C_atan");
lf[203]=C_h_intern(&lf[203],17,"C_a_i_flonum_acos");
lf[204]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\006C_acos");
lf[206]=C_h_intern(&lf[206],17,"C_a_i_flonum_asin");
lf[207]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\006C_asin");
lf[209]=C_h_intern(&lf[209],16,"C_a_i_flonum_tan");
lf[210]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\005C_tab");
lf[212]=C_h_intern(&lf[212],16,"C_a_i_flonum_cos");
lf[213]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\005C_cos");
lf[215]=C_h_intern(&lf[215],16,"C_a_i_flonum_sin");
lf[216]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\005C_sin");
lf[218]=C_h_intern(&lf[218],21,"C_a_i_flonum_quotient");
lf[219]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\026C_ub_i_flonum_quotient");
lf[221]=C_h_intern(&lf[221],18,"C_a_i_flonum_times");
lf[222]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\023C_ub_i_flonum_times");
lf[224]=C_h_intern(&lf[224],23,"C_a_i_flonum_difference");
lf[225]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\030C_ub_i_flonum_difference");
lf[227]=C_h_intern(&lf[227],17,"C_a_i_flonum_plus");
lf[228]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006flonum\376\003\000\000\002\376\001\000\000\006flonum\376\377\016");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\022C_ub_i_flonum_plus");
C_register_lf2(lf,230,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_872,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k870 */
static void C_ccall f_872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_875,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k873 in k870 */
static void C_ccall f_875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_875,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! d ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_877,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[6]+1 /* (set! ##compiler#perform-unboxing! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_895,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[81]+1 /* (set! ##compiler#register-unboxed-op ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2682,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t5,lf[227],lf[228],lf[17],lf[229]);}

/* k2695 in k873 in k870 */
static void C_ccall f_2697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2700,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[224],lf[225],lf[17],lf[226]);}

/* k2698 in k2695 in k873 in k870 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2703,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[221],lf[222],lf[17],lf[223]);}

/* k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2706,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[218],lf[219],lf[17],lf[220]);}

/* k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2709,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[215],lf[216],lf[17],lf[217]);}

/* k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2712,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[212],lf[213],lf[17],lf[214]);}

/* k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2715,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[209],lf[210],lf[17],lf[211]);}

/* k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2718,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[206],lf[207],lf[17],lf[208]);}

/* k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2721,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[203],lf[204],lf[17],lf[205]);}

/* k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2724,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[200],lf[201],lf[17],lf[202]);}

/* k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2727,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[197],lf[198],lf[17],lf[199]);}

/* k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2730,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[194],lf[195],lf[17],lf[196]);}

/* k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2733,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[191],lf[192],lf[17],lf[193]);}

/* k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2736,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[188],lf[189],lf[17],lf[190]);}

/* k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2739,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[185],lf[186],lf[17],lf[187]);}

/* k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2742,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[182],lf[183],lf[17],lf[184]);}

/* k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2745,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[179],lf[180],lf[17],lf[181]);}

/* k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2748,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[176],lf[177],lf[17],lf[178]);}

/* k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2751,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[173],lf[174],lf[17],lf[175]);}

/* k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2754,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[170],lf[171],lf[17],lf[172]);}

/* k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2757,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[167],lf[168],lf[24],lf[169]);}

/* k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2760,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[164],lf[165],lf[24],lf[166]);}

/* k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2763,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[161],lf[162],lf[17],lf[163]);}

/* k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2766,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[158],lf[159],lf[17],lf[160]);}

/* k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2769,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[155],lf[156],lf[28],lf[157]);}

/* k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2772,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[152],lf[153],lf[28],lf[154]);}

/* k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2775,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[149],lf[150],lf[28],lf[151]);}

/* k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2778,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[146],lf[147],lf[28],lf[148]);}

/* k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2781,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[143],lf[144],lf[28],lf[145]);}

/* k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[140],lf[141],lf[28],lf[142]);}

/* k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2787,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[137],lf[138],lf[21],lf[139]);}

/* k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2790,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[134],lf[135],lf[28],lf[136]);}

/* k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[131],lf[132],lf[24],lf[133]);}

/* k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[128],lf[129],lf[24],lf[130]);}

/* k2794 in k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[125],lf[126],lf[24],lf[127]);}

/* k2797 in k2794 in k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2802,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[122],lf[123],lf[24],lf[124]);}

/* k2800 in k2797 in k2794 in k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2805,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[119],lf[120],lf[24],lf[121]);}

/* k2803 in k2800 in k2797 in k2794 in k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2808,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[116],lf[117],lf[24],lf[118]);}

/* k2806 in k2803 in k2800 in k2797 in k2794 in k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2811,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[113],lf[114],lf[17],lf[115]);}

/* k2809 in k2806 in k2803 in k2800 in k2797 in k2794 in k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2814,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[110],lf[111],lf[17],lf[112]);}

/* k2812 in k2809 in k2806 in k2803 in k2800 in k2797 in k2794 in k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2817,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[107],lf[108],lf[24],lf[109]);}

/* k2815 in k2812 in k2809 in k2806 in k2803 in k2800 in k2797 in k2794 in k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2820,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[104],lf[105],lf[24],lf[106]);}

/* k2818 in k2815 in k2812 in k2809 in k2806 in k2803 in k2800 in k2797 in k2794 in k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2823,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[101],lf[102],lf[24],lf[103]);}

/* k2821 in k2818 in k2815 in k2812 in k2809 in k2806 in k2803 in k2800 in k2797 in k2794 in k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2826,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[98],lf[99],lf[24],lf[100]);}

/* k2824 in k2821 in k2818 in k2815 in k2812 in k2809 in k2806 in k2803 in k2800 in k2797 in k2794 in k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2829,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[95],lf[96],lf[24],lf[97]);}

/* k2827 in k2824 in k2821 in k2818 in k2815 in k2812 in k2809 in k2806 in k2803 in k2800 in k2797 in k2794 in k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2832,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[92],lf[93],lf[24],lf[94]);}

/* k2830 in k2827 in k2824 in k2821 in k2818 in k2815 in k2812 in k2809 in k2806 in k2803 in k2800 in k2797 in k2794 in k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2835,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[89],lf[90],lf[17],lf[91]);}

/* k2833 in k2830 in k2827 in k2824 in k2821 in k2818 in k2815 in k2812 in k2809 in k2806 in k2803 in k2800 in k2797 in k2794 in k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2838,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[86],lf[87],lf[17],lf[88]);}

/* k2836 in k2833 in k2830 in k2827 in k2824 in k2821 in k2818 in k2815 in k2812 in k2809 in k2806 in k2803 in k2800 in k2797 in k2794 in k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2841,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##compiler#register-unboxed-op */
((C_proc6)C_retrieve_proc(*((C_word*)lf[81]+1)))(6,*((C_word*)lf[81]+1),t2,lf[83],lf[84],lf[28],lf[85]);}

/* k2839 in k2836 in k2833 in k2830 in k2827 in k2824 in k2821 in k2818 in k2815 in k2812 in k2809 in k2806 in k2803 in k2800 in k2797 in k2794 in k2791 in k2788 in k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in k2749 in k2746 in k2743 in k2740 in k2737 in k2734 in k2731 in k2728 in k2725 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 in k2704 in k2701 in k2698 in k2695 in k873 in k870 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##compiler#register-unboxed-op in k873 in k870 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2682,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2690,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* unboxing.scm: 392  symbolify */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t6,t2);}

/* k2688 in ##compiler#register-unboxed-op in k873 in k870 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2690,2,t0,t1);}
t2=C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
/* unboxing.scm: 392  ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[82]))(5,*((C_word*)lf[82]+1),((C_word*)t0)[2],t1,lf[60],t2);}

/* ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_895(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_895,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_899,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* unboxing.scm: 42   make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[80]+1)))(4,*((C_word*)lf[80]+1),t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_899,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_901,a[2]=t5,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2650,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* unboxing.scm: 377  walk-lambda */
t8=((C_word*)t5)[1];
f_901(t8,t7,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* k2648 in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2656,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* unboxing.scm: 379  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t2,lf[78],lf[79]);}
else{
t3=t2;
f_2656(2,t3,C_SCHEME_FALSE);}}

/* k2654 in k2648 in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2656,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2661,tmp=(C_word)a,a+=2,tmp);
/* unboxing.scm: 380  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[76]))(4,*((C_word*)lf[76]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* a2660 in k2654 in k2648 in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2661,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[1]+1);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2665,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t5,lf[75],t4);}

/* k2663 in a2660 in k2654 in k2648 in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2668,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2666 in k2663 in a2660 in k2654 in k2648 in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(9),((C_word*)t0)[3]);}

/* k2669 in k2666 in k2663 in a2660 in k2654 in k2648 in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2672 in k2669 in k2666 in k2663 in a2660 in k2654 in k2648 in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_901(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word ab[92],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_901,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_904,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t34=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_928,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t35=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_990,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t36=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1002,tmp=(C_word)a,a+=2,tmp));
t37=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1011,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t38=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1033,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t39=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1039,a[2]=t16,tmp=(C_word)a,a+=3,tmp));
t40=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1107,a[2]=((C_word*)t0)[3],a[3]=t26,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t41=C_set_block_item(t24,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1523,a[2]=t18,a[3]=t26,tmp=(C_word)a,a+=4,tmp));
t42=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1555,a[2]=t26,tmp=(C_word)a,a+=3,tmp));
t43=C_set_block_item(t28,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1681,a[2]=t28,a[3]=t26,tmp=(C_word)a,a+=4,tmp));
t44=C_set_block_item(t30,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1807,a[2]=t30,tmp=(C_word)a,a+=3,tmp));
t45=C_set_block_item(t32,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1977,a[2]=t30,a[3]=t28,a[4]=t20,a[5]=t16,a[6]=t26,a[7]=t24,a[8]=t32,a[9]=t14,a[10]=t12,a[11]=t10,a[12]=t22,a[13]=t8,a[14]=t18,a[15]=t4,a[16]=((C_word*)t0)[2],tmp=(C_word)a,a+=17,tmp));
t46=C_retrieve(lf[7]);
t47=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2644,a[2]=t3,a[3]=t1,a[4]=t32,tmp=(C_word)a,a+=5,tmp);
/* unboxing.scm: 374  walk */
t48=((C_word*)t32)[1];
f_1977(t48,t47,t3,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k2642 in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* unboxing.scm: 375  walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1977(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_1977(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1977,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=C_slot(t6,C_fix(3));
t8=t2;
t9=C_slot(t8,C_fix(2));
t10=t2;
t11=C_slot(t10,C_fix(1));
t12=C_retrieve(lf[7]);
t13=C_eqp(t11,lf[52]);
t14=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t3,a[14]=((C_word*)t0)[13],a[15]=t4,a[16]=((C_word*)t0)[14],a[17]=t2,a[18]=((C_word*)t0)[15],a[19]=((C_word*)t0)[16],a[20]=t7,a[21]=t5,a[22]=t9,a[23]=t11,a[24]=t1,tmp=(C_word)a,a+=25,tmp);
if(C_truep(t13)){
t15=t14;
f_2014(t15,t13);}
else{
t15=C_eqp(t11,lf[71]);
if(C_truep(t15)){
t16=t14;
f_2014(t16,t15);}
else{
t16=C_eqp(t11,lf[72]);
if(C_truep(t16)){
t17=t14;
f_2014(t17,t16);}
else{
t17=C_eqp(t11,lf[73]);
t18=t14;
f_2014(t18,(C_truep(t17)?t17:C_eqp(t11,lf[74])));}}}}

/* k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_2014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2014,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[24];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[23],lf[53]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[23],lf[54]));
if(C_truep(t3)){
t4=C_i_caddr(((C_word*)t0)[22]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2032,a[2]=((C_word*)t0)[19],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[22],a[5]=((C_word*)t0)[21],tmp=(C_word)a,a+=6,tmp);
/* unboxing.scm: 263  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),((C_word*)t0)[24],t4,t5);}
else{
t4=C_eqp(((C_word*)t0)[23],lf[58]);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[22]);
t6=C_i_assq(t5,((C_word*)((C_word*)t0)[18])[1]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2072,a[2]=t6,a[3]=((C_word*)t0)[24],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[21])){
t8=(C_truep(t6)?C_i_cdr(t6):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2098,a[2]=((C_word*)t0)[17],a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* unboxing.scm: 279  alias */
t10=((C_word*)((C_word*)t0)[16])[1];
f_1033(t10,t9,t5);}
else{
t9=((C_word*)t0)[24];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t6);}}
else{
if(C_truep(t6)){
t8=((C_word*)t0)[15];
if(C_truep(t8)){
t9=((C_word*)t0)[24];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t6);}
else{
/* unboxing.scm: 282  boxed! */
t9=((C_word*)((C_word*)t0)[14])[1];
f_904(t9,t7,t5);}}
else{
t8=((C_word*)t0)[24];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t6);}}}
else{
t5=C_eqp(((C_word*)t0)[23],lf[27]);
t6=(C_truep(t5)?t5:C_eqp(((C_word*)t0)[23],lf[20]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2132,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[20],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[18],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[24],a[12]=((C_word*)t0)[21],tmp=(C_word)a,a+=13,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2266,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=C_i_car(((C_word*)t0)[22]);
/* unboxing.scm: 286  symbolify */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t8,t9);}
else{
t7=C_eqp(((C_word*)t0)[23],lf[49]);
if(C_truep(t7)){
t8=C_i_car(((C_word*)t0)[22]);
t9=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2282,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[22],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[20],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[17],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[18],a[12]=t8,a[13]=((C_word*)t0)[21],a[14]=((C_word*)t0)[24],tmp=(C_word)a,a+=15,tmp);
t10=C_i_car(((C_word*)t0)[20]);
/* unboxing.scm: 316  walk */
t11=((C_word*)((C_word*)t0)[8])[1];
f_1977(t11,t9,t10,t8,C_SCHEME_TRUE,((C_word*)t0)[21]);}
else{
t8=C_eqp(((C_word*)t0)[23],lf[61]);
if(C_truep(t8)){
t9=C_i_car(((C_word*)t0)[22]);
t10=C_i_assq(t9,((C_word*)((C_word*)t0)[18])[1]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2359,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[11],a[5]=t9,a[6]=((C_word*)t0)[16],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[20],a[9]=t10,a[10]=((C_word*)t0)[21],a[11]=((C_word*)t0)[24],tmp=(C_word)a,a+=12,tmp);
t12=C_i_car(((C_word*)t0)[20]);
if(C_truep(t10)){
t13=C_i_cdr(t10);
/* unboxing.scm: 330  walk */
t14=((C_word*)((C_word*)t0)[8])[1];
f_1977(t14,t11,t12,t9,t13,((C_word*)t0)[21]);}
else{
/* unboxing.scm: 330  walk */
t13=((C_word*)((C_word*)t0)[8])[1];
f_1977(t13,t11,t12,t9,C_SCHEME_FALSE,((C_word*)t0)[21]);}}
else{
t9=C_eqp(((C_word*)t0)[23],lf[63]);
if(C_truep(t9)){
t10=((C_word*)t0)[24];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
else{
t10=C_eqp(((C_word*)t0)[23],lf[64]);
t11=(C_truep(t10)?t10:C_eqp(((C_word*)t0)[23],lf[65]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2446,a[2]=((C_word*)t0)[17],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[21],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[20],a[9]=((C_word*)t0)[24],a[10]=((C_word*)t0)[4],tmp=(C_word)a,a+=11,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2470,a[2]=t12,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t14=C_i_car(((C_word*)t0)[20]);
/* unboxing.scm: 347  walk */
t15=((C_word*)((C_word*)t0)[8])[1];
f_1977(t15,t13,t14,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[21]);}
else{
t12=C_eqp(((C_word*)t0)[23],lf[66]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2483,a[2]=((C_word*)t0)[24],a[3]=((C_word*)t0)[21],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[20],tmp=(C_word)a,a+=9,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2550,a[2]=t13,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t15=C_i_car(((C_word*)t0)[20]);
/* unboxing.scm: 354  walk */
t16=((C_word*)((C_word*)t0)[8])[1];
f_1977(t16,t14,t15,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[21]);}
else{
t13=C_eqp(((C_word*)t0)[23],lf[68]);
t14=(C_truep(t13)?t13:C_eqp(((C_word*)t0)[23],lf[69]));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2566,a[2]=((C_word*)t0)[17],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[21],a[5]=((C_word*)t0)[24],tmp=(C_word)a,a+=6,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2574,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[21],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t17=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t15,t16,((C_word*)t0)[20]);}
else{
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2590,a[2]=((C_word*)t0)[24],tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2592,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[21],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t17=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t15,t16,((C_word*)t0)[20]);}}}}}}}}}}}

/* a2591 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2592(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2592,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2605,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* g698699 */
t5=t3;
f_2598(t5,t4,t2);}

/* k2603 in a2591 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* invalidate84 */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1011(t2,((C_word*)t0)[2],t1);}

/* g698 in a2591 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_2598(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2598,NULL,3,t0,t1,t2);}
/* g707708 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1977(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k2588 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* a2573 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2574,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2580,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2587,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* g674675 */
t5=t3;
f_2580(t5,t4,t2);}

/* k2585 in a2573 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* invalidate84 */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1011(t2,((C_word*)t0)[2],t1);}

/* g674 in a2573 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_2580(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2580,NULL,3,t0,t1,t2);}
/* g683684 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1977(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k2564 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2569,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[4])){
/* unboxing.scm: 366  straighten-call! */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1807(t3,t2,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2567 in k2564 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k2548 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* unboxing.scm: 354  invalidate */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1011(t2,((C_word*)t0)[2],t1);}

/* k2481 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2483,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[8]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2492,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_2492(t6,((C_word*)t0)[2],t2,lf[67]);}

/* doloop652 in k2481 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_2492(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2492,NULL,4,t0,t1,t2,t3);}
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2506,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=C_i_car(t2);
/* unboxing.scm: 361  walk */
t7=((C_word*)((C_word*)t0)[6])[1];
f_1977(t7,t5,t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t5=C_i_cddr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2521,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t7=C_eqp(t3,lf[67]);
if(C_truep(t7)){
t8=C_i_cadr(t2);
/* unboxing.scm: 358  walk */
t9=((C_word*)((C_word*)t0)[6])[1];
f_1977(t9,t6,t8,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2538,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t9=C_i_cadr(t2);
/* unboxing.scm: 359  walk */
t10=((C_word*)((C_word*)t0)[6])[1];
f_1977(t10,t8,t9,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k2536 in doloop652 in k2481 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* unboxing.scm: 359  merge */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1039(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2519 in doloop652 in k2481 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2492(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2504 in doloop652 in k2481 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* unboxing.scm: 361  merge */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1039(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2468 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* unboxing.scm: 347  invalidate */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1011(t2,((C_word*)t0)[2],t1);}

/* k2444 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2449,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* unboxing.scm: 348  straighten-conditional! */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1681(t3,t2,((C_word*)t0)[2]);}

/* k2447 in k2444 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_i_cadr(((C_word*)t0)[6]);
/* unboxing.scm: 349  walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_1977(t4,t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2450 in k2447 in k2444 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2455,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=C_i_caddr(((C_word*)t0)[6]);
/* unboxing.scm: 350  walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_1977(t4,t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2453 in k2450 in k2447 in k2444 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* unboxing.scm: 351  merge */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1039(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2357 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2362,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=(C_truep(((C_word*)t0)[9])?C_i_cdr(((C_word*)t0)[9]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2388,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* unboxing.scm: 335  alias */
t5=((C_word*)((C_word*)t0)[6])[1];
f_1033(t5,t4,((C_word*)t0)[5]);}
else{
t4=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=(C_truep(t1)?C_i_cdr(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_i_cdr(t1);
/* unboxing.scm: 338  unboxed! */
t5=((C_word*)((C_word*)t0)[4])[1];
f_928(t5,t2,((C_word*)t0)[5],t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2411,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* unboxing.scm: 340  boxed! */
t5=((C_word*)((C_word*)t0)[2])[1];
f_904(t5,t4,((C_word*)t0)[5]);}}}

/* k2409 in k2357 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* unboxing.scm: 341  invalidate */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1011(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2386 in k2357 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2388,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_a_i_list(&a,2,t1,t2);
t4=C_a_i_record(&a,4,lf[14],lf[62],t3,((C_word*)t0)[4]);
/* unboxing.scm: 333  copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2360 in k2357 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k2280 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2285,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
t3=((C_word*)t0)[13];
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_truep(t1)?C_i_cdr(t1):C_SCHEME_FALSE));
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[3]);
t6=C_i_cdr(t1);
/* unboxing.scm: 318  unboxed! */
t7=((C_word*)((C_word*)t0)[2])[1];
f_928(t7,t2,t5,t6);}
else{
t5=t2;
f_2285(2,t5,C_SCHEME_UNDEFINED);}}

/* k2283 in k2280 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2288,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t3=C_i_cadr(((C_word*)t0)[5]);
/* unboxing.scm: 319  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1977(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[11]);}

/* k2286 in k2283 in k2280 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2291,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[7])){
t3=C_i_assq(((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t4=(C_truep(t3)?C_i_cdr(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_i_cdr(t3);
/* unboxing.scm: 323  rebind-unboxed! */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1523(t6,t2,((C_word*)t0)[3],t5);}
else{
/* unboxing.scm: 324  straighten-binding! */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1555(t5,t2,((C_word*)t0)[3]);}}
else{
t3=t1;
t4=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2289 in k2286 in k2283 in k2280 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2264 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* unboxing.scm: 286  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[59]))(4,*((C_word*)lf[59]+1),((C_word*)t0)[2],t1,lf[60]);}

/* k2130 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2135,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2258,a[2]=((C_word*)t0)[12],a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[6]);}

/* a2257 in k2130 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2258,3,t0,t1,t2);}
/* g546547 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1977(t3,t1,t2,C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2133 in k2130 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2135,2,t0,t1);}
t2=((C_word*)t0)[12];
if(C_truep(t2)){
t3=C_i_not(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_2150(2,t5,t3);}
else{
if(C_truep(((C_word*)t0)[9])){
t5=f_990(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[9]);
if(C_truep(t5)){
t6=t4;
f_2150(2,t6,t5);}
else{
/* unboxing.scm: 291  any */
((C_proc4)C_retrieve_symbol_proc(lf[51]))(4,*((C_word*)lf[51]+1),t4,((C_word*)((C_word*)t0)[2])[1],t1);}}
else{
/* unboxing.scm: 291  any */
((C_proc4)C_retrieve_symbol_proc(lf[51]))(4,*((C_word*)lf[51]+1),t4,((C_word*)((C_word*)t0)[2])[1],t1);}}}
else{
t3=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2148 in k2133 in k2130 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2150,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[11]);
t3=C_i_cadr(((C_word*)t0)[11]);
t4=C_i_caddr(((C_word*)t0)[11]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2162,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
if(C_truep(((C_word*)t0)[8])){
t6=C_i_assq(((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
/* unboxing.scm: 297  rewrite! */
t7=((C_word*)((C_word*)t0)[6])[1];
f_1107(t7,t5,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],t3,t4,t6);}
else{
/* unboxing.scm: 297  rewrite! */
t6=((C_word*)((C_word*)t0)[6])[1];
f_1107(t6,t5,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],t3,t4,C_SCHEME_FALSE);}}
else{
t6=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,C_SCHEME_FALSE,t4));}}
else{
t2=C_i_caddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2181,a[2]=t2,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,C_SCHEME_FALSE,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2187,a[2]=((C_word*)t0)[10],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2195,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_2195(t8,t4,((C_word*)t0)[3]);}}}

/* loop579 in k2148 in k2133 in k2130 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_2195(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2195,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2203,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2233,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g586587 */
t6=t3;
f_2203(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2231 in loop579 in k2148 in k2133 in k2130 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2195(t3,((C_word*)t0)[2],t2);}

/* g586 in loop579 in k2148 in k2133 in k2130 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_2203(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2203,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2210,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=C_i_car(t2);
t5=t3;
f_2210(t5,(C_truep(t4)?C_i_cdr(t2):C_SCHEME_FALSE));}
else{
t4=t3;
f_2210(t4,C_SCHEME_FALSE);}}

/* k2208 in g586 in loop579 in k2148 in k2133 in k2130 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_2210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[4]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* unboxing.scm: 308  unboxed! */
t4=((C_word*)((C_word*)t0)[3])[1];
f_928(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2185 in k2148 in k2133 in k2130 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2187,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
/* unboxing.scm: 311  unboxed! */
t2=((C_word*)((C_word*)t0)[5])[1];
f_928(t2,((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]));}}

/* k2179 in k2148 in k2133 in k2130 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2181,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[2]));}

/* k2160 in k2148 in k2133 in k2130 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2162,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[2]));}

/* k2096 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2098,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[4]);
t3=C_a_i_list(&a,2,t1,t2);
t4=C_a_i_record(&a,4,lf[14],lf[19],t3,C_SCHEME_END_OF_LIST);
/* unboxing.scm: 278  copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2070 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a2031 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2032,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2036,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_car(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2047,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2053,tmp=(C_word)a,a+=2,tmp);
/* map */
t9=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t2);}}

/* a2052 in a2031 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2053(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2053,3,t0,t1,t2);}
t3=*((C_word*)lf[55]+1);
/* g497498 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* k2045 in a2031 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(((C_word*)t0)[4]);
/* unboxing.scm: 267  walk-lambda */
t3=((C_word*)((C_word*)t0)[3])[1];
f_901(t3,((C_word*)t0)[2],t1,t2);}

/* k2034 in a2031 in k2012 in walk in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* straighten-call! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_1807(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1807,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t2;
t6=C_slot(t5,C_fix(3));
t7=t2;
t8=C_slot(t7,C_fix(2));
t9=C_i_car(t6);
t10=C_i_cdr(t6);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1841,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1844,a[2]=t1,a[3]=t10,a[4]=((C_word*)t0)[2],a[5]=t8,a[6]=t4,a[7]=t9,a[8]=t2,a[9]=t11,tmp=(C_word)a,a+=10,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1962,tmp=(C_word)a,a+=2,tmp);
/* unboxing.scm: 228  any */
((C_proc4)C_retrieve_symbol_proc(lf[51]))(4,*((C_word*)lf[51]+1),t12,t13,t10);}

/* a1961 in straighten-call! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1962,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_memq(t3,lf[50]));}

/* k1842 in straighten-call! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1844,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1854,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1856,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1856(t7,t3,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[8]);}}

/* loop in k1842 in straighten-call! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_1856(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1856,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1883,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* unboxing.scm: 235  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[35]+1)))(3,*((C_word*)lf[35]+1),t4,t3);}
else{
t4=C_i_car(t2);
t5=C_slot(t4,C_fix(1));
t6=C_slot(t4,C_fix(3));
if(C_truep((C_truep(C_eqp(t5,lf[49]))?C_SCHEME_TRUE:(C_truep(C_eqp(t5,lf[16]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=C_slot(t4,C_fix(2));
t8=C_i_car(t6);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1937,a[2]=t7,a[3]=t5,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=C_i_cdr(t2);
t11=C_i_cadr(t6);
t12=C_a_i_cons(&a,2,t11,t3);
/* unboxing.scm: 244  loop */
t17=t9;
t18=t10;
t19=t12;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t7=C_i_cdr(t2);
t8=C_a_i_cons(&a,2,t4,t3);
/* unboxing.scm: 245  loop */
t17=t1;
t18=t7;
t19=t8;
t1=t17;
t2=t18;
t3=t19;
goto loop;}}}

/* k1935 in loop in k1842 in straighten-call! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1937,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[14],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k1881 in loop in k1842 in straighten-call! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=C_a_i_record(&a,4,lf[14],((C_word*)t0)[5],((C_word*)t0)[4],t2);
/* unboxing.scm: 234  straighten-call! */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1807(t4,((C_word*)t0)[2],t3);}

/* k1852 in k1842 in straighten-call! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* unboxing.scm: 231  copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1839 in straighten-call! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* straighten-conditional! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_1681(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1681,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=C_i_car(t4);
t6=C_slot(t5,C_fix(1));
if(C_truep((C_truep(C_eqp(t6,lf[49]))?C_SCHEME_TRUE:(C_truep(C_eqp(t6,lf[16]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=C_retrieve(lf[7]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1713,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t9=C_slot(t5,C_fix(2));
t10=C_slot(t5,C_fix(3));
t11=C_i_car(t10);
t12=t2;
t13=C_slot(t12,C_fix(1));
t14=t2;
t15=C_slot(t14,C_fix(2));
t16=C_i_cadr(t10);
t17=C_i_cdr(t4);
t18=C_a_i_cons(&a,2,t16,t17);
t19=C_a_i_record(&a,4,lf[14],t13,t15,t18);
t20=C_a_i_list(&a,2,t11,t19);
t21=C_a_i_record(&a,4,lf[14],t6,t9,t20);
/* unboxing.scm: 205  copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t8,t21,t2);}
else{
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k1711 in straighten-conditional! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1716,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
t4=C_slot(t3,C_fix(3));
t5=C_i_cadr(t4);
/* unboxing.scm: 216  straighten-conditional! */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1681(t6,t2,t5);}

/* k1714 in k1711 in straighten-conditional! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* unboxing.scm: 218  straighten-binding! */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1555(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* straighten-binding! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_1555(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1555,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=C_i_car(t4);
t6=C_slot(t5,C_fix(1));
if(C_truep((C_truep(C_eqp(t6,lf[49]))?C_SCHEME_TRUE:(C_truep(C_eqp(t6,lf[16]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=C_retrieve(lf[7]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1587,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t9=C_slot(t5,C_fix(2));
t10=C_slot(t5,C_fix(3));
t11=C_i_car(t10);
t12=t2;
t13=C_slot(t12,C_fix(1));
t14=t2;
t15=C_slot(t14,C_fix(2));
t16=C_i_cadr(t10);
t17=C_i_cadr(t4);
t18=C_a_i_list(&a,2,t16,t17);
t19=C_a_i_record(&a,4,lf[14],t13,t15,t18);
t20=C_a_i_list(&a,2,t11,t19);
t21=C_a_i_record(&a,4,lf[14],t6,t9,t20);
/* unboxing.scm: 181  copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t8,t21,t2);}
else{
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k1585 in straighten-binding! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* unboxing.scm: 194  straighten-binding! */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1555(t3,t2,((C_word*)t0)[4]);}

/* k1588 in k1585 in straighten-binding! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[4];
t3=C_slot(t2,C_fix(3));
t4=C_i_cadr(t3);
/* unboxing.scm: 195  straighten-binding! */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1555(t5,((C_word*)t0)[2],t4);}

/* rebind-unboxed! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_1523(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1523,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1527,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=t2;
t6=C_slot(t5,C_fix(2));
t7=C_i_car(t6);
/* unboxing.scm: 168  alias */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1033(t8,t4,t7);}

/* k1525 in rebind-unboxed! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1530,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* unboxing.scm: 169  node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[48]))(4,*((C_word*)lf[48]+1),t2,((C_word*)t0)[3],lf[16]);}

/* k1528 in k1525 in rebind-unboxed! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1533,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* unboxing.scm: 170  node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,((C_word*)t0)[4],t3);}

/* k1531 in k1528 in k1525 in rebind-unboxed! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* unboxing.scm: 171  straighten-binding! */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1555(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* rewrite! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_1107(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1107,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=C_retrieve(lf[7]);
t10=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1114,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t4,a[5]=t5,a[6]=t7,a[7]=t8,a[8]=t3,a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[3],a[12]=((C_word*)t0)[4],tmp=(C_word)a,a+=13,tmp);
/* unboxing.scm: 98   symbolify */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t10,t3);}

/* k1112 in rewrite! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1114,2,t0,t1);}
t2=C_set_block_item(((C_word*)t0)[12],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1118,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1518,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* unboxing.scm: 101  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t4,((C_word*)t0)[2],t1);}

/* k1516 in k1112 in rewrite! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=C_fixnum_increase(t2);
/* unboxing.scm: 100  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
/* unboxing.scm: 100  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}}

/* k1116 in k1112 in rewrite! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1121,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1128,a[2]=((C_word*)t0)[8],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1130,a[2]=t5,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1130(t7,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k1116 in k1112 in rewrite! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_1130(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1130,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_nullp(t2))){
t6=C_a_i_list(&a,1,((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1343,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* unboxing.scm: 107  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[35]+1)))(3,*((C_word*)lf[35]+1),t7,t5);}
else{
t6=C_i_car(t4);
t7=C_eqp(t6,lf[30]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1352,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=t8;
f_1352(t9,t7);}
else{
t9=C_i_car(t2);
t10=t8;
f_1352(t10,(C_truep(t9)?C_i_cdr(t9):C_SCHEME_FALSE));}}}

/* k1350 in loop in k1116 in k1112 in rewrite! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_1352(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1352,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[7]);
t3=C_i_cdr(((C_word*)t0)[6]);
t4=C_i_cdr(((C_word*)t0)[5]);
t5=C_i_car(((C_word*)t0)[6]);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[4]);
/* unboxing.scm: 139  loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_1130(t7,((C_word*)t0)[2],t2,t3,t4,t6);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1378,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* unboxing.scm: 145  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t2,lf[43]);}}

/* k1376 in k1350 in loop in k1116 in k1112 in rewrite! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1378,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[7]);
t3=C_a_i_list(&a,2,t1,t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t5=C_i_car(((C_word*)t0)[7]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1455,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=C_eqp(t5,lf[23]);
if(C_truep(t7)){
t8=t4;
f_1440(t8,C_a_i_list(&a,1,lf[36]));}
else{
t8=C_eqp(t5,lf[24]);
if(C_truep(t8)){
t9=t4;
f_1440(t9,C_a_i_list(&a,1,lf[37]));}
else{
t9=C_eqp(t5,lf[17]);
if(C_truep(t9)){
t10=t4;
f_1440(t10,C_a_i_list(&a,1,lf[38]));}
else{
t10=C_eqp(t5,lf[21]);
if(C_truep(t10)){
t11=t4;
f_1440(t11,C_a_i_list(&a,1,lf[39]));}
else{
t11=C_eqp(t5,lf[28]);
if(C_truep(t11)){
t12=t4;
f_1440(t12,C_a_i_list(&a,1,lf[40]));}
else{
t12=C_eqp(t5,lf[30]);
if(C_truep(t12)){
t13=t4;
f_1440(t13,C_a_i_list(&a,1,lf[41]));}
else{
t13=C_i_car(((C_word*)t0)[7]);
/* unboxing.scm: 157  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t6,lf[42],t13);}}}}}}}

/* k1453 in k1376 in k1350 in loop in k1116 in k1112 in rewrite! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1455,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1440(t2,C_a_i_list(&a,1,t1));}

/* k1438 in k1376 in k1350 in loop in k1116 in k1112 in rewrite! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_1440(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1440,NULL,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[9]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_record(&a,4,lf[14],lf[27],t1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1407,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_i_cdr(((C_word*)t0)[6]);
t7=C_i_cdr(((C_word*)t0)[9]);
t8=C_i_cdr(((C_word*)t0)[5]);
t9=C_a_i_list(&a,1,((C_word*)t0)[4]);
t10=C_a_i_record(&a,4,lf[14],lf[19],t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t10,((C_word*)t0)[3]);
/* unboxing.scm: 159  loop */
t12=((C_word*)((C_word*)t0)[2])[1];
f_1130(t12,t5,t6,t7,t8,t11);}

/* k1405 in k1438 in k1376 in k1350 in loop in k1116 in k1112 in rewrite! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1407,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[14],lf[16],((C_word*)t0)[2],t2));}

/* k1341 in loop in k1116 in k1112 in rewrite! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1343,2,t0,t1);}
t2=C_a_i_record(&a,4,lf[14],lf[15],((C_word*)t0)[5],t1);
t3=(C_truep(((C_word*)t0)[4])?C_i_cdr(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1154,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* unboxing.scm: 110  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t4,lf[34]);}}

/* k1152 in k1341 in loop in k1116 in k1112 in rewrite! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[47],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1154,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1174,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=C_eqp(t3,lf[17]);
if(C_truep(t5)){
t6=C_a_i_list(&a,2,lf[18],C_fix(4));
t7=C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t8=C_a_i_record(&a,4,lf[14],lf[19],t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_list(&a,1,t8);
t10=C_a_i_record(&a,4,lf[14],lf[20],t6,t9);
t11=C_a_i_list(&a,2,((C_word*)t0)[3],t10);
t12=((C_word*)t0)[2];
t13=t12;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_record(&a,4,lf[14],lf[16],t2,t11));}
else{
t6=C_eqp(t3,lf[21]);
if(C_truep(t6)){
t7=C_a_i_list(&a,2,lf[22],C_fix(2));
t8=C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t9=C_a_i_record(&a,4,lf[14],lf[19],t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_list(&a,1,t9);
t11=C_a_i_record(&a,4,lf[14],lf[20],t7,t10);
t12=C_a_i_list(&a,2,((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];
t14=t13;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_a_i_record(&a,4,lf[14],lf[16],t2,t12));}
else{
t7=C_eqp(t3,lf[23]);
t8=(C_truep(t7)?t7:C_eqp(t3,lf[24]));
if(C_truep(t8)){
t9=C_eqp(((C_word*)t0)[4],lf[23]);
t10=(C_truep(t9)?C_a_i_list(&a,1,lf[25]):C_a_i_list(&a,1,lf[26]));
t11=C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t12=C_a_i_record(&a,4,lf[14],lf[19],t11,C_SCHEME_END_OF_LIST);
t13=C_a_i_list(&a,1,t12);
t14=C_a_i_record(&a,4,lf[14],lf[27],t10,t13);
t15=C_a_i_list(&a,2,((C_word*)t0)[3],t14);
t16=((C_word*)t0)[2];
t17=t16;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_a_i_record(&a,4,lf[14],lf[16],t2,t15));}
else{
t9=C_eqp(t3,lf[28]);
if(C_truep(t9)){
t10=C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t11=C_a_i_record(&a,4,lf[14],lf[19],t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_list(&a,1,t11);
t13=C_a_i_record(&a,4,lf[14],lf[27],lf[29],t12);
t14=C_a_i_list(&a,2,((C_word*)t0)[3],t13);
t15=((C_word*)t0)[2];
t16=t15;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_a_i_record(&a,4,lf[14],lf[16],t2,t14));}
else{
t10=C_eqp(t3,lf[30]);
if(C_truep(t10)){
/* unboxing.scm: 135  bomb */
((C_proc3)C_retrieve_symbol_proc(lf[31]))(3,*((C_word*)lf[31]+1),t4,lf[32]);}
else{
/* unboxing.scm: 136  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t4,lf[33],((C_word*)t0)[4]);}}}}}}

/* k1172 in k1152 in k1341 in loop in k1116 in k1112 in rewrite! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1174,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[14],lf[16],((C_word*)t0)[2],t2));}

/* k1126 in k1116 in k1112 in rewrite! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* unboxing.scm: 102  copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1119 in k1116 in k1112 in rewrite! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* unboxing.scm: 165  straighten-binding! */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1555(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* merge in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_1039(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1039,NULL,4,t0,t1,t2,t3);}
t4=C_i_not(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1049,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_1049(t6,t4);}
else{
t6=C_i_cdr(t2);
t7=t5;
f_1049(t7,C_i_not(t6));}}

/* k1047 in merge in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_1049(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1049,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1052,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* unboxing.scm: 86   invalidate */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1011(t3,t2,((C_word*)t0)[3]);}
else{
t2=C_i_not(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_1061(t4,t2);}
else{
t4=C_i_cdr(((C_word*)t0)[3]);
t5=t3;
f_1061(t5,C_i_not(t4));}}}

/* k1059 in k1047 in merge in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_1061(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1061,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1064,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* unboxing.scm: 89   invalidate */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1011(t3,t2,((C_word*)t0)[3]);}
else{
if(C_truep(C_i_equalp(((C_word*)t0)[3],((C_word*)t0)[2]))){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=C_eqp(t2,t3);
if(C_truep(t4)){
t5=C_i_cdr(((C_word*)t0)[3]);
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,C_SCHEME_FALSE,t5));}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* k1062 in k1059 in k1047 in merge in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k1050 in k1047 in merge in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* alias in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_1033(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1033,NULL,3,t0,t1,t2);}
/* unboxing.scm: 82   alist-ref */
((C_proc6)C_retrieve_symbol_proc(lf[11]))(6,*((C_word*)lf[11]+1),t1,t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[12]+1),t2);}

/* invalidate in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_1011(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1011,NULL,3,t0,t1,t2);}
t3=C_i_pairp(t2);
t4=(C_truep(t3)?C_i_car(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_i_car(t2);
/* unboxing.scm: 79   boxed! */
t6=((C_word*)((C_word*)t0)[2])[1];
f_904(t6,t1,t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* unboxed-value? in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1002,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_i_cdr(t2):C_SCHEME_FALSE));}

/* unboxed? in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static C_word C_fcall f_990(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_i_assq(t1,((C_word*)((C_word*)t0)[2])[1]);
return((C_truep(t2)?C_i_cdr(t2):C_SCHEME_FALSE));}

/* unboxed! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_928(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_928,NULL,4,t0,t1,t2,t3);}
t4=C_retrieve(lf[7]);
t5=C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_939,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* g118119 */
t7=t6;
f_939(t7,t1,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_980,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_988,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* unboxing.scm: 67   gensym */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t7,lf[10]);}}

/* k986 in unboxed! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* unboxing.scm: 67   alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[8]))(5,*((C_word*)lf[8]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k978 in unboxed! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_980,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_984,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* unboxing.scm: 68   alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[8]))(5,*((C_word*)lf[8]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k982 in k978 in unboxed! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* g118 in unboxed! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_939(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_939,NULL,3,t0,t1,t2);}
if(C_truep(C_i_cdr(t2))){
t3=C_i_cdr(t2);
t4=C_eqp(t3,((C_word*)t0)[4]);
t5=(C_truep(t4)?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_set_cdr(t2,t5));}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_959,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* unboxing.scm: 64   alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[8]))(5,*((C_word*)lf[8]+1),t6,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1]);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_973,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* unboxing.scm: 65   alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[8]))(5,*((C_word*)lf[8]+1),t3,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1]);}}

/* k971 in g118 in unboxed! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_set_cdr(((C_word*)((C_word*)t0)[2])[1],t1));}

/* k957 in g118 in unboxed! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* boxed! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_fcall f_904(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_904,NULL,3,t0,t1,t2);}
t3=C_retrieve(lf[7]);
t4=C_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(t4)){
t5=t1;
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_set_cdr(t4,C_SCHEME_FALSE));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_926,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* unboxing.scm: 54   alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[8]))(5,*((C_word*)lf[8]+1),t5,t2,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}}

/* k924 in boxed! in walk-lambda in k897 in ##compiler#perform-unboxing! in k873 in k870 */
static void C_ccall f_926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* d in k873 in k870 */
static void C_ccall f_877(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_877r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_877r(t0,t1,t2,t3);}}

static void C_ccall f_877r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
if(C_truep(C_fudge(C_fix(13)))){
t4=*((C_word*)lf[1]+1);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_887,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[4]+1)))(4,*((C_word*)lf[4]+1),t5,lf[5],t4);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k885 in d in k873 in k870 */
static void C_ccall f_887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_890,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t2,C_retrieve(lf[3]),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k888 in k885 in d in k873 in k870 */
static void C_ccall f_890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[2]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[168] = {
{"toplevel:unboxing_scm",(void*)C_unboxing_toplevel},
{"f_872:unboxing_scm",(void*)f_872},
{"f_875:unboxing_scm",(void*)f_875},
{"f_2697:unboxing_scm",(void*)f_2697},
{"f_2700:unboxing_scm",(void*)f_2700},
{"f_2703:unboxing_scm",(void*)f_2703},
{"f_2706:unboxing_scm",(void*)f_2706},
{"f_2709:unboxing_scm",(void*)f_2709},
{"f_2712:unboxing_scm",(void*)f_2712},
{"f_2715:unboxing_scm",(void*)f_2715},
{"f_2718:unboxing_scm",(void*)f_2718},
{"f_2721:unboxing_scm",(void*)f_2721},
{"f_2724:unboxing_scm",(void*)f_2724},
{"f_2727:unboxing_scm",(void*)f_2727},
{"f_2730:unboxing_scm",(void*)f_2730},
{"f_2733:unboxing_scm",(void*)f_2733},
{"f_2736:unboxing_scm",(void*)f_2736},
{"f_2739:unboxing_scm",(void*)f_2739},
{"f_2742:unboxing_scm",(void*)f_2742},
{"f_2745:unboxing_scm",(void*)f_2745},
{"f_2748:unboxing_scm",(void*)f_2748},
{"f_2751:unboxing_scm",(void*)f_2751},
{"f_2754:unboxing_scm",(void*)f_2754},
{"f_2757:unboxing_scm",(void*)f_2757},
{"f_2760:unboxing_scm",(void*)f_2760},
{"f_2763:unboxing_scm",(void*)f_2763},
{"f_2766:unboxing_scm",(void*)f_2766},
{"f_2769:unboxing_scm",(void*)f_2769},
{"f_2772:unboxing_scm",(void*)f_2772},
{"f_2775:unboxing_scm",(void*)f_2775},
{"f_2778:unboxing_scm",(void*)f_2778},
{"f_2781:unboxing_scm",(void*)f_2781},
{"f_2784:unboxing_scm",(void*)f_2784},
{"f_2787:unboxing_scm",(void*)f_2787},
{"f_2790:unboxing_scm",(void*)f_2790},
{"f_2793:unboxing_scm",(void*)f_2793},
{"f_2796:unboxing_scm",(void*)f_2796},
{"f_2799:unboxing_scm",(void*)f_2799},
{"f_2802:unboxing_scm",(void*)f_2802},
{"f_2805:unboxing_scm",(void*)f_2805},
{"f_2808:unboxing_scm",(void*)f_2808},
{"f_2811:unboxing_scm",(void*)f_2811},
{"f_2814:unboxing_scm",(void*)f_2814},
{"f_2817:unboxing_scm",(void*)f_2817},
{"f_2820:unboxing_scm",(void*)f_2820},
{"f_2823:unboxing_scm",(void*)f_2823},
{"f_2826:unboxing_scm",(void*)f_2826},
{"f_2829:unboxing_scm",(void*)f_2829},
{"f_2832:unboxing_scm",(void*)f_2832},
{"f_2835:unboxing_scm",(void*)f_2835},
{"f_2838:unboxing_scm",(void*)f_2838},
{"f_2841:unboxing_scm",(void*)f_2841},
{"f_2682:unboxing_scm",(void*)f_2682},
{"f_2690:unboxing_scm",(void*)f_2690},
{"f_895:unboxing_scm",(void*)f_895},
{"f_899:unboxing_scm",(void*)f_899},
{"f_2650:unboxing_scm",(void*)f_2650},
{"f_2656:unboxing_scm",(void*)f_2656},
{"f_2661:unboxing_scm",(void*)f_2661},
{"f_2665:unboxing_scm",(void*)f_2665},
{"f_2668:unboxing_scm",(void*)f_2668},
{"f_2671:unboxing_scm",(void*)f_2671},
{"f_2674:unboxing_scm",(void*)f_2674},
{"f_901:unboxing_scm",(void*)f_901},
{"f_2644:unboxing_scm",(void*)f_2644},
{"f_1977:unboxing_scm",(void*)f_1977},
{"f_2014:unboxing_scm",(void*)f_2014},
{"f_2592:unboxing_scm",(void*)f_2592},
{"f_2605:unboxing_scm",(void*)f_2605},
{"f_2598:unboxing_scm",(void*)f_2598},
{"f_2590:unboxing_scm",(void*)f_2590},
{"f_2574:unboxing_scm",(void*)f_2574},
{"f_2587:unboxing_scm",(void*)f_2587},
{"f_2580:unboxing_scm",(void*)f_2580},
{"f_2566:unboxing_scm",(void*)f_2566},
{"f_2569:unboxing_scm",(void*)f_2569},
{"f_2550:unboxing_scm",(void*)f_2550},
{"f_2483:unboxing_scm",(void*)f_2483},
{"f_2492:unboxing_scm",(void*)f_2492},
{"f_2538:unboxing_scm",(void*)f_2538},
{"f_2521:unboxing_scm",(void*)f_2521},
{"f_2506:unboxing_scm",(void*)f_2506},
{"f_2470:unboxing_scm",(void*)f_2470},
{"f_2446:unboxing_scm",(void*)f_2446},
{"f_2449:unboxing_scm",(void*)f_2449},
{"f_2452:unboxing_scm",(void*)f_2452},
{"f_2455:unboxing_scm",(void*)f_2455},
{"f_2359:unboxing_scm",(void*)f_2359},
{"f_2411:unboxing_scm",(void*)f_2411},
{"f_2388:unboxing_scm",(void*)f_2388},
{"f_2362:unboxing_scm",(void*)f_2362},
{"f_2282:unboxing_scm",(void*)f_2282},
{"f_2285:unboxing_scm",(void*)f_2285},
{"f_2288:unboxing_scm",(void*)f_2288},
{"f_2291:unboxing_scm",(void*)f_2291},
{"f_2266:unboxing_scm",(void*)f_2266},
{"f_2132:unboxing_scm",(void*)f_2132},
{"f_2258:unboxing_scm",(void*)f_2258},
{"f_2135:unboxing_scm",(void*)f_2135},
{"f_2150:unboxing_scm",(void*)f_2150},
{"f_2195:unboxing_scm",(void*)f_2195},
{"f_2233:unboxing_scm",(void*)f_2233},
{"f_2203:unboxing_scm",(void*)f_2203},
{"f_2210:unboxing_scm",(void*)f_2210},
{"f_2187:unboxing_scm",(void*)f_2187},
{"f_2181:unboxing_scm",(void*)f_2181},
{"f_2162:unboxing_scm",(void*)f_2162},
{"f_2098:unboxing_scm",(void*)f_2098},
{"f_2072:unboxing_scm",(void*)f_2072},
{"f_2032:unboxing_scm",(void*)f_2032},
{"f_2053:unboxing_scm",(void*)f_2053},
{"f_2047:unboxing_scm",(void*)f_2047},
{"f_2036:unboxing_scm",(void*)f_2036},
{"f_1807:unboxing_scm",(void*)f_1807},
{"f_1962:unboxing_scm",(void*)f_1962},
{"f_1844:unboxing_scm",(void*)f_1844},
{"f_1856:unboxing_scm",(void*)f_1856},
{"f_1937:unboxing_scm",(void*)f_1937},
{"f_1883:unboxing_scm",(void*)f_1883},
{"f_1854:unboxing_scm",(void*)f_1854},
{"f_1841:unboxing_scm",(void*)f_1841},
{"f_1681:unboxing_scm",(void*)f_1681},
{"f_1713:unboxing_scm",(void*)f_1713},
{"f_1716:unboxing_scm",(void*)f_1716},
{"f_1555:unboxing_scm",(void*)f_1555},
{"f_1587:unboxing_scm",(void*)f_1587},
{"f_1590:unboxing_scm",(void*)f_1590},
{"f_1523:unboxing_scm",(void*)f_1523},
{"f_1527:unboxing_scm",(void*)f_1527},
{"f_1530:unboxing_scm",(void*)f_1530},
{"f_1533:unboxing_scm",(void*)f_1533},
{"f_1107:unboxing_scm",(void*)f_1107},
{"f_1114:unboxing_scm",(void*)f_1114},
{"f_1518:unboxing_scm",(void*)f_1518},
{"f_1118:unboxing_scm",(void*)f_1118},
{"f_1130:unboxing_scm",(void*)f_1130},
{"f_1352:unboxing_scm",(void*)f_1352},
{"f_1378:unboxing_scm",(void*)f_1378},
{"f_1455:unboxing_scm",(void*)f_1455},
{"f_1440:unboxing_scm",(void*)f_1440},
{"f_1407:unboxing_scm",(void*)f_1407},
{"f_1343:unboxing_scm",(void*)f_1343},
{"f_1154:unboxing_scm",(void*)f_1154},
{"f_1174:unboxing_scm",(void*)f_1174},
{"f_1128:unboxing_scm",(void*)f_1128},
{"f_1121:unboxing_scm",(void*)f_1121},
{"f_1039:unboxing_scm",(void*)f_1039},
{"f_1049:unboxing_scm",(void*)f_1049},
{"f_1061:unboxing_scm",(void*)f_1061},
{"f_1064:unboxing_scm",(void*)f_1064},
{"f_1052:unboxing_scm",(void*)f_1052},
{"f_1033:unboxing_scm",(void*)f_1033},
{"f_1011:unboxing_scm",(void*)f_1011},
{"f_1002:unboxing_scm",(void*)f_1002},
{"f_990:unboxing_scm",(void*)f_990},
{"f_928:unboxing_scm",(void*)f_928},
{"f_988:unboxing_scm",(void*)f_988},
{"f_980:unboxing_scm",(void*)f_980},
{"f_984:unboxing_scm",(void*)f_984},
{"f_939:unboxing_scm",(void*)f_939},
{"f_973:unboxing_scm",(void*)f_973},
{"f_959:unboxing_scm",(void*)f_959},
{"f_904:unboxing_scm",(void*)f_904},
{"f_926:unboxing_scm",(void*)f_926},
{"f_877:unboxing_scm",(void*)f_877},
{"f_887:unboxing_scm",(void*)f_887},
{"f_890:unboxing_scm",(void*)f_890},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
