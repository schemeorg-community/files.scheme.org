/* Generated from optimizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:53
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: optimizer.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file optimizer.c
   unit: optimizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[272];
static double C_possibly_force_alignment;


C_noret_decl(C_optimizer_toplevel)
C_externexport void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4102)
static void C_ccall f_4102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14625)
static void C_ccall f_14625(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_14633)
static void C_ccall f_14633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14638)
static void C_fcall f_14638(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14688)
static void C_ccall f_14688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14692)
static void C_ccall f_14692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14648)
static void C_ccall f_14648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14652)
static void C_fcall f_14652(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14674)
static void C_ccall f_14674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6292)
static void C_ccall f_6292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13534)
static void C_ccall f_13534(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_13580)
static void C_ccall f_13580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13682)
static void C_ccall f_13682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13692)
static void C_fcall f_13692(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14029)
static void C_ccall f_14029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14021)
static void C_ccall f_14021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13798)
static void C_ccall f_13798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13827)
static void C_fcall f_13827(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13997)
static void C_ccall f_13997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13989)
static void C_ccall f_13989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13858)
static void C_fcall f_13858(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13911)
static void C_ccall f_13911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13901)
static void C_ccall f_13901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13909)
static void C_ccall f_13909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14083)
static void C_ccall f_14083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10) C_noret;
C_noret_decl(f_14096)
static void C_ccall f_14096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14138)
static void C_ccall f_14138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14122)
static void C_ccall f_14122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14126)
static void C_ccall f_14126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14118)
static void C_ccall f_14118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14304)
static void C_ccall f_14304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13) C_noret;
C_noret_decl(f_14317)
static void C_ccall f_14317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14323)
static void C_ccall f_14323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14375)
static void C_ccall f_14375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14367)
static void C_ccall f_14367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14351)
static void C_ccall f_14351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14355)
static void C_ccall f_14355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14359)
static void C_ccall f_14359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6295)
static void C_ccall f_6295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13175)
static void C_ccall f_13175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_13197)
static void C_ccall f_13197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13277)
static void C_ccall f_13277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13235)
static void C_ccall f_13235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13269)
static void C_ccall f_13269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13273)
static void C_ccall f_13273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13261)
static void C_ccall f_13261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13233)
static void C_ccall f_13233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13371)
static void C_ccall f_13371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_13391)
static void C_ccall f_13391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6298)
static void C_ccall f_6298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10553)
static void C_ccall f_10553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13048)
static void C_ccall f_13048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13051)
static void C_ccall f_13051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13054)
static void C_ccall f_13054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13057)
static void C_ccall f_13057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13060)
static void C_ccall f_13060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13063)
static void C_ccall f_13063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13146)
static void C_ccall f_13146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13066)
static void C_ccall f_13066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13069)
static void C_ccall f_13069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13072)
static void C_ccall f_13072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13140)
static void C_ccall f_13140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13075)
static void C_ccall f_13075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13078)
static void C_ccall f_13078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13137)
static void C_ccall f_13137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11327)
static void C_fcall f_11327(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11345)
static void C_ccall f_11345(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11351)
static void C_ccall f_11351(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11331)
static void C_ccall f_11331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13081)
static void C_ccall f_13081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13129)
static void C_ccall f_13129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13127)
static void C_ccall f_13127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13084)
static void C_ccall f_13084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13087)
static void C_ccall f_13087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13090)
static void C_ccall f_13090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13114)
static void C_ccall f_13114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13093)
static void C_ccall f_13093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13096)
static void C_ccall f_13096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13099)
static void C_ccall f_13099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13102)
static void C_ccall f_13102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13105)
static void C_ccall f_13105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13108)
static void C_ccall f_13108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12807)
static void C_fcall f_12807(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12813)
static void C_fcall f_12813(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13024)
static void C_fcall f_13024(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13034)
static void C_ccall f_13034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12998)
static void C_fcall f_12998(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13008)
static void C_ccall f_13008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12968)
static void C_ccall f_12968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12977)
static void C_ccall f_12977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12980)
static void C_ccall f_12980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12938)
static void C_fcall f_12938(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12948)
static void C_ccall f_12948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12847)
static void C_ccall f_12847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12852)
static void C_fcall f_12852(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12890)
static void C_ccall f_12890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12875)
static void C_ccall f_12875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12886)
static void C_ccall f_12886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12882)
static void C_ccall f_12882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12609)
static void C_fcall f_12609(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12615)
static void C_fcall f_12615(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12784)
static void C_fcall f_12784(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12794)
static void C_ccall f_12794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12724)
static void C_fcall f_12724(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12753)
static void C_ccall f_12753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12714)
static void C_ccall f_12714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12710)
static void C_ccall f_12710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12652)
static void C_ccall f_12652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12666)
static void C_fcall f_12666(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12676)
static void C_ccall f_12676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12081)
static void C_fcall f_12081(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12095)
static void C_ccall f_12095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12102)
static void C_ccall f_12102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12105)
static void C_ccall f_12105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12114)
static void C_ccall f_12114(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12266)
static void C_fcall f_12266(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12295)
static void C_ccall f_12295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12121)
static void C_ccall f_12121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12217)
static void C_fcall f_12217(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12250)
static void C_ccall f_12250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12230)
static void C_fcall f_12230(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12124)
static void C_ccall f_12124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12345)
static void C_fcall f_12345(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12586)
static void C_fcall f_12586(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12596)
static void C_ccall f_12596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12527)
static void C_ccall f_12527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12548)
static void C_fcall f_12548(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12546)
static void C_ccall f_12546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12542)
static void C_ccall f_12542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12474)
static void C_ccall f_12474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12479)
static void C_fcall f_12479(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12489)
static void C_ccall f_12489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12411)
static void C_fcall f_12411(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12409)
static void C_ccall f_12409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12379)
static void C_ccall f_12379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12384)
static void C_fcall f_12384(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12394)
static void C_ccall f_12394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12330)
static C_word C_fcall f_12330(C_word t0,C_word t1);
C_noret_decl(f_12127)
static void C_ccall f_12127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12202)
static void C_ccall f_12202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12190)
static void C_ccall f_12190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12186)
static void C_ccall f_12186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12093)
static void C_ccall f_12093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11672)
static void C_fcall f_11672(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12033)
static void C_fcall f_12033(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11798)
static void C_ccall f_11798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12010)
static void C_fcall f_12010(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12020)
static void C_ccall f_12020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11931)
static void C_ccall f_11931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11936)
static void C_fcall f_11936(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12004)
static void C_ccall f_12004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11963)
static void C_fcall f_11963(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12001)
static void C_ccall f_12001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11681)
static void C_fcall f_11681(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11774)
static void C_fcall f_11774(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11784)
static void C_ccall f_11784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11757)
static void C_ccall f_11757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11762)
static void C_ccall f_11762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11716)
static void C_ccall f_11716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11721)
static void C_fcall f_11721(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11731)
static void C_ccall f_11731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11679)
static void C_ccall f_11679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11993)
static void C_ccall f_11993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11979)
static void C_ccall f_11979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11977)
static void C_ccall f_11977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11800)
static void C_fcall f_11800(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11924)
static void C_ccall f_11924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11922)
static void C_ccall f_11922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11888)
static void C_fcall f_11888(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11907)
static void C_ccall f_11907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11896)
static void C_fcall f_11896(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11820)
static void C_ccall f_11820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11844)
static void C_fcall f_11844(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11871)
static C_word C_fcall f_11871(C_word t0,C_word t1);
C_noret_decl(f_11842)
static void C_ccall f_11842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11838)
static void C_ccall f_11838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11830)
static void C_ccall f_11830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11361)
static void C_fcall f_11361(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11367)
static void C_fcall f_11367(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11401)
static void C_fcall f_11401(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11623)
static void C_fcall f_11623(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11638)
static void C_ccall f_11638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11631)
static void C_fcall f_11631(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11520)
static void C_ccall f_11520(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11536)
static void C_fcall f_11536(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11589)
static void C_ccall f_11589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11593)
static void C_ccall f_11593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11556)
static void C_ccall f_11556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11565)
static void C_fcall f_11565(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11575)
static void C_ccall f_11575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11487)
static void C_ccall f_11487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11492)
static void C_fcall f_11492(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11507)
static void C_ccall f_11507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11500)
static void C_fcall f_11500(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11463)
static void C_ccall f_11463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11475)
static void C_ccall f_11475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11412)
static void C_fcall f_11412(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11433)
static void C_ccall f_11433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11430)
static void C_ccall f_11430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11365)
static void C_ccall f_11365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11080)
static void C_fcall f_11080(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11086)
static void C_fcall f_11086(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11120)
static void C_fcall f_11120(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11222)
static void C_fcall f_11222(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11237)
static void C_ccall f_11237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11230)
static void C_fcall f_11230(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11213)
static void C_ccall f_11213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11179)
static void C_fcall f_11179(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11188)
static void C_ccall f_11188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11200)
static void C_ccall f_11200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11131)
static void C_fcall f_11131(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11152)
static void C_ccall f_11152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11149)
static void C_ccall f_11149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11084)
static void C_ccall f_11084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10947)
static void C_fcall f_10947(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10953)
static void C_ccall f_10953(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10997)
static void C_ccall f_10997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11002)
static void C_fcall f_11002(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11009)
static void C_ccall f_11009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11070)
static void C_ccall f_11070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11066)
static void C_ccall f_11066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11024)
static void C_fcall f_11024(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11058)
static void C_ccall f_11058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11051)
static void C_fcall f_11051(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11022)
static void C_ccall f_11022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10987)
static void C_ccall f_10987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10965)
static void C_ccall f_10965(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10972)
static void C_ccall f_10972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10659)
static void C_fcall f_10659(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10872)
static void C_fcall f_10872(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10934)
static void C_ccall f_10934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10880)
static void C_fcall f_10880(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10905)
static void C_ccall f_10905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10895)
static void C_ccall f_10895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10899)
static void C_ccall f_10899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10870)
static void C_ccall f_10870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10662)
static void C_fcall f_10662(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10838)
static void C_fcall f_10838(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10853)
static void C_ccall f_10853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10846)
static void C_fcall f_10846(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10821)
static void C_ccall f_10821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10833)
static void C_ccall f_10833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10767)
static void C_fcall f_10767(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10791)
static void C_ccall f_10791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10785)
static void C_ccall f_10785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10749)
static void C_ccall f_10749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10702)
static void C_fcall f_10702(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10705)
static void C_fcall f_10705(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10710)
static void C_fcall f_10710(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10725)
static void C_ccall f_10725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10718)
static void C_fcall f_10718(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10556)
static void C_fcall f_10556(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10562)
static void C_ccall f_10562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10590)
static void C_fcall f_10590(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10594)
static void C_ccall f_10594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10598)
static void C_ccall f_10598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10560)
static void C_ccall f_10560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9168)
static void C_ccall f_9168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10548)
static void C_ccall f_10548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10551)
static void C_ccall f_10551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9824)
static void C_fcall f_9824(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_10538)
static void C_ccall f_10538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10536)
static void C_ccall f_10536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9828)
static void C_ccall f_9828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9843)
static void C_ccall f_9843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9852)
static void C_fcall f_9852(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9858)
static void C_ccall f_9858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9861)
static void C_ccall f_9861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9867)
static void C_ccall f_9867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10150)
static void C_fcall f_10150(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10465)
static void C_fcall f_10465(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10475)
static void C_ccall f_10475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10439)
static void C_fcall f_10439(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10449)
static void C_ccall f_10449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10424)
static void C_ccall f_10424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10427)
static void C_ccall f_10427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10372)
static void C_ccall f_10372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10375)
static void C_ccall f_10375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10219)
static void C_ccall f_10219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10266)
static void C_fcall f_10266(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10276)
static void C_ccall f_10276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10279)
static void C_ccall f_10279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10313)
static void C_ccall f_10313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10282)
static void C_ccall f_10282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10285)
static void C_ccall f_10285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10228)
static void C_ccall f_10228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10231)
static void C_ccall f_10231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10234)
static void C_ccall f_10234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9870)
static void C_ccall f_9870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10132)
static void C_ccall f_10132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10041)
static void C_ccall f_10041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10043)
static void C_fcall f_10043(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10119)
static void C_ccall f_10119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10051)
static void C_fcall f_10051(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10066)
static void C_ccall f_10066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9873)
static void C_ccall f_9873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9890)
static void C_ccall f_9890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9961)
static void C_ccall f_9961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9893)
static void C_ccall f_9893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9896)
static void C_ccall f_9896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9901)
static void C_fcall f_9901(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9945)
static void C_ccall f_9945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9916)
static void C_ccall f_9916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9370)
static void C_fcall f_9370(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_9815)
static void C_ccall f_9815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9822)
static void C_ccall f_9822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9373)
static void C_fcall f_9373(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9802)
static void C_ccall f_9802(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9778)
static void C_ccall f_9778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9789)
static void C_ccall f_9789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9745)
static void C_ccall f_9745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9636)
static void C_fcall f_9636(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9641)
static void C_ccall f_9641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9583)
static void C_ccall f_9583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9589)
static void C_fcall f_9589(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9594)
static void C_ccall f_9594(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9542)
static void C_ccall f_9542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9548)
static void C_fcall f_9548(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9553)
static void C_ccall f_9553(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9526)
static void C_ccall f_9526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9522)
static void C_ccall f_9522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9492)
static void C_ccall f_9492(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9455)
static void C_ccall f_9455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9471)
static void C_ccall f_9471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9437)
static void C_ccall f_9437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9171)
static void C_fcall f_9171(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9342)
static void C_fcall f_9342(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9357)
static void C_ccall f_9357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9350)
static void C_fcall f_9350(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9322)
static void C_ccall f_9322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9296)
static void C_ccall f_9296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9242)
static void C_ccall f_9242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9248)
static void C_ccall f_9248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9254)
static void C_ccall f_9254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9211)
static void C_ccall f_9211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_9035)
static void C_ccall f_9035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9064)
static void C_ccall f_9064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9076)
static void C_ccall f_9076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9090)
static void C_fcall f_9090(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9139)
static void C_ccall f_9139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6834)
static void C_fcall f_6834(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9110)
static void C_ccall f_9110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9114)
static void C_ccall f_9114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9084)
static void C_ccall f_9084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9070)
static void C_ccall f_9070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9068)
static void C_ccall f_9068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9060)
static void C_ccall f_9060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8955)
static void C_ccall f_8955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8999)
static void C_ccall f_8999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8760)
static void C_ccall f_8760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8766)
static void C_ccall f_8766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8882)
static void C_ccall f_8882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8775)
static void C_ccall f_8775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8837)
static void C_ccall f_8837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8835)
static void C_ccall f_8835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8797)
static void C_ccall f_8797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8675)
static void C_ccall f_8675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8716)
static void C_ccall f_8716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8728)
static void C_ccall f_8728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8706)
static void C_ccall f_8706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8704)
static void C_ccall f_8704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8493)
static void C_ccall f_8493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8599)
static void C_ccall f_8599(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8502)
static void C_ccall f_8502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8573)
static void C_ccall f_8573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8571)
static void C_ccall f_8571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8524)
static void C_ccall f_8524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8453)
static void C_ccall f_8453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8469)
static void C_ccall f_8469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8374)
static void C_ccall f_8374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8403)
static void C_fcall f_8403(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8284)
static void C_ccall f_8284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8318)
static void C_fcall f_8318(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8179)
static void C_ccall f_8179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8205)
static void C_ccall f_8205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8201)
static void C_ccall f_8201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8085)
static void C_ccall f_8085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8008)
static void C_ccall f_8008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8032)
static void C_fcall f_8032(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8036)
static void C_ccall f_8036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7920)
static void C_ccall f_7920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7976)
static void C_ccall f_7976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7972)
static void C_ccall f_7972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7849)
static void C_ccall f_7849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7861)
static void C_fcall f_7861(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7877)
static void C_ccall f_7877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7750)
static void C_ccall f_7750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7779)
static void C_ccall f_7779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7787)
static void C_ccall f_7787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7791)
static void C_ccall f_7791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7507)
static void C_ccall f_7507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7535)
static void C_fcall f_7535(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7538)
static void C_fcall f_7538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7651)
static void C_fcall f_7651(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7685)
static void C_ccall f_7685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7541)
static void C_ccall f_7541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7616)
static void C_fcall f_7616(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7645)
static void C_ccall f_7645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7544)
static void C_ccall f_7544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7588)
static void C_ccall f_7588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7586)
static void C_ccall f_7586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7549)
static void C_ccall f_7549(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7529)
static void C_ccall f_7529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7481)
static void C_ccall f_7481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static void C_ccall f_7408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7445)
static void C_ccall f_7445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7437)
static void C_ccall f_7437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7319)
static void C_ccall f_7319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7214)
static void C_ccall f_7214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7269)
static void C_ccall f_7269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7146)
static void C_ccall f_7146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7166)
static void C_ccall f_7166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7174)
static void C_ccall f_7174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7097)
static void C_ccall f_7097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7113)
static void C_ccall f_7113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7022)
static void C_ccall f_7022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6871)
static void C_ccall f_6871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6952)
static void C_ccall f_6952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6874)
static void C_fcall f_6874(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6803)
static void C_ccall f_6803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6300)
static void C_ccall f_6300(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6736)
static void C_fcall f_6736(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6769)
static void C_ccall f_6769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6749)
static void C_fcall f_6749(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6689)
static void C_fcall f_6689(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6709)
static void C_ccall f_6709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6697)
static void C_fcall f_6697(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6706)
static void C_ccall f_6706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6702)
static void C_ccall f_6702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6609)
static void C_fcall f_6609(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6676)
static void C_ccall f_6676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6617)
static void C_fcall f_6617(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6649)
static void C_ccall f_6649(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6662)
static void C_ccall f_6662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6627)
static void C_ccall f_6627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6643)
static void C_ccall f_6643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6631)
static void C_ccall f_6631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6635)
static void C_ccall f_6635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6354)
static void C_ccall f_6354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6528)
static void C_fcall f_6528(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6596)
static void C_ccall f_6596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6536)
static void C_fcall f_6536(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6579)
static void C_ccall f_6579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6585)
static void C_ccall f_6585(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6543)
static void C_ccall f_6543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6553)
static void C_ccall f_6553(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6566)
static void C_ccall f_6566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6551)
static void C_ccall f_6551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6360)
static void C_ccall f_6360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6380)
static void C_ccall f_6380(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6393)
static void C_fcall f_6393(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6454)
static void C_ccall f_6454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6500)
static void C_ccall f_6500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6452)
static void C_ccall f_6452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6372)
static void C_ccall f_6372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6306)
static void C_fcall f_6306(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6312)
static void C_fcall f_6312(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5966)
static void C_ccall f_5966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5980)
static void C_ccall f_5980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6000)
static void C_ccall f_6000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6007)
static void C_ccall f_6007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6012)
static void C_fcall f_6012(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6272)
static void C_ccall f_6272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6020)
static void C_fcall f_6020(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6256)
static void C_ccall f_6256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6038)
static void C_ccall f_6038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6047)
static void C_fcall f_6047(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6067)
static void C_fcall f_6067(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6073)
static void C_ccall f_6073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6079)
static void C_fcall f_6079(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6088)
static void C_fcall f_6088(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6095)
static void C_ccall f_6095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6098)
static void C_ccall f_6098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6101)
static void C_ccall f_6101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5983)
static void C_ccall f_5983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5986)
static void C_ccall f_5986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5973)
static void C_fcall f_5973(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5969)
static C_word C_fcall f_5969(C_word t0);
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5848)
static void C_ccall f_5848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5854)
static void C_ccall f_5854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5858)
static void C_ccall f_5858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5861)
static void C_ccall f_5861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5897)
static void C_ccall f_5897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5902)
static void C_fcall f_5902(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5914)
static void C_ccall f_5914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5864)
static void C_ccall f_5864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5867)
static void C_ccall f_5867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5870)
static void C_ccall f_5870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5873)
static void C_ccall f_5873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5818)
static void C_fcall f_5818(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5838)
static void C_ccall f_5838(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5822)
static void C_ccall f_5822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_fcall f_4560(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5708)
static void C_ccall f_5708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5711)
static void C_ccall f_5711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5810)
static void C_ccall f_5810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5806)
static void C_ccall f_5806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5768)
static void C_fcall f_5768(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5799)
static void C_ccall f_5799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5795)
static void C_ccall f_5795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5728)
static void C_fcall f_5728(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5758)
static void C_ccall f_5758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5734)
static void C_ccall f_5734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5682)
static void C_ccall f_5682(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5680)
static void C_ccall f_5680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5630)
static void C_ccall f_5630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4951)
static void C_ccall f_4951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5182)
static void C_fcall f_5182(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5586)
static void C_ccall f_5586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5208)
static void C_fcall f_5208(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5280)
static void C_ccall f_5280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5458)
static void C_fcall f_5458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5461)
static void C_ccall f_5461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5473)
static void C_ccall f_5473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5523)
static void C_ccall f_5523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5503)
static void C_ccall f_5503(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5501)
static void C_ccall f_5501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5478)
static void C_ccall f_5478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5294)
static void C_fcall f_5294(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5339)
static void C_ccall f_5339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5345)
static void C_ccall f_5345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5351)
static void C_ccall f_5351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5395)
static void C_ccall f_5395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5371)
static void C_ccall f_5371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5375)
static void C_ccall f_5375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5333)
static void C_ccall f_5333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5321)
static void C_ccall f_5321(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5319)
static void C_ccall f_5319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5274)
static void C_ccall f_5274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5211)
static void C_ccall f_5211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5245)
static void C_ccall f_5245(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5217)
static void C_ccall f_5217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5220)
static void C_ccall f_5220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5230)
static void C_ccall f_5230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5033)
static void C_ccall f_5033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5054)
static void C_ccall f_5054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5057)
static void C_fcall f_5057(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5093)
static void C_ccall f_5093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5012)
static void C_fcall f_5012(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4968)
static void C_ccall f_4968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4851)
static void C_ccall f_4851(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4898)
static void C_ccall f_4898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4878)
static void C_ccall f_4878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static void C_ccall f_4752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4770)
static void C_ccall f_4770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4824)
static void C_ccall f_4824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4817)
static void C_ccall f_4817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4758)
static void C_ccall f_4758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4764)
static void C_ccall f_4764(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_fcall f_4684(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4600)
static void C_fcall f_4600(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4622)
static void C_ccall f_4622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4642)
static void C_ccall f_4642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static void C_fcall f_4279(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4465)
static void C_fcall f_4465(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4459)
static void C_ccall f_4459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_ccall f_4384(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4407)
static void C_ccall f_4407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4413)
static void C_ccall f_4413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4420)
static void C_ccall f_4420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4390)
static void C_ccall f_4390(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4396)
static void C_ccall f_4396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4400)
static void C_fcall f_4400(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4404)
static void C_ccall f_4404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4148)
static void C_fcall f_4148(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4222)
static void C_fcall f_4222(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4249)
static C_word C_fcall f_4249(C_word t0,C_word t1);
C_noret_decl(f_4220)
static void C_ccall f_4220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4185)
static void C_ccall f_4185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4144)
static C_word C_fcall f_4144(C_word t0);
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4108)
static void C_fcall f_4108(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3736)
static void C_ccall f_3736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4046)
static void C_ccall f_4046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_ccall f_4052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3808)
static void C_fcall f_3808(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3889)
static void C_fcall f_3889(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_fcall f_3939(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3963)
static void C_ccall f_3963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3966)
static void C_ccall f_3966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3984)
static void C_fcall f_3984(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3987)
static void C_ccall f_3987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3892)
static void C_ccall f_3892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3862)
static void C_fcall f_3862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_fcall f_3845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3851)
static void C_ccall f_3851(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3774)
static void C_fcall f_3774(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3780)
static void C_fcall f_3780(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3795)
static void C_ccall f_3795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_fcall f_3788(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3769)
static C_word C_fcall f_3769(C_word t0);
C_noret_decl(f_3762)
static void C_fcall f_3762(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3739)
static void C_fcall f_3739(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3746)
static void C_fcall f_3746(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_14638)
static void C_fcall trf_14638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14638(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14638(t0,t1,t2);}

C_noret_decl(trf_14652)
static void C_fcall trf_14652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14652(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14652(t0,t1,t2);}

C_noret_decl(trf_13692)
static void C_fcall trf_13692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13692(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_13692(t0,t1,t2,t3);}

C_noret_decl(trf_13827)
static void C_fcall trf_13827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13827(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_13827(t0,t1,t2,t3,t4);}

C_noret_decl(trf_13858)
static void C_fcall trf_13858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13858(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13858(t0,t1);}

C_noret_decl(trf_11327)
static void C_fcall trf_11327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11327(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11327(t0,t1,t2,t3);}

C_noret_decl(trf_12807)
static void C_fcall trf_12807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12807(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12807(t0,t1,t2);}

C_noret_decl(trf_12813)
static void C_fcall trf_12813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12813(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12813(t0,t1,t2);}

C_noret_decl(trf_13024)
static void C_fcall trf_13024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13024(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13024(t0,t1,t2);}

C_noret_decl(trf_12998)
static void C_fcall trf_12998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12998(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12998(t0,t1,t2);}

C_noret_decl(trf_12938)
static void C_fcall trf_12938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12938(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12938(t0,t1,t2);}

C_noret_decl(trf_12852)
static void C_fcall trf_12852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12852(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12852(t0,t1,t2,t3);}

C_noret_decl(trf_12609)
static void C_fcall trf_12609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12609(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12609(t0,t1,t2);}

C_noret_decl(trf_12615)
static void C_fcall trf_12615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12615(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12615(t0,t1,t2);}

C_noret_decl(trf_12784)
static void C_fcall trf_12784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12784(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12784(t0,t1,t2);}

C_noret_decl(trf_12724)
static void C_fcall trf_12724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12724(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12724(t0,t1,t2);}

C_noret_decl(trf_12666)
static void C_fcall trf_12666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12666(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12666(t0,t1,t2);}

C_noret_decl(trf_12081)
static void C_fcall trf_12081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12081(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12081(t0,t1,t2,t3);}

C_noret_decl(trf_12266)
static void C_fcall trf_12266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12266(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12266(t0,t1,t2);}

C_noret_decl(trf_12217)
static void C_fcall trf_12217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12217(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12217(t0,t1,t2,t3);}

C_noret_decl(trf_12230)
static void C_fcall trf_12230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12230(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12230(t0,t1);}

C_noret_decl(trf_12345)
static void C_fcall trf_12345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12345(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12345(t0,t1,t2);}

C_noret_decl(trf_12586)
static void C_fcall trf_12586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12586(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12586(t0,t1,t2);}

C_noret_decl(trf_12548)
static void C_fcall trf_12548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12548(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12548(t0,t1,t2);}

C_noret_decl(trf_12479)
static void C_fcall trf_12479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12479(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12479(t0,t1,t2);}

C_noret_decl(trf_12411)
static void C_fcall trf_12411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12411(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12411(t0,t1,t2);}

C_noret_decl(trf_12384)
static void C_fcall trf_12384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12384(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12384(t0,t1,t2);}

C_noret_decl(trf_11672)
static void C_fcall trf_11672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11672(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11672(t0,t1,t2);}

C_noret_decl(trf_12033)
static void C_fcall trf_12033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12033(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12033(t0,t1,t2);}

C_noret_decl(trf_12010)
static void C_fcall trf_12010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12010(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12010(t0,t1,t2);}

C_noret_decl(trf_11936)
static void C_fcall trf_11936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11936(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11936(t0,t1,t2);}

C_noret_decl(trf_11963)
static void C_fcall trf_11963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11963(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11963(t0,t1,t2);}

C_noret_decl(trf_11681)
static void C_fcall trf_11681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11681(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11681(t0,t1,t2);}

C_noret_decl(trf_11774)
static void C_fcall trf_11774(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11774(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11774(t0,t1,t2);}

C_noret_decl(trf_11721)
static void C_fcall trf_11721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11721(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11721(t0,t1,t2);}

C_noret_decl(trf_11800)
static void C_fcall trf_11800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11800(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11800(t0,t1,t2);}

C_noret_decl(trf_11888)
static void C_fcall trf_11888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11888(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11888(t0,t1,t2);}

C_noret_decl(trf_11896)
static void C_fcall trf_11896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11896(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11896(t0,t1,t2);}

C_noret_decl(trf_11844)
static void C_fcall trf_11844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11844(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11844(t0,t1,t2);}

C_noret_decl(trf_11361)
static void C_fcall trf_11361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11361(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11361(t0,t1,t2);}

C_noret_decl(trf_11367)
static void C_fcall trf_11367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11367(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11367(t0,t1,t2,t3);}

C_noret_decl(trf_11401)
static void C_fcall trf_11401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11401(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11401(t0,t1);}

C_noret_decl(trf_11623)
static void C_fcall trf_11623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11623(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11623(t0,t1,t2);}

C_noret_decl(trf_11631)
static void C_fcall trf_11631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11631(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11631(t0,t1,t2);}

C_noret_decl(trf_11536)
static void C_fcall trf_11536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11536(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11536(t0,t1,t2);}

C_noret_decl(trf_11565)
static void C_fcall trf_11565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11565(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11565(t0,t1,t2);}

C_noret_decl(trf_11492)
static void C_fcall trf_11492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11492(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11492(t0,t1,t2);}

C_noret_decl(trf_11500)
static void C_fcall trf_11500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11500(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11500(t0,t1,t2);}

C_noret_decl(trf_11412)
static void C_fcall trf_11412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11412(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11412(t0,t1,t2,t3);}

C_noret_decl(trf_11080)
static void C_fcall trf_11080(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11080(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11080(t0,t1,t2);}

C_noret_decl(trf_11086)
static void C_fcall trf_11086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11086(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11086(t0,t1,t2,t3);}

C_noret_decl(trf_11120)
static void C_fcall trf_11120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11120(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11120(t0,t1);}

C_noret_decl(trf_11222)
static void C_fcall trf_11222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11222(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11222(t0,t1,t2);}

C_noret_decl(trf_11230)
static void C_fcall trf_11230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11230(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11230(t0,t1,t2);}

C_noret_decl(trf_11179)
static void C_fcall trf_11179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11179(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11179(t0,t1);}

C_noret_decl(trf_11131)
static void C_fcall trf_11131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11131(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11131(t0,t1,t2,t3);}

C_noret_decl(trf_10947)
static void C_fcall trf_10947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10947(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10947(t0,t1,t2,t3);}

C_noret_decl(trf_11002)
static void C_fcall trf_11002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11002(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11002(t0,t1,t2,t3);}

C_noret_decl(trf_11024)
static void C_fcall trf_11024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11024(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11024(t0,t1,t2);}

C_noret_decl(trf_11051)
static void C_fcall trf_11051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11051(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11051(t0,t1,t2);}

C_noret_decl(trf_10659)
static void C_fcall trf_10659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10659(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10659(t0,t1,t2);}

C_noret_decl(trf_10872)
static void C_fcall trf_10872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10872(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10872(t0,t1,t2);}

C_noret_decl(trf_10880)
static void C_fcall trf_10880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10880(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10880(t0,t1,t2);}

C_noret_decl(trf_10662)
static void C_fcall trf_10662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10662(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10662(t0,t1,t2,t3);}

C_noret_decl(trf_10838)
static void C_fcall trf_10838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10838(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10838(t0,t1,t2);}

C_noret_decl(trf_10846)
static void C_fcall trf_10846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10846(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10846(t0,t1,t2);}

C_noret_decl(trf_10767)
static void C_fcall trf_10767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10767(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10767(t0,t1,t2,t3);}

C_noret_decl(trf_10702)
static void C_fcall trf_10702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10702(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10702(t0,t1);}

C_noret_decl(trf_10705)
static void C_fcall trf_10705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10705(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10705(t0,t1);}

C_noret_decl(trf_10710)
static void C_fcall trf_10710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10710(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10710(t0,t1,t2);}

C_noret_decl(trf_10718)
static void C_fcall trf_10718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10718(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10718(t0,t1,t2);}

C_noret_decl(trf_10556)
static void C_fcall trf_10556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10556(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10556(t0,t1);}

C_noret_decl(trf_10590)
static void C_fcall trf_10590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10590(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10590(t0,t1);}

C_noret_decl(trf_9824)
static void C_fcall trf_9824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9824(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_9824(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_9852)
static void C_fcall trf_9852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9852(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9852(t0,t1);}

C_noret_decl(trf_10150)
static void C_fcall trf_10150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10150(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10150(t0,t1,t2);}

C_noret_decl(trf_10465)
static void C_fcall trf_10465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10465(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10465(t0,t1,t2);}

C_noret_decl(trf_10439)
static void C_fcall trf_10439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10439(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10439(t0,t1,t2);}

C_noret_decl(trf_10266)
static void C_fcall trf_10266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10266(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10266(t0,t1,t2);}

C_noret_decl(trf_10043)
static void C_fcall trf_10043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10043(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10043(t0,t1,t2);}

C_noret_decl(trf_10051)
static void C_fcall trf_10051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10051(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10051(t0,t1,t2);}

C_noret_decl(trf_9901)
static void C_fcall trf_9901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9901(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9901(t0,t1,t2);}

C_noret_decl(trf_9370)
static void C_fcall trf_9370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9370(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_9370(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_9373)
static void C_fcall trf_9373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9373(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_9373(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_9636)
static void C_fcall trf_9636(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9636(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9636(t0,t1);}

C_noret_decl(trf_9589)
static void C_fcall trf_9589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9589(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9589(t0,t1);}

C_noret_decl(trf_9548)
static void C_fcall trf_9548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9548(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9548(t0,t1);}

C_noret_decl(trf_9171)
static void C_fcall trf_9171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9171(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9171(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9342)
static void C_fcall trf_9342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9342(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9342(t0,t1,t2);}

C_noret_decl(trf_9350)
static void C_fcall trf_9350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9350(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9350(t0,t1,t2);}

C_noret_decl(trf_9090)
static void C_fcall trf_9090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9090(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9090(t0,t1,t2,t3);}

C_noret_decl(trf_6834)
static void C_fcall trf_6834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6834(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6834(t0,t1);}

C_noret_decl(trf_8403)
static void C_fcall trf_8403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8403(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8403(t0,t1);}

C_noret_decl(trf_8318)
static void C_fcall trf_8318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8318(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8318(t0,t1);}

C_noret_decl(trf_8032)
static void C_fcall trf_8032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8032(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8032(t0,t1);}

C_noret_decl(trf_7861)
static void C_fcall trf_7861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7861(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7861(t0,t1);}

C_noret_decl(trf_7535)
static void C_fcall trf_7535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7535(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7535(t0,t1);}

C_noret_decl(trf_7538)
static void C_fcall trf_7538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7538(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7538(t0,t1);}

C_noret_decl(trf_7651)
static void C_fcall trf_7651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7651(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7651(t0,t1,t2);}

C_noret_decl(trf_7616)
static void C_fcall trf_7616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7616(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7616(t0,t1,t2);}

C_noret_decl(trf_6874)
static void C_fcall trf_6874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6874(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6874(t0,t1);}

C_noret_decl(trf_6736)
static void C_fcall trf_6736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6736(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6736(t0,t1,t2,t3);}

C_noret_decl(trf_6749)
static void C_fcall trf_6749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6749(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6749(t0,t1);}

C_noret_decl(trf_6689)
static void C_fcall trf_6689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6689(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6689(t0,t1,t2,t3);}

C_noret_decl(trf_6697)
static void C_fcall trf_6697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6697(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6697(t0,t1,t2,t3);}

C_noret_decl(trf_6609)
static void C_fcall trf_6609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6609(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6609(t0,t1,t2);}

C_noret_decl(trf_6617)
static void C_fcall trf_6617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6617(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6617(t0,t1,t2);}

C_noret_decl(trf_6528)
static void C_fcall trf_6528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6528(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6528(t0,t1,t2);}

C_noret_decl(trf_6536)
static void C_fcall trf_6536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6536(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6536(t0,t1,t2);}

C_noret_decl(trf_6393)
static void C_fcall trf_6393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6393(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6393(t0,t1);}

C_noret_decl(trf_6306)
static void C_fcall trf_6306(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6306(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6306(t0,t1,t2,t3);}

C_noret_decl(trf_6312)
static void C_fcall trf_6312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6312(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6312(t0,t1,t2,t3);}

C_noret_decl(trf_6012)
static void C_fcall trf_6012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6012(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6012(t0,t1,t2);}

C_noret_decl(trf_6020)
static void C_fcall trf_6020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6020(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6020(t0,t1,t2);}

C_noret_decl(trf_6047)
static void C_fcall trf_6047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6047(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6047(t0,t1);}

C_noret_decl(trf_6067)
static void C_fcall trf_6067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6067(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6067(t0,t1);}

C_noret_decl(trf_6079)
static void C_fcall trf_6079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6079(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6079(t0,t1);}

C_noret_decl(trf_6088)
static void C_fcall trf_6088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6088(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6088(t0,t1);}

C_noret_decl(trf_5973)
static void C_fcall trf_5973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5973(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5973(t0,t1,t2,t3);}

C_noret_decl(trf_5902)
static void C_fcall trf_5902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5902(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5902(t0,t1,t2);}

C_noret_decl(trf_5818)
static void C_fcall trf_5818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5818(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5818(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4560)
static void C_fcall trf_4560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4560(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4560(t0,t1,t2,t3);}

C_noret_decl(trf_5768)
static void C_fcall trf_5768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5768(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5768(t0,t1);}

C_noret_decl(trf_5728)
static void C_fcall trf_5728(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5728(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5728(t0,t1);}

C_noret_decl(trf_5182)
static void C_fcall trf_5182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5182(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5182(t0,t1);}

C_noret_decl(trf_5208)
static void C_fcall trf_5208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5208(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5208(t0,t1);}

C_noret_decl(trf_5458)
static void C_fcall trf_5458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5458(t0,t1);}

C_noret_decl(trf_5294)
static void C_fcall trf_5294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5294(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5294(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5057)
static void C_fcall trf_5057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5057(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5057(t0,t1);}

C_noret_decl(trf_5012)
static void C_fcall trf_5012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5012(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5012(t0,t1);}

C_noret_decl(trf_4684)
static void C_fcall trf_4684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4684(t0,t1);}

C_noret_decl(trf_4600)
static void C_fcall trf_4600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4600(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4600(t0,t1,t2);}

C_noret_decl(trf_4279)
static void C_fcall trf_4279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4279(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4279(t0,t1,t2,t3);}

C_noret_decl(trf_4465)
static void C_fcall trf_4465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4465(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4465(t0,t1,t2);}

C_noret_decl(trf_4400)
static void C_fcall trf_4400(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4400(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4400(t0,t1);}

C_noret_decl(trf_4148)
static void C_fcall trf_4148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4148(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4148(t0,t1,t2);}

C_noret_decl(trf_4222)
static void C_fcall trf_4222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4222(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4222(t0,t1,t2);}

C_noret_decl(trf_4108)
static void C_fcall trf_4108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4108(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4108(t0,t1,t2,t3);}

C_noret_decl(trf_3808)
static void C_fcall trf_3808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3808(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3808(t0,t1,t2,t3);}

C_noret_decl(trf_3889)
static void C_fcall trf_3889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3889(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3889(t0,t1);}

C_noret_decl(trf_3939)
static void C_fcall trf_3939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3939(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3939(t0,t1);}

C_noret_decl(trf_3984)
static void C_fcall trf_3984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3984(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3984(t0,t1);}

C_noret_decl(trf_3862)
static void C_fcall trf_3862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3862(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3862(t0,t1);}

C_noret_decl(trf_3845)
static void C_fcall trf_3845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3845(t0,t1);}

C_noret_decl(trf_3774)
static void C_fcall trf_3774(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3774(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3774(t0,t1,t2,t3);}

C_noret_decl(trf_3780)
static void C_fcall trf_3780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3780(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3780(t0,t1,t2);}

C_noret_decl(trf_3788)
static void C_fcall trf_3788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3788(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3788(t0,t1,t2);}

C_noret_decl(trf_3762)
static void C_fcall trf_3762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3762(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3762(t0,t1,t2,t3);}

C_noret_decl(trf_3739)
static void C_fcall trf_3739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3739(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3739(t0,t1,t2);}

C_noret_decl(trf_3746)
static void C_fcall trf_3746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3746(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3746(t0,t1);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr14)
static void C_fcall tr14(C_proc14 k) C_regparm C_noret;
C_regparm static void C_fcall tr14(C_proc14 k){
C_word t13=C_pick(0);
C_word t12=C_pick(1);
C_word t11=C_pick(2);
C_word t10=C_pick(3);
C_word t9=C_pick(4);
C_word t8=C_pick(5);
C_word t7=C_pick(6);
C_word t6=C_pick(7);
C_word t5=C_pick(8);
C_word t4=C_pick(9);
C_word t3=C_pick(10);
C_word t2=C_pick(11);
C_word t1=C_pick(12);
C_word t0=C_pick(13);
C_adjust_stack(-14);
(k)(14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}

C_noret_decl(tr11)
static void C_fcall tr11(C_proc11 k) C_regparm C_noret;
C_regparm static void C_fcall tr11(C_proc11 k){
C_word t10=C_pick(0);
C_word t9=C_pick(1);
C_word t8=C_pick(2);
C_word t7=C_pick(3);
C_word t6=C_pick(4);
C_word t5=C_pick(5);
C_word t4=C_pick(6);
C_word t3=C_pick(7);
C_word t2=C_pick(8);
C_word t1=C_pick(9);
C_word t0=C_pick(10);
C_adjust_stack(-11);
(k)(11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("optimizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2024)){
C_save(t1);
C_rereclaim2(2024*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,272);
lf[0]=C_h_intern(&lf[0],34,"\010compilerscan-toplevel-assignments");
lf[1]=C_h_intern(&lf[1],13,"alist-update!");
lf[2]=C_h_intern(&lf[2],13,"\004corevariable");
lf[3]=C_h_intern(&lf[3],6,"remove");
lf[4]=C_h_intern(&lf[4],2,"if");
lf[5]=C_h_intern(&lf[5],3,"let");
lf[6]=C_h_intern(&lf[6],6,"append");
lf[7]=C_h_intern(&lf[7],6,"lambda");
lf[8]=C_h_intern(&lf[8],9,"\004corecall");
lf[9]=C_h_intern(&lf[9],4,"set!");
lf[10]=C_h_intern(&lf[10],4,"node");
lf[11]=C_h_intern(&lf[11],14,"\004coreundefined");
lf[12]=C_h_intern(&lf[12],19,"\010compilercopy-node!");
lf[13]=C_h_intern(&lf[13],10,"\003sysnotice");
lf[14]=C_h_intern(&lf[14],17,"get-output-string");
lf[15]=C_h_intern(&lf[15],19,"\003syswrite-char/port");
lf[16]=C_h_intern(&lf[16],5,"write");
lf[17]=C_h_intern(&lf[17],7,"display");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\0008dropping assignment of unused value to global variable `");
lf[19]=C_h_intern(&lf[19],18,"open-output-string");
lf[20]=C_h_intern(&lf[20],9,"alist-ref");
lf[21]=C_h_intern(&lf[21],11,"\004corelambda");
lf[22]=C_h_intern(&lf[22],13,"\004corecallunit");
lf[23]=C_h_intern(&lf[23],9,"\004corecond");
lf[24]=C_h_intern(&lf[24],11,"\004coreswitch");
lf[25]=C_h_intern(&lf[25],8,"\003sysput!");
lf[26]=C_h_intern(&lf[26],21,"\010compileralways-bound");
lf[27]=C_h_intern(&lf[27],9,"\003syserror");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[29]=C_h_intern(&lf[29],12,"\003sysfor-each");
lf[30]=C_h_intern(&lf[30],18,"\010compilerdebugging");
lf[31]=C_h_intern(&lf[31],1,"o");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\014safe globals");
lf[33]=C_h_intern(&lf[33],17,"delete-duplicates");
lf[34]=C_h_intern(&lf[34],3,"eq\077");
lf[35]=C_h_intern(&lf[35],1,"p");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000 scanning toplevel assignments...");
lf[37]=C_h_intern(&lf[37],24,"\010compilersimplifications");
lf[38]=C_h_intern(&lf[38],23,"\010compilersimplified-ops");
lf[39]=C_h_intern(&lf[39],41,"\010compilerperform-high-level-optimizations");
lf[40]=C_h_intern(&lf[40],12,"\010compilerget");
lf[41]=C_h_intern(&lf[41],5,"quote");
lf[42]=C_h_intern(&lf[42],10,"alist-cons");
lf[43]=C_h_intern(&lf[43],4,"caar");
lf[44]=C_h_intern(&lf[44],19,"\010compilermatch-node");
lf[45]=C_h_intern(&lf[45],3,"any");
lf[46]=C_h_intern(&lf[46],18,"\003syshash-table-ref");
lf[47]=C_h_intern(&lf[47],30,"\010compilerbroken-constant-nodes");
lf[48]=C_h_intern(&lf[48],11,"lset-adjoin");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[50]=C_h_intern(&lf[50],14,"\010compilerqnode");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\033folding constant expression");
lf[52]=C_h_intern(&lf[52],4,"eval");
lf[53]=C_h_intern(&lf[53],22,"with-exception-handler");
lf[54]=C_h_intern(&lf[54],30,"call-with-current-continuation");
lf[55]=C_h_intern(&lf[55],5,"every");
lf[56]=C_h_intern(&lf[56],9,"foldable\077");
lf[57]=C_h_intern(&lf[57],7,"\003sysget");
lf[58]=C_h_intern(&lf[58],18,"\010compilerintrinsic");
lf[59]=C_h_intern(&lf[59],5,"value");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\035substituted constant variable");
lf[61]=C_h_intern(&lf[61],16,"\010compilervarnode");
lf[62]=C_h_intern(&lf[62],11,"collapsable");
lf[63]=C_h_intern(&lf[63],10,"replacable");
lf[64]=C_h_intern(&lf[64],7,"\003sysmap");
lf[65]=C_h_intern(&lf[65],9,"replacing");
lf[66]=C_h_intern(&lf[66],12,"contractable");
lf[67]=C_h_intern(&lf[67],9,"removable");
lf[68]=C_h_intern(&lf[68],6,"unused");
lf[69]=C_h_intern(&lf[69],9,"partition");
lf[70]=C_h_intern(&lf[70],26,"\010compilerbuild-lambda-list");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[72]=C_h_intern(&lf[72],13,"explicit-rest");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000 removed unused formal parameters");
lf[74]=C_h_intern(&lf[74],30,"\010compilerdecompose-lambda-list");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[76]=C_h_intern(&lf[76],21,"has-unused-parameters");
lf[77]=C_h_intern(&lf[77],31,"\010compilerinline-lambda-bindings");
lf[78]=C_h_intern(&lf[78],13,"\010compilerput!");
lf[79]=C_h_intern(&lf[79],13,"inline-target");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\024contracted procedure");
lf[81]=C_h_intern(&lf[81],24,"\010compilercheck-signature");
lf[82]=C_h_intern(&lf[82],30,"\010compilerconstant-declarations");
lf[83]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[84]=C_h_intern(&lf[84],1,"x");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\0005removed call to constant procedure with unused result");
lf[86]=C_h_intern(&lf[86],37,"\010compilerexpression-has-side-effects\077");
lf[87]=C_h_intern(&lf[87],8,"assigned");
lf[88]=C_h_intern(&lf[88],10,"references");
lf[89]=C_h_intern(&lf[89],7,"unknown");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\022inlining procedure");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\017global inlining");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\010inlining");
lf[93]=C_h_intern(&lf[93],1,"i");
lf[94]=C_h_intern(&lf[94],22,"\010compilerinline-global");
lf[95]=C_h_intern(&lf[95],14,"append-reverse");
lf[96]=C_h_intern(&lf[96],6,"gensym");
lf[97]=C_h_intern(&lf[97],1,"t");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000+removed unused parameter to known procedure");
lf[99]=C_h_intern(&lf[99],8,"split-at");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[101]=C_h_intern(&lf[101],20,"\004coreinline_allocate");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\042consed rest parameter at call site");
lf[103]=C_h_intern(&lf[103],21,"\010compilerllist-length");
lf[104]=C_h_intern(&lf[104],23,"\010compilerinline-locally");
lf[105]=C_h_intern(&lf[105],3,"yes");
lf[106]=C_h_intern(&lf[106],2,"no");
lf[107]=C_h_intern(&lf[107],24,"\010compilerinline-max-size");
lf[108]=C_h_intern(&lf[108],15,"\010compilerinline");
lf[109]=C_h_intern(&lf[109],9,"inlinable");
lf[110]=C_h_intern(&lf[110],11,"local-value");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\0006removed side-effect free assignment to unused variable");
lf[112]=C_h_intern(&lf[112],16,"inline-transient");
lf[113]=C_h_intern(&lf[113],26,"\010compilervariable-visible\077");
lf[114]=C_h_intern(&lf[114],6,"global");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\031removed conditional forms");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\025removed binding forms");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\022replaced variables");
lf[118]=C_h_intern(&lf[118],5,"print");
lf[119]=C_h_intern(&lf[119],7,"newline");
lf[120]=C_h_intern(&lf[120],6,"print*");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\027  call simplifications:");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\017simplifications");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\022traversal phase...");
lf[124]=C_h_intern(&lf[124],34,"\010compilerperform-pre-optimization!");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\023Removed `not\047 forms");
lf[126]=C_h_intern(&lf[126],24,"node-subexpressions-set!");
lf[127]=C_h_intern(&lf[127],7,"reverse");
lf[128]=C_h_intern(&lf[128],20,"node-parameters-set!");
lf[129]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[130]=C_h_intern(&lf[130],17,"\010compilerget-list");
lf[131]=C_h_intern(&lf[131],3,"not");
lf[132]=C_h_intern(&lf[132],10,"call-sites");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\031pre-optimization phase...");
lf[134]=C_h_intern(&lf[134],24,"register-simplifications");
lf[135]=C_h_intern(&lf[135],19,"\003syshash-table-set!");
lf[136]=C_h_intern(&lf[136],38,"\010compilerreorganize-recursive-bindings");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000!converted assignments to bindings");
lf[138]=C_h_intern(&lf[138],10,"fold-right");
lf[139]=C_h_intern(&lf[139],4,"fold");
lf[140]=C_h_intern(&lf[140],16,"topological-sort");
lf[141]=C_h_intern(&lf[141],6,"lset<=");
lf[142]=C_h_intern(&lf[142],10,"filter-map");
lf[143]=C_h_intern(&lf[143],6,"filter");
lf[144]=C_h_intern(&lf[144],10,"append-map");
lf[145]=C_h_intern(&lf[145],28,"\010compilerscan-used-variables");
lf[146]=C_h_intern(&lf[146],4,"cons");
lf[147]=C_h_intern(&lf[147],27,"\010compilersubstitution-table");
lf[148]=C_h_intern(&lf[148],16,"\010compilerrewrite");
lf[149]=C_h_intern(&lf[149],28,"\010compilersimplify-named-call");
lf[150]=C_h_intern(&lf[150],37,"\010compilerinline-substitutions-enabled");
lf[151]=C_h_intern(&lf[151],11,"\004coreinline");
lf[152]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[154]=C_h_intern(&lf[154],6,"unsafe");
lf[155]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[157]=C_h_intern(&lf[157],11,"number-type");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[162]=C_h_intern(&lf[162],6,"fixnum");
lf[163]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[164]=C_h_intern(&lf[164],21,"\010compilerfold-boolean");
lf[165]=C_h_intern(&lf[165],6,"flonum");
lf[166]=C_h_intern(&lf[166],7,"generic");
lf[167]=C_h_intern(&lf[167],5,"cons*");
lf[168]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[169]=C_h_intern(&lf[169],9,"\004coreproc");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[175]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[176]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[177]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[178]=C_h_intern(&lf[178],19,"\010compilerfold-inner");
lf[179]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[180]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[181]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[182]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[183]=C_h_intern(&lf[183],5,"fifth");
lf[184]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[185]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[186]=C_h_intern(&lf[186],13,"\010compilerbomb");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\023bad type (optimize)");
lf[188]=C_h_intern(&lf[188],34,"\010compilertransform-direct-lambdas!");
lf[189]=C_h_intern(&lf[189],5,"boxed");
lf[190]=C_h_intern(&lf[190],18,"\004coredirect_lambda");
lf[191]=C_h_intern(&lf[191],15,"\004coreinline_ref");
lf[192]=C_h_intern(&lf[192],37,"\010compilerestimate-foreign-result-size");
lf[193]=C_h_intern(&lf[193],19,"\004coreinline_loc_ref");
lf[194]=C_h_intern(&lf[194],16,"\004coredirect_call");
lf[195]=C_h_intern(&lf[195],5,"lset=");
lf[196]=C_h_intern(&lf[196],6,"delete");
lf[197]=C_h_intern(&lf[197],4,"quit");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000;known procedure called with wrong number of arguments: `~A\047");
lf[199]=C_h_intern(&lf[199],15,"lset-difference");
lf[200]=C_h_intern(&lf[200],15,"node-class-set!");
lf[201]=C_h_intern(&lf[201],12,"\004corerecurse");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[203]=C_h_intern(&lf[203],4,"take");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\014missing kvar");
lf[206]=C_h_intern(&lf[206],11,"\004corereturn");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\017bad call (leaf)");
lf[208]=C_h_intern(&lf[208],6,"cdaddr");
lf[209]=C_h_intern(&lf[209],6,"caaddr");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid parameter list");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\0006direct leaf routine with hoistable closures/allocation");
lf[212]=C_h_intern(&lf[212],6,"unzip1");
lf[213]=C_h_intern(&lf[213],16,"\003sysmake-promise");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\036direct leaf routine/allocation");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000(direct leaf routine optimization pass...");
lf[216]=C_h_intern(&lf[216],32,"\010compilerperform-lambda-lifting!");
lf[217]=C_h_intern(&lf[217],23,"\003syshash-table-for-each");
lf[218]=C_h_intern(&lf[218],1,"+");
lf[219]=C_h_intern(&lf[219],14,"\004coreprimitive");
lf[220]=C_h_intern(&lf[220],7,"delete!");
lf[221]=C_h_intern(&lf[221],11,"concatenate");
lf[222]=C_h_intern(&lf[222],5,"count");
lf[223]=C_h_intern(&lf[223],22,"\010compilerhide-variable");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\037moving liftables to toplevel...");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\032removing local bindings...");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\026changing call sites...");
lf[227]=C_h_intern(&lf[227],12,"pretty-print");
lf[228]=C_h_intern(&lf[228],1,"l");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\026additional parameters:");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\035gathering extra parameters...");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\031liftable local procedures");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000Aeliminating liftables by access-lists and non-liftable callees...");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\014accessibles:");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\031computing access-lists...");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\013call-graph:");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\034eliminating non-liftables...");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\026building call graph...");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\026gathering liftables...");
lf[239]=C_h_intern(&lf[239],11,"make-vector");
lf[240]=C_h_intern(&lf[240],3,"var");
lf[241]=C_h_intern(&lf[241],1,"y");
lf[242]=C_h_intern(&lf[242],2,"d2");
lf[243]=C_h_intern(&lf[243],1,"z");
lf[244]=C_h_intern(&lf[244],2,"d3");
lf[245]=C_h_intern(&lf[245],2,"d1");
lf[246]=C_h_intern(&lf[246],2,"op");
lf[247]=C_h_intern(&lf[247],5,"clist");
lf[248]=C_h_intern(&lf[248],34,"\010compilermembership-test-operators");
lf[249]=C_h_intern(&lf[249],32,"\010compilermembership-unfold-limit");
lf[250]=C_h_intern(&lf[250],4,"var1");
lf[251]=C_h_intern(&lf[251],4,"var0");
lf[252]=C_h_intern(&lf[252],6,"const1");
lf[253]=C_h_intern(&lf[253],4,"var2");
lf[254]=C_h_intern(&lf[254],6,"const2");
lf[255]=C_h_intern(&lf[255],4,"rest");
lf[256]=C_h_intern(&lf[256],5,"body2");
lf[257]=C_h_intern(&lf[257],5,"body1");
lf[258]=C_h_intern(&lf[258],27,"\010compilereq-inline-operator");
lf[259]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\002\376\377\016");
lf[260]=C_h_intern(&lf[260],19,"\010compilerimmediate\077");
lf[261]=C_h_intern(&lf[261],5,"const");
lf[262]=C_h_intern(&lf[262],1,"n");
lf[263]=C_h_intern(&lf[263],7,"clauses");
lf[264]=C_h_intern(&lf[264],4,"body");
lf[265]=C_h_intern(&lf[265],1,"d");
lf[266]=C_h_intern(&lf[266],4,"more");
lf[267]=C_h_intern(&lf[267],4,"args");
lf[268]=C_h_intern(&lf[268],1,"a");
lf[269]=C_h_intern(&lf[269],1,"b");
lf[270]=C_h_intern(&lf[270],1,"c");
lf[271]=C_h_intern(&lf[271],4,"cdar");
C_register_lf2(lf,272,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3731,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3729 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3734,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3732 in k3729 */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3734,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! ##compiler#scan-toplevel-assignments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3736,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4102,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 127  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[239]+1)))(4,*((C_word*)lf[239]+1),t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k4100 in k3732 in k3729 */
static void C_ccall f_4102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4102,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1 /* (set! ##compiler#simplifications ...) */,t1);
t3=C_set_block_item(lf[38] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t4=C_mutate((C_word*)lf[39]+1 /* (set! ##compiler#perform-high-level-optimizations ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4105,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[124]+1 /* (set! ##compiler#perform-pre-optimization! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5966,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[134]+1 /* (set! register-simplifications ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6285,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6292,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=C_a_i_cons(&a,2,lf[268],C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,lf[2],t9);
t11=C_a_i_cons(&a,2,lf[269],lf[270]);
t12=C_a_i_cons(&a,2,t10,t11);
t13=C_a_i_cons(&a,2,lf[265],t12);
t14=C_a_i_cons(&a,2,lf[8],t13);
t15=C_a_i_cons(&a,2,lf[265],C_SCHEME_END_OF_LIST);
t16=C_a_i_cons(&a,2,lf[270],t15);
t17=C_a_i_cons(&a,2,lf[269],t16);
t18=C_a_i_cons(&a,2,lf[268],t17);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14625,tmp=(C_word)a,a+=2,tmp);
t20=C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=C_a_i_cons(&a,2,t18,t20);
t22=C_a_i_cons(&a,2,t14,t21);
t23=C_a_i_list(&a,1,t22);
/* optimizer.scm: 496  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t7,C_retrieve(lf[37]),lf[8],t23);}

/* a14624 in k4100 in k3732 in k3729 */
static void C_ccall f_14625(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_14625,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14633,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 505  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[46]))(4,*((C_word*)lf[46]+1),t7,C_retrieve(lf[147]),t3);}

/* k14631 in a14624 in k4100 in k3732 in k3729 */
static void C_ccall f_14633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14633,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14638,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_14638(t6,((C_word*)t0)[2],t2);}

/* loop in k14631 in a14624 in k4100 in k3732 in k3729 */
static void C_fcall f_14638(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14638,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14648,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14688,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 507  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t4,t2);}}

/* k14686 in loop in k14631 in a14624 in k4100 in k3732 in k3729 */
static void C_ccall f_14688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14692,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 507  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[271]+1)))(3,*((C_word*)lf[271]+1),t2,((C_word*)t0)[2]);}

/* k14690 in k14686 in loop in k14631 in a14624 in k4100 in k3732 in k3729 */
static void C_ccall f_14692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 507  simplify-named-call */
((C_proc9)C_retrieve_symbol_proc(lf[149]))(9,*((C_word*)lf[149]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k14646 in loop in k14631 in a14624 in k4100 in k3732 in k3729 */
static void C_ccall f_14648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14648,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14652,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* g10111012 */
t3=t2;
f_14652(t3,((C_word*)t0)[4],t1);}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 514  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_14638(t3,((C_word*)t0)[4],t2);}}

/* g1011 in k14646 in loop in k14631 in a14624 in k4100 in k3732 in k3729 */
static void C_fcall f_14652(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14652,NULL,3,t0,t1,t2);}
t3=C_i_assq(((C_word*)t0)[2],C_retrieve(lf[38]));
if(C_truep(t3)){
t4=C_i_cdr(t3);
t5=C_fixnum_increase(t4);
t6=C_i_set_cdr(t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14674,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 512  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),t4,((C_word*)t0)[2],C_fix(1),C_retrieve(lf[38]));}}

/* k14672 in g1011 in k14646 in loop in k14631 in a14624 in k4100 in k3732 in k3729 */
static void C_ccall f_14674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[38]+1 /* (set! ##compiler#simplified-ops ...) */,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word ab[446],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6295,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,lf[250],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[251],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[2],t6);
t8=C_a_i_cons(&a,2,lf[252],C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,lf[41],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,t7,t11);
t13=C_a_i_cons(&a,2,t4,t12);
t14=C_a_i_cons(&a,2,lf[151],t13);
t15=C_a_i_cons(&a,2,lf[250],C_SCHEME_END_OF_LIST);
t16=C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=C_a_i_cons(&a,2,lf[2],t16);
t18=C_a_i_cons(&a,2,lf[253],C_SCHEME_END_OF_LIST);
t19=C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t20=C_a_i_cons(&a,2,lf[251],C_SCHEME_END_OF_LIST);
t21=C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=C_a_i_cons(&a,2,lf[2],t21);
t23=C_a_i_cons(&a,2,lf[254],C_SCHEME_END_OF_LIST);
t24=C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=C_a_i_cons(&a,2,lf[41],t24);
t26=C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=C_a_i_cons(&a,2,t22,t26);
t28=C_a_i_cons(&a,2,t19,t27);
t29=C_a_i_cons(&a,2,lf[151],t28);
t30=C_a_i_cons(&a,2,lf[253],C_SCHEME_END_OF_LIST);
t31=C_a_i_cons(&a,2,t30,C_SCHEME_END_OF_LIST);
t32=C_a_i_cons(&a,2,lf[2],t31);
t33=C_a_i_cons(&a,2,lf[255],C_SCHEME_END_OF_LIST);
t34=C_a_i_cons(&a,2,lf[256],t33);
t35=C_a_i_cons(&a,2,t32,t34);
t36=C_a_i_cons(&a,2,lf[242],t35);
t37=C_a_i_cons(&a,2,lf[4],t36);
t38=C_a_i_cons(&a,2,t37,C_SCHEME_END_OF_LIST);
t39=C_a_i_cons(&a,2,t29,t38);
t40=C_a_i_cons(&a,2,t18,t39);
t41=C_a_i_cons(&a,2,lf[5],t40);
t42=C_a_i_cons(&a,2,t41,C_SCHEME_END_OF_LIST);
t43=C_a_i_cons(&a,2,lf[257],t42);
t44=C_a_i_cons(&a,2,t17,t43);
t45=C_a_i_cons(&a,2,lf[245],t44);
t46=C_a_i_cons(&a,2,lf[4],t45);
t47=C_a_i_cons(&a,2,t46,C_SCHEME_END_OF_LIST);
t48=C_a_i_cons(&a,2,t14,t47);
t49=C_a_i_cons(&a,2,t3,t48);
t50=C_a_i_cons(&a,2,lf[5],t49);
t51=C_a_i_cons(&a,2,lf[255],C_SCHEME_END_OF_LIST);
t52=C_a_i_cons(&a,2,lf[242],t51);
t53=C_a_i_cons(&a,2,lf[245],t52);
t54=C_a_i_cons(&a,2,lf[256],t53);
t55=C_a_i_cons(&a,2,lf[257],t54);
t56=C_a_i_cons(&a,2,lf[254],t55);
t57=C_a_i_cons(&a,2,lf[252],t56);
t58=C_a_i_cons(&a,2,lf[246],t57);
t59=C_a_i_cons(&a,2,lf[253],t58);
t60=C_a_i_cons(&a,2,lf[250],t59);
t61=C_a_i_cons(&a,2,lf[251],t60);
t62=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14304,tmp=(C_word)a,a+=2,tmp);
t63=C_a_i_cons(&a,2,t62,C_SCHEME_END_OF_LIST);
t64=C_a_i_cons(&a,2,t61,t63);
t65=C_a_i_cons(&a,2,t50,t64);
t66=C_a_i_cons(&a,2,lf[240],C_SCHEME_END_OF_LIST);
t67=C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t68=C_a_i_cons(&a,2,lf[251],C_SCHEME_END_OF_LIST);
t69=C_a_i_cons(&a,2,t68,C_SCHEME_END_OF_LIST);
t70=C_a_i_cons(&a,2,lf[2],t69);
t71=C_a_i_cons(&a,2,lf[261],C_SCHEME_END_OF_LIST);
t72=C_a_i_cons(&a,2,t71,C_SCHEME_END_OF_LIST);
t73=C_a_i_cons(&a,2,lf[41],t72);
t74=C_a_i_cons(&a,2,t73,C_SCHEME_END_OF_LIST);
t75=C_a_i_cons(&a,2,t70,t74);
t76=C_a_i_cons(&a,2,t67,t75);
t77=C_a_i_cons(&a,2,lf[151],t76);
t78=C_a_i_cons(&a,2,lf[240],C_SCHEME_END_OF_LIST);
t79=C_a_i_cons(&a,2,t78,C_SCHEME_END_OF_LIST);
t80=C_a_i_cons(&a,2,lf[2],t79);
t81=C_a_i_cons(&a,2,lf[262],C_SCHEME_END_OF_LIST);
t82=C_a_i_cons(&a,2,lf[251],C_SCHEME_END_OF_LIST);
t83=C_a_i_cons(&a,2,t82,C_SCHEME_END_OF_LIST);
t84=C_a_i_cons(&a,2,lf[2],t83);
t85=C_a_i_cons(&a,2,t84,lf[263]);
t86=C_a_i_cons(&a,2,t81,t85);
t87=C_a_i_cons(&a,2,lf[24],t86);
t88=C_a_i_cons(&a,2,t87,C_SCHEME_END_OF_LIST);
t89=C_a_i_cons(&a,2,lf[264],t88);
t90=C_a_i_cons(&a,2,t80,t89);
t91=C_a_i_cons(&a,2,lf[265],t90);
t92=C_a_i_cons(&a,2,lf[4],t91);
t93=C_a_i_cons(&a,2,t92,C_SCHEME_END_OF_LIST);
t94=C_a_i_cons(&a,2,t77,t93);
t95=C_a_i_cons(&a,2,t66,t94);
t96=C_a_i_cons(&a,2,lf[5],t95);
t97=C_a_i_cons(&a,2,lf[263],C_SCHEME_END_OF_LIST);
t98=C_a_i_cons(&a,2,lf[262],t97);
t99=C_a_i_cons(&a,2,lf[264],t98);
t100=C_a_i_cons(&a,2,lf[265],t99);
t101=C_a_i_cons(&a,2,lf[261],t100);
t102=C_a_i_cons(&a,2,lf[251],t101);
t103=C_a_i_cons(&a,2,lf[246],t102);
t104=C_a_i_cons(&a,2,lf[240],t103);
t105=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14083,tmp=(C_word)a,a+=2,tmp);
t106=C_a_i_cons(&a,2,t105,C_SCHEME_END_OF_LIST);
t107=C_a_i_cons(&a,2,t104,t106);
t108=C_a_i_cons(&a,2,t96,t107);
t109=C_a_i_cons(&a,2,lf[250],C_SCHEME_END_OF_LIST);
t110=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t111=C_a_i_cons(&a,2,lf[11],t110);
t112=C_a_i_cons(&a,2,lf[266],C_SCHEME_END_OF_LIST);
t113=C_a_i_cons(&a,2,t111,t112);
t114=C_a_i_cons(&a,2,t109,t113);
t115=C_a_i_cons(&a,2,lf[5],t114);
t116=C_a_i_cons(&a,2,lf[266],C_SCHEME_END_OF_LIST);
t117=C_a_i_cons(&a,2,lf[250],t116);
t118=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13682,tmp=(C_word)a,a+=2,tmp);
t119=C_a_i_cons(&a,2,t118,C_SCHEME_END_OF_LIST);
t120=C_a_i_cons(&a,2,t117,t119);
t121=C_a_i_cons(&a,2,t115,t120);
t122=C_a_i_cons(&a,2,lf[240],C_SCHEME_END_OF_LIST);
t123=C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t124=C_a_i_cons(&a,2,t123,lf[267]);
t125=C_a_i_cons(&a,2,lf[151],t124);
t126=C_a_i_cons(&a,2,lf[240],C_SCHEME_END_OF_LIST);
t127=C_a_i_cons(&a,2,t126,C_SCHEME_END_OF_LIST);
t128=C_a_i_cons(&a,2,lf[2],t127);
t129=C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t130=C_a_i_cons(&a,2,lf[84],t129);
t131=C_a_i_cons(&a,2,t128,t130);
t132=C_a_i_cons(&a,2,lf[265],t131);
t133=C_a_i_cons(&a,2,lf[4],t132);
t134=C_a_i_cons(&a,2,t133,C_SCHEME_END_OF_LIST);
t135=C_a_i_cons(&a,2,t125,t134);
t136=C_a_i_cons(&a,2,t122,t135);
t137=C_a_i_cons(&a,2,lf[5],t136);
t138=C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t139=C_a_i_cons(&a,2,lf[84],t138);
t140=C_a_i_cons(&a,2,lf[265],t139);
t141=C_a_i_cons(&a,2,lf[267],t140);
t142=C_a_i_cons(&a,2,lf[246],t141);
t143=C_a_i_cons(&a,2,lf[240],t142);
t144=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13534,tmp=(C_word)a,a+=2,tmp);
t145=C_a_i_cons(&a,2,t144,C_SCHEME_END_OF_LIST);
t146=C_a_i_cons(&a,2,t143,t145);
t147=C_a_i_cons(&a,2,t137,t146);
t148=C_a_i_list(&a,4,t65,t108,t121,t147);
/* optimizer.scm: 496  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t2,C_retrieve(lf[37]),lf[5],t148);}

/* a13533 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13534(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_13534,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
if(C_truep(C_i_equalp(t4,C_retrieve(lf[258])))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13580,a[2]=t6,a[3]=t1,a[4]=t8,a[5]=t7,a[6]=t5,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 655  get-list */
((C_proc5)C_retrieve_symbol_proc(lf[130]))(5,*((C_word*)lf[130]+1),t9,t2,t3,lf[88]);}}

/* k13578 in a13533 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13580,2,t0,t1);}
t2=C_i_length(t1);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=C_a_i_list(&a,1,((C_word*)t0)[7]);
t5=((C_word*)t0)[6];
t6=C_a_i_record(&a,4,lf[10],lf[151],t4,t5);
t7=C_a_i_list(&a,3,t6,((C_word*)t0)[5],((C_word*)t0)[4]);
t8=((C_word*)t0)[3];
t9=((C_word*)t0)[2];
t10=t8;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_record(&a,4,lf[10],lf[4],t9,t7));}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* a13681 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13682,5,t0,t1,t2,t3,t4);}
t5=C_a_i_list(&a,1,t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13692,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_13692(t9,t1,t5,t4);}

/* loop1 in a13681 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_13692(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13692,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=C_slot(t4,C_fix(1));
t6=t3;
t7=C_slot(t6,C_fix(2));
t8=t3;
t9=C_slot(t8,C_fix(3));
t10=C_eqp(t5,lf[5]);
if(C_truep(t10)){
t11=C_i_cdr(t7);
if(C_truep(C_i_nullp(t11))){
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t7,a[6]=t9,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t13=C_i_car(t7);
/* optimizer.scm: 594  get */
((C_proc5)C_retrieve_symbol_proc(lf[40]))(5,*((C_word*)lf[40]+1),t12,((C_word*)t0)[2],t13,lf[112]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k14027 in loop1 in a13681 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_14029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14029,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 595  get */
((C_proc5)C_retrieve_symbol_proc(lf[40]))(5,*((C_word*)lf[40]+1),t2,((C_word*)t0)[2],t3,lf[88]);}}

/* k14019 in k14027 in loop1 in a13681 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_14021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14021,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_i_car(((C_word*)t0)[6]);
t3=C_slot(t2,C_fix(2));
t4=C_slot(t2,C_fix(3));
t5=C_slot(t2,C_fix(1));
t6=C_eqp(t5,lf[11]);
if(C_truep(t6)){
t7=C_i_car(((C_word*)t0)[5]);
t8=C_a_i_cons(&a,2,t7,((C_word*)t0)[4]);
t9=C_i_cadr(((C_word*)t0)[6]);
/* optimizer.scm: 600  loop1 */
t10=((C_word*)((C_word*)t0)[3])[1];
f_13692(t10,((C_word*)t0)[7],t8,t9);}
else{
t7=C_eqp(t5,lf[9]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13798,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 602  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t8,((C_word*)t0)[4]);}
else{
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}

/* k13796 in k14019 in k14027 in loop1 in a13681 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13798,2,t0,t1);}
if(C_truep(C_i_pairp(t1))){
t2=C_i_car(((C_word*)t0)[6]);
t3=C_i_car(t1);
t4=C_eqp(t2,t3);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[5]);
t6=C_a_i_list(&a,1,t5);
t7=C_i_cdr(t1);
t8=C_i_cadr(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13827,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_13827(t12,((C_word*)t0)[2],t6,t7,t8);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k13796 in k14019 in k14027 in loop1 in a13681 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_13827(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13827,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
t6=C_slot(t5,C_fix(1));
t7=t4;
t8=C_slot(t7,C_fix(2));
t9=t4;
t10=C_slot(t9,C_fix(3));
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13858,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,a[8]=t10,tmp=(C_word)a,a+=9,tmp);
t12=C_eqp(t6,lf[5]);
if(C_truep(t12)){
t13=C_i_cdr(t8);
if(C_truep(C_i_nullp(t13))){
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13997,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t10,a[5]=t3,a[6]=t11,tmp=(C_word)a,a+=7,tmp);
t15=C_i_car(t8);
/* optimizer.scm: 613  get */
((C_proc5)C_retrieve_symbol_proc(lf[40]))(5,*((C_word*)lf[40]+1),t14,((C_word*)t0)[2],t15,lf[112]);}
else{
t14=t11;
f_13858(t14,C_SCHEME_FALSE);}}
else{
t13=t11;
f_13858(t13,C_SCHEME_FALSE);}}

/* k13995 in loop2 in k13796 in k14019 in k14027 in loop1 in a13681 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13997,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_13858(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13989,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 614  get */
((C_proc5)C_retrieve_symbol_proc(lf[40]))(5,*((C_word*)lf[40]+1),t2,((C_word*)t0)[2],t3,lf[88]);}}

/* k13987 in k13995 in loop2 in k13796 in k14019 in k14027 in loop1 in a13681 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_13858(t2,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_slot(t2,C_fix(1));
t4=C_eqp(lf[9],t3);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[3]);
t6=C_i_car(((C_word*)t0)[2]);
t7=C_slot(t6,C_fix(2));
t8=C_i_car(t7);
t9=((C_word*)t0)[4];
f_13858(t9,C_eqp(t5,t8));}
else{
t5=((C_word*)t0)[4];
f_13858(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
f_13858(t2,C_SCHEME_FALSE);}}}

/* k13856 in loop2 in k13796 in k14019 in k14027 in loop1 in a13681 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_13858(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13858,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[8]);
t3=C_slot(t2,C_fix(3));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
t6=C_i_cdr(((C_word*)t0)[6]);
t7=C_i_cadr(((C_word*)t0)[8]);
/* optimizer.scm: 618  loop2 */
t8=((C_word*)((C_word*)t0)[5])[1];
f_13827(t8,((C_word*)t0)[4],t5,t6,t7);}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13901,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13911,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* a13910 in k13856 in loop2 in k13796 in k14019 in k14027 in loop1 in a13681 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13911(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13911,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:C_SCHEME_FALSE));}

/* a13900 in k13856 in loop2 in k13796 in k14019 in k14027 in loop1 in a13681 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13909,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 623  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t2,((C_word*)t0)[2]);}

/* k13907 in a13900 in k13856 in loop2 in k13796 in k14019 in k14027 in loop1 in a13681 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 623  reorganize-recursive-bindings */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a14082 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_14083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=11) C_bad_argc_2(c,11,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr11,(void*)f_14083,11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
if(C_truep(C_i_equalp(t4,C_retrieve(lf[258])))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_14096,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t6,a[6]=t10,a[7]=t8,a[8]=t1,a[9]=t9,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 564  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[260]))(3,*((C_word*)lf[260]+1),t11,t6);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k14094 in a14082 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_14096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14096,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14138,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 565  get-list */
((C_proc5)C_retrieve_symbol_proc(lf[130]))(5,*((C_word*)lf[130]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[88]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14136 in k14094 in a14082 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_14138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14138,2,t0,t1);}
t2=C_i_length(t1);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=C_fixnum_increase(((C_word*)t0)[7]);
t5=C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14118,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14122,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 569  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t7,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k14120 in k14136 in k14094 in a14082 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_14122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14126,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 570  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t2,((C_word*)t0)[2]);}

/* k14124 in k14120 in k14136 in k14094 in a14082 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_14126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 569  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[167]))(6,*((C_word*)lf[167]+1),((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14116 in k14136 in k14094 in a14082 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_14118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14118,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[24],((C_word*)t0)[2],t1));}

/* a14303 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_14304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13){
C_word tmp;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(c!=14) C_bad_argc_2(c,14,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr14,(void*)f_14304,14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}
if(C_truep(C_i_equalp(t6,C_retrieve(lf[258])))){
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_14317,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,a[6]=t7,a[7]=t8,a[8]=t1,a[9]=t13,a[10]=t10,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 537  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[260]))(3,*((C_word*)lf[260]+1),t14,t7);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}

/* k14315 in a14303 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_14317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14317,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_14323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 538  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[260]))(3,*((C_word*)lf[260]+1),t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14321 in k14315 in a14303 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_14323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14323,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_14375,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 539  get-list */
((C_proc5)C_retrieve_symbol_proc(lf[130]))(5,*((C_word*)lf[130]+1),t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[88]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14373 in k14321 in k14315 in a14303 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_14375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14375,2,t0,t1);}
t2=C_i_length(t1);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14367,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 540  get-list */
((C_proc5)C_retrieve_symbol_proc(lf[130]))(5,*((C_word*)lf[130]+1),t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[88]);}
else{
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k14365 in k14373 in k14321 in k14315 in a14303 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_14367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14367,2,t0,t1);}
t2=C_i_length(t1);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14351,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 544  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k14349 in k14365 in k14373 in k14321 in k14315 in a14303 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_14351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14355,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 545  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t2,((C_word*)t0)[2]);}

/* k14353 in k14349 in k14365 in k14373 in k14321 in k14315 in a14303 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_14355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14359,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 547  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t2,((C_word*)t0)[2]);}

/* k14357 in k14353 in k14349 in k14365 in k14373 in k14321 in k14315 in a14303 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_14359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14359,2,t0,t1);}
t2=C_a_i_list(&a,6,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[24],lf[259],t2));}

/* k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word ab[166],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6298,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,lf[240],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[2],t4);
t6=C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,t5,t6);
t8=C_a_i_cons(&a,2,lf[242],t7);
t9=C_a_i_cons(&a,2,lf[8],t8);
t10=C_a_i_cons(&a,2,lf[240],C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,lf[2],t11);
t13=C_a_i_cons(&a,2,lf[243],C_SCHEME_END_OF_LIST);
t14=C_a_i_cons(&a,2,t12,t13);
t15=C_a_i_cons(&a,2,lf[244],t14);
t16=C_a_i_cons(&a,2,lf[8],t15);
t17=C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=C_a_i_cons(&a,2,t9,t17);
t19=C_a_i_cons(&a,2,lf[84],t18);
t20=C_a_i_cons(&a,2,lf[245],t19);
t21=C_a_i_cons(&a,2,lf[4],t20);
t22=C_a_i_cons(&a,2,lf[240],C_SCHEME_END_OF_LIST);
t23=C_a_i_cons(&a,2,lf[243],t22);
t24=C_a_i_cons(&a,2,lf[241],t23);
t25=C_a_i_cons(&a,2,lf[84],t24);
t26=C_a_i_cons(&a,2,lf[244],t25);
t27=C_a_i_cons(&a,2,lf[242],t26);
t28=C_a_i_cons(&a,2,lf[245],t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13371,tmp=(C_word)a,a+=2,tmp);
t30=C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=C_a_i_cons(&a,2,t28,t30);
t32=C_a_i_cons(&a,2,t21,t31);
t33=C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t34=C_a_i_cons(&a,2,lf[247],C_SCHEME_END_OF_LIST);
t35=C_a_i_cons(&a,2,t34,C_SCHEME_END_OF_LIST);
t36=C_a_i_cons(&a,2,lf[41],t35);
t37=C_a_i_cons(&a,2,t36,C_SCHEME_END_OF_LIST);
t38=C_a_i_cons(&a,2,lf[84],t37);
t39=C_a_i_cons(&a,2,t33,t38);
t40=C_a_i_cons(&a,2,lf[151],t39);
t41=C_a_i_cons(&a,2,lf[243],C_SCHEME_END_OF_LIST);
t42=C_a_i_cons(&a,2,lf[241],t41);
t43=C_a_i_cons(&a,2,t40,t42);
t44=C_a_i_cons(&a,2,lf[245],t43);
t45=C_a_i_cons(&a,2,lf[4],t44);
t46=C_a_i_cons(&a,2,lf[243],C_SCHEME_END_OF_LIST);
t47=C_a_i_cons(&a,2,lf[241],t46);
t48=C_a_i_cons(&a,2,lf[247],t47);
t49=C_a_i_cons(&a,2,lf[84],t48);
t50=C_a_i_cons(&a,2,lf[246],t49);
t51=C_a_i_cons(&a,2,lf[245],t50);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13175,tmp=(C_word)a,a+=2,tmp);
t53=C_a_i_cons(&a,2,t52,C_SCHEME_END_OF_LIST);
t54=C_a_i_cons(&a,2,t51,t53);
t55=C_a_i_cons(&a,2,t45,t54);
t56=C_a_i_list(&a,2,t32,t55);
/* optimizer.scm: 496  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t2,C_retrieve(lf[37]),lf[4],t56);}

/* a13174 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_13175,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=C_i_assoc(t4,C_retrieve(lf[248]));
if(C_truep(t9)){
if(C_truep(C_i_listp(t6))){
t10=C_i_length(t6);
t11=C_retrieve(lf[249]);
if(C_truep(C_fixnum_lessp(t10,t11))){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13197,a[2]=t6,a[3]=t1,a[4]=t5,a[5]=t3,a[6]=t8,a[7]=t7,a[8]=t9,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 693  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[96]))(2,*((C_word*)lf[96]+1),t12);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k13195 in a13174 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13197,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[8]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,1,t1);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13233,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13235,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13277,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 710  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t7,C_SCHEME_FALSE);}

/* k13275 in k13195 in a13174 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 702  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a13234 in k13195 in a13174 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13235,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13269,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 707  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t4,((C_word*)t0)[2]);}

/* k13267 in a13234 in k13195 in a13174 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13273,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 707  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t2,((C_word*)t0)[2]);}

/* k13271 in k13267 in a13234 in k13195 in a13174 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13273,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_record(&a,4,lf[10],lf[151],((C_word*)t0)[4],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 708  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t4,C_SCHEME_TRUE);}

/* k13259 in k13271 in k13267 in a13234 in k13195 in a13174 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13261,2,t0,t1);}
t2=C_a_i_list(&a,3,((C_word*)t0)[4],t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[23],C_SCHEME_END_OF_LIST,t2));}

/* k13231 in k13195 in a13174 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13233,2,t0,t1);}
t2=C_a_i_list(&a,3,t1,((C_word*)t0)[7],((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=C_a_i_record(&a,4,lf[10],lf[4],t3,t2);
t5=C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record(&a,4,lf[10],lf[5],((C_word*)t0)[2],t5));}

/* a13370 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_13371,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
if(C_truep(C_retrieve(lf[150]))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13391,a[2]=t4,a[3]=t1,a[4]=t8,a[5]=t7,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 678  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t10,t9);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k13389 in a13370 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13391,2,t0,t1);}
t2=C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=C_a_i_record(&a,4,lf[10],lf[23],C_SCHEME_END_OF_LIST,t2);
t4=C_a_i_list(&a,2,t1,t3);
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record(&a,4,lf[10],lf[8],t6,t4));}

/* k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6298,2,t0,t1);}
t2=C_mutate((C_word*)lf[136]+1 /* (set! ##compiler#reorganize-recursive-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6300,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6787,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 805  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[239]+1)))(4,*((C_word*)lf[239]+1),t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6787,2,t0,t1);}
t2=C_mutate((C_word*)lf[147]+1 /* (set! ##compiler#substitution-table ...) */,t1);
t3=C_mutate((C_word*)lf[148]+1 /* (set! ##compiler#rewrite ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6789,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[149]+1 /* (set! ##compiler#simplify-named-call ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6809,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[188]+1 /* (set! ##compiler#transform-direct-lambdas! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9168,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[216]+1 /* (set! ##compiler#perform-lambda-lifting! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10553,tmp=(C_word)a,a+=2,tmp));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}

/* ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[62],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10553,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10556,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t25=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10659,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t26=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10947,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t27=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11080,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t28=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11361,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t29=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11672,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t30=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12081,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t31=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12609,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t32=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12807,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t33=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13048,a[2]=t7,a[3]=t9,a[4]=t11,a[5]=t13,a[6]=t15,a[7]=t17,a[8]=t21,a[9]=t23,a[10]=t1,a[11]=t19,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1775 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t33,lf[35],lf[238]);}

/* k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_13051,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1776 find-lifting-candidates */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10556(t3,t2);}

/* k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13054,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1777 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,lf[35],lf[237]);}

/* k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_13057,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1778 build-call-graph */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10659(t3,t2,((C_word*)t0)[3]);}

/* k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13060,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1779 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,lf[35],lf[236]);}

/* k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13063,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1780 eliminate */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10947(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13066,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13146,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1781 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t3,lf[228],lf[235]);}

/* k13144 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1781 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[227]))(3,*((C_word*)lf[227]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_13066(2,t2,C_SCHEME_UNDEFINED);}}

/* k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1782 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,lf[35],lf[234]);}

/* k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13072,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1783 collect-accessibles */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11080(t3,t2,((C_word*)t0)[3]);}

/* k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13140,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1784 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t3,lf[228],lf[233]);}

/* k13138 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1784 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[227]))(3,*((C_word*)lf[227]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_13075(2,t2,C_SCHEME_UNDEFINED);}}

/* k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1785 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,lf[35],lf[232]);}

/* k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13081,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13137,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1786 eliminate4 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_11361(t4,t3,((C_word*)t0)[2]);}

/* k13135 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13137,2,t0,t1);}
t2=C_i_length(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11327,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_11327(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k13135 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11327(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11327,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11331,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11345,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1580 filter */
((C_proc4)C_retrieve_symbol_proc(lf[143]))(4,*((C_word*)lf[143]+1),t4,t5,t2);}

/* a11344 in loop in k13135 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11345(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11345,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11351,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_i_cddr(t2);
/* optimizer.scm: 1580 every */
((C_proc4)C_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),t1,t3,t4);}

/* a11350 in a11344 in loop in k13135 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11351(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11351,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_assq(t2,((C_word*)t0)[2]));}

/* k11329 in loop in k13135 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_length(t1);
t3=((C_word*)t0)[4];
t4=C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
/* optimizer.scm: 1584 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11327(t5,((C_word*)t0)[3],t1,t2);}}

/* k13079 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(t1))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13127,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13129,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-promise */
t5=*((C_word*)lf[213]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=t2;
f_13084(2,t3,C_SCHEME_UNDEFINED);}}

/* a13128 in k13079 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13129,2,t0,t1);}
/* optimizer.scm: 1788 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[212]))(3,*((C_word*)lf[212]+1),t1,((C_word*)t0)[2]);}

/* k13125 in k13079 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1788 debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),((C_word*)t0)[2],lf[31],lf[231],t1);}

/* k13082 in k13079 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1789 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,lf[35],lf[230]);}

/* k13085 in k13082 in k13079 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13090,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1790 compute-extra-variables */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11672(t3,t2,((C_word*)t0)[5]);}

/* k13088 in k13085 in k13082 in k13079 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13114,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1791 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t3,lf[228],lf[229]);}

/* k13112 in k13088 in k13085 in k13082 in k13079 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1791 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[227]))(3,*((C_word*)lf[227]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_13093(2,t2,C_SCHEME_UNDEFINED);}}

/* k13091 in k13088 in k13085 in k13082 in k13079 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1792 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,lf[35],lf[226]);}

/* k13094 in k13091 in k13088 in k13085 in k13082 in k13079 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13099,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1793 extend-call-sites! */
t3=((C_word*)((C_word*)t0)[2])[1];
f_12609(t3,t2,((C_word*)t0)[4]);}

/* k13097 in k13094 in k13091 in k13088 in k13085 in k13082 in k13079 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13102,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1794 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,lf[35],lf[225]);}

/* k13100 in k13097 in k13094 in k13091 in k13088 in k13085 in k13082 in k13079 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13105,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1795 remove-local-bindings! */
t3=((C_word*)((C_word*)t0)[2])[1];
f_12807(t3,t2,((C_word*)t0)[4]);}

/* k13103 in k13100 in k13097 in k13094 in k13091 in k13088 in k13085 in k13082 in k13079 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1796 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,lf[35],lf[224]);}

/* k13106 in k13103 in k13100 in k13097 in k13094 in k13091 in k13088 in k13085 in k13082 in k13079 in k13076 in k13073 in k13070 in k13067 in k13064 in k13061 in k13058 in k13055 in k13052 in k13049 in k13046 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1797 reconstruct! */
t2=((C_word*)((C_word*)t0)[5])[1];
f_12081(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12807(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12807,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12813,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_12813(t6,t1,((C_word*)t0)[2]);}

/* walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12813(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12813,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t2;
t6=C_slot(t5,C_fix(2));
t7=t2;
t8=C_slot(t7,C_fix(3));
t9=C_eqp(t4,lf[5]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12847,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t11=t2;
t12=C_slot(t11,C_fix(3));
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12938,a[2]=((C_word*)t0)[2],a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_12938(t16,t10,t12);}
else{
t10=C_eqp(t4,lf[9]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12968,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t12=t2;
t13=C_slot(t12,C_fix(3));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12998,a[2]=((C_word*)t0)[2],a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=((C_word*)t15)[1];
f_12998(t17,t11,t13);}
else{
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13024,a[2]=((C_word*)t0)[2],a[3]=t12,tmp=(C_word)a,a+=4,tmp));
t14=((C_word*)t12)[1];
f_13024(t14,t1,t8);}}}

/* loop3653 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_13024(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13024,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13034,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g36603661 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12813(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k13032 in loop3653 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_13024(t3,((C_word*)t0)[2],t2);}

/* loop3632 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12998(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12998,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13008,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g36393640 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12813(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k13006 in loop3632 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_13008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12998(t3,((C_word*)t0)[2],t2);}

/* k12966 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12968,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[5]);
if(C_truep(C_i_assq(t2,((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1770 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[200]))(4,*((C_word*)lf[200]+1),t3,((C_word*)t0)[2],lf[11]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12975 in k12966 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1771 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k12978 in k12975 in k12966 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1772 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop3595 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12938(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12938,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12948,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g36023603 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12813(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12946 in loop3595 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12938(t3,((C_word*)t0)[2],t2);}

/* k12845 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12847,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12852,a[2]=t7,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_12852(t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop3611 in k12845 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12852(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12852,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[6])[1]))){
t4=C_i_car(t3);
/* optimizer.scm: 1760 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[12]))(4,*((C_word*)lf[12]+1),t1,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12875,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12890,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1762 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t5,((C_word*)((C_word*)t0)[6])[1]);}}
else{
t4=C_i_car(t2);
if(C_truep(C_i_assq(t4,((C_word*)t0)[3]))){
t5=C_i_cdr(t2);
t6=C_i_cdr(t3);
t19=t1;
t20=t5;
t21=t6;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
t5=C_i_car(t2);
t6=C_a_i_cons(&a,2,t5,((C_word*)((C_word*)t0)[6])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[6])+1,t6);
t8=C_i_car(t3);
t9=C_a_i_cons(&a,2,t8,((C_word*)((C_word*)t0)[4])[1]);
t10=C_mutate(((C_word *)((C_word*)t0)[4])+1,t9);
t11=C_i_cdr(t2);
t12=C_i_cdr(t3);
t19=t1;
t20=t11;
t21=t12;
t1=t19;
t2=t20;
t3=t21;
goto loop;}}}

/* k12888 in doloop3611 in k12845 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1762 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k12873 in doloop3611 in k12845 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12882,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12886,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1763 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k12884 in k12873 in doloop3611 in k12845 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1763 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k12880 in k12873 in doloop3611 in k12845 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1763 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extend-call-sites! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12609(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12609,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12615,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_12615(t6,t1,((C_word*)t0)[2]);}

/* walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12615(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12615,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t2;
t6=C_slot(t5,C_fix(2));
t7=t2;
t8=C_slot(t7,C_fix(3));
t9=C_eqp(t4,lf[8]);
if(C_truep(t9)){
t10=C_i_car(t8);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12652,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t12=C_slot(t10,C_fix(1));
t13=C_eqp(lf[2],t12);
if(C_truep(t13)){
t14=C_slot(t10,C_fix(2));
t15=C_i_car(t14);
t16=C_i_assq(t15,((C_word*)t0)[2]);
if(C_truep(t16)){
t17=C_i_set_car(t6,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12710,a[2]=t2,a[3]=t11,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t19=C_SCHEME_END_OF_LIST;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_FALSE;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12714,a[2]=t18,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t24=C_i_cdr(t16);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12724,a[2]=t20,a[3]=t26,a[4]=t22,tmp=(C_word)a,a+=5,tmp));
t28=((C_word*)t26)[1];
f_12724(t28,t23,t24);}
else{
t17=C_SCHEME_UNDEFINED;
t18=t11;
f_12652(2,t18,t17);}}
else{
t14=t11;
f_12652(2,t14,C_SCHEME_UNDEFINED);}}
else{
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12784,a[2]=((C_word*)t0)[3],a[3]=t11,tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_12784(t13,t1,t8);}}

/* loop3561 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12784(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12784,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12794,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g35683569 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12615(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12792 in loop3561 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12784(t3,((C_word*)t0)[2],t2);}

/* loop3520 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12724(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12724,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[61]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12753,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g35363537 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12751 in loop3520 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12753,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop35203533 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12724(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop35203533 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12724(t6,((C_word*)t0)[3],t5);}}

/* k12712 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1742 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,t2);}

/* k12708 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12710,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 1740 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k12650 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12652,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=C_slot(t2,C_fix(3));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12666,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_12666(t7,((C_word*)t0)[2],t3);}

/* loop3544 in k12650 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12666(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12666,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12676,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g35513552 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12615(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12674 in loop3544 in k12650 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12666(t3,((C_word*)t0)[2],t2);}

/* reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12081(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12081,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12093,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12095,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[3];
t7=C_slot(t6,C_fix(3));
t8=C_i_car(t7);
/* optimizer.scm: 1676 fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),t4,t5,t8,t2);}

/* a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12095,4,t0,t1,t2,t3);}
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12102,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1679 get */
((C_proc5)C_retrieve_symbol_proc(lf[40]))(5,*((C_word*)lf[40]+1),t5,((C_word*)t0)[2],t4,lf[59]);}

/* k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1680 hide-variable */
((C_proc3)C_retrieve_symbol_proc(lf[223]))(3,*((C_word*)lf[223]+1),t2,((C_word*)t0)[5]);}

/* k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12105,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=C_slot(t2,C_fix(2));
t4=C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12114,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1681 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),((C_word*)t0)[2],t4,t5);}

/* a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12114(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[21],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12114,5,t0,t1,t2,t3,t4);}
t5=C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t6=C_i_cdr(t5);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12121,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12266,a[2]=t8,a[3]=t13,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t15=((C_word*)t13)[1];
f_12266(t15,t11,t6);}

/* loop3294 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12266(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12266,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[96]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12295,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g33103311 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12293 in loop3294 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12295,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop32943307 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12266(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop32943307 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12266(t6,((C_word*)t0)[3],t5);}}

/* k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12121,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12124,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12217,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_12217(t10,t6,((C_word*)t0)[5],t1);}

/* loop3318 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12217(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12217,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[146]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12250,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g33383339 */
t10=t6;
((C_proc4)C_retrieve_proc(t10))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k12248 in loop3318 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12250,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12230,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_12230(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_12230(t5,t4);}}

/* k12228 in k12248 in loop3318 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12230(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop33183332 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_12217(t5,((C_word*)t0)[2],t3,t4);}

/* k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12127,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[9];
t4=C_slot(t3,C_fix(3));
t5=C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12330,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12345,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_12345(t10,t2,t5);}

/* walk in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12345(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12345,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t2;
t6=C_slot(t5,C_fix(2));
t7=t2;
t8=C_slot(t7,C_fix(3));
t9=C_eqp(t4,lf[5]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12379,a[2]=t8,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_END_OF_LIST;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12409,a[2]=t2,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12411,a[2]=t12,a[3]=t17,a[4]=t14,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t19=((C_word*)t17)[1];
f_12411(t19,t15,t6);}
else{
t10=C_eqp(t4,lf[2]);
if(C_truep(t10)){
t11=C_i_car(t6);
t12=f_12330(((C_word*)t0)[2],t11);
t13=C_a_i_list(&a,1,t12);
/* optimizer.scm: 1715 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t1,t2,t13);}
else{
t11=C_eqp(t4,lf[9]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12474,a[2]=t8,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t13=C_i_car(t6);
t14=f_12330(((C_word*)t0)[2],t13);
t15=C_a_i_list(&a,1,t14);
/* optimizer.scm: 1717 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t12,t2,t15);}
else{
t12=C_eqp(t4,lf[7]);
if(C_truep(t12)){
t13=C_i_car(t6);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1720 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),t1,t13,t14);}
else{
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12586,a[2]=((C_word*)t0)[3],a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_12586(t16,t1,t8);}}}}}

/* loop3473 in walk in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12586(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12586,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12596,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g34803481 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12345(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12594 in loop3473 in walk in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12586(t3,((C_word*)t0)[2],t2);}

/* a12526 in walk in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[23],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12527,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12542,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12546,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12548,a[2]=t7,a[3]=t12,a[4]=t9,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_12548(t14,t10,t2);}

/* loop3449 in a12526 in walk in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12548(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12548,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_12330(((C_word*)t0)[5],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop34493462 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop34493462 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12544 in a12526 in walk in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1723 build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[70]))(5,*((C_word*)lf[70]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12540 in a12526 in walk in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_set_car(((C_word*)t0)[5],t1);
t3=C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1724 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12345(t4,((C_word*)t0)[2],t3);}

/* k12472 in walk in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12474,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12479,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_12479(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop3432 in k12472 in walk in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12479(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12479,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12489,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g34393440 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12345(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12487 in loop3432 in k12472 in walk in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12479(t3,((C_word*)t0)[2],t2);}

/* loop3395 in walk in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12411(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12411,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_12330(((C_word*)t0)[5],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop33953408 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop33953408 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12407 in walk in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1712 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k12377 in walk in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12379,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12384,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_12384(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop3418 in k12377 in walk in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12384(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12384,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12394,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g34253426 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12345(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12392 in loop3418 in k12377 in walk in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12384(t3,((C_word*)t0)[2],t2);}

/* rename in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static C_word C_fcall f_12330(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=C_i_assq(t1,((C_word*)t0)[2]);
if(C_truep(t2)){
return(C_i_cdr(t2));}
else{
t3=t1;
return(t3);}}

/* k12125 in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1689 gensym */
((C_proc3)C_retrieve_symbol_proc(lf[96]))(3,*((C_word*)lf[96]+1),t2,lf[97]);}

/* k12200 in k12125 in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12202,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=C_a_i_list(&a,1,((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12186,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12190,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1695 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12188 in k12200 in k12125 in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_length(((C_word*)t0)[5]);
t3=C_fixnum_plus(((C_word*)t0)[4],t2);
/* optimizer.scm: 1695 build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[70]))(5,*((C_word*)lf[70]+1),((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k12184 in k12200 in k12125 in k12122 in k12119 in a12113 in k12103 in k12100 in a12094 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12186,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[6];
t4=C_slot(t3,C_fix(3));
t5=C_a_i_record(&a,4,lf[10],lf[7],t2,t4);
t6=C_a_i_list(&a,1,t5);
t7=C_a_i_record(&a,4,lf[10],lf[9],((C_word*)t0)[5],t6);
t8=C_a_i_list(&a,2,t7,((C_word*)t0)[4]);
t9=((C_word*)t0)[3];
t10=t9;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_record(&a,4,lf[10],lf[5],((C_word*)t0)[2],t8));}

/* k12091 in reconstruct! in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12093,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* optimizer.scm: 1673 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11672(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11672,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11798,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12033,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_12033(t11,t7,t2);}

/* loop3149 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12033(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12033,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_i_cadr(t3);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t8=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop31493162 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop31493162 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11798,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11800,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11931,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12010,a[2]=t5,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_12010(t11,t7,((C_word*)t0)[4]);}

/* loop3173 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_12010(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12010,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12020,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g32363237 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11800(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12018 in loop3173 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12010(t3,((C_word*)t0)[2],t2);}

/* k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11931,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11936,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_11936(t9,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop3242 in k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11936(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11936,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11963,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12004,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g32583259 */
t6=t3;
f_11963(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12002 in loop3242 in k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12004,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop32423255 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11936(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop32423255 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11936(t6,((C_word*)t0)[3],t5);}}

/* g3258 in loop3242 in k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11963(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11963,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12001,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1662 get */
((C_proc5)C_retrieve_symbol_proc(lf[40]))(5,*((C_word*)lf[40]+1),t4,((C_word*)t0)[2],t3,lf[59]);}

/* k11999 in g3258 in loop3242 in k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_12001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12001,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11681,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_11681(t8,t4,t1);}

/* walk in k11999 in g3258 in loop3242 in k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11681(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11681,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t2;
t6=C_slot(t5,C_fix(2));
t7=t2;
t8=C_slot(t7,C_fix(3));
t9=C_eqp(t4,lf[5]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11716,a[2]=t8,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1638 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t10,t6,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=C_eqp(t4,lf[7]);
if(C_truep(t10)){
t11=C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11757,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1641 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),t1,t11,t12);}
else{
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11774,a[2]=((C_word*)t0)[2],a[3]=t12,tmp=(C_word)a,a+=4,tmp));
t14=((C_word*)t12)[1];
f_11774(t14,t1,t8);}}}

/* loop3132 in walk in k11999 in g3258 in loop3242 in k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11774(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11774,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11784,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g31393140 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11681(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11782 in loop3132 in walk in k11999 in g3258 in loop3242 in k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11774(t3,((C_word*)t0)[2],t2);}

/* a11756 in walk in k11999 in g3258 in loop3242 in k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11757,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11762,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1644 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t5,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k11760 in a11756 in walk in k11999 in g3258 in loop3242 in k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1645 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_11681(t4,((C_word*)t0)[2],t3);}

/* k11714 in walk in k11999 in g3258 in loop3242 in k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11716,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11721,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_11721(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop3114 in k11714 in walk in k11999 in g3258 in loop3242 in k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11721(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11721,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11731,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g31213122 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11681(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11729 in loop3114 in k11714 in walk in k11999 in g3258 in loop3242 in k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11721(t3,((C_word*)t0)[2],t2);}

/* k11677 in k11999 in g3258 in loop3242 in k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11679,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11977,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11979,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11993,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 1668 delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t5,t6,*((C_word*)lf[34]+1));}

/* k11991 in k11677 in k11999 in g3258 in loop3242 in k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1664 remove */
((C_proc4)C_retrieve_symbol_proc(lf[3]))(4,*((C_word*)lf[3]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11978 in k11677 in k11999 in g3258 in loop3242 in k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11979,3,t0,t1,t2);}
t3=C_i_assq(t2,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:C_i_memq(t2,((C_word*)t0)[2])));}

/* k11975 in k11677 in k11999 in g3258 in loop3242 in k11929 in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11977,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* walk in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11800(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11800,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11924,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1653 count */
((C_proc4)C_retrieve_symbol_proc(lf[222]))(4,*((C_word*)lf[222]+1),t4,t5,((C_word*)((C_word*)t0)[5])[1]);}

/* a11923 in walk in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11924,3,t0,t1,t2);}
t3=*((C_word*)lf[34]+1);
/* g31903191 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,((C_word*)t0)[2],t2);}

/* k11920 in walk in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11922,2,t0,t1);}
if(C_truep(C_fixnum_greaterp(t1,C_fix(1)))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_i_cddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11820,a[2]=t4,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11888,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_11888(t9,t5,t4);}}

/* loop3195 in k11920 in walk in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11888(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11888,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11907,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g32023203 */
t6=t3;
f_11896(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11905 in loop3195 in k11920 in walk in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11888(t3,((C_word*)t0)[2],t2);}

/* g3202 in loop3195 in k11920 in walk in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11896(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11896,NULL,3,t0,t1,t2);}
t3=C_i_assq(t2,((C_word*)t0)[3]);
/* optimizer.scm: 1656 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_11800(t4,t1,t3);}

/* k11818 in k11920 in walk in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11820,2,t0,t1);}
t2=C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11830,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11838,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11842,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11844,a[2]=t7,a[3]=t12,a[4]=t9,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_11844(t14,t10,((C_word*)t0)[2]);}

/* loop3210 in k11818 in k11920 in walk in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11844(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11844,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11871,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_11871(t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop32103223 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop32103223 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g3226 in loop3210 in k11818 in k11920 in walk in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static C_word C_fcall f_11871(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_i_assq(t1,((C_word*)t0)[2]);
return(C_i_cdr(t2));}

/* k11840 in k11818 in k11920 in walk in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1658 concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[221]))(3,*((C_word*)lf[221]+1),((C_word*)t0)[2],t1);}

/* k11836 in k11818 in k11920 in walk in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1658 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11828 in k11818 in k11920 in walk in k11796 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_set_cdr(((C_word*)t0)[2],t1));}

/* eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11361(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11361,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11365,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11367,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_11367(t8,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11367(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11367,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(1));
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t2;
t9=C_slot(t8,C_fix(3));
t10=C_eqp(t5,lf[2]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11401,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_11401(t12,t10);}
else{
t12=C_eqp(t5,lf[41]);
if(C_truep(t12)){
t13=t11;
f_11401(t13,t12);}
else{
t13=C_eqp(t5,lf[11]);
if(C_truep(t13)){
t14=t11;
f_11401(t14,t13);}
else{
t14=C_eqp(t5,lf[219]);
t15=t11;
f_11401(t15,(C_truep(t14)?t14:C_eqp(t5,lf[169])));}}}}

/* k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11401(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11401,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[7],lf[5]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11412,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_11412(t6,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t3=C_eqp(((C_word*)t0)[7],lf[7]);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11463,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1603 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),((C_word*)t0)[8],t4,t5);}
else{
t4=C_eqp(((C_word*)t0)[7],lf[8]);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11487,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11520,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1609 call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[54]+1)))(3,*((C_word*)lf[54]+1),t6,t7);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11623,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_11623(t8,((C_word*)t0)[8],((C_word*)t0)[3]);}}}}}

/* loop3075 in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11623(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11623,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11638,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g30823083 */
t6=t3;
f_11631(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11636 in loop3075 in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11623(t3,((C_word*)t0)[2],t2);}

/* g3082 in loop3075 in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11631(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11631,NULL,3,t0,t1,t2);}
/* optimizer.scm: 1624 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11367(t3,t1,t2,((C_word*)t0)[2]);}

/* a11519 in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11520(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11520,3,t0,t1,t2);}
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_eqp(lf[2],t3);
if(C_truep(t4)){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_slot(((C_word*)t0)[4],C_fix(2));
t8=C_i_car(t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11536,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t10,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_11536(t12,t1,t8);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* loop in a11519 in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11536(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11536,NULL,3,t0,t1,t2);}
if(C_truep(C_i_memq(t2,((C_word*)((C_word*)t0)[6])[1]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11556,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11589,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=C_i_cadr(t5);
/* optimizer.scm: 1618 lset<= */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t7,*((C_word*)lf[34]+1),t8,((C_word*)t0)[2]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k11587 in loop in a11519 in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11589,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_11556(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11593,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1620 delete! */
((C_proc5)C_retrieve_symbol_proc(lf[220]))(5,*((C_word*)lf[220]+1),t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[34]+1));}}

/* k11591 in k11587 in loop in a11519 in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* optimizer.scm: 1621 return */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k11554 in loop in a11519 in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11556,2,t0,t1);}
t2=C_i_cddr(((C_word*)t0)[4]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11565,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_11565(t6,((C_word*)t0)[2],t2);}

/* loop3041 in k11554 in loop in a11519 in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11565(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11565,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11575,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g30483049 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11536(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11573 in loop3041 in k11554 in loop in a11519 in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11565(t3,((C_word*)t0)[2],t2);}

/* k11485 in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11487,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11492,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11492(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop3060 in k11485 in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11492(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11492,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11500,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11507,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g30673068 */
t6=t3;
f_11500(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11505 in loop3060 in k11485 in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11492(t3,((C_word*)t0)[2],t2);}

/* g3067 in loop3060 in k11485 in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11500(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11500,NULL,3,t0,t1,t2);}
/* optimizer.scm: 1623 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11367(t3,t1,t2,((C_word*)t0)[2]);}

/* a11462 in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11463,5,t0,t1,t2,t3,t4);}
t5=C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11475,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1606 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t6,t2,((C_word*)t0)[2]);}

/* k11473 in a11462 in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1606 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11367(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11412(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11412,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11430,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1598 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11433,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
/* optimizer.scm: 1600 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_11367(t6,t4,t5,((C_word*)t0)[3]);}}

/* k11431 in loop in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1601 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_11412(t4,((C_word*)t0)[2],t2,t3);}

/* k11428 in loop in k11399 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1598 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11367(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11363 in eliminate4 in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* collect-accessibles in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11080(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11080,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11084,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11086,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_11086(t9,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11086(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11086,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(1));
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t2;
t9=C_slot(t8,C_fix(3));
t10=C_eqp(t5,lf[2]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t9,a[7]=t3,a[8]=t7,a[9]=((C_word*)t0)[5],a[10]=t5,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t10)){
t12=t11;
f_11120(t12,t10);}
else{
t12=C_eqp(t5,lf[41]);
if(C_truep(t12)){
t13=t11;
f_11120(t13,t12);}
else{
t13=C_eqp(t5,lf[11]);
if(C_truep(t13)){
t14=t11;
f_11120(t14,t13);}
else{
t14=C_eqp(t5,lf[219]);
t15=t11;
f_11120(t15,(C_truep(t14)?t14:C_eqp(t5,lf[169])));}}}}

/* k11118 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11120(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11120,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[10],lf[5]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11131,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_11131(t6,((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[6]);}
else{
t3=C_eqp(((C_word*)t0)[10],lf[7]);
if(C_truep(t3)){
t4=C_i_assq(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11179,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=C_i_cdr(t4);
if(C_truep(C_i_assq(t6,((C_word*)t0)[3]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11213,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=C_i_cdr(t4);
/* optimizer.scm: 1555 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),t7,t8,((C_word*)t0)[7],((C_word*)((C_word*)t0)[2])[1]);}
else{
t7=C_SCHEME_UNDEFINED;
t8=t5;
f_11179(t8,t7);}}
else{
t6=t5;
f_11179(t6,C_SCHEME_UNDEFINED);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11222,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_11222(t7,((C_word*)t0)[11],((C_word*)t0)[6]);}}}}

/* loop2939 in k11118 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11222(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11222,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11230,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11237,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g29462947 */
t6=t3;
f_11230(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11235 in loop2939 in k11118 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11222(t3,((C_word*)t0)[2],t2);}

/* g2946 in loop2939 in k11118 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11230(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11230,NULL,3,t0,t1,t2);}
/* optimizer.scm: 1561 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11086(t3,t1,t2,((C_word*)t0)[2]);}

/* k11211 in k11118 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_11179(t3,t2);}

/* k11177 in k11118 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11179(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11179,NULL,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11188,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1556 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),((C_word*)t0)[2],t2,t3);}

/* a11187 in k11177 in k11118 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11188,5,t0,t1,t2,t3,t4);}
t5=C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11200,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1559 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t6,t2,((C_word*)t0)[2]);}

/* k11198 in a11187 in k11177 in k11118 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1559 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11086(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k11118 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11131(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11131,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11149,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1546 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11152,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
/* optimizer.scm: 1548 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_11086(t6,t4,t5,((C_word*)t0)[3]);}}

/* k11150 in loop in k11118 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1549 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_11131(t4,((C_word*)t0)[2],t2,t3);}

/* k11147 in loop in k11118 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1546 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11086(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11082 in collect-accessibles in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* eliminate in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10947(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10947,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10953,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1516 remove */
((C_proc4)C_retrieve_symbol_proc(lf[3]))(4,*((C_word*)lf[3]+1),t1,t4,t3);}

/* a10952 in eliminate in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10953(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10953,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10987,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_i_car(t2);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10997,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1526 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[212]))(3,*((C_word*)lf[212]+1),t6,t5);}

/* k10995 in a10952 in eliminate in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10997,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11002,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11002(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* count in k10995 in a10952 in eliminate in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11002(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11002,NULL,4,t0,t1,t2,t3);}
t4=C_i_assq(t2,((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11009,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=C_i_cddr(t4);
/* optimizer.scm: 1529 lset-difference */
((C_proc6)C_retrieve_symbol_proc(lf[199]))(6,*((C_word*)lf[199]+1),t5,*((C_word*)lf[34]+1),t6,t3,((C_word*)t0)[2]);}

/* k11007 in count in k10995 in a10952 in eliminate in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11070,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1530 delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t2,t3,*((C_word*)lf[34]+1));}

/* k11068 in k11007 in count in k10995 in a10952 in eliminate in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11070,2,t0,t1);}
t2=C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11066,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1531 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11064 in k11068 in k11007 in count in k10995 in a10952 in eliminate in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11066,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11022,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11024,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_11024(t11,t7,((C_word*)t0)[2]);}

/* loop2857 in k11064 in k11068 in k11007 in count in k10995 in a10952 in eliminate in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11024(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11024,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11051,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11058,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g28732874 */
t6=t3;
f_11051(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11056 in loop2857 in k11064 in k11068 in k11007 in count in k10995 in a10952 in eliminate in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11058,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop28572870 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11024(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop28572870 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11024(t6,((C_word*)t0)[3],t5);}}

/* g2873 in loop2857 in k11064 in k11068 in k11007 in count in k10995 in a10952 in eliminate in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_11051(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11051,NULL,3,t0,t1,t2);}
/* optimizer.scm: 1532 count */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11002(t3,t1,t2,((C_word*)t0)[2]);}

/* k11020 in k11064 in k11068 in k11007 in count in k10995 in a10952 in eliminate in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_11022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1532 fold */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),((C_word*)t0)[3],*((C_word*)lf[218]+1),((C_word*)t0)[2],t1);}

/* k10985 in a10952 in eliminate in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10987,2,t0,t1);}
t2=C_fixnum_greaterp(t1,C_fix(16));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10965,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1519 any */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),((C_word*)t0)[5],t3,t4);}}

/* a10964 in k10985 in a10952 in eliminate in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10965(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10965,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10972,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1520 get */
((C_proc5)C_retrieve_symbol_proc(lf[40]))(5,*((C_word*)lf[40]+1),t3,((C_word*)t0)[2],t2,lf[87]);}

/* k10970 in a10964 in k10985 in a10952 in eliminate in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10659(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10659,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10662,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=t2,a[6]=t10,tmp=(C_word)a,a+=7,tmp));
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10870,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10872,a[2]=t14,a[3]=t10,a[4]=t4,a[5]=t8,a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_10872(t16,t12,t2);}

/* loop2729 in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10872(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10872,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10880,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10934,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g28102811 */
t6=t3;
f_10880(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10932 in loop2729 in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10872(t3,((C_word*)t0)[2],t2);}

/* g2810 in loop2729 in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10880(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10880,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=C_i_cdr(t2);
t5=C_slot(t4,C_fix(2));
t6=C_i_car(t5);
t7=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_END_OF_LIST);
t8=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10895,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10905,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1505 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),t9,t6,t10);}

/* a10904 in g2810 in loop2729 in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10905,5,t0,t1,t2,t3,t4);}
t5=C_slot(((C_word*)t0)[3],C_fix(3));
t6=C_i_car(t5);
/* optimizer.scm: 1508 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_10662(t7,t1,t6,t2);}

/* k10893 in g2810 in loop2729 in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10899,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
/* optimizer.scm: 1509 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),t2,((C_word*)t0)[2],t3,((C_word*)((C_word*)t0)[6])[1]);}

/* k10897 in k10893 in g2810 in loop2729 in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10868 in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10662(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10662,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(1));
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t2;
t9=C_slot(t8,C_fix(3));
t10=C_eqp(t5,lf[2]);
t11=(C_truep(t10)?t10:C_eqp(t5,lf[9]));
if(C_truep(t11)){
t12=C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10702,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t12,a[5]=t9,a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t14=C_i_memq(t12,t3);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10749,a[2]=((C_word*)t0)[3],a[3]=t12,a[4]=t13,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t14)){
t16=t15;
f_10749(2,t16,t14);}
else{
/* optimizer.scm: 1481 get */
((C_proc5)C_retrieve_symbol_proc(lf[40]))(5,*((C_word*)lf[40]+1),t15,((C_word*)t0)[2],t12,lf[114]);}}
else{
t12=C_eqp(t5,lf[5]);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10767,a[2]=t14,a[3]=t3,a[4]=t7,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_10767(t16,t1,t7,t9);}
else{
t13=C_eqp(t5,lf[7]);
if(C_truep(t13)){
t14=C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10821,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1493 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),t1,t14,t15);}
else{
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10838,a[2]=t15,a[3]=t3,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp));
t17=((C_word*)t15)[1];
f_10838(t17,t1,t9);}}}}

/* loop2796 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10838(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10838,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10846,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10853,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g28032804 */
t6=t3;
f_10846(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10851 in loop2796 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10838(t3,((C_word*)t0)[2],t2);}

/* g2803 in loop2796 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10846(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10846,NULL,3,t0,t1,t2);}
/* optimizer.scm: 1496 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10662(t3,t1,t2,((C_word*)t0)[2]);}

/* a10820 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10821,5,t0,t1,t2,t3,t4);}
t5=C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10833,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1495 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t6,t2,((C_word*)t0)[2]);}

/* k10831 in a10820 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1495 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10662(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10767(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10767,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10785,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1488 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10791,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=C_i_car(t3);
/* optimizer.scm: 1490 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_10662(t7,t5,t6,((C_word*)t0)[3]);}}

/* k10789 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1491 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10767(t4,((C_word*)t0)[2],t2,t3);}

/* k10783 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1488 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10662(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10747 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10749,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10702(t2,C_SCHEME_UNDEFINED);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[4];
f_10702(t4,t3);}}

/* k10700 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10702(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10702,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10705,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_10705(t5,t4);}
else{
t3=t2;
f_10705(t3,C_SCHEME_UNDEFINED);}}

/* k10703 in k10700 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10705(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10705,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10710,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10710(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2771 in k10703 in k10700 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10710(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10710,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10718,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10725,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g27782779 */
t6=t3;
f_10718(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10723 in loop2771 in k10703 in k10700 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10710(t3,((C_word*)t0)[2],t2);}

/* g2778 in loop2771 in k10703 in k10700 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10718(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10718,NULL,3,t0,t1,t2);}
/* optimizer.scm: 1484 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10662(t3,t1,t2,((C_word*)t0)[2]);}

/* find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10556(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10556,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10560,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10562,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1452 ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[217]))(4,*((C_word*)lf[217]+1),t4,t5,((C_word*)t0)[2]);}

/* a10561 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10562,4,t0,t1,t2,t3);}
t4=C_i_assq(lf[59],t3);
if(C_truep(t4)){
t5=C_i_assq(lf[88],t3);
if(C_truep(t5)){
t6=C_i_assq(lf[132],t3);
if(C_truep(t6)){
t7=C_i_cdr(t5);
t8=C_i_length(t7);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10590,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_assq(lf[89],t3))){
t10=t9;
f_10590(t10,C_SCHEME_FALSE);}
else{
t10=C_i_cdr(t4);
t11=C_slot(t10,C_fix(1));
t12=C_eqp(lf[7],t11);
if(C_truep(t12)){
if(C_truep(C_i_assq(lf[114],t3))){
t13=t9;
f_10590(t13,C_SCHEME_FALSE);}
else{
t13=C_i_cdr(t6);
t14=C_i_length(t13);
t15=t9;
f_10590(t15,C_eqp(t8,t14));}}
else{
t13=t9;
f_10590(t13,C_SCHEME_FALSE);}}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k10588 in a10561 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10590(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10590,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1463 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),t2,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k10592 in k10588 in a10561 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10594,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10598,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1464 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),t3,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[5])[1]);}

/* k10596 in k10592 in k10588 in a10561 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10558 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9168,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9171,a[2]=t3,a[3]=t15,a[4]=t13,a[5]=t11,a[6]=t9,a[7]=t7,a[8]=t17,tmp=(C_word)a,a+=9,tmp));
t19=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9370,a[2]=t7,a[3]=t9,a[4]=t3,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t20=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9824,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10548,a[2]=t2,a[3]=t13,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1431 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t21,lf[35],lf[215]);}

/* k10546 in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10551,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1432 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9171(t3,t2,C_SCHEME_FALSE,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k10549 in k10546 in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_9824(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9824,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9828,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t1,a[7]=t5,a[8]=t6,a[9]=t2,a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10536,a[2]=t7,a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10538,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-promise */
t11=*((C_word*)lf[213]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
/* optimizer.scm: 1322 debugging */
((C_proc6)C_retrieve_symbol_proc(lf[30]))(6,*((C_word*)lf[30]+1),t8,lf[31],lf[214],t3,t7);}}

/* a10537 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10538,2,t0,t1);}
/* optimizer.scm: 1321 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[212]))(3,*((C_word*)lf[212]+1),t1,((C_word*)t0)[2]);}

/* k10534 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1321 debugging */
((C_proc7)C_retrieve_symbol_proc(lf[30]))(7,*((C_word*)lf[30]+1),((C_word*)t0)[4],lf[31],lf[211],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9828,2,t0,t1);}
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
t4=C_slot(t3,C_fix(2));
t5=C_i_caddr(t4);
t6=C_i_length(t5);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9843,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1327 get */
((C_proc5)C_retrieve_symbol_proc(lf[40]))(5,*((C_word*)lf[40]+1),t9,((C_word*)t0)[2],((C_word*)t0)[4],lf[132]);}

/* k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9843,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[11]))){
t6=C_i_length(((C_word*)t0)[11]);
t7=C_eqp(t6,C_fix(4));
if(C_truep(t7)){
t8=C_i_caddr(((C_word*)t0)[11]);
t9=t5;
f_9852(t9,C_i_listp(t8));}
else{
t8=t5;
f_9852(t8,C_SCHEME_FALSE);}}
else{
t6=t5;
f_9852(t6,C_SCHEME_FALSE);}}

/* k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_9852(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9852,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1331 caaddr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[209]+1)))(3,*((C_word*)lf[209]+1),t3,((C_word*)t0)[13]);}
else{
/* optimizer.scm: 1429 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[186]))(4,*((C_word*)lf[186]+1),((C_word*)t0)[10],lf[210],((C_word*)t0)[13]);}}

/* k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_9861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm: 1332 cdaddr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[208]+1)))(3,*((C_word*)lf[208]+1),t2,((C_word*)t0)[14]);}

/* k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9861,2,t0,t1);}
t2=C_i_cddr(((C_word*)t0)[15]);
t3=C_i_set_car(t2,t1);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1336 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[200]))(4,*((C_word*)lf[200]+1),t4,((C_word*)t0)[5],lf[190]);}

/* k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9870,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[5];
t4=C_slot(t3,C_fix(3));
t5=C_i_car(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10150,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_10150(t9,t2,t5);}

/* rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10150(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10150,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(2));
t5=t2;
t6=C_slot(t5,C_fix(3));
t7=t2;
t8=C_slot(t7,C_fix(1));
t9=C_eqp(t8,lf[8]);
if(C_truep(t9)){
t10=C_i_car(t6);
t11=C_i_cadr(t6);
t12=C_slot(t10,C_fix(2));
t13=C_slot(t11,C_fix(2));
t14=C_slot(t10,C_fix(1));
t15=C_eqp(lf[2],t14);
if(C_truep(t15)){
t16=C_i_car(t12);
t17=C_eqp(((C_word*)t0)[9],t16);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10219,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=t6,a[10]=((C_word*)t0)[7],a[11]=t13,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm: 1350 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),t18,C_SCHEME_FALSE,t2,((C_word*)((C_word*)t0)[8])[1]);}
else{
t18=C_i_car(t12);
t19=C_eqp(((C_word*)t0)[7],t18);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10372,a[2]=t2,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1375 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[200]))(4,*((C_word*)lf[200]+1),t20,t2,lf[206]);}
else{
/* optimizer.scm: 1378 bomb */
((C_proc3)C_retrieve_symbol_proc(lf[186]))(3,*((C_word*)lf[186]+1),t1,lf[207]);}}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}
else{
t10=C_eqp(t8,lf[5]);
if(C_truep(t10)){
t11=C_i_car(t4);
t12=C_i_car(t6);
if(C_truep(C_i_memq(t11,((C_word*)t0)[2]))){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10424,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1383 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),t13,t11,t12,((C_word*)((C_word*)t0)[4])[1]);}
else{
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10439,a[2]=((C_word*)t0)[3],a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_10439(t16,t1,t6);}}
else{
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10465,a[2]=((C_word*)t0)[3],a[3]=t12,tmp=(C_word)a,a+=4,tmp));
t14=((C_word*)t12)[1];
f_10465(t14,t1,t6);}}}

/* loop2564 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10465(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10465,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10475,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g25712572 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10150(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10473 in loop2564 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10465(t3,((C_word*)t0)[2],t2);}

/* loop2551 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10439(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10439,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10449,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g25582559 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10150(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10447 in loop2551 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10439(t3,((C_word*)t0)[2],t2);}

/* k10422 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10424,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1384 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[12]))(4,*((C_word*)lf[12]+1),t3,t4,((C_word*)t0)[3]);}

/* k10425 in k10422 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1385 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10150(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10370 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1376 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10373 in k10370 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1377 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10217 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10219,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[12])+1,t1);
t3=C_i_car(((C_word*)t0)[11]);
t4=C_eqp(((C_word*)t0)[10],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10228,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t6=C_i_cdr(((C_word*)t0)[9]);
t7=C_i_length(t6);
t8=C_eqp(((C_word*)t0)[5],t7);
if(C_truep(t8)){
t9=t5;
f_10228(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1353 quit */
((C_proc4)C_retrieve_symbol_proc(lf[197]))(4,*((C_word*)lf[197]+1),t5,lf[202],((C_word*)t0)[4]);}}
else{
t5=C_i_car(((C_word*)t0)[11]);
t6=C_i_assq(t5,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10266,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* g25132514 */
t8=t7;
f_10266(t8,((C_word*)t0)[8],t6);}
else{
/* optimizer.scm: 1373 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[186]))(4,*((C_word*)lf[186]+1),((C_word*)t0)[8],lf[205],((C_word*)t0)[11]);}}}

/* g2513 in k10217 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10266(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10266,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=C_slot(t3,C_fix(3));
t5=C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10276,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=C_i_cdr(((C_word*)t0)[5]);
t8=C_i_length(t7);
t9=C_eqp(((C_word*)t0)[3],t8);
if(C_truep(t9)){
t10=t6;
f_10276(2,t10,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1364 quit */
((C_proc4)C_retrieve_symbol_proc(lf[197]))(4,*((C_word*)lf[197]+1),t6,lf[204],((C_word*)t0)[2]);}}

/* k10274 in g2513 in k10217 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1367 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[200]))(4,*((C_word*)lf[200]+1),t2,((C_word*)t0)[3],lf[5]);}

/* k10277 in k10274 in g2513 in k10217 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10313,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_slot(((C_word*)t0)[2],C_fix(2));
t5=C_i_caddr(t4);
/* optimizer.scm: 1368 take */
((C_proc4)C_retrieve_symbol_proc(lf[203]))(4,*((C_word*)lf[203]+1),t3,t5,C_fix(1));}

/* k10311 in k10277 in k10274 in g2513 in k10217 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1368 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10280 in k10277 in k10274 in g2513 in k10217 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10285,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list(&a,2,C_SCHEME_FALSE,((C_word*)t0)[4]);
t4=C_i_cddr(((C_word*)t0)[3]);
t5=C_a_i_record(&a,4,lf[10],lf[201],t3,t4);
t6=C_a_i_list(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm: 1369 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),t2,((C_word*)t0)[2],t6);}

/* k10283 in k10280 in k10277 in k10274 in g2513 in k10217 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1372 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10150(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10226 in k10217 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1356 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[200]))(4,*((C_word*)lf[200]+1),t2,((C_word*)t0)[3],lf[201]);}

/* k10229 in k10226 in k10217 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10234,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list(&a,2,C_SCHEME_TRUE,((C_word*)t0)[2]);
/* optimizer.scm: 1357 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t2,((C_word*)t0)[3],t3);}

/* k10232 in k10229 in k10226 in k10217 in rec in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 1358 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9868 in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9873,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10041,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10132,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1406 lset-difference */
((C_proc5)C_retrieve_symbol_proc(lf[199]))(5,*((C_word*)lf[199]+1),t3,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* a10131 in k9868 in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10132,4,t0,t1,t2,t3);}
t4=C_i_cdr(t2);
t5=C_i_cdr(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_eqp(t4,t5));}

/* k10039 in k9868 in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10041,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10043,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_10043(t5,((C_word*)t0)[2],t1);}

/* loop2581 in k10039 in k9868 in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10043(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10043,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10051,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10119,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g25882589 */
t6=t3;
f_10051(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10117 in loop2581 in k10039 in k9868 in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10043(t3,((C_word*)t0)[2],t2);}

/* g2588 in loop2581 in k10039 in k9868 in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_10051(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10051,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=C_slot(t3,C_fix(3));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10066,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=C_i_cdr(t4);
t7=C_i_length(t6);
t8=C_eqp(((C_word*)t0)[3],t7);
if(C_truep(t8)){
t9=t5;
f_10066(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1396 quit */
((C_proc4)C_retrieve_symbol_proc(lf[197]))(4,*((C_word*)lf[197]+1),t5,lf[198],((C_word*)t0)[2]);}}

/* k10064 in g2588 in loop2581 in k10039 in k9868 in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_10066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10066,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[6]);
t3=C_a_i_list(&a,4,C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=C_i_car(((C_word*)t0)[6]);
t5=C_i_cddr(((C_word*)t0)[6]);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_record(&a,4,lf[10],lf[194],t3,t6);
t8=C_a_i_list(&a,2,t2,t7);
/* optimizer.scm: 1399 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),((C_word*)t0)[3],((C_word*)t0)[2],t8);}

/* k9871 in k9868 in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9873,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?C_i_pairp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=C_a_i_record(&a,4,lf[10],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9890,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1411 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[12]))(4,*((C_word*)lf[12]+1),t4,((C_word*)t0)[4],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9888 in k9871 in k9868 in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9961,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1413 fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),t2,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a9960 in k9888 in k9871 in k9868 in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9961,4,t0,t1,t2,t3);}
t4=C_i_car(t2);
t5=C_a_i_list(&a,1,t4);
t6=C_i_cdr(t2);
t7=C_slot(t6,C_fix(3));
t8=C_i_car(t7);
t9=C_slot(t8,C_fix(1));
t10=C_slot(t8,C_fix(2));
t11=C_slot(t8,C_fix(3));
t12=C_a_i_record(&a,4,lf[10],t9,t10,t11);
t13=C_a_i_list(&a,2,t12,t3);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_a_i_record(&a,4,lf[10],lf[5],t5,t13));}

/* k9891 in k9888 in k9871 in k9868 in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1422 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[12]))(4,*((C_word*)lf[12]+1),t2,t1,((C_word*)t0)[2]);}

/* k9894 in k9891 in k9888 in k9871 in k9868 in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9896,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9901,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_9901(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2647 in k9894 in k9891 in k9888 in k9871 in k9868 in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_9901(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9901,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9916,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9945,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1426 gensym */
((C_proc2)C_retrieve_symbol_proc(lf[96]))(2,*((C_word*)lf[96]+1),t6);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9943 in loop2647 in k9894 in k9891 in k9888 in k9871 in k9868 in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9945,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* optimizer.scm: 1426 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9914 in loop2647 in k9894 in k9891 in k9888 in k9871 in k9868 in k9865 in k9859 in k9856 in k9850 in k9841 in k9826 in transform in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9916,2,t0,t1);}
t2=C_slot(((C_word*)t0)[5],C_fix(3));
t3=C_a_i_record(&a,4,lf[10],lf[11],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=C_i_set_car(t2,t3);
t5=C_slot(((C_word*)t0)[4],C_fix(1));
t6=((C_word*)((C_word*)t0)[3])[1];
f_9901(t6,((C_word*)t0)[2],t5);}

/* scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_9370(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9370,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9373,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t5,a[7]=t12,a[8]=t8,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t6,tmp=(C_word)a,a+=13,tmp));
t14=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t15=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(((C_word*)t0)[5],0,C_fix(0));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9815,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1316 rec */
t18=((C_word*)t12)[1];
f_9373(t18,t17,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,t6);}

/* k9813 in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9815,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9822,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1317 delete */
((C_proc5)C_retrieve_symbol_proc(lf[196]))(5,*((C_word*)lf[196]+1),t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[34]+1));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9820 in k9813 in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1317 lset= */
((C_proc5)C_retrieve_symbol_proc(lf[195]))(5,*((C_word*)lf[195]+1),((C_word*)t0)[3],*((C_word*)lf[34]+1),((C_word*)((C_word*)t0)[2])[1],t1);}

/* rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_9373(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9373,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t2;
t9=C_slot(t8,C_fix(3));
t10=t2;
t11=C_slot(t10,C_fix(1));
t12=C_eqp(t11,lf[2]);
if(C_truep(t12)){
t13=C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9437,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t13,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1248 get */
((C_proc5)C_retrieve_symbol_proc(lf[40]))(5,*((C_word*)lf[40]+1),t14,((C_word*)t0)[9],t13,lf[189]);}
else{
t13=C_eqp(t11,lf[21]);
if(C_truep(t13)){
if(C_truep(t3)){
t14=C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9455,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=t9,a[5]=((C_word*)t0)[8],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1256 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),t1,t14,t15);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=C_eqp(t11,lf[101]);
if(C_truep(t14)){
t15=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}
else{
t16=C_i_cadr(t7);
t17=C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t16);
t18=C_mutate(((C_word *)((C_word*)t0)[10])+1,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9492,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1265 every */
((C_proc4)C_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),t1,t19,t9);}}
else{
t15=C_eqp(t11,lf[190]);
if(C_truep(t15)){
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[6])){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9526,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t17=C_i_car(t9);
/* optimizer.scm: 1268 scan-used-variables */
((C_proc4)C_retrieve_symbol_proc(lf[145]))(4,*((C_word*)lf[145]+1),t16,t17,t5);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=C_eqp(t11,lf[191]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9542,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t18=C_i_cadr(t7);
/* optimizer.scm: 1273 estimate-foreign-result-size */
((C_proc3)C_retrieve_symbol_proc(lf[192]))(3,*((C_word*)lf[192]+1),t17,t18);}
else{
t17=C_eqp(t11,lf[193]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9583,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t19=C_i_car(t7);
/* optimizer.scm: 1281 estimate-foreign-result-size */
((C_proc3)C_retrieve_symbol_proc(lf[192]))(3,*((C_word*)lf[192]+1),t18,t19);}
else{
t18=C_eqp(t11,lf[8]);
if(C_truep(t18)){
t19=C_i_car(t9);
t20=C_slot(t19,C_fix(1));
t21=C_eqp(lf[2],t20);
if(C_truep(t21)){
t22=C_slot(t19,C_fix(2));
t23=C_i_car(t22);
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9636,a[2]=t1,a[3]=t9,a[4]=t5,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t25=C_eqp(t23,((C_word*)t0)[4]);
if(C_truep(t25)){
t26=C_eqp(((C_word*)((C_word*)t0)[10])[1],C_fix(0));
if(C_truep(t26)){
t27=C_i_cadr(t9);
t28=C_slot(t27,C_fix(1));
t29=C_eqp(lf[2],t28);
if(C_truep(t29)){
t30=C_slot(t27,C_fix(2));
t31=C_i_car(t30);
t32=C_a_i_cons(&a,2,t31,((C_word*)((C_word*)t0)[3])[1]);
t33=C_mutate(((C_word *)((C_word*)t0)[3])+1,t32);
t34=C_set_block_item(((C_word*)t0)[11],0,C_SCHEME_TRUE);
t35=t24;
f_9636(t35,C_SCHEME_TRUE);}
else{
t30=C_set_block_item(((C_word*)t0)[11],0,C_SCHEME_TRUE);
t31=t24;
f_9636(t31,C_SCHEME_TRUE);}}
else{
t27=t24;
f_9636(t27,C_SCHEME_FALSE);}}
else{
t26=t24;
f_9636(t26,C_eqp(t23,((C_word*)t0)[2]));}}
else{
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_FALSE);}}
else{
t19=C_eqp(t11,lf[194]);
if(C_truep(t19)){
t20=C_i_cadddr(t7);
t21=C_eqp(t20,C_fix(0));
if(C_truep(t21)){
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,t21);}
else{
t22=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t22)){
t23=t1;
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_FALSE);}
else{
t23=C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t20);
t24=C_mutate(((C_word *)((C_word*)t0)[10])+1,t23);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9745,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1307 every */
((C_proc4)C_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),t1,t25,t9);}}}
else{
t20=C_eqp(t11,lf[9]);
if(C_truep(t20)){
t21=C_i_car(t9);
t22=C_i_car(t7);
/* optimizer.scm: 1308 rec */
t67=t1;
t68=t21;
t69=t22;
t70=C_SCHEME_FALSE;
t71=t5;
t1=t67;
t2=t68;
t3=t69;
t4=t70;
t5=t71;
goto loop;}
else{
t21=C_eqp(t11,lf[5]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9778,a[2]=t5,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t23=C_i_car(t9);
t24=C_i_car(t7);
/* optimizer.scm: 1310 rec */
t67=t22;
t68=t23;
t69=t24;
t70=t2;
t71=t5;
t1=t67;
t2=t68;
t3=t69;
t4=t70;
t5=t71;
goto loop;}
else{
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9802,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1312 every */
((C_proc4)C_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),t1,t22,t9);}}}}}}}}}}}

/* a9801 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9802(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9802,3,t0,t1,t2);}
/* optimizer.scm: 1312 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9373(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k9776 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9778,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9789,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1311 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9787 in k9776 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1311 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9373(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* a9744 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9745,3,t0,t1,t2);}
/* optimizer.scm: 1307 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9373(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k9634 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_9636(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9636,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9641,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1300 every */
((C_proc4)C_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a9640 in k9634 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9641,3,t0,t1,t2);}
/* optimizer.scm: 1300 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9373(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k9581 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9583,2,t0,t1);}
t2=C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9589,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9589(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_9589(t5,C_SCHEME_FALSE);}
else{
t5=C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_9589(t7,C_SCHEME_TRUE);}}}

/* k9587 in k9581 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_9589(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9589,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9594,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1287 every */
((C_proc4)C_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a9593 in k9587 in k9581 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9594(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9594,3,t0,t1,t2);}
/* optimizer.scm: 1287 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9373(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k9540 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9542,2,t0,t1);}
t2=C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9548,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9548(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_9548(t5,C_SCHEME_FALSE);}
else{
t5=C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_9548(t7,C_SCHEME_TRUE);}}}

/* k9546 in k9540 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_9548(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9548,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9553,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1279 every */
((C_proc4)C_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a9552 in k9546 in k9540 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9553(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9553,3,t0,t1,t2);}
/* optimizer.scm: 1279 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9373(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k9524 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9526,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9522,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1270 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9520 in k9524 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a9491 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9492(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9492,3,t0,t1,t2);}
/* optimizer.scm: 1265 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9373(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a9454 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9455,5,t0,t1,t2,t3,t4);}
t5=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
t7=C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9471,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1260 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t8,t2,((C_word*)t0)[2]);}

/* k9469 in a9454 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1260 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9373(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k9435 in rec in scan in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=C_i_memq(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=C_i_not(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(2));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}}}}

/* walk in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_9171(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9171,NULL,5,t0,t1,t2,t3,t4);}
t5=t3;
t6=C_slot(t5,C_fix(2));
t7=t3;
t8=C_slot(t7,C_fix(3));
t9=t3;
t10=C_slot(t9,C_fix(1));
t11=C_eqp(t10,lf[21]);
if(C_truep(t11)){
t12=C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9211,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
if(C_truep(C_i_cadr(t6))){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9296,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t8,a[7]=t3,a[8]=t12,a[9]=t13,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1223 get */
((C_proc5)C_retrieve_symbol_proc(lf[40]))(5,*((C_word*)lf[40]+1),t14,((C_word*)t0)[2],t2,lf[89]);}
else{
t14=t13;
f_9211(2,t14,C_SCHEME_FALSE);}}
else{
t14=t13;
f_9211(2,t14,C_SCHEME_FALSE);}}
else{
t12=C_eqp(t10,lf[9]);
if(C_truep(t12)){
t13=C_i_car(t6);
t14=C_i_car(t8);
/* optimizer.scm: 1233 walk */
t26=t1;
t27=t13;
t28=t14;
t29=C_SCHEME_FALSE;
t1=t26;
t2=t27;
t3=t28;
t4=t29;
goto loop;}
else{
t13=C_eqp(t10,lf[5]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9322,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t15=C_i_car(t6);
t16=C_i_car(t8);
/* optimizer.scm: 1235 walk */
t26=t14;
t27=t15;
t28=t16;
t29=t3;
t1=t26;
t2=t27;
t3=t28;
t4=t29;
goto loop;}
else{
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9342,a[2]=t15,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t17=((C_word*)t15)[1];
f_9342(t17,t1,t8);}}}}

/* loop2287 in walk in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_9342(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9342,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9350,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9357,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g22942295 */
t6=t3;
f_9350(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9355 in loop2287 in walk in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9342(t3,((C_word*)t0)[2],t2);}

/* g2294 in loop2287 in walk in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_9350(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9350,NULL,3,t0,t1,t2);}
/* optimizer.scm: 1237 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9171(t3,t1,C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k9320 in walk in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 1236 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9171(t3,((C_word*)t0)[2],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k9294 in walk in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9296,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_9211(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_listp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1225 get */
((C_proc5)C_retrieve_symbol_proc(lf[40]))(5,*((C_word*)lf[40]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5],lf[59]);}
else{
t2=((C_word*)t0)[9];
f_9211(2,t2,C_SCHEME_FALSE);}}}

/* k9240 in k9294 in walk in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9242,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1226 get-list */
((C_proc5)C_retrieve_symbol_proc(lf[130]))(5,*((C_word*)lf[130]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[88]);}
else{
t2=((C_word*)t0)[4];
f_9211(2,t2,C_SCHEME_FALSE);}}

/* k9246 in k9240 in k9294 in walk in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9248,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9254,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1227 get-list */
((C_proc5)C_retrieve_symbol_proc(lf[130]))(5,*((C_word*)lf[130]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[132]);}
else{
t2=((C_word*)t0)[4];
f_9211(2,t2,C_SCHEME_FALSE);}}

/* k9252 in k9246 in k9240 in k9294 in walk in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9254,2,t0,t1);}
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[10],((C_word*)t0)[9]);
if(C_truep(t2)){
t3=C_i_length(((C_word*)t0)[8]);
t4=C_i_length(t1);
t5=C_eqp(t3,t4);
if(C_truep(t5)){
t6=C_i_car(((C_word*)t0)[7]);
t7=C_i_car(((C_word*)t0)[6]);
t8=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* optimizer.scm: 1230 scan */
t9=((C_word*)((C_word*)t0)[4])[1];
f_9370(t9,((C_word*)t0)[3],t6,t7,((C_word*)t0)[5],((C_word*)t0)[2],t8);}
else{
t6=((C_word*)t0)[3];
f_9211(2,t6,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_9211(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_9211(2,t2,C_SCHEME_FALSE);}}

/* k9209 in walk in ##compiler#transform-direct-lambdas! in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1231 transform */
t2=((C_word*)((C_word*)t0)[11])[1];
f_9824(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 1232 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9171(t3,((C_word*)t0)[10],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}}

/* ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6809,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
switch(t6){
case C_fix(1):
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6871,a[2]=t5,a[3]=t8,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t9,t10,lf[58]);
case C_fix(2):
if(C_truep(C_retrieve(lf[150]))){
t9=C_i_length(t8);
t10=C_i_car(t7);
t11=C_eqp(t9,t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7022,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t13=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t12,t13,lf[58]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(3):
if(C_truep(C_retrieve(lf[150]))){
if(C_truep(C_i_nullp(t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7097,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t10=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t9,t10,lf[58]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(4):
if(C_truep(C_retrieve(lf[150]))){
if(C_truep(C_retrieve(lf[154]))){
t9=C_i_length(t8);
t10=C_eqp(C_fix(2),t9);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7146,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t11,t12,lf[58]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(5):
if(C_truep(C_retrieve(lf[150]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7214,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t9,t10,lf[58]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(6):
t9=C_i_caddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[154]));
if(C_truep(t10)){
if(C_truep(C_retrieve(lf[150]))){
t11=C_i_length(t8);
t12=C_eqp(C_fix(1),t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7319,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t14=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t13,t14,lf[58]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(7):
t9=C_i_cadddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[154]));
if(C_truep(t10)){
if(C_truep(C_retrieve(lf[150]))){
t11=C_i_length(t8);
t12=C_i_car(t7);
t13=C_eqp(t11,t12);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7408,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t15=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t14,t15,lf[58]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(8):
if(C_truep(C_retrieve(lf[150]))){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7481,a[2]=t8,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t10=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t9,t10,lf[58]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(9):
if(C_truep(C_retrieve(lf[150]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7507,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t9,t10,lf[58]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(10):
if(C_truep(C_retrieve(lf[150]))){
t9=C_i_cadddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[154]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7750,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t12=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t11,t12,lf[58]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(11):
if(C_truep(C_retrieve(lf[150]))){
t9=C_i_caddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[154]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7849,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t11,t12,lf[58]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(12):
if(C_truep(C_retrieve(lf[150]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7920,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t9,t10,lf[58]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(13):
if(C_truep(C_retrieve(lf[150]))){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8008,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t10=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t9,t10,lf[58]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(14):
if(C_truep(C_retrieve(lf[150]))){
t9=C_i_cadr(t7);
t10=C_i_length(t8);
t11=C_eqp(t9,t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8085,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t13=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t12,t13,lf[58]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(15):
if(C_truep(C_retrieve(lf[150]))){
t9=C_i_length(t8);
t10=C_eqp(C_fix(1),t9);
if(C_truep(t10)){
t11=C_retrieve(lf[154]);
t12=(C_truep(t11)?t11:C_i_cadddr(t7));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8179,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t14=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t13,t14,lf[58]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(16):
t9=C_i_car(t7);
t10=C_i_length(t8);
t11=C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[150]))){
t12=C_i_not(t9);
t13=(C_truep(t12)?t12:C_eqp(t10,t9));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8284,a[2]=t10,a[3]=t11,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t15=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t14,t15,lf[58]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(17):
if(C_truep(C_retrieve(lf[150]))){
t9=C_i_length(t8);
t10=C_i_car(t7);
t11=C_eqp(t9,t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8374,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t13=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t12,t13,lf[58]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(18):
if(C_truep(C_retrieve(lf[150]))){
if(C_truep(C_i_nullp(t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8453,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t10=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t9,t10,lf[58]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(19):
if(C_truep(C_retrieve(lf[150]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8493,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t9,t10,lf[58]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(20):
t9=C_i_length(t8);
t10=C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[154]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[150]))){
t12=C_i_car(t7);
t13=C_eqp(t9,t12);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8675,a[2]=t8,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t15=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t14,t15,lf[58]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(21):
if(C_truep(C_retrieve(lf[150]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8760,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t9,t10,lf[58]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(22):
t9=C_i_car(t7);
t10=C_i_length(t8);
t11=C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[150]))){
t12=C_eqp(t10,t9);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8955,a[2]=t11,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t14=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t13,t14,lf[58]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(23):
if(C_truep(C_retrieve(lf[150]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9035,a[2]=t5,a[3]=t1,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t9,t10,lf[58]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
default:
/* optimizer.scm: 1198 bomb */
((C_proc3)C_retrieve_symbol_proc(lf[186]))(3,*((C_word*)lf[186]+1),t1,lf[187]);}}

/* k9033 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9035,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_i_length(((C_word*)t0)[4]);
t4=C_i_car(((C_word*)t0)[5]);
if(C_truep(C_fixnum_greater_or_equal_p(t3,t4))){
t5=C_i_cadr(((C_word*)t0)[5]);
t6=C_a_i_list(&a,2,C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9060,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9064,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 1184 varnode */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t8,t9);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9062 in k9033 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9068,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9070,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9076,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a9075 in k9062 in k9033 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9076,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9084,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cddr(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9090,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_9090(t9,t4,t3,t5);}

/* loop in a9075 in k9062 in k9033 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_9090(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9090,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9110,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_i_car(t3);
if(C_truep(C_i_symbolp(t5))){
/* optimizer.scm: 814  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t4,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6834,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t5))){
t7=C_i_car(t5);
t8=t6;
f_6834(t8,C_eqp(lf[41],t7));}
else{
t7=t6;
f_6834(t7,C_SCHEME_FALSE);}}}}
else{
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9139,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cdr(t2);
t7=C_i_cdr(t3);
/* optimizer.scm: 1196 loop */
t13=t5;
t14=t6;
t15=t7;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}}

/* k9137 in loop in a9075 in k9062 in k9033 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9139,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6832 in loop in a9075 in k9062 in k9033 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_6834(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[3]);
/* optimizer.scm: 815  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),((C_word*)t0)[2],t2);}
else{
/* optimizer.scm: 816  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k9108 in loop in a9075 in k9062 in k9033 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9114,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1194 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_9090(t4,t2,C_SCHEME_END_OF_LIST,t3);}

/* k9112 in k9108 in loop in a9075 in k9062 in k9033 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9114,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k9082 in a9075 in k9062 in k9033 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1187 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9069 in k9062 in k9033 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9070,2,t0,t1);}
/* optimizer.scm: 1186 split-at */
((C_proc4)C_retrieve_symbol_proc(lf[99]))(4,*((C_word*)lf[99]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9066 in k9062 in k9033 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1183 cons* */
((C_proc5)C_retrieve_symbol_proc(lf[167]))(5,*((C_word*)lf[167]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9058 in k9033 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_9060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9060,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[2],t1));}

/* k8953 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8955,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[154]));
if(C_truep(t3)){
t4=C_eqp(C_retrieve(lf[157]),lf[162]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8999,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1165 fifth */
((C_proc3)C_retrieve_symbol_proc(lf[183]))(3,*((C_word*)lf[183]+1),t5,((C_word*)t0)[6]);}
else{
t5=C_i_cadr(((C_word*)t0)[6]);
t6=C_a_i_list(&a,2,t5,((C_word*)t0)[2]);
t7=((C_word*)t0)[5];
t8=C_a_i_record(&a,4,lf[10],lf[101],t6,t7);
t9=C_a_i_list(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
t11=t10;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_record(&a,4,lf[10],lf[8],lf[185],t9));}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8997 in k8953 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8999,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[4];
t4=C_a_i_record(&a,4,lf[10],lf[151],t2,t3);
t5=C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record(&a,4,lf[10],lf[8],lf[184],t5));}

/* k8758 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8760,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8766,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1125 fifth */
((C_proc3)C_retrieve_symbol_proc(lf[183]))(3,*((C_word*)lf[183]+1),t3,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8764 in k8758 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8766,2,t0,t1);}
t2=C_i_cadddr(((C_word*)t0)[6]);
t3=(C_truep(C_retrieve(lf[154]))?C_i_caddr(((C_word*)t0)[6]):C_i_cadr(((C_word*)t0)[6]));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8775,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8882,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1129 remove */
((C_proc4)C_retrieve_symbol_proc(lf[3]))(4,*((C_word*)lf[3]+1),t4,t5,((C_word*)t0)[2]);}

/* a8881 in k8764 in k8758 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8882,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(lf[41],t4);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k8773 in k8764 in k8758 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8775,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8797,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1134 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t2,((C_word*)t0)[5]);}
else{
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=C_i_car(t1);
t4=C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=((C_word*)t0)[6];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record(&a,4,lf[10],lf[8],lf[181],t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8835,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1142 fold-inner */
((C_proc4)C_retrieve_symbol_proc(lf[178]))(4,*((C_word*)lf[178]+1),t3,t4,t1);}}}

/* a8836 in k8773 in k8764 in k8758 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8837,4,t0,t1,t2,t3);}
t4=C_eqp(C_retrieve(lf[157]),lf[162]);
if(C_truep(t4)){
t5=C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=C_a_i_list(&a,2,t2,t3);
t7=t1;
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record(&a,4,lf[10],lf[151],t5,t6));}
else{
t5=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t6=C_a_i_list(&a,2,t2,t3);
t7=t1;
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record(&a,4,lf[10],lf[101],t5,t6));}}

/* k8833 in k8773 in k8764 in k8758 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8835,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],lf[182],t2));}

/* k8795 in k8773 in k8764 in k8758 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8797,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],lf[180],t2));}

/* k8673 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8675,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[6]);
t3=C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8704,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8716,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8715 in k8673 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8716,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8728,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 1113 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t4,t5);}

/* k8726 in a8715 in k8673 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8728,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* optimizer.scm: 1112 append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[6]+1)))(5,*((C_word*)lf[6]+1),((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8705 in k8673 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8706,2,t0,t1);}
t2=C_fixnum_decrease(((C_word*)t0)[3]);
/* optimizer.scm: 1111 split-at */
((C_proc4)C_retrieve_symbol_proc(lf[99]))(4,*((C_word*)lf[99]+1),t1,((C_word*)t0)[2],t2);}

/* k8702 in k8673 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8704,2,t0,t1);}
t2=C_a_i_record(&a,4,lf[10],lf[151],((C_word*)t0)[4],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record(&a,4,lf[10],lf[8],lf[179],t3));}

/* k8491 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8493,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=(C_truep(C_retrieve(lf[154]))?C_i_caddr(((C_word*)t0)[5]):C_i_cadr(((C_word*)t0)[5]));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8502,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8599,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1080 remove */
((C_proc4)C_retrieve_symbol_proc(lf[3]))(4,*((C_word*)lf[3]+1),t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8598 in k8491 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8599(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8599,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(lf[41],t4);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k8500 in k8491 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8502,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8524,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1085 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t2,((C_word*)t0)[4]);}
else{
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=C_i_car(t1);
t4=C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=((C_word*)t0)[5];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record(&a,4,lf[10],lf[8],lf[176],t4));}
else{
t3=C_i_cadddr(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:C_eqp(C_retrieve(lf[157]),lf[162]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8571,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8573,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1093 fold-inner */
((C_proc4)C_retrieve_symbol_proc(lf[178]))(4,*((C_word*)lf[178]+1),t5,t6,t1);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* a8572 in k8500 in k8491 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8573,4,t0,t1,t2,t3);}
t4=C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=C_a_i_list(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record(&a,4,lf[10],lf[151],t4,t5));}

/* k8569 in k8500 in k8491 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8571,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],lf[177],t2));}

/* k8522 in k8500 in k8491 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8524,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],lf[175],t2));}

/* k8451 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8453,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8469,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 1067 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8467 in k8451 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8469,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],lf[174],t2));}

/* k8372 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8374,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8403,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[154]))){
t3=C_i_cddr(((C_word*)t0)[2]);
t4=C_i_pairp(t3);
t5=t2;
f_8403(t5,(C_truep(t4)?C_i_caddr(((C_word*)t0)[2]):C_i_cadr(((C_word*)t0)[2])));}
else{
t3=t2;
f_8403(t3,C_i_cadr(((C_word*)t0)[2]));}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8401 in k8372 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_8403(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8403,NULL,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[4];
t4=C_a_i_record(&a,4,lf[10],lf[151],t2,t3);
t5=C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record(&a,4,lf[10],lf[8],lf[173],t5));}

/* k8282 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8284,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:C_retrieve(lf[154]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8318,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=C_i_cadr(((C_word*)t0)[7]);
t6=C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t6)){
t7=C_fixnum_increase(((C_word*)t0)[2]);
t8=t4;
f_8318(t8,C_a_i_list(&a,2,t5,t7));}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t7=C_i_car(((C_word*)t0)[3]);
t8=C_fixnum_times(((C_word*)t0)[2],t7);
t9=t4;
f_8318(t9,C_a_i_list(&a,2,t5,t8));}
else{
t7=t4;
f_8318(t7,C_a_i_list(&a,2,t5,((C_word*)t0)[3]));}}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8316 in k8282 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_8318(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8318,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=C_a_i_record(&a,4,lf[10],lf[101],t1,t2);
t4=C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record(&a,4,lf[10],lf[8],lf[172],t4));}

/* k8177 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8179,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_eqp(C_retrieve(lf[157]),t2);
if(C_truep(t3)){
t4=C_i_caddr(((C_word*)t0)[5]);
t5=C_a_i_list(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8201,a[2]=t5,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 1018 varnode */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t7,t8);}
else{
t4=C_i_cadr(((C_word*)t0)[5]);
t5=C_eqp(C_retrieve(lf[157]),t4);
if(C_truep(t5)){
t6=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t7=((C_word*)t0)[4];
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record(&a,4,lf[10],lf[8],lf[171],t6));}
else{
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8203 in k8177 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1018 cons* */
((C_proc5)C_retrieve_symbol_proc(lf[167]))(5,*((C_word*)lf[167]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8199 in k8177 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8201,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[2],t1));}

/* k8083 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8085,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_eqp(C_retrieve(lf[157]),t2);
if(C_truep(t3)){
t4=C_i_cadddr(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:C_retrieve(lf[154]));
if(C_truep(t5)){
t6=(C_truep(C_retrieve(lf[154]))?C_i_cadddr(((C_word*)t0)[5]):C_i_caddr(((C_word*)t0)[5]));
t7=C_a_i_list(&a,1,t6);
t8=((C_word*)t0)[4];
t9=C_a_i_record(&a,4,lf[10],lf[151],t7,t8);
t10=C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
t12=t11;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_a_i_record(&a,4,lf[10],lf[8],lf[170],t10));}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8006 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8008,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[154]));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8032,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t6=C_i_cdr(((C_word*)t0)[2]);
t7=t5;
f_8032(t7,C_a_i_cons(&a,2,C_SCHEME_TRUE,t6));}
else{
t6=t5;
f_8032(t6,((C_word*)t0)[2]);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8030 in k8006 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_8032(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8032,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8036,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_list(&a,2,((C_word*)t0)[4],C_SCHEME_TRUE);
t4=C_a_i_record(&a,4,lf[10],lf[169],t3,C_SCHEME_END_OF_LIST);
/* optimizer.scm: 991  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[167]))(5,*((C_word*)lf[167]+1),t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8034 in k8030 in k8006 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_8036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8036,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],t3,t1));}

/* k7918 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7920,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:C_retrieve(lf[154]));
if(C_truep(t3)){
t4=C_i_length(((C_word*)t0)[4]);
t5=C_i_caddr(((C_word*)t0)[5]);
if(C_truep(C_fixnum_less_or_equal_p(t4,t5))){
t6=C_eqp(t4,C_fix(1));
if(C_truep(t6)){
t7=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t8=((C_word*)t0)[2];
t9=t8;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_record(&a,4,lf[10],lf[8],lf[168],t7));}
else{
t7=C_i_car(((C_word*)t0)[5]);
t8=C_a_i_list(&a,2,C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7972,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7976,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 981  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t10,t11);}}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7974 in k7918 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 981  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[167]))(5,*((C_word*)lf[167]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7970 in k7918 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7972,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[2],t1));}

/* k7847 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7849,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_7861(t5,t3);}
else{
t5=C_i_length(((C_word*)t0)[2]);
t6=C_i_car(((C_word*)t0)[5]);
t7=t4;
f_7861(t7,C_eqp(t5,t6));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7859 in k7847 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_7861(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7861,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_a_i_list(&a,2,C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7877,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 966  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7879 in k7859 in k7847 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 966  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[167]))(5,*((C_word*)lf[167]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7875 in k7859 in k7847 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7877,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[2],t1));}

/* k7748 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7750,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_length(((C_word*)t0)[5]);
if(C_truep(C_and(C_fixnum_lessp(C_fix(0),t2),C_fixnum_lessp(t2,C_fix(3))))){
t3=C_i_car(((C_word*)t0)[4]);
t4=C_a_i_list(&a,2,C_SCHEME_FALSE,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7779,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 948  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t5,t6);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7777 in k7748 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7779,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 951  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* k7785 in k7777 in k7748 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7791,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
if(C_truep(C_i_nullp(t3))){
t4=C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 953  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t2,t4);}
else{
t4=t2;
f_7791(2,t4,C_i_cadr(((C_word*)t0)[3]));}}

/* k7789 in k7785 in k7777 in k7748 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7791,2,t0,t1);}
t2=C_a_i_list(&a,5,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[2],t2));}

/* k7505 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7507,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_length(((C_word*)t0)[5]);
if(C_truep(C_fixnum_lessp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7529,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 919  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7535,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[154]))){
t4=C_eqp(C_retrieve(lf[157]),lf[166]);
t5=t3;
f_7535(t5,C_i_not(t4));}
else{
t4=t3;
f_7535(t4,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7533 in k7505 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_7535(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7535,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_7538(t3,t1);}
else{
t3=C_eqp(C_retrieve(lf[157]),lf[162]);
t4=(C_truep(t3)?C_i_caddr(((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_7538(t5,t4);}
else{
t5=C_eqp(C_retrieve(lf[157]),lf[165]);
t6=t2;
f_7538(t6,(C_truep(t5)?C_i_cadddr(((C_word*)t0)[5]):C_SCHEME_FALSE));}}}

/* k7536 in k7533 in k7505 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_7538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7538,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7651,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_7651(t10,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop1712 in k7536 in k7533 in k7505 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_7651(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7651,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7685,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm: 923  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[96]))(2,*((C_word*)lf[96]+1),t3);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7683 in loop1712 in k7536 in k7533 in k7505 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7685,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop17121725 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7651(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop17121725 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7651(t6,((C_word*)t0)[3],t5);}}

/* k7539 in k7536 in k7533 in k7505 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7541,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7544,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7616,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_7616(t10,t6,t1);}

/* loop1737 in k7539 in k7536 in k7533 in k7505 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_7616(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7616,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[61]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7645,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g17531754 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7643 in loop1737 in k7539 in k7536 in k7533 in k7505 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7645,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop17371750 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7616(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop17371750 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7616(t6,((C_word*)t0)[3],t5);}}

/* k7542 in k7539 in k7536 in k7533 in k7505 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7549,tmp=(C_word)a,a+=2,tmp);
t3=C_eqp(C_retrieve(lf[157]),lf[162]);
t4=(C_truep(t3)?C_i_car(((C_word*)t0)[6]):C_i_cadr(((C_word*)t0)[6]));
t5=C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7588,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 935  fold-boolean */
((C_proc4)C_retrieve_symbol_proc(lf[164]))(4,*((C_word*)lf[164]+1),t6,t7,t1);}

/* a7587 in k7542 in k7539 in k7536 in k7533 in k7505 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7588,4,t0,t1,t2,t3);}
t4=C_a_i_list(&a,2,t2,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record(&a,4,lf[10],lf[151],((C_word*)t0)[2],t4));}

/* k7584 in k7542 in k7539 in k7536 in k7533 in k7505 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7586,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=C_a_i_record(&a,4,lf[10],lf[8],lf[163],t2);
/* optimizer.scm: 925  fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[138]))(6,*((C_word*)lf[138]+1),((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7548 in k7542 in k7539 in k7536 in k7533 in k7505 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7549(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7549,5,t0,t1,t2,t3,t4);}
t5=C_a_i_list(&a,1,t3);
t6=C_a_i_list(&a,2,t2,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record(&a,4,lf[10],lf[5],t5,t6));}

/* k7527 in k7505 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7529,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],lf[161],t2));}

/* k7479 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[6]);
/* g16761677 */
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7406 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7408,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7437,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7445,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 905  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7443 in k7406 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7445,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* optimizer.scm: 904  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7435 in k7406 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7437,2,t0,t1);}
t2=C_a_i_record(&a,4,lf[10],lf[151],((C_word*)t0)[4],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record(&a,4,lf[10],lf[8],lf[160],t3));}

/* k7317 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7319,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_a_i_list(&a,1,t2);
t4=C_i_cadr(((C_word*)t0)[5]);
t5=C_a_i_list(&a,1,t4);
t6=((C_word*)t0)[4];
t7=C_a_i_record(&a,4,lf[10],lf[151],t5,t6);
t8=C_a_i_list(&a,1,t7);
t9=C_a_i_record(&a,4,lf[10],lf[151],t3,t8);
t10=C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
t12=t11;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_a_i_record(&a,4,lf[10],lf[8],lf[159],t10));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7212 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7214,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_length(((C_word*)t0)[5]);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=C_i_caddr(((C_word*)t0)[4]);
t5=C_i_not(t4);
t6=(C_truep(t5)?t5:C_eqp(t4,C_retrieve(lf[157])));
if(C_truep(t6)){
t7=C_i_car(((C_word*)t0)[4]);
t8=C_a_i_list(&a,1,t7);
t9=C_i_car(((C_word*)t0)[5]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7269,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 881  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t10,t11);}
else{
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7267 in k7212 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7269,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_record(&a,4,lf[10],lf[151],((C_word*)t0)[4],t2);
t4=C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record(&a,4,lf[10],lf[8],lf[158],t4));}

/* k7144 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7146,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_a_i_list(&a,2,C_SCHEME_FALSE,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7166,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 863  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t4,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7164 in k7144 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7166,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7174,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 866  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* k7172 in k7164 in k7144 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7174,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[7]);
t3=C_a_i_list(&a,5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[2],t3));}

/* k7095 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7097,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7113,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 854  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7111 in k7095 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7113,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],lf[156],t2));}

/* k7020 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_7022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7022,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:C_retrieve(lf[154]));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
t5=C_i_cadr(((C_word*)t0)[5]);
t6=C_a_i_list(&a,1,t5);
t7=((C_word*)t0)[4];
t8=C_a_i_record(&a,4,lf[10],lf[151],t6,t7);
t9=C_a_i_list(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
t11=t10;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_record(&a,4,lf[10],lf[8],lf[155],t9));}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6869 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6871,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_length(((C_word*)t0)[3]);
t4=C_i_car(((C_word*)t0)[4]);
t5=C_eqp(t3,t4);
if(C_truep(t5)){
t6=C_i_car(((C_word*)t0)[3]);
t7=C_i_cadr(((C_word*)t0)[3]);
t8=C_slot(t6,C_fix(1));
t9=C_eqp(lf[2],t8);
if(C_truep(t9)){
t10=C_slot(t7,C_fix(1));
t11=C_eqp(lf[2],t10);
if(C_truep(t11)){
t12=C_slot(t6,C_fix(2));
t13=C_slot(t7,C_fix(2));
if(C_truep(C_i_equalp(t12,t13))){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6952,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 830  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t14,C_SCHEME_TRUE);}
else{
t14=t2;
f_6874(t14,C_SCHEME_FALSE);}}
else{
t12=t2;
f_6874(t12,C_SCHEME_FALSE);}}
else{
t10=t2;
f_6874(t10,C_SCHEME_FALSE);}}
else{
t6=t2;
f_6874(t6,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6950 in k6869 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6952,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_6874(t3,C_a_i_record(&a,4,lf[10],lf[8],lf[153],t2));}

/* k6872 in k6869 in ##compiler#simplify-named-call in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_6874(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6874,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(C_retrieve(lf[150]))){
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[3];
t5=C_a_i_record(&a,4,lf[10],lf[151],t3,t4);
t6=C_a_i_list(&a,2,((C_word*)t0)[2],t5);
t7=((C_word*)t0)[5];
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record(&a,4,lf[10],lf[8],lf[152],t6));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* ##compiler#rewrite in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6789(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6789r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6789r(t0,t1,t2,t3);}}

static void C_ccall f_6789r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6793,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 808  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[46]))(4,*((C_word*)lf[46]+1),t4,C_retrieve(lf[147]),t2);}

/* k6791 in ##compiler#rewrite in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6793,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6803,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* optimizer.scm: 809  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t3,t2,t4);}

/* k6801 in k6791 in ##compiler#rewrite in k6785 in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 809  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),((C_word*)t0)[3],C_retrieve(lf[147]),((C_word*)t0)[2],t1);}

/* ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6300(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6300,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6304,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6736,a[2]=t8,a[3]=t13,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t15=((C_word*)t13)[1];
f_6736(t15,t11,t2,t3);}

/* loop1277 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_6736(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6736,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[146]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6769,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g12971298 */
t10=t6;
((C_proc4)C_retrieve_proc(t10))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k6767 in loop1277 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6769,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6749,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_6749(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_6749(t5,t4);}}

/* k6747 in k6767 in loop1277 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_6749(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop12771291 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6736(t5,((C_word*)t0)[2],t3,t4);}

/* k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6306,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6351,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6689,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6689(t7,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop1304 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_6689(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6689,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6697,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6709,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g13321333 */
t10=t6;
f_6697(t10,t7,t8,t9);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k6707 in loop1304 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_6689(t4,((C_word*)t0)[2],t2,t3);}

/* g1332 in loop1304 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_6697(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6697,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6702,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6706,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 732  scan-used-variables */
((C_proc4)C_retrieve_symbol_proc(lf[145]))(4,*((C_word*)lf[145]+1),t5,t3,((C_word*)t0)[2]);}

/* k6704 in g1332 in loop1304 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 732  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k6700 in g1332 in loop1304 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6351,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6609,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_6609(t10,t6,((C_word*)t0)[2]);}

/* loop1342 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_6609(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6609,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6617,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6676,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g13491350 */
t6=t3;
f_6617(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6674 in loop1342 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6609(t3,((C_word*)t0)[2],t2);}

/* g1349 in loop1342 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_6617(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6617,NULL,3,t0,t1,t2);}
if(C_truep(C_i_memq(t2,((C_word*)((C_word*)t0)[5])[1]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6627,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6649,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 741  filter */
((C_proc4)C_retrieve_symbol_proc(lf[143]))(4,*((C_word*)lf[143]+1),t3,t4,((C_word*)t0)[2]);}}

/* a6648 in g1349 in loop1342 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6649(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6649,3,t0,t1,t2);}
t3=C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6662,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 742  find-path */
t5=((C_word*)t0)[2];
f_6306(t5,t4,((C_word*)t0)[3],t2);}}

/* k6660 in a6648 in g1349 in loop1342 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 742  find-path */
t2=((C_word*)t0)[5];
f_6306(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6625 in g1349 in loop1342 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6631,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6643,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 744  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[96]))(2,*((C_word*)lf[96]+1),t3);}

/* k6641 in k6625 in g1349 in loop1342 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6643,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* optimizer.scm: 744  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[3],t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k6629 in k6625 in g1349 in loop1342 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6631,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6635,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_list(&a,1,((C_word*)t0)[3]);
/* optimizer.scm: 745  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[6]+1)))(5,*((C_word*)lf[6]+1),t3,t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k6633 in k6629 in k6625 in g1349 in loop1342 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6354,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6357,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6528,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_6528(t8,t4,((C_word*)((C_word*)t0)[7])[1]);}

/* loop1366 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_6528(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6528,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6536,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6596,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g13731374 */
t6=t3;
f_6536(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6594 in loop1366 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6528(t3,((C_word*)t0)[2],t2);}

/* g1373 in loop1366 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_6536(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6536,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6543,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=C_i_cdr(t2);
/* optimizer.scm: 754  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[144]))(4,*((C_word*)lf[144]+1),t4,t5,t6);}

/* a6578 in g1373 in loop1366 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6579,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6585,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 755  filter */
((C_proc4)C_retrieve_symbol_proc(lf[143]))(4,*((C_word*)lf[143]+1),t1,t3,((C_word*)t0)[2]);}

/* a6584 in a6578 in g1373 in loop1366 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6585(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6585,3,t0,t1,t2);}
/* optimizer.scm: 755  find-path */
t3=((C_word*)t0)[3];
f_6306(t3,t1,((C_word*)t0)[2],t2);}

/* k6541 in g1373 in loop1366 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6547,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6551,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6553,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 760  filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[142]))(4,*((C_word*)lf[142]+1),t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a6552 in k6541 in g1373 in loop1366 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6553(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6553,3,t0,t1,t2);}
t3=C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6566,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cdr(t2);
/* optimizer.scm: 761  lset<= */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t4,*((C_word*)lf[34]+1),t5,((C_word*)t0)[2]);}}

/* k6564 in a6552 in k6541 in g1373 in loop1366 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE));}

/* k6549 in k6541 in g1373 in loop1366 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 758  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k6545 in k6541 in g1373 in loop1366 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6355 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6360,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 767  topological-sort */
((C_proc4)C_retrieve_symbol_proc(lf[140]))(4,*((C_word*)lf[140]+1),t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[34]+1));}

/* k6358 in k6355 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6360,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6380,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 772  fold */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t4,t5,((C_word*)t0)[2],t1);}

/* a6379 in k6358 in k6355 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6380(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6380,4,t0,t1,t2,t3);}
t4=C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
t5=C_i_cdr(t4);
t6=C_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6393,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=C_i_cdr(t5);
if(C_truep(C_i_nullp(t8))){
t9=C_i_assq(t6,((C_word*)((C_word*)t0)[2])[1]);
t10=C_i_cdr(t9);
t11=C_i_memq(t6,t10);
t12=t7;
f_6393(t12,C_i_not(t11));}
else{
t9=t7;
f_6393(t9,C_SCHEME_FALSE);}}

/* k6391 in a6379 in k6358 in k6355 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_6393(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6393,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_i_assq(((C_word*)t0)[7],((C_word*)t0)[5]);
t5=C_i_cdr(t4);
t6=C_a_i_list(&a,2,t5,((C_word*)t0)[4]);
t7=((C_word*)t0)[3];
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record(&a,4,lf[10],lf[5],((C_word*)t0)[2],t6));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6422,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6452,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6454,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 786  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),t3,t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a6453 in k6391 in a6379 in k6358 in k6355 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6454,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6500,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 789  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[96]))(2,*((C_word*)lf[96]+1),t4);}

/* k6498 in a6453 in k6391 in a6379 in k6358 in k6355 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6500,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=C_i_cdr(t4);
t6=C_a_i_list(&a,1,t5);
t7=C_a_i_record(&a,4,lf[10],lf[9],t3,t6);
t8=C_a_i_list(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
t10=t9;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_record(&a,4,lf[10],lf[5],t2,t8));}

/* k6450 in k6391 in a6379 in k6358 in k6355 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 781  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6421 in k6391 in a6379 in k6358 in k6355 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6422,4,t0,t1,t2,t3);}
t4=C_a_i_list(&a,1,t2);
t5=C_a_i_record(&a,4,lf[10],lf[11],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=C_a_i_list(&a,2,t5,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record(&a,4,lf[10],lf[5],t4,t6));}

/* k6361 in k6358 in k6355 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6363,2,t0,t1);}
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6372,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 798  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t2,lf[31],lf[137],((C_word*)((C_word*)t0)[3])[1]);}
else{
/* optimizer.scm: 800  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* k6370 in k6361 in k6358 in k6355 in k6352 in k6349 in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 799  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* find-path in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_6306(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6306,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6312,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6312(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* find in find-path in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_fcall f_6312(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6312,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_memq(t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_assq(t2,((C_word*)((C_word*)t0)[4])[1]);
t5=C_i_cdr(t4);
t6=C_i_memq(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=C_a_i_cons(&a,2,t2,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6336,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 728  any */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t1,t8,t5);}}}

/* a6335 in find in find-path in k6302 in ##compiler#reorganize-recursive-bindings in k6296 in k6293 in k6290 in k4100 in k3732 in k3729 */
static void C_ccall f_6336(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6336,3,t0,t1,t2);}
/* optimizer.scm: 728  find */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6312(t3,t1,t2,((C_word*)t0)[2]);}

/* register-simplifications in k4100 in k3732 in k3729 */
static void C_ccall f_6285(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_6285r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6285r(t0,t1,t2,t3);}}

static void C_ccall f_6285r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* optimizer.scm: 496  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[135]))(5,*((C_word*)lf[135]+1),t1,C_retrieve(lf[37]),t2,t3);}

/* ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_ccall f_5966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5966,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5969,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5973,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5980,a[2]=t11,a[3]=t3,a[4]=t9,a[5]=t7,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 448  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t14,lf[35],lf[133]);}

/* k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_ccall f_5980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5983,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6000,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t3,lf[131],lf[58]);}

/* k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_ccall f_6000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6000,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 487  test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5973(t3,t2,lf[131],lf[132]);}
else{
t2=((C_word*)t0)[2];
f_5983(2,t2,C_SCHEME_UNDEFINED);}}

/* k6005 in k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_ccall f_6007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6007,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6012,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_6012(t6,((C_word*)t0)[2],t2);}

/* loop897 in k6005 in k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_fcall f_6012(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6012,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6272,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g904905 */
t6=t3;
f_6020(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6270 in loop897 in k6005 in k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_ccall f_6272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6012(t3,((C_word*)t0)[2],t2);}

/* g904 in loop897 in k6005 in k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_fcall f_6020(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6020,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=C_slot(t3,C_fix(3));
t5=C_i_cadr(t4);
t6=C_slot(t5,C_fix(2));
t7=C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6038,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6256,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 457  test */
t10=((C_word*)((C_word*)t0)[2])[1];
f_5973(t10,t9,t7,lf[89]);}

/* k6254 in g904 in loop897 in k6005 in k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_ccall f_6256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6038(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 457  test */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5973(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[59]);}}

/* k6036 in g904 in loop897 in k6005 in k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_ccall f_6038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6041,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 458  get-list */
((C_proc5)C_retrieve_symbol_proc(lf[130]))(5,*((C_word*)lf[130]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[88]);}

/* k6039 in k6036 in g904 in loop897 in k6005 in k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[8])){
if(C_truep(t1)){
t3=C_i_length(t1);
t4=C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=C_i_length(((C_word*)t0)[4]);
t6=C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=((C_word*)t0)[8];
t8=C_slot(t7,C_fix(1));
t9=t2;
f_6047(t9,C_eqp(lf[21],t8));}
else{
t7=t2;
f_6047(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_6047(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6047(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6047(t3,C_SCHEME_FALSE);}}

/* k6045 in k6039 in k6036 in g904 in loop897 in k6005 in k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_fcall f_6047(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6047,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=C_slot(t2,C_fix(2));
t4=C_i_caddr(t3);
t5=((C_word*)t0)[8];
t6=C_slot(t5,C_fix(3));
t7=C_i_car(t6);
t8=C_slot(t7,C_fix(3));
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t8,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t7,a[10]=t4,tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_listp(t4))){
t10=C_i_cdr(t4);
t11=t9;
f_6067(t11,C_i_nullp(t10));}
else{
t10=t9;
f_6067(t10,C_SCHEME_FALSE);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6065 in k6045 in k6039 in k6036 in g904 in loop897 in k6005 in k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_fcall f_6067(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6067,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6073,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 469  get-list */
((C_proc5)C_retrieve_symbol_proc(lf[130]))(5,*((C_word*)lf[130]+1),t3,((C_word*)t0)[2],t2,lf[88]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k6071 in k6065 in k6045 in k6039 in k6036 in g904 in loop897 in k6005 in k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_ccall f_6073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=C_i_length(t1);
t4=C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=C_slot(((C_word*)t0)[9],C_fix(1));
t6=t2;
f_6079(t6,C_eqp(lf[4],t5));}
else{
t5=t2;
f_6079(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6079(t3,C_SCHEME_FALSE);}}

/* k6077 in k6071 in k6065 in k6045 in k6039 in k6036 in g904 in loop897 in k6005 in k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_fcall f_6079(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6079,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[9],C_fix(3));
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6088,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=C_slot(t3,C_fix(1));
t6=C_eqp(lf[2],t5);
if(C_truep(t6)){
t7=C_slot(t3,C_fix(2));
t8=C_i_car(t7);
t9=t4;
f_6088(t9,C_eqp(((C_word*)t0)[2],t8));}
else{
t7=t4;
f_6088(t7,C_SCHEME_FALSE);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6086 in k6077 in k6071 in k6065 in k6045 in k6039 in k6036 in g904 in loop897 in k6005 in k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_fcall f_6088(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6088,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 481  node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t4,((C_word*)t0)[2],lf[129]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k6093 in k6086 in k6077 in k6071 in k6065 in k6045 in k6039 in k6036 in g904 in loop897 in k6005 in k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_ccall f_6095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6098,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 482  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),t2,((C_word*)t0)[2],t3);}

/* k6096 in k6093 in k6086 in k6077 in k6071 in k6065 in k6045 in k6039 in k6036 in g904 in loop897 in k6005 in k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_ccall f_6098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6101,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6116,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 485  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t4,t5);}

/* k6114 in k6096 in k6093 in k6086 in k6077 in k6071 in k6065 in k6045 in k6039 in k6036 in g904 in loop897 in k6005 in k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_ccall f_6116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6116,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 483  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6099 in k6096 in k6093 in k6086 in k6077 in k6071 in k6065 in k6045 in k6039 in k6036 in g904 in loop897 in k6005 in k5998 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_ccall f_6101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 486  touch */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_5969(((C_word*)((C_word*)t0)[2])[1]));}

/* k5981 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_ccall f_5983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5986,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 489  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t2,lf[31],lf[125],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)((C_word*)t0)[3])[1]);}}

/* k5984 in k5981 in k5978 in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_ccall f_5986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* test in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static void C_fcall f_5973(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5973,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 446  get */
((C_proc5)C_retrieve_symbol_proc(lf[40]))(5,*((C_word*)lf[40]+1),t1,((C_word*)t0)[2],t2,t3);}

/* touch in ##compiler#perform-pre-optimization! in k4100 in k3732 in k3729 */
static C_word C_fcall f_5969(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(C_SCHEME_TRUE);}

/* ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[72],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4105,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4108,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t31=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4114,tmp=(C_word)a,a+=2,tmp));
t32=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4144,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t33=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4148,a[2]=t3,a[3]=t23,a[4]=t21,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t34=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4279,a[2]=t27,a[3]=t19,a[4]=t25,a[5]=t21,a[6]=t7,a[7]=t23,a[8]=t15,tmp=(C_word)a,a+=9,tmp));
t35=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4560,a[2]=t11,a[3]=t3,a[4]=t29,a[5]=t25,a[6]=t5,a[7]=t9,a[8]=t17,a[9]=t21,tmp=(C_word)a,a+=10,tmp));
t36=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5818,a[2]=t25,tmp=(C_word)a,a+=3,tmp));
t37=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5848,a[2]=t25,a[3]=t13,a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t15,a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 414  perform-pre-optimization! */
((C_proc4)C_retrieve_symbol_proc(lf[124]))(4,*((C_word*)lf[124]+1),t37,t2,t3);}

/* k5846 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5848,2,t0,t1);}
if(C_truep(t1)){
/* optimizer.scm: 415  values */
C_values(4,0,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5854,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 417  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,lf[35],lf[123]);}}

/* k5852 in k5846 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5854,2,t0,t1);}
t2=C_set_block_item(lf[38] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5858,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 419  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4279(t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5856 in k5852 in k5846 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5861,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* optimizer.scm: 420  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t2,lf[31],lf[122],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_5861(2,t3,C_SCHEME_UNDEFINED);}}

/* k5859 in k5856 in k5852 in k5846 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5897,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(C_retrieve(lf[38])))){
/* optimizer.scm: 421  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t3,lf[31],lf[121]);}
else{
t4=t3;
f_5897(2,t4,C_SCHEME_FALSE);}}

/* k5895 in k5859 in k5856 in k5852 in k5846 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5897,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5902,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5902(t5,((C_word*)t0)[2],C_retrieve(lf[38]));}
else{
t2=((C_word*)t0)[2];
f_5864(2,t2,C_SCHEME_UNDEFINED);}}

/* loop848 in k5895 in k5859 in k5856 in k5852 in k5846 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_5902(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5902,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5941,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5914,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_car(t4);
/* optimizer.scm: 424  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[120]+1)))(4,*((C_word*)lf[120]+1),t5,C_make_character(9),t6);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5912 in loop848 in k5895 in k5859 in k5856 in k5852 in k5846 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[3]);
if(C_truep(C_fixnum_greaterp(t2,C_fix(1)))){
t3=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 426  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[118]+1)))(4,*((C_word*)lf[118]+1),((C_word*)t0)[2],C_make_character(9),t3);}
else{
/* optimizer.scm: 427  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[119]+1)))(2,*((C_word*)lf[119]+1),((C_word*)t0)[2]);}}

/* k5939 in loop848 in k5895 in k5859 in k5856 in k5852 in k5846 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5902(t3,((C_word*)t0)[2],t2);}

/* k5862 in k5859 in k5856 in k5852 in k5846 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 429  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t2,lf[31],lf[117],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5867(2,t4,C_SCHEME_UNDEFINED);}}

/* k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5870,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 430  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t2,lf[31],lf[116],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5870(2,t4,C_SCHEME_UNDEFINED);}}

/* k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5873,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 431  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t2,lf[31],lf[115],((C_word*)((C_word*)t0)[2])[1]);}
else{
/* optimizer.scm: 432  values */
C_values(4,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);}}

/* k5871 in k5868 in k5865 in k5862 in k5859 in k5856 in k5852 in k5846 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 432  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* walk-generic in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_5818(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5818,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5822,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5838,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t9=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t5);}

/* a5837 in walk-generic in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5838(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5838,3,t0,t1,t2);}
/* g832833 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4279(t3,t1,t2,((C_word*)t0)[2]);}

/* k5820 in walk-generic in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5828,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 410  every */
((C_proc5)C_retrieve_symbol_proc(lf[55]))(5,*((C_word*)lf[55]+1),t2,*((C_word*)lf[34]+1),((C_word*)t0)[2],t1);}

/* k5826 in k5820 in walk-generic in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5828,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
t6=t2;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record(&a,4,lf[10],t3,t4,t5));}}

/* walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_4560(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4560,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t2;
t9=C_slot(t8,C_fix(1));
t10=C_eqp(t9,lf[2]);
if(C_truep(t10)){
t11=C_i_car(t7);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4600,a[2]=((C_word*)t0)[7],a[3]=t7,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t13,tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_4600(t15,t1,t11);}
else{
t11=C_eqp(t9,lf[5]);
if(C_truep(t11)){
t12=C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4681,a[2]=t12,a[3]=((C_word*)t0)[8],a[4]=t7,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 226  test */
t14=((C_word*)((C_word*)t0)[8])[1];
f_4108(t14,t13,t12,lf[67]);}
else{
t12=C_eqp(t9,lf[21]);
if(C_truep(t12)){
t13=C_i_caddr(t7);
t14=C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4747,a[2]=t9,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t13,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=t14,a[10]=t5,a[11]=t7,a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
/* optimizer.scm: 236  test */
t16=((C_word*)((C_word*)t0)[8])[1];
f_4108(t16,t15,t14,lf[76]);}
else{
t13=C_eqp(t9,lf[8]);
if(C_truep(t13)){
t14=C_i_car(t5);
t15=C_slot(t14,C_fix(1));
t16=C_eqp(t15,lf[2]);
if(C_truep(t16)){
t17=C_slot(t14,C_fix(2));
t18=C_i_car(t17);
t19=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4942,a[2]=((C_word*)t0)[2],a[3]=t14,a[4]=((C_word*)t0)[8],a[5]=t7,a[6]=t9,a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=t18,a[10]=((C_word*)t0)[3],a[11]=t3,a[12]=t1,a[13]=((C_word*)t0)[5],a[14]=((C_word*)t0)[9],a[15]=t5,tmp=(C_word)a,a+=16,tmp);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5640,a[2]=t18,a[3]=((C_word*)t0)[8],a[4]=t19,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 274  test */
t21=((C_word*)((C_word*)t0)[8])[1];
f_4108(t21,t20,t18,lf[89]);}
else{
t17=C_eqp(t15,lf[21]);
if(C_truep(t17)){
if(C_truep(C_i_car(t7))){
/* optimizer.scm: 387  walk-generic */
t18=((C_word*)((C_word*)t0)[4])[1];
f_5818(t18,t1,t2,t9,t7,t5,t3);}
else{
t18=C_i_cdr(t7);
t19=C_a_i_cons(&a,2,C_SCHEME_TRUE,t18);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5680,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5682,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t22=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t20,t21,t5);}}
else{
/* optimizer.scm: 389  walk-generic */
t18=((C_word*)((C_word*)t0)[4])[1];
f_5818(t18,t1,t2,t9,t7,t5,t3);}}}
else{
t14=C_eqp(t9,lf[9]);
if(C_truep(t14)){
t15=C_i_car(t7);
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5708,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t7,a[8]=t15,a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 393  test */
t17=((C_word*)((C_word*)t0)[8])[1];
f_4108(t17,t16,t15,lf[66]);}
else{
/* optimizer.scm: 406  walk-generic */
t15=((C_word*)((C_word*)t0)[4])[1];
f_5818(t15,t1,t2,t9,t7,t5,t3);}}}}}}

/* k5706 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t1)){
t3=t2;
f_5711(2,t3,t1);}
else{
/* optimizer.scm: 393  test */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4108(t3,t2,((C_word*)t0)[8],lf[63]);}}

/* k5709 in k5706 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5711,2,t0,t1);}
if(C_truep(t1)){
t2=f_4144(((C_word*)((C_word*)t0)[10])[1]);
t3=((C_word*)t0)[9];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[11],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5728,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5810,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 396  test */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4108(t4,t3,((C_word*)t0)[8],lf[114]);}}

/* k5808 in k5709 in k5706 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5810,2,t0,t1);}
t2=C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_5768(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5806,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 397  variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[113]))(3,*((C_word*)lf[113]+1),t4,((C_word*)t0)[2]);}}

/* k5804 in k5808 in k5709 in k5706 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5768(t2,C_i_not(t1));}

/* k5766 in k5808 in k5709 in k5706 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_5768(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5768,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 398  test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4108(t3,t2,((C_word*)t0)[2],lf[112]);}
else{
t2=((C_word*)t0)[6];
f_5728(t2,C_SCHEME_FALSE);}}

/* k5797 in k5766 in k5808 in k5709 in k5706 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5799,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_5728(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5795,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 399  test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4108(t3,t2,((C_word*)t0)[2],lf[88]);}}

/* k5793 in k5797 in k5766 in k5808 in k5709 in k5706 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5795,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5728(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5787,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 400  expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t2,t3,((C_word*)t0)[2]);}}

/* k5785 in k5793 in k5797 in k5766 in k5808 in k5709 in k5706 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5728(t2,C_i_not(t1));}

/* k5726 in k5709 in k5706 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_5728(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5728,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_4144(((C_word*)((C_word*)t0)[8])[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5734,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 402  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t3,lf[31],lf[111],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5758,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 404  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4279(t4,t2,t3,((C_word*)t0)[2]);}}

/* k5756 in k5726 in k5709 in k5706 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5758,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[9],((C_word*)t0)[2],t2));}

/* k5732 in k5726 in k5709 in k5706 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5734,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[11],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* a5681 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5682(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5682,3,t0,t1,t2);}
/* g764765 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4279(t3,t1,t2,((C_word*)t0)[2]);}

/* k5678 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5680,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[2],t1));}

/* k5638 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5640,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4942(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 275  test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4108(t3,t2,((C_word*)t0)[2],lf[59]);}}

/* k5628 in k5638 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[4];
f_4942(2,t3,t2);}
else{
/* optimizer.scm: 276  test */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4108(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[110]);}}

/* k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4942,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=t1,tmp=(C_word)a,a+=18,tmp);
/* optimizer.scm: 278  test */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4108(t4,t3,((C_word*)t0)[9],lf[66]);}

/* k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4951,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[17];
t3=C_slot(t2,C_fix(2));
t4=C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4965,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t4,a[6]=((C_word*)t0)[17],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 281  check-signature */
((C_proc5)C_retrieve_symbol_proc(lf[81]))(5,*((C_word*)lf[81]+1),t5,((C_word*)t0)[10],((C_word*)t0)[12],t4);}
else{
if(C_truep(C_i_memq(((C_word*)t0)[10],C_retrieve(lf[82])))){
t2=C_i_car(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5012,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=C_slot(t2,C_fix(1));
t5=C_eqp(lf[2],t4);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(2));
t7=C_i_car(t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5033,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5158,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 292  test */
t10=((C_word*)((C_word*)t0)[4])[1];
f_4108(t10,t9,t7,lf[89]);}
else{
t8=t3;
f_5012(t8,C_SCHEME_FALSE);}}
else{
t6=t3;
f_5012(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_5012(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5182,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[17])){
t3=((C_word*)t0)[17];
t4=C_slot(t3,C_fix(1));
t5=t2;
f_5182(t5,C_eqp(lf[21],t4));}
else{
t3=t2;
f_5182(t3,C_SCHEME_FALSE);}}}}

/* k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_5182(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5182,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[17];
t3=C_slot(t2,C_fix(2));
t4=C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5198,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t4,a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=t3,tmp=(C_word)a,a+=19,tmp);
/* optimizer.scm: 308  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),((C_word*)t0)[2],t4,t5);}
else{
/* optimizer.scm: 384  walk-generic */
t2=((C_word*)((C_word*)t0)[10])[1];
f_5818(t2,((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[14]);}}

/* a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[30],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5198,5,t0,t1,t2,t3,t4);}
t5=C_i_car(((C_word*)t0)[18]);
t6=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5208,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=t5,a[13]=((C_word*)t0)[18],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],a[18]=((C_word*)t0)[14],a[19]=((C_word*)t0)[15],a[20]=t1,a[21]=((C_word*)t0)[16],a[22]=((C_word*)t0)[17],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_retrieve(lf[104]))){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5572,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[18],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 313  test */
t8=((C_word*)((C_word*)t0)[3])[1];
f_4108(t8,t7,((C_word*)t0)[10],lf[109]);}
else{
t7=t6;
f_5208(t7,C_SCHEME_FALSE);}}

/* k5570 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5572,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5609,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 314  test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4108(t3,t2,((C_word*)t0)[2],lf[79]);}
else{
t2=((C_word*)t0)[6];
f_5208(t2,C_SCHEME_FALSE);}}

/* k5607 in k5570 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5609,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5208(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5586,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t2,((C_word*)t0)[2],lf[108]);}}

/* k5584 in k5607 in k5570 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_eqp(t1,lf[105]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_5208(t3,C_SCHEME_TRUE);}
else{
t3=C_eqp(t1,lf[106]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_5208(t4,C_SCHEME_FALSE);}
else{
t4=C_i_cadddr(((C_word*)t0)[2]);
t5=C_retrieve(lf[107]);
t6=((C_word*)t0)[3];
f_5208(t6,C_fixnum_lessp(t4,t5));}}}

/* k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_5208(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5208,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5211,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[18],a[7]=((C_word*)t0)[19],a[8]=((C_word*)t0)[20],a[9]=((C_word*)t0)[21],a[10]=((C_word*)t0)[22],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5274,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[14],a[4]=t2,a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t3,((C_word*)t0)[14],lf[94]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5280,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[21],a[11]=((C_word*)t0)[22],a[12]=((C_word*)t0)[19],a[13]=((C_word*)t0)[6],a[14]=((C_word*)t0)[7],a[15]=((C_word*)t0)[8],a[16]=((C_word*)t0)[9],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[10],a[19]=((C_word*)t0)[11],a[20]=((C_word*)t0)[16],tmp=(C_word)a,a+=21,tmp);
/* optimizer.scm: 333  test */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4108(t3,t2,((C_word*)t0)[12],lf[76]);}}

/* k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5280,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_length(((C_word*)t0)[20]);
t3=((C_word*)t0)[19];
if(C_truep(C_fixnum_lessp(t2,t3))){
/* optimizer.scm: 335  walk-generic */
t4=((C_word*)((C_word*)t0)[18])[1];
f_5818(t4,((C_word*)t0)[17],((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5294,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t5,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_5294(t7,((C_word*)t0)[17],((C_word*)t0)[5],((C_word*)t0)[19],((C_word*)t0)[20],C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5458,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[18],a[14]=((C_word*)t0)[20],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5559,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[16],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 359  test */
t4=((C_word*)((C_word*)t0)[6])[1];
f_4108(t4,t3,((C_word*)t0)[2],lf[72]);}}

/* k5557 in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_memq(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[2];
f_5458(t3,C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_5458(t2,C_SCHEME_FALSE);}}

/* k5456 in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_5458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5458,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5461,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm: 361  llist-length */
((C_proc3)C_retrieve_symbol_proc(lf[103]))(3,*((C_word*)lf[103]+1),t2,((C_word*)t0)[3]);}
else{
/* optimizer.scm: 383  walk-generic */
t2=((C_word*)((C_word*)t0)[13])[1];
f_5818(t2,((C_word*)t0)[12],((C_word*)t0)[2],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* k5459 in k5456 in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5461,2,t0,t1);}
t2=C_i_length(((C_word*)t0)[12]);
t3=t1;
if(C_truep(C_fixnum_lessp(t2,t3))){
/* optimizer.scm: 363  walk-generic */
t4=((C_word*)((C_word*)t0)[11])[1];
f_5818(t4,((C_word*)t0)[10],t1,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5473,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 365  debugging */
((C_proc6)C_retrieve_symbol_proc(lf[30]))(6,*((C_word*)lf[30]+1),t4,lf[31],lf[102],((C_word*)t0)[2],t1);}}

/* k5471 in k5459 in k5456 in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5478,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5483 in k5471 in k5459 in k5456 in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[32],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5484,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5501,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5503,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5515,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5523,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* optimizer.scm: 376  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t7,C_SCHEME_END_OF_LIST);}
else{
t8=C_i_length(t3);
t9=C_fixnum_times(C_fix(3),t8);
t10=C_a_i_list(&a,2,lf[100],t9);
t11=t3;
t12=C_a_i_record(&a,4,lf[10],lf[101],t10,t11);
t13=C_a_i_list(&a,1,t12);
/* optimizer.scm: 372  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t6,t2,t13);}}

/* k5521 in a5483 in k5471 in k5459 in k5456 in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5523,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* optimizer.scm: 372  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5513 in a5483 in k5471 in k5459 in k5456 in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5515,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a5502 in a5483 in k5471 in k5459 in k5456 in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5503(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5503,3,t0,t1,t2);}
/* g731732 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4279(t3,t1,t2,((C_word*)t0)[2]);}

/* k5499 in a5483 in k5471 in k5459 in k5456 in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5501,2,t0,t1);}
t2=C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a5477 in k5471 in k5459 in k5456 in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5478,2,t0,t1);}
/* optimizer.scm: 366  split-at */
((C_proc4)C_retrieve_symbol_proc(lf[99]))(4,*((C_word*)lf[99]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_5294(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5294,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_nullp(t2);
t7=(C_truep(t6)?t6:C_eqp(t3,C_fix(0)));
if(C_truep(t7)){
t8=f_4144(((C_word*)((C_word*)t0)[10])[1]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5319,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5321,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5333,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 342  append-reverse */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t11,t5,t4);}
else{
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5339,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t5,a[7]=((C_word*)t0)[5],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=t1,a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t9=C_i_car(t2);
/* optimizer.scm: 343  test */
t10=((C_word*)((C_word*)t0)[2])[1];
f_4108(t10,t8,t9,lf[68]);}}

/* k5337 in loop in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5339,2,t0,t1);}
if(C_truep(t1)){
t2=f_4144(((C_word*)((C_word*)t0)[12])[1]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5345,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=C_i_car(((C_word*)t0)[10]);
/* optimizer.scm: 345  debugging */
((C_proc6)C_retrieve_symbol_proc(lf[30]))(6,*((C_word*)lf[30]+1),t3,lf[31],lf[98],t4,((C_word*)t0)[2]);}
else{
t2=C_i_cdr(((C_word*)t0)[10]);
t3=C_fixnum_decrease(((C_word*)t0)[9]);
t4=C_i_cdr(((C_word*)t0)[8]);
t5=C_i_car(((C_word*)t0)[8]);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[6]);
/* optimizer.scm: 355  loop */
t7=((C_word*)((C_word*)t0)[7])[1];
f_5294(t7,((C_word*)t0)[11],t2,t3,t4,t6);}}

/* k5343 in k5337 in loop in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5351,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=C_i_car(((C_word*)t0)[7]);
/* optimizer.scm: 348  expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t2,t3,((C_word*)t0)[2]);}

/* k5349 in k5343 in k5337 in loop in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5351,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 351  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[96]))(3,*((C_word*)lf[96]+1),t2,lf[97]);}
else{
t2=C_i_cdr(((C_word*)t0)[8]);
t3=C_fixnum_decrease(((C_word*)t0)[7]);
t4=C_i_cdr(((C_word*)t0)[6]);
/* optimizer.scm: 354  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_5294(t5,((C_word*)t0)[9],t2,t3,t4,((C_word*)t0)[4]);}}

/* k5393 in k5349 in k5343 in k5337 in loop in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5395,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5371,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=C_i_car(((C_word*)t0)[6]);
/* optimizer.scm: 352  walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4279(t5,t3,t4,((C_word*)t0)[2]);}

/* k5369 in k5393 in k5349 in k5343 in k5337 in loop in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5375,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=C_i_cdr(((C_word*)t0)[6]);
t4=C_fixnum_decrease(((C_word*)t0)[5]);
t5=C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 353  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_5294(t6,t2,t3,t4,t5,((C_word*)t0)[2]);}

/* k5373 in k5369 in k5393 in k5349 in k5343 in k5337 in loop in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5375,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[5],((C_word*)t0)[2],t2));}

/* k5331 in loop in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5333,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a5320 in loop in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5321(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5321,3,t0,t1,t2);}
/* g682683 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4279(t3,t1,t2,((C_word*)t0)[2]);}

/* k5317 in loop in k5278 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5319,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[2],t1));}

/* k5272 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_structurep(t1,lf[10]);
t3=(C_truep(t2)?lf[91]:lf[92]);
t4=C_i_cadddr(((C_word*)t0)[5]);
/* optimizer.scm: 320  debugging */
((C_proc7)C_retrieve_symbol_proc(lf[30]))(7,*((C_word*)lf[30]+1),((C_word*)t0)[4],lf[93],t3,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k5209 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5245,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[7]);}

/* a5244 in k5209 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5245(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5245,3,t0,t1,t2);}
t3=C_retrieve(lf[78]);
/* g632633 */
t4=t3;
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t2,lf[79],C_SCHEME_TRUE);}

/* k5212 in k5209 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 327  check-signature */
((C_proc5)C_retrieve_symbol_proc(lf[81]))(5,*((C_word*)lf[81]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k5215 in k5212 in k5209 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5220,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 328  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t2,lf[31],lf[90],((C_word*)t0)[2]);}

/* k5218 in k5215 in k5212 in k5209 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5220,2,t0,t1);}
t2=f_4144(((C_word*)((C_word*)t0)[9])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5230,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[5];
t5=C_slot(t4,C_fix(3));
t6=C_i_car(t5);
/* optimizer.scm: 331  inline-lambda-bindings */
((C_proc7)C_retrieve_symbol_proc(lf[77]))(7,*((C_word*)lf[77]+1),t3,((C_word*)t0)[4],((C_word*)t0)[3],t6,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* k5228 in k5218 in k5215 in k5212 in k5209 in k5206 in a5197 in k5180 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 330  walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4279(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5156 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5033(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 292  test */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4108(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[59]);}}

/* k5031 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5033,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=C_slot(t2,C_fix(1));
t4=C_eqp(lf[21],t3);
if(C_truep(t4)){
t5=t1;
t6=C_slot(t5,C_fix(2));
t7=C_i_caddr(t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5054,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t9=C_i_car(t7);
/* optimizer.scm: 295  test */
t10=((C_word*)((C_word*)t0)[2])[1];
f_4108(t10,t8,t9,lf[68]);}
else{
t8=((C_word*)t0)[7];
f_5012(t8,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[7];
f_5012(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
f_5012(t2,C_SCHEME_FALSE);}}

/* k5052 in k5031 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5057,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_5057(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 296  test */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4108(t5,t3,t4,lf[88]);}}

/* k5120 in k5052 in k5031 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5122,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5057(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5114,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 297  test */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4108(t4,t2,t3,lf[87]);}}

/* k5112 in k5120 in k5052 in k5031 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5057(t2,C_i_not(t1));}

/* k5055 in k5052 in k5031 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_5057(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5057,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5091,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5093,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 298  any */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t2,t3,t4);}
else{
t2=((C_word*)t0)[6];
f_5012(t2,C_SCHEME_FALSE);}}

/* a5092 in k5055 in k5052 in k5031 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5093,3,t0,t1,t2);}
t3=C_retrieve(lf[86]);
/* g563564 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,((C_word*)t0)[2]);}

/* k5089 in k5055 in k5052 in k5031 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5091,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5012(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5066,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 299  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t2,lf[84],lf[85],((C_word*)t0)[2]);}}

/* k5064 in k5089 in k5055 in k5052 in k5031 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_5066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5066,2,t0,t1);}
t2=C_a_i_record(&a,4,lf[10],lf[11],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_5012(t4,C_a_i_record(&a,4,lf[10],lf[8],lf[83],t3));}

/* k5010 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_5012(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* optimizer.scm: 303  walk-generic */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5818(t2,((C_word*)t0)[8],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4963 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4968,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 282  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t2,lf[31],lf[80],((C_word*)t0)[2]);}

/* k4966 in k4963 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4968,2,t0,t1);}
t2=f_4144(((C_word*)((C_word*)t0)[9])[1]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4996,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[6]);}

/* a4995 in k4966 in k4963 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4996,3,t0,t1,t2);}
t3=C_retrieve(lf[78]);
/* g514515 */
t4=t3;
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],t2,lf[79],C_SCHEME_TRUE);}

/* k4972 in k4966 in k4963 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4981,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[5];
t4=C_slot(t3,C_fix(3));
t5=C_i_car(t4);
/* optimizer.scm: 286  inline-lambda-bindings */
((C_proc7)C_retrieve_symbol_proc(lf[77]))(7,*((C_word*)lf[77]+1),t2,((C_word*)t0)[4],((C_word*)t0)[3],t5,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4979 in k4972 in k4966 in k4963 in k4949 in k4940 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 285  walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4279(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4745 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4747,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4752,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 237  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm: 252  test */
t3=((C_word*)((C_word*)t0)[13])[1];
f_4108(t3,t2,((C_word*)t0)[9],lf[72]);}}

/* k4844 in k4745 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4846,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4851,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 253  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
/* optimizer.scm: 265  walk-generic */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5818(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[11],((C_word*)t0)[10],t2);}}

/* a4850 in k4844 in k4745 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4851(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4851,5,t0,t1,t2,t3,t4);}
t5=f_4144(((C_word*)((C_word*)t0)[7])[1]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4858,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 257  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t6,lf[31],lf[75],t4);}

/* k4856 in a4850 in k4844 in k4745 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4858,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[9]);
t3=C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4898,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t3,a[8]=t2,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=C_fixnum_increase(((C_word*)t0)[3]);
/* optimizer.scm: 262  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[70]))(5,*((C_word*)lf[70]+1),t4,((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k4896 in k4856 in a4850 in k4844 in k4745 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4898,2,t0,t1);}
t2=C_i_cadddr(((C_word*)t0)[9]);
t3=C_a_i_list(&a,4,((C_word*)t0)[8],((C_word*)t0)[7],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4878,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(((C_word*)t0)[5]);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* optimizer.scm: 264  walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_4279(t7,t4,t5,t6);}

/* k4876 in k4896 in k4856 in a4850 in k4844 in k4745 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4878,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[21],((C_word*)t0)[2],t2));}

/* a4751 in k4745 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4752,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4758,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4770,a[2]=((C_word*)t0)[8],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4769 in a4751 in k4745 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4770,4,t0,t1,t2,t3);}
t4=f_4144(((C_word*)((C_word*)t0)[10])[1]);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 242  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t5,lf[31],lf[73],t2);}

/* k4775 in a4769 in a4751 in k4745 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4777,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[11]);
t3=C_i_cadr(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4817,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t3,a[8]=t2,a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4824,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* optimizer.scm: 246  test */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4108(t6,t5,((C_word*)t0)[8],lf[72]);}
else{
t6=t5;
f_4824(2,t6,C_SCHEME_FALSE);}}

/* k4822 in k4775 in a4769 in a4751 in k4745 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4824,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4827,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 247  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t2,lf[31],lf[71],((C_word*)t0)[2]);}
else{
/* optimizer.scm: 249  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[70]))(5,*((C_word*)lf[70]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k4825 in k4822 in k4775 in a4769 in a4751 in k4745 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_increase(((C_word*)t0)[4]);
/* optimizer.scm: 248  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[70]))(5,*((C_word*)lf[70]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k4815 in k4775 in a4769 in a4751 in k4745 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4817,2,t0,t1);}
t2=C_i_cadddr(((C_word*)t0)[9]);
t3=C_a_i_list(&a,4,((C_word*)t0)[8],((C_word*)t0)[7],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4797,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(((C_word*)t0)[5]);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* optimizer.scm: 251  walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_4279(t7,t4,t5,t6);}

/* k4795 in k4815 in k4775 in a4769 in a4751 in k4745 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4797,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[21],((C_word*)t0)[2],t2));}

/* a4757 in a4751 in k4745 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4764,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 240  partition */
((C_proc4)C_retrieve_symbol_proc(lf[69]))(4,*((C_word*)lf[69]+1),t1,t2,((C_word*)t0)[2]);}

/* a4763 in a4757 in a4751 in k4745 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4764(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4764,3,t0,t1,t2);}
/* optimizer.scm: 240  test */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4108(t3,t1,t2,lf[68]);}

/* k4679 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4684,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=t2;
f_4684(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 227  test */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4108(t4,t3,((C_word*)t0)[2],lf[66]);}}

/* k4720 in k4679 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4722,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4729,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 227  test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4108(t3,t2,((C_word*)t0)[2],lf[65]);}
else{
t2=((C_word*)t0)[4];
f_4684(t2,C_SCHEME_FALSE);}}

/* k4727 in k4720 in k4679 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4684(t2,C_i_not(t1));}

/* k4682 in k4679 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_4684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4684,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_4144(((C_word*)((C_word*)t0)[8])[1]);
t3=C_fixnum_increase(((C_word*)((C_word*)t0)[7])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t3);
t5=C_i_cadr(((C_word*)t0)[6]);
/* optimizer.scm: 230  walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_4279(t6,((C_word*)t0)[4],t5,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[6]);}}

/* a4711 in k4682 in k4679 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4712,3,t0,t1,t2);}
/* g420421 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4279(t3,t1,t2,((C_word*)t0)[2]);}

/* k4708 in k4682 in k4679 in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4710,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[5],((C_word*)t0)[2],t1));}

/* replace in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_4600(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4600,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 212  test */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4108(t4,t3,t2,lf[63]);}

/* k4602 in replace in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4604,2,t0,t1);}
if(C_truep(t1)){
/* replace362 */
t2=((C_word*)((C_word*)t0)[8])[1];
f_4600(t2,((C_word*)t0)[7],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 213  test */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4108(t3,t2,((C_word*)t0)[4],lf[62]);}}

/* k4614 in k4602 in replace in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4616,2,t0,t1);}
if(C_truep(t1)){
t2=f_4144(((C_word*)((C_word*)t0)[7])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4622,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 215  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t3,lf[31],lf[60],((C_word*)t0)[4]);}
else{
t2=C_i_car(((C_word*)t0)[3]);
t3=C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t3)){
/* optimizer.scm: 222  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t4=f_4144(((C_word*)((C_word*)t0)[7])[1]);
t5=C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
/* optimizer.scm: 222  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),((C_word*)t0)[6],((C_word*)t0)[4]);}}}

/* k4620 in k4614 in k4602 in replace in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4642,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 216  test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4108(t3,t2,((C_word*)t0)[2],lf[59]);}

/* k4640 in k4620 in k4614 in k4602 in replace in walk1 in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(t1,C_fix(2));
t3=C_i_car(t2);
/* optimizer.scm: 216  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),((C_word*)t0)[2],t3);}

/* walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_4279(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4279,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_memq(t2,C_retrieve(lf[47])))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)((C_word*)t0)[8])[1];
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4293,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 165  walk1 */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4560(t6,t5,t2,t3);}}

/* k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4293,2,t0,t1);}
t2=t1;
t3=C_slot(t2,C_fix(3));
t4=t1;
t5=C_slot(t4,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4312,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t7=C_eqp(t5,lf[4]);
if(C_truep(t7)){
t8=C_i_car(t3);
t9=C_slot(t8,C_fix(1));
t10=C_eqp(lf[41],t9);
if(C_truep(t10)){
t11=C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t12=C_mutate(((C_word *)((C_word*)t0)[8])+1,t11);
t13=f_4144(((C_word*)((C_word*)t0)[7])[1]);
t14=C_i_car(t3);
t15=C_slot(t14,C_fix(2));
t16=C_i_car(t15);
t17=(C_truep(t16)?C_i_cadr(t3):C_i_caddr(t3));
/* optimizer.scm: 173  walk */
t18=((C_word*)((C_word*)t0)[6])[1];
f_4279(t18,t6,t17,((C_word*)t0)[5]);}
else{
t11=t1;
/* optimizer.scm: 163  simplify */
t12=((C_word*)((C_word*)t0)[10])[1];
f_4148(t12,((C_word*)t0)[9],t11);}}
else{
t8=C_eqp(t5,lf[8]);
if(C_truep(t8)){
t9=C_i_car(t3);
t10=C_slot(t9,C_fix(1));
t11=C_eqp(lf[2],t10);
if(C_truep(t11)){
t12=C_i_car(t3);
t13=C_slot(t12,C_fix(2));
t14=C_i_car(t13);
t15=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t3,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t1,a[9]=t6,a[10]=t14,tmp=(C_word)a,a+=11,tmp);
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4519,a[2]=t14,a[3]=((C_word*)t0)[2],a[4]=t15,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t16,t14,lf[58]);}
else{
t12=t1;
/* optimizer.scm: 163  simplify */
t13=((C_word*)((C_word*)t0)[10])[1];
f_4148(t13,((C_word*)t0)[9],t12);}}
else{
t9=t1;
/* optimizer.scm: 163  simplify */
t10=((C_word*)((C_word*)t0)[10])[1];
f_4148(t10,((C_word*)t0)[9],t9);}}}

/* k4517 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4519,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4525,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 183  foldable? */
((C_proc3)C_retrieve_symbol_proc(lf[56]))(3,*((C_word*)lf[56]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_4373(2,t2,C_SCHEME_FALSE);}}

/* k4523 in k4517 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 184  every */
((C_proc4)C_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}
else{
t2=((C_word*)t0)[3];
f_4373(2,t2,C_SCHEME_FALSE);}}

/* k4371 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4373,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4459,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t7=C_i_cddr(((C_word*)t0)[4]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4465,a[2]=t3,a[3]=t9,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_4465(t11,t6,t7);}
else{
t2=((C_word*)t0)[8];
/* optimizer.scm: 163  simplify */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4148(t3,((C_word*)t0)[2],t2);}}

/* loop297 in k4371 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_4465(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4465,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(2));
t5=C_i_car(t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[41],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t9=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t8);
t10=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t11=C_slot(t2,C_fix(1));
/* loop297310 */
t17=t1;
t18=t11;
t1=t17;
t2=t18;
goto loop;}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[2])+1,t8);
t10=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t11=C_slot(t2,C_fix(1));
/* loop297310 */
t17=t1;
t18=t11;
t1=t17;
t2=t18;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4457 in k4371 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4459,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4379,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4384,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[54]+1)))(3,*((C_word*)lf[54]+1),t3,t4);}

/* a4383 in k4457 in k4371 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4384(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4384,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4390,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4407,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[53]))(4,*((C_word*)lf[53]+1),t1,t3,t4);}

/* a4406 in a4383 in k4457 in k4371 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4413,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4445,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4444 in a4406 in a4383 in k4457 in k4371 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4445r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4445r(t0,t1,t2);}}

static void C_ccall f_4445r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4451,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k323328 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4450 in a4444 in a4406 in a4383 in k4457 in k4371 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4451,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4412 in a4406 in a4383 in k4457 in k4371 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4417,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 192  eval */
((C_proc3)C_retrieve_symbol_proc(lf[52]))(3,*((C_word*)lf[52]+1),t2,((C_word*)t0)[2]);}

/* k4415 in a4412 in a4406 in a4383 in k4457 in k4371 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4420,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 193  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t2,lf[31],lf[51],((C_word*)t0)[2]);}

/* k4418 in k4415 in a4412 in a4406 in a4383 in k4457 in k4371 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4420,2,t0,t1);}
t2=f_4144(((C_word*)((C_word*)t0)[5])[1]);
t3=C_i_cadr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4443,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 198  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t4,((C_word*)t0)[2]);}

/* k4441 in k4418 in k4415 in a4412 in a4406 in a4383 in k4457 in k4371 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4443,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],lf[49],t2));}

/* a4389 in a4383 in k4457 in k4371 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4390(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4390,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4396,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* k323328 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4395 in a4389 in a4383 in k4457 in k4371 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4400,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_4400(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t2;
f_4400(t4,t3);}}

/* k4398 in a4395 in a4389 in a4383 in k4457 in k4371 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_4400(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4400,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 190  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t2,*((C_word*)lf[34]+1),C_retrieve(lf[47]),((C_word*)t0)[2]);}

/* k4402 in k4398 in a4395 in a4389 in a4383 in k4457 in k4371 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[47]+1 /* (set! ##compiler#broken-constant-nodes ...) */,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k4377 in k4457 in k4371 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g326327 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k4310 in k4291 in walk in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 163  simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4148(t2,((C_word*)t0)[2],t1);}

/* simplify in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_4148(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4148,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=t2;
t5=C_slot(t4,C_fix(1));
/* optimizer.scm: 144  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[46]))(4,*((C_word*)lf[46]+1),t3,C_retrieve(lf[37]),t5);}

/* k4150 in simplify in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4155,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4163,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 145  any */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t2,t3,t1);}
else{
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a4162 in k4150 in simplify in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4163,3,t0,t1,t2);}
t3=C_i_cadr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4173,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=C_i_car(t2);
/* optimizer.scm: 147  match-node */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),t4,((C_word*)t0)[2],t5,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k4171 in a4162 in k4150 in simplify in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4173,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4179,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=C_i_caddr(((C_word*)t0)[4]);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4220,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4222,a[2]=t5,a[3]=t10,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_4222(t12,t8,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop228 in k4171 in a4162 in k4150 in simplify in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_4222(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4222,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4249,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_4249(t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop228241 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop228241 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g244 in loop228 in k4171 in a4162 in k4150 in simplify in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static C_word C_fcall f_4249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_i_assq(t1,((C_word*)t0)[2]);
return(C_i_cdr(t2));}

/* k4218 in k4171 in a4162 in k4150 in simplify in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4177 in k4171 in a4162 in k4150 in simplify in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4179,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4185,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 150  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4183 in k4177 in k4171 in a4162 in k4150 in simplify in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4185,2,t0,t1);}
t2=C_i_assq(t1,((C_word*)((C_word*)t0)[6])[1]);
if(C_truep(t2)){
t3=C_i_cdr(t2);
t4=C_fixnum_increase(t3);
t5=C_i_set_cdr(t2,t4);
t6=f_4144(((C_word*)((C_word*)t0)[5])[1]);
/* optimizer.scm: 156  simplify */
t7=((C_word*)((C_word*)t0)[4])[1];
f_4148(t7,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 154  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),t3,t1,C_fix(1),((C_word*)((C_word*)t0)[6])[1]);}}

/* k4210 in k4183 in k4177 in k4171 in a4162 in k4150 in simplify in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=f_4144(((C_word*)((C_word*)t0)[5])[1]);
/* optimizer.scm: 156  simplify */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4148(t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4153 in k4150 in simplify in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* touch in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static C_word C_fcall f_4144(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(t1);}

/* constant-node? in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4114,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_eqp(lf[41],t3));}

/* test in ##compiler#perform-high-level-optimizations in k4100 in k3732 in k3729 */
static void C_fcall f_4108(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4108,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 138  get */
((C_proc5)C_retrieve_symbol_proc(lf[40]))(5,*((C_word*)lf[40]+1),t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_3736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[49],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3736,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3739,a[2]=t6,a[3]=t8,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t22=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3762,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t23=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3769,a[2]=t10,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t24=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3774,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3808,a[2]=t12,a[3]=t14,a[4]=t20,a[5]=t18,a[6]=t16,a[7]=t4,a[8]=t6,a[9]=t10,tmp=(C_word)a,a+=10,tmp));
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4046,a[2]=t2,a[3]=t20,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 104  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t26,lf[35],lf[36]);}

/* k4044 in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_4046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4049,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 105  scan */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3808(t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4047 in k4044 in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4098,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 107  delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t3,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[34]+1));}
else{
t3=t2;
f_4052(2,t3,C_SCHEME_UNDEFINED);}}

/* k4096 in k4047 in k4044 in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_4098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 107  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),((C_word*)t0)[2],lf[31],lf[32],t1);}

/* k4050 in k4047 in k4044 in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_4052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4057,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a4056 in k4050 in k4047 in k4044 in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4057,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4063,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t1,t2,lf[26],C_SCHEME_TRUE);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=C_i_car(t3);
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t1,t2,lf[26],t6);}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[28],t3);}}}

/* k4061 in a4056 in k4050 in k4047 in k4044 in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[26],t1);}

/* scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_fcall f_3808(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3808,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(2));
t6=t2;
t7=C_slot(t6,C_fix(3));
t8=t2;
t9=C_slot(t8,C_fix(1));
t10=C_eqp(t9,lf[2]);
if(C_truep(t10)){
t11=C_i_car(t5);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3845,a[2]=t11,a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3862,a[2]=t12,a[3]=((C_word*)t0)[8],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_memq(t11,t3))){
t14=t13;
f_3862(t14,C_SCHEME_FALSE);}
else{
t14=C_i_memq(t11,((C_word*)((C_word*)t0)[7])[1]);
t15=t13;
f_3862(t15,C_i_not(t14));}}
else{
t11=C_eqp(t9,lf[4]);
t12=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3889,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t9,a[9]=((C_word*)t0)[4],a[10]=t3,a[11]=t1,a[12]=((C_word*)t0)[5],a[13]=t7,a[14]=((C_word*)t0)[6],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t11)){
t13=t12;
f_3889(t13,t11);}
else{
t13=C_eqp(t9,lf[23]);
t14=t12;
f_3889(t14,(C_truep(t13)?t13:C_eqp(t9,lf[24])));}}}

/* k3887 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_fcall f_3889(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3889,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3892,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[13]);
/* optimizer.scm: 75   scan */
t4=((C_word*)((C_word*)t0)[9])[1];
f_3808(t4,t2,t3,((C_word*)t0)[10]);}
else{
t2=C_eqp(((C_word*)t0)[8],lf[5]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t4=C_i_car(((C_word*)t0)[13]);
/* optimizer.scm: 80   scan */
t5=((C_word*)((C_word*)t0)[9])[1];
f_3808(t5,t3,t4,((C_word*)t0)[10]);}
else{
t3=C_eqp(((C_word*)t0)[8],lf[7]);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3939,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[11],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t3)){
t5=t4;
f_3939(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[8],lf[21]);
t6=t4;
f_3939(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[8],lf[22])));}}}}

/* k3937 in k3887 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_fcall f_3939(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3939,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[13],lf[8]);
if(C_truep(t2)){
/* optimizer.scm: 85   touch */
t3=((C_word*)t0)[14];
((C_proc2)C_retrieve_proc(t3))(2,t3,f_3769(((C_word*)((C_word*)t0)[12])[1]));}
else{
t3=C_eqp(((C_word*)t0)[13],lf[9]);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[11]);
t5=C_i_car(((C_word*)t0)[10]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3963,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t4,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 90   scan */
t7=((C_word*)((C_word*)t0)[3])[1];
f_3808(t7,t6,t5,((C_word*)t0)[7]);}
else{
/* optimizer.scm: 102  scan-each */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3774(t4,((C_word*)t0)[14],((C_word*)t0)[10],((C_word*)t0)[7]);}}}}

/* k3961 in k3937 in k3887 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_3963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3966,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 91   alist-ref */
((C_proc4)C_retrieve_symbol_proc(lf[20]))(4,*((C_word*)lf[20]+1),t2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[2])[1]);}

/* k3964 in k3961 in k3937 in k3887 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_3966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3984,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t4=C_i_memq(((C_word*)t0)[6],((C_word*)((C_word*)t0)[2])[1]);
t5=t3;
f_3984(t5,C_i_not(t4));}
else{
t4=t3;
f_3984(t4,C_SCHEME_FALSE);}}

/* k3982 in k3964 in k3961 in k3937 in k3887 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_fcall f_3984(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3984,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3987,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4003,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[19]))(2,*((C_word*)lf[19]+1),t3);}
else{
t2=((C_word*)t0)[4];
f_3969(2,t2,C_SCHEME_UNDEFINED);}}

/* k4001 in k3982 in k3964 in k3961 in k3937 in k3887 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_4003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4006,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,lf[18],t1);}

/* k4004 in k4001 in k3982 in k3964 in k3961 in k3937 in k3887 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_4006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4009,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[16]+1)))(4,*((C_word*)lf[16]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4007 in k4004 in k4001 in k3982 in k3964 in k3961 in k3937 in k3887 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[15]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k4010 in k4007 in k4004 in k4001 in k3982 in k3964 in k3961 in k3937 in k3887 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_4012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4015,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t2,((C_word*)t0)[2]);}

/* k4013 in k4010 in k4007 in k4004 in k4001 in k3982 in k3964 in k3961 in k3937 in k3887 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 93   ##sys#notice */
((C_proc3)C_retrieve_symbol_proc(lf[13]))(3,*((C_word*)lf[13]+1),((C_word*)t0)[2],t1);}

/* k3985 in k3982 in k3964 in k3961 in k3937 in k3887 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_3987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3987,2,t0,t1);}
t2=C_a_i_record(&a,4,lf[10],lf[11],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
/* optimizer.scm: 96   copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[12]))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k3967 in k3964 in k3961 in k3937 in k3887 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_memq(((C_word*)t0)[5],((C_word*)t0)[3]))){
/* optimizer.scm: 100  remember */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3762(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
/* optimizer.scm: 99   mark */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3739(t3,t2,((C_word*)t0)[5]);}}

/* k3970 in k3967 in k3964 in k3961 in k3937 in k3887 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 100  remember */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3762(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3913 in k3887 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3915,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3926,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 81   append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3924 in k3913 in k3887 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_3926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 81   scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3808(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3890 in k3887 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_3892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=f_3769(((C_word*)((C_word*)t0)[6])[1]);
t3=C_i_cdr(((C_word*)t0)[5]);
/* optimizer.scm: 77   scan-each */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3774(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k3860 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_fcall f_3862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3862,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_3845(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_3845(t2,C_SCHEME_UNDEFINED);}}

/* k3843 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_fcall f_3845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3845,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3849,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3851,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 72   remove */
((C_proc4)C_retrieve_symbol_proc(lf[3]))(4,*((C_word*)lf[3]+1),t2,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* a3850 in k3843 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_3851(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3851,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_eqp(t3,((C_word*)t0)[2]));}

/* k3847 in k3843 in scan in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* scan-each in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_fcall f_3774(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3774,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3780,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3780(t7,t1,t2);}

/* loop53 in scan-each in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_fcall f_3780(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3780,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3788,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3795,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g6061 */
t6=t3;
f_3788(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3793 in loop53 in scan-each in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_3795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3780(t3,((C_word*)t0)[2],t2);}

/* g60 in loop53 in scan-each in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_fcall f_3788(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3788,NULL,3,t0,t1,t2);}
/* optimizer.scm: 60   scan */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3808(t3,t1,t2,((C_word*)t0)[2]);}

/* touch in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static C_word C_fcall f_3769(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
return(t2);}

/* remember in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_fcall f_3762(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3762,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3767,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 53   alist-update! */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k3765 in remember in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* mark in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_fcall f_3739(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3739,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3746,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_3746(t5,C_SCHEME_FALSE);}
else{
t5=C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]);
t6=t3;
f_3746(t6,C_i_not(t5));}}

/* k3744 in mark in ##compiler#scan-toplevel-assignments in k3732 in k3729 */
static void C_fcall f_3746(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3746,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[679] = {
{"toplevel:optimizer_scm",(void*)C_optimizer_toplevel},
{"f_3731:optimizer_scm",(void*)f_3731},
{"f_3734:optimizer_scm",(void*)f_3734},
{"f_4102:optimizer_scm",(void*)f_4102},
{"f_14625:optimizer_scm",(void*)f_14625},
{"f_14633:optimizer_scm",(void*)f_14633},
{"f_14638:optimizer_scm",(void*)f_14638},
{"f_14688:optimizer_scm",(void*)f_14688},
{"f_14692:optimizer_scm",(void*)f_14692},
{"f_14648:optimizer_scm",(void*)f_14648},
{"f_14652:optimizer_scm",(void*)f_14652},
{"f_14674:optimizer_scm",(void*)f_14674},
{"f_6292:optimizer_scm",(void*)f_6292},
{"f_13534:optimizer_scm",(void*)f_13534},
{"f_13580:optimizer_scm",(void*)f_13580},
{"f_13682:optimizer_scm",(void*)f_13682},
{"f_13692:optimizer_scm",(void*)f_13692},
{"f_14029:optimizer_scm",(void*)f_14029},
{"f_14021:optimizer_scm",(void*)f_14021},
{"f_13798:optimizer_scm",(void*)f_13798},
{"f_13827:optimizer_scm",(void*)f_13827},
{"f_13997:optimizer_scm",(void*)f_13997},
{"f_13989:optimizer_scm",(void*)f_13989},
{"f_13858:optimizer_scm",(void*)f_13858},
{"f_13911:optimizer_scm",(void*)f_13911},
{"f_13901:optimizer_scm",(void*)f_13901},
{"f_13909:optimizer_scm",(void*)f_13909},
{"f_14083:optimizer_scm",(void*)f_14083},
{"f_14096:optimizer_scm",(void*)f_14096},
{"f_14138:optimizer_scm",(void*)f_14138},
{"f_14122:optimizer_scm",(void*)f_14122},
{"f_14126:optimizer_scm",(void*)f_14126},
{"f_14118:optimizer_scm",(void*)f_14118},
{"f_14304:optimizer_scm",(void*)f_14304},
{"f_14317:optimizer_scm",(void*)f_14317},
{"f_14323:optimizer_scm",(void*)f_14323},
{"f_14375:optimizer_scm",(void*)f_14375},
{"f_14367:optimizer_scm",(void*)f_14367},
{"f_14351:optimizer_scm",(void*)f_14351},
{"f_14355:optimizer_scm",(void*)f_14355},
{"f_14359:optimizer_scm",(void*)f_14359},
{"f_6295:optimizer_scm",(void*)f_6295},
{"f_13175:optimizer_scm",(void*)f_13175},
{"f_13197:optimizer_scm",(void*)f_13197},
{"f_13277:optimizer_scm",(void*)f_13277},
{"f_13235:optimizer_scm",(void*)f_13235},
{"f_13269:optimizer_scm",(void*)f_13269},
{"f_13273:optimizer_scm",(void*)f_13273},
{"f_13261:optimizer_scm",(void*)f_13261},
{"f_13233:optimizer_scm",(void*)f_13233},
{"f_13371:optimizer_scm",(void*)f_13371},
{"f_13391:optimizer_scm",(void*)f_13391},
{"f_6298:optimizer_scm",(void*)f_6298},
{"f_6787:optimizer_scm",(void*)f_6787},
{"f_10553:optimizer_scm",(void*)f_10553},
{"f_13048:optimizer_scm",(void*)f_13048},
{"f_13051:optimizer_scm",(void*)f_13051},
{"f_13054:optimizer_scm",(void*)f_13054},
{"f_13057:optimizer_scm",(void*)f_13057},
{"f_13060:optimizer_scm",(void*)f_13060},
{"f_13063:optimizer_scm",(void*)f_13063},
{"f_13146:optimizer_scm",(void*)f_13146},
{"f_13066:optimizer_scm",(void*)f_13066},
{"f_13069:optimizer_scm",(void*)f_13069},
{"f_13072:optimizer_scm",(void*)f_13072},
{"f_13140:optimizer_scm",(void*)f_13140},
{"f_13075:optimizer_scm",(void*)f_13075},
{"f_13078:optimizer_scm",(void*)f_13078},
{"f_13137:optimizer_scm",(void*)f_13137},
{"f_11327:optimizer_scm",(void*)f_11327},
{"f_11345:optimizer_scm",(void*)f_11345},
{"f_11351:optimizer_scm",(void*)f_11351},
{"f_11331:optimizer_scm",(void*)f_11331},
{"f_13081:optimizer_scm",(void*)f_13081},
{"f_13129:optimizer_scm",(void*)f_13129},
{"f_13127:optimizer_scm",(void*)f_13127},
{"f_13084:optimizer_scm",(void*)f_13084},
{"f_13087:optimizer_scm",(void*)f_13087},
{"f_13090:optimizer_scm",(void*)f_13090},
{"f_13114:optimizer_scm",(void*)f_13114},
{"f_13093:optimizer_scm",(void*)f_13093},
{"f_13096:optimizer_scm",(void*)f_13096},
{"f_13099:optimizer_scm",(void*)f_13099},
{"f_13102:optimizer_scm",(void*)f_13102},
{"f_13105:optimizer_scm",(void*)f_13105},
{"f_13108:optimizer_scm",(void*)f_13108},
{"f_12807:optimizer_scm",(void*)f_12807},
{"f_12813:optimizer_scm",(void*)f_12813},
{"f_13024:optimizer_scm",(void*)f_13024},
{"f_13034:optimizer_scm",(void*)f_13034},
{"f_12998:optimizer_scm",(void*)f_12998},
{"f_13008:optimizer_scm",(void*)f_13008},
{"f_12968:optimizer_scm",(void*)f_12968},
{"f_12977:optimizer_scm",(void*)f_12977},
{"f_12980:optimizer_scm",(void*)f_12980},
{"f_12938:optimizer_scm",(void*)f_12938},
{"f_12948:optimizer_scm",(void*)f_12948},
{"f_12847:optimizer_scm",(void*)f_12847},
{"f_12852:optimizer_scm",(void*)f_12852},
{"f_12890:optimizer_scm",(void*)f_12890},
{"f_12875:optimizer_scm",(void*)f_12875},
{"f_12886:optimizer_scm",(void*)f_12886},
{"f_12882:optimizer_scm",(void*)f_12882},
{"f_12609:optimizer_scm",(void*)f_12609},
{"f_12615:optimizer_scm",(void*)f_12615},
{"f_12784:optimizer_scm",(void*)f_12784},
{"f_12794:optimizer_scm",(void*)f_12794},
{"f_12724:optimizer_scm",(void*)f_12724},
{"f_12753:optimizer_scm",(void*)f_12753},
{"f_12714:optimizer_scm",(void*)f_12714},
{"f_12710:optimizer_scm",(void*)f_12710},
{"f_12652:optimizer_scm",(void*)f_12652},
{"f_12666:optimizer_scm",(void*)f_12666},
{"f_12676:optimizer_scm",(void*)f_12676},
{"f_12081:optimizer_scm",(void*)f_12081},
{"f_12095:optimizer_scm",(void*)f_12095},
{"f_12102:optimizer_scm",(void*)f_12102},
{"f_12105:optimizer_scm",(void*)f_12105},
{"f_12114:optimizer_scm",(void*)f_12114},
{"f_12266:optimizer_scm",(void*)f_12266},
{"f_12295:optimizer_scm",(void*)f_12295},
{"f_12121:optimizer_scm",(void*)f_12121},
{"f_12217:optimizer_scm",(void*)f_12217},
{"f_12250:optimizer_scm",(void*)f_12250},
{"f_12230:optimizer_scm",(void*)f_12230},
{"f_12124:optimizer_scm",(void*)f_12124},
{"f_12345:optimizer_scm",(void*)f_12345},
{"f_12586:optimizer_scm",(void*)f_12586},
{"f_12596:optimizer_scm",(void*)f_12596},
{"f_12527:optimizer_scm",(void*)f_12527},
{"f_12548:optimizer_scm",(void*)f_12548},
{"f_12546:optimizer_scm",(void*)f_12546},
{"f_12542:optimizer_scm",(void*)f_12542},
{"f_12474:optimizer_scm",(void*)f_12474},
{"f_12479:optimizer_scm",(void*)f_12479},
{"f_12489:optimizer_scm",(void*)f_12489},
{"f_12411:optimizer_scm",(void*)f_12411},
{"f_12409:optimizer_scm",(void*)f_12409},
{"f_12379:optimizer_scm",(void*)f_12379},
{"f_12384:optimizer_scm",(void*)f_12384},
{"f_12394:optimizer_scm",(void*)f_12394},
{"f_12330:optimizer_scm",(void*)f_12330},
{"f_12127:optimizer_scm",(void*)f_12127},
{"f_12202:optimizer_scm",(void*)f_12202},
{"f_12190:optimizer_scm",(void*)f_12190},
{"f_12186:optimizer_scm",(void*)f_12186},
{"f_12093:optimizer_scm",(void*)f_12093},
{"f_11672:optimizer_scm",(void*)f_11672},
{"f_12033:optimizer_scm",(void*)f_12033},
{"f_11798:optimizer_scm",(void*)f_11798},
{"f_12010:optimizer_scm",(void*)f_12010},
{"f_12020:optimizer_scm",(void*)f_12020},
{"f_11931:optimizer_scm",(void*)f_11931},
{"f_11936:optimizer_scm",(void*)f_11936},
{"f_12004:optimizer_scm",(void*)f_12004},
{"f_11963:optimizer_scm",(void*)f_11963},
{"f_12001:optimizer_scm",(void*)f_12001},
{"f_11681:optimizer_scm",(void*)f_11681},
{"f_11774:optimizer_scm",(void*)f_11774},
{"f_11784:optimizer_scm",(void*)f_11784},
{"f_11757:optimizer_scm",(void*)f_11757},
{"f_11762:optimizer_scm",(void*)f_11762},
{"f_11716:optimizer_scm",(void*)f_11716},
{"f_11721:optimizer_scm",(void*)f_11721},
{"f_11731:optimizer_scm",(void*)f_11731},
{"f_11679:optimizer_scm",(void*)f_11679},
{"f_11993:optimizer_scm",(void*)f_11993},
{"f_11979:optimizer_scm",(void*)f_11979},
{"f_11977:optimizer_scm",(void*)f_11977},
{"f_11800:optimizer_scm",(void*)f_11800},
{"f_11924:optimizer_scm",(void*)f_11924},
{"f_11922:optimizer_scm",(void*)f_11922},
{"f_11888:optimizer_scm",(void*)f_11888},
{"f_11907:optimizer_scm",(void*)f_11907},
{"f_11896:optimizer_scm",(void*)f_11896},
{"f_11820:optimizer_scm",(void*)f_11820},
{"f_11844:optimizer_scm",(void*)f_11844},
{"f_11871:optimizer_scm",(void*)f_11871},
{"f_11842:optimizer_scm",(void*)f_11842},
{"f_11838:optimizer_scm",(void*)f_11838},
{"f_11830:optimizer_scm",(void*)f_11830},
{"f_11361:optimizer_scm",(void*)f_11361},
{"f_11367:optimizer_scm",(void*)f_11367},
{"f_11401:optimizer_scm",(void*)f_11401},
{"f_11623:optimizer_scm",(void*)f_11623},
{"f_11638:optimizer_scm",(void*)f_11638},
{"f_11631:optimizer_scm",(void*)f_11631},
{"f_11520:optimizer_scm",(void*)f_11520},
{"f_11536:optimizer_scm",(void*)f_11536},
{"f_11589:optimizer_scm",(void*)f_11589},
{"f_11593:optimizer_scm",(void*)f_11593},
{"f_11556:optimizer_scm",(void*)f_11556},
{"f_11565:optimizer_scm",(void*)f_11565},
{"f_11575:optimizer_scm",(void*)f_11575},
{"f_11487:optimizer_scm",(void*)f_11487},
{"f_11492:optimizer_scm",(void*)f_11492},
{"f_11507:optimizer_scm",(void*)f_11507},
{"f_11500:optimizer_scm",(void*)f_11500},
{"f_11463:optimizer_scm",(void*)f_11463},
{"f_11475:optimizer_scm",(void*)f_11475},
{"f_11412:optimizer_scm",(void*)f_11412},
{"f_11433:optimizer_scm",(void*)f_11433},
{"f_11430:optimizer_scm",(void*)f_11430},
{"f_11365:optimizer_scm",(void*)f_11365},
{"f_11080:optimizer_scm",(void*)f_11080},
{"f_11086:optimizer_scm",(void*)f_11086},
{"f_11120:optimizer_scm",(void*)f_11120},
{"f_11222:optimizer_scm",(void*)f_11222},
{"f_11237:optimizer_scm",(void*)f_11237},
{"f_11230:optimizer_scm",(void*)f_11230},
{"f_11213:optimizer_scm",(void*)f_11213},
{"f_11179:optimizer_scm",(void*)f_11179},
{"f_11188:optimizer_scm",(void*)f_11188},
{"f_11200:optimizer_scm",(void*)f_11200},
{"f_11131:optimizer_scm",(void*)f_11131},
{"f_11152:optimizer_scm",(void*)f_11152},
{"f_11149:optimizer_scm",(void*)f_11149},
{"f_11084:optimizer_scm",(void*)f_11084},
{"f_10947:optimizer_scm",(void*)f_10947},
{"f_10953:optimizer_scm",(void*)f_10953},
{"f_10997:optimizer_scm",(void*)f_10997},
{"f_11002:optimizer_scm",(void*)f_11002},
{"f_11009:optimizer_scm",(void*)f_11009},
{"f_11070:optimizer_scm",(void*)f_11070},
{"f_11066:optimizer_scm",(void*)f_11066},
{"f_11024:optimizer_scm",(void*)f_11024},
{"f_11058:optimizer_scm",(void*)f_11058},
{"f_11051:optimizer_scm",(void*)f_11051},
{"f_11022:optimizer_scm",(void*)f_11022},
{"f_10987:optimizer_scm",(void*)f_10987},
{"f_10965:optimizer_scm",(void*)f_10965},
{"f_10972:optimizer_scm",(void*)f_10972},
{"f_10659:optimizer_scm",(void*)f_10659},
{"f_10872:optimizer_scm",(void*)f_10872},
{"f_10934:optimizer_scm",(void*)f_10934},
{"f_10880:optimizer_scm",(void*)f_10880},
{"f_10905:optimizer_scm",(void*)f_10905},
{"f_10895:optimizer_scm",(void*)f_10895},
{"f_10899:optimizer_scm",(void*)f_10899},
{"f_10870:optimizer_scm",(void*)f_10870},
{"f_10662:optimizer_scm",(void*)f_10662},
{"f_10838:optimizer_scm",(void*)f_10838},
{"f_10853:optimizer_scm",(void*)f_10853},
{"f_10846:optimizer_scm",(void*)f_10846},
{"f_10821:optimizer_scm",(void*)f_10821},
{"f_10833:optimizer_scm",(void*)f_10833},
{"f_10767:optimizer_scm",(void*)f_10767},
{"f_10791:optimizer_scm",(void*)f_10791},
{"f_10785:optimizer_scm",(void*)f_10785},
{"f_10749:optimizer_scm",(void*)f_10749},
{"f_10702:optimizer_scm",(void*)f_10702},
{"f_10705:optimizer_scm",(void*)f_10705},
{"f_10710:optimizer_scm",(void*)f_10710},
{"f_10725:optimizer_scm",(void*)f_10725},
{"f_10718:optimizer_scm",(void*)f_10718},
{"f_10556:optimizer_scm",(void*)f_10556},
{"f_10562:optimizer_scm",(void*)f_10562},
{"f_10590:optimizer_scm",(void*)f_10590},
{"f_10594:optimizer_scm",(void*)f_10594},
{"f_10598:optimizer_scm",(void*)f_10598},
{"f_10560:optimizer_scm",(void*)f_10560},
{"f_9168:optimizer_scm",(void*)f_9168},
{"f_10548:optimizer_scm",(void*)f_10548},
{"f_10551:optimizer_scm",(void*)f_10551},
{"f_9824:optimizer_scm",(void*)f_9824},
{"f_10538:optimizer_scm",(void*)f_10538},
{"f_10536:optimizer_scm",(void*)f_10536},
{"f_9828:optimizer_scm",(void*)f_9828},
{"f_9843:optimizer_scm",(void*)f_9843},
{"f_9852:optimizer_scm",(void*)f_9852},
{"f_9858:optimizer_scm",(void*)f_9858},
{"f_9861:optimizer_scm",(void*)f_9861},
{"f_9867:optimizer_scm",(void*)f_9867},
{"f_10150:optimizer_scm",(void*)f_10150},
{"f_10465:optimizer_scm",(void*)f_10465},
{"f_10475:optimizer_scm",(void*)f_10475},
{"f_10439:optimizer_scm",(void*)f_10439},
{"f_10449:optimizer_scm",(void*)f_10449},
{"f_10424:optimizer_scm",(void*)f_10424},
{"f_10427:optimizer_scm",(void*)f_10427},
{"f_10372:optimizer_scm",(void*)f_10372},
{"f_10375:optimizer_scm",(void*)f_10375},
{"f_10219:optimizer_scm",(void*)f_10219},
{"f_10266:optimizer_scm",(void*)f_10266},
{"f_10276:optimizer_scm",(void*)f_10276},
{"f_10279:optimizer_scm",(void*)f_10279},
{"f_10313:optimizer_scm",(void*)f_10313},
{"f_10282:optimizer_scm",(void*)f_10282},
{"f_10285:optimizer_scm",(void*)f_10285},
{"f_10228:optimizer_scm",(void*)f_10228},
{"f_10231:optimizer_scm",(void*)f_10231},
{"f_10234:optimizer_scm",(void*)f_10234},
{"f_9870:optimizer_scm",(void*)f_9870},
{"f_10132:optimizer_scm",(void*)f_10132},
{"f_10041:optimizer_scm",(void*)f_10041},
{"f_10043:optimizer_scm",(void*)f_10043},
{"f_10119:optimizer_scm",(void*)f_10119},
{"f_10051:optimizer_scm",(void*)f_10051},
{"f_10066:optimizer_scm",(void*)f_10066},
{"f_9873:optimizer_scm",(void*)f_9873},
{"f_9890:optimizer_scm",(void*)f_9890},
{"f_9961:optimizer_scm",(void*)f_9961},
{"f_9893:optimizer_scm",(void*)f_9893},
{"f_9896:optimizer_scm",(void*)f_9896},
{"f_9901:optimizer_scm",(void*)f_9901},
{"f_9945:optimizer_scm",(void*)f_9945},
{"f_9916:optimizer_scm",(void*)f_9916},
{"f_9370:optimizer_scm",(void*)f_9370},
{"f_9815:optimizer_scm",(void*)f_9815},
{"f_9822:optimizer_scm",(void*)f_9822},
{"f_9373:optimizer_scm",(void*)f_9373},
{"f_9802:optimizer_scm",(void*)f_9802},
{"f_9778:optimizer_scm",(void*)f_9778},
{"f_9789:optimizer_scm",(void*)f_9789},
{"f_9745:optimizer_scm",(void*)f_9745},
{"f_9636:optimizer_scm",(void*)f_9636},
{"f_9641:optimizer_scm",(void*)f_9641},
{"f_9583:optimizer_scm",(void*)f_9583},
{"f_9589:optimizer_scm",(void*)f_9589},
{"f_9594:optimizer_scm",(void*)f_9594},
{"f_9542:optimizer_scm",(void*)f_9542},
{"f_9548:optimizer_scm",(void*)f_9548},
{"f_9553:optimizer_scm",(void*)f_9553},
{"f_9526:optimizer_scm",(void*)f_9526},
{"f_9522:optimizer_scm",(void*)f_9522},
{"f_9492:optimizer_scm",(void*)f_9492},
{"f_9455:optimizer_scm",(void*)f_9455},
{"f_9471:optimizer_scm",(void*)f_9471},
{"f_9437:optimizer_scm",(void*)f_9437},
{"f_9171:optimizer_scm",(void*)f_9171},
{"f_9342:optimizer_scm",(void*)f_9342},
{"f_9357:optimizer_scm",(void*)f_9357},
{"f_9350:optimizer_scm",(void*)f_9350},
{"f_9322:optimizer_scm",(void*)f_9322},
{"f_9296:optimizer_scm",(void*)f_9296},
{"f_9242:optimizer_scm",(void*)f_9242},
{"f_9248:optimizer_scm",(void*)f_9248},
{"f_9254:optimizer_scm",(void*)f_9254},
{"f_9211:optimizer_scm",(void*)f_9211},
{"f_6809:optimizer_scm",(void*)f_6809},
{"f_9035:optimizer_scm",(void*)f_9035},
{"f_9064:optimizer_scm",(void*)f_9064},
{"f_9076:optimizer_scm",(void*)f_9076},
{"f_9090:optimizer_scm",(void*)f_9090},
{"f_9139:optimizer_scm",(void*)f_9139},
{"f_6834:optimizer_scm",(void*)f_6834},
{"f_9110:optimizer_scm",(void*)f_9110},
{"f_9114:optimizer_scm",(void*)f_9114},
{"f_9084:optimizer_scm",(void*)f_9084},
{"f_9070:optimizer_scm",(void*)f_9070},
{"f_9068:optimizer_scm",(void*)f_9068},
{"f_9060:optimizer_scm",(void*)f_9060},
{"f_8955:optimizer_scm",(void*)f_8955},
{"f_8999:optimizer_scm",(void*)f_8999},
{"f_8760:optimizer_scm",(void*)f_8760},
{"f_8766:optimizer_scm",(void*)f_8766},
{"f_8882:optimizer_scm",(void*)f_8882},
{"f_8775:optimizer_scm",(void*)f_8775},
{"f_8837:optimizer_scm",(void*)f_8837},
{"f_8835:optimizer_scm",(void*)f_8835},
{"f_8797:optimizer_scm",(void*)f_8797},
{"f_8675:optimizer_scm",(void*)f_8675},
{"f_8716:optimizer_scm",(void*)f_8716},
{"f_8728:optimizer_scm",(void*)f_8728},
{"f_8706:optimizer_scm",(void*)f_8706},
{"f_8704:optimizer_scm",(void*)f_8704},
{"f_8493:optimizer_scm",(void*)f_8493},
{"f_8599:optimizer_scm",(void*)f_8599},
{"f_8502:optimizer_scm",(void*)f_8502},
{"f_8573:optimizer_scm",(void*)f_8573},
{"f_8571:optimizer_scm",(void*)f_8571},
{"f_8524:optimizer_scm",(void*)f_8524},
{"f_8453:optimizer_scm",(void*)f_8453},
{"f_8469:optimizer_scm",(void*)f_8469},
{"f_8374:optimizer_scm",(void*)f_8374},
{"f_8403:optimizer_scm",(void*)f_8403},
{"f_8284:optimizer_scm",(void*)f_8284},
{"f_8318:optimizer_scm",(void*)f_8318},
{"f_8179:optimizer_scm",(void*)f_8179},
{"f_8205:optimizer_scm",(void*)f_8205},
{"f_8201:optimizer_scm",(void*)f_8201},
{"f_8085:optimizer_scm",(void*)f_8085},
{"f_8008:optimizer_scm",(void*)f_8008},
{"f_8032:optimizer_scm",(void*)f_8032},
{"f_8036:optimizer_scm",(void*)f_8036},
{"f_7920:optimizer_scm",(void*)f_7920},
{"f_7976:optimizer_scm",(void*)f_7976},
{"f_7972:optimizer_scm",(void*)f_7972},
{"f_7849:optimizer_scm",(void*)f_7849},
{"f_7861:optimizer_scm",(void*)f_7861},
{"f_7881:optimizer_scm",(void*)f_7881},
{"f_7877:optimizer_scm",(void*)f_7877},
{"f_7750:optimizer_scm",(void*)f_7750},
{"f_7779:optimizer_scm",(void*)f_7779},
{"f_7787:optimizer_scm",(void*)f_7787},
{"f_7791:optimizer_scm",(void*)f_7791},
{"f_7507:optimizer_scm",(void*)f_7507},
{"f_7535:optimizer_scm",(void*)f_7535},
{"f_7538:optimizer_scm",(void*)f_7538},
{"f_7651:optimizer_scm",(void*)f_7651},
{"f_7685:optimizer_scm",(void*)f_7685},
{"f_7541:optimizer_scm",(void*)f_7541},
{"f_7616:optimizer_scm",(void*)f_7616},
{"f_7645:optimizer_scm",(void*)f_7645},
{"f_7544:optimizer_scm",(void*)f_7544},
{"f_7588:optimizer_scm",(void*)f_7588},
{"f_7586:optimizer_scm",(void*)f_7586},
{"f_7549:optimizer_scm",(void*)f_7549},
{"f_7529:optimizer_scm",(void*)f_7529},
{"f_7481:optimizer_scm",(void*)f_7481},
{"f_7408:optimizer_scm",(void*)f_7408},
{"f_7445:optimizer_scm",(void*)f_7445},
{"f_7437:optimizer_scm",(void*)f_7437},
{"f_7319:optimizer_scm",(void*)f_7319},
{"f_7214:optimizer_scm",(void*)f_7214},
{"f_7269:optimizer_scm",(void*)f_7269},
{"f_7146:optimizer_scm",(void*)f_7146},
{"f_7166:optimizer_scm",(void*)f_7166},
{"f_7174:optimizer_scm",(void*)f_7174},
{"f_7097:optimizer_scm",(void*)f_7097},
{"f_7113:optimizer_scm",(void*)f_7113},
{"f_7022:optimizer_scm",(void*)f_7022},
{"f_6871:optimizer_scm",(void*)f_6871},
{"f_6952:optimizer_scm",(void*)f_6952},
{"f_6874:optimizer_scm",(void*)f_6874},
{"f_6789:optimizer_scm",(void*)f_6789},
{"f_6793:optimizer_scm",(void*)f_6793},
{"f_6803:optimizer_scm",(void*)f_6803},
{"f_6300:optimizer_scm",(void*)f_6300},
{"f_6736:optimizer_scm",(void*)f_6736},
{"f_6769:optimizer_scm",(void*)f_6769},
{"f_6749:optimizer_scm",(void*)f_6749},
{"f_6304:optimizer_scm",(void*)f_6304},
{"f_6689:optimizer_scm",(void*)f_6689},
{"f_6709:optimizer_scm",(void*)f_6709},
{"f_6697:optimizer_scm",(void*)f_6697},
{"f_6706:optimizer_scm",(void*)f_6706},
{"f_6702:optimizer_scm",(void*)f_6702},
{"f_6351:optimizer_scm",(void*)f_6351},
{"f_6609:optimizer_scm",(void*)f_6609},
{"f_6676:optimizer_scm",(void*)f_6676},
{"f_6617:optimizer_scm",(void*)f_6617},
{"f_6649:optimizer_scm",(void*)f_6649},
{"f_6662:optimizer_scm",(void*)f_6662},
{"f_6627:optimizer_scm",(void*)f_6627},
{"f_6643:optimizer_scm",(void*)f_6643},
{"f_6631:optimizer_scm",(void*)f_6631},
{"f_6635:optimizer_scm",(void*)f_6635},
{"f_6354:optimizer_scm",(void*)f_6354},
{"f_6528:optimizer_scm",(void*)f_6528},
{"f_6596:optimizer_scm",(void*)f_6596},
{"f_6536:optimizer_scm",(void*)f_6536},
{"f_6579:optimizer_scm",(void*)f_6579},
{"f_6585:optimizer_scm",(void*)f_6585},
{"f_6543:optimizer_scm",(void*)f_6543},
{"f_6553:optimizer_scm",(void*)f_6553},
{"f_6566:optimizer_scm",(void*)f_6566},
{"f_6551:optimizer_scm",(void*)f_6551},
{"f_6547:optimizer_scm",(void*)f_6547},
{"f_6357:optimizer_scm",(void*)f_6357},
{"f_6360:optimizer_scm",(void*)f_6360},
{"f_6380:optimizer_scm",(void*)f_6380},
{"f_6393:optimizer_scm",(void*)f_6393},
{"f_6454:optimizer_scm",(void*)f_6454},
{"f_6500:optimizer_scm",(void*)f_6500},
{"f_6452:optimizer_scm",(void*)f_6452},
{"f_6422:optimizer_scm",(void*)f_6422},
{"f_6363:optimizer_scm",(void*)f_6363},
{"f_6372:optimizer_scm",(void*)f_6372},
{"f_6306:optimizer_scm",(void*)f_6306},
{"f_6312:optimizer_scm",(void*)f_6312},
{"f_6336:optimizer_scm",(void*)f_6336},
{"f_6285:optimizer_scm",(void*)f_6285},
{"f_5966:optimizer_scm",(void*)f_5966},
{"f_5980:optimizer_scm",(void*)f_5980},
{"f_6000:optimizer_scm",(void*)f_6000},
{"f_6007:optimizer_scm",(void*)f_6007},
{"f_6012:optimizer_scm",(void*)f_6012},
{"f_6272:optimizer_scm",(void*)f_6272},
{"f_6020:optimizer_scm",(void*)f_6020},
{"f_6256:optimizer_scm",(void*)f_6256},
{"f_6038:optimizer_scm",(void*)f_6038},
{"f_6041:optimizer_scm",(void*)f_6041},
{"f_6047:optimizer_scm",(void*)f_6047},
{"f_6067:optimizer_scm",(void*)f_6067},
{"f_6073:optimizer_scm",(void*)f_6073},
{"f_6079:optimizer_scm",(void*)f_6079},
{"f_6088:optimizer_scm",(void*)f_6088},
{"f_6095:optimizer_scm",(void*)f_6095},
{"f_6098:optimizer_scm",(void*)f_6098},
{"f_6116:optimizer_scm",(void*)f_6116},
{"f_6101:optimizer_scm",(void*)f_6101},
{"f_5983:optimizer_scm",(void*)f_5983},
{"f_5986:optimizer_scm",(void*)f_5986},
{"f_5973:optimizer_scm",(void*)f_5973},
{"f_5969:optimizer_scm",(void*)f_5969},
{"f_4105:optimizer_scm",(void*)f_4105},
{"f_5848:optimizer_scm",(void*)f_5848},
{"f_5854:optimizer_scm",(void*)f_5854},
{"f_5858:optimizer_scm",(void*)f_5858},
{"f_5861:optimizer_scm",(void*)f_5861},
{"f_5897:optimizer_scm",(void*)f_5897},
{"f_5902:optimizer_scm",(void*)f_5902},
{"f_5914:optimizer_scm",(void*)f_5914},
{"f_5941:optimizer_scm",(void*)f_5941},
{"f_5864:optimizer_scm",(void*)f_5864},
{"f_5867:optimizer_scm",(void*)f_5867},
{"f_5870:optimizer_scm",(void*)f_5870},
{"f_5873:optimizer_scm",(void*)f_5873},
{"f_5818:optimizer_scm",(void*)f_5818},
{"f_5838:optimizer_scm",(void*)f_5838},
{"f_5822:optimizer_scm",(void*)f_5822},
{"f_5828:optimizer_scm",(void*)f_5828},
{"f_4560:optimizer_scm",(void*)f_4560},
{"f_5708:optimizer_scm",(void*)f_5708},
{"f_5711:optimizer_scm",(void*)f_5711},
{"f_5810:optimizer_scm",(void*)f_5810},
{"f_5806:optimizer_scm",(void*)f_5806},
{"f_5768:optimizer_scm",(void*)f_5768},
{"f_5799:optimizer_scm",(void*)f_5799},
{"f_5795:optimizer_scm",(void*)f_5795},
{"f_5787:optimizer_scm",(void*)f_5787},
{"f_5728:optimizer_scm",(void*)f_5728},
{"f_5758:optimizer_scm",(void*)f_5758},
{"f_5734:optimizer_scm",(void*)f_5734},
{"f_5682:optimizer_scm",(void*)f_5682},
{"f_5680:optimizer_scm",(void*)f_5680},
{"f_5640:optimizer_scm",(void*)f_5640},
{"f_5630:optimizer_scm",(void*)f_5630},
{"f_4942:optimizer_scm",(void*)f_4942},
{"f_4951:optimizer_scm",(void*)f_4951},
{"f_5182:optimizer_scm",(void*)f_5182},
{"f_5198:optimizer_scm",(void*)f_5198},
{"f_5572:optimizer_scm",(void*)f_5572},
{"f_5609:optimizer_scm",(void*)f_5609},
{"f_5586:optimizer_scm",(void*)f_5586},
{"f_5208:optimizer_scm",(void*)f_5208},
{"f_5280:optimizer_scm",(void*)f_5280},
{"f_5559:optimizer_scm",(void*)f_5559},
{"f_5458:optimizer_scm",(void*)f_5458},
{"f_5461:optimizer_scm",(void*)f_5461},
{"f_5473:optimizer_scm",(void*)f_5473},
{"f_5484:optimizer_scm",(void*)f_5484},
{"f_5523:optimizer_scm",(void*)f_5523},
{"f_5515:optimizer_scm",(void*)f_5515},
{"f_5503:optimizer_scm",(void*)f_5503},
{"f_5501:optimizer_scm",(void*)f_5501},
{"f_5478:optimizer_scm",(void*)f_5478},
{"f_5294:optimizer_scm",(void*)f_5294},
{"f_5339:optimizer_scm",(void*)f_5339},
{"f_5345:optimizer_scm",(void*)f_5345},
{"f_5351:optimizer_scm",(void*)f_5351},
{"f_5395:optimizer_scm",(void*)f_5395},
{"f_5371:optimizer_scm",(void*)f_5371},
{"f_5375:optimizer_scm",(void*)f_5375},
{"f_5333:optimizer_scm",(void*)f_5333},
{"f_5321:optimizer_scm",(void*)f_5321},
{"f_5319:optimizer_scm",(void*)f_5319},
{"f_5274:optimizer_scm",(void*)f_5274},
{"f_5211:optimizer_scm",(void*)f_5211},
{"f_5245:optimizer_scm",(void*)f_5245},
{"f_5214:optimizer_scm",(void*)f_5214},
{"f_5217:optimizer_scm",(void*)f_5217},
{"f_5220:optimizer_scm",(void*)f_5220},
{"f_5230:optimizer_scm",(void*)f_5230},
{"f_5158:optimizer_scm",(void*)f_5158},
{"f_5033:optimizer_scm",(void*)f_5033},
{"f_5054:optimizer_scm",(void*)f_5054},
{"f_5122:optimizer_scm",(void*)f_5122},
{"f_5114:optimizer_scm",(void*)f_5114},
{"f_5057:optimizer_scm",(void*)f_5057},
{"f_5093:optimizer_scm",(void*)f_5093},
{"f_5091:optimizer_scm",(void*)f_5091},
{"f_5066:optimizer_scm",(void*)f_5066},
{"f_5012:optimizer_scm",(void*)f_5012},
{"f_4965:optimizer_scm",(void*)f_4965},
{"f_4968:optimizer_scm",(void*)f_4968},
{"f_4996:optimizer_scm",(void*)f_4996},
{"f_4974:optimizer_scm",(void*)f_4974},
{"f_4981:optimizer_scm",(void*)f_4981},
{"f_4747:optimizer_scm",(void*)f_4747},
{"f_4846:optimizer_scm",(void*)f_4846},
{"f_4851:optimizer_scm",(void*)f_4851},
{"f_4858:optimizer_scm",(void*)f_4858},
{"f_4898:optimizer_scm",(void*)f_4898},
{"f_4878:optimizer_scm",(void*)f_4878},
{"f_4752:optimizer_scm",(void*)f_4752},
{"f_4770:optimizer_scm",(void*)f_4770},
{"f_4777:optimizer_scm",(void*)f_4777},
{"f_4824:optimizer_scm",(void*)f_4824},
{"f_4827:optimizer_scm",(void*)f_4827},
{"f_4817:optimizer_scm",(void*)f_4817},
{"f_4797:optimizer_scm",(void*)f_4797},
{"f_4758:optimizer_scm",(void*)f_4758},
{"f_4764:optimizer_scm",(void*)f_4764},
{"f_4681:optimizer_scm",(void*)f_4681},
{"f_4722:optimizer_scm",(void*)f_4722},
{"f_4729:optimizer_scm",(void*)f_4729},
{"f_4684:optimizer_scm",(void*)f_4684},
{"f_4712:optimizer_scm",(void*)f_4712},
{"f_4710:optimizer_scm",(void*)f_4710},
{"f_4600:optimizer_scm",(void*)f_4600},
{"f_4604:optimizer_scm",(void*)f_4604},
{"f_4616:optimizer_scm",(void*)f_4616},
{"f_4622:optimizer_scm",(void*)f_4622},
{"f_4642:optimizer_scm",(void*)f_4642},
{"f_4279:optimizer_scm",(void*)f_4279},
{"f_4293:optimizer_scm",(void*)f_4293},
{"f_4519:optimizer_scm",(void*)f_4519},
{"f_4525:optimizer_scm",(void*)f_4525},
{"f_4373:optimizer_scm",(void*)f_4373},
{"f_4465:optimizer_scm",(void*)f_4465},
{"f_4459:optimizer_scm",(void*)f_4459},
{"f_4384:optimizer_scm",(void*)f_4384},
{"f_4407:optimizer_scm",(void*)f_4407},
{"f_4445:optimizer_scm",(void*)f_4445},
{"f_4451:optimizer_scm",(void*)f_4451},
{"f_4413:optimizer_scm",(void*)f_4413},
{"f_4417:optimizer_scm",(void*)f_4417},
{"f_4420:optimizer_scm",(void*)f_4420},
{"f_4443:optimizer_scm",(void*)f_4443},
{"f_4390:optimizer_scm",(void*)f_4390},
{"f_4396:optimizer_scm",(void*)f_4396},
{"f_4400:optimizer_scm",(void*)f_4400},
{"f_4404:optimizer_scm",(void*)f_4404},
{"f_4379:optimizer_scm",(void*)f_4379},
{"f_4312:optimizer_scm",(void*)f_4312},
{"f_4148:optimizer_scm",(void*)f_4148},
{"f_4152:optimizer_scm",(void*)f_4152},
{"f_4163:optimizer_scm",(void*)f_4163},
{"f_4173:optimizer_scm",(void*)f_4173},
{"f_4222:optimizer_scm",(void*)f_4222},
{"f_4249:optimizer_scm",(void*)f_4249},
{"f_4220:optimizer_scm",(void*)f_4220},
{"f_4179:optimizer_scm",(void*)f_4179},
{"f_4185:optimizer_scm",(void*)f_4185},
{"f_4212:optimizer_scm",(void*)f_4212},
{"f_4155:optimizer_scm",(void*)f_4155},
{"f_4144:optimizer_scm",(void*)f_4144},
{"f_4114:optimizer_scm",(void*)f_4114},
{"f_4108:optimizer_scm",(void*)f_4108},
{"f_3736:optimizer_scm",(void*)f_3736},
{"f_4046:optimizer_scm",(void*)f_4046},
{"f_4049:optimizer_scm",(void*)f_4049},
{"f_4098:optimizer_scm",(void*)f_4098},
{"f_4052:optimizer_scm",(void*)f_4052},
{"f_4057:optimizer_scm",(void*)f_4057},
{"f_4063:optimizer_scm",(void*)f_4063},
{"f_3808:optimizer_scm",(void*)f_3808},
{"f_3889:optimizer_scm",(void*)f_3889},
{"f_3939:optimizer_scm",(void*)f_3939},
{"f_3963:optimizer_scm",(void*)f_3963},
{"f_3966:optimizer_scm",(void*)f_3966},
{"f_3984:optimizer_scm",(void*)f_3984},
{"f_4003:optimizer_scm",(void*)f_4003},
{"f_4006:optimizer_scm",(void*)f_4006},
{"f_4009:optimizer_scm",(void*)f_4009},
{"f_4012:optimizer_scm",(void*)f_4012},
{"f_4015:optimizer_scm",(void*)f_4015},
{"f_3987:optimizer_scm",(void*)f_3987},
{"f_3969:optimizer_scm",(void*)f_3969},
{"f_3972:optimizer_scm",(void*)f_3972},
{"f_3915:optimizer_scm",(void*)f_3915},
{"f_3926:optimizer_scm",(void*)f_3926},
{"f_3892:optimizer_scm",(void*)f_3892},
{"f_3862:optimizer_scm",(void*)f_3862},
{"f_3845:optimizer_scm",(void*)f_3845},
{"f_3851:optimizer_scm",(void*)f_3851},
{"f_3849:optimizer_scm",(void*)f_3849},
{"f_3774:optimizer_scm",(void*)f_3774},
{"f_3780:optimizer_scm",(void*)f_3780},
{"f_3795:optimizer_scm",(void*)f_3795},
{"f_3788:optimizer_scm",(void*)f_3788},
{"f_3769:optimizer_scm",(void*)f_3769},
{"f_3762:optimizer_scm",(void*)f_3762},
{"f_3767:optimizer_scm",(void*)f_3767},
{"f_3739:optimizer_scm",(void*)f_3739},
{"f_3746:optimizer_scm",(void*)f_3746},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
