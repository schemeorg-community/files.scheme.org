/* Generated from compiler-syntax.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:53
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: compiler-syntax.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file compiler-syntax.c
   unit: compiler_syntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[76];
static double C_possibly_force_alignment;


C_noret_decl(C_compiler_syntax_toplevel)
C_externexport void C_ccall C_compiler_syntax_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_700)
static void C_ccall f_700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_703)
static void C_ccall f_703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2449)
static void C_ccall f_2449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_fcall f_2467(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2756)
static void C_fcall f_2756(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2790)
static void C_ccall f_2790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2707)
static void C_fcall f_2707(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2740)
static void C_ccall f_2740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2720)
static void C_fcall f_2720(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2663)
static void C_fcall f_2663(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2690)
static C_word C_fcall f_2690(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_fcall f_2599(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_fcall f_2539(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_794)
static void C_ccall f_794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_fcall f_1915(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2344)
static void C_fcall f_2344(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_fcall f_2267(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_fcall f_2280(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_fcall f_2223(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2250)
static C_word C_fcall f_2250(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2159)
static void C_fcall f_2159(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2157)
static void C_ccall f_2157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_fcall f_2019(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_800)
static void C_ccall f_800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1655)
static void C_ccall f_1655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1659)
static void C_ccall f_1659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1662)
static void C_ccall f_1662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_ccall f_1716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_803)
static void C_ccall f_803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1653)
static void C_ccall f_1653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1649)
static void C_ccall f_1649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1633)
static void C_ccall f_1633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_806)
static void C_ccall f_806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1534)
static void C_ccall f_1534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1526)
static void C_ccall f_1526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1522)
static void C_ccall f_1522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1447)
static void C_ccall f_1447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_809)
static void C_ccall f_809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_811)
static void C_ccall f_811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_817)
static void C_ccall f_817(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1429)
static void C_ccall f_1429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1425)
static void C_ccall f_1425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_839)
static void C_fcall f_839(C_word t0,C_word t1) C_noret;
C_noret_decl(f_842)
static void C_ccall f_842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_885)
static void C_ccall f_885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_888)
static void C_ccall f_888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_891)
static void C_ccall f_891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_894)
static void C_ccall f_894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_897)
static void C_ccall f_897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_900)
static void C_ccall f_900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_903)
static void C_ccall f_903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_997)
static void C_fcall f_997(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1058)
static void C_ccall f_1058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1362)
static C_word C_fcall f_1362(C_word t0,C_word t1);
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1246)
static void C_ccall f_1246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1209)
static void C_ccall f_1209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1172)
static void C_ccall f_1172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1110)
static void C_ccall f_1110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1064)
static void C_ccall f_1064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1007)
static void C_ccall f_1007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1029)
static void C_ccall f_1029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_987)
static C_word C_fcall f_987(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_934)
static void C_fcall f_934(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_977)
static void C_ccall f_977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_915)
static void C_fcall f_915(C_word t0,C_word t1) C_noret;
C_noret_decl(f_905)
static C_word C_fcall f_905(C_word t0);
C_noret_decl(f_847)
static void C_fcall f_847(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_851)
static void C_ccall f_851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_867)
static void C_ccall f_867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_870)
static void C_ccall f_870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_873)
static void C_ccall f_873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_876)
static void C_ccall f_876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_864)
static void C_ccall f_864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_854)
static void C_ccall f_854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_720)
static void C_ccall f_720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_720)
static void C_ccall f_720r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_724)
static void C_ccall f_724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_772)
static void C_ccall f_772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_736)
static void C_fcall f_736(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_751)
static void C_ccall f_751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_744)
static void C_fcall f_744(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_706)
static void C_ccall f_706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_710)
static void C_ccall f_710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_714)
static void C_ccall f_714(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2467)
static void C_fcall trf_2467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2467(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2467(t0,t1);}

C_noret_decl(trf_2756)
static void C_fcall trf_2756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2756(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2756(t0,t1,t2);}

C_noret_decl(trf_2707)
static void C_fcall trf_2707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2707(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2707(t0,t1,t2,t3);}

C_noret_decl(trf_2720)
static void C_fcall trf_2720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2720(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2720(t0,t1);}

C_noret_decl(trf_2663)
static void C_fcall trf_2663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2663(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2663(t0,t1,t2);}

C_noret_decl(trf_2599)
static void C_fcall trf_2599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2599(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2599(t0,t1,t2);}

C_noret_decl(trf_2539)
static void C_fcall trf_2539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2539(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2539(t0,t1,t2);}

C_noret_decl(trf_1915)
static void C_fcall trf_1915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1915(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1915(t0,t1);}

C_noret_decl(trf_2344)
static void C_fcall trf_2344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2344(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2344(t0,t1,t2);}

C_noret_decl(trf_2267)
static void C_fcall trf_2267(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2267(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2267(t0,t1,t2,t3);}

C_noret_decl(trf_2280)
static void C_fcall trf_2280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2280(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2280(t0,t1);}

C_noret_decl(trf_2223)
static void C_fcall trf_2223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2223(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2223(t0,t1,t2);}

C_noret_decl(trf_2159)
static void C_fcall trf_2159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2159(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2159(t0,t1,t2);}

C_noret_decl(trf_2019)
static void C_fcall trf_2019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2019(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2019(t0,t1,t2);}

C_noret_decl(trf_839)
static void C_fcall trf_839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_839(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_839(t0,t1);}

C_noret_decl(trf_997)
static void C_fcall trf_997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_997(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_997(t0,t1,t2);}

C_noret_decl(trf_934)
static void C_fcall trf_934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_934(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_934(t0,t1,t2);}

C_noret_decl(trf_915)
static void C_fcall trf_915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_915(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_915(t0,t1);}

C_noret_decl(trf_847)
static void C_fcall trf_847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_847(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_847(t0,t1,t2,t3,t4);}

C_noret_decl(trf_736)
static void C_fcall trf_736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_736(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_736(t0,t1,t2);}

C_noret_decl(trf_744)
static void C_fcall trf_744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_744(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_744(t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr8)
static void C_fcall tr8(C_proc8 k) C_regparm C_noret;
C_regparm static void C_fcall tr8(C_proc8 k){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
(k)(8,t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_compiler_syntax_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_compiler_syntax_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("compiler_syntax_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(864)){
C_save(t1);
C_rereclaim2(864*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,76);
lf[0]=C_h_intern(&lf[0],35,"\010compilercompiler-syntax-statistics");
lf[1]=C_h_intern(&lf[1],24,"\003syscompiler-syntax-hook");
lf[2]=C_h_intern(&lf[2],13,"alist-update!");
lf[3]=C_h_intern(&lf[3],9,"alist-ref");
lf[4]=C_h_intern(&lf[4],3,"eq\077");
lf[5]=C_h_intern(&lf[5],14,"\010compilerr-c-s");
lf[6]=C_h_intern(&lf[6],8,"\003sysput!");
lf[7]=C_h_intern(&lf[7],24,"\010compilercompiler-syntax");
lf[8]=C_h_intern(&lf[8],18,"\003syser-transformer");
lf[9]=C_h_intern(&lf[9],9,"\003syserror");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[11]=C_h_intern(&lf[11],30,"\010compilercompile-format-string");
lf[12]=C_h_intern(&lf[12],17,"extended-bindings");
lf[13]=C_h_intern(&lf[13],25,"\010compilercompiler-warning");
lf[14]=C_h_intern(&lf[14],6,"syntax");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\037`~a\047, in format string ~s~a, ~\077");
lf[16]=C_h_intern(&lf[16],17,"get-output-string");
lf[17]=C_h_intern(&lf[17],19,"\003syswrite-char/port");
lf[18]=C_h_intern(&lf[18],7,"display");
lf[19]=C_h_intern(&lf[19],18,"open-output-string");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[21]=C_h_intern(&lf[21],17,"\010compilerget-line");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000/too few arguments to formatted output procedure");
lf[23]=C_h_intern(&lf[23],20,"reverse-list->string");
lf[24]=C_h_intern(&lf[24],10,"\003sysappend");
lf[25]=C_h_intern(&lf[25],7,"reverse");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\0000too many arguments to formatted output procedure");
lf[27]=C_h_intern(&lf[27],16,"\003sysflush-output");
lf[28]=C_h_intern(&lf[28],9,"\003sysapply");
lf[29]=C_h_intern(&lf[29],10,"write-char");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000$illegal format-string character `~c\047");
lf[31]=C_h_intern(&lf[31],14,"number->string");
lf[32]=C_h_intern(&lf[32],3,"let");
lf[33]=C_h_intern(&lf[33],7,"fprintf");
lf[34]=C_h_intern(&lf[34],3,"out");
lf[35]=C_h_intern(&lf[35],5,"write");
lf[36]=C_h_intern(&lf[36],5,"cadar");
lf[37]=C_h_intern(&lf[37],4,"caar");
lf[38]=C_h_intern(&lf[38],5,"quote");
lf[39]=C_h_intern(&lf[39],7,"call/cc");
lf[40]=C_h_intern(&lf[40],6,"printf");
lf[41]=C_h_intern(&lf[41],19,"\003sysstandard-output");
lf[42]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006printf\376\003\000\000\002\376\001\000\000\010#%printf\376\377\016");
lf[43]=C_h_intern(&lf[43],19,"\003sysprimitive-alias");
lf[44]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007fprintf\376\003\000\000\002\376\001\000\000\011#%fprintf\376\377\016");
lf[45]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007sprintf\376\003\000\000\002\376\001\000\000\011#%sprintf\376\377\016");
lf[46]=C_h_intern(&lf[46],7,"sprintf");
lf[47]=C_h_intern(&lf[47],6,"format");
lf[48]=C_h_intern(&lf[48],6,"gensym");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007sprintf\376\003\000\000\002\376\001\000\000\011#%sprintf\376\003\000\000\002\376\001\000\000\006format\376\003\000\000\002\376\001\000\000\010#%format\376\377\016");
lf[50]=C_h_intern(&lf[50],1,"o");
lf[51]=C_h_intern(&lf[51],10,"fold-right");
lf[52]=C_h_intern(&lf[52],4,"list");
lf[53]=C_h_intern(&lf[53],6,"lambda");
lf[54]=C_h_intern(&lf[54],3,"tmp");
lf[55]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001o\376\003\000\000\002\376\001\000\000\003#%o\376\377\016");
lf[56]=C_h_intern(&lf[56],11,"\003syssetslot");
lf[57]=C_h_intern(&lf[57],8,"\003sysslot");
lf[58]=C_h_intern(&lf[58],3,"map");
lf[59]=C_h_intern(&lf[59],17,"standard-bindings");
lf[60]=C_h_intern(&lf[60],5,"caadr");
lf[61]=C_h_intern(&lf[61],7,"length+");
lf[62]=C_h_intern(&lf[62],5,"pair\077");
lf[63]=C_h_intern(&lf[63],3,"and");
lf[64]=C_h_intern(&lf[64],5,"begin");
lf[65]=C_h_intern(&lf[65],4,"node");
lf[66]=C_h_intern(&lf[66],6,"result");
lf[67]=C_h_intern(&lf[67],4,"set!");
lf[68]=C_h_intern(&lf[68],4,"cons");
lf[69]=C_h_intern(&lf[69],3,"res");
lf[70]=C_h_intern(&lf[70],4,"loop");
lf[71]=C_h_intern(&lf[71],2,"if");
lf[72]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000\007\003sysmap\376\003\000\000\002\376\001\000\000\005#%map\376\377\016");
lf[73]=C_h_intern(&lf[73],8,"\004coreapp");
lf[74]=C_h_intern(&lf[74],8,"for-each");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\014\003sysfor-each\376\003\000\000\002\376\001\000\000\012#%for-each\376\377\016");
C_register_lf2(lf,76,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_700,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k698 */
static void C_ccall f_700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_703,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k701 in k698 */
static void C_ccall f_703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_703,2,t0,t1);}
t2=C_set_block_item(lf[0] /* compiler-syntax-statistics */,0,C_SCHEME_END_OF_LIST);
t3=C_mutate((C_word*)lf[1]+1 /* (set! ##sys#compiler-syntax-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_706,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[5]+1 /* (set! ##compiler#r-c-s ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_720,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_794,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2436,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2846,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t7,lf[62]);}

/* k2844 in k701 in k698 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2846,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[62],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##compiler#r-c-s */
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[75],((C_word*)t0)[2],t3);}

/* a2435 in k701 in k698 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2436,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2440,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm: 61   r */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[32]);}

/* k2438 in a2435 in k701 in k698 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 62   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[71]);}

/* k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm: 63   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[70]);}

/* k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm: 64   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[64]);}

/* k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler-syntax.scm: 65   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[63]);}

/* k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm: 66   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[62]);}

/* k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm: 67   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2458,2,t0,t1);}
t2=C_i_cddr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2467,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_memq(lf[74],C_retrieve(lf[59])))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2834,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm: 70   length+ */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t4,((C_word*)t0)[10]);}
else{
t4=t3;
f_2467(t4,C_SCHEME_FALSE);}}

/* k2832 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2834,2,t0,t1);}
if(C_truep(C_fixnum_greaterp(t1,C_fix(2)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2806,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
if(C_truep(C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2826,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm: 72   caadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[60]+1)))(3,*((C_word*)lf[60]+1),t4,((C_word*)t0)[4]);}
else{
t4=C_i_cadr(((C_word*)t0)[4]);
t5=((C_word*)t0)[5];
f_2467(t5,C_i_symbolp(t4));}}
else{
t2=((C_word*)t0)[5];
f_2467(t2,C_SCHEME_FALSE);}}

/* k2824 in k2832 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler-syntax.scm: 72   c */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2804 in k2832 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2467(t2,t1);}
else{
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_2467(t3,C_i_symbolp(t2));}}

/* k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_fcall f_2467(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2467,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2756,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2756(t10,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[9];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* loop137 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_fcall f_2756(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2756,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2790,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_list(&a,1,t4);
/* compiler-syntax.scm: 74   gensym */
((C_proc2)C_retrieve_symbol_proc(lf[48]))(2,*((C_word*)lf[48]+1),t3);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2788 in loop137 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2790,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop137150 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2756(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop137150 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2756(t6,((C_word*)t0)[3],t5);}}

/* k2468 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2485,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2707,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2707(t10,t6,t1,((C_word*)t0)[2]);}

/* loop165 in k2468 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_fcall f_2707(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2707,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[52]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2740,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g185186 */
t10=t6;
((C_proc4)C_retrieve_proc(t10))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k2738 in loop165 in k2468 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2740,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2720,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_2720(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_2720(t5,t4);}}

/* k2718 in k2738 in loop165 in k2468 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_fcall f_2720(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop165179 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2707(t5,((C_word*)t0)[2],t3,t4);}

/* k2483 in k2468 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2661,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2663,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2663(t11,t7,((C_word*)t0)[3]);}

/* loop192 in k2483 in k2468 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_fcall f_2663(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2663,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2690,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_2690(C_a_i(&a,6),t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop192205 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop192205 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g208 in loop192 in k2483 in k2468 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static C_word C_fcall f_2690(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
return(C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k2659 in k2483 in k2468 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2655 in k2483 in k2468 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2657,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=C_i_cadr(((C_word*)t0)[9]);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],a[10]=t5,tmp=(C_word)a,a+=11,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2597,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2599,a[2]=t8,a[3]=t13,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t15=((C_word*)t13)[1];
f_2599(t15,t11,((C_word*)t0)[2]);}

/* loop220 in k2655 in k2483 in k2468 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_fcall f_2599(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2599,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_a_i_cons(&a,2,lf[57],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t8=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop220233 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop220233 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2595 in k2655 in k2483 in k2468 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2591 in k2655 in k2483 in k2468 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2593,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2533,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2537,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2539,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_2539(t12,t8,((C_word*)t0)[2]);}

/* loop248 in k2591 in k2655 in k2483 in k2468 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_fcall f_2539(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2539,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_a_i_cons(&a,2,lf[57],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t8=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop248261 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop248261 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2535 in k2591 in k2655 in k2483 in k2468 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2531 in k2591 in k2655 in k2483 in k2468 in k2465 in k2456 in k2453 in k2450 in k2447 in k2444 in k2441 in k2438 in a2435 in k701 in k698 */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2533,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=C_a_i_cons(&a,2,lf[73],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[6],t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[5],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,((C_word*)t0)[4],t10);
t12=C_a_i_cons(&a,2,((C_word*)t0)[9],t11);
t13=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_cons(&a,2,((C_word*)t0)[2],t12));}

/* k792 in k701 in k698 */
static void C_ccall f_794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_797,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1866,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2434,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t4,lf[62]);}

/* k2432 in k792 in k701 in k698 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2434,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[62],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##compiler#r-c-s */
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[72],((C_word*)t0)[2],t3);}

/* a1865 in k792 in k701 in k698 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1866,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1870,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm: 87   r */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[32]);}

/* k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 88   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[71]);}

/* k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm: 89   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[70]);}

/* k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm: 90   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[69]);}

/* k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler-syntax.scm: 91   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[68]);}

/* k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm: 92   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[67]);}

/* k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler-syntax.scm: 93   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[66]);}

/* k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler-syntax.scm: 94   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[65]);}

/* k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler-syntax.scm: 95   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[38]);}

/* k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* compiler-syntax.scm: 96   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[64]);}

/* k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* compiler-syntax.scm: 97   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1903,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* compiler-syntax.scm: 98   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[63]);}

/* k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* compiler-syntax.scm: 99   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[62]);}

/* k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
t2=C_i_cddr(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1915,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_i_memq(lf[58],C_retrieve(lf[59])))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[16],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm: 102  length+ */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t4,((C_word*)t0)[16]);}
else{
t4=t3;
f_1915(t4,C_SCHEME_FALSE);}}

/* k2420 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2422,2,t0,t1);}
if(C_truep(C_fixnum_greaterp(t1,C_fix(2)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2394,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
if(C_truep(C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm: 104  caadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[60]+1)))(3,*((C_word*)lf[60]+1),t4,((C_word*)t0)[4]);}
else{
t4=C_i_cadr(((C_word*)t0)[4]);
t5=((C_word*)t0)[5];
f_1915(t5,C_i_symbolp(t4));}}
else{
t2=((C_word*)t0)[5];
f_1915(t2,C_SCHEME_FALSE);}}

/* k2412 in k2420 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler-syntax.scm: 104  c */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2392 in k2420 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1915(t2,t1);}
else{
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_1915(t3,C_i_symbolp(t2));}}

/* k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_fcall f_1915(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1915,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2344,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2344(t10,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[12];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* loop314 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_fcall f_2344(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2344,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2378,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_list(&a,1,t4);
/* compiler-syntax.scm: 106  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[48]))(2,*((C_word*)lf[48]+1),t3);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2376 in loop314 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2378,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop314327 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2344(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop314327 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2344(t6,((C_word*)t0)[3],t5);}}

/* k1916 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1918,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[16],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[15],t4);
t6=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[14],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t5,t8);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t9,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],tmp=(C_word)a,a+=18,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2267,a[2]=t11,a[3]=t16,a[4]=t13,tmp=(C_word)a,a+=5,tmp));
t18=((C_word*)t16)[1];
f_2267(t18,t14,t1,((C_word*)t0)[2]);}

/* loop342 in k1916 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_fcall f_2267(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2267,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[52]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2300,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g362363 */
t10=t6;
((C_proc4)C_retrieve_proc(t10))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k2298 in loop342 in k1916 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2300,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2280,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_2280(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_2280(t5,t4);}}

/* k2278 in k2298 in loop342 in k1916 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_fcall f_2280(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop342356 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2267(t5,((C_word*)t0)[2],t3,t4);}

/* k1947 in k1916 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2217,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2221,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2223,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2223(t11,t7,((C_word*)t0)[3]);}

/* loop369 in k1947 in k1916 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_fcall f_2223(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2223,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2250,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_2250(C_a_i(&a,6),t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop369382 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop369382 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g385 in loop369 in k1947 in k1916 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static C_word C_fcall f_2250(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
return(C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k2219 in k1947 in k1916 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2215 in k1947 in k1916 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2217,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[17],t1);
t3=C_i_cadr(((C_word*)t0)[16]);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[15],t4);
t6=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=t5,tmp=(C_word)a,a+=17,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2157,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2159,a[2]=t8,a[3]=t13,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t15=((C_word*)t13)[1];
f_2159(t15,t11,((C_word*)t0)[2]);}

/* loop397 in k2215 in k1947 in k1916 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_fcall f_2159(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2159,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_a_i_cons(&a,2,lf[57],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t8=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop397410 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop397410 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2155 in k2215 in k1947 in k1916 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_2157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2151 in k2215 in k1947 in k1916 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2153,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[16],t1);
t3=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[15],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t2,t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[14],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,((C_word*)t0)[13],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,C_fix(1),t11);
t13=C_a_i_cons(&a,2,((C_word*)t0)[12],t12);
t14=C_a_i_cons(&a,2,lf[56],t13);
t15=C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t16=C_a_i_cons(&a,2,((C_word*)t0)[11],t15);
t17=C_a_i_cons(&a,2,((C_word*)t0)[10],t16);
t18=C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=C_a_i_cons(&a,2,t14,t18);
t20=C_a_i_cons(&a,2,((C_word*)t0)[12],t19);
t21=C_a_i_cons(&a,2,((C_word*)t0)[9],t20);
t22=C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t23=C_a_i_cons(&a,2,((C_word*)t0)[12],t22);
t24=C_a_i_cons(&a,2,((C_word*)t0)[10],t23);
t25=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=t10,a[10]=t21,a[11]=t24,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
t26=C_SCHEME_END_OF_LIST;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_FALSE;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2017,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_set_block_item(t32,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2019,a[2]=t27,a[3]=t32,a[4]=t29,tmp=(C_word)a,a+=5,tmp));
t34=((C_word*)t32)[1];
f_2019(t34,t30,((C_word*)t0)[2]);}

/* loop425 in k2151 in k2215 in k1947 in k1916 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_fcall f_2019(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2019,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_a_i_cons(&a,2,lf[57],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t8=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop425438 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop425438 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2015 in k2151 in k2215 in k1947 in k1916 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2011 in k2151 in k2215 in k1947 in k1916 in k1913 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1874 in k1871 in k1868 in a1865 in k792 in k701 in k698 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2013,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[12],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[11],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[9],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[8],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t7,t8);
t10=C_a_i_cons(&a,2,((C_word*)t0)[6],t9);
t11=C_a_i_cons(&a,2,((C_word*)t0)[5],t10);
t12=C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,((C_word*)t0)[4],t12);
t14=C_a_i_cons(&a,2,((C_word*)t0)[12],t13);
t15=C_a_i_cons(&a,2,((C_word*)t0)[8],t14);
t16=C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=C_a_i_cons(&a,2,((C_word*)t0)[3],t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_a_i_cons(&a,2,((C_word*)t0)[8],t17));}

/* k795 in k792 in k701 in k698 */
static void C_ccall f_797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_800,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1817,tmp=(C_word)a,a+=2,tmp);
/* ##compiler#r-c-s */
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),t2,lf[55],t3,C_SCHEME_END_OF_LIST);}

/* a1816 in k795 in k792 in k701 in k698 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1817,5,t0,t1,t2,t3,t4);}
t5=C_i_length(t2);
t6=C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?C_i_memq(lf[50],C_retrieve(lf[12])):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1827,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm: 128  r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[54]);}
else{
t8=t2;
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}

/* k1825 in a1816 in k795 in k792 in k701 in k698 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm: 129  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k1832 in k1825 in a1816 in k795 in k792 in k701 in k698 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1834,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1850,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_i_cdr(((C_word*)t0)[2]);
/* compiler-syntax.scm: 129  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[51]))(5,*((C_word*)lf[51]+1),t3,*((C_word*)lf[52]+1),((C_word*)t0)[4],t4);}

/* k1848 in k1832 in k1825 in a1816 in k795 in k792 in k701 in k698 */
static void C_ccall f_1850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1850,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_803,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1655,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1815,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t4,lf[18]);}

/* k1813 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1815,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[18],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[35]);}

/* k1809 in k1813 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1811,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[35],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[33]);}

/* k1805 in k1809 in k1813 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1807,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[33],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[31]);}

/* k1801 in k1805 in k1809 in k1813 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1803,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[29]);}

/* k1797 in k1801 in k1805 in k1809 in k1813 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1799,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[29],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[19]);}

/* k1793 in k1797 in k1801 in k1805 in k1809 in k1813 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1795,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[19],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[16]);}

/* k1789 in k1793 in k1797 in k1801 in k1805 in k1809 in k1813 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1791,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[16],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
/* ##compiler#r-c-s */
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[49],((C_word*)t0)[2],t9);}

/* a1654 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1655,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1659,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm: 134  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t5,lf[34]);}

/* k1657 in a1654 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1662,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[3]);
t4=C_i_memq(t3,lf[45]);
t5=(C_truep(t4)?lf[46]:lf[47]);
t6=C_i_cdr(((C_word*)t0)[3]);
/* compiler-syntax.scm: 135  compile-format-string */
((C_proc8)C_retrieve_symbol_proc(lf[11]))(8,*((C_word*)lf[11]+1),t2,t5,t1,((C_word*)t0)[3],t6,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1660 in k1657 in a1654 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1662,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm: 144  r */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[32]);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1670 in k1660 in k1657 in a1654 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1716,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 144  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[19]);}

/* k1714 in k1670 in k1660 in k1657 in a1654 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1716,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1696,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 146  r */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[16]);}

/* k1694 in k1714 in k1670 in k1660 in k1657 in a1654 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1696,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_806,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1544,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1653,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t4,lf[18]);}

/* k1651 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1653,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[18],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[35]);}

/* k1647 in k1651 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1649,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[35],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[33]);}

/* k1643 in k1647 in k1651 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1645,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[33],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[31]);}

/* k1639 in k1643 in k1647 in k1651 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1641,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[29]);}

/* k1635 in k1639 in k1643 in k1647 in k1651 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1637,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[29],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[19]);}

/* k1631 in k1635 in k1639 in k1643 in k1647 in k1651 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1633,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[19],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[16]);}

/* k1627 in k1631 in k1635 in k1639 in k1643 in k1647 in k1651 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1629,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[16],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
/* ##compiler#r-c-s */
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[44],((C_word*)t0)[2],t9);}

/* a1543 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1544,5,t0,t1,t2,t3,t4);}
t5=C_i_length(t2);
if(C_truep(C_fixnum_greater_or_equal_p(t5,C_fix(3)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1554,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cadr(t2);
t8=C_i_cddr(t2);
/* compiler-syntax.scm: 152  compile-format-string */
((C_proc8)C_retrieve_symbol_proc(lf[11]))(8,*((C_word*)lf[11]+1),t6,lf[33],t7,t2,t8,t3,t4);}
else{
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k1552 in a1543 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1447,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1542,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t4,lf[18]);}

/* k1540 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1542,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[18],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[35]);}

/* k1536 in k1540 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1538,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[35],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[33]);}

/* k1532 in k1536 in k1540 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1534,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[33],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[31]);}

/* k1528 in k1532 in k1536 in k1540 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1530,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[29]);}

/* k1524 in k1528 in k1532 in k1536 in k1540 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1526,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[29],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[19]);}

/* k1520 in k1524 in k1528 in k1532 in k1536 in k1540 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1522,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[19],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[16]);}

/* k1516 in k1520 in k1524 in k1528 in k1532 in k1536 in k1540 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1518,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[16],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
/* ##compiler#r-c-s */
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[42],((C_word*)t0)[2],t9);}

/* a1446 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1447,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1451,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cdr(t2);
/* compiler-syntax.scm: 161  compile-format-string */
((C_proc8)C_retrieve_symbol_proc(lf[11]))(8,*((C_word*)lf[11]+1),t5,lf[40],lf[41],t2,t6,t3,t4);}

/* k1449 in a1446 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_809,2,t0,t1);}
t2=C_mutate((C_word*)lf[11]+1 /* (set! ##compiler#compile-format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_811,tmp=(C_word)a,a+=2,tmp));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=8) C_bad_argc_2(c,8,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_811,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_817,a[2]=t7,a[3]=t6,a[4]=t3,a[5]=t4,a[6]=t2,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm: 168  call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[39]+1)))(3,*((C_word*)lf[39]+1),t1,t8);}

/* a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_817(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_817,3,t0,t1,t2);}
t3=C_i_length(((C_word*)t0)[7]);
if(C_truep(C_fixnum_greater_or_equal_p(t3,C_fix(1)))){
if(C_truep(C_i_memq(((C_word*)t0)[6],C_retrieve(lf[12])))){
t4=C_i_car(((C_word*)t0)[7]);
t5=C_i_stringp(t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_839,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_839(t7,t5);}
else{
t7=C_i_car(((C_word*)t0)[7]);
if(C_truep(C_i_listp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1418,a[2]=((C_word*)t0)[7],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1429,a[2]=((C_word*)t0)[7],a[3]=t8,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm: 174  r */
t10=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[38]);}
else{
t8=t6;
f_839(t8,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1427 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1433,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm: 174  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[37]+1)))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[2]);}

/* k1431 in k1427 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler-syntax.scm: 174  c */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1416 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1418,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1425,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* compiler-syntax.scm: 175  cadar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_839(t2,C_SCHEME_FALSE);}}

/* k1423 in k1416 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_839(t2,C_i_stringp(t1));}

/* k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_fcall f_839(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_839,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_i_car(((C_word*)t0)[8]);
if(C_truep(C_i_stringp(t3))){
t4=t2;
f_842(2,t4,C_i_car(((C_word*)t0)[8]));}
else{
/* compiler-syntax.scm: 176  cadar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)t0)[8]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_842,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[8]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_847,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_i_string_length(t1);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t10,a[6]=t7,a[7]=t5,a[8]=t4,a[9]=t9,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm: 190  r */
t12=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,lf[18]);}

/* k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler-syntax.scm: 191  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[35]);}

/* k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler-syntax.scm: 192  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[29]);}

/* k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler-syntax.scm: 193  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[34]);}

/* k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* compiler-syntax.scm: 194  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[33]);}

/* k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* compiler-syntax.scm: 195  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[32]);}

/* k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_903,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* compiler-syntax.scm: 196  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[31]);}

/* k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[47],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_903,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_905,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_915,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp));
t12=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_934,a[2]=((C_word*)t0)[9],a[3]=t9,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp));
t13=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_987,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_997,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=t5,a[7]=t9,a[8]=((C_word*)t0)[4],a[9]=t15,a[10]=t3,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t7,a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[5],a[16]=((C_word*)t0)[11],a[17]=((C_word*)t0)[6],a[18]=((C_word*)t0)[7],a[19]=((C_word*)t0)[14],tmp=(C_word)a,a+=20,tmp));
t17=((C_word*)t15)[1];
f_997(t17,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_fcall f_997(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_997,NULL,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[19])[1];
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[18]))){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1007,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t1,a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[12])[1]))){
t5=t4;
f_1007(2,t5,C_SCHEME_UNDEFINED);}
else{
/* compiler-syntax.scm: 218  fail */
t5=((C_word*)t0)[11];
f_847(t5,t4,C_SCHEME_FALSE,lf[26],C_SCHEME_END_OF_LIST);}}
else{
t4=f_905(((C_word*)((C_word*)t0)[10])[1]);
t5=C_eqp(t4,C_make_character(126));
if(C_truep(t5)){
t6=f_905(((C_word*)((C_word*)t0)[10])[1]);
t7=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1058,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[19],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[16],a[13]=t1,a[14]=((C_word*)t0)[9],a[15]=t6,tmp=(C_word)a,a+=16,tmp);
/* compiler-syntax.scm: 226  endchunk */
t8=((C_word*)((C_word*)t0)[13])[1];
f_934(t8,t7,t2);}
else{
t6=C_a_i_cons(&a,2,t4,t2);
/* compiler-syntax.scm: 249  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k1056 in loop in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1058,2,t0,t1);}
t2=C_u_i_char_upcase(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1064,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
switch(t2){
case C_make_character(83):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1085,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 228  next */
t5=((C_word*)((C_word*)t0)[9])[1];
f_915(t5,t4);
case C_make_character(65):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1110,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 229  next */
t5=((C_word*)((C_word*)t0)[9])[1];
f_915(t5,t4);
case C_make_character(67):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1135,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 230  next */
t5=((C_word*)((C_word*)t0)[9])[1];
f_915(t5,t4);
case C_make_character(66):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1172,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm: 231  next */
t5=((C_word*)((C_word*)t0)[9])[1];
f_915(t5,t4);
case C_make_character(79):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1209,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm: 232  next */
t5=((C_word*)((C_word*)t0)[9])[1];
f_915(t5,t4);
case C_make_character(88):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1246,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm: 233  next */
t5=((C_word*)((C_word*)t0)[9])[1];
f_915(t5,t4);
case C_make_character(33):
t4=C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[27],t4);
t6=f_987(C_a_i(&a,3),((C_word*)((C_word*)t0)[10])[1],t5);
/* compiler-syntax.scm: 248  loop */
t7=((C_word*)((C_word*)t0)[14])[1];
f_997(t7,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
case C_make_character(63):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1276,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm: 236  next */
t5=((C_word*)((C_word*)t0)[9])[1];
f_915(t5,t4);
case C_make_character(126):
t4=C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,C_make_character(126),t4);
t6=C_a_i_cons(&a,2,*((C_word*)lf[29]+1),t5);
t7=f_987(C_a_i(&a,3),((C_word*)((C_word*)t0)[10])[1],t6);
/* compiler-syntax.scm: 248  loop */
t8=((C_word*)((C_word*)t0)[14])[1];
f_997(t8,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
default:
t4=C_eqp(t2,C_make_character(37));
t5=(C_truep(t4)?t4:C_eqp(t2,C_make_character(78)));
if(C_truep(t5)){
t6=C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,C_make_character(10),t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
t9=f_987(C_a_i(&a,3),((C_word*)((C_word*)t0)[10])[1],t8);
/* compiler-syntax.scm: 248  loop */
t10=((C_word*)((C_word*)t0)[14])[1];
f_997(t10,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);}
else{
if(C_truep(C_u_i_char_whitespacep(((C_word*)t0)[15]))){
t6=f_905(((C_word*)((C_word*)t0)[4])[1]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1362,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=f_1362(t7,t6);
/* compiler-syntax.scm: 248  loop */
t9=((C_word*)((C_word*)t0)[14])[1];
f_997(t9,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);}
else{
/* compiler-syntax.scm: 247  fail */
t6=((C_word*)t0)[2];
f_847(t6,t3,C_SCHEME_TRUE,lf[30],C_a_i_list(&a,1,((C_word*)t0)[15]));}}}}

/* skip in k1056 in loop in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static C_word C_fcall f_1362(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep(C_u_i_char_whitespacep(t1))){
t2=f_905(((C_word*)((C_word*)t0)[3])[1]);
t6=t2;
t1=t6;
goto loop;}
else{
t2=C_fixnum_decrease(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

/* k1274 in k1056 in loop in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1279,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm: 237  next */
t3=((C_word*)((C_word*)t0)[2])[1];
f_915(t3,t2);}

/* k1277 in k1274 in k1056 in loop in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1279,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=C_a_i_cons(&a,2,lf[28],t5);
t7=f_987(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t6);
/* compiler-syntax.scm: 248  loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_997(t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1244 in k1056 in loop in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1246,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_fix(16),C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=f_987(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t7);
/* compiler-syntax.scm: 248  loop */
t9=((C_word*)((C_word*)t0)[3])[1];
f_997(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1207 in k1056 in loop in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1209,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_fix(8),C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=f_987(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t7);
/* compiler-syntax.scm: 248  loop */
t9=((C_word*)((C_word*)t0)[3])[1];
f_997(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1170 in k1056 in loop in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1172,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_fix(2),C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=f_987(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t7);
/* compiler-syntax.scm: 248  loop */
t9=((C_word*)((C_word*)t0)[3])[1];
f_997(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1133 in k1056 in loop in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1135,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=f_987(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t4);
/* compiler-syntax.scm: 248  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_997(t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1108 in k1056 in loop in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1110,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=f_987(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t4);
/* compiler-syntax.scm: 248  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_997(t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1083 in k1056 in loop in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1085,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=f_987(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t4);
/* compiler-syntax.scm: 248  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_997(t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1062 in k1056 in loop in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler-syntax.scm: 248  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_997(t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1005 in loop in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1010,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm: 219  endchunk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_934(t3,t2,((C_word*)t0)[2]);}

/* k1008 in k1005 in loop in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1010,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1025,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1029,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* compiler-syntax.scm: 221  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[25]+1)))(3,*((C_word*)lf[25]+1),t6,((C_word*)((C_word*)t0)[2])[1]);}

/* k1027 in k1008 in k1005 in loop in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1023 in k1008 in k1005 in loop in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1025,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* push in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static C_word C_fcall f_987(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}

/* endchunk in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_fcall f_934(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_934,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_i_length(t2);
t4=C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=C_i_car(t2);
t6=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,t5,t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
/* compiler-syntax.scm: 209  push */
t9=t1;
((C_proc2)C_retrieve_proc(t9))(2,t9,f_987(C_a_i(&a,3),((C_word*)((C_word*)t0)[3])[1],t8));}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_977,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm: 212  reverse-list->string */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t5,t2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k975 in endchunk in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_977,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
/* compiler-syntax.scm: 209  push */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,f_987(C_a_i(&a,3),((C_word*)((C_word*)t0)[2])[1],t4));}

/* next in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_fcall f_915(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_915,NULL,2,t0,t1);}
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
/* compiler-syntax.scm: 203  fail */
t2=((C_word*)t0)[2];
f_847(t2,t1,C_SCHEME_TRUE,lf[22],C_SCHEME_END_OF_LIST);}
else{
t2=C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* fetch in k901 in k898 in k895 in k892 in k889 in k886 in k883 in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static C_word C_fcall f_905(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t1=C_i_string_ref(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t2=C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t1);}

/* fail in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_fcall f_847(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_847,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_851,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm: 179  get-line */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t5,((C_word*)t0)[2]);}

/* k849 in fail in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_854,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_867,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[19]))(2,*((C_word*)lf[19]+1),t4);}
else{
/* compiler-syntax.scm: 180  compiler-warning */
((C_proc9)C_retrieve_symbol_proc(lf[13]))(9,*((C_word*)lf[13]+1),t2,lf[14],lf[15],((C_word*)t0)[5],((C_word*)t0)[4],lf[20],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k865 in k849 in fail in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_870,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[17]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(40),t1);}

/* k868 in k865 in k849 in fail in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_873,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[18]+1)))(4,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k871 in k868 in k865 in k849 in fail in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[17]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(41),((C_word*)t0)[2]);}

/* k874 in k871 in k868 in k865 in k849 in fail in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k862 in k849 in fail in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compiler-syntax.scm: 180  compiler-warning */
((C_proc9)C_retrieve_symbol_proc(lf[13]))(9,*((C_word*)lf[13]+1),((C_word*)t0)[6],lf[14],lf[15],((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k852 in k849 in fail in k840 in k837 in a816 in ##compiler#compile-format-string in k807 in k804 in k801 in k798 in k795 in k792 in k701 in k698 */
static void C_ccall f_854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* compiler-syntax.scm: 186  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#r-c-s in k701 in k698 */
static void C_ccall f_720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_720r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_720r(t0,t1,t2,t3,t4);}}

static void C_ccall f_720r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_724,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_724(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_724(2,t7,C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[10],t4);}}}

/* k722 in ##compiler#r-c-s in k701 in k698 */
static void C_ccall f_724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_772,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm: 46   ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),t2,((C_word*)t0)[2]);}

/* k770 in k722 in ##compiler#r-c-s in k701 in k698 */
static void C_ccall f_772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_772,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=C_i_symbolp(((C_word*)t0)[3]);
t4=(C_truep(t3)?C_a_i_list(&a,1,((C_word*)t0)[3]):((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_736,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_736(t8,((C_word*)t0)[2],t4);}

/* loop52 in k770 in k722 in ##compiler#r-c-s in k701 in k698 */
static void C_fcall f_736(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_736,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_744,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_751,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g5960 */
t6=t3;
f_744(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k749 in loop52 in k770 in k722 in ##compiler#r-c-s in k701 in k698 */
static void C_ccall f_751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_736(t3,((C_word*)t0)[2],t2);}

/* g59 in loop52 in k770 in k722 in ##compiler#r-c-s in k701 in k698 */
static void C_fcall f_744(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_744,NULL,3,t0,t1,t2);}
/* compiler-syntax.scm: 49   ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t1,t2,lf[7],((C_word*)t0)[2]);}

/* ##sys#compiler-syntax-hook in k701 in k698 */
static void C_ccall f_706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_706,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_710,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* compiler-syntax.scm: 41   alist-ref */
((C_proc6)C_retrieve_symbol_proc(lf[3]))(6,*((C_word*)lf[3]+1),t4,t2,*((C_word*)lf[0]+1),*((C_word*)lf[4]+1),C_fix(0));}

/* k708 in ##sys#compiler-syntax-hook in k701 in k698 */
static void C_ccall f_710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_714,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_fixnum_increase(t1);
/* compiler-syntax.scm: 43   alist-update! */
((C_proc5)C_retrieve_symbol_proc(lf[2]))(5,*((C_word*)lf[2]+1),t2,((C_word*)t0)[2],t3,*((C_word*)lf[0]+1));}

/* k712 in k708 in ##sys#compiler-syntax-hook in k701 in k698 */
static void C_ccall f_714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[0]+1 /* (set! ##compiler#compiler-syntax-statistics ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[164] = {
{"toplevel:compiler_syntax_scm",(void*)C_compiler_syntax_toplevel},
{"f_700:compiler_syntax_scm",(void*)f_700},
{"f_703:compiler_syntax_scm",(void*)f_703},
{"f_2846:compiler_syntax_scm",(void*)f_2846},
{"f_2436:compiler_syntax_scm",(void*)f_2436},
{"f_2440:compiler_syntax_scm",(void*)f_2440},
{"f_2443:compiler_syntax_scm",(void*)f_2443},
{"f_2446:compiler_syntax_scm",(void*)f_2446},
{"f_2449:compiler_syntax_scm",(void*)f_2449},
{"f_2452:compiler_syntax_scm",(void*)f_2452},
{"f_2455:compiler_syntax_scm",(void*)f_2455},
{"f_2458:compiler_syntax_scm",(void*)f_2458},
{"f_2834:compiler_syntax_scm",(void*)f_2834},
{"f_2826:compiler_syntax_scm",(void*)f_2826},
{"f_2806:compiler_syntax_scm",(void*)f_2806},
{"f_2467:compiler_syntax_scm",(void*)f_2467},
{"f_2756:compiler_syntax_scm",(void*)f_2756},
{"f_2790:compiler_syntax_scm",(void*)f_2790},
{"f_2470:compiler_syntax_scm",(void*)f_2470},
{"f_2707:compiler_syntax_scm",(void*)f_2707},
{"f_2740:compiler_syntax_scm",(void*)f_2740},
{"f_2720:compiler_syntax_scm",(void*)f_2720},
{"f_2485:compiler_syntax_scm",(void*)f_2485},
{"f_2663:compiler_syntax_scm",(void*)f_2663},
{"f_2690:compiler_syntax_scm",(void*)f_2690},
{"f_2661:compiler_syntax_scm",(void*)f_2661},
{"f_2657:compiler_syntax_scm",(void*)f_2657},
{"f_2599:compiler_syntax_scm",(void*)f_2599},
{"f_2597:compiler_syntax_scm",(void*)f_2597},
{"f_2593:compiler_syntax_scm",(void*)f_2593},
{"f_2539:compiler_syntax_scm",(void*)f_2539},
{"f_2537:compiler_syntax_scm",(void*)f_2537},
{"f_2533:compiler_syntax_scm",(void*)f_2533},
{"f_794:compiler_syntax_scm",(void*)f_794},
{"f_2434:compiler_syntax_scm",(void*)f_2434},
{"f_1866:compiler_syntax_scm",(void*)f_1866},
{"f_1870:compiler_syntax_scm",(void*)f_1870},
{"f_1873:compiler_syntax_scm",(void*)f_1873},
{"f_1876:compiler_syntax_scm",(void*)f_1876},
{"f_1879:compiler_syntax_scm",(void*)f_1879},
{"f_1882:compiler_syntax_scm",(void*)f_1882},
{"f_1885:compiler_syntax_scm",(void*)f_1885},
{"f_1888:compiler_syntax_scm",(void*)f_1888},
{"f_1891:compiler_syntax_scm",(void*)f_1891},
{"f_1894:compiler_syntax_scm",(void*)f_1894},
{"f_1897:compiler_syntax_scm",(void*)f_1897},
{"f_1900:compiler_syntax_scm",(void*)f_1900},
{"f_1903:compiler_syntax_scm",(void*)f_1903},
{"f_1906:compiler_syntax_scm",(void*)f_1906},
{"f_2422:compiler_syntax_scm",(void*)f_2422},
{"f_2414:compiler_syntax_scm",(void*)f_2414},
{"f_2394:compiler_syntax_scm",(void*)f_2394},
{"f_1915:compiler_syntax_scm",(void*)f_1915},
{"f_2344:compiler_syntax_scm",(void*)f_2344},
{"f_2378:compiler_syntax_scm",(void*)f_2378},
{"f_1918:compiler_syntax_scm",(void*)f_1918},
{"f_2267:compiler_syntax_scm",(void*)f_2267},
{"f_2300:compiler_syntax_scm",(void*)f_2300},
{"f_2280:compiler_syntax_scm",(void*)f_2280},
{"f_1949:compiler_syntax_scm",(void*)f_1949},
{"f_2223:compiler_syntax_scm",(void*)f_2223},
{"f_2250:compiler_syntax_scm",(void*)f_2250},
{"f_2221:compiler_syntax_scm",(void*)f_2221},
{"f_2217:compiler_syntax_scm",(void*)f_2217},
{"f_2159:compiler_syntax_scm",(void*)f_2159},
{"f_2157:compiler_syntax_scm",(void*)f_2157},
{"f_2153:compiler_syntax_scm",(void*)f_2153},
{"f_2019:compiler_syntax_scm",(void*)f_2019},
{"f_2017:compiler_syntax_scm",(void*)f_2017},
{"f_2013:compiler_syntax_scm",(void*)f_2013},
{"f_797:compiler_syntax_scm",(void*)f_797},
{"f_1817:compiler_syntax_scm",(void*)f_1817},
{"f_1827:compiler_syntax_scm",(void*)f_1827},
{"f_1834:compiler_syntax_scm",(void*)f_1834},
{"f_1850:compiler_syntax_scm",(void*)f_1850},
{"f_800:compiler_syntax_scm",(void*)f_800},
{"f_1815:compiler_syntax_scm",(void*)f_1815},
{"f_1811:compiler_syntax_scm",(void*)f_1811},
{"f_1807:compiler_syntax_scm",(void*)f_1807},
{"f_1803:compiler_syntax_scm",(void*)f_1803},
{"f_1799:compiler_syntax_scm",(void*)f_1799},
{"f_1795:compiler_syntax_scm",(void*)f_1795},
{"f_1791:compiler_syntax_scm",(void*)f_1791},
{"f_1655:compiler_syntax_scm",(void*)f_1655},
{"f_1659:compiler_syntax_scm",(void*)f_1659},
{"f_1662:compiler_syntax_scm",(void*)f_1662},
{"f_1672:compiler_syntax_scm",(void*)f_1672},
{"f_1716:compiler_syntax_scm",(void*)f_1716},
{"f_1696:compiler_syntax_scm",(void*)f_1696},
{"f_803:compiler_syntax_scm",(void*)f_803},
{"f_1653:compiler_syntax_scm",(void*)f_1653},
{"f_1649:compiler_syntax_scm",(void*)f_1649},
{"f_1645:compiler_syntax_scm",(void*)f_1645},
{"f_1641:compiler_syntax_scm",(void*)f_1641},
{"f_1637:compiler_syntax_scm",(void*)f_1637},
{"f_1633:compiler_syntax_scm",(void*)f_1633},
{"f_1629:compiler_syntax_scm",(void*)f_1629},
{"f_1544:compiler_syntax_scm",(void*)f_1544},
{"f_1554:compiler_syntax_scm",(void*)f_1554},
{"f_806:compiler_syntax_scm",(void*)f_806},
{"f_1542:compiler_syntax_scm",(void*)f_1542},
{"f_1538:compiler_syntax_scm",(void*)f_1538},
{"f_1534:compiler_syntax_scm",(void*)f_1534},
{"f_1530:compiler_syntax_scm",(void*)f_1530},
{"f_1526:compiler_syntax_scm",(void*)f_1526},
{"f_1522:compiler_syntax_scm",(void*)f_1522},
{"f_1518:compiler_syntax_scm",(void*)f_1518},
{"f_1447:compiler_syntax_scm",(void*)f_1447},
{"f_1451:compiler_syntax_scm",(void*)f_1451},
{"f_809:compiler_syntax_scm",(void*)f_809},
{"f_811:compiler_syntax_scm",(void*)f_811},
{"f_817:compiler_syntax_scm",(void*)f_817},
{"f_1429:compiler_syntax_scm",(void*)f_1429},
{"f_1433:compiler_syntax_scm",(void*)f_1433},
{"f_1418:compiler_syntax_scm",(void*)f_1418},
{"f_1425:compiler_syntax_scm",(void*)f_1425},
{"f_839:compiler_syntax_scm",(void*)f_839},
{"f_842:compiler_syntax_scm",(void*)f_842},
{"f_885:compiler_syntax_scm",(void*)f_885},
{"f_888:compiler_syntax_scm",(void*)f_888},
{"f_891:compiler_syntax_scm",(void*)f_891},
{"f_894:compiler_syntax_scm",(void*)f_894},
{"f_897:compiler_syntax_scm",(void*)f_897},
{"f_900:compiler_syntax_scm",(void*)f_900},
{"f_903:compiler_syntax_scm",(void*)f_903},
{"f_997:compiler_syntax_scm",(void*)f_997},
{"f_1058:compiler_syntax_scm",(void*)f_1058},
{"f_1362:compiler_syntax_scm",(void*)f_1362},
{"f_1276:compiler_syntax_scm",(void*)f_1276},
{"f_1279:compiler_syntax_scm",(void*)f_1279},
{"f_1246:compiler_syntax_scm",(void*)f_1246},
{"f_1209:compiler_syntax_scm",(void*)f_1209},
{"f_1172:compiler_syntax_scm",(void*)f_1172},
{"f_1135:compiler_syntax_scm",(void*)f_1135},
{"f_1110:compiler_syntax_scm",(void*)f_1110},
{"f_1085:compiler_syntax_scm",(void*)f_1085},
{"f_1064:compiler_syntax_scm",(void*)f_1064},
{"f_1007:compiler_syntax_scm",(void*)f_1007},
{"f_1010:compiler_syntax_scm",(void*)f_1010},
{"f_1029:compiler_syntax_scm",(void*)f_1029},
{"f_1025:compiler_syntax_scm",(void*)f_1025},
{"f_987:compiler_syntax_scm",(void*)f_987},
{"f_934:compiler_syntax_scm",(void*)f_934},
{"f_977:compiler_syntax_scm",(void*)f_977},
{"f_915:compiler_syntax_scm",(void*)f_915},
{"f_905:compiler_syntax_scm",(void*)f_905},
{"f_847:compiler_syntax_scm",(void*)f_847},
{"f_851:compiler_syntax_scm",(void*)f_851},
{"f_867:compiler_syntax_scm",(void*)f_867},
{"f_870:compiler_syntax_scm",(void*)f_870},
{"f_873:compiler_syntax_scm",(void*)f_873},
{"f_876:compiler_syntax_scm",(void*)f_876},
{"f_864:compiler_syntax_scm",(void*)f_864},
{"f_854:compiler_syntax_scm",(void*)f_854},
{"f_720:compiler_syntax_scm",(void*)f_720},
{"f_724:compiler_syntax_scm",(void*)f_724},
{"f_772:compiler_syntax_scm",(void*)f_772},
{"f_736:compiler_syntax_scm",(void*)f_736},
{"f_751:compiler_syntax_scm",(void*)f_751},
{"f_744:compiler_syntax_scm",(void*)f_744},
{"f_706:compiler_syntax_scm",(void*)f_706},
{"f_710:compiler_syntax_scm",(void*)f_710},
{"f_714:compiler_syntax_scm",(void*)f_714},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
