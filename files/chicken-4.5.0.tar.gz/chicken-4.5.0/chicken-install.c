/* Generated from chicken-install.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:54
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: chicken-install.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -ignore-repository -output-file chicken-install.c
   used units: library eval srfi_1 posix data_structures utils regex ports extras srfi_13 files chicken_syntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[310];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1324)
static void C_ccall f_1324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1330)
static void C_ccall f_1330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1333)
static void C_ccall f_1333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1339)
static void C_ccall f_1339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1353)
static void C_ccall f_1353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1356)
static void C_ccall f_1356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1359)
static void C_ccall f_1359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4512)
static void C_ccall f_4512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4526)
static void C_ccall f_4526(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4571)
static void C_ccall f_4571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1570)
static void C_ccall f_1570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1407)
static void C_fcall f_1407(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1415)
static void C_fcall f_1415(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_fcall f_1460(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1525)
static void C_ccall f_1525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1487)
static void C_fcall f_1487(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1491)
static void C_ccall f_1491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1494)
static void C_ccall f_1494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1432)
static void C_ccall f_1432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1388)
static void C_fcall f_1388(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3690)
static void C_ccall f_3690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3698)
static void C_fcall f_3698(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3826)
static void C_fcall f_3826(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4301)
static void C_fcall f_4301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4453)
static void C_ccall f_4453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4411)
static void C_ccall f_4411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4415)
static void C_fcall f_4415(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4427)
static void C_ccall f_4427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4366)
static void C_ccall f_4366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4389)
static void C_ccall f_4389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4405)
static void C_ccall f_4405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4966)
static void C_ccall f4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4342)
static void C_ccall f_4342(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4961)
static void C_ccall f4961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4333)
static void C_ccall f_4333(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4327)
static void C_ccall f_4327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4323)
static void C_ccall f_4323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4956)
static void C_ccall f4956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4274)
static void C_ccall f_4274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4951)
static void C_ccall f4951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4946)
static void C_ccall f4946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4127)
static void C_ccall f_4127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4130)
static void C_ccall f_4130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4933)
static void C_ccall f4933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static void C_fcall f_1669(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1677)
static void C_fcall f_1677(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4069)
static void C_ccall f_4069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4926)
static void C_ccall f4926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4018)
static void C_ccall f_4018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4921)
static void C_ccall f4921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4916)
static void C_ccall f4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3838)
static void C_ccall f_3838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4911)
static void C_ccall f4911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3746)
static void C_ccall f_3746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3762)
static void C_fcall f_3762(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3797)
static void C_ccall f_3797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3760)
static void C_ccall f_3760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3756)
static void C_ccall f_3756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3717)
static void C_ccall f_3717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3728)
static void C_ccall f_3728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3140)
static void C_ccall f_3140(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_fcall f_2969(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3113)
static void C_ccall f_3113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2977)
static void C_fcall f_2977(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3097)
static void C_ccall f_3097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3081)
static void C_fcall f_3081(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3084)
static void C_ccall f_3084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_fcall f_2828(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2835)
static void C_ccall f_2835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2844)
static void C_ccall f_2844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2847)
static void C_ccall f_2847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2909)
static void C_ccall f_2909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3014)
static void C_ccall f_3014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3528)
static void C_ccall f_3528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3178)
static void C_ccall f_3178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3403)
static void C_ccall f_3403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3409)
static void C_fcall f_3409(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3417)
static void C_fcall f_3417(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3501)
static void C_ccall f_3501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3489)
static void C_ccall f_3489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3449)
static void C_ccall f_3449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3462)
static void C_ccall f_3462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3398)
static void C_ccall f_3398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3184)
static void C_ccall f_3184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3275)
static void C_ccall f_3275(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3282)
static void C_ccall f_3282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3296)
static void C_ccall f_3296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3354)
static void C_fcall f_3354(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3381)
static C_word C_fcall f_3381(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_fcall f_3310(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3337)
static C_word C_fcall f_3337(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_fcall f_3218(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4575)
static void C_ccall f_4575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_ccall f_4532(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4542)
static void C_ccall f_4542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4545)
static void C_ccall f_4545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4515)
static void C_ccall f_4515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4518)
static void C_ccall f_4518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_fcall f_3664(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3642)
static void C_fcall f_3642(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3646)
static void C_ccall f_3646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3534)
static void C_fcall f_3534(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3626)
static void C_ccall f_3626(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3632)
static void C_ccall f_3632(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_fcall f_3585(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3545)
static void C_ccall f_3545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_fcall f_3150(C_word t0) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_fcall f_2298(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2302)
static void C_ccall f_2302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_fcall f_2572(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1613)
static void C_fcall f_1613(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1610)
static void C_ccall f_1610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1606)
static void C_fcall f_1606(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_fcall f_2139(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2141)
static void C_fcall f_2141(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2205)
static void C_ccall f_2205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2157)
static void C_fcall f_2157(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_fcall f_2160(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2171)
static void C_ccall f_2171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2114)
static void C_ccall f_2114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_fcall f_2029(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2041)
static void C_fcall f_2041(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2053)
static void C_fcall f_2053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2313)
static void C_fcall f_2313(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2335)
static void C_ccall f_2335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2347)
static void C_ccall f_2347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2691)
static void C_ccall f_2691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2726)
static void C_fcall f_2726(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_fcall f_2666(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2364)
static void C_ccall f_2364(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2369)
static void C_ccall f_2369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2473)
static void C_fcall f_2473(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2483)
static void C_fcall f_2483(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_fcall f_2228(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2429)
static void C_ccall f_2429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2396)
static void C_fcall f_2396(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2408)
static void C_ccall f_2408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_fcall f_1791(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1847)
static void C_fcall f_1847(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1809)
static void C_ccall f_1809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1709)
static void C_fcall f_1709(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1719)
static void C_fcall f_1719(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1639)
static C_word C_fcall f_1639(C_word t0,C_word t1);

C_noret_decl(trf_1407)
static void C_fcall trf_1407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1407(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1407(t0,t1,t2);}

C_noret_decl(trf_1415)
static void C_fcall trf_1415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1415(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1415(t0,t1,t2);}

C_noret_decl(trf_1460)
static void C_fcall trf_1460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1460(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1460(t0,t1,t2);}

C_noret_decl(trf_1487)
static void C_fcall trf_1487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1487(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1487(t0,t1,t2);}

C_noret_decl(trf_1388)
static void C_fcall trf_1388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1388(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1388(t0,t1,t2);}

C_noret_decl(trf_3698)
static void C_fcall trf_3698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3698(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3698(t0,t1,t2,t3);}

C_noret_decl(trf_3826)
static void C_fcall trf_3826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3826(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3826(t0,t1);}

C_noret_decl(trf_4301)
static void C_fcall trf_4301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4301(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4301(t0,t1);}

C_noret_decl(trf_4415)
static void C_fcall trf_4415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4415(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4415(t0,t1,t2);}

C_noret_decl(trf_1669)
static void C_fcall trf_1669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1669(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1669(t0,t1,t2);}

C_noret_decl(trf_1677)
static void C_fcall trf_1677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1677(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1677(t0,t1,t2);}

C_noret_decl(trf_3762)
static void C_fcall trf_3762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3762(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3762(t0,t1,t2);}

C_noret_decl(trf_2969)
static void C_fcall trf_2969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2969(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2969(t0,t1,t2,t3);}

C_noret_decl(trf_2977)
static void C_fcall trf_2977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2977(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2977(t0,t1,t2,t3);}

C_noret_decl(trf_3081)
static void C_fcall trf_3081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3081(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3081(t0,t1);}

C_noret_decl(trf_2828)
static void C_fcall trf_2828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2828(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2828(t0,t1);}

C_noret_decl(trf_3409)
static void C_fcall trf_3409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3409(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3409(t0,t1,t2);}

C_noret_decl(trf_3417)
static void C_fcall trf_3417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3417(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3417(t0,t1,t2);}

C_noret_decl(trf_3354)
static void C_fcall trf_3354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3354(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3354(t0,t1,t2);}

C_noret_decl(trf_3310)
static void C_fcall trf_3310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3310(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3310(t0,t1,t2);}

C_noret_decl(trf_3218)
static void C_fcall trf_3218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3218(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3218(t0,t1,t2);}

C_noret_decl(trf_3664)
static void C_fcall trf_3664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3664(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3664(t0,t1,t2);}

C_noret_decl(trf_3642)
static void C_fcall trf_3642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3642(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3642(t0,t1);}

C_noret_decl(trf_3534)
static void C_fcall trf_3534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3534(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3534(t0,t1);}

C_noret_decl(trf_3585)
static void C_fcall trf_3585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3585(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3585(t0,t1,t2);}

C_noret_decl(trf_3150)
static void C_fcall trf_3150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3150(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3150(t0);}

C_noret_decl(trf_2298)
static void C_fcall trf_2298(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2298(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2298(t0,t1);}

C_noret_decl(trf_2572)
static void C_fcall trf_2572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2572(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2572(t0,t1,t2);}

C_noret_decl(trf_1613)
static void C_fcall trf_1613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1613(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1613(t0,t1);}

C_noret_decl(trf_1606)
static void C_fcall trf_1606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1606(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1606(t0,t1);}

C_noret_decl(trf_2139)
static void C_fcall trf_2139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2139(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2139(t0,t1);}

C_noret_decl(trf_2141)
static void C_fcall trf_2141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2141(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2141(t0,t1,t2);}

C_noret_decl(trf_2157)
static void C_fcall trf_2157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2157(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2157(t0,t1);}

C_noret_decl(trf_2160)
static void C_fcall trf_2160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2160(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2160(t0,t1);}

C_noret_decl(trf_2029)
static void C_fcall trf_2029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2029(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2029(t0,t1);}

C_noret_decl(trf_2041)
static void C_fcall trf_2041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2041(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2041(t0,t1);}

C_noret_decl(trf_2053)
static void C_fcall trf_2053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2053(t0,t1);}

C_noret_decl(trf_2313)
static void C_fcall trf_2313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2313(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2313(t0,t1,t2);}

C_noret_decl(trf_2726)
static void C_fcall trf_2726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2726(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2726(t0,t1);}

C_noret_decl(trf_2666)
static void C_fcall trf_2666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2666(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2666(t0,t1);}

C_noret_decl(trf_2473)
static void C_fcall trf_2473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2473(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2473(t0,t1,t2);}

C_noret_decl(trf_2483)
static void C_fcall trf_2483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2483(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2483(t0,t1);}

C_noret_decl(trf_2228)
static void C_fcall trf_2228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2228(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2228(t0,t1,t2);}

C_noret_decl(trf_2396)
static void C_fcall trf_2396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2396(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2396(t0,t1,t2);}

C_noret_decl(trf_1791)
static void C_fcall trf_1791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1791(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1791(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1847)
static void C_fcall trf_1847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1847(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1847(t0,t1);}

C_noret_decl(trf_1709)
static void C_fcall trf_1709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1709(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1709(t0,t1);}

C_noret_decl(trf_1719)
static void C_fcall trf_1719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1719(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1719(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1431)){
C_save(t1);
C_rereclaim2(1431*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,310);
lf[13]=C_h_intern(&lf[13],4,"http");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[25]=C_h_intern(&lf[25],7,"chicken");
lf[26]=C_h_intern(&lf[26],15,"chicken-version");
lf[27]=C_h_intern(&lf[27],7,"version");
lf[28]=C_h_intern(&lf[28],8,"->string");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\0050.0.0");
lf[30]=C_h_intern(&lf[30],21,"extension-information");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[32]=C_h_intern(&lf[32],24,"\003syscore-library-modules");
lf[38]=C_h_intern(&lf[38],7,"reverse");
lf[39]=C_h_intern(&lf[39],10,"alist-cons");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[41]=C_h_intern(&lf[41],5,"error");
lf[42]=C_h_intern(&lf[42],13,"string-append");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000JYour CHICKEN version is not recent enough to use this extension - version ");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\025 or newer is required");
lf[45]=C_h_intern(&lf[45],20,"setup-api#version>=\077");
lf[46]=C_h_intern(&lf[46],7,"warning");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\0007invalid dependency syntax in extension meta information");
lf[48]=C_h_intern(&lf[48],7,"depends");
lf[49]=C_h_intern(&lf[49],5,"needs");
lf[50]=C_h_intern(&lf[50],12,"test-depends");
lf[51]=C_h_intern(&lf[51],6,"append");
lf[52]=C_h_intern(&lf[52],26,"setup-api#remove-extension");
lf[53]=C_h_intern(&lf[53],5,"print");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000)removing previously installed extension `");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\012 upgrade: ");
lf[57]=C_h_intern(&lf[57],18,"string-intersperse");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[59]=C_h_intern(&lf[59],6,"unzip1");
lf[60]=C_h_intern(&lf[60],20,"setup-api#yes-or-no\077");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[62]=C_h_intern(&lf[62],18,"string-concatenate");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000:The following installed extensions are outdated, because `");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\033\047 requires later versions:\012");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\0000\012Do you want to replace the existing extensions\077\376\377\016");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\003\077\077\077");
lf[67]=C_h_intern(&lf[67],4,"conc");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\002 (");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\012 missing: ");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\033checking dependencies for `");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000)extension is not targeted for this system");
lf[78]=C_h_intern(&lf[78],8,"platform");
lf[79]=C_h_intern(&lf[79],8,"feature\077");
lf[80]=C_h_intern(&lf[80],3,"and");
lf[81]=C_h_intern(&lf[81],5,"every");
lf[82]=C_h_intern(&lf[82],2,"or");
lf[83]=C_h_intern(&lf[83],3,"any");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid `platform\047 property");
lf[85]=C_h_intern(&lf[85],3,"not");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid `platform\047 property");
lf[87]=C_h_intern(&lf[87],14,"\000cross-chicken");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\027checking platform for `");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[90]=C_h_intern(&lf[90],20,"with-input-from-file");
lf[91]=C_h_intern(&lf[91],4,"read");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\013extension `");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\024\047 has no .meta file ");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000!- assuming it has no dependencies");
lf[95]=C_h_intern(&lf[95],12,"file-exists\077");
lf[96]=C_h_intern(&lf[96],13,"make-pathname");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[98]=C_h_intern(&lf[98],6,"delete");
lf[99]=C_h_intern(&lf[99],3,"eq\077");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[101]=C_h_intern(&lf[101],9,"condition");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\023TCP connect timeout");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\023HTTP protocol error");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[107]=C_h_intern(&lf[107],19,"print-error-message");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\015Server error:");
lf[109]=C_h_intern(&lf[109],5,"abort");
lf[110]=C_h_intern(&lf[110],3,"exn");
lf[111]=C_h_intern(&lf[111],20,"setup-download-error");
lf[112]=C_h_intern(&lf[112],10,"http-fetch");
lf[113]=C_h_intern(&lf[113],3,"net");
lf[114]=C_h_intern(&lf[114],33,"setup-download#retrieve-extension");
lf[115]=C_h_intern(&lf[115],8,"\000version");
lf[116]=C_h_intern(&lf[116],12,"\000destination");
lf[117]=C_h_intern(&lf[117],6,"\000tests");
lf[118]=C_h_intern(&lf[118],9,"\000username");
lf[119]=C_h_intern(&lf[119],9,"\000password");
lf[120]=C_h_intern(&lf[120],6,"\000trunk");
lf[121]=C_h_intern(&lf[121],11,"\000proxy-host");
lf[122]=C_h_intern(&lf[122],11,"\000proxy-port");
lf[123]=C_h_intern(&lf[123],17,"current-directory");
lf[124]=C_h_intern(&lf[124],22,"with-exception-handler");
lf[125]=C_h_intern(&lf[125],30,"call-with-current-continuation");
lf[126]=C_h_intern(&lf[126],9,"transport");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\027missing transport entry");
lf[128]=C_h_intern(&lf[128],8,"location");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\026missing location entry");
lf[130]=C_h_intern(&lf[130],5,"local");
lf[131]=C_h_intern(&lf[131],18,"absolute-pathname\077");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\014 located at ");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\036extension or version not found");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\016retrieving ...");
lf[137]=C_h_intern(&lf[137],26,"setup-api#remove-directory");
lf[138]=C_h_intern(&lf[138],34,"setup-download#temporary-directory");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\007mapped ");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\004 to ");
lf[141]=C_h_intern(&lf[141],5,"lset=");
lf[142]=C_h_intern(&lf[142],17,"delete-duplicates");
lf[143]=C_h_intern(&lf[143],8,"string=\077");
lf[144]=C_h_intern(&lf[144],4,"find");
lf[145]=C_h_intern(&lf[145],10,"append-map");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000/shell command terminated with nonzero exit code");
lf[148]=C_h_intern(&lf[148],6,"system");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[153]=C_h_intern(&lf[153],7,"sprintf");
lf[154]=C_h_intern(&lf[154],25,"\003sysimplicit-exit-handler");
lf[155]=C_h_intern(&lf[155],4,"exit");
lf[156]=C_h_intern(&lf[156],18,"current-error-port");
lf[157]=C_h_intern(&lf[157],7,"newline");
lf[158]=C_h_intern(&lf[158],19,"setup-api#copy-file");
lf[159]=C_h_intern(&lf[159],15,"repository-path");
lf[160]=C_h_intern(&lf[160],5,"write");
lf[161]=C_h_intern(&lf[161],19,"with-output-to-file");
lf[162]=C_h_intern(&lf[162],8,"string<\077");
lf[163]=C_h_intern(&lf[163],14,"symbol->string");
lf[164]=C_h_intern(&lf[164],4,"sort");
lf[165]=C_h_intern(&lf[165],18,"\003sysmodule-exports");
lf[166]=C_h_intern(&lf[166],5,"value");
lf[167]=C_h_intern(&lf[167],6,"syntax");
lf[168]=C_h_intern(&lf[168],6,"print*");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[170]=C_h_intern(&lf[170],15,"\003sysmodule-name");
lf[171]=C_h_intern(&lf[171],16,"\003sysmodule-table");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\023generating database");
lf[173]=C_h_intern(&lf[173],20,"\003syswarnings-enabled");
lf[174]=C_h_intern(&lf[174],17,"get-output-string");
lf[175]=C_h_intern(&lf[175],19,"\003syswrite-char/port");
lf[176]=C_h_intern(&lf[176],7,"display");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\027Failed to import from `");
lf[178]=C_h_intern(&lf[178],18,"open-output-string");
lf[179]=C_h_intern(&lf[179],6,"import");
lf[180]=C_h_intern(&lf[180],4,"eval");
lf[181]=C_h_intern(&lf[181],14,"string->symbol");
lf[182]=C_h_intern(&lf[182],12,"string-match");
lf[183]=C_h_intern(&lf[183],16,"\003sysdynamic-wind");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\034loading import libraries ...");
lf[185]=C_h_intern(&lf[185],6,"regexp");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\034.*/([^/]+)\134.import\134.(scm|so)");
lf[187]=C_h_intern(&lf[187],36,"setup-api#create-temporary-directory");
lf[188]=C_h_intern(&lf[188],4,"glob");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\012*.import.*");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\020~a -s run.scm ~a");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\015tests/run.scm");
lf[193]=C_h_intern(&lf[193],10,"directory\077");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\027 -e \042(sudo-install #t)\042");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(keep-intermediates #t)\042");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(setup-install-mode #f)\042");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\031 -e \042(host-extension #t)\042");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\032 -e \042(deployment-mode #t)\042");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\006 -bnq ");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\0008-e \042(require-library setup-api)\042 -e \042(import setup-api)\042");
lf[209]=C_h_intern(&lf[209],19,"setup-api#shellpath");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\004\134\042)\042");
lf[212]=C_h_intern(&lf[212],18,"normalize-pathname");
lf[213]=C_h_intern(&lf[213],4,"unix");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\033 -e \042(destination-prefix \134\042");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[216]=C_h_intern(&lf[216],22,"setup-api#sudo-install");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\005\134\042))\042");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\005\134\042 \134\042");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000% -e \042(extension-name-and-version \047(\134\042");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\014-setup-mode ");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\036changing current directory to ");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\013installing ");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\026aborting installation.");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\203You specified `-no-install\047, but this extension has dependencies that are r"
"equired for building. Do you still want to install them\077");
lf[227]=C_h_intern(&lf[227],4,"iota");
lf[228]=C_h_intern(&lf[228],5,"assoc");
lf[229]=C_h_intern(&lf[229],7,"\003sysmap");
lf[230]=C_h_intern(&lf[230],2,"pp");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\016install order:");
lf[232]=C_h_intern(&lf[232],16,"topological-sort");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000;no default location defined - please use `-location\047 option");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000=no default transport defined - please use `-transport\047 option");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[237]=C_h_intern(&lf[237],13,"pathname-file");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\033no setup-scripts to process");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\007*.setup");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\005\270usage: chicken-install [OPTION | EXTENSION[:VERSION]] ...\012\012  -h   -help    "
"                show this message and exit\012  -v   -version                 show "
"version and exit\012       -force                   don\047t ask, install even if vers"
"ions don\047t match\012  -k   -keep                    keep temporary files\012  -l   -lo"
"cation LOCATION       install from given location instead of default\012  -t   -tra"
"nsport TRANSPORT     use given transport instead of default\012       -proxy HOST[:"
"PORT]       download via HTTP proxy\012  -s   -sudo                    use sudo(1) "
"for filesystem operations\012  -r   -retrieve                only retrieve egg into"
" current directory, don\047t install\012  -n   -no-install              do not install"
", just build (implies `-keep\047)\012  -p   -prefix PREFIX           change installati"
"on prefix to PREFIX\012       -host                    when cross-compiling, compil"
"e extension for host\012       -test                    run included test-cases, if"
" available\012       -username USER           set username for transports that requ"
"ire this\012       -password PASS           set password for transports that requir"
"e this\012  -i   -init DIRECTORY          initialize empty alternative repository\012 "
" -u   -update-db               update export database\012       -repository        "
"      print path used for egg installation\012       -deploy                  build"
" extensions for deployment\012       -trunk                   build trunk instead o"
"f tagged version (only local)");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\013-repository");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\006-force");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\005-keep");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\005-sudo");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\002-r");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\011-retrieve");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\011-location");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\002-t");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\012-transport");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\007-prefix");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\002-n");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-install");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\002-u");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\012-update-db");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\002-i");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\005-init");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\004copy");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\010~a ~a ~a");
lf[267]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014setup-api.so\376\003\000\000\002\376B\000\000\023setup-api.import.so\376\003\000\000\002\376B\000\000\021setup-download.so\376\003"
"\000\000\002\376B\000\000\030setup-download.import.so\376\003\000\000\002\376B\000\000\021chicken.import.so\376\003\000\000\002\376B\000\000\021lolevel.imp"
"ort.so\376\003\000\000\002\376B\000\000\020srfi-1.import.so\376\003\000\000\002\376B\000\000\020srfi-4.import.so\376\003\000\000\002\376B\000\000\031data-structu"
"res.import.so\376\003\000\000\002\376B\000\000\017ports.import.so\376\003\000\000\002\376B\000\000\017files.import.so\376\003\000\000\002\376B\000\000\017posix.i"
"mport.so\376\003\000\000\002\376B\000\000\021srfi-13.import.so\376\003\000\000\002\376B\000\000\021srfi-69.import.so\376\003\000\000\002\376B\000\000\020extras.i"
"mport.so\376\003\000\000\002\376B\000\000\017regex.import.so\376\003\000\000\002\376B\000\000\021srfi-14.import.so\376\003\000\000\002\376B\000\000\015tcp.import"
".so\376\003\000\000\002\376B\000\000\021foreign.import.so\376\003\000\000\002\376B\000\000\020scheme.import.so\376\003\000\000\002\376B\000\000\021srfi-18.import"
".so\376\003\000\000\002\376B\000\000\017utils.import.so\376\003\000\000\002\376B\000\000\015csi.import.so\376\003\000\000\002\376B\000\000\021irregex.import.so\376\003"
"\000\000\002\376B\000\000\010types.db\376\377\016");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\032copying required files to ");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\006-proxy");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\016(.+)\134:([0-9]+)");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\005-test");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\017-host-extension");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\007-deploy");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\011-username");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\006-trunk");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\011-password");
lf[279]=C_h_intern(&lf[279],6,"string");
lf[280]=C_h_intern(&lf[280],4,"memq");
lf[281]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000l\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000p\376\003\000\000\002\376\377\012\000\000r\376\003\000"
"\000\002\376\377\012\000\000n\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000u\376\377\016");
lf[282]=C_h_intern(&lf[282],16,"\003sysstring->list");
lf[283]=C_h_intern(&lf[283],9,"substring");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[286]=C_h_intern(&lf[286],18,"pathname-directory");
lf[287]=C_h_intern(&lf[287],18,"pathname-extension");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\014([^:]+):(.+)");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid entry in defaults file");
lf[292]=C_h_intern(&lf[292],6,"server");
lf[293]=C_h_intern(&lf[293],3,"map");
lf[294]=C_h_intern(&lf[294],8,"split-at");
lf[295]=C_h_intern(&lf[295],2,"->");
lf[296]=C_h_intern(&lf[296],10,"list-index");
lf[297]=C_h_intern(&lf[297],9,"read-file");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\016setup.defaults");
lf[299]=C_h_intern(&lf[299],12,"chicken-home");
lf[300]=C_h_intern(&lf[300],22,"command-line-arguments");
lf[301]=C_h_intern(&lf[301],17,"register-feature!");
lf[302]=C_h_intern(&lf[302],15,"chicken-install");
lf[303]=C_h_intern(&lf[303],17,"\003syspeek-c-string");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[305]=C_h_intern(&lf[305],24,"get-environment-variable");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[307]=C_h_intern(&lf[307],11,"\003sysrequire");
lf[308]=C_h_intern(&lf[308],9,"setup-api");
lf[309]=C_h_intern(&lf[309],14,"setup-download");
C_register_lf2(lf,310,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1309,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1307 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1310 in k1307 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1313 in k1310 in k1307 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1324,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1339,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1342,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1345,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[307]))(3,*((C_word*)lf[307]+1),t2,lf[309]);}

/* k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1348,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[307]))(3,*((C_word*)lf[307]+1),t2,lf[308]);}

/* k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1353,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 66   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[305]))(3,*((C_word*)lf[305]+1),t2,lf[306]);}

/* k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1356,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* chicken-install.scm: 67   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),t2,t1,lf[304]);}
else{
t3=t2;
f_1356(2,t3,C_SCHEME_FALSE);}}

/* k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1359,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1359(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[303]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}}

/* k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1359,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! main#*program-path* ...) */,t1);
t3=lf[1] /* main#*keep* */ =C_SCHEME_FALSE;;
t4=lf[2] /* main#*force* */ =C_SCHEME_FALSE;;
t5=lf[3] /* main#*prefix* */ =C_SCHEME_FALSE;;
t6=lf[4] /* main#*host-extension* */ =C_SCHEME_FALSE;;
t7=lf[5] /* main#*run-tests* */ =C_SCHEME_FALSE;;
t8=lf[6] /* main#*retrieve-only* */ =C_SCHEME_FALSE;;
t9=lf[7] /* main#*no-install* */ =C_SCHEME_FALSE;;
t10=lf[8] /* main#*username* */ =C_SCHEME_FALSE;;
t11=lf[9] /* main#*password* */ =C_SCHEME_FALSE;;
t12=lf[10] /* main#*default-sources* */ =C_SCHEME_END_OF_LIST;;
t13=lf[11] /* main#*default-location* */ =C_SCHEME_FALSE;;
t14=C_mutate(&lf[12] /* (set! main#*default-transport* ...) */,lf[13]);
t15=C_mutate(&lf[14] /* (set! main#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t16=lf[15] /* main#*proxy-host* */ =C_SCHEME_FALSE;;
t17=lf[16] /* main#*proxy-port* */ =C_SCHEME_FALSE;;
t18=lf[17] /* main#*running-test* */ =C_SCHEME_FALSE;;
t19=lf[18] /* main#*mappings* */ =C_SCHEME_END_OF_LIST;;
t20=lf[19] /* main#*deploy* */ =C_SCHEME_FALSE;;
t21=lf[20] /* main#*trunk* */ =C_SCHEME_FALSE;;
t22=C_mutate(&lf[21] /* (set! main#constant172 ...) */,lf[22]);
t23=C_mutate(&lf[23] /* (set! main#deps ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1639,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate(&lf[24] /* (set! main#ext-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1709,tmp=(C_word)a,a+=2,tmp));
t25=lf[33] /* main#*eggs+dirs+vers* */ =C_SCHEME_END_OF_LIST;;
t26=lf[34] /* main#*dependencies* */ =C_SCHEME_END_OF_LIST;;
t27=lf[35] /* main#*checked* */ =C_SCHEME_END_OF_LIST;;
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1996,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4598,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t30=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4602,a[2]=t29,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t31=*((C_word*)lf[303]+1);
((C_proc4)(void*)(*((C_word*)t31+1)))(4,t31,t30,C_mpointer(&a,(void*)C_CSI_PROGRAM),C_fix(0));}

/* k4600 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 211  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),((C_word*)t0)[2],C_retrieve2(lf[0],"main#*program-path*"),t1);}

/* k4596 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 211  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[209]))(3,*((C_word*)lf[209]+1),((C_word*)t0)[2],t1);}

/* k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1996,2,t0,t1);}
t2=C_mutate(&lf[36] /* (set! main#*csi* ...) */,t1);
t3=C_mutate(&lf[37] /* (set! main#retrieve ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2298,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[136] /* (set! main#cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3150,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[74] /* (set! main#apply-mappings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3534,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[146] /* (set! main#$system ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3642,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[151] /* (set! main#command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3664,tmp=(C_word)a,a+=2,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4512,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 654  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[301]))(3,*((C_word*)lf[301]+1),t8,lf[302]);}

/* k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4515,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4526,tmp=(C_word)a,a+=2,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[125]+1)))(3,*((C_word*)lf[125]+1),t2,t3);}

/* a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4526(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4526,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4532,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4565,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[124]))(4,*((C_word*)lf[124]+1),t1,t3,t4);}

/* a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4571,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4584,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4583 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4584r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4584r(t0,t1,t2);}}

static void C_ccall f_4584r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4590,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k12261231 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4589 in a4583 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4590,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4575,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4582,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 662  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[300]))(2,*((C_word*)lf[300]+1),t3);}

/* k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3690,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1386,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1570,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 94   chicken-home */
((C_proc2)C_retrieve_symbol_proc(lf[299]))(2,*((C_word*)lf[299]+1),t4);}

/* k1568 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 94   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),((C_word*)t0)[2],t1,lf[298]);}

/* k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1388,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1566,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 97   file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[95]))(3,*((C_word*)lf[95]+1),t3,t1);}

/* k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1566,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 118  read-file */
((C_proc3)C_retrieve_symbol_proc(lf[297]))(3,*((C_word*)lf[297]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3690(2,t2,C_SCHEME_END_OF_LIST);}}

/* k1403 in k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1405,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1407,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1407(t5,((C_word*)t0)[2],t1);}

/* loop187 in k1403 in k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_1407(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1407,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1415,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1551,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g194195 */
t6=t3;
f_1415(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1549 in loop187 in k1403 in k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1407(t3,((C_word*)t0)[2],t2);}

/* g194 in loop187 in k1403 in k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_1415(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1415,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1419,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(t2))){
t4=C_i_length(t2);
if(C_truep(C_i_positivep(t4))){
t5=t3;
f_1419(2,t5,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 102  broken */
t5=((C_word*)t0)[2];
f_1388(t5,t3,t2);}}
else{
/* chicken-install.scm: 102  broken */
t4=((C_word*)t0)[2];
f_1388(t4,t3,t2);}}

/* k1417 in g194 in loop187 in k1403 in k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1419,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[4]);
t3=C_eqp(t2,lf[292]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1432,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=C_i_cdr(((C_word*)t0)[4]);
t6=C_a_i_list(&a,1,t5);
/* chicken-install.scm: 106  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),t4,C_retrieve2(lf[10],"main#*default-sources*"),t6);}
else{
t4=C_eqp(t2,lf[293]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1450,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1454,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=C_i_cdr(((C_word*)t0)[4]);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1460,a[2]=t7,a[3]=t13,a[4]=t9,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_1460(t15,t10,t11);}
else{
/* chicken-install.scm: 117  broken */
t5=((C_word*)t0)[2];
f_1388(t5,((C_word*)t0)[3],((C_word*)t0)[4]);}}}

/* loop208 in k1417 in g194 in loop187 in k1403 in k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_1460(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1460,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1487,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1525,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g224225 */
t6=t3;
f_1487(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1523 in loop208 in k1417 in g194 in loop187 in k1403 in k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1525,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop208221 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1460(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop208221 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1460(t6,((C_word*)t0)[3],t5);}}

/* g224 in loop208 in k1417 in g194 in loop187 in k1403 in k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_1487(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1487,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1518,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm: 112  list-index */
((C_proc4)C_retrieve_symbol_proc(lf[296]))(4,*((C_word*)lf[296]+1),t3,t4,t2);}

/* a1517 in g224 in loop208 in k1417 in g194 in loop187 in k1403 in k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1518,3,t0,t1,t2);}
t3=*((C_word*)lf[99]+1);
/* g235236 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,lf[295],t2);}

/* k1489 in g224 in loop208 in k1417 in g194 in loop187 in k1403 in k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1494,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_1494(2,t3,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 113  broken */
t3=((C_word*)t0)[3];
f_1388(t3,t2,((C_word*)t0)[2]);}}

/* k1492 in k1489 in g224 in loop208 in k1417 in g194 in loop187 in k1403 in k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1499,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1505,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1504 in k1492 in k1489 in g224 in loop208 in k1417 in g194 in loop187 in k1403 in k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1505,4,t0,t1,t2,t3);}
t4=C_i_cdr(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,t2,t4));}

/* a1498 in k1492 in k1489 in g224 in loop208 in k1417 in g194 in loop187 in k1403 in k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1499,2,t0,t1);}
/* chicken-install.scm: 114  split-at */
((C_proc4)C_retrieve_symbol_proc(lf[294]))(4,*((C_word*)lf[294]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1452 in k1417 in g194 in loop187 in k1403 in k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 109  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),((C_word*)t0)[2],C_retrieve2(lf[18],"main#*mappings*"),t1);}

/* k1448 in k1417 in g194 in loop187 in k1403 in k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[18] /* (set! main#*mappings* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1430 in k1417 in g194 in loop187 in k1403 in k1564 in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[10] /* (set! main#*default-sources* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* broken in k1384 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_1388(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1388,NULL,3,t0,t1,t2);}
/* chicken-install.scm: 96   error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[41]+1)))(5,*((C_word*)lf[41]+1),t1,lf[291],((C_word*)t0)[2],t2);}

/* k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3690,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 517  regexp */
((C_proc3)C_retrieve_symbol_proc(lf[185]))(3,*((C_word*)lf[185]+1),t4,lf[290]);}

/* k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3693,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3698,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_3698(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_3698(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3698,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t4=t1;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3169,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3528,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3532,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 417  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[159]))(2,*((C_word*)lf[159]+1),t7);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3714,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t3))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3746,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 523  glob */
((C_proc3)C_retrieve_symbol_proc(lf[188]))(3,*((C_word*)lf[188]+1),t5,lf[239]);}
else{
t5=t4;
f_3714(2,t5,C_SCHEME_UNDEFINED);}}}
else{
t4=C_i_car(t2);
t5=C_i_string_equal_p(t4,lf[240]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_3826(t7,t5);}
else{
t7=C_i_string_equal_p(t4,lf[288]);
t8=t6;
f_3826(t8,(C_truep(t7)?t7:C_i_string_equal_p(t4,lf[289])));}}}

/* k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_3826(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3826,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4911,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 485  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t3,lf[241]);}
else{
if(C_truep(C_i_string_equal_p(((C_word*)t0)[7],lf[242]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3838,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3845,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 547  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[159]))(2,*((C_word*)lf[159]+1),t3);}
else{
if(C_truep(C_i_string_equal_p(((C_word*)t0)[7],lf[243]))){
t2=lf[2] /* main#*force* */ =C_SCHEME_TRUE;;
t3=C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 551  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3698(t4,((C_word*)t0)[8],t3,((C_word*)t0)[4]);}
else{
t2=C_i_string_equal_p(((C_word*)t0)[7],lf[244]);
t3=(C_truep(t2)?t2:C_i_string_equal_p(((C_word*)t0)[7],lf[245]));
if(C_truep(t3)){
t4=lf[1] /* main#*keep* */ =C_SCHEME_TRUE;;
t5=C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 554  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3698(t6,((C_word*)t0)[8],t5,((C_word*)t0)[4]);}
else{
t4=C_i_string_equal_p(((C_word*)t0)[7],lf[246]);
t5=(C_truep(t4)?t4:C_i_string_equal_p(((C_word*)t0)[7],lf[247]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3888,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 556  setup-api#sudo-install */
((C_proc3)C_retrieve_symbol_proc(lf[216]))(3,*((C_word*)lf[216]+1),t6,C_SCHEME_TRUE);}
else{
t6=C_i_string_equal_p(((C_word*)t0)[7],lf[248]);
t7=(C_truep(t6)?t6:C_i_string_equal_p(((C_word*)t0)[7],lf[249]));
if(C_truep(t7)){
t8=lf[6] /* main#*retrieve-only* */ =C_SCHEME_TRUE;;
t9=C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 560  loop */
t10=((C_word*)((C_word*)t0)[5])[1];
f_3698(t10,((C_word*)t0)[8],t9,((C_word*)t0)[4]);}
else{
t8=C_i_string_equal_p(((C_word*)t0)[7],lf[250]);
t9=(C_truep(t8)?t8:C_i_string_equal_p(((C_word*)t0)[7],lf[251]));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3924,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t11=C_i_cdr(((C_word*)t0)[6]);
if(C_truep(C_i_pairp(t11))){
t12=t10;
f_3924(2,t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4916,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 485  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t12,lf[241]);}}
else{
t10=C_i_string_equal_p(((C_word*)t0)[7],lf[252]);
t11=(C_truep(t10)?t10:C_i_string_equal_p(((C_word*)t0)[7],lf[253]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3957,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t13=C_i_cdr(((C_word*)t0)[6]);
if(C_truep(C_i_pairp(t13))){
t14=t12;
f_3957(2,t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4921,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 485  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t14,lf[241]);}}
else{
t12=C_i_string_equal_p(((C_word*)t0)[7],lf[254]);
t13=(C_truep(t12)?t12:C_i_string_equal_p(((C_word*)t0)[7],lf[255]));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3994,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t15=C_i_cdr(((C_word*)t0)[6]);
if(C_truep(C_i_pairp(t15))){
t16=t14;
f_3994(2,t16,C_SCHEME_UNDEFINED);}
else{
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4926,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 485  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t16,lf[241]);}}
else{
t14=C_i_string_equal_p(((C_word*)t0)[7],lf[256]);
t15=(C_truep(t14)?t14:C_i_string_equal_p(((C_word*)t0)[7],lf[257]));
if(C_truep(t15)){
t16=lf[1] /* main#*keep* */ =C_SCHEME_TRUE;;
t17=lf[7] /* main#*no-install* */ =C_SCHEME_TRUE;;
t18=C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 581  loop */
t19=((C_word*)((C_word*)t0)[5])[1];
f_3698(t19,((C_word*)t0)[8],t18,((C_word*)t0)[4]);}
else{
t16=C_i_string_equal_p(((C_word*)t0)[7],lf[258]);
t17=(C_truep(t16)?t16:C_i_string_equal_p(((C_word*)t0)[7],lf[259]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4062,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4069,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 583  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[26]))(2,*((C_word*)lf[26]+1),t19);}
else{
t18=C_i_string_equal_p(((C_word*)t0)[7],lf[260]);
t19=(C_truep(t18)?t18:C_i_string_equal_p(((C_word*)t0)[7],lf[261]));
if(C_truep(t19)){
t20=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t21=C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 587  loop */
t22=((C_word*)((C_word*)t0)[5])[1];
f_3698(t22,((C_word*)t0)[8],t21,((C_word*)t0)[4]);}
else{
t20=C_i_string_equal_p(((C_word*)t0)[7],lf[262]);
t21=(C_truep(t20)?t20:C_i_string_equal_p(((C_word*)t0)[7],lf[263]));
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4098,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t23=C_i_cdr(((C_word*)t0)[6]);
if(C_truep(C_i_pairp(t23))){
t24=t22;
f_4098(2,t24,C_SCHEME_UNDEFINED);}
else{
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4933,a[2]=t22,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 485  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t24,lf[241]);}}
else{
if(C_truep(C_i_string_equal_p(lf[270],((C_word*)t0)[7]))){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4127,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t23=C_i_cdr(((C_word*)t0)[6]);
if(C_truep(C_i_pairp(t23))){
t24=t22;
f_4127(2,t24,C_SCHEME_UNDEFINED);}
else{
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4946,a[2]=t22,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 485  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t24,lf[241]);}}
else{
if(C_truep(C_i_string_equal_p(lf[272],((C_word*)t0)[7]))){
t22=lf[5] /* main#*run-tests* */ =C_SCHEME_TRUE;;
t23=C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 604  loop */
t24=((C_word*)((C_word*)t0)[5])[1];
f_3698(t24,((C_word*)t0)[8],t23,((C_word*)t0)[4]);}
else{
t22=C_i_string_equal_p(lf[273],((C_word*)t0)[7]);
t23=(C_truep(t22)?t22:C_i_string_equal_p(lf[274],((C_word*)t0)[7]));
if(C_truep(t23)){
t24=lf[4] /* main#*host-extension* */ =C_SCHEME_TRUE;;
t25=C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 608  loop */
t26=((C_word*)((C_word*)t0)[5])[1];
f_3698(t26,((C_word*)t0)[8],t25,((C_word*)t0)[4]);}
else{
if(C_truep(C_i_string_equal_p(lf[275],((C_word*)t0)[7]))){
t24=lf[19] /* main#*deploy* */ =C_SCHEME_TRUE;;
t25=C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 611  loop */
t26=((C_word*)((C_word*)t0)[5])[1];
f_3698(t26,((C_word*)t0)[8],t25,((C_word*)t0)[4]);}
else{
if(C_truep(C_i_string_equal_p(lf[276],((C_word*)t0)[7]))){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4230,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t25=C_i_cdr(((C_word*)t0)[6]);
if(C_truep(C_i_pairp(t25))){
t26=t24;
f_4230(2,t26,C_SCHEME_UNDEFINED);}
else{
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4951,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 485  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t26,lf[241]);}}
else{
if(C_truep(C_i_string_equal_p(lf[277],((C_word*)t0)[7]))){
t24=lf[20] /* main#*trunk* */ =C_SCHEME_TRUE;;
t25=C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 618  loop */
t26=((C_word*)((C_word*)t0)[5])[1];
f_3698(t26,((C_word*)t0)[8],t25,((C_word*)t0)[4]);}
else{
if(C_truep(C_i_string_equal_p(lf[278],((C_word*)t0)[7]))){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4274,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t25=C_i_cdr(((C_word*)t0)[6]);
if(C_truep(C_i_pairp(t25))){
t26=t24;
f_4274(2,t26,C_SCHEME_UNDEFINED);}
else{
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4956,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 485  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t26,lf[241]);}}
else{
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t25=C_i_string_length(((C_word*)t0)[7]);
if(C_truep(C_i_positivep(t25))){
t26=C_i_string_ref(((C_word*)t0)[7],C_fix(0));
t27=t24;
f_4301(t27,C_eqp(C_make_character(45),t26));}
else{
t26=t24;
f_4301(t26,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}}}}}

/* k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_4301(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4301,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_string_length(((C_word*)t0)[7]);
if(C_truep(C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4310,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4350,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 626  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[283]+1)))(4,*((C_word*)lf[283]+1),t4,((C_word*)t0)[7],C_fix(1));}
else{
t3=((C_word*)t0)[5];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4966,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 485  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t4,lf[241]);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm: 634  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[287]))(3,*((C_word*)lf[287]+1),t2,((C_word*)t0)[7]);}}

/* k4451 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4453,2,t0,t1);}
if(C_truep(C_i_equalp(lf[284],t1))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4366,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 635  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[237]))(3,*((C_word*)lf[237]+1),t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4411,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 649  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k4409 in k4451 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4411,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4415,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* g12221223 */
t3=t2;
f_4415(t3,((C_word*)t0)[3],t1);}
else{
t2=C_i_cdr(((C_word*)t0)[6]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
/* chicken-install.scm: 652  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3698(t4,((C_word*)t0)[3],t2,t3);}}

/* g1222 in k4409 in k4451 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_4415(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4415,NULL,3,t0,t1,t2);}
t3=C_i_cdr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4427,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=C_i_cadr(t2);
t6=C_i_caddr(t2);
/* chicken-install.scm: 651  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[39]))(5,*((C_word*)lf[39]+1),t4,t5,t6,((C_word*)t0)[2]);}

/* k4425 in g1222 in k4409 in k4451 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 651  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3698(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4364 in k4451 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4389,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 640  pathname-directory */
((C_proc3)C_retrieve_symbol_proc(lf[286]))(3,*((C_word*)lf[286]+1),t3,((C_word*)t0)[2]);}

/* k4387 in k4364 in k4451 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4398,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 642  absolute-pathname? */
((C_proc3)C_retrieve_symbol_proc(lf[131]))(3,*((C_word*)lf[131]+1),t3,t1);}
else{
/* chicken-install.scm: 645  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[123]))(2,*((C_word*)lf[123]+1),t2);}}

/* k4396 in k4387 in k4364 in k4451 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4398,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=C_a_i_list(&a,2,t2,lf[285]);
/* chicken-install.scm: 637  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[39]))(5,*((C_word*)lf[39]+1),((C_word*)t0)[4],((C_word*)t0)[3],t3,C_retrieve2(lf[33],"main#*eggs+dirs+vers*"));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4405,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 644  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[123]))(2,*((C_word*)lf[123]+1),t2);}}

/* k4403 in k4396 in k4387 in k4364 in k4451 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 644  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4390 in k4387 in k4364 in k4451 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4392,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,lf[285]);
/* chicken-install.scm: 637  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[39]))(5,*((C_word*)lf[39]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2,C_retrieve2(lf[33],"main#*eggs+dirs+vers*"));}

/* k4368 in k4364 in k4451 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=C_mutate(&lf[33] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=C_i_cdr(((C_word*)t0)[6]);
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* chicken-install.scm: 648  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3698(t5,((C_word*)t0)[2],t3,t4);}

/* f4966 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 510  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(1));}

/* k4348 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[282]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4308 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4316,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4342,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm: 627  every */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t2,t3,t1);}

/* a4341 in k4308 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4342(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4342,3,t0,t1,t2);}
t3=*((C_word*)lf[280]+1);
/* g11951196 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[281]);}

/* k4314 in k4308 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4316,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4323,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4327,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4333,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4961,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 485  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t3,lf[241]);}}

/* f4961 in k4314 in k4308 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f4961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 510  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(1));}

/* a4332 in k4314 in k4308 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4333(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4333,3,t0,t1,t2);}
t3=*((C_word*)lf[279]+1);
/* g12161217 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,C_make_character(45),t2);}

/* k4325 in k4314 in k4308 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[3]);
/* chicken-install.scm: 628  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),((C_word*)t0)[2],t1,t2);}

/* k4321 in k4314 in k4308 in k4299 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 628  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3698(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f4956 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f4956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 510  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(1));}

/* k4272 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[9] /* (set! main#*password* ...) */,t2);
t4=C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 622  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3698(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* f4951 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f4951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 510  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(1));}

/* k4228 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[8] /* (set! main#*username* ...) */,t2);
t4=C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 615  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3698(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* f4946 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f4946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 510  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(1));}

/* k4125 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[5]);
/* chicken-install.scm: 594  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t2,lf[271],t3);}

/* k4128 in k4125 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4130,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=C_i_cadr(t2);
t4=C_mutate(&lf[15] /* (set! main#*proxy-host* ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=C_i_caddr(t2);
/* chicken-install.scm: 597  string->number */
C_string_to_number(3,0,t5,t6);}
else{
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[15] /* (set! main#*proxy-host* ...) */,t2);
t4=lf[16] /* main#*proxy-port* */ =C_fix(80);;
t5=C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 601  loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3698(t6,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}}

/* k4148 in k4128 in k4125 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[16] /* (set! main#*proxy-port* ...) */,t1);
t3=C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 601  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3698(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* f4933 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f4933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 510  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(1));}

/* k4096 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4101,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1658,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 140  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[159]))(2,*((C_word*)lf[159]+1),t4);}

/* k1656 in k4096 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1658,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[14],"main#*windows-shell*"))?lf[264]:lf[265]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1664,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 144  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t3,lf[268],((C_word*)t0)[3],lf[269]);}

/* k1662 in k1656 in k4096 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1664,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1669,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1669(t5,((C_word*)t0)[2],lf[267]);}

/* loop286 in k1662 in k1656 in k4096 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_1669(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1669,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1677,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1696,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g293294 */
t6=t3;
f_1677(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1694 in loop286 in k1662 in k1656 in k4096 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1669(t3,((C_word*)t0)[2],t2);}

/* g293 in loop286 in k1662 in k1656 in k4096 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_1677(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1677,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1693,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 147  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),t4,((C_word*)t0)[2],t2);}

/* k1691 in g293 in loop286 in k1662 in k1656 in k4096 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 147  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[209]))(3,*((C_word*)lf[209]+1),((C_word*)t0)[2],t1);}

/* k1683 in g293 in loop286 in k1662 in k1656 in k4096 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1689,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 147  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[209]))(3,*((C_word*)lf[209]+1),t2,((C_word*)t0)[2]);}

/* k1687 in k1683 in g293 in loop286 in k1662 in k1656 in k4096 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1689,2,t0,t1);}
/* chicken-install.scm: 147  command */
f_3664(((C_word*)t0)[4],lf[266],C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4099 in k4096 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 591  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(0));}

/* k4067 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 583  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),((C_word*)t0)[2],t1);}

/* k4060 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 584  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(0));}

/* f4926 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f4926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 510  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(1));}

/* k3992 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3994,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4011,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm: 573  absolute-pathname? */
((C_proc3)C_retrieve_symbol_proc(lf[131]))(3,*((C_word*)lf[131]+1),t4,t2);}

/* k4009 in k3992 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4011,2,t0,t1);}
if(C_truep(t1)){
t2=C_mutate(&lf[3] /* (set! main#*prefix* ...) */,((C_word*)t0)[7]);
t3=C_i_cddr(((C_word*)t0)[6]);
/* chicken-install.scm: 577  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3698(t4,((C_word*)t0)[4],t3,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4018,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4022,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 576  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[123]))(2,*((C_word*)lf[123]+1),t3);}}

/* k4020 in k4009 in k3992 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 576  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4016 in k4009 in k3992 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 575  normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[212]))(3,*((C_word*)lf[212]+1),((C_word*)t0)[2],t1);}

/* k3999 in k3992 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[3] /* (set! main#*prefix* ...) */,t1);
t3=C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 577  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3698(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* f4921 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f4921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 510  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(1));}

/* k3955 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[5]);
/* chicken-install.scm: 567  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[181]+1)))(3,*((C_word*)lf[181]+1),t2,t3);}

/* k3959 in k3955 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[12] /* (set! main#*default-transport* ...) */,t1);
t3=C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 568  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3698(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* f4916 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 510  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(1));}

/* k3922 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[11] /* (set! main#*default-location* ...) */,t2);
t4=C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 564  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3698(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k3886 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 557  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3698(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k3843 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 547  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),((C_word*)t0)[2],t1);}

/* k3836 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 548  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(0));}

/* f4911 in k3824 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f4911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 510  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(0));}

/* k3744 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3746,2,t0,t1);}
if(C_truep(C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3756,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3760,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3762,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_3762(t11,t7,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3811,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 532  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t2,lf[238]);}}

/* k3809 in k3744 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 533  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(1));}

/* loop1025 in k3744 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_3762(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3762,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3797,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 528  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[237]))(3,*((C_word*)lf[237]+1),t4,t3);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3795 in loop1025 in k3744 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3797,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[235],lf[236]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t5=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t4);
t6=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t7=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10251038 */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3762(t8,((C_word*)t0)[3],t7);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t7=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10251038 */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3762(t8,((C_word*)t0)[3],t7);}}

/* k3758 in k3744 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 526  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[33],"main#*eggs+dirs+vers*"));}

/* k3754 in k3744 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[33] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=((C_word*)t0)[2];
f_3714(2,t3,t2);}

/* k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3717,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3717(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3731,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[12],"main#*default-transport*"))){
if(C_truep(C_retrieve2(lf[11],"main#*default-location*"))){
t4=C_SCHEME_UNDEFINED;
t5=t2;
f_3717(2,t5,t4);}
else{
/* chicken-install.scm: 538  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),t2,lf[233]);}}
else{
/* chicken-install.scm: 536  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),t3,lf[234]);}}}

/* k3729 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_retrieve2(lf[11],"main#*default-location*"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_3717(2,t3,t2);}
else{
/* chicken-install.scm: 538  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),((C_word*)t0)[2],lf[233]);}}

/* k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3724,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3728,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 539  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t3,((C_word*)t0)[2]);}

/* k3726 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 539  apply-mappings */
f_3534(((C_word*)t0)[2],t1);}

/* k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3724,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2941,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 372  retrieve */
f_2298(t3,t1);}

/* k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2941,2,t0,t1);}
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2947,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3148,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 374  topological-sort */
((C_proc4)C_retrieve_symbol_proc(lf[232]))(4,*((C_word*)lf[232]+1),t3,C_retrieve2(lf[34],"main#*dependencies*"),*((C_word*)lf[143]+1));}}

/* k3146 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 374  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),((C_word*)t0)[2],t1);}

/* k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2947,2,t0,t1);}
t2=C_i_length(t1);
t3=C_retrieve2(lf[2],"main#*force*");
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2953,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 377  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t4,lf[231]);}

/* k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 378  pp */
((C_proc3)C_retrieve_symbol_proc(lf[230]))(3,*((C_word*)lf[230]+1),t2,((C_word*)t0)[2]);}

/* k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3140,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3139 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3140(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3140,3,t0,t1,t2);}
t3=*((C_word*)lf[228]+1);
/* g770771 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_retrieve2(lf[33],"main#*eggs+dirs+vers*"));}

/* k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2967,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 409  iota */
((C_proc5)C_retrieve_symbol_proc(lf[227]))(5,*((C_word*)lf[227]+1),t2,((C_word*)t0)[3],((C_word*)t0)[3],C_fix(-1));}

/* k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2967,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2969,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2969(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2969(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2969,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2977,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3113,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g701702 */
t10=t6;
f_2977(t10,t7,t8,t9);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3111 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2969(t4,((C_word*)t0)[2],t2,t3);}

/* g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2977(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2977,NULL,4,t0,t1,t2,t3);}
t4=C_i_greaterp(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2984,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_truep(((C_word*)t0)[3])?C_SCHEME_FALSE:(C_truep(t4)?C_i_nequalp(t3,((C_word*)t0)[2]):C_SCHEME_FALSE));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3081,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[7],"main#*no-install*"))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3097,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 386  setup-api#yes-or-no? */
((C_proc3)C_retrieve_symbol_proc(lf[60]))(3,*((C_word*)lf[60]+1),t8,lf[226]);}
else{
t8=t7;
f_3081(t8,C_SCHEME_FALSE);}}
else{
t7=t5;
f_2984(2,t7,C_SCHEME_UNDEFINED);}}

/* k3095 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3081(t2,C_i_not(t1));}

/* k3079 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_3081(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3081,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3084,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 390  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t2,lf[225]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_2984(2,t3,t2);}}

/* k3082 in k3079 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3087,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 391  cleanup */
f_3150(t2);}

/* k3085 in k3082 in k3079 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 392  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(1));}

/* k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[5]);
t4=C_i_caddr(((C_word*)t0)[5]);
/* chicken-install.scm: 393  print */
((C_proc7)C_retrieve_proc(*((C_word*)lf[53]+1)))(7,*((C_word*)lf[53]+1),t2,lf[223],t3,C_make_character(58),t4,lf[224]);}

/* k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[5]);
/* chicken-install.scm: 394  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),t2,lf[222],t3);}

/* k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2990,2,t0,t1);}
t2=C_retrieve(lf[123]);
t3=C_i_cadr(((C_word*)t0)[5]);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2994,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3007,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t8=*((C_word*)lf[183]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[2],t6,t7,t6);}

/* a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=C_i_greaterp(((C_word*)t0)[2],C_fix(1));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2828,a[2]=t4,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2932,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 353  feature? */
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t6,lf[87]);}

/* k2930 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_retrieve2(lf[4],"main#*host-extension*");
t3=((C_word*)t0)[2];
f_2828(t3,(C_truep(t2)?lf[220]:lf[221]));}
else{
t2=((C_word*)t0)[2];
f_2828(t2,lf[220]);}}

/* k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2828(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2828,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2832,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[178]))(2,*((C_word*)lf[178]+1),t2);}

/* k2830 in k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2835,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[176]+1)))(4,*((C_word*)lf[176]+1),t2,lf[219],t1);}

/* k2833 in k2830 in k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[176]+1)))(4,*((C_word*)lf[176]+1),t2,t3,((C_word*)t0)[2]);}

/* k2836 in k2833 in k2830 in k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[176]+1)))(4,*((C_word*)lf[176]+1),t2,lf[218],((C_word*)t0)[2]);}

/* k2839 in k2836 in k2833 in k2830 in k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_caddr(((C_word*)t0)[3]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[176]+1)))(4,*((C_word*)lf[176]+1),t2,t3,((C_word*)t0)[2]);}

/* k2842 in k2839 in k2836 in k2833 in k2830 in k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[176]+1)))(4,*((C_word*)lf[176]+1),t2,lf[217],((C_word*)t0)[2]);}

/* k2845 in k2842 in k2839 in k2836 in k2833 in k2830 in k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2850,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t2,((C_word*)t0)[2]);}

/* k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in k2830 in k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2918,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 359  setup-api#sudo-install */
((C_proc2)C_retrieve_symbol_proc(lf[216]))(2,*((C_word*)lf[216]+1),t2);}

/* k2916 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in k2830 in k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2918,2,t0,t1);}
t2=(C_truep(t1)?lf[197]:lf[198]);
t3=(C_truep(C_retrieve2(lf[1],"main#*keep*"))?lf[199]:lf[200]);
t4=(C_truep(C_retrieve2(lf[7],"main#*no-install*"))?(C_truep(((C_word*)t0)[6])?lf[201]:lf[202]):lf[201]);
t5=(C_truep(C_retrieve2(lf[4],"main#*host-extension*"))?lf[203]:lf[204]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2870,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_retrieve2(lf[3],"main#*prefix*"))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2893,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[178]))(2,*((C_word*)lf[178]+1),t7);}
else{
t7=t6;
f_2870(2,t7,lf[215]);}}

/* k2891 in k2916 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in k2830 in k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2896,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[176]+1)))(4,*((C_word*)lf[176]+1),t2,lf[214],t1);}

/* k2894 in k2891 in k2916 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in k2830 in k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2909,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 365  normalize-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[212]))(4,*((C_word*)lf[212]+1),t3,C_retrieve2(lf[3],"main#*prefix*"),lf[213]);}

/* k2907 in k2894 in k2891 in k2916 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in k2830 in k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[176]+1)))(4,*((C_word*)lf[176]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2897 in k2894 in k2891 in k2916 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in k2830 in k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[176]+1)))(4,*((C_word*)lf[176]+1),t2,lf[211],((C_word*)t0)[2]);}

/* k2900 in k2897 in k2894 in k2891 in k2916 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in k2830 in k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2868 in k2916 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in k2830 in k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2870,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[19],"main#*deploy*"))?lf[205]:lf[206]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2878,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2882,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
t6=C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 369  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[96]))(5,*((C_word*)lf[96]+1),t4,t5,t6,lf[210]);}

/* k2880 in k2868 in k2916 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in k2830 in k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 369  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[209]))(3,*((C_word*)lf[209]+1),((C_word*)t0)[2],t1);}

/* k2876 in k2868 in k2916 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in k2830 in k2826 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 350  conc */
((C_proc15)C_retrieve_symbol_proc(lf[67]))(15,*((C_word*)lf[67]+1),((C_word*)t0)[10],C_retrieve2(lf[36],"main#*csi*"),lf[207],((C_word*)t0)[9],lf[208],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_make_character(32),t1);}

/* k3009 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3014,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 397  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),t2,lf[196],t1);}

/* k3012 in k3009 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 398  $system */
f_3642(t2,((C_word*)t0)[2]);}

/* k3015 in k3012 in k3009 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[5],"main#*run-tests*"))){
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3023(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3047,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 401  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[95]))(3,*((C_word*)lf[95]+1),t3,lf[195]);}}
else{
t3=t2;
f_3023(2,t3,C_SCHEME_FALSE);}}

/* k3045 in k3015 in k3012 in k3009 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3047,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3053,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 402  directory? */
((C_proc3)C_retrieve_symbol_proc(lf[193]))(3,*((C_word*)lf[193]+1),t2,lf[194]);}
else{
t2=((C_word*)t0)[2];
f_3023(2,t2,C_SCHEME_FALSE);}}

/* k3051 in k3045 in k3015 in k3012 in k3009 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm: 403  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[95]))(3,*((C_word*)lf[95]+1),((C_word*)t0)[2],lf[192]);}
else{
t2=((C_word*)t0)[2];
f_3023(2,t2,C_SCHEME_FALSE);}}

/* k3021 in k3015 in k3012 in k3009 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3023,2,t0,t1);}
if(C_truep(t1)){
t2=lf[17] /* main#*running-test* */ =C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 405  current-directory */
((C_proc3)C_retrieve_symbol_proc(lf[123]))(3,*((C_word*)lf[123]+1),t3,lf[191]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3025 in k3021 in k3015 in k3012 in k3009 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3030,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 406  command */
f_3664(t2,lf[190],C_a_i_list(&a,2,C_retrieve2(lf[36],"main#*csi*"),t3));}

/* k3028 in k3025 in k3021 in k3015 in k3012 in k3009 in a3006 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=lf[17] /* main#*running-test* */ =C_SCHEME_FALSE;;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* swap718 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2998,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* g721722725 */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2996 in swap718 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3001,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g721722725 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k2999 in k2996 in swap718 in k2988 in k2985 in k2982 in g701 in loop690 in k2965 in k2961 in k2954 in k2951 in k2945 in k2939 in k3722 in k3715 in k3712 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3530 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 417  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),((C_word*)t0)[2],t1,lf[189]);}

/* k3526 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 417  glob */
((C_proc3)C_retrieve_symbol_proc(lf[188]))(3,*((C_word*)lf[188]+1),((C_word*)t0)[2],t1);}

/* k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3172,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 418  setup-api#create-temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[187]))(2,*((C_word*)lf[187]+1),t2);}

/* k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3175,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 419  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),t2,t1,C_retrieve2(lf[21],"main#constant172"));}

/* k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3178,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 420  regexp */
((C_proc3)C_retrieve_symbol_proc(lf[185]))(3,*((C_word*)lf[185]+1),t2,lf[186]);}

/* k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3181,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 421  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t2,lf[184]);}

/* k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3181,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3184,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3398,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3521,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[183]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a3520 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3521,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[173]));
t3=C_mutate((C_word*)lf[173]+1 /* (set! ##sys#warnings-enabled ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3403,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3409,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3409(t5,t1,((C_word*)t0)[2]);}

/* loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_3409(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3409,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3417,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3508,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g807808 */
t6=t3;
f_3417(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3506 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3409(t3,((C_word*)t0)[2],t2);}

/* g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_3417(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3417,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3421,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 425  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t3,((C_word*)t0)[2],t2);}

/* k3419 in g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3424,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3429,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[125]+1)))(3,*((C_word*)lf[125]+1),t2,t3);}

/* a3428 in k3419 in g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3429,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3435,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3467,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[124]))(4,*((C_word*)lf[124]+1),t1,t3,t4);}

/* a3466 in a3428 in k3419 in g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3473,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3495,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3494 in a3466 in a3428 in k3419 in g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3495(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3495r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3495r(t0,t1,t2);}}

static void C_ccall f_3495r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3501,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k811816 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3500 in a3494 in a3466 in a3428 in k3419 in g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3501,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3472 in a3466 in a3428 in k3419 in g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3489,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 430  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[181]+1)))(3,*((C_word*)lf[181]+1),t2,t3);}

/* k3487 in a3472 in a3466 in a3428 in k3419 in g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3489,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[179],t2);
/* chicken-install.scm: 430  eval */
((C_proc3)C_retrieve_symbol_proc(lf[180]))(3,*((C_word*)lf[180]+1),((C_word*)t0)[2],t3);}

/* a3434 in a3428 in k3419 in g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3435,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3441,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* k811816 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3440 in a3434 in a3428 in k3419 in g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 428  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[156]))(2,*((C_word*)lf[156]+1),t2);}

/* k3447 in a3440 in a3434 in a3428 in k3419 in g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3453,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[178]))(2,*((C_word*)lf[178]+1),t2);}

/* k3451 in k3447 in a3440 in a3434 in a3428 in k3419 in g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3456,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[176]+1)))(4,*((C_word*)lf[176]+1),t2,lf[177],t1);}

/* k3454 in k3451 in k3447 in a3440 in a3434 in a3428 in k3419 in g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3459,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[176]+1)))(4,*((C_word*)lf[176]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3457 in k3454 in k3451 in k3447 in a3440 in a3434 in a3428 in k3419 in g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_retrieve(lf[175]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k3460 in k3457 in k3454 in k3451 in k3447 in a3440 in a3434 in a3428 in k3419 in g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3465,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t2,((C_word*)t0)[2]);}

/* k3463 in k3460 in k3457 in k3454 in k3451 in k3447 in a3440 in a3434 in a3428 in k3419 in g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 427  print-error-message */
((C_proc5)C_retrieve_symbol_proc(lf[107]))(5,*((C_word*)lf[107]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3422 in k3419 in g807 in loop800 in a3402 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g814815 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a3397 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3398,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[173]));
t3=C_mutate((C_word*)lf[173]+1 /* (set! ##sys#warnings-enabled ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 432  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t2,lf[172]);}

/* k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3251,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3275,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm: 435  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[145]))(4,*((C_word*)lf[145]+1),t3,t4,C_retrieve(lf[171]));}

/* a3274 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3275(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3275,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3282,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 438  ##sys#module-name */
((C_proc3)C_retrieve_symbol_proc(lf[170]))(3,*((C_word*)lf[170]+1),t4,t3);}

/* k3280 in a3274 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3285,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 439  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[168]+1)))(4,*((C_word*)lf[168]+1),t2,lf[169],t1);}

/* k3283 in k3280 in a3274 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3290,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3296,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3295 in k3283 in k3280 in a3274 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3296,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3304,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3354,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_3354(t13,t9,t4);}

/* loop856 in a3295 in k3283 in k3280 in a3274 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_3354(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(15);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3354,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_3381(C_a_i(&a,9),t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop856869 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop856869 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g872 in loop856 in a3295 in k3283 in k3280 in a3274 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static C_word C_fcall f_3381(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_i_car(t1);
return(C_a_i_list(&a,3,t2,lf[167],((C_word*)t0)[2]));}

/* k3302 in a3295 in k3283 in k3280 in a3274 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3304,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3308,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3310,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3310(t10,t6,((C_word*)t0)[2]);}

/* loop880 in k3302 in a3295 in k3283 in k3280 in a3274 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_3310(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(15);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3310,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3337,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_3337(C_a_i(&a,9),t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop880893 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop880893 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g896 in loop880 in k3302 in a3295 in k3283 in k3280 in a3274 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static C_word C_fcall f_3337(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_i_car(t1);
return(C_a_i_list(&a,3,t2,lf[166],((C_word*)t0)[2]));}

/* k3306 in k3302 in a3295 in k3283 in k3280 in a3274 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 441  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3289 in k3283 in k3280 in a3274 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3290,2,t0,t1);}
/* chicken-install.scm: 440  ##sys#module-exports */
((C_proc3)C_retrieve_symbol_proc(lf[165]))(3,*((C_word*)lf[165]+1),t1,((C_word*)t0)[2]);}

/* k3249 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3253,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm: 434  sort */
((C_proc4)C_retrieve_symbol_proc(lf[164]))(4,*((C_word*)lf[164]+1),((C_word*)t0)[2],t1,t2);}

/* a3252 in k3249 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3253,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3261,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(t2);
/* chicken-install.scm: 446  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t4,t5);}

/* k3259 in a3252 in k3249 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3265,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 446  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t2,t3);}

/* k3263 in k3259 in a3252 in k3249 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 446  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[162]+1)))(4,*((C_word*)lf[162]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3193,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 447  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[157]+1)))(2,*((C_word*)lf[157]+1),t2);}

/* k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3212,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 448  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[161]))(4,*((C_word*)lf[161]+1),t2,((C_word*)t0)[3],t3);}

/* a3211 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3212,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3218,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3218(t5,t1,((C_word*)t0)[2]);}

/* loop907 in a3211 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_3218(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3218,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3236,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3230,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 450  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[160]+1)))(3,*((C_word*)lf[160]+1),t5,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3228 in loop907 in a3211 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 450  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[157]+1)))(2,*((C_word*)lf[157]+1),((C_word*)t0)[2]);}

/* k3234 in loop907 in a3211 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3218(t3,((C_word*)t0)[2],t2);}

/* k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3199,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3206,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3210,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 451  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[159]))(2,*((C_word*)lf[159]+1),t4);}

/* k3208 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 451  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[21],"main#constant172"));}

/* k3204 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 451  setup-api#copy-file */
((C_proc4)C_retrieve_symbol_proc(lf[158]))(4,*((C_word*)lf[158]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3197 in k3194 in k3191 in k3188 in k3185 in k3182 in k3179 in k3176 in k3173 in k3170 in k3167 in loop in k3691 in k3688 in k4580 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 452  setup-api#remove-directory */
((C_proc3)C_retrieve_symbol_proc(lf[137]))(3,*((C_word*)lf[137]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4573 in a4570 in a4564 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 663  cleanup */
f_3150(((C_word*)t0)[2]);}

/* a4531 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4532(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4532,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4538,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k12261231 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4537 in a4531 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4542,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4563,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 658  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[156]))(2,*((C_word*)lf[156]+1),t3);}

/* k4561 in a4537 in a4531 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 658  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[157]+1)))(3,*((C_word*)lf[157]+1),((C_word*)t0)[2],t1);}

/* k4540 in a4537 in a4531 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4545,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 659  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[156]))(2,*((C_word*)lf[156]+1),t3);}

/* k4557 in k4540 in a4537 in a4531 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 659  print-error-message */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4543 in k4540 in a4537 in a4531 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4548,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 660  cleanup */
f_3150(t2);}

/* k4546 in k4543 in k4540 in a4537 in a4531 in a4525 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[17],"main#*running-test*"))){
/* chicken-install.scm: 661  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(2));}
else{
/* chicken-install.scm: 661  exit */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[2],C_fix(1));}}

/* k4513 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4518,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* g12291230 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4516 in k4513 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4521,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4524,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[154]))(2,*((C_word*)lf[154]+1),t3);}

/* k4522 in k4516 in k4513 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k4519 in k4516 in k4513 in k4510 in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#command in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_3664(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3664,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3668,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t4,*((C_word*)lf[153]+1),t2,t3);}

/* k3666 in main#command in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3671,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 481  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),t2,lf[152],t1);}

/* k3669 in k3666 in main#command in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 482  $system */
f_3642(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* main#$system in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_3642(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3642,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3646,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3659,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[14],"main#*windows-shell*"))){
/* chicken-install.scm: 474  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[42]+1)))(5,*((C_word*)lf[42]+1),t4,lf[149],t2,lf[150]);}
else{
t5=t2;
/* chicken-install.scm: 472  system */
((C_proc3)C_retrieve_symbol_proc(lf[148]))(3,*((C_word*)lf[148]+1),t3,t5);}}

/* k3657 in main#$system in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 472  system */
((C_proc3)C_retrieve_symbol_proc(lf[148]))(3,*((C_word*)lf[148]+1),((C_word*)t0)[2],t1);}

/* k3644 in main#$system in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_zerop(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* chicken-install.scm: 477  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[41]+1)))(5,*((C_word*)lf[41]+1),((C_word*)t0)[3],lf[147],t1,((C_word*)t0)[2]);}}

/* main#apply-mappings in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_3534(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3534,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3537,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3552,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3565,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3567,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 459  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[145]))(4,*((C_word*)lf[145]+1),t5,t6,t2);}

/* a3566 in main#apply-mappings in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3567,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3571,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3626,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 461  find */
((C_proc4)C_retrieve_symbol_proc(lf[144]))(4,*((C_word*)lf[144]+1),t3,t4,C_retrieve2(lf[18],"main#*mappings*"));}

/* a3625 in a3566 in main#apply-mappings in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3626(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3626,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3632,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(t2);
/* chicken-install.scm: 461  find */
((C_proc4)C_retrieve_symbol_proc(lf[144]))(4,*((C_word*)lf[144]+1),t1,t3,t4);}

/* a3631 in a3625 in a3566 in main#apply-mappings in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3632(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3632,3,t0,t1,t2);}
/* g949950 */
t3=((C_word*)t0)[3];
f_3537(4,t3,t1,((C_word*)t0)[2],t2);}

/* k3569 in a3566 in main#apply-mappings in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3571,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=t1;
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_i_cdr(t3);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3585,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_3585(t12,t2,t8);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* loop956 in k3569 in a3566 in main#apply-mappings in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_3585(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3585,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[28]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3614,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g972973 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3612 in loop956 in k3569 in a3566 in main#apply-mappings in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3614,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop956969 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3585(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop956969 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3585(t6,((C_word*)t0)[3],t5);}}

/* k3563 in main#apply-mappings in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 458  delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[142]))(4,*((C_word*)lf[142]+1),((C_word*)t0)[2],t1,*((C_word*)lf[143]+1));}

/* k3550 in main#apply-mappings in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3555,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3558,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 467  lset= */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t3,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k3556 in k3550 in main#apply-mappings in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
/* chicken-install.scm: 468  print */
((C_proc6)C_retrieve_proc(*((C_word*)lf[53]+1)))(6,*((C_word*)lf[53]+1),((C_word*)t0)[3],lf[139],((C_word*)t0)[2],lf[140],((C_word*)t0)[4]);}}

/* k3553 in k3550 in main#apply-mappings in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* same? in main#apply-mappings in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3537,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3545,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 456  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t4,t2);}

/* k3543 in same? in main#apply-mappings in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3549,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 456  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t2,((C_word*)t0)[2]);}

/* k3547 in k3543 in same? in main#apply-mappings in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_string_equal_p(((C_word*)t0)[2],t1));}

/* main#cleanup in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_3150(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3150,NULL,1,t1);}
if(C_truep(C_retrieve2(lf[1],"main#*keep*"))){
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3157,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 413  setup-download#temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[138]))(2,*((C_word*)lf[138]+1),t2);}}

/* k3155 in main#cleanup in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm: 414  setup-api#remove-directory */
((C_proc3)C_retrieve_symbol_proc(lf[137]))(3,*((C_word*)lf[137]+1),((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2298(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2298,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2302,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 271  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t3,lf[135]);}

/* k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2305,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2572,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2572(t6,t2,((C_word*)t0)[2]);}

/* loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2572(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2572,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2650,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_assoc(t4,C_retrieve2(lf[33],"main#*eggs+dirs+vers*"));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2597,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 277  delete */
((C_proc5)C_retrieve_symbol_proc(lf[98]))(5,*((C_word*)lf[98]+1),t6,t5,C_retrieve2(lf[33],"main#*eggs+dirs+vers*"),*((C_word*)lf[99]+1));}
else{
t6=C_i_pairp(t4);
t7=(C_truep(t6)?C_i_car(t4):t4);
t8=C_i_pairp(t4);
t9=(C_truep(t8)?C_i_cdr(t4):C_SCHEME_FALSE);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2611,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2617,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t3,t10,t11);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a2616 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2617,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2621,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=t4;
f_2621(2,t5,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 282  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),t4,lf[134]);}}

/* k2619 in a2616 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 283  print */
((C_proc6)C_retrieve_proc(*((C_word*)lf[53]+1)))(6,*((C_word*)lf[53]+1),t2,lf[132],((C_word*)t0)[5],lf[133],((C_word*)t0)[4]);}

/* k2622 in k2619 in a2616 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2624,2,t0,t1);}
t2=C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t2,C_retrieve2(lf[33],"main#*eggs+dirs+vers*"));
t4=C_mutate(&lf[33] /* (set! main#*eggs+dirs+vers* ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2139,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(C_retrieve2(lf[11],"main#*default-location*"))?C_retrieve2(lf[12],"main#*default-transport*"):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1606,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1610,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1613,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_eqp(C_retrieve2(lf[12],"main#*default-transport*"),lf[130]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1630,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 125  absolute-pathname? */
((C_proc3)C_retrieve_symbol_proc(lf[131]))(3,*((C_word*)lf[131]+1),t8,C_retrieve2(lf[11],"main#*default-location*"));}
else{
t8=t6;
f_1613(t8,C_SCHEME_FALSE);}}
else{
t4=C_retrieve2(lf[10],"main#*default-sources*");
t5=t2;
f_2139(t5,t4);}}

/* k1628 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1613(t2,C_i_not(t1));}

/* k1611 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_1613(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1613,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1620,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 126  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[123]))(2,*((C_word*)lf[123]+1),t2);}
else{
t2=C_retrieve2(lf[11],"main#*default-location*");
t3=((C_word*)t0)[2];
f_1606(t3,C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}}

/* k1618 in k1611 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 126  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[11],"main#*default-location*"));}

/* k1608 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1610,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1606(t2,C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST));}

/* k1604 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_1606(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1606,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[128],t1);
t3=C_a_i_cons(&a,2,C_retrieve2(lf[12],"main#*default-transport*"),C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[126],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t2,t5);
t7=((C_word*)t0)[2];
f_2139(t7,C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2139(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2139,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2141,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2141(t5,((C_word*)t0)[2],t1);}

/* trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2141(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2141,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
/* chicken-install.scm: 241  values */
C_values(4,0,t1,C_SCHEME_FALSE,lf[100]);}
else{
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2157,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t5=C_i_assq(lf[128],t3);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2205,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t5)){
t7=t4;
f_2157(t7,C_i_cadr(t5));}
else{
/* chicken-install.scm: 244  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[41]+1)))(4,*((C_word*)lf[41]+1),t6,lf[129],t3);}}}

/* k2203 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2157(t2,C_i_cadr(t1));}

/* k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2157(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2157,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=C_i_assq(lf[126],((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2195,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t2;
f_2160(t5,C_i_cadr(t3));}
else{
/* chicken-install.scm: 246  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[41]+1)))(4,*((C_word*)lf[41]+1),t4,lf[127],((C_word*)t0)[3]);}}

/* k2193 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2160(t2,C_i_cadr(t1));}

/* k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2160,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2165,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2171,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2170 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2171,4,t0,t1,t2,t3);}
if(C_truep(t2)){
/* chicken-install.scm: 249  values */
C_values(4,0,t1,t2,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1637,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 132  delete */
((C_proc5)C_retrieve_symbol_proc(lf[98]))(5,*((C_word*)lf[98]+1),t4,((C_word*)t0)[2],C_retrieve2(lf[10],"main#*default-sources*"),*((C_word*)lf[99]+1));}}

/* k1635 in a2170 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[10] /* (set! main#*default-sources* ...) */,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken-install.scm: 252  trying-sources */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2141(t4,((C_word*)t0)[2],t3);}

/* a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2165,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2002,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2007,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[125]+1)))(3,*((C_word*)lf[125]+1),t4,t5);}

/* a2006 in a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2007,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2013,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2100,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[124]))(4,*((C_word*)lf[124]+1),t1,t3,t4);}

/* a2099 in a2006 in a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2106,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2119,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2118 in a2099 in a2006 in a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2119r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2119r(t0,t1,t2);}}

static void C_ccall f_2119r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2125,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k382387 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2124 in a2118 in a2099 in a2006 in a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2125,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2105 in a2099 in a2006 in a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2114,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
/* chicken-install.scm: 218  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[123]))(2,*((C_word*)lf[123]+1),t2);}
else{
t3=t2;
f_2114(2,t3,C_SCHEME_FALSE);}}

/* k2112 in a2105 in a2099 in a2006 in a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 215  setup-download#retrieve-extension */
((C_proc21)C_retrieve_symbol_proc(lf[114]))(21,*((C_word*)lf[114]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[115],((C_word*)t0)[2],lf[116],t1,lf[117],C_retrieve2(lf[5],"main#*run-tests*"),lf[118],C_retrieve2(lf[8],"main#*username*"),lf[119],C_retrieve2(lf[9],"main#*password*"),lf[120],C_retrieve2(lf[20],"main#*trunk*"),lf[121],C_retrieve2(lf[15],"main#*proxy-host*"),lf[122],C_retrieve2(lf[16],"main#*proxy-port*"));}

/* a2012 in a2006 in a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2013,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2019,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k382387 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2018 in a2012 in a2006 in a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2019,2,t0,t1);}
t2=C_i_structurep(((C_word*)t0)[2],lf[101]);
t3=(C_truep(t2)?C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2029,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=C_i_memv(lf[110],t3);
t6=t4;
f_2029(t6,(C_truep(t5)?C_i_memv(lf[113],t3):C_SCHEME_FALSE));}
else{
t5=t4;
f_2029(t5,C_SCHEME_FALSE);}}

/* k2027 in a2018 in a2012 in a2006 in a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2029(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2029,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2032,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 226  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t2,lf[103]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2041,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_i_memv(lf[110],((C_word*)t0)[2]);
t4=t2;
f_2041(t4,(C_truep(t3)?C_i_memv(lf[112],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t3=t2;
f_2041(t3,C_SCHEME_FALSE);}}}

/* k2039 in k2027 in a2018 in a2012 in a2006 in a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2041(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2041,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 229  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t2,lf[105]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2053,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_i_memv(lf[110],((C_word*)t0)[2]);
t4=t2;
f_2053(t4,(C_truep(t3)?C_i_memv(lf[111],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t3=t2;
f_2053(t3,C_SCHEME_FALSE);}}}

/* k2051 in k2039 in k2027 in a2018 in a2012 in a2006 in a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2053,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2056,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 232  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t3,lf[108]);}
else{
t2=((C_word*)t0)[3];
/* chicken-install.scm: 236  abort */
((C_proc3)C_retrieve_symbol_proc(lf[109]))(3,*((C_word*)lf[109]+1),((C_word*)t0)[2],t2);}}

/* k2054 in k2051 in k2039 in k2027 in a2018 in a2012 in a2006 in a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2059,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 233  print-error-message */
((C_proc3)C_retrieve_symbol_proc(lf[107]))(3,*((C_word*)lf[107]+1),t2,((C_word*)t0)[2]);}

/* k2057 in k2054 in k2051 in k2039 in k2027 in a2018 in a2012 in a2006 in a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 234  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[106]);}

/* k2042 in k2039 in k2027 in a2018 in a2012 in a2006 in a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 230  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[104]);}

/* k2030 in k2027 in a2018 in a2012 in a2006 in a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 227  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[102]);}

/* k2000 in a2164 in k2158 in k2155 in trying-sources in k2137 in a2610 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g385386 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2595 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2597,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=C_mutate(&lf[33] /* (set! main#*eggs+dirs+vers* ...) */,t2);
t4=C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2572(t5,((C_word*)t0)[2],t4);}

/* k2648 in loop482 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2572(t3,((C_word*)t0)[2],t2);}

/* k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2305,2,t0,t1);}
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2313,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2313(t5,((C_word*)t0)[2],C_retrieve2(lf[33],"main#*eggs+dirs+vers*"));}}

/* loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2313(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2313,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2559,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
if(C_truep(C_i_member(t5,C_retrieve2(lf[35],"main#*checked*")))){
t6=C_slot(t2,C_fix(1));
t15=t1;
t16=t6;
t1=t15;
t2=t16;
goto loop;}
else{
t6=C_i_car(t4);
t7=C_a_i_cons(&a,2,t6,C_retrieve2(lf[35],"main#*checked*"));
t8=C_mutate(&lf[35] /* (set! main#*checked* ...) */,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2335,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=C_i_cadr(t4);
t11=C_i_car(t4);
/* chicken-install.scm: 291  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[96]))(5,*((C_word*)lf[96]+1),t9,t10,t11,lf[97]);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2341,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 292  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[95]))(3,*((C_word*)lf[95]+1),t2,t1);}

/* k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2341,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2344,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 293  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[90]))(4,*((C_word*)lf[90]+1),t2,((C_word*)t0)[2],*((C_word*)lf[91]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2536,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* chicken-install.scm: 326  string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[42]+1)))(6,*((C_word*)lf[42]+1),t2,lf[92],t3,lf[93],lf[94]);}}

/* k2534 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 325  warning */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* chicken-install.scm: 294  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t2,lf[88],t3,lf[89]);}

/* k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[3]);
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2666,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2676,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 334  feature? */
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t6,lf[87]);}

/* k2674 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2676,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_2350(2,t3,t2);}
else{
t2=C_i_assq(lf[78],((C_word*)t0)[4]);
if(C_truep(t2)){
t3=C_i_cadr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2691,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2691(3,t7,((C_word*)t0)[5],t3);}
else{
t3=((C_word*)t0)[5];
f_2350(2,t3,C_SCHEME_FALSE);}}}

/* loop in k2674 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2691,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2701,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 338  feature? */
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t3,t2);}
else{
if(C_truep(C_i_listp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=C_i_car(t2);
t5=C_eqp(lf[85],t4);
if(C_truep(t5)){
t6=C_i_cdr(t2);
t7=t3;
f_2726(t7,C_i_pairp(t6));}
else{
t6=t3;
f_2726(t6,C_SCHEME_FALSE);}}
else{
t3=C_i_cadr(((C_word*)t0)[3]);
/* chicken-install.scm: 340  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[41]+1)))(5,*((C_word*)lf[41]+1),t1,lf[86],((C_word*)t0)[2],t3);}}}

/* k2724 in loop in k2674 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2726(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2726,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2739,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[5]);
/* chicken-install.scm: 342  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2691(3,t4,t2,t3);}
else{
t2=C_i_car(((C_word*)t0)[5]);
t3=C_eqp(lf[80],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2755,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 344  every */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t4=C_i_car(((C_word*)t0)[5]);
t5=C_eqp(lf[82],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2781,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t7=C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 346  any */
((C_proc4)C_retrieve_symbol_proc(lf[83]))(4,*((C_word*)lf[83]+1),t6,((C_word*)((C_word*)t0)[4])[1],t7);}
else{
t6=C_i_cadr(((C_word*)t0)[3]);
/* chicken-install.scm: 347  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[41]+1)))(5,*((C_word*)lf[41]+1),((C_word*)t0)[7],lf[84],((C_word*)t0)[2],t6);}}}}

/* k2779 in k2724 in loop in k2674 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* chicken-install.scm: 346  fail */
t2=((C_word*)t0)[2];
f_2666(t2,((C_word*)t0)[3]);}}

/* k2753 in k2724 in loop in k2674 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm: 344  fail */
t2=((C_word*)t0)[3];
f_2666(t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2737 in k2724 in loop in k2674 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* chicken-install.scm: 342  fail */
t2=((C_word*)t0)[2];
f_2666(t2,((C_word*)t0)[3]);}}

/* k2699 in loop in k2674 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* chicken-install.scm: 338  fail */
t2=((C_word*)t0)[2];
f_2666(t2,((C_word*)t0)[3]);}}

/* fail in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2666(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2666,NULL,2,t0,t1);}
/* chicken-install.scm: 333  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[41]+1)))(4,*((C_word*)lf[41]+1),t1,lf[77],((C_word*)t0)[2]);}

/* k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* chicken-install.scm: 296  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t2,lf[75],t3,lf[76]);}

/* k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2358,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2364,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2364(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2364,4,t0,t1,t2,t3);}
t4=t2;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2369,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 298  apply-mappings */
f_3534(t6,((C_word*)t5)[1]);}

/* k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2369,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_car(((C_word*)t0)[4]);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2467,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2471,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 306  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),t9,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k2469 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2471,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2473,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2473(t5,((C_word*)t0)[2],t1);}

/* loop559 in k2469 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2473(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2473,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2483,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
if(C_truep(C_i_pairp(t4))){
t5=C_i_car(t4);
t6=t3;
f_2483(t6,C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST));}
else{
t5=t3;
f_2483(t5,C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2481 in loop559 in k2469 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2483(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop559572 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2473(t5,((C_word*)t0)[3],t4);}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop559572 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2473(t5,((C_word*)t0)[3],t4);}}

/* k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2467,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=C_a_i_cons(&a,2,t2,C_retrieve2(lf[34],"main#*dependencies*"));
t4=C_mutate(&lf[34] /* (set! main#*dependencies* ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2448,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2455,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 309  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t7,((C_word*)((C_word*)t0)[2])[1],lf[73]);}
else{
t6=t5;
f_2376(2,t6,C_SCHEME_UNDEFINED);}}

/* k2453 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 309  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),((C_word*)t0)[2],lf[72],t1);}

/* k2446 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 310  retrieve */
f_2298(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2374 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2382,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t3=C_retrieve2(lf[2],"main#*force*");
if(C_truep(t3)){
t4=t2;
f_2382(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2442,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2218,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=C_i_car(((C_word*)t0)[2]);
t8=C_a_i_list(&a,3,lf[63],t7,lf[64]);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2226,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2228,a[2]=t10,a[3]=t15,a[4]=t12,tmp=(C_word)a,a+=5,tmp));
t17=((C_word*)t15)[1];
f_2228(t17,t13,t5);}}
else{
t3=t2;
f_2382(2,t3,C_SCHEME_FALSE);}}

/* loop455 in k2374 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2228(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2228,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2288,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2281,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t7=C_i_car(t4);
/* chicken-install.scm: 264  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[30]))(3,*((C_word*)lf[30]+1),t6,t7);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2279 in loop455 in k2374 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_assq(lf[27],t1);
t3=(C_truep(t2)?C_i_cadr(t2):lf[66]);
t4=C_i_cdr(((C_word*)t0)[4]);
/* chicken-install.scm: 262  conc */
((C_proc10)C_retrieve_symbol_proc(lf[67]))(10,*((C_word*)lf[67]+1),((C_word*)t0)[3],lf[68],((C_word*)t0)[2],lf[69],t3,lf[70],t4,lf[71],C_make_character(10));}

/* k2286 in loop455 in k2374 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2288,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop455468 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2228(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop455468 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2228(t6,((C_word*)t0)[3],t5);}}

/* k2224 in k2374 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 256  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[65]);}

/* k2216 in k2374 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 255  string-concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),((C_word*)t0)[2],t1);}

/* k2440 in k2374 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 313  setup-api#yes-or-no? */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[2],t1,lf[61]);}

/* k2380 in k2374 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2382,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2385,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 316  unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[59]))(3,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2383 in k2380 in k2374 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2388,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2429,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 317  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t3,t1,lf[58]);}

/* k2427 in k2383 in k2380 in k2374 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 317  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),((C_word*)t0)[2],lf[56],t1);}

/* k2386 in k2383 in k2380 in k2374 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2396,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2396(t6,t2,((C_word*)t0)[2]);}

/* loop596 in k2386 in k2383 in k2380 in k2374 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_2396(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2396,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2414,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2408,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 320  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t5,lf[54],t4,lf[55]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2406 in loop596 in k2386 in k2383 in k2380 in k2374 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 321  setup-api#remove-extension */
((C_proc3)C_retrieve_symbol_proc(lf[52]))(3,*((C_word*)lf[52]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2412 in loop596 in k2386 in k2383 in k2380 in k2374 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2396(t3,((C_word*)t0)[2],t2);}

/* k2389 in k2386 in k2383 in k2380 in k2374 in k2465 in k2367 in a2363 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 323  retrieve */
f_2298(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2358,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1786,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=f_1639(lf[48],t2);
t5=f_1639(lf[49],t2);
if(C_truep(C_retrieve2(lf[5],"main#*run-tests*"))){
t6=f_1639(lf[50],t2);
/* chicken-install.scm: 164  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t3,t4,t5,t6);}
else{
/* chicken-install.scm: 164  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t3,t4,t5,C_SCHEME_END_OF_LIST);}}

/* k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1786,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1791,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1791(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_1791(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1791,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1805,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 173  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t5,t3);}
else{
t5=C_i_car(t2);
t6=C_i_cdr(t2);
t7=C_i_symbolp(t5);
t8=(C_truep(t7)?t7:C_i_stringp(t5));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1834,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm: 178  ext-version */
f_1709(t9,t5);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1847,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_listp(t5))){
t10=C_i_length(t5);
if(C_truep(C_i_nequalp(C_fix(2),t10))){
t11=C_i_car(t5);
t12=C_i_stringp(t11);
if(C_truep(t12)){
t13=t9;
f_1847(t13,t12);}
else{
t13=C_i_car(t5);
t14=t9;
f_1847(t14,C_i_symbolp(t13));}}
else{
t11=t9;
f_1847(t11,C_SCHEME_FALSE);}}
else{
t10=t9;
f_1847(t10,C_SCHEME_FALSE);}}}}

/* k1845 in loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_1847(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1847,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 184  ext-version */
f_1709(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1953,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 201  warning */
((C_proc4)C_retrieve_symbol_proc(lf[46]))(4,*((C_word*)lf[46]+1),t2,lf[47],((C_word*)t0)[2]);}}

/* k1951 in k1845 in loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 204  loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_1791(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1848 in k1845 in loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1850,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1942,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 187  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 186  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t3,t4);}}

/* k1865 in k1848 in k1845 in loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1867,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken-install.scm: 186  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1791(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1940 in k1848 in k1845 in loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 187  setup-api#version>=? */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1936 in k1848 in k1845 in loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1938,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm: 199  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_1791(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1927,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 188  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t3,t4);}}

/* k1925 in k1936 in k1848 in k1845 in loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1927,2,t0,t1);}
t2=C_i_string_equal_p(lf[40],t1);
t3=(C_truep(t2)?C_i_not(C_retrieve2(lf[2],"main#*force*")):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1913,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 191  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[42]+1)))(5,*((C_word*)lf[42]+1),t4,lf[43],t5,lf[44]);}
else{
t4=((C_word*)t0)[3];
f_1880(2,t4,C_SCHEME_UNDEFINED);}}

/* k1911 in k1925 in k1936 in k1848 in k1845 in loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 190  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),((C_word*)t0)[2],t1);}

/* k1878 in k1936 in k1848 in k1845 in loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1887,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 197  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t3,t4);}

/* k1889 in k1878 in k1936 in k1848 in k1845 in loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1895,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 197  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t2,t3);}

/* k1893 in k1889 in k1878 in k1936 in k1848 in k1845 in loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 196  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[39]))(5,*((C_word*)lf[39]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1885 in k1878 in k1936 in k1848 in k1845 in loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 195  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1791(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1832 in loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1834,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
/* chicken-install.scm: 177  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_1791(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 180  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t2,((C_word*)t0)[2]);}}

/* k1839 in k1832 in loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1841,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken-install.scm: 177  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1791(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1803 in loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1809,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 173  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t2,((C_word*)t0)[2]);}

/* k1807 in k1803 in loop in k1784 in a2357 in k2351 in k2348 in k2345 in k2342 in k2339 in k2333 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 173  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2557 in loop527 in k2303 in k2300 in main#retrieve in k1994 in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2313(t3,((C_word*)t0)[2],t2);}

/* main#ext-version in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_1709(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1709,NULL,2,t1,t2);}
t3=C_eqp(t2,lf[25]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1719,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_1719(t5,t3);}
else{
t5=C_i_equalp(t2,lf[31]);
if(C_truep(t5)){
t6=t4;
f_1719(t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1759,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 153  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t6,t2);}}}

/* k1757 in main#ext-version in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1719(t2,C_i_member(t1,C_retrieve(lf[32])));}

/* k1717 in main#ext-version in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_fcall f_1719(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1719,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm: 154  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[26]))(2,*((C_word*)lf[26]+1),((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1725,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 155  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[30]))(3,*((C_word*)lf[30]+1),t2,((C_word*)t0)[2]);}}

/* k1723 in k1717 in main#ext-version in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=t1;
t4=C_i_assq(lf[27],t3);
if(C_truep(t4)){
t5=C_i_cadr(t4);
/* chicken-install.scm: 159  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t2,t5);}
else{
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[29]);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* main#deps in k1357 in k1354 in k1351 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 */
static C_word C_fcall f_1639(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=C_i_assq(t1,t2);
if(C_truep(t3)){
t4=C_i_cdr(t3);
return((C_truep(t4)?t4:C_SCHEME_END_OF_LIST));}
else{
return(C_SCHEME_END_OF_LIST);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[362] = {
{"toplevel:chicken_install_scm",(void*)C_toplevel},
{"f_1309:chicken_install_scm",(void*)f_1309},
{"f_1312:chicken_install_scm",(void*)f_1312},
{"f_1315:chicken_install_scm",(void*)f_1315},
{"f_1318:chicken_install_scm",(void*)f_1318},
{"f_1321:chicken_install_scm",(void*)f_1321},
{"f_1324:chicken_install_scm",(void*)f_1324},
{"f_1327:chicken_install_scm",(void*)f_1327},
{"f_1330:chicken_install_scm",(void*)f_1330},
{"f_1333:chicken_install_scm",(void*)f_1333},
{"f_1336:chicken_install_scm",(void*)f_1336},
{"f_1339:chicken_install_scm",(void*)f_1339},
{"f_1342:chicken_install_scm",(void*)f_1342},
{"f_1345:chicken_install_scm",(void*)f_1345},
{"f_1348:chicken_install_scm",(void*)f_1348},
{"f_1353:chicken_install_scm",(void*)f_1353},
{"f_1356:chicken_install_scm",(void*)f_1356},
{"f_1359:chicken_install_scm",(void*)f_1359},
{"f_4602:chicken_install_scm",(void*)f_4602},
{"f_4598:chicken_install_scm",(void*)f_4598},
{"f_1996:chicken_install_scm",(void*)f_1996},
{"f_4512:chicken_install_scm",(void*)f_4512},
{"f_4526:chicken_install_scm",(void*)f_4526},
{"f_4565:chicken_install_scm",(void*)f_4565},
{"f_4584:chicken_install_scm",(void*)f_4584},
{"f_4590:chicken_install_scm",(void*)f_4590},
{"f_4571:chicken_install_scm",(void*)f_4571},
{"f_4582:chicken_install_scm",(void*)f_4582},
{"f_1570:chicken_install_scm",(void*)f_1570},
{"f_1386:chicken_install_scm",(void*)f_1386},
{"f_1566:chicken_install_scm",(void*)f_1566},
{"f_1405:chicken_install_scm",(void*)f_1405},
{"f_1407:chicken_install_scm",(void*)f_1407},
{"f_1551:chicken_install_scm",(void*)f_1551},
{"f_1415:chicken_install_scm",(void*)f_1415},
{"f_1419:chicken_install_scm",(void*)f_1419},
{"f_1460:chicken_install_scm",(void*)f_1460},
{"f_1525:chicken_install_scm",(void*)f_1525},
{"f_1487:chicken_install_scm",(void*)f_1487},
{"f_1518:chicken_install_scm",(void*)f_1518},
{"f_1491:chicken_install_scm",(void*)f_1491},
{"f_1494:chicken_install_scm",(void*)f_1494},
{"f_1505:chicken_install_scm",(void*)f_1505},
{"f_1499:chicken_install_scm",(void*)f_1499},
{"f_1454:chicken_install_scm",(void*)f_1454},
{"f_1450:chicken_install_scm",(void*)f_1450},
{"f_1432:chicken_install_scm",(void*)f_1432},
{"f_1388:chicken_install_scm",(void*)f_1388},
{"f_3690:chicken_install_scm",(void*)f_3690},
{"f_3693:chicken_install_scm",(void*)f_3693},
{"f_3698:chicken_install_scm",(void*)f_3698},
{"f_3826:chicken_install_scm",(void*)f_3826},
{"f_4301:chicken_install_scm",(void*)f_4301},
{"f_4453:chicken_install_scm",(void*)f_4453},
{"f_4411:chicken_install_scm",(void*)f_4411},
{"f_4415:chicken_install_scm",(void*)f_4415},
{"f_4427:chicken_install_scm",(void*)f_4427},
{"f_4366:chicken_install_scm",(void*)f_4366},
{"f_4389:chicken_install_scm",(void*)f_4389},
{"f_4398:chicken_install_scm",(void*)f_4398},
{"f_4405:chicken_install_scm",(void*)f_4405},
{"f_4392:chicken_install_scm",(void*)f_4392},
{"f_4370:chicken_install_scm",(void*)f_4370},
{"f4966:chicken_install_scm",(void*)f4966},
{"f_4350:chicken_install_scm",(void*)f_4350},
{"f_4310:chicken_install_scm",(void*)f_4310},
{"f_4342:chicken_install_scm",(void*)f_4342},
{"f_4316:chicken_install_scm",(void*)f_4316},
{"f4961:chicken_install_scm",(void*)f4961},
{"f_4333:chicken_install_scm",(void*)f_4333},
{"f_4327:chicken_install_scm",(void*)f_4327},
{"f_4323:chicken_install_scm",(void*)f_4323},
{"f4956:chicken_install_scm",(void*)f4956},
{"f_4274:chicken_install_scm",(void*)f_4274},
{"f4951:chicken_install_scm",(void*)f4951},
{"f_4230:chicken_install_scm",(void*)f_4230},
{"f4946:chicken_install_scm",(void*)f4946},
{"f_4127:chicken_install_scm",(void*)f_4127},
{"f_4130:chicken_install_scm",(void*)f_4130},
{"f_4150:chicken_install_scm",(void*)f_4150},
{"f4933:chicken_install_scm",(void*)f4933},
{"f_4098:chicken_install_scm",(void*)f_4098},
{"f_1658:chicken_install_scm",(void*)f_1658},
{"f_1664:chicken_install_scm",(void*)f_1664},
{"f_1669:chicken_install_scm",(void*)f_1669},
{"f_1696:chicken_install_scm",(void*)f_1696},
{"f_1677:chicken_install_scm",(void*)f_1677},
{"f_1693:chicken_install_scm",(void*)f_1693},
{"f_1685:chicken_install_scm",(void*)f_1685},
{"f_1689:chicken_install_scm",(void*)f_1689},
{"f_4101:chicken_install_scm",(void*)f_4101},
{"f_4069:chicken_install_scm",(void*)f_4069},
{"f_4062:chicken_install_scm",(void*)f_4062},
{"f4926:chicken_install_scm",(void*)f4926},
{"f_3994:chicken_install_scm",(void*)f_3994},
{"f_4011:chicken_install_scm",(void*)f_4011},
{"f_4022:chicken_install_scm",(void*)f_4022},
{"f_4018:chicken_install_scm",(void*)f_4018},
{"f_4001:chicken_install_scm",(void*)f_4001},
{"f4921:chicken_install_scm",(void*)f4921},
{"f_3957:chicken_install_scm",(void*)f_3957},
{"f_3961:chicken_install_scm",(void*)f_3961},
{"f4916:chicken_install_scm",(void*)f4916},
{"f_3924:chicken_install_scm",(void*)f_3924},
{"f_3888:chicken_install_scm",(void*)f_3888},
{"f_3845:chicken_install_scm",(void*)f_3845},
{"f_3838:chicken_install_scm",(void*)f_3838},
{"f4911:chicken_install_scm",(void*)f4911},
{"f_3746:chicken_install_scm",(void*)f_3746},
{"f_3811:chicken_install_scm",(void*)f_3811},
{"f_3762:chicken_install_scm",(void*)f_3762},
{"f_3797:chicken_install_scm",(void*)f_3797},
{"f_3760:chicken_install_scm",(void*)f_3760},
{"f_3756:chicken_install_scm",(void*)f_3756},
{"f_3714:chicken_install_scm",(void*)f_3714},
{"f_3731:chicken_install_scm",(void*)f_3731},
{"f_3717:chicken_install_scm",(void*)f_3717},
{"f_3728:chicken_install_scm",(void*)f_3728},
{"f_3724:chicken_install_scm",(void*)f_3724},
{"f_2941:chicken_install_scm",(void*)f_2941},
{"f_3148:chicken_install_scm",(void*)f_3148},
{"f_2947:chicken_install_scm",(void*)f_2947},
{"f_2953:chicken_install_scm",(void*)f_2953},
{"f_2956:chicken_install_scm",(void*)f_2956},
{"f_3140:chicken_install_scm",(void*)f_3140},
{"f_2963:chicken_install_scm",(void*)f_2963},
{"f_2967:chicken_install_scm",(void*)f_2967},
{"f_2969:chicken_install_scm",(void*)f_2969},
{"f_3113:chicken_install_scm",(void*)f_3113},
{"f_2977:chicken_install_scm",(void*)f_2977},
{"f_3097:chicken_install_scm",(void*)f_3097},
{"f_3081:chicken_install_scm",(void*)f_3081},
{"f_3084:chicken_install_scm",(void*)f_3084},
{"f_3087:chicken_install_scm",(void*)f_3087},
{"f_2984:chicken_install_scm",(void*)f_2984},
{"f_2987:chicken_install_scm",(void*)f_2987},
{"f_2990:chicken_install_scm",(void*)f_2990},
{"f_3007:chicken_install_scm",(void*)f_3007},
{"f_2932:chicken_install_scm",(void*)f_2932},
{"f_2828:chicken_install_scm",(void*)f_2828},
{"f_2832:chicken_install_scm",(void*)f_2832},
{"f_2835:chicken_install_scm",(void*)f_2835},
{"f_2838:chicken_install_scm",(void*)f_2838},
{"f_2841:chicken_install_scm",(void*)f_2841},
{"f_2844:chicken_install_scm",(void*)f_2844},
{"f_2847:chicken_install_scm",(void*)f_2847},
{"f_2850:chicken_install_scm",(void*)f_2850},
{"f_2918:chicken_install_scm",(void*)f_2918},
{"f_2893:chicken_install_scm",(void*)f_2893},
{"f_2896:chicken_install_scm",(void*)f_2896},
{"f_2909:chicken_install_scm",(void*)f_2909},
{"f_2899:chicken_install_scm",(void*)f_2899},
{"f_2902:chicken_install_scm",(void*)f_2902},
{"f_2870:chicken_install_scm",(void*)f_2870},
{"f_2882:chicken_install_scm",(void*)f_2882},
{"f_2878:chicken_install_scm",(void*)f_2878},
{"f_3011:chicken_install_scm",(void*)f_3011},
{"f_3014:chicken_install_scm",(void*)f_3014},
{"f_3017:chicken_install_scm",(void*)f_3017},
{"f_3047:chicken_install_scm",(void*)f_3047},
{"f_3053:chicken_install_scm",(void*)f_3053},
{"f_3023:chicken_install_scm",(void*)f_3023},
{"f_3027:chicken_install_scm",(void*)f_3027},
{"f_3030:chicken_install_scm",(void*)f_3030},
{"f_2994:chicken_install_scm",(void*)f_2994},
{"f_2998:chicken_install_scm",(void*)f_2998},
{"f_3001:chicken_install_scm",(void*)f_3001},
{"f_3532:chicken_install_scm",(void*)f_3532},
{"f_3528:chicken_install_scm",(void*)f_3528},
{"f_3169:chicken_install_scm",(void*)f_3169},
{"f_3172:chicken_install_scm",(void*)f_3172},
{"f_3175:chicken_install_scm",(void*)f_3175},
{"f_3178:chicken_install_scm",(void*)f_3178},
{"f_3181:chicken_install_scm",(void*)f_3181},
{"f_3521:chicken_install_scm",(void*)f_3521},
{"f_3403:chicken_install_scm",(void*)f_3403},
{"f_3409:chicken_install_scm",(void*)f_3409},
{"f_3508:chicken_install_scm",(void*)f_3508},
{"f_3417:chicken_install_scm",(void*)f_3417},
{"f_3421:chicken_install_scm",(void*)f_3421},
{"f_3429:chicken_install_scm",(void*)f_3429},
{"f_3467:chicken_install_scm",(void*)f_3467},
{"f_3495:chicken_install_scm",(void*)f_3495},
{"f_3501:chicken_install_scm",(void*)f_3501},
{"f_3473:chicken_install_scm",(void*)f_3473},
{"f_3489:chicken_install_scm",(void*)f_3489},
{"f_3435:chicken_install_scm",(void*)f_3435},
{"f_3441:chicken_install_scm",(void*)f_3441},
{"f_3449:chicken_install_scm",(void*)f_3449},
{"f_3453:chicken_install_scm",(void*)f_3453},
{"f_3456:chicken_install_scm",(void*)f_3456},
{"f_3459:chicken_install_scm",(void*)f_3459},
{"f_3462:chicken_install_scm",(void*)f_3462},
{"f_3465:chicken_install_scm",(void*)f_3465},
{"f_3424:chicken_install_scm",(void*)f_3424},
{"f_3398:chicken_install_scm",(void*)f_3398},
{"f_3184:chicken_install_scm",(void*)f_3184},
{"f_3187:chicken_install_scm",(void*)f_3187},
{"f_3275:chicken_install_scm",(void*)f_3275},
{"f_3282:chicken_install_scm",(void*)f_3282},
{"f_3285:chicken_install_scm",(void*)f_3285},
{"f_3296:chicken_install_scm",(void*)f_3296},
{"f_3354:chicken_install_scm",(void*)f_3354},
{"f_3381:chicken_install_scm",(void*)f_3381},
{"f_3304:chicken_install_scm",(void*)f_3304},
{"f_3310:chicken_install_scm",(void*)f_3310},
{"f_3337:chicken_install_scm",(void*)f_3337},
{"f_3308:chicken_install_scm",(void*)f_3308},
{"f_3290:chicken_install_scm",(void*)f_3290},
{"f_3251:chicken_install_scm",(void*)f_3251},
{"f_3253:chicken_install_scm",(void*)f_3253},
{"f_3261:chicken_install_scm",(void*)f_3261},
{"f_3265:chicken_install_scm",(void*)f_3265},
{"f_3190:chicken_install_scm",(void*)f_3190},
{"f_3193:chicken_install_scm",(void*)f_3193},
{"f_3212:chicken_install_scm",(void*)f_3212},
{"f_3218:chicken_install_scm",(void*)f_3218},
{"f_3230:chicken_install_scm",(void*)f_3230},
{"f_3236:chicken_install_scm",(void*)f_3236},
{"f_3196:chicken_install_scm",(void*)f_3196},
{"f_3210:chicken_install_scm",(void*)f_3210},
{"f_3206:chicken_install_scm",(void*)f_3206},
{"f_3199:chicken_install_scm",(void*)f_3199},
{"f_4575:chicken_install_scm",(void*)f_4575},
{"f_4532:chicken_install_scm",(void*)f_4532},
{"f_4538:chicken_install_scm",(void*)f_4538},
{"f_4563:chicken_install_scm",(void*)f_4563},
{"f_4542:chicken_install_scm",(void*)f_4542},
{"f_4559:chicken_install_scm",(void*)f_4559},
{"f_4545:chicken_install_scm",(void*)f_4545},
{"f_4548:chicken_install_scm",(void*)f_4548},
{"f_4515:chicken_install_scm",(void*)f_4515},
{"f_4518:chicken_install_scm",(void*)f_4518},
{"f_4524:chicken_install_scm",(void*)f_4524},
{"f_4521:chicken_install_scm",(void*)f_4521},
{"f_3664:chicken_install_scm",(void*)f_3664},
{"f_3668:chicken_install_scm",(void*)f_3668},
{"f_3671:chicken_install_scm",(void*)f_3671},
{"f_3642:chicken_install_scm",(void*)f_3642},
{"f_3659:chicken_install_scm",(void*)f_3659},
{"f_3646:chicken_install_scm",(void*)f_3646},
{"f_3534:chicken_install_scm",(void*)f_3534},
{"f_3567:chicken_install_scm",(void*)f_3567},
{"f_3626:chicken_install_scm",(void*)f_3626},
{"f_3632:chicken_install_scm",(void*)f_3632},
{"f_3571:chicken_install_scm",(void*)f_3571},
{"f_3585:chicken_install_scm",(void*)f_3585},
{"f_3614:chicken_install_scm",(void*)f_3614},
{"f_3565:chicken_install_scm",(void*)f_3565},
{"f_3552:chicken_install_scm",(void*)f_3552},
{"f_3558:chicken_install_scm",(void*)f_3558},
{"f_3555:chicken_install_scm",(void*)f_3555},
{"f_3537:chicken_install_scm",(void*)f_3537},
{"f_3545:chicken_install_scm",(void*)f_3545},
{"f_3549:chicken_install_scm",(void*)f_3549},
{"f_3150:chicken_install_scm",(void*)f_3150},
{"f_3157:chicken_install_scm",(void*)f_3157},
{"f_2298:chicken_install_scm",(void*)f_2298},
{"f_2302:chicken_install_scm",(void*)f_2302},
{"f_2572:chicken_install_scm",(void*)f_2572},
{"f_2617:chicken_install_scm",(void*)f_2617},
{"f_2621:chicken_install_scm",(void*)f_2621},
{"f_2624:chicken_install_scm",(void*)f_2624},
{"f_2611:chicken_install_scm",(void*)f_2611},
{"f_1630:chicken_install_scm",(void*)f_1630},
{"f_1613:chicken_install_scm",(void*)f_1613},
{"f_1620:chicken_install_scm",(void*)f_1620},
{"f_1610:chicken_install_scm",(void*)f_1610},
{"f_1606:chicken_install_scm",(void*)f_1606},
{"f_2139:chicken_install_scm",(void*)f_2139},
{"f_2141:chicken_install_scm",(void*)f_2141},
{"f_2205:chicken_install_scm",(void*)f_2205},
{"f_2157:chicken_install_scm",(void*)f_2157},
{"f_2195:chicken_install_scm",(void*)f_2195},
{"f_2160:chicken_install_scm",(void*)f_2160},
{"f_2171:chicken_install_scm",(void*)f_2171},
{"f_1637:chicken_install_scm",(void*)f_1637},
{"f_2165:chicken_install_scm",(void*)f_2165},
{"f_2007:chicken_install_scm",(void*)f_2007},
{"f_2100:chicken_install_scm",(void*)f_2100},
{"f_2119:chicken_install_scm",(void*)f_2119},
{"f_2125:chicken_install_scm",(void*)f_2125},
{"f_2106:chicken_install_scm",(void*)f_2106},
{"f_2114:chicken_install_scm",(void*)f_2114},
{"f_2013:chicken_install_scm",(void*)f_2013},
{"f_2019:chicken_install_scm",(void*)f_2019},
{"f_2029:chicken_install_scm",(void*)f_2029},
{"f_2041:chicken_install_scm",(void*)f_2041},
{"f_2053:chicken_install_scm",(void*)f_2053},
{"f_2056:chicken_install_scm",(void*)f_2056},
{"f_2059:chicken_install_scm",(void*)f_2059},
{"f_2044:chicken_install_scm",(void*)f_2044},
{"f_2032:chicken_install_scm",(void*)f_2032},
{"f_2002:chicken_install_scm",(void*)f_2002},
{"f_2597:chicken_install_scm",(void*)f_2597},
{"f_2650:chicken_install_scm",(void*)f_2650},
{"f_2305:chicken_install_scm",(void*)f_2305},
{"f_2313:chicken_install_scm",(void*)f_2313},
{"f_2335:chicken_install_scm",(void*)f_2335},
{"f_2341:chicken_install_scm",(void*)f_2341},
{"f_2536:chicken_install_scm",(void*)f_2536},
{"f_2344:chicken_install_scm",(void*)f_2344},
{"f_2347:chicken_install_scm",(void*)f_2347},
{"f_2676:chicken_install_scm",(void*)f_2676},
{"f_2691:chicken_install_scm",(void*)f_2691},
{"f_2726:chicken_install_scm",(void*)f_2726},
{"f_2781:chicken_install_scm",(void*)f_2781},
{"f_2755:chicken_install_scm",(void*)f_2755},
{"f_2739:chicken_install_scm",(void*)f_2739},
{"f_2701:chicken_install_scm",(void*)f_2701},
{"f_2666:chicken_install_scm",(void*)f_2666},
{"f_2350:chicken_install_scm",(void*)f_2350},
{"f_2353:chicken_install_scm",(void*)f_2353},
{"f_2364:chicken_install_scm",(void*)f_2364},
{"f_2369:chicken_install_scm",(void*)f_2369},
{"f_2471:chicken_install_scm",(void*)f_2471},
{"f_2473:chicken_install_scm",(void*)f_2473},
{"f_2483:chicken_install_scm",(void*)f_2483},
{"f_2467:chicken_install_scm",(void*)f_2467},
{"f_2455:chicken_install_scm",(void*)f_2455},
{"f_2448:chicken_install_scm",(void*)f_2448},
{"f_2376:chicken_install_scm",(void*)f_2376},
{"f_2228:chicken_install_scm",(void*)f_2228},
{"f_2281:chicken_install_scm",(void*)f_2281},
{"f_2288:chicken_install_scm",(void*)f_2288},
{"f_2226:chicken_install_scm",(void*)f_2226},
{"f_2218:chicken_install_scm",(void*)f_2218},
{"f_2442:chicken_install_scm",(void*)f_2442},
{"f_2382:chicken_install_scm",(void*)f_2382},
{"f_2385:chicken_install_scm",(void*)f_2385},
{"f_2429:chicken_install_scm",(void*)f_2429},
{"f_2388:chicken_install_scm",(void*)f_2388},
{"f_2396:chicken_install_scm",(void*)f_2396},
{"f_2408:chicken_install_scm",(void*)f_2408},
{"f_2414:chicken_install_scm",(void*)f_2414},
{"f_2391:chicken_install_scm",(void*)f_2391},
{"f_2358:chicken_install_scm",(void*)f_2358},
{"f_1786:chicken_install_scm",(void*)f_1786},
{"f_1791:chicken_install_scm",(void*)f_1791},
{"f_1847:chicken_install_scm",(void*)f_1847},
{"f_1953:chicken_install_scm",(void*)f_1953},
{"f_1850:chicken_install_scm",(void*)f_1850},
{"f_1867:chicken_install_scm",(void*)f_1867},
{"f_1942:chicken_install_scm",(void*)f_1942},
{"f_1938:chicken_install_scm",(void*)f_1938},
{"f_1927:chicken_install_scm",(void*)f_1927},
{"f_1913:chicken_install_scm",(void*)f_1913},
{"f_1880:chicken_install_scm",(void*)f_1880},
{"f_1891:chicken_install_scm",(void*)f_1891},
{"f_1895:chicken_install_scm",(void*)f_1895},
{"f_1887:chicken_install_scm",(void*)f_1887},
{"f_1834:chicken_install_scm",(void*)f_1834},
{"f_1841:chicken_install_scm",(void*)f_1841},
{"f_1805:chicken_install_scm",(void*)f_1805},
{"f_1809:chicken_install_scm",(void*)f_1809},
{"f_2559:chicken_install_scm",(void*)f_2559},
{"f_1709:chicken_install_scm",(void*)f_1709},
{"f_1759:chicken_install_scm",(void*)f_1759},
{"f_1719:chicken_install_scm",(void*)f_1719},
{"f_1725:chicken_install_scm",(void*)f_1725},
{"f_1639:chicken_install_scm",(void*)f_1639},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
