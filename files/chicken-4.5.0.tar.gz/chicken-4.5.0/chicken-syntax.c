/* Generated from chicken-syntax.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:51
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: chicken-syntax.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -output-file chicken-syntax.c
   unit: chicken_syntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[232];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,28),40,97,50,50,55,53,32,102,111,114,109,50,48,57,49,32,114,50,48,57,50,32,99,50,48,57,51,41,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,52),40,97,50,50,56,53,32,105,110,112,117,116,50,48,54,48,50,48,55,51,32,114,101,110,97,109,101,50,48,54,57,50,48,55,52,32,99,111,109,112,97,114,101,50,48,53,55,50,48,55,53,41,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,52),40,97,50,51,52,49,32,105,110,112,117,116,50,48,48,56,50,48,50,49,32,114,101,110,97,109,101,50,48,49,55,50,48,50,50,32,99,111,109,112,97,114,101,50,48,48,53,50,48,50,51,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,25),40,97,50,53,48,55,32,120,49,57,57,53,32,114,49,57,57,54,32,99,49,57,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,28),40,97,50,53,51,50,32,102,111,114,109,49,57,56,55,32,114,49,57,56,56,32,99,49,57,56,57,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,28),40,97,50,53,54,57,32,102,111,114,109,49,57,55,52,32,114,49,57,55,53,32,99,49,57,55,54,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,47),40,108,111,111,112,32,120,115,49,57,52,57,32,118,97,114,115,49,57,53,48,32,98,115,49,57,53,49,32,118,97,108,115,49,57,53,50,32,114,101,115,116,49,57,53,51,41,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,28),40,97,50,54,55,48,32,102,111,114,109,49,57,52,50,32,114,49,57,52,51,32,99,49,57,52,52,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,40),40,108,111,111,112,32,120,115,49,57,49,53,32,118,97,114,115,49,57,49,54,32,118,97,108,115,49,57,49,55,32,114,101,115,116,49,57,49,56,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,28),40,97,50,56,57,53,32,102,111,114,109,49,57,48,56,32,114,49,57,48,57,32,99,49,57,49,48,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,115,108,111,116,115,49,56,53,55,32,105,49,56,53,56,41,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,7),40,103,49,56,53,48,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,56,51,52,32,103,49,56,52,52,49,56,52,56,41,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,56,48,55,32,103,49,56,49,55,49,56,50,49,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,28),40,97,51,48,56,57,32,102,111,114,109,49,55,57,49,32,114,49,55,57,50,32,99,49,55,57,51,41,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,7),40,103,49,55,52,52,41,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,55,50,56,32,103,49,55,51,56,49,55,52,50,41,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,20),40,112,97,114,115,101,45,99,108,97,117,115,101,32,99,49,55,48,51,41,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,55,54,52,32,103,49,55,55,52,49,55,55,56,41,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,28),40,97,51,54,52,56,32,102,111,114,109,49,54,57,48,32,114,49,54,57,49,32,99,49,54,57,50,41,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,28),40,97,52,48,54,53,32,102,111,114,109,49,54,55,54,32,114,49,54,55,55,32,99,49,54,55,56,41,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,28),40,97,52,50,55,54,32,102,111,114,109,49,54,53,48,32,114,49,54,53,49,32,99,49,54,53,50,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,53,50,55,41,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,15),40,103,101,110,118,97,114,115,32,110,49,53,50,53,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,7),40,97,52,53,49,56,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,30),40,108,111,111,112,49,54,50,49,32,103,49,54,51,49,49,54,51,54,32,103,49,54,51,50,49,54,51,55,41,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,27),40,98,117,105,108,100,32,118,97,114,115,50,49,53,57,51,32,118,114,101,115,116,49,53,57,52,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,27),40,97,52,53,50,56,32,118,97,114,115,49,49,53,56,57,32,118,97,114,115,50,49,53,57,48,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,34),40,97,52,52,56,54,32,118,97,114,115,49,53,55,49,32,97,114,103,99,49,53,55,50,32,114,101,115,116,49,53,55,51,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,22),40,97,52,52,55,54,32,99,49,53,54,57,32,98,111,100,121,49,53,55,48,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,34),40,97,52,56,53,49,32,118,97,114,115,49,53,53,50,32,97,114,103,99,49,53,53,51,32,114,101,115,116,49,53,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,53,51,51,32,103,49,53,52,51,49,53,52,55,41,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,28),40,97,52,51,55,52,32,102,111,114,109,49,53,50,49,32,114,49,53,50,50,32,99,49,53,50,51,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,27),40,108,111,111,112,32,97,114,103,115,49,52,57,57,32,118,97,114,100,101,102,115,49,53,48,48,41,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,28),40,97,52,57,49,51,32,102,111,114,109,49,52,56,52,32,114,49,52,56,53,32,99,49,52,56,54,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,28),40,97,53,50,50,49,32,102,111,114,109,49,52,54,54,32,114,49,52,54,55,32,99,49,52,54,56,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,48),40,114,101,99,117,114,32,118,97,114,115,49,51,51,52,32,100,101,102,97,117,108,116,101,114,115,49,51,51,53,32,110,111,110,45,100,101,102,97,117,108,116,115,49,51,51,54,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,61),40,109,97,107,101,45,105,102,45,116,114,101,101,32,118,97,114,115,49,51,50,56,32,100,101,102,97,117,108,116,101,114,115,49,51,50,57,32,98,111,100,121,45,112,114,111,99,49,51,51,48,32,114,101,115,116,49,51,51,49,41,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,31),40,112,114,101,102,105,120,45,115,121,109,32,112,114,101,102,105,120,49,51,55,51,32,115,121,109,49,51,55,52,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,58),40,114,101,99,117,114,32,118,97,114,115,49,51,49,56,32,100,101,102,97,117,108,116,101,114,45,110,97,109,101,115,49,51,49,57,32,100,101,102,115,49,51,50,48,32,110,101,120,116,45,103,117,121,49,51,50,49,41,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,15),40,103,49,52,52,53,32,118,97,114,49,52,52,55,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,52,50,57,32,103,49,52,51,57,49,52,52,51,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,52,48,51,32,103,49,52,49,51,49,52,49,55,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,13),40,103,49,51,57,52,32,118,49,51,57,54,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,51,55,56,32,103,49,51,56,56,49,51,57,50,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,51,53,49,32,103,49,51,54,49,49,51,54,53,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,28),40,97,53,52,51,57,32,102,111,114,109,49,51,48,52,32,114,49,51,48,53,32,99,49,51,48,54,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,103,49,50,56,55,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,50,55,49,32,103,49,50,56,49,49,50,56,53,41,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,30),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,50,52,50,32,101,108,115,101,63,49,50,52,51,41,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,28),40,97,54,48,50,51,32,102,111,114,109,49,50,50,57,32,114,49,50,51,48,32,99,49,50,51,49,41,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,13),40,102,111,108,100,32,98,115,49,50,48,49,41,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,28),40,97,54,50,51,56,32,102,111,114,109,49,49,57,53,32,114,49,49,57,54,32,99,49,49,57,55,41,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,28),40,113,117,111,116,105,102,121,45,112,114,111,99,32,120,115,49,49,54,57,32,105,100,49,49,55,48,41,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,28),40,97,54,51,57,49,32,102,111,114,109,49,49,54,53,32,114,49,49,54,54,32,99,49,49,54,55,41,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,28),40,97,54,53,49,49,32,102,111,114,109,49,49,53,54,32,114,49,49,53,55,32,99,49,49,53,56,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,8),40,108,111,111,107,117,112,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,103,49,49,51,56,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,49,50,50,32,103,49,49,51,50,49,49,51,54,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,48,57,57,32,103,49,49,48,57,49,49,49,51,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,14),40,103,49,48,57,48,32,118,98,49,48,57,50,41,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,48,55,52,32,103,49,48,56,52,49,48,56,56,41,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,48,53,48,32,103,49,48,54,48,49,48,54,52,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,13),40,103,49,48,51,54,32,118,49,48,51,56,41,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,48,50,48,32,103,49,48,51,48,49,48,51,52,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,57,57,53,32,103,49,48,48,53,49,48,48,57,41,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,25),40,97,54,53,57,49,32,102,111,114,109,57,56,54,32,114,57,56,55,32,99,57,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,19),40,102,111,108,100,32,118,98,105,110,100,105,110,103,115,57,55,53,41,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,25),40,97,54,57,53,54,32,102,111,114,109,57,54,56,32,114,57,54,57,32,99,57,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,20),40,97,112,112,101,110,100,42,32,105,108,56,48,50,32,108,56,48,51,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,19),40,109,97,112,42,32,112,114,111,99,56,48,52,32,108,56,48,53,41,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,13),40,108,111,111,107,117,112,32,118,56,55,55,41,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,11),40,103,57,50,52,32,118,57,50,54,41,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,57,48,56,32,103,57,49,56,57,50,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,35),40,102,111,108,100,32,108,108,105,115,116,115,56,57,51,32,101,120,112,115,56,57,52,32,108,108,105,115,116,115,50,56,57,53,41,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,57,52,51,32,103,57,53,51,57,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,56,56,48,32,97,99,99,56,56,49,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,11),40,103,56,55,48,32,118,56,55,50,41,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,56,53,52,32,103,56,54,52,56,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,56,51,57,32,97,99,99,56,52,48,41,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,56,49,54,32,103,56,50,54,56,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,25),40,97,55,48,50,53,32,102,111,114,109,55,57,53,32,114,55,57,54,32,99,55,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,18),40,97,55,53,54,56,32,103,55,56,52,55,56,53,55,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,25),40,97,55,53,52,52,32,102,111,114,109,55,55,49,32,114,55,55,50,32,99,55,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,55,51,57,32,103,55,52,57,55,53,52,32,103,55,53,48,55,53,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,55,49,50,32,103,55,50,50,55,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,25),40,97,55,53,56,54,32,102,111,114,109,54,57,48,32,114,54,57,49,32,99,54,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,25),40,97,55,56,49,49,32,102,111,114,109,54,56,50,32,114,54,56,51,32,99,54,56,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,25),40,97,55,56,53,54,32,102,111,114,109,54,55,52,32,114,54,55,53,32,99,54,55,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,54,52,50,32,103,54,53,50,54,53,55,32,103,54,53,51,54,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,54,49,53,32,103,54,50,53,54,51,48,32,103,54,50,54,54,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,53,56,56,32,103,53,57,56,54,48,51,32,103,53,57,57,54,48,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,6),40,103,53,55,54,41,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,53,54,48,32,103,53,55,48,53,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,6),40,103,53,53,49,41,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,53,51,53,32,103,53,52,53,53,52,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,53,49,49,32,103,53,50,49,53,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,52,56,55,32,103,52,57,55,53,48,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,25),40,97,55,56,57,51,32,102,111,114,109,52,55,55,32,114,52,55,56,32,99,52,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,115,115,52,52,57,41,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,25),40,97,56,51,55,51,32,102,111,114,109,52,51,50,32,114,52,51,51,32,99,52,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,52,48,48,32,103,52,49,48,52,49,53,32,103,52,49,49,52,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,51,54,55,32,103,51,55,55,51,56,50,32,103,51,55,56,51,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,51,51,52,32,103,51,52,52,51,52,57,32,103,51,52,53,51,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,51,48,49,32,103,51,49,49,51,49,54,32,103,51,49,50,51,49,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,50,55,49,32,103,50,56,49,50,56,54,32,103,50,56,50,50,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,110,50,57,55,41,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,50,50,49,32,103,50,51,49,50,51,54,32,103,50,51,50,50,51,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,50,52,56,32,103,50,53,56,50,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,6),40,103,50,48,57,41,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,49,57,51,32,103,50,48,51,50,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,6),40,103,49,56,52,41,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,49,54,56,32,103,49,55,56,49,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,49,52,52,32,103,49,53,52,49,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,25),40,97,56,52,57,49,32,102,111,114,109,49,51,53,32,114,49,51,54,32,99,49,51,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,25),40,97,57,49,55,49,32,102,111,114,109,49,49,57,32,114,49,50,48,32,99,49,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,24),40,97,57,51,48,50,32,102,111,114,109,57,57,32,114,49,48,48,32,99,49,48,49,41};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,22),40,97,57,52,49,48,32,102,111,114,109,57,49,32,114,57,50,32,99,57,51,41,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,22),40,97,57,52,51,49,32,102,111,114,109,56,52,32,114,56,53,32,99,56,54,41,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,22),40,97,57,52,52,57,32,102,111,114,109,55,54,32,114,55,55,32,99,55,56,41,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,22),40,97,57,53,52,50,32,102,111,114,109,52,56,32,114,52,57,32,99,53,48,41,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,22),40,109,97,112,115,108,111,116,115,32,115,108,111,116,115,50,56,32,105,50,57,41,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,19),40,97,57,54,55,57,32,120,49,51,32,114,49,52,32,99,49,53,41,0,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,20),40,97,49,48,49,49,55,32,102,111,114,109,53,32,114,54,32,99,55,41,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_chicken_syntax_toplevel)
C_externexport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10118)
static void C_ccall f_10118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10122)
static void C_ccall f_10122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10129)
static void C_ccall f_10129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10116)
static void C_ccall f_10116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9680)
static void C_ccall f_9680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9684)
static void C_ccall f_9684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9693)
static void C_ccall f_9693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9699)
static void C_ccall f_9699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9702)
static void C_ccall f_9702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10112)
static void C_ccall f_10112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10072)
static void C_ccall f_10072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10104)
static void C_ccall f_10104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10064)
static void C_ccall f_10064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10020)
static void C_ccall f_10020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9731)
static void C_fcall f_9731(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9741)
static void C_ccall f_9741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10008)
static void C_ccall f_10008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9744)
static void C_ccall f_9744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10004)
static void C_ccall f_10004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9747)
static void C_ccall f_9747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9794)
static void C_fcall f_9794(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9758)
static void C_ccall f_9758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9729)
static void C_ccall f_9729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9725)
static void C_ccall f_9725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9678)
static void C_ccall f_9678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9543)
static void C_ccall f_9543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9547)
static void C_ccall f_9547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9583)
static void C_ccall f_9583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9598)
static void C_fcall f_9598(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9652)
static void C_ccall f_9652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9613)
static void C_ccall f_9613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9576)
static void C_ccall f_9576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9541)
static void C_ccall f_9541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9450)
static void C_ccall f_9450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9454)
static void C_ccall f_9454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9533)
static void C_ccall f_9533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9448)
static void C_ccall f_9448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9432)
static void C_ccall f_9432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9440)
static void C_ccall f_9440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9430)
static void C_ccall f_9430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9411)
static void C_ccall f_9411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9415)
static void C_ccall f_9415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9409)
static void C_ccall f_9409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9303)
static void C_ccall f_9303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9307)
static void C_ccall f_9307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9316)
static void C_fcall f_9316(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9376)
static void C_ccall f_9376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9351)
static void C_ccall f_9351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9301)
static void C_ccall f_9301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2171)
static void C_ccall f_2171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9172)
static void C_ccall f_9172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9176)
static void C_ccall f_9176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9188)
static void C_ccall f_9188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9235)
static void C_ccall f_9235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9170)
static void C_ccall f_9170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8492)
static void C_ccall f_8492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8496)
static void C_ccall f_8496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9133)
static void C_fcall f_9133(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9162)
static void C_ccall f_9162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8505)
static void C_ccall f_8505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9089)
static void C_fcall f_9089(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9127)
static void C_ccall f_9127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9116)
static void C_fcall f_9116(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9124)
static void C_ccall f_9124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8508)
static void C_ccall f_8508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9045)
static void C_fcall f_9045(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9083)
static void C_ccall f_9083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9072)
static void C_fcall f_9072(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9080)
static void C_ccall f_9080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8511)
static void C_ccall f_8511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9010)
static void C_fcall f_9010(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9039)
static void C_ccall f_9039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8959)
static void C_ccall f_8959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8961)
static void C_fcall f_8961(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8994)
static void C_ccall f_8994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8974)
static void C_fcall f_8974(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8870)
static void C_ccall f_8870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8937)
static void C_fcall f_8937(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8951)
static void C_ccall f_8951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8882)
static void C_ccall f_8882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8884)
static void C_fcall f_8884(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8917)
static void C_ccall f_8917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8897)
static void C_fcall f_8897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8878)
static void C_ccall f_8878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8874)
static void C_ccall f_8874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8522)
static void C_ccall f_8522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8806)
static void C_fcall f_8806(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8819)
static void C_fcall f_8819(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8726)
static void C_ccall f_8726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8744)
static void C_fcall f_8744(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8757)
static void C_fcall f_8757(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8734)
static void C_ccall f_8734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8730)
static void C_ccall f_8730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8722)
static void C_ccall f_8722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8714)
static void C_ccall f_8714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8646)
static void C_fcall f_8646(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8659)
static void C_fcall f_8659(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8566)
static void C_ccall f_8566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8584)
static void C_fcall f_8584(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8597)
static void C_fcall f_8597(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8574)
static void C_ccall f_8574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8570)
static void C_ccall f_8570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8562)
static void C_ccall f_8562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8490)
static void C_ccall f_8490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8374)
static void C_ccall f_8374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8378)
static void C_ccall f_8378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8482)
static void C_ccall f_8482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8387)
static void C_ccall f_8387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8390)
static void C_ccall f_8390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8393)
static void C_ccall f_8393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8433)
static void C_fcall f_8433(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8456)
static void C_ccall f_8456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8463)
static void C_ccall f_8463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8470)
static void C_ccall f_8470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8446)
static void C_ccall f_8446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8396)
static void C_ccall f_8396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8372)
static void C_ccall f_8372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7894)
static void C_ccall f_7894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7898)
static void C_ccall f_7898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8335)
static void C_fcall f_8335(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8364)
static void C_ccall f_8364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7910)
static void C_ccall f_7910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8300)
static void C_fcall f_8300(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8329)
static void C_ccall f_8329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7913)
static void C_ccall f_7913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8256)
static void C_fcall f_8256(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8294)
static void C_ccall f_8294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8283)
static void C_fcall f_8283(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8291)
static void C_ccall f_8291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7916)
static void C_ccall f_7916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8212)
static void C_fcall f_8212(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8250)
static void C_ccall f_8250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8239)
static void C_fcall f_8239(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8247)
static void C_ccall f_8247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7919)
static void C_ccall f_7919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8163)
static void C_fcall f_8163(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8196)
static void C_ccall f_8196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8176)
static void C_fcall f_8176(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8108)
static void C_ccall f_8108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8114)
static void C_fcall f_8114(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8147)
static void C_ccall f_8147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8127)
static void C_fcall f_8127(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8112)
static void C_ccall f_8112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7930)
static void C_ccall f_7930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8004)
static void C_fcall f_8004(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8017)
static void C_fcall f_8017(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8002)
static void C_ccall f_8002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7998)
static void C_ccall f_7998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7978)
static void C_ccall f_7978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7892)
static void C_ccall f_7892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7857)
static void C_ccall f_7857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7861)
static void C_ccall f_7861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7884)
static void C_ccall f_7884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7855)
static void C_ccall f_7855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7812)
static void C_ccall f_7812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7816)
static void C_ccall f_7816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7847)
static void C_ccall f_7847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7810)
static void C_ccall f_7810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7587)
static void C_ccall f_7587(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7591)
static void C_ccall f_7591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7769)
static void C_fcall f_7769(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7798)
static void C_ccall f_7798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7666)
static void C_ccall f_7666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7699)
static void C_fcall f_7699(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7712)
static void C_fcall f_7712(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7697)
static void C_ccall f_7697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7693)
static void C_ccall f_7693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7585)
static void C_ccall f_7585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7545)
static void C_ccall f_7545(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7549)
static void C_ccall f_7549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7569)
static void C_ccall f_7569(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7577)
static void C_ccall f_7577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7552)
static void C_ccall f_7552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7559)
static void C_ccall f_7559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7563)
static void C_ccall f_7563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7543)
static void C_ccall f_7543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7026)
static void C_ccall f_7026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7030)
static void C_ccall f_7030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7506)
static void C_fcall f_7506(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7535)
static void C_ccall f_7535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7111)
static void C_ccall f_7111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7466)
static void C_fcall f_7466(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7479)
static void C_ccall f_7479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7114)
static void C_ccall f_7114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7418)
static void C_fcall f_7418(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7460)
static void C_ccall f_7460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7445)
static void C_fcall f_7445(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7457)
static void C_ccall f_7457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7453)
static void C_ccall f_7453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7117)
static void C_ccall f_7117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7372)
static void C_fcall f_7372(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7405)
static void C_ccall f_7405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7412)
static void C_ccall f_7412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7129)
static void C_ccall f_7129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7332)
static void C_fcall f_7332(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7136)
static void C_ccall f_7136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7138)
static void C_fcall f_7138(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7326)
static void C_ccall f_7326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7210)
static void C_fcall f_7210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7292)
static void C_ccall f_7292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7249)
static void C_ccall f_7249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7229)
static void C_ccall f_7229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7162)
static void C_fcall f_7162(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7200)
static void C_ccall f_7200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7189)
static void C_fcall f_7189(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7197)
static void C_ccall f_7197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7156)
static void C_ccall f_7156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7160)
static void C_ccall f_7160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7069)
static void C_fcall f_7069(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7092)
static void C_ccall f_7092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7096)
static void C_ccall f_7096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7038)
static void C_fcall f_7038(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7024)
static void C_ccall f_7024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6957)
static void C_ccall f_6957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6961)
static void C_ccall f_6961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6970)
static void C_ccall f_6970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6975)
static void C_fcall f_6975(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7012)
static void C_ccall f_7012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6993)
static void C_ccall f_6993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6955)
static void C_ccall f_6955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6592)
static void C_ccall f_6592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6596)
static void C_ccall f_6596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6913)
static void C_fcall f_6913(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6911)
static void C_ccall f_6911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6605)
static void C_ccall f_6605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6861)
static void C_fcall f_6861(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6903)
static void C_ccall f_6903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6888)
static void C_fcall f_6888(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6900)
static void C_ccall f_6900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6896)
static void C_ccall f_6896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6608)
static void C_ccall f_6608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6821)
static void C_fcall f_6821(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6628)
static void C_ccall f_6628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6642)
static void C_fcall f_6642(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6815)
static void C_ccall f_6815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6669)
static void C_fcall f_6669(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6767)
static void C_fcall f_6767(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6697)
static void C_ccall f_6697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6711)
static void C_fcall f_6711(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6738)
static C_word C_fcall f_6738(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_6705)
static void C_ccall f_6705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6701)
static void C_ccall f_6701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6636)
static void C_ccall f_6636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6640)
static void C_ccall f_6640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6632)
static void C_ccall f_6632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6609)
static C_word C_fcall f_6609(C_word t0,C_word t1);
C_noret_decl(f_6590)
static void C_ccall f_6590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2204)
static void C_ccall f_2204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6512)
static void C_ccall f_6512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6516)
static void C_ccall f_6516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6519)
static void C_ccall f_6519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6554)
static void C_ccall f_6554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6510)
static void C_ccall f_6510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2207)
static void C_ccall f_2207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6498)
static void C_ccall f_6498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6494)
static void C_ccall f_6494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6395)
static void C_fcall f_6395(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6474)
static void C_ccall f_6474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6408)
static void C_fcall f_6408(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6440)
static void C_ccall f_6440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6436)
static void C_ccall f_6436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6420)
static void C_fcall f_6420(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6239)
static void C_ccall f_6239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6243)
static void C_ccall f_6243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6254)
static void C_fcall f_6254(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6295)
static void C_ccall f_6295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6362)
static void C_ccall f_6362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6268)
static void C_ccall f_6268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6237)
static void C_ccall f_6237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6024)
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6037)
static void C_ccall f_6037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6040)
static void C_ccall f_6040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6043)
static void C_ccall f_6043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6064)
static void C_fcall f_6064(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6089)
static void C_ccall f_6089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6095)
static void C_ccall f_6095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6171)
static void C_fcall f_6171(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6198)
static C_word C_fcall f_6198(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_6165)
static void C_ccall f_6165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6161)
static void C_ccall f_6161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6153)
static void C_ccall f_6153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6149)
static void C_ccall f_6149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6122)
static void C_ccall f_6122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6115)
static void C_ccall f_6115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6118)
static void C_ccall f_6118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6098)
static void C_ccall f_6098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6105)
static void C_ccall f_6105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6062)
static void C_ccall f_6062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6022)
static void C_ccall f_6022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6018)
static void C_ccall f_6018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6014)
static void C_ccall f_6014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5753)
static void C_ccall f_5753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5756)
static void C_ccall f_5756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5965)
static void C_fcall f_5965(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5994)
static void C_ccall f_5994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5921)
static void C_fcall f_5921(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5959)
static void C_ccall f_5959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5948)
static void C_fcall f_5948(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5956)
static void C_ccall f_5956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5775)
static void C_ccall f_5775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5886)
static void C_fcall f_5886(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5915)
static void C_ccall f_5915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5778)
static void C_ccall f_5778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5781)
static void C_ccall f_5781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5784)
static void C_ccall f_5784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5842)
static void C_fcall f_5842(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5880)
static void C_ccall f_5880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5869)
static void C_fcall f_5869(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5877)
static void C_ccall f_5877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5463)
static void C_ccall f_5463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5471)
static void C_ccall f_5471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5473)
static void C_fcall f_5473(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5790)
static void C_ccall f_5790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5793)
static void C_ccall f_5793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5800)
static void C_ccall f_5800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5760)
static void C_fcall f_5760(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5772)
static void C_ccall f_5772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5768)
static void C_ccall f_5768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5552)
static void C_fcall f_5552(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5558)
static void C_fcall f_5558(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5746)
static void C_ccall f_5746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5734)
static void C_ccall f_5734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5718)
static void C_ccall f_5718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5682)
static void C_ccall f_5682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5632)
static void C_ccall f_5632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5620)
static void C_ccall f_5620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5426)
static void C_ccall f_5426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5422)
static void C_ccall f_5422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5382)
static void C_ccall f_5382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5343)
static void C_ccall f_5343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5220)
static void C_ccall f_5220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5212)
static void C_ccall f_5212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4914)
static void C_ccall f_4914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4933)
static void C_ccall f_4933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4939)
static void C_ccall f_4939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4960)
static void C_fcall f_4960(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5069)
static void C_ccall f_5069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4900)
static void C_ccall f_4900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4375)
static void C_ccall f_4375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4815)
static void C_fcall f_4815(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4856)
static void C_ccall f_4856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4422)
static void C_ccall f_4422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4425)
static void C_ccall f_4425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4477)
static void C_ccall f_4477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4491)
static void C_ccall f_4491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4505)
static void C_fcall f_4505(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4605)
static void C_fcall f_4605(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4753)
static void C_ccall f_4753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4673)
static void C_ccall f_4673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4692)
static void C_ccall f_4692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4630)
static void C_ccall f_4630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4556)
static void C_fcall f_4556(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4569)
static void C_fcall f_4569(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4550)
static void C_ccall f_4550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4513)
static void C_ccall f_4513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4381)
static void C_fcall f_4381(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4387)
static void C_fcall f_4387(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4413)
static void C_ccall f_4413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4401)
static void C_ccall f_4401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4405)
static void C_ccall f_4405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4281)
static void C_ccall f_4281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4342)
static void C_ccall f_4342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4327)
static void C_ccall f_4327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4275)
static void C_ccall f_4275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4087)
static void C_ccall f_4087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4056)
static void C_ccall f_4056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_ccall f_4052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3662)
static void C_ccall f_3662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_fcall f_3951(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_fcall f_3670(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3794)
static void C_fcall f_3794(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3821)
static C_word C_fcall f_3821(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3712)
static void C_ccall f_3712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3647)
static void C_ccall f_3647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3639)
static void C_ccall f_3639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3598)
static void C_fcall f_3598(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3627)
static void C_ccall f_3627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3124)
static void C_ccall f_3124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3551)
static void C_fcall f_3551(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3578)
static C_word C_fcall f_3578(C_word t0,C_word t1);
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3545)
static void C_ccall f_3545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_fcall f_3153(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_fcall f_3172(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3178)
static void C_fcall f_3178(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3283)
static void C_ccall f_3283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3276)
static void C_fcall f_3276(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3193)
static void C_fcall f_3193(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3201)
static void C_ccall f_3201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3197)
static void C_ccall f_3197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3151)
static void C_ccall f_3151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3147)
static void C_ccall f_3147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3088)
static void C_ccall f_3088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2915)
static void C_fcall f_2915(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3018)
static void C_ccall f_3018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2671)
static void C_ccall f_2671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2690)
static void C_fcall f_2690(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2703)
static void C_ccall f_2703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2752)
static void C_ccall f_2752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2560)
static void C_ccall f_2560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2512)
static void C_ccall f_2512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2352)
static void C_fcall f_2352(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2426)
static void C_fcall f_2426(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2408)
static void C_ccall f_2408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_9731)
static void C_fcall trf_9731(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9731(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9731(t0,t1,t2,t3);}

C_noret_decl(trf_9794)
static void C_fcall trf_9794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9794(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9794(t0,t1);}

C_noret_decl(trf_9598)
static void C_fcall trf_9598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9598(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9598(t0,t1);}

C_noret_decl(trf_9316)
static void C_fcall trf_9316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9316(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9316(t0,t1);}

C_noret_decl(trf_9133)
static void C_fcall trf_9133(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9133(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9133(t0,t1,t2);}

C_noret_decl(trf_9089)
static void C_fcall trf_9089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9089(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9089(t0,t1,t2);}

C_noret_decl(trf_9116)
static void C_fcall trf_9116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9116(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9116(t0,t1);}

C_noret_decl(trf_9045)
static void C_fcall trf_9045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9045(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9045(t0,t1,t2);}

C_noret_decl(trf_9072)
static void C_fcall trf_9072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9072(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9072(t0,t1);}

C_noret_decl(trf_9010)
static void C_fcall trf_9010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9010(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9010(t0,t1,t2);}

C_noret_decl(trf_8961)
static void C_fcall trf_8961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8961(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8961(t0,t1,t2,t3);}

C_noret_decl(trf_8974)
static void C_fcall trf_8974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8974(t0,t1);}

C_noret_decl(trf_8937)
static void C_fcall trf_8937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8937(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8937(t0,t1,t2);}

C_noret_decl(trf_8884)
static void C_fcall trf_8884(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8884(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8884(t0,t1,t2,t3);}

C_noret_decl(trf_8897)
static void C_fcall trf_8897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8897(t0,t1);}

C_noret_decl(trf_8806)
static void C_fcall trf_8806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8806(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8806(t0,t1,t2,t3);}

C_noret_decl(trf_8819)
static void C_fcall trf_8819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8819(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8819(t0,t1);}

C_noret_decl(trf_8744)
static void C_fcall trf_8744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8744(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8744(t0,t1,t2,t3);}

C_noret_decl(trf_8757)
static void C_fcall trf_8757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8757(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8757(t0,t1);}

C_noret_decl(trf_8646)
static void C_fcall trf_8646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8646(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8646(t0,t1,t2,t3);}

C_noret_decl(trf_8659)
static void C_fcall trf_8659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8659(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8659(t0,t1);}

C_noret_decl(trf_8584)
static void C_fcall trf_8584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8584(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8584(t0,t1,t2,t3);}

C_noret_decl(trf_8597)
static void C_fcall trf_8597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8597(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8597(t0,t1);}

C_noret_decl(trf_8433)
static void C_fcall trf_8433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8433(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8433(t0,t1,t2);}

C_noret_decl(trf_8335)
static void C_fcall trf_8335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8335(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8335(t0,t1,t2);}

C_noret_decl(trf_8300)
static void C_fcall trf_8300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8300(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8300(t0,t1,t2);}

C_noret_decl(trf_8256)
static void C_fcall trf_8256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8256(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8256(t0,t1,t2);}

C_noret_decl(trf_8283)
static void C_fcall trf_8283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8283(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8283(t0,t1);}

C_noret_decl(trf_8212)
static void C_fcall trf_8212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8212(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8212(t0,t1,t2);}

C_noret_decl(trf_8239)
static void C_fcall trf_8239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8239(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8239(t0,t1);}

C_noret_decl(trf_8163)
static void C_fcall trf_8163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8163(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8163(t0,t1,t2,t3);}

C_noret_decl(trf_8176)
static void C_fcall trf_8176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8176(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8176(t0,t1);}

C_noret_decl(trf_8114)
static void C_fcall trf_8114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8114(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8114(t0,t1,t2,t3);}

C_noret_decl(trf_8127)
static void C_fcall trf_8127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8127(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8127(t0,t1);}

C_noret_decl(trf_8004)
static void C_fcall trf_8004(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8004(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8004(t0,t1,t2,t3);}

C_noret_decl(trf_8017)
static void C_fcall trf_8017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8017(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8017(t0,t1);}

C_noret_decl(trf_7769)
static void C_fcall trf_7769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7769(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7769(t0,t1,t2);}

C_noret_decl(trf_7699)
static void C_fcall trf_7699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7699(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7699(t0,t1,t2,t3);}

C_noret_decl(trf_7712)
static void C_fcall trf_7712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7712(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7712(t0,t1);}

C_noret_decl(trf_7506)
static void C_fcall trf_7506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7506(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7506(t0,t1,t2);}

C_noret_decl(trf_7466)
static void C_fcall trf_7466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7466(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7466(t0,t1,t2,t3);}

C_noret_decl(trf_7418)
static void C_fcall trf_7418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7418(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7418(t0,t1,t2);}

C_noret_decl(trf_7445)
static void C_fcall trf_7445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7445(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7445(t0,t1,t2);}

C_noret_decl(trf_7372)
static void C_fcall trf_7372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7372(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7372(t0,t1,t2,t3);}

C_noret_decl(trf_7332)
static void C_fcall trf_7332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7332(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7332(t0,t1,t2);}

C_noret_decl(trf_7138)
static void C_fcall trf_7138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7138(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7138(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7210)
static void C_fcall trf_7210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7210(t0,t1);}

C_noret_decl(trf_7162)
static void C_fcall trf_7162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7162(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7162(t0,t1,t2);}

C_noret_decl(trf_7189)
static void C_fcall trf_7189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7189(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7189(t0,t1,t2);}

C_noret_decl(trf_7069)
static void C_fcall trf_7069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7069(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7069(t0,t1,t2,t3);}

C_noret_decl(trf_7038)
static void C_fcall trf_7038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7038(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7038(t0,t1,t2,t3);}

C_noret_decl(trf_6975)
static void C_fcall trf_6975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6975(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6975(t0,t1,t2);}

C_noret_decl(trf_6913)
static void C_fcall trf_6913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6913(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6913(t0,t1,t2);}

C_noret_decl(trf_6861)
static void C_fcall trf_6861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6861(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6861(t0,t1,t2);}

C_noret_decl(trf_6888)
static void C_fcall trf_6888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6888(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6888(t0,t1,t2);}

C_noret_decl(trf_6821)
static void C_fcall trf_6821(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6821(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6821(t0,t1,t2);}

C_noret_decl(trf_6642)
static void C_fcall trf_6642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6642(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6642(t0,t1,t2);}

C_noret_decl(trf_6669)
static void C_fcall trf_6669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6669(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6669(t0,t1,t2);}

C_noret_decl(trf_6767)
static void C_fcall trf_6767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6767(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6767(t0,t1,t2);}

C_noret_decl(trf_6711)
static void C_fcall trf_6711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6711(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6711(t0,t1,t2);}

C_noret_decl(trf_6395)
static void C_fcall trf_6395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6395(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6395(t0,t1,t2,t3);}

C_noret_decl(trf_6408)
static void C_fcall trf_6408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6408(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6408(t0,t1);}

C_noret_decl(trf_6420)
static void C_fcall trf_6420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6420(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6420(t0,t1);}

C_noret_decl(trf_6254)
static void C_fcall trf_6254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6254(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6254(t0,t1,t2);}

C_noret_decl(trf_6064)
static void C_fcall trf_6064(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6064(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6064(t0,t1,t2,t3);}

C_noret_decl(trf_6171)
static void C_fcall trf_6171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6171(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6171(t0,t1,t2);}

C_noret_decl(trf_5965)
static void C_fcall trf_5965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5965(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5965(t0,t1,t2);}

C_noret_decl(trf_5921)
static void C_fcall trf_5921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5921(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5921(t0,t1,t2);}

C_noret_decl(trf_5948)
static void C_fcall trf_5948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5948(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5948(t0,t1,t2);}

C_noret_decl(trf_5886)
static void C_fcall trf_5886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5886(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5886(t0,t1,t2);}

C_noret_decl(trf_5842)
static void C_fcall trf_5842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5842(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5842(t0,t1,t2);}

C_noret_decl(trf_5869)
static void C_fcall trf_5869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5869(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5869(t0,t1,t2);}

C_noret_decl(trf_5473)
static void C_fcall trf_5473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5473(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5473(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5760)
static void C_fcall trf_5760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5760(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5760(t0,t1,t2);}

C_noret_decl(trf_5552)
static void C_fcall trf_5552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5552(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5552(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5558)
static void C_fcall trf_5558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5558(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5558(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4960)
static void C_fcall trf_4960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4960(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4960(t0,t1,t2,t3);}

C_noret_decl(trf_4815)
static void C_fcall trf_4815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4815(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4815(t0,t1,t2);}

C_noret_decl(trf_4505)
static void C_fcall trf_4505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4505(t0,t1);}

C_noret_decl(trf_4605)
static void C_fcall trf_4605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4605(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4605(t0,t1,t2,t3);}

C_noret_decl(trf_4556)
static void C_fcall trf_4556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4556(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4556(t0,t1,t2,t3);}

C_noret_decl(trf_4569)
static void C_fcall trf_4569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4569(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4569(t0,t1);}

C_noret_decl(trf_4381)
static void C_fcall trf_4381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4381(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4381(t0,t1,t2);}

C_noret_decl(trf_4387)
static void C_fcall trf_4387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4387(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4387(t0,t1,t2);}

C_noret_decl(trf_3951)
static void C_fcall trf_3951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3951(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3951(t0,t1,t2);}

C_noret_decl(trf_3670)
static void C_fcall trf_3670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3670(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3670(t0,t1,t2);}

C_noret_decl(trf_3794)
static void C_fcall trf_3794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3794(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3794(t0,t1,t2);}

C_noret_decl(trf_3598)
static void C_fcall trf_3598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3598(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3598(t0,t1,t2);}

C_noret_decl(trf_3551)
static void C_fcall trf_3551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3551(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3551(t0,t1,t2);}

C_noret_decl(trf_3153)
static void C_fcall trf_3153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3153(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3153(t0,t1,t2,t3);}

C_noret_decl(trf_3172)
static void C_fcall trf_3172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3172(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3172(t0,t1);}

C_noret_decl(trf_3178)
static void C_fcall trf_3178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3178(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3178(t0,t1);}

C_noret_decl(trf_3276)
static void C_fcall trf_3276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3276(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3276(t0,t1);}

C_noret_decl(trf_3193)
static void C_fcall trf_3193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3193(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3193(t0,t1);}

C_noret_decl(trf_2915)
static void C_fcall trf_2915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2915(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2915(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2690)
static void C_fcall trf_2690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2690(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2690(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2352)
static void C_fcall trf_2352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2352(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2352(t0,t1);}

C_noret_decl(trf_2426)
static void C_fcall trf_2426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2426(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2426(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_chicken_syntax_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("chicken_syntax_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3057)){
C_save(t1);
C_rereclaim2(3057*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,232);
lf[0]=C_h_intern(&lf[0],29,"\003syschicken-macro-environment");
lf[1]=C_h_intern(&lf[1],17,"register-feature!");
lf[2]=C_h_intern(&lf[2],6,"srfi-8");
lf[3]=C_h_intern(&lf[3],7,"srfi-16");
lf[4]=C_h_intern(&lf[4],7,"srfi-26");
lf[5]=C_h_intern(&lf[5],7,"srfi-31");
lf[6]=C_h_intern(&lf[6],7,"srfi-15");
lf[7]=C_h_intern(&lf[7],7,"srfi-11");
lf[8]=C_h_intern(&lf[8],16,"\003sysmacro-subset");
lf[9]=C_h_intern(&lf[9],29,"\003sysdefault-macro-environment");
lf[10]=C_h_intern(&lf[10],28,"\003sysextend-macro-environment");
lf[11]=C_h_intern(&lf[11],12,"define-macro");
lf[12]=C_h_intern(&lf[12],12,"syntax-error");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000<`define-macro\047 is not supported - please use `define-syntax\047");
lf[14]=C_h_intern(&lf[14],18,"\003syser-transformer");
lf[15]=C_h_intern(&lf[15],19,"let-compiler-syntax");
lf[16]=C_h_intern(&lf[16],24,"\004corelet-compiler-syntax");
lf[17]=C_h_intern(&lf[17],25,"\003syssyntax-rules-mismatch");
lf[18]=C_h_intern(&lf[18],9,"\003syslist\077");
lf[19]=C_h_intern(&lf[19],22,"define-compiler-syntax");
lf[20]=C_h_intern(&lf[20],27,"\004coredefine-compiler-syntax");
lf[21]=C_h_intern(&lf[21],6,"lambda");
lf[22]=C_h_intern(&lf[22],3,"use");
lf[23]=C_h_intern(&lf[23],22,"\004corerequire-extension");
lf[24]=C_h_intern(&lf[24],16,"\003syscheck-syntax");
lf[25]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[26]=C_h_intern(&lf[26],17,"define-for-syntax");
lf[27]=C_h_intern(&lf[27],10,"\003sysappend");
lf[28]=C_h_intern(&lf[28],6,"define");
lf[29]=C_h_intern(&lf[29],16,"begin-for-syntax");
lf[30]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[31]=C_h_intern(&lf[31],3,"rec");
lf[32]=C_h_intern(&lf[32],11,"\004corelambda");
lf[33]=C_h_intern(&lf[33],11,"\004coreletrec");
lf[34]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[35]=C_h_intern(&lf[35],5,"apply");
lf[36]=C_h_intern(&lf[36],4,"cute");
lf[37]=C_h_intern(&lf[37],8,"\004corelet");
lf[38]=C_h_intern(&lf[38],6,"gensym");
lf[39]=C_h_intern(&lf[39],7,"reverse");
lf[40]=C_h_intern(&lf[40],5,"<...>");
lf[41]=C_h_intern(&lf[41],2,"<>");
lf[42]=C_h_intern(&lf[42],19,"\003sysprimitive-alias");
lf[43]=C_h_intern(&lf[43],3,"cut");
lf[44]=C_h_intern(&lf[44],10,"\004corebegin");
lf[45]=C_h_intern(&lf[45],18,"getter-with-setter");
lf[46]=C_h_intern(&lf[46],18,"define-record-type");
lf[47]=C_h_intern(&lf[47],10,"\004corequote");
lf[48]=C_h_intern(&lf[48],18,"\003sysmake-structure");
lf[49]=C_h_intern(&lf[49],14,"\003sysstructure\077");
lf[50]=C_h_intern(&lf[50],19,"\003syscheck-structure");
lf[51]=C_h_intern(&lf[51],10,"\004corecheck");
lf[52]=C_h_intern(&lf[52],13,"\003sysblock-ref");
lf[53]=C_h_intern(&lf[53],10,"\003syssetter");
lf[54]=C_h_intern(&lf[54],14,"\003sysblock-set!");
lf[55]=C_h_intern(&lf[55],6,"setter");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[57]=C_h_intern(&lf[57],3,"car");
lf[58]=C_h_intern(&lf[58],1,"y");
lf[59]=C_h_intern(&lf[59],1,"x");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\010variable\376\001\000"
"\000\001_");
lf[61]=C_h_intern(&lf[61],4,"else");
lf[62]=C_h_intern(&lf[62],4,"memv");
lf[63]=C_h_intern(&lf[63],14,"condition-case");
lf[64]=C_h_intern(&lf[64],9,"condition");
lf[65]=C_h_intern(&lf[65],8,"\003sysslot");
lf[66]=C_h_intern(&lf[66],10,"\003syssignal");
lf[67]=C_h_intern(&lf[67],4,"cond");
lf[68]=C_h_intern(&lf[68],17,"handle-exceptions");
lf[69]=C_h_intern(&lf[69],3,"and");
lf[70]=C_h_intern(&lf[70],4,"kvar");
lf[71]=C_h_intern(&lf[71],5,"exvar");
lf[72]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[73]=C_h_intern(&lf[73],30,"call-with-current-continuation");
lf[74]=C_h_intern(&lf[74],22,"with-exception-handler");
lf[75]=C_h_intern(&lf[75],10,"\003sysvalues");
lf[76]=C_h_intern(&lf[76],9,"\003sysapply");
lf[77]=C_h_intern(&lf[77],20,"\003syscall-with-values");
lf[78]=C_h_intern(&lf[78],4,"args");
lf[79]=C_h_intern(&lf[79],1,"k");
lf[80]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[81]=C_h_intern(&lf[81],21,"define-record-printer");
lf[82]=C_h_intern(&lf[82],5,"quote");
lf[83]=C_h_intern(&lf[83],27,"\003sysregister-record-printer");
lf[84]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[86]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[87]=C_h_intern(&lf[87],2,">=");
lf[88]=C_h_intern(&lf[88],3,"cdr");
lf[89]=C_h_intern(&lf[89],3,"eq\077");
lf[90]=C_h_intern(&lf[90],11,"case-lambda");
lf[91]=C_h_intern(&lf[91],6,"length");
lf[92]=C_h_intern(&lf[92],7,"\004coreif");
lf[93]=C_h_intern(&lf[93],9,"split-at!");
lf[94]=C_h_intern(&lf[94],4,"take");
lf[95]=C_h_intern(&lf[95],4,"list");
lf[96]=C_h_intern(&lf[96],11,"lambda-list");
lf[97]=C_h_intern(&lf[97],25,"\003sysdecompose-lambda-list");
lf[98]=C_h_intern(&lf[98],10,"fold-right");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[100]=C_h_intern(&lf[100],6,"append");
lf[101]=C_h_intern(&lf[101],4,"lvar");
lf[102]=C_h_intern(&lf[102],4,"rvar");
lf[103]=C_h_intern(&lf[103],3,"min");
lf[104]=C_h_intern(&lf[104],7,"require");
lf[105]=C_h_intern(&lf[105],6,"srfi-1");
lf[106]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[107]=C_h_intern(&lf[107],5,"null\077");
lf[108]=C_h_intern(&lf[108],14,"let-optionals*");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[110]=C_h_intern(&lf[110],14,"\004coreimmutable");
lf[111]=C_h_intern(&lf[111],9,"\003syserror");
lf[112]=C_h_intern(&lf[112],4,"tmp2");
lf[113]=C_h_intern(&lf[113],3,"tmp");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[115]=C_h_intern(&lf[115],8,"optional");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[119]=C_h_intern(&lf[119],13,"let-optionals");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[121]=C_h_intern(&lf[121],14,"string->symbol");
lf[122]=C_h_intern(&lf[122],13,"string-append");
lf[123]=C_h_intern(&lf[123],14,"symbol->string");
lf[124]=C_h_intern(&lf[124],4,"let*");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[126]=C_h_intern(&lf[126],5,"%rest");
lf[127]=C_h_intern(&lf[127],4,"body");
lf[128]=C_h_intern(&lf[128],4,"cadr");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[130]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[131]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[132]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[133]=C_h_intern(&lf[133],6,"select");
lf[134]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corebegin\376\377\016");
lf[136]=C_h_intern(&lf[136],10,"\003sysnotice");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\0003non-`else\047 clause following `else\047 clause in `cond\047");
lf[138]=C_h_intern(&lf[138],16,"\003sysstrip-syntax");
lf[139]=C_h_intern(&lf[139],8,"\003syseqv\077");
lf[140]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[141]=C_h_intern(&lf[141],16,"\003syssyntax-error");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid syntax");
lf[143]=C_h_intern(&lf[143],2,"or");
lf[144]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[145]=C_h_intern(&lf[145],8,"and-let*");
lf[146]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[147]=C_h_intern(&lf[147],13,"define-inline");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[149]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[150]=C_h_intern(&lf[150],18,"\004coredefine-inline");
lf[151]=C_h_intern(&lf[151],8,"list-ref");
lf[152]=C_h_intern(&lf[152],9,"nth-value");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[154]=C_h_intern(&lf[154],13,"letrec-values");
lf[155]=C_h_intern(&lf[155],9,"\004coreset!");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[157]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[158]=C_h_intern(&lf[158],11,"let*-values");
lf[159]=C_h_intern(&lf[159],10,"let-values");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[161]=C_h_intern(&lf[161],4,"caar");
lf[162]=C_h_intern(&lf[162],4,"cdar");
lf[163]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[164]=C_h_intern(&lf[164],13,"define-values");
lf[165]=C_h_intern(&lf[165],11,"set!-values");
lf[166]=C_h_intern(&lf[166],19,"\003sysregister-export");
lf[167]=C_h_intern(&lf[167],18,"\003syscurrent-module");
lf[168]=C_h_intern(&lf[168],12,"\003sysfor-each");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[170]=C_h_intern(&lf[170],14,"\004coreundefined");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[172]=C_h_intern(&lf[172],6,"unless");
lf[173]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[174]=C_h_intern(&lf[174],4,"when");
lf[175]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[176]=C_h_intern(&lf[176],12,"parameterize");
lf[177]=C_h_intern(&lf[177],16,"\003sysdynamic-wind");
lf[178]=C_h_intern(&lf[178],1,"t");
lf[179]=C_h_intern(&lf[179],8,"\003syslist");
lf[180]=C_h_intern(&lf[180],4,"swap");
lf[181]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[182]=C_h_intern(&lf[182],9,"eval-when");
lf[183]=C_h_intern(&lf[183],10,"\000compiling");
lf[184]=C_h_intern(&lf[184],12,"\003sysfeatures");
lf[185]=C_h_intern(&lf[185],19,"\004corecompiletimetoo");
lf[186]=C_h_intern(&lf[186],20,"\004corecompiletimeonly");
lf[187]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[188]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[190]=C_h_intern(&lf[190],4,"load");
lf[191]=C_h_intern(&lf[191],7,"compile");
lf[192]=C_h_intern(&lf[192],4,"eval");
lf[193]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[194]=C_h_intern(&lf[194],9,"fluid-let");
lf[195]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[196]=C_h_intern(&lf[196],6,"ensure");
lf[197]=C_h_intern(&lf[197],11,"\000type-error");
lf[198]=C_h_intern(&lf[198],15,"\003syssignal-hook");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[200]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\003");
lf[201]=C_h_intern(&lf[201],6,"assert");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[203]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[204]=C_h_intern(&lf[204],7,"include");
lf[205]=C_h_intern(&lf[205],12,"\004coreinclude");
lf[206]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[207]=C_h_intern(&lf[207],7,"declare");
lf[208]=C_h_intern(&lf[208],12,"\004coredeclare");
lf[209]=C_h_intern(&lf[209],4,"time");
lf[210]=C_h_intern(&lf[210],15,"\003sysstart-timer");
lf[211]=C_h_intern(&lf[211],14,"\003sysstop-timer");
lf[212]=C_h_intern(&lf[212],17,"\003sysdisplay-times");
lf[213]=C_h_intern(&lf[213],7,"receive");
lf[214]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[215]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[216]=C_h_intern(&lf[216],13,"define-record");
lf[217]=C_h_intern(&lf[217],15,"\000record-setters");
lf[218]=C_h_intern(&lf[218],3,"val");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[224]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[225]=C_h_intern(&lf[225],15,"define-constant");
lf[226]=C_h_intern(&lf[226],20,"\004coredefine-constant");
lf[227]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[228]=C_h_intern(&lf[228],21,"\003sysmacro-environment");
lf[229]=C_h_intern(&lf[229],11,"\003sysprovide");
lf[230]=C_h_intern(&lf[230],19,"chicken-more-macros");
lf[231]=C_h_intern(&lf[231],14,"chicken-syntax");
C_register_lf2(lf,232,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2146,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 38   ##sys#provide */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[230],lf[231]);}

/* k2144 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 46   ##sys#macro-environment */
t3=*((C_word*)lf[228]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2148 in k2144 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2153,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10116,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10118,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 51   ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a10117 in k2148 in k2144 */
static void C_ccall f_10118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10118,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10122,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 53   ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[225],t2,lf[227]);}

/* k10120 in a10117 in k2148 in k2144 */
static void C_ccall f_10122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10129,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k10127 in k10120 in a10117 in k2148 in k2144 */
static void C_ccall f_10129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10129,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[226],t1));}

/* k10114 in k2148 in k2144 */
static void C_ccall f_10116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 48   ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[225],C_SCHEME_END_OF_LIST,t1);}

/* k2151 in k2148 in k2144 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2156,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9678,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9680,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 58   ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_9680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9680,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9684,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 60   ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[216],t2,lf[224]);}

/* k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_9684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9684,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 63   symbol->string */
t5=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_9693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9693,2,t0,t1);}
t2=C_i_memq(lf[217],*((C_word*)lf[184]+1));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9699,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 65   r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[28]);}

/* k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_9699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9702,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 66   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[45]);}

/* k9700 in k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_9702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10072,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10112,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 69   string-append */
t4=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[223],((C_word*)t0)[2]);}

/* k10110 in k9700 in k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_10112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 69   string->symbol */
t2=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10070 in k9700 in k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_10072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10072,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[47],t2);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);}

/* k10102 in k10070 in k9700 in k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_10104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10104,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=C_a_i_cons(&a,2,lf[48],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=C_a_i_cons(&a,2,lf[32],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[8],t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[7],t8);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10020,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t9,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10064,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 72   string-append */
t12=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)t0)[2],lf[222]);}

/* k10062 in k10102 in k10070 in k9700 in k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_10064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 72   string->symbol */
t2=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10018 in k10102 in k10070 in k9700 in k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_10020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10020,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[59],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[82],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[59],t5);
t7=C_a_i_cons(&a,2,lf[49],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t2,t8);
t10=C_a_i_cons(&a,2,lf[32],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,t1,t11);
t13=C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9725,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t13,tmp=(C_word)a,a+=5,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9729,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9731,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t17,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word)li121),tmp=(C_word)a,a+=9,tmp));
t19=((C_word*)t17)[1];
f_9731(t19,t15,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k10018 in k10102 in k10070 in k9700 in k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_fcall f_9731(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9731,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t6=C_slot(t2,C_fix(0));
/* chicken-syntax.scm: 77   symbol->string */
t7=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}

/* k9739 in mapslots in k10018 in k10102 in k10070 in k9700 in k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_9741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9744,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10008,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 78   string-append */
t4=*((C_word*)lf[122]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],lf[220],t1,lf[221]);}

/* k10006 in k9739 in mapslots in k10018 in k10102 in k10070 in k9700 in k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_10008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 78   string->symbol */
t2=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9742 in k9739 in mapslots in k10018 in k10102 in k10070 in k9700 in k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_9744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9747,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10004,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 79   string-append */
t4=*((C_word*)lf[122]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],lf[219],((C_word*)t0)[2]);}

/* k10002 in k9742 in k9739 in mapslots in k10018 in k10102 in k10070 in k9700 in k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_10004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 79   string->symbol */
t2=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9745 in k9742 in k9739 in mapslots in k10018 in k10102 in k10070 in k9700 in k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_9747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word ab[123],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9747,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[218],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[59],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[47],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[59],t6);
t8=C_a_i_cons(&a,2,lf[50],t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,lf[51],t9);
t11=C_a_i_cons(&a,2,lf[218],C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,((C_word*)t0)[9],t11);
t13=C_a_i_cons(&a,2,lf[59],t12);
t14=C_a_i_cons(&a,2,lf[54],t13);
t15=C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=C_a_i_cons(&a,2,t10,t15);
t17=C_a_i_cons(&a,2,t3,t16);
t18=C_a_i_cons(&a,2,lf[32],t17);
t19=C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=C_a_i_cons(&a,2,((C_word*)t0)[8],t19);
t21=C_a_i_cons(&a,2,((C_word*)t0)[7],t20);
t22=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9794,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t21,a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t23=C_a_i_cons(&a,2,lf[59],C_SCHEME_END_OF_LIST);
t24=C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t25=C_a_i_cons(&a,2,lf[47],t24);
t26=C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=C_a_i_cons(&a,2,lf[59],t26);
t28=C_a_i_cons(&a,2,lf[50],t27);
t29=C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=C_a_i_cons(&a,2,lf[51],t29);
t31=C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t32=C_a_i_cons(&a,2,lf[59],t31);
t33=C_a_i_cons(&a,2,lf[52],t32);
t34=C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=C_a_i_cons(&a,2,t30,t34);
t36=C_a_i_cons(&a,2,t23,t35);
t37=C_a_i_cons(&a,2,lf[32],t36);
t38=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t39=C_a_i_cons(&a,2,t37,t38);
t40=t22;
f_9794(t40,C_a_i_cons(&a,2,((C_word*)t0)[2],t39));}
else{
t23=C_a_i_cons(&a,2,lf[59],C_SCHEME_END_OF_LIST);
t24=C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t25=C_a_i_cons(&a,2,lf[47],t24);
t26=C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=C_a_i_cons(&a,2,lf[59],t26);
t28=C_a_i_cons(&a,2,lf[50],t27);
t29=C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=C_a_i_cons(&a,2,lf[51],t29);
t31=C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t32=C_a_i_cons(&a,2,lf[59],t31);
t33=C_a_i_cons(&a,2,lf[52],t32);
t34=C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=C_a_i_cons(&a,2,t30,t34);
t36=C_a_i_cons(&a,2,t23,t35);
t37=t22;
f_9794(t37,C_a_i_cons(&a,2,lf[32],t36));}}

/* k9792 in k9745 in k9742 in k9739 in mapslots in k10018 in k10102 in k10070 in k9700 in k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_fcall f_9794(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9794,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=C_a_i_cons(&a,2,lf[44],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9758,a[2]=t7,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=C_slot(((C_word*)t0)[4],C_fix(1));
t10=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm: 101  mapslots */
t11=((C_word*)((C_word*)t0)[2])[1];
f_9731(t11,t8,t9,t10);}

/* k9756 in k9792 in k9745 in k9742 in k9739 in mapslots in k10018 in k10102 in k10070 in k9700 in k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_9758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9758,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k9727 in k10018 in k10102 in k10070 in k9700 in k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_9729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k9723 in k10018 in k10102 in k10070 in k9700 in k9697 in k9691 in k9682 in a9679 in k2151 in k2148 in k2144 */
static void C_ccall f_9725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9725,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[44],t3));}

/* k9676 in k2151 in k2148 in k2144 */
static void C_ccall f_9678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 56   ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[216],C_SCHEME_END_OF_LIST,t1);}

/* k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9541,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9543,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 106  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9542 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9543,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9547,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 108  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[213],t2,lf[215]);}

/* k9545 in a9542 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9547,2,t0,t1);}
t2=C_i_cddr(((C_word*)t0)[3]);
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9576,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_i_cdr(((C_word*)t0)[3]);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 112  ##sys#check-syntax */
t4=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[213],((C_word*)t0)[3],lf[214]);}}

/* k9581 in k9545 in a9542 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9583,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=C_i_caddr(((C_word*)t0)[3]);
t4=C_i_cdddr(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9598,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t2))){
t6=C_i_cdr(t2);
t7=t5;
f_9598(t7,C_i_nullp(t6));}
else{
t6=t5;
f_9598(t6,C_SCHEME_FALSE);}}

/* k9596 in k9581 in k9545 in a9542 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_9598(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9598,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t2,t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9613,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=C_a_i_cons(&a,2,lf[32],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9652,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k9650 in k9596 in k9581 in k9545 in a9542 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9652,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[77],t5));}

/* k9611 in k9596 in k9581 in k9545 in a9542 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9613,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[37],t2));}

/* k9574 in k9545 in a9542 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9576,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,lf[179],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[77],t5));}

/* k9539 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 103  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[213],C_SCHEME_END_OF_LIST,t1);}

/* k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2162,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9448,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9450,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 124  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9449 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9450,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9454,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 126  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[178]);}

/* k9452 in a9449 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9454,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[210],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9533,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k9531 in k9452 in a9449 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9533,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,lf[211],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[212],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,lf[75],t7);
t9=C_a_i_cons(&a,2,lf[76],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t6,t10);
t12=C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=C_a_i_cons(&a,2,lf[32],t12);
t14=C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,t3,t14);
t16=C_a_i_cons(&a,2,lf[77],t15);
t17=C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=C_a_i_cons(&a,2,((C_word*)t0)[3],t17);
t19=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,C_a_i_cons(&a,2,lf[44],t18));}

/* k9446 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 122  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[209],C_SCHEME_END_OF_LIST,t1);}

/* k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9430,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9432,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 137  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9431 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9432,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9440,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_i_cdr(t2);
/* ##sys#append */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k9438 in a9431 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9440,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[208],t1));}

/* k9428 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 135  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[207],C_SCHEME_END_OF_LIST,t1);}

/* k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9409,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9411,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 143  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9410 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9411,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9415,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 145  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[204],t2,lf[206]);}

/* k9413 in a9410 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9415,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[205],t3));}

/* k9407 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 141  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[204],C_SCHEME_END_OF_LIST,t1);}

/* k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9301,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9303,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 150  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9302 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9303,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9307,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 152  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[201],t2,lf[203]);}

/* k9305 in a9302 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9307,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=C_i_cddr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9316,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_eqp(C_SCHEME_END_OF_LIST,t3);
if(C_truep(t5)){
t6=C_a_i_cons(&a,2,lf[202],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[82],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t4;
f_9316(t9,C_a_i_cons(&a,2,lf[110],t8));}
else{
t6=t4;
f_9316(t6,C_i_car(t3));}}

/* k9314 in k9305 in a9302 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_9316(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9316,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[51],t2);
t4=C_a_i_cons(&a,2,lf[170],C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9351,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=C_i_length(((C_word*)t0)[2]);
if(C_truep(C_fixnum_greaterp(t6,C_fix(1)))){
t7=C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t8=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t7,C_SCHEME_END_OF_LIST);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9376,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 164  ##sys#strip-syntax */
t8=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[4]);}}

/* k9374 in k9314 in k9305 in a9302 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9376,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[47],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t4,C_SCHEME_END_OF_LIST);}

/* k9349 in k9314 in k9305 in a9302 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9351,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_cons(&a,2,lf[111],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_cons(&a,2,lf[92],t6));}

/* k9299 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 148  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[201],C_SCHEME_END_OF_LIST,t1);}

/* k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9170,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9172,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 169  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9171 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9172,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9176,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 171  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[196],t2,lf[200]);}

/* k9174 in a9171 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9176,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_caddr(((C_word*)t0)[4]);
t4=C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9188,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 175  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[113]);}

/* k9186 in k9174 in a9171 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9188,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,lf[51],t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9235,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
/* ##sys#append */
t10=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t10=C_a_i_cons(&a,2,lf[199],C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,lf[82],t10);
t12=C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,lf[110],t12);
t14=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,lf[82],t14);
t16=C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=C_a_i_cons(&a,2,t1,t16);
t18=C_a_i_cons(&a,2,t13,t17);
/* ##sys#append */
t19=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t9,t18,C_SCHEME_END_OF_LIST);}}

/* k9233 in k9186 in k9174 in a9171 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9235,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[197],t1);
t3=C_a_i_cons(&a,2,lf[198],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_cons(&a,2,lf[92],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,lf[37],t9));}

/* k9168 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 166  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[196],C_SCHEME_END_OF_LIST,t1);}

/* k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8490,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8492,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 189  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8492,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8496,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 191  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[194],t2,lf[195]);}

/* k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8496,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_cddr(((C_word*)t0)[4]);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8505,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9133,a[2]=t5,a[3]=t10,a[4]=t7,a[5]=((C_word)li113),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_9133(t12,t8,t2);}

/* loop144 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_9133(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9133,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[57]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9162,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g160161 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9160 in loop144 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9162,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop144157 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9133(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop144157 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9133(t6,((C_word*)t0)[3],t5);}}

/* k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8505,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9089,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li112),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_9089(t10,t6,((C_word*)t0)[3]);}

/* loop168 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_9089(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9089,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9116,a[2]=((C_word*)t0)[5],a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9127,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g184185 */
t6=t3;
f_9116(t6,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9125 in loop168 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9127,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop168181 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9089(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop168181 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9089(t6,((C_word*)t0)[3],t5);}}

/* g184 in loop168 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_9116(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9116,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9124,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 195  gensym */
t3=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9122 in g184 in loop168 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 195  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8508,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8511,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9045,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li110),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_9045(t10,t6,((C_word*)t0)[3]);}

/* loop193 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_9045(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9045,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9072,a[2]=((C_word*)t0)[5],a[3]=((C_word)li109),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9083,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g209210 */
t6=t3;
f_9072(t6,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9081 in loop193 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9083,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop193206 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9045(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop193206 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9045(t6,((C_word*)t0)[3],t5);}}

/* g209 in loop193 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_9072(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9072,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9080,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 196  gensym */
t3=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9078 in g209 in loop193 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 196  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8522,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8870,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8959,a[2]=((C_word*)t0)[4],a[3]=t7,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9010,a[2]=t9,a[3]=t14,a[4]=t11,a[5]=((C_word)li108),tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_9010(t16,t12,((C_word*)t0)[2]);}

/* loop248 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_9010(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9010,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[128]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9039,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g264265 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9037 in loop248 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_9039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9039,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop248261 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9010(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop248261 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9010(t6,((C_word*)t0)[3],t5);}}

/* k8957 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8959,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8961,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word)li107),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_8961(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop221 in k8957 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8961(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8961,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[179]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8994,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g241242 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8992 in loop221 in k8957 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8994,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8974,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_8974(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_8974(t5,t4);}}

/* k8972 in k8992 in loop221 in k8957 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop221235 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8961(t5,((C_word*)t0)[2],t3,t4);}

/* k8868 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8874,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8878,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8882,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t9=C_i_length(((C_word*)t0)[2]);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8937,a[2]=t11,a[3]=((C_word)li106),tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_8937(t13,t8,t9);}

/* loop in k8868 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8937(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8937,NULL,3,t0,t1,t2);}
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8951,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_fixnum_difference(t2,C_fix(1));
/* chicken-syntax.scm: 203  loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k8949 in loop in k8868 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8951,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k8880 in k8868 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8882,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8884,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word)li105),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_8884(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop271 in k8880 in k8868 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8884(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8884,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[179]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8917,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g291292 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8915 in loop271 in k8880 in k8868 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8917,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8897,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_8897(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_8897(t5,t4);}}

/* k8895 in k8915 in loop271 in k8880 in k8868 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop271285 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8884(t5,((C_word*)t0)[2],t3,t4);}

/* k8876 in k8868 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8872 in k8868 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8726,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8806,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word)li104),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_8806(t11,t7,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* loop301 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8806(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8806,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t6,t8);
t10=C_a_i_cons(&a,2,lf[155],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8819,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t11,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t13=t12;
f_8819(t13,C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t11));}
else{
t13=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t14=t12;
f_8819(t14,t13);}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8817 in loop301 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8819(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop301315 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8806(t5,((C_word*)t0)[2],t3,t4);}

/* k8724 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8730,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8734,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8744,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word)li103),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_8744(t11,t7,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop334 in k8724 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8744(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8744,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t6,t8);
t10=C_a_i_cons(&a,2,lf[155],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8757,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t11,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t13=t12;
f_8757(t13,C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t11));}
else{
t13=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t14=t12;
f_8757(t14,t13);}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8755 in loop334 in k8724 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8757(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop334348 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8744(t5,((C_word*)t0)[2],t3,t4);}

/* k8732 in k8724 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8734,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[170],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8728 in k8724 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8720 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8722,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8714,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8712 in k8720 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8714,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8562,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8646,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word)li102),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_8646(t13,t9,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* loop367 in k8712 in k8720 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8646(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8646,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t6,t8);
t10=C_a_i_cons(&a,2,lf[155],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8659,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t11,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t13=t12;
f_8659(t13,C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t11));}
else{
t13=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t14=t12;
f_8659(t14,t13);}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8657 in loop367 in k8712 in k8720 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8659(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop367381 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8646(t5,((C_word*)t0)[2],t3,t4);}

/* k8564 in k8712 in k8720 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8570,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8574,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8584,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word)li101),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_8584(t11,t7,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop400 in k8564 in k8712 in k8720 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8584(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8584,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t6,t8);
t10=C_a_i_cons(&a,2,lf[155],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8597,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t11,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t13=t12;
f_8597(t13,C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t11));}
else{
t13=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t14=t12;
f_8597(t14,t13);}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8595 in loop400 in k8564 in k8712 in k8720 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8597(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop400414 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8584(t5,((C_word*)t0)[2],t3,t4);}

/* k8572 in k8564 in k8712 in k8720 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8574,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[170],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8568 in k8564 in k8712 in k8720 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8560 in k8712 in k8720 in k8520 in k8509 in k8506 in k8503 in k8494 in a8491 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8562,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_cons(&a,2,lf[177],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,lf[37],t9));}

/* k8488 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 187  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[194],C_SCHEME_END_OF_LIST,t1);}

/* k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8372,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8374,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 221  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a8373 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8374,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8378,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 223  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[182],t2,lf[193]);}

/* k8376 in a8373 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8378,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8482,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_i_cddr(((C_word*)t0)[5]);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k8480 in k8376 in a8373 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8482,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[44],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 226  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[192]);}

/* k8385 in k8480 in k8376 in a8373 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 227  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[191]);}

/* k8388 in k8385 in k8480 in k8376 in a8373 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8393,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 228  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[190]);}

/* k8391 in k8388 in k8385 in k8480 in k8376 in a8373 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8393,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8396,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8433,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t7,a[8]=t3,a[9]=t10,a[10]=((C_word)li99),tmp=(C_word)a,a+=11,tmp));
t12=((C_word*)t10)[1];
f_8433(t12,t8,((C_word*)t0)[2]);}

/* loop in k8391 in k8388 in k8385 in k8480 in k8376 in a8373 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8433(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8433,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8446,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8456,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=t2,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 235  c */
t6=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8454 in loop in k8391 in k8388 in k8385 in k8480 in k8376 in a8373 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8456,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[12],0,C_SCHEME_TRUE);
t3=C_slot(((C_word*)t0)[11],C_fix(1));
/* chicken-syntax.scm: 239  loop */
t4=((C_word*)((C_word*)t0)[10])[1];
f_8433(t4,((C_word*)t0)[9],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8463,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 236  c */
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k8461 in k8454 in loop in k8391 in k8388 in k8385 in k8480 in k8376 in a8373 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8463,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=C_slot(((C_word*)t0)[9],C_fix(1));
/* chicken-syntax.scm: 239  loop */
t4=((C_word*)((C_word*)t0)[8])[1];
f_8433(t4,((C_word*)t0)[7],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8470,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 237  c */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k8468 in k8461 in k8454 in loop in k8391 in k8388 in k8385 in k8480 in k8376 in a8373 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
/* chicken-syntax.scm: 239  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_8433(t4,((C_word*)t0)[3],t3);}
else{
t2=C_i_car(((C_word*)t0)[5]);
/* chicken-syntax.scm: 238  ##sys#error */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[189],t2);}}

/* k8444 in loop in k8391 in k8388 in k8385 in k8480 in k8376 in a8373 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
/* chicken-syntax.scm: 239  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8433(t3,((C_word*)t0)[2],t2);}

/* k8394 in k8391 in k8388 in k8385 in k8480 in k8376 in a8373 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8396,2,t0,t1);}
if(C_truep(C_i_memq(lf[183],*((C_word*)lf[184]+1)))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[185],t3));}
else{
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[186],t3));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[4]:lf[187]));}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[4]:lf[188]));}}

/* k8370 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 219  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[182],C_SCHEME_END_OF_LIST,t1);}

/* k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7892,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7894,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 251  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7894,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7898,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 253  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[176],t2,lf[181]);}

/* k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7898,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7907,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 256  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[180]);}

/* k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7907,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8335,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li97),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_8335(t10,t6,((C_word*)t0)[2]);}

/* loop487 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8335(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8335,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[57]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8364,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g503504 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8362 in loop487 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8364,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop487500 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8335(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop487500 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8335(t6,((C_word*)t0)[3],t5);}}

/* k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7910,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7913,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8300,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li96),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_8300(t10,t6,((C_word*)t0)[2]);}

/* loop511 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8300(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8300,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[128]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8329,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g527528 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8327 in loop511 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8329,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop511524 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8300(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop511524 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8300(t6,((C_word*)t0)[3],t5);}}

/* k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7913,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8256,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li95),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_8256(t10,t6,((C_word*)t0)[3]);}

/* loop535 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8256(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8256,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8283,a[2]=((C_word*)t0)[5],a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8294,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g551552 */
t6=t3;
f_8283(t6,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8292 in loop535 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8294,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop535548 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8256(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop535548 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8256(t6,((C_word*)t0)[3],t5);}}

/* g551 in loop535 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8283(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8283,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8291,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 259  gensym */
t3=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8289 in g551 in loop535 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 259  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7916,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7919,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8212,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li93),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_8212(t10,t6,((C_word*)t0)[3]);}

/* loop560 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8212(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8212,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8239,a[2]=((C_word*)t0)[5],a[3]=((C_word)li92),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8250,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g576577 */
t6=t3;
f_8239(t6,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8248 in loop560 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8250,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop560573 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8212(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop560573 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8212(t6,((C_word*)t0)[3],t5);}}

/* g576 in loop560 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8239(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8239,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8247,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 260  gensym */
t3=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8245 in g576 in loop560 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 260  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7917 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7930,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8108,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8163,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word)li91),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_8163(t11,t7,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* loop588 in k7917 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8163(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8163,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[179]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8196,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g608609 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8194 in loop588 in k7917 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8196,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8176,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_8176(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_8176(t5,t4);}}

/* k8174 in k8194 in loop588 in k7917 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8176(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop588602 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8163(t5,((C_word*)t0)[2],t3,t4);}

/* k8106 in k7917 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8108,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8112,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8114,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li90),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_8114(t10,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop615 in k8106 in k7917 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8114(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8114,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[179]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8147,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g635636 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8145 in loop615 in k8106 in k7917 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8147,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8127,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_8127(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_8127(t5,t4);}}

/* k8125 in k8145 in loop615 in k8106 in k7917 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8127(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop615629 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8114(t5,((C_word*)t0)[2],t3,t4);}

/* k8110 in k8106 in k7917 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 262  ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7928 in k7917 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7998,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8002,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8004,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word)li89),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_8004(t11,t7,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop642 in k7928 in k7917 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8004(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8004,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,lf[178],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,t6,t12);
t14=C_a_i_cons(&a,2,lf[178],C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,t7,t14);
t16=C_a_i_cons(&a,2,lf[155],t15);
t17=C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=C_a_i_cons(&a,2,t13,t17);
t19=C_a_i_cons(&a,2,t11,t18);
t20=C_a_i_cons(&a,2,lf[37],t19);
t21=C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8017,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t21,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t23=t22;
f_8017(t23,C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t21));}
else{
t23=C_mutate(((C_word *)((C_word*)t0)[2])+1,t21);
t24=t22;
f_8017(t24,t23);}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8015 in loop642 in k7928 in k7917 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_8017(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop642656 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8004(t5,((C_word*)t0)[2],t3,t4);}

/* k8000 in k7928 in k7917 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_8002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7996 in k7928 in k7917 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7998,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7978,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t8=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k7976 in k7996 in k7928 in k7917 in k7914 in k7911 in k7908 in k7905 in k7896 in a7893 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7978,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=C_a_i_cons(&a,2,lf[177],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=C_a_i_cons(&a,2,lf[37],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_cons(&a,2,lf[37],t12));}

/* k7890 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 249  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[176],C_SCHEME_END_OF_LIST,t1);}

/* k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7855,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7857,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 279  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7856 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7857,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7861,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 281  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[174],t2,lf[175]);}

/* k7859 in a7856 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7861,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7884,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k7882 in k7859 in a7856 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7884,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[44],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[92],t4));}

/* k7853 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 277  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[174],C_SCHEME_END_OF_LIST,t1);}

/* k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7810,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7812,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 287  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7811 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7812,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7816,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 289  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[172],t2,lf[173]);}

/* k7814 in a7811 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7816,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,lf[170],C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7847,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k7845 in k7814 in a7811 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7847,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[44],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[92],t5));}

/* k7808 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 285  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[172],C_SCHEME_END_OF_LIST,t1);}

/* k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7585,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7587,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 296  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7586 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7587(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7587,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7591,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 298  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[165],t2,lf[171]);}

/* k7589 in a7586 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7591,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=C_i_caddr(((C_word*)t0)[3]);
if(C_truep(C_i_nullp(t2))){
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4);
t6=C_a_i_cons(&a,2,lf[32],t5);
t7=C_a_i_cons(&a,2,lf[170],C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t8);
t10=C_a_i_cons(&a,2,lf[32],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,t6,t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_cons(&a,2,lf[77],t12));}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=C_i_car(t2);
t6=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[155],t7));}
else{
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7666,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7769,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word)li85),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_7769(t13,t9,t2);}}}

/* loop712 in k7589 in a7586 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_7769(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7769,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[38]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7798,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g728729 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7796 in loop712 in k7589 in a7586 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7798,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop712725 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7769(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop712725 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7769(t6,((C_word*)t0)[3],t5);}}

/* k7664 in k7589 in a7586 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7666,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=C_a_i_cons(&a,2,lf[32],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7693,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7697,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7699,a[2]=t7,a[3]=t12,a[4]=t9,a[5]=((C_word)li84),tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_7699(t14,t10,((C_word*)t0)[2],t1);}

/* loop739 in k7664 in k7589 in a7586 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_7699(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7699,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t6,t8);
t10=C_a_i_cons(&a,2,lf[155],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7712,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t11,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t13=t12;
f_7712(t13,C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t11));}
else{
t13=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t14=t12;
f_7712(t14,t13);}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k7710 in loop739 in k7664 in k7589 in a7586 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_7712(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop739753 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7699(t5,((C_word*)t0)[2],t3,t4);}

/* k7695 in k7664 in k7589 in a7586 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7691 in k7664 in k7589 in a7586 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7693,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[77],t5));}

/* k7583 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 294  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[165],C_SCHEME_END_OF_LIST,t1);}

/* k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7543,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7545,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 319  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7544 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7545(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7545,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7549,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 321  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[164],t2,lf[169]);}

/* k7547 in a7544 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7569,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp);
t4=C_i_cadr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7568 in k7547 in a7544 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7569(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7569,3,t0,t1,t2);}
t3=*((C_word*)lf[166]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7577,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 322  ##sys#current-module */
t5=*((C_word*)lf[167]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7575 in a7568 in k7547 in a7544 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g787788 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7550 in k7547 in a7544 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7559,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 323  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[165]);}

/* k7557 in k7550 in k7547 in a7544 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7563,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k7561 in k7557 in k7550 in k7547 in a7544 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7563,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7541 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 317  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[164],C_SCHEME_END_OF_LIST,t1);}

/* k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7024,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7026,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 327  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7026,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7030,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 329  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[159],t2,lf[163]);}

/* k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7030,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_cddr(((C_word*)t0)[4]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7038,a[2]=t5,a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7069,a[2]=t7,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp));
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7111,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7506,a[2]=t11,a[3]=t16,a[4]=t13,a[5]=((C_word)li80),tmp=(C_word)a,a+=6,tmp));
t18=((C_word*)t16)[1];
f_7506(t18,t14,t2);}

/* loop816 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_7506(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7506,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[57]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7535,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g832833 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7533 in loop816 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7535,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop816829 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7506(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop816829 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7506(t6,((C_word*)t0)[3],t5);}}

/* k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7114,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7466,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word)li79),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7466(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_7466(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7466,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7479,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(t4))){
/* chicken-syntax.scm: 347  append */
t6=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,t3);}
else{
if(C_truep(C_i_pairp(t4))){
/* chicken-syntax.scm: 348  append* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_7038(t6,t5,t4,t3);}
else{
t6=C_a_i_cons(&a,2,t4,t3);
t7=C_i_cdr(t2);
/* chicken-syntax.scm: 350  loop */
t10=t1;
t11=t7;
t12=t6;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}}}

/* k7477 in loop in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 350  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7466(t3,((C_word*)t0)[2],t2,t1);}

/* k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7114,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7117,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7418,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li78),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_7418(t10,t6,t1);}

/* loop854 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_7418(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7418,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7445,a[2]=((C_word*)t0)[5],a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7460,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g870871 */
t6=t3;
f_7445(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7458 in loop854 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7460,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop854867 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7418(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop854867 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7418(t6,((C_word*)t0)[3],t5);}}

/* g870 in loop854 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_7445(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7445,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7453,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7457,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 351  gensym */
t5=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7455 in g870 in loop854 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 351  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7451 in g870 in loop854 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7453,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7118,a[2]=t1,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7129,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7372,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word)li76),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7372(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_7372(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7372,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
/* chicken-syntax.scm: 355  reverse */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=C_i_car(t2);
if(C_truep(C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7412,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 359  map* */
t6=((C_word*)((C_word*)t0)[3])[1];
f_7069(t6,t5,((C_word*)t0)[2],t4);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7405,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 358  lookup */
t6=((C_word*)t0)[2];
f_7118(3,t6,t5,t4);}}}

/* k7403 in loop in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7405,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 360  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7372(t4,((C_word*)t0)[2],t3,t2);}

/* k7410 in loop in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7412,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 360  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7372(t4,((C_word*)t0)[2],t3,t2);}

/* k7127 in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7129,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7136,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7332,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li75),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_7332(t10,t6,((C_word*)t0)[2]);}

/* loop943 in k7127 in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_7332(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7332,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop943956 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop943956 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7134 in k7127 in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7136,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7138,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word)li74),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_7138(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k7134 in k7127 in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_7138(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7138,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7156,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7162,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=((C_word)li73),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_7162(t13,t9,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7210,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(t4);
if(C_truep(C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7326,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 368  cdar */
t8=*((C_word*)lf[162]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}
else{
t7=t5;
f_7210(t7,C_SCHEME_FALSE);}}}

/* k7324 in fold in k7134 in k7127 in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7210(t2,C_i_nullp(t1));}

/* k7208 in fold in k7134 in k7127 in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_7210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7210,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 370  caar */
t3=*((C_word*)lf[161]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=C_i_car(((C_word*)t0)[6]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=C_a_i_cons(&a,2,lf[32],t4);
t6=C_i_car(((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7292,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_i_cdr(((C_word*)t0)[4]);
t9=C_i_cdr(((C_word*)t0)[6]);
t10=C_i_cdr(((C_word*)t0)[3]);
/* chicken-syntax.scm: 377  fold */
t11=((C_word*)((C_word*)t0)[2])[1];
f_7138(t11,t7,t8,t9,t10);}}

/* k7290 in k7208 in fold in k7134 in k7127 in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7292,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=C_a_i_cons(&a,2,lf[32],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_cons(&a,2,lf[77],t6));}

/* k7247 in k7208 in fold in k7134 in k7127 in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7249,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[6]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7229,a[2]=((C_word*)t0)[5],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cdr(((C_word*)t0)[4]);
t8=C_i_cdr(((C_word*)t0)[6]);
t9=C_i_cdr(((C_word*)t0)[3]);
/* chicken-syntax.scm: 371  fold */
t10=((C_word*)((C_word*)t0)[2])[1];
f_7138(t10,t6,t7,t8,t9);}

/* k7227 in k7247 in k7208 in fold in k7134 in k7127 in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7229,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[37],t3));}

/* loop908 in fold in k7134 in k7127 in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_7162(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7162,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7189,a[2]=((C_word*)t0)[5],a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7200,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g924925 */
t6=t3;
f_7189(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7198 in loop908 in fold in k7134 in k7127 in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7200,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop908921 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7162(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop908921 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7162(t6,((C_word*)t0)[3],t5);}}

/* g924 in loop908 in fold in k7134 in k7127 in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_7189(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7189,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7197,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 366  lookup */
t4=((C_word*)t0)[2];
f_7118(3,t4,t3,t2);}

/* k7195 in g924 in loop908 in fold in k7134 in k7127 in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7197,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k7154 in fold in k7134 in k7127 in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7160,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k7158 in k7154 in fold in k7134 in k7127 in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7160,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[37],t2));}

/* lookup in k7115 in k7112 in k7109 in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7118,3,t0,t1,t2);}
t3=C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_cdr(t3));}

/* map* in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_7069(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7069,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep(C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7092,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
/* chicken-syntax.scm: 340  proc */
t6=t2;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
/* chicken-syntax.scm: 339  proc */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}}

/* k7090 in map* in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7096,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 340  map* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7069(t4,t2,((C_word*)t0)[2],t3);}

/* k7094 in k7090 in map* in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7096,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_7038(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7038,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7059,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cdr(t2);
/* chicken-syntax.scm: 336  append* */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t2,t3));}}

/* k7057 in append* in k7028 in a7025 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7059,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7022 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 325  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[159],C_SCHEME_END_OF_LIST,t1);}

/* k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6955,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6957,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 381  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6956 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6957,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6961,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 383  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[158],t2,lf[160]);}

/* k6959 in a6956 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6961,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6970,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 386  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[159]);}

/* k6968 in k6959 in a6956 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6970,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6975,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li67),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6975(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fold in k6968 in k6959 in a6956 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_6975(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6975,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6993,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7012,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_i_cdr(t2);
/* chicken-syntax.scm: 391  fold */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k7010 in fold in k6968 in k6959 in a6956 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_7012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7012,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k6991 in fold in k6968 in k6959 in a6956 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6993,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[37],t2));}

/* k6953 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 379  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[158],C_SCHEME_END_OF_LIST,t1);}

/* k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6590,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6592,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 395  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6592,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6596,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 397  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[154],t2,lf[157]);}

/* k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6596,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6605,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6911,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6913,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word)li65),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_6913(t13,t9,t2);}

/* loop995 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_6913(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6913,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop9951008 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop9951008 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6909 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[27]+1),t1);}

/* k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6605,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6608,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6861,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li64),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_6861(t10,t6,t1);}

/* loop1020 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_6861(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6861,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6888,a[2]=((C_word*)t0)[5],a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6903,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g10361037 */
t6=t3;
f_6888(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6901 in loop1020 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6903,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10201033 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6861(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10201033 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6861(t6,((C_word*)t0)[3],t5);}}

/* g1036 in loop1020 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_6888(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6888,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6896,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6900,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 401  gensym */
t5=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6898 in g1036 in loop1020 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 401  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6894 in g1036 in loop1020 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6896,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6606 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6609,a[2]=t1,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6628,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6821,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_6821(t11,t7,((C_word*)t0)[2]);}

/* loop1050 in k6606 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_6821(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6821,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,2,t3,lf[156]);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop10501063 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop10501063 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6626 in k6606 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6632,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6636,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6642,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=((C_word)li61),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_6642(t11,t7,((C_word*)t0)[2]);}

/* loop1074 in k6626 in k6606 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_6642(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6642,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6669,a[2]=((C_word*)t0)[5],a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6815,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g10901091 */
t6=t3;
f_6669(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6813 in loop1074 in k6626 in k6606 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6815,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10741087 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6642(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10741087 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6642(t6,((C_word*)t0)[3],t5);}}

/* g1090 in loop1074 in k6626 in k6606 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_6669(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6669,NULL,3,t0,t1,t2);}
t3=C_i_cadr(t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4);
t6=C_a_i_cons(&a,2,lf[32],t5);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6697,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t12=C_i_car(t2);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6767,a[2]=t8,a[3]=t14,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word)li59),tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_6767(t16,t11,t12);}

/* loop1099 in g1090 in loop1074 in k6626 in k6606 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_6767(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6767,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_6609(((C_word*)t0)[5],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop10991112 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop10991112 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6695 in g1090 in loop1074 in k6626 in k6606 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6701,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6705,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_i_car(((C_word*)t0)[3]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6711,a[2]=t4,a[3]=t10,a[4]=t6,a[5]=((C_word*)t0)[2],a[6]=((C_word)li58),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_6711(t12,t7,t8);}

/* loop1122 in k6695 in g1090 in loop1074 in k6626 in k6606 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_6711(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6711,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6738,a[2]=((C_word*)t0)[5],a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_6738(C_a_i(&a,9),t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop11221135 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop11221135 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g1138 in loop1122 in k6695 in g1090 in loop1074 in k6626 in k6606 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static C_word C_fcall f_6738(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t2=f_6609(((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t1,t3);
return(C_a_i_cons(&a,2,lf[155],t4));}

/* k6703 in k6695 in g1090 in loop1074 in k6626 in k6606 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6699 in k6695 in g1090 in loop1074 in k6626 in k6606 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6701,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[77],t5));}

/* k6634 in k6626 in k6606 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6640,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6638 in k6634 in k6626 in k6606 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6630 in k6626 in k6606 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6632,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[37],t2));}

/* lookup in k6606 in k6603 in k6594 in a6591 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static C_word C_fcall f_6609(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_i_assq(t1,((C_word*)t0)[2]);
return(C_i_cdr(t2));}

/* k6588 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 393  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[154],C_SCHEME_END_OF_LIST,t1);}

/* k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2207,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6586,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 415  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[151]);}

/* k6584 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6586,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[151],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6510,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6512,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 416  ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a6511 in k6584 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6512,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6516,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 418  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[152],t2,lf[153]);}

/* k6514 in a6511 in k6584 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 419  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[113]);}

/* k6517 in k6514 in a6511 in k6584 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6519,2,t0,t1);}
t2=C_i_caddr(((C_word*)t0)[4]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=C_a_i_cons(&a,2,lf[32],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6554,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 422  r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[151]);}

/* k6552 in k6517 in k6514 in a6511 in k6584 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6554,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_cons(&a,2,t1,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=C_a_i_cons(&a,2,lf[32],t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_cons(&a,2,lf[77],t10));}

/* k6508 in k6584 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 413  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[152],((C_word*)t0)[2],t1);}

/* k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6390,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6392,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 426  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6391 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6392,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6395,a[2]=t3,a[3]=t4,a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6494,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6498,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=C_i_cdr(t2);
/* chicken-syntax.scm: 443  quotify-proc */
t9=t5;
f_6395(t9,t7,t8,lf[147]);}

/* k6496 in a6391 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6492 in a6391 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6494,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[150],t1));}

/* quotify-proc in a6391 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_6395(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6395,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 430  ##sys#check-syntax */
t5=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t3,t2,lf[149]);}

/* k6397 in quotify-proc in a6391 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6399,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[5]);
t3=C_i_pairp(t2);
t4=(C_truep(t3)?C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6408,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t2))){
t6=C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6474,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_i_cdr(((C_word*)t0)[5]);
/* ##sys#append */
t9=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t6=t5;
f_6408(t6,C_i_cadr(((C_word*)t0)[5]));}}

/* k6472 in k6397 in quotify-proc in a6391 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6474,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_6408(t3,C_a_i_cons(&a,2,lf[32],t2));}

/* k6406 in k6397 in quotify-proc in a6391 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_6408(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6408,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6411,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_i_pairp(t1);
t4=C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_6420(t6,t4);}
else{
t6=C_i_car(t1);
t7=C_eqp(lf[32],t6);
if(C_truep(t7)){
t8=t5;
f_6420(t8,C_SCHEME_FALSE);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6436,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6440,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 438  r */
t10=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,lf[21]);}}}

/* k6438 in k6406 in k6397 in quotify-proc in a6391 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(((C_word*)t0)[4]);
/* chicken-syntax.scm: 438  c */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k6434 in k6406 in k6397 in quotify-proc in a6391 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6420(t2,C_i_not(t1));}

/* k6418 in k6406 in k6397 in quotify-proc in a6391 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_6420(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6420,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-syntax.scm: 439  syntax-error */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[147],lf[148],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]));}}

/* k6409 in k6406 in k6397 in quotify-proc in a6391 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6411,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k6388 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 424  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[147],C_SCHEME_END_OF_LIST,t1);}

/* k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6237,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6239,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 447  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6238 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6239,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6243,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 449  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[145],t2,lf[146]);}

/* k6241 in a6238 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6243,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=C_i_cddr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6254,a[2]=t5,a[3]=t3,a[4]=((C_word)li51),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6254(t7,((C_word*)t0)[2],t2);}

/* fold in k6241 in a6238 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_6254(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6254,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6268,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
t4=C_i_cdr(t2);
if(C_truep(C_i_pairp(t3))){
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=C_i_car(t3);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6324,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 458  fold */
t17=t7;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
t6=C_i_car(t3);
t7=C_i_cadr(t3);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t6,t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6362,a[2]=t1,a[3]=t10,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 462  fold */
t17=t11;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6295,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 457  fold */
t17=t5;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}}

/* k6293 in fold in k6241 in a6238 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6295,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[92],t4));}

/* k6360 in fold in k6241 in a6238 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6362,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_cons(&a,2,lf[92],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[37],t7));}

/* k6322 in fold in k6241 in a6238 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6324,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[92],t4));}

/* k6266 in fold in k6241 in a6238 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6268,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[44],t1));}

/* k6235 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 445  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[145],C_SCHEME_END_OF_LIST,t1);}

/* k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6022,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6024,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 466  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6024,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6028,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 468  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[133],t2,lf[144]);}

/* k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6028,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6037,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 471  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[113]);}

/* k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 472  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[61]);}

/* k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6043,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 473  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[143]);}

/* k6041 in k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6043,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6062,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=t7,a[7]=((C_word)li49),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_6064(t9,t5,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* expand in k6041 in k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_6064(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6064,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[134]);}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_slot(t2,C_fix(0));
t5=C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t5,a[8]=((C_word*)t0)[6],a[9]=t4,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 484  ##sys#check-syntax */
t7=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[133],t4,lf[140]);}
else{
/* chicken-syntax.scm: 480  ##sys#syntax-error */
t4=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[133],lf[142],t2);}}}

/* k6087 in expand in k6041 in k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6095,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=C_i_car(((C_word*)t0)[9]);
/* chicken-syntax.scm: 485  c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k6093 in k6087 in expand in k6041 in k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6095,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6098,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 486  expand */
t3=((C_word*)((C_word*)t0)[6])[1];
f_6064(t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6115,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6122,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 491  ##sys#strip-syntax */
t4=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6161,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6165,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_i_car(((C_word*)t0)[7]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6171,a[2]=t4,a[3]=t10,a[4]=t6,a[5]=((C_word*)t0)[2],a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_6171(t12,t7,t8);}}}

/* loop1271 in k6093 in k6087 in expand in k6041 in k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_6171(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6171,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6198,a[2]=((C_word*)t0)[5],a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_6198(C_a_i(&a,9),t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop12711284 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop12711284 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g1287 in loop1271 in k6093 in k6087 in expand in k6041 in k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static C_word C_fcall f_6198(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],t2);
return(C_a_i_cons(&a,2,lf[139],t3));}

/* k6163 in k6093 in k6087 in expand in k6041 in k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6159 in k6093 in k6087 in expand in k6041 in k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6161,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6153,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k6151 in k6159 in k6093 in k6087 in expand in k6041 in k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6153,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[44],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6149,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 499  expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6064(t4,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k6147 in k6151 in k6159 in k6093 in k6087 in expand in k6041 in k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6149,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[92],t4));}

/* k6120 in k6093 in k6087 in expand in k6041 in k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 489  ##sys#notice */
t2=*((C_word*)lf[136]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[137],t1);}

/* k6113 in k6093 in k6087 in expand in k6041 in k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6118,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 492  expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6064(t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6116 in k6113 in k6093 in k6087 in expand in k6041 in k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[135]);}

/* k6096 in k6093 in k6087 in expand in k6041 in k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6105,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6103 in k6096 in k6093 in k6087 in expand in k6041 in k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6105,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[44],t1));}

/* k6060 in k6041 in k6038 in k6035 in k6026 in a6023 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6062,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[37],t3));}

/* k6020 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 464  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[133],C_SCHEME_END_OF_LIST,t1);}

/* k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2219,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6018,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 580  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[57]);}

/* k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6018,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[57],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6014,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 581  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[88]);}

/* k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_6014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6014,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[88],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5438,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5440,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 582  ##sys#er-transformer */
t7=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5440,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5444,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 584  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[119],t2,lf[132]);}

/* k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5444,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_caddr(((C_word*)t0)[4]);
t4=C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5552,a[2]=((C_word*)t0)[3],a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5753,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 625  ##sys#check-syntax */
t7=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[119],t3,lf[131]);}

/* k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 626  ##sys#check-syntax */
t3=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[119],((C_word*)t0)[6],lf[130]);}

/* k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5756,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5965,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li45),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_5965(t10,t6,((C_word*)t0)[2]);}

/* loop1351 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_5965(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5965,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[57]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5994,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g13671368 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5992 in loop1351 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5994,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13511364 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5965(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13511364 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5965(t6,((C_word*)t0)[3],t5);}}

/* k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5760,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5775,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5921,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word)li44),tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_5921(t11,t7,t1);}

/* loop1378 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_5921(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5921,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5948,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5959,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g13941395 */
t6=t3;
f_5948(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5957 in loop1378 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5959,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13781391 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5921(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13781391 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5921(t6,((C_word*)t0)[3],t5);}}

/* g1394 in loop1378 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_5948(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5948,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5956,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 634  prefix-sym */
f_5760(t3,lf[129],t2);}

/* k5954 in g1394 in loop1378 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 634  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5775,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5778,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5886,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li42),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_5886(t10,t6,((C_word*)t0)[2]);}

/* loop1403 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_5886(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5886,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[128]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5915,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g14191420 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5913 in loop1403 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5915,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14031416 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5886(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14031416 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5886(t6,((C_word*)t0)[3],t5);}}

/* k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5781,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 638  r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[127]);}

/* k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 641  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[126]);}

/* k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5784,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5787,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5842,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[6],a[7]=((C_word)li41),tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_5842(t10,t6,((C_word*)t0)[10]);}

/* loop1429 in k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_5842(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5842,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5869,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word)li40),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5880,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g14451446 */
t6=t3;
f_5869(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5878 in loop1429 in k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5880,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14291442 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5842(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14291442 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5842(t6,((C_word*)t0)[3],t5);}}

/* g1445 in loop1429 in k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_5869(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5869,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5877,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 643  prefix-sym */
f_5760(t3,lf[125],t2);}

/* k5875 in g1445 in loop1429 in k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 643  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5785 in k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5790,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[7];
t5=t1;
t6=((C_word*)t0)[2];
t7=*((C_word*)lf[38]+1);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5463,a[2]=t5,a[3]=t6,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 593  reverse */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}

/* k5461 in k5785 in k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5467,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 594  reverse */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5465 in k5461 in k5785 in k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5471,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 595  reverse */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5469 in k5465 in k5461 in k5785 in k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5471,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5473,a[2]=t3,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5473(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k5469 in k5465 in k5461 in k5785 in k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_5473(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5473,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_i_cdr(t2);
t7=C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5526,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 600  reverse */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}}

/* k5524 in recur in k5469 in k5465 in k5461 in k5785 in k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5542,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 601  reverse */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5540 in k5524 in recur in k5469 in k5465 in k5461 in k5785 in k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5542,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k5536 in k5524 in recur in k5469 in k5465 in k5461 in k5785 in k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5538,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=C_a_i_cons(&a,2,lf[32],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5494,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=C_i_cdr(((C_word*)t0)[5]);
t10=C_i_cdr(((C_word*)t0)[4]);
t11=C_i_car(((C_word*)t0)[5]);
/* chicken-syntax.scm: 602  recur */
t12=((C_word*)((C_word*)t0)[3])[1];
f_5473(t12,t8,((C_word*)t0)[2],t9,t10,t11);}

/* k5492 in k5536 in k5524 in recur in k5469 in k5465 in k5461 in k5785 in k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5494,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5788 in k5785 in k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5793,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 648  make-if-tree */
t3=((C_word*)t0)[4];
f_5552(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],((C_word*)t0)[10]);}

/* k5791 in k5788 in k5785 in k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5800,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 651  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[124]);}

/* k5798 in k5791 in k5788 in k5785 in k5782 in k5779 in k5776 in k5773 in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5800,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=C_a_i_cons(&a,2,lf[32],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=C_a_i_cons(&a,2,t7,((C_word*)t0)[4]);
t9=C_a_i_cons(&a,2,t3,t8);
t10=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t9,t10);
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_a_i_cons(&a,2,t1,t11));}

/* prefix-sym in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_5760(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5760,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5768,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5772,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 629  symbol->string */
t6=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k5770 in prefix-sym in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 629  string-append */
t2=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5766 in prefix-sym in k5757 in k5754 in k5751 in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 629  string->symbol */
t2=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* make-if-tree in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_5552(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5552,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5558,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t5,a[6]=((C_word)li36),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_5558(t9,t1,t2,t3,C_SCHEME_END_OF_LIST);}

/* recur in make-if-tree in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_5558(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5558,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5632,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 613  r */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[107]);}
else{
t5=C_i_car(t2);
t6=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[107],t6);
t8=C_i_car(t3);
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5746,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,a[8]=t7,a[9]=t5,a[10]=((C_word*)t0)[5],a[11]=t8,tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 618  reverse */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}}

/* k5744 in recur in make-if-tree in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5746,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[11],t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 619  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[57]);}

/* k5732 in k5744 in recur in make-if-tree in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5734,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5718,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t5,a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 620  r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[88]);}

/* k5716 in k5732 in k5744 in recur in make-if-tree in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5718,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[11],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[10],t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5682,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t9=C_i_cdr(((C_word*)t0)[6]);
t10=C_i_cdr(((C_word*)t0)[5]);
t11=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* chicken-syntax.scm: 621  recur */
t12=((C_word*)((C_word*)t0)[2])[1];
f_5558(t12,t8,t9,t10,t11);}

/* k5680 in k5716 in k5732 in k5744 in recur in make-if-tree in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5682,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=C_a_i_cons(&a,2,lf[37],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[92],t7));}

/* k5630 in recur in make-if-tree in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5632,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[51],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5620,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 614  reverse */
t7=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}

/* k5618 in k5630 in recur in make-if-tree in k5442 in a5439 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5620,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_cons(&a,2,lf[120],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[82],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[110],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,lf[111],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t2,t10);
t12=C_a_i_cons(&a,2,((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_cons(&a,2,lf[92],t12));}

/* k5436 in k6012 in k6016 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 578  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[119],((C_word*)t0)[2],t1);}

/* k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5430,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 671  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[107]);}

/* k5428 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5430,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[107],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5426,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 672  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[57]);}

/* k5424 in k5428 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5426,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[57],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 673  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[88]);}

/* k5420 in k5424 in k5428 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5422,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[88],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5220,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5222,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 674  ##sys#er-transformer */
t8=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* a5221 in k5420 in k5424 in k5428 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5222,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5226,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 676  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[115],t2,lf[118]);}

/* k5224 in a5221 in k5420 in k5424 in k5428 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 677  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[113]);}

/* k5227 in k5224 in a5221 in k5420 in k5424 in k5428 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5229,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 679  r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[107]);}

/* k5380 in k5227 in k5224 in a5221 in k5420 in k5424 in k5428 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5382,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_i_cddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_5267(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_5267(2,t7,C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[117],t4);}}}

/* k5265 in k5380 in k5227 in k5224 in a5221 in k5420 in k5424 in k5428 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 681  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[107]);}

/* k5341 in k5265 in k5380 in k5227 in k5224 in a5221 in k5420 in k5424 in k5428 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 681  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[88]);}

/* k5353 in k5341 in k5265 in k5380 in k5227 in k5224 in a5221 in k5420 in k5424 in k5428 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5355,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[51],t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5327,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t7,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 682  r */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,lf[57]);}

/* k5325 in k5353 in k5341 in k5265 in k5380 in k5227 in k5224 in a5221 in k5420 in k5424 in k5428 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5327,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,lf[116],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[82],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[110],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t7,t8);
t10=C_a_i_cons(&a,2,lf[111],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,t3,t11);
t13=C_a_i_cons(&a,2,((C_word*)t0)[6],t12);
t14=C_a_i_cons(&a,2,lf[92],t13);
t15=C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=C_a_i_cons(&a,2,((C_word*)t0)[5],t15);
t17=C_a_i_cons(&a,2,((C_word*)t0)[4],t16);
t18=C_a_i_cons(&a,2,lf[92],t17);
t19=C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=C_a_i_cons(&a,2,((C_word*)t0)[3],t19);
t21=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,C_a_i_cons(&a,2,lf[37],t20));}

/* k5218 in k5420 in k5424 in k5428 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 669  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[115],((C_word*)t0)[2],t1);}

/* k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5212,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 705  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[107]);}

/* k5210 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5212,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[107],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4912,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4914,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 706  ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a4913 in k5210 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4914,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4918,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 708  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[108],t2,lf[114]);}

/* k4916 in a4913 in k5210 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4918,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_caddr(((C_word*)t0)[4]);
t4=C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4930,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 712  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[107]);}

/* k4928 in k4916 in a4913 in k5210 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 713  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[57]);}

/* k4931 in k4928 in k4916 in a4913 in k5210 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 714  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[88]);}

/* k4934 in k4931 in k4928 in k4916 in a4913 in k5210 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 715  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[113]);}

/* k4937 in k4934 in k4931 in k4928 in k4916 in a4913 in k5210 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4939,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4958,a[2]=((C_word*)t0)[8],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4960,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li33),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_4960(t9,t5,t1,((C_word*)t0)[2]);}

/* loop in k4937 in k4934 in k4931 in k4928 in k4916 in a4913 in k5210 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_4960(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4960,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[51],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5026,a[2]=t1,a[3]=t7,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}
else{
t4=C_i_car(t3);
if(C_truep(C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5050,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 727  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[112]);}
else{
t5=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5188,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t9=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}}}

/* k5186 in loop in k4937 in k4934 in k4931 in k4928 in k4916 in a4913 in k5210 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5188,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[37],t2));}

/* k5048 in loop in k4937 in k4934 in k4931 in k4928 in k4916 in a4913 in k5210 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[76],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5050,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[9]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=C_i_cadr(((C_word*)t0)[9]);
t6=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t5,t8);
t10=C_a_i_cons(&a,2,t4,t9);
t11=C_a_i_cons(&a,2,lf[92],t10);
t12=C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,t2,t12);
t14=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,((C_word*)t0)[7],t14);
t16=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t17=C_a_i_cons(&a,2,lf[82],t16);
t18=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t19=C_a_i_cons(&a,2,((C_word*)t0)[5],t18);
t20=C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=C_a_i_cons(&a,2,t17,t20);
t22=C_a_i_cons(&a,2,t15,t21);
t23=C_a_i_cons(&a,2,lf[92],t22);
t24=C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=C_a_i_cons(&a,2,t1,t24);
t26=C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=C_a_i_cons(&a,2,t13,t26);
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5069,a[2]=((C_word*)t0)[4],a[3]=t27,tmp=(C_word)a,a+=4,tmp);
t29=C_i_cdr(((C_word*)t0)[3]);
/* chicken-syntax.scm: 734  loop */
t30=((C_word*)((C_word*)t0)[2])[1];
f_4960(t30,t28,t1,t29);}

/* k5067 in k5048 in loop in k4937 in k4934 in k4931 in k4928 in k4916 in a4913 in k5210 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5069,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[37],t3));}

/* k5024 in loop in k4937 in k4934 in k4931 in k4928 in k4916 in a4913 in k5210 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_5026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5026,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[37],t2);
t4=C_a_i_cons(&a,2,lf[109],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[82],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[110],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t7,t8);
t10=C_a_i_cons(&a,2,lf[111],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,t3,t11);
t13=C_a_i_cons(&a,2,((C_word*)t0)[3],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_a_i_cons(&a,2,lf[92],t13));}

/* k4956 in k4937 in k4934 in k4931 in k4928 in k4916 in a4913 in k5210 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4958,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[37],t3));}

/* k4910 in k5210 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 703  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[108],((C_word*)t0)[2],t1);}

/* k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4904,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 742  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[87]);}

/* k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4904,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[87],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4900,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 743  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[57]);}

/* k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4900,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[57],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 744  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[88]);}

/* k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4896,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[88],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 745  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[89]);}

/* k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4892,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[89],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4373,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4375,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 746  ##sys#er-transformer */
t9=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4375,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4379,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 748  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[90],t2,lf[106]);}

/* k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4381,a[2]=((C_word*)t0)[4],a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4416,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 754  require */
t4=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[105]);}

/* k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4809,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_i_cdr(((C_word*)t0)[3]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4815,a[2]=t4,a[3]=t10,a[4]=t6,a[5]=((C_word)li31),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_4815(t12,t7,t8);}

/* loop1533 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_4815(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4815,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4856,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4852,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 756  ##sys#decompose-lambda-list */
t7=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t5,t6);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a4851 in loop1533 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4852,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k4854 in loop1533 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4856,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop15331546 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4815(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop15331546 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4815(t6,((C_word*)t0)[3],t5);}}

/* k4807 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[103]+1),t1);}

/* k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4422,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 760  genvars */
t3=((C_word*)t0)[2];
f_4381(t3,t2,t1);}

/* k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4425,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 761  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[102]);}

/* k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 762  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[101]);}

/* k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 763  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[87]);}

/* k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4434,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 764  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[89]);}

/* k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4437,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 765  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[57]);}

/* k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 766  r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[88]);}

/* k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 768  append */
t3=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],((C_word*)t0)[11]);}

/* k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4451,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[91],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[11],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4475,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4477,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word)li29),tmp=(C_word)a,a+=12,tmp);
t9=C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm: 771  fold-right */
t10=*((C_word*)lf[98]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,t8,lf[99],t9);}

/* a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4477,4,t0,t1,t2,t3);}
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=((C_word*)t0)[10],a[13]=((C_word)li28),tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 773  ##sys#decompose-lambda-list */
t6=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t4,t5);}

/* a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4487,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=t1,a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],a[16]=t3,tmp=(C_word)a,a+=17,tmp);
t6=C_i_car(((C_word*)t0)[9]);
/* chicken-syntax.scm: 776  ##sys#check-syntax */
t7=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[90],t6,lf[96]);}

/* k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4491,2,t0,t1);}
t2=C_fixnum_difference(((C_word*)t0)[16],((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[16],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
t4=C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=t3;
f_4505(t5,C_SCHEME_TRUE);}
else{
t5=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=t3;
f_4505(t7,C_a_i_cons(&a,2,((C_word*)t0)[3],t6));}}
else{
t4=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=t3;
f_4505(t6,C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}}

/* k4503 in k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_4505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4505,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[12],a[3]=t1,a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4519,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word)li24),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4529,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li27),tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a4528 in k4503 in k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4529,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4533,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4605,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li26),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_4605(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a4528 in k4503 in k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_4605(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4605,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[7])){
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4630,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_i_cdr(((C_word*)t0)[6]);
/* ##sys#append */
t9=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t4=C_i_cddr(((C_word*)t0)[6]);
if(C_truep(C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_cadr(((C_word*)t0)[6]));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4662,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_i_cdr(((C_word*)t0)[6]);
/* ##sys#append */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4673,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4753,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 791  gensym */
t6=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k4751 in build in a4528 in k4503 in k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 791  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4671 in build in a4528 in k4503 in k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4673,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[7]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t2,t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,t1,t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,t6,t11);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4692,a[2]=((C_word*)t0)[3],a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=C_i_cdr(((C_word*)t0)[7]);
if(C_truep(C_i_pairp(t14))){
t15=C_i_cdr(((C_word*)t0)[7]);
/* chicken-syntax.scm: 795  build */
t16=((C_word*)((C_word*)t0)[2])[1];
f_4605(t16,t13,t15,t1);}
else{
/* chicken-syntax.scm: 796  build */
t15=((C_word*)((C_word*)t0)[2])[1];
f_4605(t15,t13,C_SCHEME_END_OF_LIST,t1);}}

/* k4690 in k4671 in build in a4528 in k4503 in k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4692,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[37],t3));}

/* k4660 in build in a4528 in k4503 in k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4662,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[37],t2));}

/* k4628 in build in a4528 in k4503 in k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4630,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[37],t2));}

/* k4531 in a4528 in k4503 in k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4533,2,t0,t1);}
if(C_truep(C_i_nullp(((C_word*)t0)[4]))){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4550,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4556,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li25),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_4556(t10,t6,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop1621 in k4531 in a4528 in k4503 in k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_4556(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4556,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[95]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4589,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g16411642 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4587 in loop1621 in k4531 in a4528 in k4503 in k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4589,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4569,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_4569(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_4569(t5,t4);}}

/* k4567 in k4587 in loop1621 in k4531 in a4528 in k4503 in k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_4569(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop16211635 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4556(t5,((C_word*)t0)[2],t3,t4);}

/* k4548 in k4531 in a4528 in k4503 in k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4550,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[37],t3));}

/* a4518 in k4503 in k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4527,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 784  take */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4525 in a4518 in k4503 in k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 784  split-at! */
t2=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4511 in k4503 in k4489 in a4486 in a4476 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4513,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[92],t4));}

/* k4473 in k4449 in k4438 in k4435 in k4432 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4475,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=C_a_i_cons(&a,2,lf[37],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_cons(&a,2,lf[32],t6));}

/* genvars in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_4381(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4381,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4387,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word)li22),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4387(t6,t1,C_fix(0));}

/* loop in genvars in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_4387(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4387,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4401,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4413,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 753  gensym */
t5=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4411 in loop in genvars in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 753  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4399 in loop in genvars in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4405,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm: 753  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4387(t4,t2,t3);}

/* k4403 in k4399 in loop in genvars in k4377 in a4374 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4405,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4371 in k4890 in k4894 in k4898 in k4902 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 740  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[90],((C_word*)t0)[2],t1);}

/* k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4275,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4277,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 809  ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a4276 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4277(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4277,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4281,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 811  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[81],t2,lf[86]);}

/* k4279 in a4276 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4281,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=C_i_cddr(((C_word*)t0)[3]);
if(C_truep(C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4296,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_a_i_cons(&a,2,t2,t3);
/* chicken-syntax.scm: 815  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[81],t5,lf[84]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4342,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_a_i_cons(&a,2,t2,t3);
/* chicken-syntax.scm: 822  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[81],t5,lf[85]);}}

/* k4340 in k4279 in a4276 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4342,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[82],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4357,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4355 in k4340 in k4279 in a4276 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4357,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[83],t2));}

/* k4294 in k4279 in a4276 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4296,2,t0,t1);}
t2=C_slot(((C_word*)t0)[4],C_fix(0));
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[82],t3);
t5=C_slot(((C_word*)t0)[4],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4327,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4325 in k4294 in k4279 in a4276 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4327,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[83],t5));}

/* k4273 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 807  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[81],C_SCHEME_END_OF_LIST,t1);}

/* k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2234,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4271,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 830  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[73]);}

/* k4269 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4271,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[73],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4267,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 831  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[74]);}

/* k4265 in k4269 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4267,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[74],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4064,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4066,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 832  ##sys#er-transformer */
t7=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a4065 in k4265 in k4269 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4066,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4070,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 834  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[68],t2,lf[80]);}

/* k4068 in a4065 in k4265 in k4269 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 835  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[79]);}

/* k4071 in k4068 in a4065 in k4265 in k4269 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 836  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[78]);}

/* k4074 in k4071 in k4068 in a4065 in k4265 in k4269 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 837  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[73]);}

/* k4085 in k4074 in k4071 in k4068 in a4065 in k4265 in k4269 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4087,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4115,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 840  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[74]);}

/* k4113 in k4085 in k4074 in k4071 in k4068 in a4065 in k4265 in k4269 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4115,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[7]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_i_caddr(((C_word*)t0)[7]);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=C_a_i_cons(&a,2,lf[32],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t3,t10);
t12=C_a_i_cons(&a,2,lf[32],t11);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4207,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t12,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t14=C_i_cdddr(((C_word*)t0)[7]);
/* ##sys#append */
t15=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,C_SCHEME_END_OF_LIST);}

/* k4205 in k4113 in k4085 in k4074 in k4071 in k4068 in a4065 in k4265 in k4269 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[84],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4207,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[75],t4);
t6=C_a_i_cons(&a,2,lf[76],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t9=C_a_i_cons(&a,2,lf[32],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,((C_word*)t0)[7],t10);
t12=C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=C_a_i_cons(&a,2,lf[32],t13);
t15=C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=C_a_i_cons(&a,2,t3,t15);
t17=C_a_i_cons(&a,2,lf[77],t16);
t18=C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t18);
t20=C_a_i_cons(&a,2,lf[32],t19);
t21=C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=C_a_i_cons(&a,2,((C_word*)t0)[6],t21);
t23=C_a_i_cons(&a,2,((C_word*)t0)[5],t22);
t24=C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=C_a_i_cons(&a,2,((C_word*)t0)[4],t24);
t26=C_a_i_cons(&a,2,lf[32],t25);
t27=C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=C_a_i_cons(&a,2,((C_word*)t0)[3],t27);
t29=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST));}

/* k4062 in k4265 in k4269 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 828  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[68],((C_word*)t0)[2],t1);}

/* k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4056,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 852  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[61]);}

/* k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4056,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[61],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 853  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[62]);}

/* k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_4052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4052,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[62],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3647,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3649,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 854  ##sys#er-transformer */
t7=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3649,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3653,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 856  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[63],t2,lf[72]);}

/* k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 857  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[71]);}

/* k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 858  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[70]);}

/* k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 859  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[69]);}

/* k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 860  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[62]);}

/* k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 861  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[61]);}

/* k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3670,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word)li17),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3877,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 875  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[68]);}

/* k3875 in k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3877,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[64],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[47],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=C_a_i_cons(&a,2,lf[49],t5);
t7=C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[9],t7);
t9=C_a_i_cons(&a,2,lf[65],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t6,t10);
t12=C_a_i_cons(&a,2,((C_word*)t0)[8],t11);
t13=C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=C_a_i_cons(&a,2,((C_word*)t0)[7],t13);
t15=C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=t15,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 878  r */
t17=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,lf[67]);}

/* k3915 in k3875 in k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3921,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3925,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=C_i_cddr(((C_word*)t0)[7]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3951,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t10,a[5]=t6,a[6]=((C_word)li18),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_3951(t12,t7,t8);}

/* loop1764 in k3915 in k3875 in k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_3951(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3951,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3980,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g17801781 */
t5=((C_word*)t0)[2];
f_3670(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3978 in loop1764 in k3915 in k3875 in k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3980,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop17641777 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3951(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop17641777 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3951(t6,((C_word*)t0)[3],t5);}}

/* k3923 in k3915 in k3875 in k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3925,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[66],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t1,t6);}

/* k3919 in k3915 in k3875 in k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3921,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=C_a_i_cons(&a,2,lf[37],t4);
t6=C_i_cadr(((C_word*)t0)[5]);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,t5,t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* parse-clause in k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_3670(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3670,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=C_i_symbolp(t3);
t5=(C_truep(t4)?C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?C_i_cadr(t2):C_i_car(t2));
t7=(C_truep(t5)?C_i_cddr(t2):C_i_cdr(t2));
if(C_truep(C_i_nullp(t6))){
if(C_truep(t5)){
t8=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t5,t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3712,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t12=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,t7,C_SCHEME_END_OF_LIST);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3731,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t9=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t7,C_SCHEME_END_OF_LIST);}}
else{
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3788,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3792,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3794,a[2]=t10,a[3]=t15,a[4]=t12,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[4],a[7]=((C_word)li16),tmp=(C_word)a,a+=8,tmp));
t17=((C_word*)t15)[1];
f_3794(t17,t13,t6);}}

/* loop1728 in parse-clause in k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_3794(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(23);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3794,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3821,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_3821(C_a_i(&a,15),t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop17281741 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop17281741 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g1744 in loop1728 in parse-clause in k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static C_word C_fcall f_3821(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_check;
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[47],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t3,t4);
return(C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k3790 in parse-clause in k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3786 in parse-clause in k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3788,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
if(C_truep(((C_word*)t0)[5])){
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3761,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t8=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3780,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k3778 in k3786 in parse-clause in k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3780,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[37],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k3759 in k3786 in parse-clause in k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3761,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,lf[37],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k3729 in parse-clause in k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3731,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[37],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k3710 in parse-clause in k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in a3648 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3712,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,lf[37],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k3645 in k4050 in k4054 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 850  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[63],((C_word*)t0)[2],t1);}

/* k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3639,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 887  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[45]);}

/* k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3639,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[45],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3088,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3090,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 888  ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3090,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3094,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 890  ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[46],t2,lf[60]);}

/* k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3094,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_i_caddr(((C_word*)t0)[5]);
t4=C_i_cadddr(((C_word*)t0)[5]);
t5=C_i_cddddr(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3109,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t2,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 898  r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[28]);}

/* k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 899  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[45]);}

/* k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3112,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3118,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 901  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[59]);}

/* k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3121,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 902  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[58]);}

/* k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3121,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3124,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3598,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li13),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3598(t10,t6,((C_word*)t0)[3]);}

/* loop1807 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_3598(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3598,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[57]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3627,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g18231824 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3625 in loop1807 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3627,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop18071820 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3598(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop18071820 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3598(t6,((C_word*)t0)[3],t5);}}

/* k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3124,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[47],t2);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3545,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t3,tmp=(C_word)a,a+=13,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3549,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3551,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word*)t0)[2],a[6]=((C_word)li12),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_3551(t13,t9,t1);}

/* loop1834 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_3551(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3551,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3578,a[2]=((C_word*)t0)[5],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_3578(t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop18341847 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop18341847 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g1850 in loop1834 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static C_word C_fcall f_3578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
if(C_truep(C_i_memq(t1,((C_word*)t0)[2]))){
t2=t1;
return(t2);}
else{
return(lf[56]);}}

/* k3547 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3543 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[65],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3545,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[12],t1);
t3=C_a_i_cons(&a,2,lf[48],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[11],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[10],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[8],t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,lf[47],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,((C_word*)t0)[9],t11);
t13=C_a_i_cons(&a,2,lf[49],t12);
t14=C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,t8,t14);
t16=C_a_i_cons(&a,2,((C_word*)t0)[10],t15);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3147,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=t16,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3151,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3153,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t20,a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word)li10),tmp=(C_word)a,a+=10,tmp));
t22=((C_word*)t20)[1];
f_3153(t22,t18,((C_word*)t0)[2],C_fix(1));}

/* loop in k3543 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_3153(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3153,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_i_car(t2);
t5=C_i_cddr(t4);
t6=C_i_pairp(t5);
t7=(C_truep(t6)?C_i_caddr(t4):C_SCHEME_FALSE);
t8=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3172,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[6],a[11]=t3,a[12]=t4,a[13]=((C_word*)t0)[7],a[14]=((C_word*)t0)[8],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_i_pairp(t7))){
t9=C_i_cdr(t7);
if(C_truep(C_i_pairp(t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3467,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t11=C_i_car(t7);
/* chicken-syntax.scm: 922  c */
t12=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,lf[55],t11);}
else{
t10=t8;
f_3172(t10,C_SCHEME_FALSE);}}
else{
t9=t8;
f_3172(t9,C_SCHEME_FALSE);}}}

/* k3465 in loop in k3543 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3172(t2,(C_truep(t1)?C_i_cadr(((C_word*)t0)[2]):C_SCHEME_FALSE));}

/* k3170 in loop in k3543 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_3172(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word ab[128],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3172,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[14],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[47],t3);
t5=C_i_cadr(((C_word*)t0)[12]);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[47],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t4,t8);
t10=C_a_i_cons(&a,2,((C_word*)t0)[14],t9);
t11=C_a_i_cons(&a,2,lf[50],t10);
t12=C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,lf[51],t12);
t14=C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,((C_word*)t0)[14],t14);
t16=C_a_i_cons(&a,2,lf[52],t15);
t17=C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=C_a_i_cons(&a,2,t13,t17);
t19=C_a_i_cons(&a,2,t2,t18);
t20=C_a_i_cons(&a,2,lf[32],t19);
t21=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3178,a[2]=((C_word*)t0)[3],a[3]=t20,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[6])){
t22=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t23=C_a_i_cons(&a,2,((C_word*)t0)[14],t22);
t24=C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t25=C_a_i_cons(&a,2,lf[47],t24);
t26=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t27=C_a_i_cons(&a,2,lf[47],t26);
t28=C_a_i_cons(&a,2,t27,C_SCHEME_END_OF_LIST);
t29=C_a_i_cons(&a,2,t25,t28);
t30=C_a_i_cons(&a,2,((C_word*)t0)[14],t29);
t31=C_a_i_cons(&a,2,lf[50],t30);
t32=C_a_i_cons(&a,2,t31,C_SCHEME_END_OF_LIST);
t33=C_a_i_cons(&a,2,lf[51],t32);
t34=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t35=C_a_i_cons(&a,2,((C_word*)t0)[11],t34);
t36=C_a_i_cons(&a,2,((C_word*)t0)[14],t35);
t37=C_a_i_cons(&a,2,lf[54],t36);
t38=C_a_i_cons(&a,2,t37,C_SCHEME_END_OF_LIST);
t39=C_a_i_cons(&a,2,t33,t38);
t40=C_a_i_cons(&a,2,t23,t39);
t41=t21;
f_3178(t41,C_a_i_cons(&a,2,lf[32],t40));}
else{
t22=t21;
f_3178(t22,C_SCHEME_FALSE);}}

/* k3176 in k3170 in loop in k3543 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_3178(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3178,NULL,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3276,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[13],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,tmp=(C_word)a,a+=14,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3283,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
t5=C_i_cadr(((C_word*)t0)[13]);
/* chicken-syntax.scm: 943  c */
t6=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[6],t5);}
else{
t5=t4;
f_3283(2,t5,C_SCHEME_FALSE);}}

/* k3281 in k3176 in k3170 in loop in k3543 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3283,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_3276(t5,C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}
else{
t2=((C_word*)t0)[2];
f_3276(t2,C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST));}}

/* k3274 in k3176 in k3170 in loop in k3543 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_3276(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3276,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[13],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[12],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3189,a[2]=t3,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3193,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[7])){
if(C_truep(((C_word*)t0)[6])){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3245,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_i_cadr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 948  c */
t8=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[6],t7);}
else{
t6=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[2],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[12],t7);
t9=t5;
f_3193(t9,C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST));}}
else{
t6=t5;
f_3193(t6,C_SCHEME_END_OF_LIST);}}

/* k3243 in k3274 in k3176 in k3170 in loop in k3543 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3245,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3193(t2,C_SCHEME_END_OF_LIST);}
else{
t2=C_a_i_cons(&a,2,lf[53],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[53],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
t6=C_a_i_cons(&a,2,t3,t5);
t7=((C_word*)t0)[4];
f_3193(t7,C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}}

/* k3191 in k3274 in k3176 in k3170 in loop in k3543 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_3193(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3193,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3197,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3201,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_cdr(((C_word*)t0)[4]);
t5=C_fixnum_increase(((C_word*)t0)[3]);
/* chicken-syntax.scm: 953  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3153(t6,t3,t4,t5);}

/* k3199 in k3191 in k3274 in k3176 in k3170 in loop in k3543 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3195 in k3191 in k3274 in k3176 in k3170 in loop in k3543 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3187 in k3274 in k3176 in k3170 in loop in k3543 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3189,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3149 in k3543 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3145 in k3543 in k3122 in k3119 in k3116 in k3110 in k3107 in k3092 in a3089 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3147,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[44],t3));}

/* k3086 in k3637 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 885  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[46],((C_word*)t0)[2],t1);}

/* k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3080,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 960  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[35]);}

/* k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3080,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[35],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2894,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2896,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 961  ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a2895 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2896,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2900,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 963  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[41]);}

/* k2898 in a2895 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2903,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 964  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[40]);}

/* k2901 in k2898 in a2895 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 965  r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[35]);}

/* k2904 in k2901 in k2898 in a2895 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2906,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[7]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2915,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word)li8),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_2915(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k2904 in k2901 in k2898 in a2895 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_2915(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2915,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2925,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 968  reverse */
t7=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3018,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=C_i_car(t2);
/* chicken-syntax.scm: 976  c */
t8=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k3016 in loop in k2904 in k2901 in k2898 in a2895 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3018,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3021,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3040,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 977  gensym */
t4=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[9]);
/* chicken-syntax.scm: 979  c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k3044 in k3016 in loop in k2904 in k2901 in k2898 in a2895 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3046,2,t0,t1);}
if(C_truep(t1)){
/* chicken-syntax.scm: 979  loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2915(t2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_i_car(((C_word*)t0)[2]);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* chicken-syntax.scm: 980  loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2915(t5,((C_word*)t0)[5],t2,((C_word*)t0)[4],t4,C_SCHEME_FALSE);}}

/* k3038 in k3016 in loop in k2904 in k2901 in k2898 in a2895 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 977  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3019 in k3016 in loop in k2904 in k2901 in k2898 in a2895 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3021,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[6]);
t3=C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken-syntax.scm: 978  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2915(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k2923 in loop in k2904 in k2901 in k2898 in a2895 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2928,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 969  reverse */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2926 in k2923 in loop in k2904 in k2901 in k2898 in a2895 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2928,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2977,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 971  gensym */
t4=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=C_i_car(t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[44],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3000,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_i_cdr(t1);
/* ##sys#append */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}

/* k2998 in k2926 in k2923 in loop in k2904 in k2901 in k2898 in a2895 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3000,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[32],t4));}

/* k2975 in k2926 in k2923 in loop in k2904 in k2901 in k2898 in a2895 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 971  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2932 in k2926 in k2923 in loop in k2904 in k2901 in k2898 in a2895 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2945,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2943 in k2932 in k2926 in k2923 in loop in k2904 in k2901 in k2898 in a2895 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2945,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=C_i_cdr(((C_word*)t0)[5]);
t5=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k2963 in k2943 in k2932 in k2926 in k2923 in loop in k2904 in k2901 in k2898 in a2895 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2965,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[32],t5));}

/* k2892 in k3078 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 958  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[43],((C_word*)t0)[2],t1);}

/* k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2886,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 984  ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[35]);}

/* k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2886,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[35],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2669,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2671,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 985  ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2671,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2675,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 987  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[35]);}

/* k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 988  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[41]);}

/* k2676 in k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2681,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 989  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[40]);}

/* k2679 in k2676 in k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2681,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[7]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2690,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li6),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_2690(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k2679 in k2676 in k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_2690(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2690,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep(C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2700,a[2]=t5,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=t4,a[6]=((C_word*)t0)[7],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 992  reverse */
t8=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2809,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t8=C_i_car(t2);
/* chicken-syntax.scm: 1002 c */
t9=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}}

/* k2807 in loop in k2679 in k2676 in k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2809,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2831,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 1003 gensym */
t4=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2837,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=C_i_car(((C_word*)t0)[10]);
/* chicken-syntax.scm: 1005 c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k2835 in k2807 in loop in k2679 in k2676 in k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2837,2,t0,t1);}
if(C_truep(t1)){
/* chicken-syntax.scm: 1005 loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2690(t2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2843,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2870,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 1007 gensym */
t4=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2868 in k2835 in k2807 in loop in k2679 in k2676 in k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1007 r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2841 in k2835 in k2807 in loop in k2679 in k2676 in k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2843,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[7]);
t3=C_i_car(((C_word*)t0)[7]);
t4=C_a_i_list(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken-syntax.scm: 1008 loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2690(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k2829 in k2807 in loop in k2679 in k2676 in k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1003 r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2810 in k2807 in loop in k2679 in k2676 in k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2812,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[7]);
t3=C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken-syntax.scm: 1004 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2690(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k2698 in loop in k2679 in k2676 in k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2703,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 993  reverse */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2701 in k2698 in loop in k2679 in k2676 in k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2703,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2709,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2764,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 995  gensym */
t4=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=C_i_cdr(t1);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k2797 in k2701 in k2698 in loop in k2679 in k2676 in k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2799,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_cons(&a,2,lf[32],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[37],t7));}

/* k2762 in k2701 in k2698 in loop in k2679 in k2676 in k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 995  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2707 in k2701 in k2698 in loop in k2679 in k2676 in k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2732,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2730 in k2707 in k2701 in k2698 in loop in k2679 in k2676 in k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2732,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2752,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=C_i_cdr(((C_word*)t0)[6]);
t5=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k2750 in k2730 in k2707 in k2701 in k2698 in loop in k2679 in k2676 in k2673 in a2670 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2752,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=C_a_i_cons(&a,2,lf[32],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_cons(&a,2,lf[37],t8));}

/* k2667 in k2884 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 982  ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[36],((C_word*)t0)[2],t1);}

/* k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2568,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2570,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1018 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2569 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2570,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2574,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 1020 ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[31],t2,lf[34]);}

/* k2572 in a2569 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2574,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
if(C_truep(C_i_pairp(t2))){
t3=C_i_car(t2);
t4=C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2630,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=C_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2657,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k2655 in k2572 in a2569 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2657,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[33],t5));}

/* k2628 in k2572 in a2569 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2630,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_i_car(((C_word*)t0)[3]);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t6,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,lf[33],t9));}

/* k2566 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1016 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[31],C_SCHEME_END_OF_LIST,t1);}

/* k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2531,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2533,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1034 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2532 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2533,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2537,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1036 ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[26],t2,lf[30]);}

/* k2535 in a2532 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1037 r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[29]);}

/* k2542 in k2535 in a2532 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2556,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1038 r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[28]);}

/* k2554 in k2542 in k2535 in a2532 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2560,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k2558 in k2554 in k2542 in k2535 in a2532 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2560,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2529 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1032 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[26],C_SCHEME_END_OF_LIST,t1);}

/* k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2506,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2508,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1045 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2507 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2508,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2512,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 1047 ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[22],t2,lf[25]);}

/* k2510 in a2507 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2512,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t2,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[23],t4));}

/* k2504 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1043 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[22],C_SCHEME_END_OF_LIST,t1);}

/* k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2340,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2342,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1055 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2341 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2342,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2352,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t5))){
t7=C_i_cdr(t5);
t8=t6;
f_2352(t8,C_eqp(t7,C_SCHEME_END_OF_LIST));}
else{
t7=t6;
f_2352(t7,C_SCHEME_FALSE);}}

/* k2350 in a2341 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_2352(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2352,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2362,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* rename20172022 */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[20]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t3=C_i_car(((C_word*)t0)[5]);
if(C_truep(C_i_pairp(t3))){
t4=C_i_cdr(((C_word*)t0)[5]);
/* ##sys#list? */
t5=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t2,t4);}
else{
t4=t2;
f_2376(2,t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2376(2,t3,C_SCHEME_FALSE);}}}

/* k2374 in k2350 in a2341 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2376,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_i_car(t2);
t4=C_i_car(((C_word*)t0)[5]);
t5=C_i_cdr(t4);
t6=C_i_cdr(((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2392,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t6,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* rename20172022 */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[19]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t3=C_i_cdr(((C_word*)t0)[5]);
if(C_truep(C_i_pairp(t3))){
t4=C_i_cdr(t3);
t5=t2;
f_2426(t5,C_eqp(t4,C_SCHEME_END_OF_LIST));}
else{
t4=t2;
f_2426(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2426(t3,C_SCHEME_FALSE);}}}

/* k2424 in k2374 in k2350 in a2341 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_fcall f_2426(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2426,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[5]);
t4=C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* rename20172022 */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[20]);}
else{
/* ##sys#syntax-rules-mismatch */
t2=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k2437 in k2424 in k2374 in k2350 in a2341 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2439,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t1,t3));}

/* k2390 in k2374 in k2350 in a2341 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2408,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* rename20172022 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[21]);}

/* k2406 in k2390 in k2374 in k2350 in a2341 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2408,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k2360 in k2350 in a2341 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2362,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t1,t3));}

/* k2338 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1053 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[19],C_SCHEME_END_OF_LIST,t1);}

/* k2256 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2284,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2286,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1066 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2285 in k2256 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2286,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2296,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t5))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2325,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=C_i_car(t5);
/* ##sys#list? */
t9=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}
else{
t7=t6;
f_2296(2,t7,C_SCHEME_FALSE);}}

/* k2323 in a2285 in k2256 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[3]);
/* ##sys#list? */
t3=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
f_2296(2,t2,C_SCHEME_FALSE);}}

/* k2294 in a2285 in k2256 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2296,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2309,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* rename20692074 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[16]);}
else{
/* ##sys#syntax-rules-mismatch */
t2=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k2307 in k2294 in a2285 in k2256 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2309,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,t1,t2));}

/* k2282 in k2256 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1064 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[15],C_SCHEME_END_OF_LIST,t1);}

/* k2259 in k2256 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2274,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2276,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1076 ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2275 in k2259 in k2256 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2276,5,t0,t1,t2,t3,t4);}
/* chicken-syntax.scm: 1078 syntax-error */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[11],lf[13]);}

/* k2272 in k2259 in k2256 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1074 ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[11],C_SCHEME_END_OF_LIST,t1);}

/* k2262 in k2259 in k2256 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2267,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1081 ##sys#macro-subset */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],*((C_word*)lf[9]+1));}

/* k2265 in k2262 in k2259 in k2256 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2267,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! ##sys#chicken-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2270,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1086 register-feature! */
t4=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t4+1)))(8,t4,t3,lf[2],lf[3],lf[4],lf[5],lf[6],lf[7]);}

/* k2268 in k2265 in k2262 in k2259 in k2256 in k2253 in k2250 in k2247 in k2244 in k2241 in k2238 in k2235 in k2232 in k2229 in k2226 in k2223 in k2220 in k2217 in k2214 in k2211 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in k2181 in k2178 in k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2154 in k2151 in k2148 in k2144 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[597] = {
{"toplevel:chicken_syntax_scm",(void*)C_chicken_syntax_toplevel},
{"f_2146:chicken_syntax_scm",(void*)f_2146},
{"f_2150:chicken_syntax_scm",(void*)f_2150},
{"f_10118:chicken_syntax_scm",(void*)f_10118},
{"f_10122:chicken_syntax_scm",(void*)f_10122},
{"f_10129:chicken_syntax_scm",(void*)f_10129},
{"f_10116:chicken_syntax_scm",(void*)f_10116},
{"f_2153:chicken_syntax_scm",(void*)f_2153},
{"f_9680:chicken_syntax_scm",(void*)f_9680},
{"f_9684:chicken_syntax_scm",(void*)f_9684},
{"f_9693:chicken_syntax_scm",(void*)f_9693},
{"f_9699:chicken_syntax_scm",(void*)f_9699},
{"f_9702:chicken_syntax_scm",(void*)f_9702},
{"f_10112:chicken_syntax_scm",(void*)f_10112},
{"f_10072:chicken_syntax_scm",(void*)f_10072},
{"f_10104:chicken_syntax_scm",(void*)f_10104},
{"f_10064:chicken_syntax_scm",(void*)f_10064},
{"f_10020:chicken_syntax_scm",(void*)f_10020},
{"f_9731:chicken_syntax_scm",(void*)f_9731},
{"f_9741:chicken_syntax_scm",(void*)f_9741},
{"f_10008:chicken_syntax_scm",(void*)f_10008},
{"f_9744:chicken_syntax_scm",(void*)f_9744},
{"f_10004:chicken_syntax_scm",(void*)f_10004},
{"f_9747:chicken_syntax_scm",(void*)f_9747},
{"f_9794:chicken_syntax_scm",(void*)f_9794},
{"f_9758:chicken_syntax_scm",(void*)f_9758},
{"f_9729:chicken_syntax_scm",(void*)f_9729},
{"f_9725:chicken_syntax_scm",(void*)f_9725},
{"f_9678:chicken_syntax_scm",(void*)f_9678},
{"f_2156:chicken_syntax_scm",(void*)f_2156},
{"f_9543:chicken_syntax_scm",(void*)f_9543},
{"f_9547:chicken_syntax_scm",(void*)f_9547},
{"f_9583:chicken_syntax_scm",(void*)f_9583},
{"f_9598:chicken_syntax_scm",(void*)f_9598},
{"f_9652:chicken_syntax_scm",(void*)f_9652},
{"f_9613:chicken_syntax_scm",(void*)f_9613},
{"f_9576:chicken_syntax_scm",(void*)f_9576},
{"f_9541:chicken_syntax_scm",(void*)f_9541},
{"f_2159:chicken_syntax_scm",(void*)f_2159},
{"f_9450:chicken_syntax_scm",(void*)f_9450},
{"f_9454:chicken_syntax_scm",(void*)f_9454},
{"f_9533:chicken_syntax_scm",(void*)f_9533},
{"f_9448:chicken_syntax_scm",(void*)f_9448},
{"f_2162:chicken_syntax_scm",(void*)f_2162},
{"f_9432:chicken_syntax_scm",(void*)f_9432},
{"f_9440:chicken_syntax_scm",(void*)f_9440},
{"f_9430:chicken_syntax_scm",(void*)f_9430},
{"f_2165:chicken_syntax_scm",(void*)f_2165},
{"f_9411:chicken_syntax_scm",(void*)f_9411},
{"f_9415:chicken_syntax_scm",(void*)f_9415},
{"f_9409:chicken_syntax_scm",(void*)f_9409},
{"f_2168:chicken_syntax_scm",(void*)f_2168},
{"f_9303:chicken_syntax_scm",(void*)f_9303},
{"f_9307:chicken_syntax_scm",(void*)f_9307},
{"f_9316:chicken_syntax_scm",(void*)f_9316},
{"f_9376:chicken_syntax_scm",(void*)f_9376},
{"f_9351:chicken_syntax_scm",(void*)f_9351},
{"f_9301:chicken_syntax_scm",(void*)f_9301},
{"f_2171:chicken_syntax_scm",(void*)f_2171},
{"f_9172:chicken_syntax_scm",(void*)f_9172},
{"f_9176:chicken_syntax_scm",(void*)f_9176},
{"f_9188:chicken_syntax_scm",(void*)f_9188},
{"f_9235:chicken_syntax_scm",(void*)f_9235},
{"f_9170:chicken_syntax_scm",(void*)f_9170},
{"f_2174:chicken_syntax_scm",(void*)f_2174},
{"f_8492:chicken_syntax_scm",(void*)f_8492},
{"f_8496:chicken_syntax_scm",(void*)f_8496},
{"f_9133:chicken_syntax_scm",(void*)f_9133},
{"f_9162:chicken_syntax_scm",(void*)f_9162},
{"f_8505:chicken_syntax_scm",(void*)f_8505},
{"f_9089:chicken_syntax_scm",(void*)f_9089},
{"f_9127:chicken_syntax_scm",(void*)f_9127},
{"f_9116:chicken_syntax_scm",(void*)f_9116},
{"f_9124:chicken_syntax_scm",(void*)f_9124},
{"f_8508:chicken_syntax_scm",(void*)f_8508},
{"f_9045:chicken_syntax_scm",(void*)f_9045},
{"f_9083:chicken_syntax_scm",(void*)f_9083},
{"f_9072:chicken_syntax_scm",(void*)f_9072},
{"f_9080:chicken_syntax_scm",(void*)f_9080},
{"f_8511:chicken_syntax_scm",(void*)f_8511},
{"f_9010:chicken_syntax_scm",(void*)f_9010},
{"f_9039:chicken_syntax_scm",(void*)f_9039},
{"f_8959:chicken_syntax_scm",(void*)f_8959},
{"f_8961:chicken_syntax_scm",(void*)f_8961},
{"f_8994:chicken_syntax_scm",(void*)f_8994},
{"f_8974:chicken_syntax_scm",(void*)f_8974},
{"f_8870:chicken_syntax_scm",(void*)f_8870},
{"f_8937:chicken_syntax_scm",(void*)f_8937},
{"f_8951:chicken_syntax_scm",(void*)f_8951},
{"f_8882:chicken_syntax_scm",(void*)f_8882},
{"f_8884:chicken_syntax_scm",(void*)f_8884},
{"f_8917:chicken_syntax_scm",(void*)f_8917},
{"f_8897:chicken_syntax_scm",(void*)f_8897},
{"f_8878:chicken_syntax_scm",(void*)f_8878},
{"f_8874:chicken_syntax_scm",(void*)f_8874},
{"f_8522:chicken_syntax_scm",(void*)f_8522},
{"f_8806:chicken_syntax_scm",(void*)f_8806},
{"f_8819:chicken_syntax_scm",(void*)f_8819},
{"f_8726:chicken_syntax_scm",(void*)f_8726},
{"f_8744:chicken_syntax_scm",(void*)f_8744},
{"f_8757:chicken_syntax_scm",(void*)f_8757},
{"f_8734:chicken_syntax_scm",(void*)f_8734},
{"f_8730:chicken_syntax_scm",(void*)f_8730},
{"f_8722:chicken_syntax_scm",(void*)f_8722},
{"f_8714:chicken_syntax_scm",(void*)f_8714},
{"f_8646:chicken_syntax_scm",(void*)f_8646},
{"f_8659:chicken_syntax_scm",(void*)f_8659},
{"f_8566:chicken_syntax_scm",(void*)f_8566},
{"f_8584:chicken_syntax_scm",(void*)f_8584},
{"f_8597:chicken_syntax_scm",(void*)f_8597},
{"f_8574:chicken_syntax_scm",(void*)f_8574},
{"f_8570:chicken_syntax_scm",(void*)f_8570},
{"f_8562:chicken_syntax_scm",(void*)f_8562},
{"f_8490:chicken_syntax_scm",(void*)f_8490},
{"f_2177:chicken_syntax_scm",(void*)f_2177},
{"f_8374:chicken_syntax_scm",(void*)f_8374},
{"f_8378:chicken_syntax_scm",(void*)f_8378},
{"f_8482:chicken_syntax_scm",(void*)f_8482},
{"f_8387:chicken_syntax_scm",(void*)f_8387},
{"f_8390:chicken_syntax_scm",(void*)f_8390},
{"f_8393:chicken_syntax_scm",(void*)f_8393},
{"f_8433:chicken_syntax_scm",(void*)f_8433},
{"f_8456:chicken_syntax_scm",(void*)f_8456},
{"f_8463:chicken_syntax_scm",(void*)f_8463},
{"f_8470:chicken_syntax_scm",(void*)f_8470},
{"f_8446:chicken_syntax_scm",(void*)f_8446},
{"f_8396:chicken_syntax_scm",(void*)f_8396},
{"f_8372:chicken_syntax_scm",(void*)f_8372},
{"f_2180:chicken_syntax_scm",(void*)f_2180},
{"f_7894:chicken_syntax_scm",(void*)f_7894},
{"f_7898:chicken_syntax_scm",(void*)f_7898},
{"f_7907:chicken_syntax_scm",(void*)f_7907},
{"f_8335:chicken_syntax_scm",(void*)f_8335},
{"f_8364:chicken_syntax_scm",(void*)f_8364},
{"f_7910:chicken_syntax_scm",(void*)f_7910},
{"f_8300:chicken_syntax_scm",(void*)f_8300},
{"f_8329:chicken_syntax_scm",(void*)f_8329},
{"f_7913:chicken_syntax_scm",(void*)f_7913},
{"f_8256:chicken_syntax_scm",(void*)f_8256},
{"f_8294:chicken_syntax_scm",(void*)f_8294},
{"f_8283:chicken_syntax_scm",(void*)f_8283},
{"f_8291:chicken_syntax_scm",(void*)f_8291},
{"f_7916:chicken_syntax_scm",(void*)f_7916},
{"f_8212:chicken_syntax_scm",(void*)f_8212},
{"f_8250:chicken_syntax_scm",(void*)f_8250},
{"f_8239:chicken_syntax_scm",(void*)f_8239},
{"f_8247:chicken_syntax_scm",(void*)f_8247},
{"f_7919:chicken_syntax_scm",(void*)f_7919},
{"f_8163:chicken_syntax_scm",(void*)f_8163},
{"f_8196:chicken_syntax_scm",(void*)f_8196},
{"f_8176:chicken_syntax_scm",(void*)f_8176},
{"f_8108:chicken_syntax_scm",(void*)f_8108},
{"f_8114:chicken_syntax_scm",(void*)f_8114},
{"f_8147:chicken_syntax_scm",(void*)f_8147},
{"f_8127:chicken_syntax_scm",(void*)f_8127},
{"f_8112:chicken_syntax_scm",(void*)f_8112},
{"f_7930:chicken_syntax_scm",(void*)f_7930},
{"f_8004:chicken_syntax_scm",(void*)f_8004},
{"f_8017:chicken_syntax_scm",(void*)f_8017},
{"f_8002:chicken_syntax_scm",(void*)f_8002},
{"f_7998:chicken_syntax_scm",(void*)f_7998},
{"f_7978:chicken_syntax_scm",(void*)f_7978},
{"f_7892:chicken_syntax_scm",(void*)f_7892},
{"f_2183:chicken_syntax_scm",(void*)f_2183},
{"f_7857:chicken_syntax_scm",(void*)f_7857},
{"f_7861:chicken_syntax_scm",(void*)f_7861},
{"f_7884:chicken_syntax_scm",(void*)f_7884},
{"f_7855:chicken_syntax_scm",(void*)f_7855},
{"f_2186:chicken_syntax_scm",(void*)f_2186},
{"f_7812:chicken_syntax_scm",(void*)f_7812},
{"f_7816:chicken_syntax_scm",(void*)f_7816},
{"f_7847:chicken_syntax_scm",(void*)f_7847},
{"f_7810:chicken_syntax_scm",(void*)f_7810},
{"f_2189:chicken_syntax_scm",(void*)f_2189},
{"f_7587:chicken_syntax_scm",(void*)f_7587},
{"f_7591:chicken_syntax_scm",(void*)f_7591},
{"f_7769:chicken_syntax_scm",(void*)f_7769},
{"f_7798:chicken_syntax_scm",(void*)f_7798},
{"f_7666:chicken_syntax_scm",(void*)f_7666},
{"f_7699:chicken_syntax_scm",(void*)f_7699},
{"f_7712:chicken_syntax_scm",(void*)f_7712},
{"f_7697:chicken_syntax_scm",(void*)f_7697},
{"f_7693:chicken_syntax_scm",(void*)f_7693},
{"f_7585:chicken_syntax_scm",(void*)f_7585},
{"f_2192:chicken_syntax_scm",(void*)f_2192},
{"f_7545:chicken_syntax_scm",(void*)f_7545},
{"f_7549:chicken_syntax_scm",(void*)f_7549},
{"f_7569:chicken_syntax_scm",(void*)f_7569},
{"f_7577:chicken_syntax_scm",(void*)f_7577},
{"f_7552:chicken_syntax_scm",(void*)f_7552},
{"f_7559:chicken_syntax_scm",(void*)f_7559},
{"f_7563:chicken_syntax_scm",(void*)f_7563},
{"f_7543:chicken_syntax_scm",(void*)f_7543},
{"f_2195:chicken_syntax_scm",(void*)f_2195},
{"f_7026:chicken_syntax_scm",(void*)f_7026},
{"f_7030:chicken_syntax_scm",(void*)f_7030},
{"f_7506:chicken_syntax_scm",(void*)f_7506},
{"f_7535:chicken_syntax_scm",(void*)f_7535},
{"f_7111:chicken_syntax_scm",(void*)f_7111},
{"f_7466:chicken_syntax_scm",(void*)f_7466},
{"f_7479:chicken_syntax_scm",(void*)f_7479},
{"f_7114:chicken_syntax_scm",(void*)f_7114},
{"f_7418:chicken_syntax_scm",(void*)f_7418},
{"f_7460:chicken_syntax_scm",(void*)f_7460},
{"f_7445:chicken_syntax_scm",(void*)f_7445},
{"f_7457:chicken_syntax_scm",(void*)f_7457},
{"f_7453:chicken_syntax_scm",(void*)f_7453},
{"f_7117:chicken_syntax_scm",(void*)f_7117},
{"f_7372:chicken_syntax_scm",(void*)f_7372},
{"f_7405:chicken_syntax_scm",(void*)f_7405},
{"f_7412:chicken_syntax_scm",(void*)f_7412},
{"f_7129:chicken_syntax_scm",(void*)f_7129},
{"f_7332:chicken_syntax_scm",(void*)f_7332},
{"f_7136:chicken_syntax_scm",(void*)f_7136},
{"f_7138:chicken_syntax_scm",(void*)f_7138},
{"f_7326:chicken_syntax_scm",(void*)f_7326},
{"f_7210:chicken_syntax_scm",(void*)f_7210},
{"f_7292:chicken_syntax_scm",(void*)f_7292},
{"f_7249:chicken_syntax_scm",(void*)f_7249},
{"f_7229:chicken_syntax_scm",(void*)f_7229},
{"f_7162:chicken_syntax_scm",(void*)f_7162},
{"f_7200:chicken_syntax_scm",(void*)f_7200},
{"f_7189:chicken_syntax_scm",(void*)f_7189},
{"f_7197:chicken_syntax_scm",(void*)f_7197},
{"f_7156:chicken_syntax_scm",(void*)f_7156},
{"f_7160:chicken_syntax_scm",(void*)f_7160},
{"f_7118:chicken_syntax_scm",(void*)f_7118},
{"f_7069:chicken_syntax_scm",(void*)f_7069},
{"f_7092:chicken_syntax_scm",(void*)f_7092},
{"f_7096:chicken_syntax_scm",(void*)f_7096},
{"f_7038:chicken_syntax_scm",(void*)f_7038},
{"f_7059:chicken_syntax_scm",(void*)f_7059},
{"f_7024:chicken_syntax_scm",(void*)f_7024},
{"f_2198:chicken_syntax_scm",(void*)f_2198},
{"f_6957:chicken_syntax_scm",(void*)f_6957},
{"f_6961:chicken_syntax_scm",(void*)f_6961},
{"f_6970:chicken_syntax_scm",(void*)f_6970},
{"f_6975:chicken_syntax_scm",(void*)f_6975},
{"f_7012:chicken_syntax_scm",(void*)f_7012},
{"f_6993:chicken_syntax_scm",(void*)f_6993},
{"f_6955:chicken_syntax_scm",(void*)f_6955},
{"f_2201:chicken_syntax_scm",(void*)f_2201},
{"f_6592:chicken_syntax_scm",(void*)f_6592},
{"f_6596:chicken_syntax_scm",(void*)f_6596},
{"f_6913:chicken_syntax_scm",(void*)f_6913},
{"f_6911:chicken_syntax_scm",(void*)f_6911},
{"f_6605:chicken_syntax_scm",(void*)f_6605},
{"f_6861:chicken_syntax_scm",(void*)f_6861},
{"f_6903:chicken_syntax_scm",(void*)f_6903},
{"f_6888:chicken_syntax_scm",(void*)f_6888},
{"f_6900:chicken_syntax_scm",(void*)f_6900},
{"f_6896:chicken_syntax_scm",(void*)f_6896},
{"f_6608:chicken_syntax_scm",(void*)f_6608},
{"f_6821:chicken_syntax_scm",(void*)f_6821},
{"f_6628:chicken_syntax_scm",(void*)f_6628},
{"f_6642:chicken_syntax_scm",(void*)f_6642},
{"f_6815:chicken_syntax_scm",(void*)f_6815},
{"f_6669:chicken_syntax_scm",(void*)f_6669},
{"f_6767:chicken_syntax_scm",(void*)f_6767},
{"f_6697:chicken_syntax_scm",(void*)f_6697},
{"f_6711:chicken_syntax_scm",(void*)f_6711},
{"f_6738:chicken_syntax_scm",(void*)f_6738},
{"f_6705:chicken_syntax_scm",(void*)f_6705},
{"f_6701:chicken_syntax_scm",(void*)f_6701},
{"f_6636:chicken_syntax_scm",(void*)f_6636},
{"f_6640:chicken_syntax_scm",(void*)f_6640},
{"f_6632:chicken_syntax_scm",(void*)f_6632},
{"f_6609:chicken_syntax_scm",(void*)f_6609},
{"f_6590:chicken_syntax_scm",(void*)f_6590},
{"f_2204:chicken_syntax_scm",(void*)f_2204},
{"f_6586:chicken_syntax_scm",(void*)f_6586},
{"f_6512:chicken_syntax_scm",(void*)f_6512},
{"f_6516:chicken_syntax_scm",(void*)f_6516},
{"f_6519:chicken_syntax_scm",(void*)f_6519},
{"f_6554:chicken_syntax_scm",(void*)f_6554},
{"f_6510:chicken_syntax_scm",(void*)f_6510},
{"f_2207:chicken_syntax_scm",(void*)f_2207},
{"f_6392:chicken_syntax_scm",(void*)f_6392},
{"f_6498:chicken_syntax_scm",(void*)f_6498},
{"f_6494:chicken_syntax_scm",(void*)f_6494},
{"f_6395:chicken_syntax_scm",(void*)f_6395},
{"f_6399:chicken_syntax_scm",(void*)f_6399},
{"f_6474:chicken_syntax_scm",(void*)f_6474},
{"f_6408:chicken_syntax_scm",(void*)f_6408},
{"f_6440:chicken_syntax_scm",(void*)f_6440},
{"f_6436:chicken_syntax_scm",(void*)f_6436},
{"f_6420:chicken_syntax_scm",(void*)f_6420},
{"f_6411:chicken_syntax_scm",(void*)f_6411},
{"f_6390:chicken_syntax_scm",(void*)f_6390},
{"f_2210:chicken_syntax_scm",(void*)f_2210},
{"f_6239:chicken_syntax_scm",(void*)f_6239},
{"f_6243:chicken_syntax_scm",(void*)f_6243},
{"f_6254:chicken_syntax_scm",(void*)f_6254},
{"f_6295:chicken_syntax_scm",(void*)f_6295},
{"f_6362:chicken_syntax_scm",(void*)f_6362},
{"f_6324:chicken_syntax_scm",(void*)f_6324},
{"f_6268:chicken_syntax_scm",(void*)f_6268},
{"f_6237:chicken_syntax_scm",(void*)f_6237},
{"f_2213:chicken_syntax_scm",(void*)f_2213},
{"f_6024:chicken_syntax_scm",(void*)f_6024},
{"f_6028:chicken_syntax_scm",(void*)f_6028},
{"f_6037:chicken_syntax_scm",(void*)f_6037},
{"f_6040:chicken_syntax_scm",(void*)f_6040},
{"f_6043:chicken_syntax_scm",(void*)f_6043},
{"f_6064:chicken_syntax_scm",(void*)f_6064},
{"f_6089:chicken_syntax_scm",(void*)f_6089},
{"f_6095:chicken_syntax_scm",(void*)f_6095},
{"f_6171:chicken_syntax_scm",(void*)f_6171},
{"f_6198:chicken_syntax_scm",(void*)f_6198},
{"f_6165:chicken_syntax_scm",(void*)f_6165},
{"f_6161:chicken_syntax_scm",(void*)f_6161},
{"f_6153:chicken_syntax_scm",(void*)f_6153},
{"f_6149:chicken_syntax_scm",(void*)f_6149},
{"f_6122:chicken_syntax_scm",(void*)f_6122},
{"f_6115:chicken_syntax_scm",(void*)f_6115},
{"f_6118:chicken_syntax_scm",(void*)f_6118},
{"f_6098:chicken_syntax_scm",(void*)f_6098},
{"f_6105:chicken_syntax_scm",(void*)f_6105},
{"f_6062:chicken_syntax_scm",(void*)f_6062},
{"f_6022:chicken_syntax_scm",(void*)f_6022},
{"f_2216:chicken_syntax_scm",(void*)f_2216},
{"f_6018:chicken_syntax_scm",(void*)f_6018},
{"f_6014:chicken_syntax_scm",(void*)f_6014},
{"f_5440:chicken_syntax_scm",(void*)f_5440},
{"f_5444:chicken_syntax_scm",(void*)f_5444},
{"f_5753:chicken_syntax_scm",(void*)f_5753},
{"f_5756:chicken_syntax_scm",(void*)f_5756},
{"f_5965:chicken_syntax_scm",(void*)f_5965},
{"f_5994:chicken_syntax_scm",(void*)f_5994},
{"f_5759:chicken_syntax_scm",(void*)f_5759},
{"f_5921:chicken_syntax_scm",(void*)f_5921},
{"f_5959:chicken_syntax_scm",(void*)f_5959},
{"f_5948:chicken_syntax_scm",(void*)f_5948},
{"f_5956:chicken_syntax_scm",(void*)f_5956},
{"f_5775:chicken_syntax_scm",(void*)f_5775},
{"f_5886:chicken_syntax_scm",(void*)f_5886},
{"f_5915:chicken_syntax_scm",(void*)f_5915},
{"f_5778:chicken_syntax_scm",(void*)f_5778},
{"f_5781:chicken_syntax_scm",(void*)f_5781},
{"f_5784:chicken_syntax_scm",(void*)f_5784},
{"f_5842:chicken_syntax_scm",(void*)f_5842},
{"f_5880:chicken_syntax_scm",(void*)f_5880},
{"f_5869:chicken_syntax_scm",(void*)f_5869},
{"f_5877:chicken_syntax_scm",(void*)f_5877},
{"f_5787:chicken_syntax_scm",(void*)f_5787},
{"f_5463:chicken_syntax_scm",(void*)f_5463},
{"f_5467:chicken_syntax_scm",(void*)f_5467},
{"f_5471:chicken_syntax_scm",(void*)f_5471},
{"f_5473:chicken_syntax_scm",(void*)f_5473},
{"f_5526:chicken_syntax_scm",(void*)f_5526},
{"f_5542:chicken_syntax_scm",(void*)f_5542},
{"f_5538:chicken_syntax_scm",(void*)f_5538},
{"f_5494:chicken_syntax_scm",(void*)f_5494},
{"f_5790:chicken_syntax_scm",(void*)f_5790},
{"f_5793:chicken_syntax_scm",(void*)f_5793},
{"f_5800:chicken_syntax_scm",(void*)f_5800},
{"f_5760:chicken_syntax_scm",(void*)f_5760},
{"f_5772:chicken_syntax_scm",(void*)f_5772},
{"f_5768:chicken_syntax_scm",(void*)f_5768},
{"f_5552:chicken_syntax_scm",(void*)f_5552},
{"f_5558:chicken_syntax_scm",(void*)f_5558},
{"f_5746:chicken_syntax_scm",(void*)f_5746},
{"f_5734:chicken_syntax_scm",(void*)f_5734},
{"f_5718:chicken_syntax_scm",(void*)f_5718},
{"f_5682:chicken_syntax_scm",(void*)f_5682},
{"f_5632:chicken_syntax_scm",(void*)f_5632},
{"f_5620:chicken_syntax_scm",(void*)f_5620},
{"f_5438:chicken_syntax_scm",(void*)f_5438},
{"f_2219:chicken_syntax_scm",(void*)f_2219},
{"f_5430:chicken_syntax_scm",(void*)f_5430},
{"f_5426:chicken_syntax_scm",(void*)f_5426},
{"f_5422:chicken_syntax_scm",(void*)f_5422},
{"f_5222:chicken_syntax_scm",(void*)f_5222},
{"f_5226:chicken_syntax_scm",(void*)f_5226},
{"f_5229:chicken_syntax_scm",(void*)f_5229},
{"f_5382:chicken_syntax_scm",(void*)f_5382},
{"f_5267:chicken_syntax_scm",(void*)f_5267},
{"f_5343:chicken_syntax_scm",(void*)f_5343},
{"f_5355:chicken_syntax_scm",(void*)f_5355},
{"f_5327:chicken_syntax_scm",(void*)f_5327},
{"f_5220:chicken_syntax_scm",(void*)f_5220},
{"f_2222:chicken_syntax_scm",(void*)f_2222},
{"f_5212:chicken_syntax_scm",(void*)f_5212},
{"f_4914:chicken_syntax_scm",(void*)f_4914},
{"f_4918:chicken_syntax_scm",(void*)f_4918},
{"f_4930:chicken_syntax_scm",(void*)f_4930},
{"f_4933:chicken_syntax_scm",(void*)f_4933},
{"f_4936:chicken_syntax_scm",(void*)f_4936},
{"f_4939:chicken_syntax_scm",(void*)f_4939},
{"f_4960:chicken_syntax_scm",(void*)f_4960},
{"f_5188:chicken_syntax_scm",(void*)f_5188},
{"f_5050:chicken_syntax_scm",(void*)f_5050},
{"f_5069:chicken_syntax_scm",(void*)f_5069},
{"f_5026:chicken_syntax_scm",(void*)f_5026},
{"f_4958:chicken_syntax_scm",(void*)f_4958},
{"f_4912:chicken_syntax_scm",(void*)f_4912},
{"f_2225:chicken_syntax_scm",(void*)f_2225},
{"f_4904:chicken_syntax_scm",(void*)f_4904},
{"f_4900:chicken_syntax_scm",(void*)f_4900},
{"f_4896:chicken_syntax_scm",(void*)f_4896},
{"f_4892:chicken_syntax_scm",(void*)f_4892},
{"f_4375:chicken_syntax_scm",(void*)f_4375},
{"f_4379:chicken_syntax_scm",(void*)f_4379},
{"f_4416:chicken_syntax_scm",(void*)f_4416},
{"f_4815:chicken_syntax_scm",(void*)f_4815},
{"f_4852:chicken_syntax_scm",(void*)f_4852},
{"f_4856:chicken_syntax_scm",(void*)f_4856},
{"f_4809:chicken_syntax_scm",(void*)f_4809},
{"f_4419:chicken_syntax_scm",(void*)f_4419},
{"f_4422:chicken_syntax_scm",(void*)f_4422},
{"f_4425:chicken_syntax_scm",(void*)f_4425},
{"f_4428:chicken_syntax_scm",(void*)f_4428},
{"f_4431:chicken_syntax_scm",(void*)f_4431},
{"f_4434:chicken_syntax_scm",(void*)f_4434},
{"f_4437:chicken_syntax_scm",(void*)f_4437},
{"f_4440:chicken_syntax_scm",(void*)f_4440},
{"f_4451:chicken_syntax_scm",(void*)f_4451},
{"f_4477:chicken_syntax_scm",(void*)f_4477},
{"f_4487:chicken_syntax_scm",(void*)f_4487},
{"f_4491:chicken_syntax_scm",(void*)f_4491},
{"f_4505:chicken_syntax_scm",(void*)f_4505},
{"f_4529:chicken_syntax_scm",(void*)f_4529},
{"f_4605:chicken_syntax_scm",(void*)f_4605},
{"f_4753:chicken_syntax_scm",(void*)f_4753},
{"f_4673:chicken_syntax_scm",(void*)f_4673},
{"f_4692:chicken_syntax_scm",(void*)f_4692},
{"f_4662:chicken_syntax_scm",(void*)f_4662},
{"f_4630:chicken_syntax_scm",(void*)f_4630},
{"f_4533:chicken_syntax_scm",(void*)f_4533},
{"f_4556:chicken_syntax_scm",(void*)f_4556},
{"f_4589:chicken_syntax_scm",(void*)f_4589},
{"f_4569:chicken_syntax_scm",(void*)f_4569},
{"f_4550:chicken_syntax_scm",(void*)f_4550},
{"f_4519:chicken_syntax_scm",(void*)f_4519},
{"f_4527:chicken_syntax_scm",(void*)f_4527},
{"f_4513:chicken_syntax_scm",(void*)f_4513},
{"f_4475:chicken_syntax_scm",(void*)f_4475},
{"f_4381:chicken_syntax_scm",(void*)f_4381},
{"f_4387:chicken_syntax_scm",(void*)f_4387},
{"f_4413:chicken_syntax_scm",(void*)f_4413},
{"f_4401:chicken_syntax_scm",(void*)f_4401},
{"f_4405:chicken_syntax_scm",(void*)f_4405},
{"f_4373:chicken_syntax_scm",(void*)f_4373},
{"f_2228:chicken_syntax_scm",(void*)f_2228},
{"f_4277:chicken_syntax_scm",(void*)f_4277},
{"f_4281:chicken_syntax_scm",(void*)f_4281},
{"f_4342:chicken_syntax_scm",(void*)f_4342},
{"f_4357:chicken_syntax_scm",(void*)f_4357},
{"f_4296:chicken_syntax_scm",(void*)f_4296},
{"f_4327:chicken_syntax_scm",(void*)f_4327},
{"f_4275:chicken_syntax_scm",(void*)f_4275},
{"f_2231:chicken_syntax_scm",(void*)f_2231},
{"f_4271:chicken_syntax_scm",(void*)f_4271},
{"f_4267:chicken_syntax_scm",(void*)f_4267},
{"f_4066:chicken_syntax_scm",(void*)f_4066},
{"f_4070:chicken_syntax_scm",(void*)f_4070},
{"f_4073:chicken_syntax_scm",(void*)f_4073},
{"f_4076:chicken_syntax_scm",(void*)f_4076},
{"f_4087:chicken_syntax_scm",(void*)f_4087},
{"f_4115:chicken_syntax_scm",(void*)f_4115},
{"f_4207:chicken_syntax_scm",(void*)f_4207},
{"f_4064:chicken_syntax_scm",(void*)f_4064},
{"f_2234:chicken_syntax_scm",(void*)f_2234},
{"f_4056:chicken_syntax_scm",(void*)f_4056},
{"f_4052:chicken_syntax_scm",(void*)f_4052},
{"f_3649:chicken_syntax_scm",(void*)f_3649},
{"f_3653:chicken_syntax_scm",(void*)f_3653},
{"f_3656:chicken_syntax_scm",(void*)f_3656},
{"f_3659:chicken_syntax_scm",(void*)f_3659},
{"f_3662:chicken_syntax_scm",(void*)f_3662},
{"f_3665:chicken_syntax_scm",(void*)f_3665},
{"f_3668:chicken_syntax_scm",(void*)f_3668},
{"f_3877:chicken_syntax_scm",(void*)f_3877},
{"f_3917:chicken_syntax_scm",(void*)f_3917},
{"f_3951:chicken_syntax_scm",(void*)f_3951},
{"f_3980:chicken_syntax_scm",(void*)f_3980},
{"f_3925:chicken_syntax_scm",(void*)f_3925},
{"f_3921:chicken_syntax_scm",(void*)f_3921},
{"f_3670:chicken_syntax_scm",(void*)f_3670},
{"f_3794:chicken_syntax_scm",(void*)f_3794},
{"f_3821:chicken_syntax_scm",(void*)f_3821},
{"f_3792:chicken_syntax_scm",(void*)f_3792},
{"f_3788:chicken_syntax_scm",(void*)f_3788},
{"f_3780:chicken_syntax_scm",(void*)f_3780},
{"f_3761:chicken_syntax_scm",(void*)f_3761},
{"f_3731:chicken_syntax_scm",(void*)f_3731},
{"f_3712:chicken_syntax_scm",(void*)f_3712},
{"f_3647:chicken_syntax_scm",(void*)f_3647},
{"f_2237:chicken_syntax_scm",(void*)f_2237},
{"f_3639:chicken_syntax_scm",(void*)f_3639},
{"f_3090:chicken_syntax_scm",(void*)f_3090},
{"f_3094:chicken_syntax_scm",(void*)f_3094},
{"f_3109:chicken_syntax_scm",(void*)f_3109},
{"f_3112:chicken_syntax_scm",(void*)f_3112},
{"f_3118:chicken_syntax_scm",(void*)f_3118},
{"f_3121:chicken_syntax_scm",(void*)f_3121},
{"f_3598:chicken_syntax_scm",(void*)f_3598},
{"f_3627:chicken_syntax_scm",(void*)f_3627},
{"f_3124:chicken_syntax_scm",(void*)f_3124},
{"f_3551:chicken_syntax_scm",(void*)f_3551},
{"f_3578:chicken_syntax_scm",(void*)f_3578},
{"f_3549:chicken_syntax_scm",(void*)f_3549},
{"f_3545:chicken_syntax_scm",(void*)f_3545},
{"f_3153:chicken_syntax_scm",(void*)f_3153},
{"f_3467:chicken_syntax_scm",(void*)f_3467},
{"f_3172:chicken_syntax_scm",(void*)f_3172},
{"f_3178:chicken_syntax_scm",(void*)f_3178},
{"f_3283:chicken_syntax_scm",(void*)f_3283},
{"f_3276:chicken_syntax_scm",(void*)f_3276},
{"f_3245:chicken_syntax_scm",(void*)f_3245},
{"f_3193:chicken_syntax_scm",(void*)f_3193},
{"f_3201:chicken_syntax_scm",(void*)f_3201},
{"f_3197:chicken_syntax_scm",(void*)f_3197},
{"f_3189:chicken_syntax_scm",(void*)f_3189},
{"f_3151:chicken_syntax_scm",(void*)f_3151},
{"f_3147:chicken_syntax_scm",(void*)f_3147},
{"f_3088:chicken_syntax_scm",(void*)f_3088},
{"f_2240:chicken_syntax_scm",(void*)f_2240},
{"f_3080:chicken_syntax_scm",(void*)f_3080},
{"f_2896:chicken_syntax_scm",(void*)f_2896},
{"f_2900:chicken_syntax_scm",(void*)f_2900},
{"f_2903:chicken_syntax_scm",(void*)f_2903},
{"f_2906:chicken_syntax_scm",(void*)f_2906},
{"f_2915:chicken_syntax_scm",(void*)f_2915},
{"f_3018:chicken_syntax_scm",(void*)f_3018},
{"f_3046:chicken_syntax_scm",(void*)f_3046},
{"f_3040:chicken_syntax_scm",(void*)f_3040},
{"f_3021:chicken_syntax_scm",(void*)f_3021},
{"f_2925:chicken_syntax_scm",(void*)f_2925},
{"f_2928:chicken_syntax_scm",(void*)f_2928},
{"f_3000:chicken_syntax_scm",(void*)f_3000},
{"f_2977:chicken_syntax_scm",(void*)f_2977},
{"f_2934:chicken_syntax_scm",(void*)f_2934},
{"f_2945:chicken_syntax_scm",(void*)f_2945},
{"f_2965:chicken_syntax_scm",(void*)f_2965},
{"f_2894:chicken_syntax_scm",(void*)f_2894},
{"f_2243:chicken_syntax_scm",(void*)f_2243},
{"f_2886:chicken_syntax_scm",(void*)f_2886},
{"f_2671:chicken_syntax_scm",(void*)f_2671},
{"f_2675:chicken_syntax_scm",(void*)f_2675},
{"f_2678:chicken_syntax_scm",(void*)f_2678},
{"f_2681:chicken_syntax_scm",(void*)f_2681},
{"f_2690:chicken_syntax_scm",(void*)f_2690},
{"f_2809:chicken_syntax_scm",(void*)f_2809},
{"f_2837:chicken_syntax_scm",(void*)f_2837},
{"f_2870:chicken_syntax_scm",(void*)f_2870},
{"f_2843:chicken_syntax_scm",(void*)f_2843},
{"f_2831:chicken_syntax_scm",(void*)f_2831},
{"f_2812:chicken_syntax_scm",(void*)f_2812},
{"f_2700:chicken_syntax_scm",(void*)f_2700},
{"f_2703:chicken_syntax_scm",(void*)f_2703},
{"f_2799:chicken_syntax_scm",(void*)f_2799},
{"f_2764:chicken_syntax_scm",(void*)f_2764},
{"f_2709:chicken_syntax_scm",(void*)f_2709},
{"f_2732:chicken_syntax_scm",(void*)f_2732},
{"f_2752:chicken_syntax_scm",(void*)f_2752},
{"f_2669:chicken_syntax_scm",(void*)f_2669},
{"f_2246:chicken_syntax_scm",(void*)f_2246},
{"f_2570:chicken_syntax_scm",(void*)f_2570},
{"f_2574:chicken_syntax_scm",(void*)f_2574},
{"f_2657:chicken_syntax_scm",(void*)f_2657},
{"f_2630:chicken_syntax_scm",(void*)f_2630},
{"f_2568:chicken_syntax_scm",(void*)f_2568},
{"f_2249:chicken_syntax_scm",(void*)f_2249},
{"f_2533:chicken_syntax_scm",(void*)f_2533},
{"f_2537:chicken_syntax_scm",(void*)f_2537},
{"f_2544:chicken_syntax_scm",(void*)f_2544},
{"f_2556:chicken_syntax_scm",(void*)f_2556},
{"f_2560:chicken_syntax_scm",(void*)f_2560},
{"f_2531:chicken_syntax_scm",(void*)f_2531},
{"f_2252:chicken_syntax_scm",(void*)f_2252},
{"f_2508:chicken_syntax_scm",(void*)f_2508},
{"f_2512:chicken_syntax_scm",(void*)f_2512},
{"f_2506:chicken_syntax_scm",(void*)f_2506},
{"f_2255:chicken_syntax_scm",(void*)f_2255},
{"f_2342:chicken_syntax_scm",(void*)f_2342},
{"f_2352:chicken_syntax_scm",(void*)f_2352},
{"f_2376:chicken_syntax_scm",(void*)f_2376},
{"f_2426:chicken_syntax_scm",(void*)f_2426},
{"f_2439:chicken_syntax_scm",(void*)f_2439},
{"f_2392:chicken_syntax_scm",(void*)f_2392},
{"f_2408:chicken_syntax_scm",(void*)f_2408},
{"f_2362:chicken_syntax_scm",(void*)f_2362},
{"f_2340:chicken_syntax_scm",(void*)f_2340},
{"f_2258:chicken_syntax_scm",(void*)f_2258},
{"f_2286:chicken_syntax_scm",(void*)f_2286},
{"f_2325:chicken_syntax_scm",(void*)f_2325},
{"f_2296:chicken_syntax_scm",(void*)f_2296},
{"f_2309:chicken_syntax_scm",(void*)f_2309},
{"f_2284:chicken_syntax_scm",(void*)f_2284},
{"f_2261:chicken_syntax_scm",(void*)f_2261},
{"f_2276:chicken_syntax_scm",(void*)f_2276},
{"f_2274:chicken_syntax_scm",(void*)f_2274},
{"f_2264:chicken_syntax_scm",(void*)f_2264},
{"f_2267:chicken_syntax_scm",(void*)f_2267},
{"f_2270:chicken_syntax_scm",(void*)f_2270},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
