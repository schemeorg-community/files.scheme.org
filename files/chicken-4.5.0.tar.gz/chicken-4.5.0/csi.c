/* Generated from csi.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:53
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: csi.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -output-file csi.c -extend ./private-namespace.scm
   used units: library eval chicken_syntax srfi_69 ports extras
*/

#include "chicken.h"

#if (defined(_MSC_VER) && defined(_WIN32)) || defined(HAVE_DIRECT_H)
# include <direct.h>
#else
# define _getcwd(buf, len)       NULL
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[361];
static double C_possibly_force_alignment;


/* from k1496 */
static C_word C_fcall stub75(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub75(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mpointer(&C_a,(void*)_getcwd(t0,t1));
return C_r;}

C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1324)
static void C_ccall f_1324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1330)
static void C_ccall f_1330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1333)
static void C_ccall f_1333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1339)
static void C_ccall f_1339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1484)
static void C_ccall f_1484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5231)
static void C_ccall f_5231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1721)
static void C_ccall f_1721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2330)
static void C_ccall f_2330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5220)
static void C_ccall f_5220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5223)
static void C_ccall f_5223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2259)
static void C_ccall f_2259(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_fcall f_2293(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2205)
static void C_ccall f_2205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2207)
static void C_fcall f_2207(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_fcall f_2217(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5210)
static void C_ccall f_5210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4201)
static void C_ccall f_4201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5206)
static void C_ccall f_5206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5193)
static void C_ccall f_5193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5103)
static void C_ccall f_5103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5109)
static void C_ccall f_5109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_ccall f_5112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5121)
static void C_ccall f_5121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4210)
static void C_fcall f_4210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5097)
static void C_ccall f_5097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4216)
static void C_fcall f_4216(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4219)
static void C_ccall f_4219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4222)
static void C_fcall f_4222(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5049)
static void C_ccall f_5049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5051)
static void C_fcall f_5051(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_fcall f_4382(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5041)
static void C_ccall f_5041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4385)
static void C_ccall f_4385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5029)
static void C_ccall f_5029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4388)
static void C_ccall f_4388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4391)
static void C_fcall f_4391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5015)
static void C_ccall f_5015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4394)
static void C_ccall f_4394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5005)
static void C_ccall f_5005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_fcall f_4397(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5767)
static void C_ccall f5767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4984)
static void C_ccall f_4984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4957)
static void C_fcall f_4957(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4928)
static void C_ccall f_4928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4930)
static void C_fcall f_4930(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4889)
static void C_ccall f_4889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4891)
static void C_fcall f_4891(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4920)
static void C_ccall f_4920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4850)
static void C_ccall f_4850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4852)
static void C_fcall f_4852(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4413)
static void C_ccall f_4413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4769)
static void C_ccall f_4769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4772)
static void C_ccall f_4772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4422)
static void C_ccall f_4422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4742)
static void C_ccall f_4742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4425)
static void C_ccall f_4425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4307)
static void C_ccall f_4307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4291)
static void C_ccall f_4291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4300)
static void C_ccall f_4300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4431)
static void C_fcall f_4431(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4436)
static void C_fcall f_4436(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4673)
static void C_fcall f_4673(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4686)
static void C_ccall f_4686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4596)
static void C_ccall f_4596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4550)
static void C_ccall f_4550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4530)
static void C_ccall f_4530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4461)
static void C_ccall f_4461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4312)
static void C_fcall f_4312(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4328)
static void C_fcall f_4328(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4351)
static void C_ccall f_4351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4338)
static void C_ccall f_4338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4227)
static void C_fcall f_4227(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4233)
static void C_fcall f_4233(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4241)
static void C_fcall f_4241(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4262)
static void C_ccall f_4262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4049)
static void C_fcall f_4049(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_fcall f_4055(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4077)
static void C_fcall f_4077(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4134)
static void C_ccall f_4134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4127)
static void C_ccall f_4127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4093)
static void C_ccall f_4093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4116)
static void C_ccall f_4116(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4166)
static C_word C_fcall f_4166(C_word t0);
C_noret_decl(f_3992)
static void C_fcall f_3992(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3998)
static void C_fcall f_3998(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4010)
static void C_fcall f_4010(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3937)
static void C_ccall f_3937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3942)
static void C_fcall f_3942(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3901)
static void C_fcall f_3901(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3718)
static void C_fcall f_3718(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3893)
static void C_ccall f_3893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3728)
static void C_ccall f_3728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_fcall f_3803(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3867)
static void C_ccall f_3867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3840)
static void C_fcall f_3840(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3850)
static void C_ccall f_3850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3737)
static void C_ccall f_3737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3752)
static void C_fcall f_3752(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3768)
static void C_ccall f_3768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3740)
static void C_ccall f_3740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3689)
static void C_fcall f_3689(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3525)
static void C_ccall f_3525(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3525)
static void C_ccall f_3525r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3638)
static void C_fcall f_3638(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3633)
static void C_fcall f_3633(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3527)
static void C_fcall f_3527(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3595)
static void C_fcall f_3595(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3530)
static void C_fcall f_3530(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3205)
static void C_ccall f_3205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3394)
static void C_fcall f_3394(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3416)
static void C_fcall f_3416(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3406)
static void C_ccall f_3406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3380)
static void C_fcall f_3380(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3281)
static void C_fcall f_3281(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3289)
static void C_fcall f_3289(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3293)
static void C_ccall f_3293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3302)
static void C_fcall f_3302(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3211)
static void C_ccall f_3211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3034)
static void C_fcall f_3034(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2909)
static void C_fcall f_2909(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2922)
static void C_ccall f_2922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2631)
static void C_fcall f_2631(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2663)
static void C_fcall f_2663(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_fcall f_2564(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2481)
static void C_fcall f_2481(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_fcall f_2489(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2498)
static void C_fcall f_2498(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_fcall f_2506(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2518)
static void C_ccall f_2518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2426)
static void C_ccall f_2426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2380)
static void C_ccall f_2380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2356)
static void C_fcall f_2356(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2364)
static void C_ccall f_2364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1793)
static void C_ccall f_1793(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1809)
static void C_fcall f_1809(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2152)
static void C_ccall f_2152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2114)
static void C_ccall f_2114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2095)
static void C_ccall f_2095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2101)
static void C_ccall f_2101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2079)
static void C_ccall f_2079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2041)
static void C_ccall f_2041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1959)
static void C_fcall f_1959(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1969)
static void C_ccall f_1969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1921)
static void C_ccall f_1921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1736)
static void C_ccall f_1736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1743)
static void C_ccall f_1743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_ccall f_1723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1667)
static void C_fcall f_1667(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1602)
static void C_ccall f_1602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_fcall f_1611(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_ccall f_1589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static C_word C_fcall f_1530(C_word t0,C_word t1);
C_noret_decl(f_1503)
static void C_fcall f_1503(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1513)
static void C_ccall f_1513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1466)
static void C_fcall f_1466(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1439)
static void C_ccall f_1439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1394)
static void C_ccall f_1394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1382)
static void C_ccall f_1382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1354)
static void C_ccall f_1354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1364)
static void C_ccall f_1364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2293)
static void C_fcall trf_2293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2293(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2293(t0,t1,t2,t3);}

C_noret_decl(trf_2207)
static void C_fcall trf_2207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2207(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2207(t0,t1,t2);}

C_noret_decl(trf_2217)
static void C_fcall trf_2217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2217(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2217(t0,t1);}

C_noret_decl(trf_4210)
static void C_fcall trf_4210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4210(t0,t1);}

C_noret_decl(trf_4216)
static void C_fcall trf_4216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4216(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4216(t0,t1);}

C_noret_decl(trf_4222)
static void C_fcall trf_4222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4222(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4222(t0,t1);}

C_noret_decl(trf_5051)
static void C_fcall trf_5051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5051(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5051(t0,t1,t2);}

C_noret_decl(trf_4382)
static void C_fcall trf_4382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4382(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4382(t0,t1);}

C_noret_decl(trf_4391)
static void C_fcall trf_4391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4391(t0,t1);}

C_noret_decl(trf_4397)
static void C_fcall trf_4397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4397(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4397(t0,t1);}

C_noret_decl(trf_4957)
static void C_fcall trf_4957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4957(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4957(t0,t1,t2);}

C_noret_decl(trf_4930)
static void C_fcall trf_4930(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4930(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4930(t0,t1,t2);}

C_noret_decl(trf_4891)
static void C_fcall trf_4891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4891(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4891(t0,t1,t2);}

C_noret_decl(trf_4852)
static void C_fcall trf_4852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4852(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4852(t0,t1,t2);}

C_noret_decl(trf_4431)
static void C_fcall trf_4431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4431(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4431(t0,t1);}

C_noret_decl(trf_4436)
static void C_fcall trf_4436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4436(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4436(t0,t1,t2);}

C_noret_decl(trf_4673)
static void C_fcall trf_4673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4673(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4673(t0,t1,t2);}

C_noret_decl(trf_4312)
static void C_fcall trf_4312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4312(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4312(t0,t1,t2);}

C_noret_decl(trf_4328)
static void C_fcall trf_4328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4328(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4328(t0,t1,t2);}

C_noret_decl(trf_4227)
static void C_fcall trf_4227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4227(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4227(t0,t1,t2);}

C_noret_decl(trf_4233)
static void C_fcall trf_4233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4233(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4233(t0,t1,t2);}

C_noret_decl(trf_4241)
static void C_fcall trf_4241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4241(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4241(t0,t1,t2);}

C_noret_decl(trf_4049)
static void C_fcall trf_4049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4049(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4049(t0,t1);}

C_noret_decl(trf_4055)
static void C_fcall trf_4055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4055(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4055(t0,t1,t2);}

C_noret_decl(trf_4077)
static void C_fcall trf_4077(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4077(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4077(t0,t1);}

C_noret_decl(trf_3992)
static void C_fcall trf_3992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3992(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3992(t0,t1,t2);}

C_noret_decl(trf_3998)
static void C_fcall trf_3998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3998(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3998(t0,t1,t2);}

C_noret_decl(trf_4010)
static void C_fcall trf_4010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4010(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4010(t0,t1,t2);}

C_noret_decl(trf_3942)
static void C_fcall trf_3942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3942(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3942(t0,t1,t2);}

C_noret_decl(trf_3901)
static void C_fcall trf_3901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3901(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3901(t0,t1,t2);}

C_noret_decl(trf_3718)
static void C_fcall trf_3718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3718(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3718(t0,t1,t2);}

C_noret_decl(trf_3803)
static void C_fcall trf_3803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3803(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3803(t0,t1,t2,t3);}

C_noret_decl(trf_3840)
static void C_fcall trf_3840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3840(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3840(t0,t1,t2);}

C_noret_decl(trf_3752)
static void C_fcall trf_3752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3752(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3752(t0,t1,t2,t3);}

C_noret_decl(trf_3689)
static void C_fcall trf_3689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3689(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3689(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3638)
static void C_fcall trf_3638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3638(t0,t1);}

C_noret_decl(trf_3633)
static void C_fcall trf_3633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3633(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3633(t0,t1,t2);}

C_noret_decl(trf_3527)
static void C_fcall trf_3527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3527(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3527(t0,t1,t2,t3);}

C_noret_decl(trf_3595)
static void C_fcall trf_3595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3595(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3595(t0,t1);}

C_noret_decl(trf_3530)
static void C_fcall trf_3530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3530(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3530(t0,t1,t2);}

C_noret_decl(trf_3394)
static void C_fcall trf_3394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3394(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3394(t0,t1,t2);}

C_noret_decl(trf_3416)
static void C_fcall trf_3416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3416(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3416(t0,t1,t2);}

C_noret_decl(trf_3380)
static void C_fcall trf_3380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3380(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3380(t0,t1,t2);}

C_noret_decl(trf_3281)
static void C_fcall trf_3281(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3281(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3281(t0,t1,t2);}

C_noret_decl(trf_3289)
static void C_fcall trf_3289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3289(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3289(t0,t1,t2);}

C_noret_decl(trf_3302)
static void C_fcall trf_3302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3302(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3302(t0,t1,t2);}

C_noret_decl(trf_3034)
static void C_fcall trf_3034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3034(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3034(t0,t1);}

C_noret_decl(trf_2909)
static void C_fcall trf_2909(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2909(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2909(t0,t1,t2);}

C_noret_decl(trf_2631)
static void C_fcall trf_2631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2631(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2631(t0,t1,t2);}

C_noret_decl(trf_2663)
static void C_fcall trf_2663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2663(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2663(t0,t1,t2,t3);}

C_noret_decl(trf_2564)
static void C_fcall trf_2564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2564(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2564(t0,t1,t2);}

C_noret_decl(trf_2481)
static void C_fcall trf_2481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2481(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2481(t0,t1,t2);}

C_noret_decl(trf_2489)
static void C_fcall trf_2489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2489(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2489(t0,t1,t2);}

C_noret_decl(trf_2498)
static void C_fcall trf_2498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2498(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2498(t0,t1,t2);}

C_noret_decl(trf_2506)
static void C_fcall trf_2506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2506(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2506(t0,t1,t2);}

C_noret_decl(trf_2356)
static void C_fcall trf_2356(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2356(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2356(t0,t1);}

C_noret_decl(trf_1809)
static void C_fcall trf_1809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1809(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1809(t0,t1);}

C_noret_decl(trf_1959)
static void C_fcall trf_1959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1959(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1959(t0,t1,t2);}

C_noret_decl(trf_1667)
static void C_fcall trf_1667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1667(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1667(t0,t1);}

C_noret_decl(trf_1611)
static void C_fcall trf_1611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1611(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1611(t0,t1,t2);}

C_noret_decl(trf_1503)
static void C_fcall trf_1503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1503(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1503(t0,t1);}

C_noret_decl(trf_1466)
static void C_fcall trf_1466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1466(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1466(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2479)){
C_save(t1);
C_rereclaim2(2479*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,361);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\006.csirc");
lf[4]=C_h_intern(&lf[4],27,"\003sysrepl-print-length-limit");
lf[5]=C_h_intern(&lf[5],4,"\000csi");
lf[6]=C_h_intern(&lf[6],12,"\003sysfeatures");
lf[7]=C_h_intern(&lf[7],19,"\003sysnotices-enabled");
lf[8]=C_h_intern(&lf[8],15,"\003csiprint-usage");
lf[9]=C_h_intern(&lf[9],7,"display");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\004V    -b  -batch                    terminate after command-line processing\012 "
"   -w  -no-warnings              disable all warnings\012    -K  -keyword-style STY"
"LE      enable alternative keyword-syntax\012                                   (pr"
"efix, suffix or none)\012        -no-parentheses-synonyms  disables list delimiter "
"synonyms\012        -no-symbol-escape         disables support for escaped symbols\012"
"        -r5rs-syntax              disables the Chicken extensions to\012           "
"                        R5RS syntax\012    -s  -script PATHNAME          use interp"
"reter for shell scripts\012        -ss PATHNAME              shell script with `mai"
"n\047 procedure\012        -sx PATHNAME              same as `-s\047, but print each expr"
"ession\012                                   as it is evaluated\012        -setup-mode"
"               prefer the current directory when locating extensions\012    -R  -re"
"quire-extension NAME   require extension and import before\012                     "
"              executing code\012    -I  -include-path PATHNAME    add PATHNAME to i"
"nclude path\012    --                            ignore all following options\012");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\003 \047\012");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000D    -n  -no-init                  do not load initialization file ` ");
lf[13]=C_h_intern(&lf[13],19,"\003sysprint-to-string");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\002\344usage: csi [FILENAME | OPTION ...]\012\012  `csi\047 is the CHICKEN interpreter.\012  \012"
"  FILENAME is a Scheme source file name with optional extension. OPTION may be\012 "
" one of the following:\012\012    -h  -help  --help             display this text and "
"exit\012    -v  -version                  display version and exit\012        -release"
"                  print release number and exit\012    -i  -case-insensitive       "
"  enable case-insensitive reading\012    -e  -eval EXPRESSION          evaluate giv"
"en expression\012    -p  -print EXPRESSION         evaluate and print result(s)\012   "
" -P  -pretty-print EXPRESSION  evaluate and print result(s) prettily\012    -D  -fe"
"ature SYMBOL           register feature identifier\012    -q  -quiet               "
"     do not print banner\012");
lf[15]=C_h_intern(&lf[15],16,"\003csiprint-banner");
lf[16]=C_h_intern(&lf[16],5,"print");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\077(c)2008-2010 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[19]=C_h_intern(&lf[19],15,"chicken-version");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\007CHICKEN");
lf[21]=C_h_intern(&lf[21],7,"newline");
lf[22]=C_h_intern(&lf[22],9,"read-char");
lf[23]=C_h_intern(&lf[23],4,"read");
lf[24]=C_h_intern(&lf[24],18,"\003sysuser-read-hook");
lf[25]=C_h_intern(&lf[25],5,"quote");
lf[26]=C_h_intern(&lf[26],17,"\003csihistory-count");
lf[27]=C_h_intern(&lf[27],15,"\003csihistory-ref");
lf[28]=C_h_intern(&lf[28],21,"\003syssharp-number-hook");
lf[30]=C_h_intern(&lf[30],9,"substring");
lf[31]=C_h_intern(&lf[31],18,"\003csichop-separator");
lf[32]=C_h_intern(&lf[32],1,"@");
lf[33]=C_h_intern(&lf[33],12,"file-exists\077");
lf[34]=C_h_intern(&lf[34],13,"string-append");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\004.bat");
lf[36]=C_h_intern(&lf[36],22,"\003csilookup-script-file");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[38]=C_h_intern(&lf[38],25,"\003syspeek-nonnull-c-string");
lf[39]=C_h_intern(&lf[39],12,"string-split");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[42]=C_h_intern(&lf[42],24,"get-environment-variable");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\004PATH");
lf[44]=C_h_intern(&lf[44],16,"\003csihistory-list");
lf[45]=C_h_intern(&lf[45],13,"vector-resize");
lf[46]=C_h_intern(&lf[46],15,"\003csihistory-add");
lf[47]=C_h_intern(&lf[47],19,"\003sysundefined-value");
lf[48]=C_h_intern(&lf[48],9,"\003syserror");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000 history entry index out of range");
lf[50]=C_h_intern(&lf[50],14,"\003csitty-input\077");
lf[51]=C_h_intern(&lf[51],13,"\003systty-port\077");
lf[52]=C_h_intern(&lf[52],18,"\003sysstandard-input");
lf[53]=C_h_intern(&lf[53],18,"\003sysbreak-on-error");
lf[54]=C_h_intern(&lf[54],20,"\003sysread-prompt-hook");
lf[56]=C_h_intern(&lf[56],16,"toplevel-command");
lf[57]=C_h_intern(&lf[57],19,"\003syshash-table-set!");
lf[58]=C_h_intern(&lf[58],4,"eval");
lf[59]=C_h_intern(&lf[59],12,"load-noisily");
lf[60]=C_h_intern(&lf[60],9,"read-line");
lf[61]=C_h_intern(&lf[61],6,"length");
lf[62]=C_h_intern(&lf[62],5,"write");
lf[63]=C_h_intern(&lf[63],6,"printf");
lf[64]=C_h_intern(&lf[64],6,"expand");
lf[65]=C_h_intern(&lf[65],12,"pretty-print");
lf[66]=C_h_intern(&lf[66],8,"integer\077");
lf[67]=C_h_intern(&lf[67],6,"values");
lf[68]=C_h_intern(&lf[68],18,"\003sysrepl-eval-hook");
lf[69]=C_h_intern(&lf[69],4,"exit");
lf[70]=C_h_intern(&lf[70],1,"x");
lf[71]=C_h_intern(&lf[71],16,"\003sysstrip-syntax");
lf[72]=C_h_intern(&lf[72],1,"p");
lf[73]=C_h_intern(&lf[73],1,"d");
lf[74]=C_h_intern(&lf[74],12,"\003csidescribe");
lf[75]=C_h_intern(&lf[75],2,"du");
lf[76]=C_h_intern(&lf[76],8,"\003csidump");
lf[77]=C_h_intern(&lf[77],3,"dur");
lf[78]=C_h_intern(&lf[78],1,"r");
lf[79]=C_h_intern(&lf[79],10,"\003csireport");
lf[80]=C_h_intern(&lf[80],1,"q");
lf[81]=C_h_intern(&lf[81],1,"l");
lf[82]=C_h_intern(&lf[82],4,"load");
lf[83]=C_h_intern(&lf[83],2,"ln");
lf[84]=C_h_intern(&lf[84],6,"print*");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\004==> ");
lf[86]=C_h_intern(&lf[86],8,"\000printer");
lf[87]=C_h_intern(&lf[87],12,"\003sysfor-each");
lf[88]=C_h_intern(&lf[88],1,"t");
lf[89]=C_h_intern(&lf[89],17,"\003sysdisplay-times");
lf[90]=C_h_intern(&lf[90],14,"\003sysstop-timer");
lf[91]=C_h_intern(&lf[91],15,"\003sysstart-timer");
lf[92]=C_h_intern(&lf[92],3,"exn");
lf[93]=C_h_intern(&lf[93],18,"\003syslast-exception");
lf[94]=C_h_intern(&lf[94],1,"s");
lf[95]=C_h_intern(&lf[95],6,"system");
lf[96]=C_h_intern(&lf[96],1,"\077");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\002 ,");
lf[98]=C_h_intern(&lf[98],23,"\003syshash-table-for-each");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\002\220Toplevel commands:\012\012 ,\077                Show this text\012 ,p EXP            Pr"
"etty print evaluated expression EXP\012 ,d EXP            Describe result of evalua"
"ted expression EXP\012 ,du EXP           Dump data of expression EXP\012 ,dur EXP N   "
"     Dump range\012 ,q                Quit interpreter\012 ,l FILENAME ...   Load one "
"or more files\012 ,ln FILENAME ...  Load one or more files and print result of each"
" top-level expression\012 ,r                Show system information\012 ,s TEXT ...   "
"    Execute shell-command\012 ,exn              Describe last exception\012 ,t EXP    "
"        Evaluate form and print elapsed time\012 ,x EXP            Pretty print exp"
"anded expression EXP\012");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\0005Undefined toplevel command ~s - enter `,\077\047 for help~%");
lf[101]=C_h_intern(&lf[101],18,"\003syshash-table-ref");
lf[102]=C_h_intern(&lf[102],7,"unquote");
lf[103]=C_h_intern(&lf[103],4,"chop");
lf[104]=C_h_intern(&lf[104],4,"sort");
lf[105]=C_h_intern(&lf[105],19,"with-output-to-port");
lf[106]=C_h_intern(&lf[106],19,"current-output-port");
lf[107]=C_h_intern(&lf[107],8,"truncate");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol gc is enabled\012");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\027interrupts are enabled\012");
lf[110]=C_h_intern(&lf[110],16,"\003syswrite-char-0");
lf[111]=C_h_intern(&lf[111],19,"\003sysstandard-output");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\010(64-bit)");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\010 (fixed)");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\010downward");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\006upward");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\002\134~%~%~\012                   Machine type:    \011~A ~A~%~\012                   Soft"
"ware type:   \011~A~%~\012                   Software version:\011~A~%~\012                 "
"  Build platform:  \011~A~%~\012                   Installation prefix:\011~A~%~\012        "
"           Extension path:  \011~A~%~\012                   Include path:    \011~A~%~\012  "
"                 Symbol-table load:\011~S~%  ~\012                     Avg bucket leng"
"th:\011~S~%  ~\012                     Total symbol count:\011~S~%~\012                   Me"
"mory:\011heap size is ~S bytes~A with ~S bytes currently in use~%~  \012              "
"       nursery size is ~S bytes, stack grows ~A~%");
lf[119]=C_h_intern(&lf[119],21,"\003sysinclude-pathnames");
lf[120]=C_h_intern(&lf[120],15,"repository-path");
lf[121]=C_h_intern(&lf[121],14,"build-platform");
lf[122]=C_h_intern(&lf[122],16,"software-version");
lf[123]=C_h_intern(&lf[123],13,"software-type");
lf[124]=C_h_intern(&lf[124],12,"machine-type");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[126]=C_h_intern(&lf[126],11,"make-string");
lf[127]=C_h_intern(&lf[127],5,"fxmax");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[129]=C_h_intern(&lf[129],8,"string<\077");
lf[130]=C_h_intern(&lf[130],15,"keyword->string");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\012Features:\012");
lf[132]=C_h_intern(&lf[132],17,"memory-statistics");
lf[133]=C_h_intern(&lf[133],21,"\003syssymbol-table-info");
lf[134]=C_h_intern(&lf[134],2,"gc");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376B\000\000\030vector of unsigned bytes\376\003\000\000\002\376\001\000\000\017u8vector-leng"
"th\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376B\000\000\026vector of signed byt"
"es\376\003\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\014s8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000"
"\002\376B\000\000\037vector of unsigned 16-bit words\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\015u16vect"
"or-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376B\000\000\035vector of signed 16-bit words\376\003\000\000\002\376\001\000"
"\000\020s16vector-length\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376B\000\000\037ve"
"ctor of unsigned 32-bit words\376\003\000\000\002\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\015u32vector-ref\376\377"
"\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376B\000\000\035vector of signed 32-bit words\376\003\000\000\002\376\001\000\000\020s32vec"
"tor-length\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376B\000\000\027vector of "
"32-bit floats\376\003\000\000\002\376\001\000\000\020f32vector-length\376\003\000\000\002\376\001\000\000\015f32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"f64vector\376\003\000\000\002\376B\000\000\027vector of 64-bit floats\376\003\000\000\002\376\001\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\015f6"
"4vector-ref\376\377\016\376\377\016");
lf[138]=C_h_intern(&lf[138],7,"sprintf");
lf[139]=C_h_intern(&lf[139],7,"fprintf");
lf[140]=C_h_intern(&lf[140],8,"list-ref");
lf[141]=C_h_intern(&lf[141],10,"string-ref");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000 ~% (~A elements not displayed)~%");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000.\011(followed by ~A identical instance~a)~% ...~%");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\007 ~S: ~S");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\021~A of length ~S~%");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000$character ~S, code: ~S, #x~X, #o~O~%");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\016boolean true~%");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\017boolean false~%");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\014empty list~%");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\024end-of-file object~%");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\024unspecified object~%");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\016, character ~S");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\042exact integer ~S, #x~X, #o~O, #b~B");
lf[156]=C_h_intern(&lf[156],28,"\003sysarbitrary-unbound-symbol");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\017unbound value~%");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\023inexact number ~S~%");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\013number ~S~%");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\006string");
lf[161]=C_h_intern(&lf[161],8,"\003syssize");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\006vector");
lf[163]=C_h_intern(&lf[163],8,"\003sysslot");
lf[164]=C_h_intern(&lf[164],27,"\003syswith-print-length-limit");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\005  ~s\011");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\020  \012properties:\012\012");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\013uninterned ");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\012qualified ");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\031~a~asymbol with name ~S~%");
lf[172]=C_h_intern(&lf[172],28,"\003syssymbol->qualified-string");
lf[173]=C_h_intern(&lf[173],18,"\003syssymbol->string");
lf[174]=C_h_intern(&lf[174],20,"\003sysinterned-symbol\077");
lf[175]=C_h_intern(&lf[175],21,"\003sysqualified-symbol\077");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\010keyword ");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\010unbound ");
lf[178]=C_h_intern(&lf[178],32,"\003syssymbol-has-toplevel-binding\077");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\004list");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\035pair with car ~S and cdr ~S~%");
lf[181]=C_h_intern(&lf[181],15,"describe-object");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\036procedure with code pointer ~X");
lf[183]=C_h_intern(&lf[183],25,"\003syspeek-unsigned-integer");
lf[184]=C_h_intern(&lf[184],9,"\000tinyclos");
lf[185]=C_h_intern(&lf[185],19,"\010tinyclosentity-tag");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\005input");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\006output");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\0005~A port of type ~A with name ~S and file pointer ~X~%");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000/locative~%  pointer ~X~%  index ~A~%  type ~A~%");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\004slot");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\010u8vector");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\010s8vector");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\011u16vector");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\011s16vector");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\011u32vector");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\011s32vector");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\011f32vector");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\011f64vector");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\024machine pointer ~X~%");
lf[201]=C_h_intern(&lf[201],11,"\003csihexdump");
lf[202]=C_h_intern(&lf[202],8,"\003sysbyte");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\022blob of size ~S:~%");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\030lambda information: ~s~%");
lf[205]=C_h_intern(&lf[205],23,"\003syslambda-info->string");
lf[206]=C_h_intern(&lf[206],10,"hash-table");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\013 ~S\011-> ~S~%");
lf[208]=C_h_intern(&lf[208],15,"hash-table-walk");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\025  hash function: ~a~%");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000:hash-table with ~S element~a~%  comparison procedure: ~A~%");
lf[213]=C_h_intern(&lf[213],9,"condition");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\011\011~s: ~s~%");
lf[215]=C_h_intern(&lf[215],4,"cdar");
lf[216]=C_h_intern(&lf[216],4,"caar");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\005 ~s~%");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\017condition: ~s~%");
lf[219]=C_h_intern(&lf[219],6,"unveil");
lf[220]=C_h_intern(&lf[220],6,"append");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\031structure of type `~S\047:~%");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\020unknown object~%");
lf[223]=C_h_intern(&lf[223],15,"meroon-instance");
lf[224]=C_h_intern(&lf[224],9,"provided\077");
lf[225]=C_h_intern(&lf[225],6,"meroon");
lf[226]=C_h_intern(&lf[226],15,"\003sysbytevector\077");
lf[227]=C_h_intern(&lf[227],13,"\003syslocative\077");
lf[228]=C_h_intern(&lf[228],9,"instance\077");
lf[229]=C_h_intern(&lf[229],5,"port\077");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\034statically allocated (0x~X) ");
lf[231]=C_h_intern(&lf[231],17,"\003sysblock-address");
lf[232]=C_h_intern(&lf[232],14,"set-describer!");
lf[233]=C_h_intern(&lf[233],16,"\003syscheck-symbol");
lf[234]=C_h_intern(&lf[234],6,"symbol");
lf[235]=C_h_intern(&lf[235],3,"min");
lf[236]=C_h_intern(&lf[236],4,"dump");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot dump immediate object");
lf[238]=C_h_intern(&lf[238],13,"\003syspeek-byte");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot dump object");
lf[240]=C_h_intern(&lf[240],10,"write-char");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[242]=C_h_intern(&lf[242],5,"fxmod");
lf[243]=C_h_intern(&lf[243],7,"\003csidel");
lf[244]=C_h_intern(&lf[244],11,"\003csideldups");
lf[245]=C_h_intern(&lf[245],6,"equal\077");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\007-script");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[253]=C_h_intern(&lf[253],6,"string");
lf[254]=C_h_intern(&lf[254],7,"\003sysmap");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[256]=C_h_intern(&lf[256],16,"\003sysstring->list");
lf[257]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\010-version\376\003\000\000\002\376B\000\000\005-help\376\003\000\000"
"\002\376B\000\000\006--help\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\021-case-insensitive\376\003\000\000\002\376B\000"
"\000\016-keyword-style\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\003\000"
"\000\002\376B\000\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\013-setup-mode\376\003\000\000\002\376B\000\000\022-require-extension\376\003\000\000\002\376B\000\000\006-b"
"atch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\015-include-p"
"ath\376\003\000\000\002\376B\000\000\010-release\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pretty-print\376\003\000\000\002\376B\000\000\002--\376\377\016");
lf[258]=C_h_intern(&lf[258],7,"\003csirun");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\047missing argument to command-line option");
lf[260]=C_h_intern(&lf[260],8,"\003syslist");
lf[261]=C_h_intern(&lf[261],17,"open-input-string");
lf[262]=C_h_intern(&lf[262],4,"repl");
lf[263]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\002-n"
"\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-"
"insensitive\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\003\000\000\002\376B\000"
"\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\013-setup-mode\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B"
"\000\000\007-script\376\377\016");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\002-K");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\016-keyword-style");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\002-R");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[272]=C_h_intern(&lf[272],22,"\004corerequire-extension");
lf[273]=C_h_intern(&lf[273],14,"string->symbol");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\002-e");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\005-eval");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\006-print");
lf[278]=C_h_intern(&lf[278],8,"for-each");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\002-P");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\015-pretty-print");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[282]=C_h_intern(&lf[282],4,"main");
lf[283]=C_h_intern(&lf[283],22,"command-line-arguments");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[285]=C_h_intern(&lf[285],18,"\003sysstandard-error");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\002; ");
lf[287]=C_h_intern(&lf[287],19,"\003syswrite-char/port");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\003\012; ");
lf[289]=C_h_intern(&lf[289],12,"flush-output");
lf[290]=C_h_intern(&lf[290],21,"with-output-to-string");
lf[291]=C_h_intern(&lf[291],8,"\003sysload");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[295]=C_h_intern(&lf[295],17,"\003sysstring-append");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[297]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\010-no-init\376\377\016");
lf[298]=C_h_intern(&lf[298],13,"symbol-escape");
lf[299]=C_h_intern(&lf[299],20,"parentheses-synonyms");
lf[300]=C_h_intern(&lf[300],13,"keyword-style");
lf[301]=C_h_intern(&lf[301],5,"\000none");
lf[302]=C_h_intern(&lf[302],14,"case-sensitive");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000/Disabled the Chicken extensions to R5RS syntax\012");
lf[304]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000%Disabled support for escaped symbols\012");
lf[306]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\377\016");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000*Disabled support for parentheses synonyms\012");
lf[308]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\377\016");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[310]=C_h_intern(&lf[310],7,"\000prefix");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[313]=C_h_intern(&lf[313],7,"\000suffix");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000+missing argument to `-keyword-style\047 option");
lf[315]=C_h_intern(&lf[315],8,"string=\077");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[318]=C_h_intern(&lf[318],17,"register-feature!");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[321]=C_h_intern(&lf[321],16,"case-insensitive");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000-Identifiers and symbols are case insensitive\012");
lf[323]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016");
lf[324]=C_h_intern(&lf[324],12,"load-verbose");
lf[325]=C_h_intern(&lf[325],20,"\003syswarnings-enabled");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\026Warnings are disabled\012");
lf[327]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\377\016");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\013-setup-mode");
lf[330]=C_h_intern(&lf[330],14,"\003syssetup-mode");
lf[331]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-v\376\003\000\000\002\376B\000\000\010-version\376\377\016");
lf[332]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376B\000\000\006--help\376\377\016");
lf[333]=C_h_intern(&lf[333],20,"\003syseval-debug-level");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[337]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[338]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\377\016");
lf[339]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-e\376\003\000\000\002\376B\000\000\002-p\376\003\000\000\002\376B\000\000\002-P\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pr"
"etty-print\376\377\016");
lf[340]=C_h_intern(&lf[340],20,"\003syswindows-platform");
lf[341]=C_h_intern(&lf[341],6,"script");
lf[342]=C_h_intern(&lf[342],12,"program-name");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\042missing or invalid script argument");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[345]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\007-script\376\377\016");
lf[346]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-K\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[348]=C_h_intern(&lf[348],17,"get-output-string");
lf[349]=C_h_intern(&lf[349],18,"open-output-string");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid option syntax");
lf[351]=C_h_intern(&lf[351],7,"reverse");
lf[352]=C_h_intern(&lf[352],22,"with-exception-handler");
lf[353]=C_h_intern(&lf[353],30,"call-with-current-continuation");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\013CSI_OPTIONS");
lf[355]=C_h_intern(&lf[355],25,"\003sysimplicit-exit-handler");
lf[356]=C_h_intern(&lf[356],11,"make-vector");
lf[357]=C_h_intern(&lf[357],17,"\003syspeek-c-string");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\006#;~A> ");
lf[360]=C_h_intern(&lf[360],11,"repl-prompt");
C_register_lf2(lf,361,create_ptable());
t2=C_mutate(&lf[0] /* (set! c172 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1324,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1322 */
static void C_ccall f_1324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1325 in k1322 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1328 in k1325 in k1322 */
static void C_ccall f_1330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1339,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1339,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! constant23 ...) */,lf[3]);
t3=C_set_block_item(lf[4] /* repl-print-length-limit */,0,C_fix(2048));
t4=C_a_i_cons(&a,2,lf[5],C_retrieve(lf[6]));
t5=C_mutate((C_word*)lf[6]+1 /* (set! ##sys#features ...) */,t4);
t6=C_set_block_item(lf[7] /* notices-enabled */,0,C_SCHEME_TRUE);
t7=C_mutate((C_word*)lf[8]+1 /* (set! ##csi#print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1350,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[15]+1 /* (set! ##csi#print-banner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1378,tmp=(C_word)a,a+=2,tmp));
t9=*((C_word*)lf[22]+1);
t10=*((C_word*)lf[23]+1);
t11=C_retrieve(lf[24]);
t12=C_mutate((C_word*)lf[24]+1 /* (set! ##sys#user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1394,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[28]+1 /* (set! ##sys#sharp-number-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1427,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[29] /* (set! dirseparator? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1441,tmp=(C_word)a,a+=2,tmp));
t15=*((C_word*)lf[30]+1);
t16=C_mutate((C_word*)lf[31]+1 /* (set! ##csi#chop-separator ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1453,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=C_set_block_item(lf[32] /* @ */,0,C_SCHEME_FALSE);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1484,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 179  make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t18,C_fix(256));}

/* k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1503,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[36]+1 /* (set! ##csi#lookup-script-file ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1551,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t4=C_SCHEME_UNDEFINED;
t5=C_a_i_vector(&a,32,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4);
t6=C_mutate((C_word*)lf[44]+1 /* (set! ##csi#history-list ...) */,t5);
t7=C_set_block_item(lf[26] /* history-count */,0,C_fix(1));
t8=C_retrieve(lf[45]);
t9=C_mutate((C_word*)lf[46]+1 /* (set! ##csi#history-add ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1657,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[27]+1 /* (set! ##csi#history-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1696,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1721,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=*((C_word*)lf[138]+1);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5231,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 231  repl-prompt */
((C_proc3)C_retrieve_symbol_proc(lf[360]))(3,*((C_word*)lf[360]+1),t11,t13);}

/* a5230 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5231,2,t0,t1);}
/* csi.scm: 234  sprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[359],C_retrieve(lf[26]));}

/* k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1721,2,t0,t1);}
t2=C_mutate((C_word*)lf[50]+1 /* (set! ##csi#tty-input? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1723,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[53] /* break-on-error */,0,C_SCHEME_FALSE);
t4=C_retrieve(lf[54]);
t5=C_mutate((C_word*)lf[54]+1 /* (set! ##sys#read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1736,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1750,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 246  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[356]+1)))(4,*((C_word*)lf[356]+1),t6,C_fix(37),C_SCHEME_END_OF_LIST);}

/* k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1750,2,t0,t1);}
t2=C_mutate(&lf[55] /* (set! command-table ...) */,t1);
t3=C_mutate((C_word*)lf[56]+1 /* (set! toplevel-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1752,tmp=(C_word)a,a+=2,tmp));
t4=C_retrieve(lf[58]);
t5=C_retrieve(lf[59]);
t6=*((C_word*)lf[23]+1);
t7=C_retrieve(lf[60]);
t8=*((C_word*)lf[61]+1);
t9=*((C_word*)lf[9]+1);
t10=*((C_word*)lf[62]+1);
t11=C_retrieve(lf[39]);
t12=*((C_word*)lf[63]+1);
t13=C_retrieve(lf[64]);
t14=C_retrieve(lf[65]);
t15=*((C_word*)lf[66]+1);
t16=*((C_word*)lf[67]+1);
t17=C_mutate((C_word*)lf[68]+1 /* (set! ##sys#repl-eval-hook ...) */,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1793,a[2]=t12,a[3]=t9,a[4]=t16,a[5]=t5,a[6]=t7,a[7]=t11,a[8]=t4,a[9]=t6,a[10]=t13,a[11]=t14,tmp=(C_word)a,a+=12,tmp));
t18=*((C_word*)lf[63]+1);
t19=C_retrieve(lf[103]);
t20=C_retrieve(lf[104]);
t21=C_retrieve(lf[105]);
t22=*((C_word*)lf[106]+1);
t23=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2330,a[2]=((C_word*)t0)[2],a[3]=t22,a[4]=t21,a[5]=t20,a[6]=t19,a[7]=t18,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 387  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[42]))(3,*((C_word*)lf[42]+1),t23,lf[358]);}

/* k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_2333(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[357]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_PREFIX),C_fix(0));}}

/* k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2333,2,t0,t1);}
t2=C_mutate((C_word*)lf[79]+1 /* (set! ##csi#report ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2334,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t3=C_mutate(&lf[135] /* (set! ##csi#bytevector-data ...) */,lf[136]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 454  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[356]+1)))(4,*((C_word*)lf[356]+1),t4,C_fix(37),C_SCHEME_END_OF_LIST);}

/* k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2611,2,t0,t1);}
t2=C_mutate(&lf[137] /* (set! describer-table ...) */,t1);
t3=*((C_word*)lf[138]+1);
t4=*((C_word*)lf[63]+1);
t5=C_retrieve(lf[139]);
t6=*((C_word*)lf[61]+1);
t7=*((C_word*)lf[140]+1);
t8=*((C_word*)lf[141]+1);
t9=C_mutate((C_word*)lf[74]+1 /* (set! ##csi#describe ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2613,a[2]=t3,a[3]=t7,a[4]=t6,a[5]=t8,a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t10=C_mutate((C_word*)lf[232]+1 /* (set! set-describer! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3516,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[76]+1 /* (set! ##csi#dump ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3525,tmp=(C_word)a,a+=2,tmp));
t12=*((C_word*)lf[9]+1);
t13=*((C_word*)lf[34]+1);
t14=*((C_word*)lf[126]+1);
t15=*((C_word*)lf[240]+1);
t16=C_mutate((C_word*)lf[201]+1 /* (set! ##csi#hexdump ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3686,a[2]=t12,a[3]=t15,a[4]=t14,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t17=C_mutate((C_word*)lf[243]+1 /* (set! ##csi#del ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3895,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[244]+1 /* (set! ##csi#deldups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3933,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[246] /* (set! member* ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3992,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[247] /* (set! canonicalize-args ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4049,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[258]+1 /* (set! ##csi#run ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4194,tmp=(C_word)a,a+=2,tmp));
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5220,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 888  run */
((C_proc2)C_retrieve_symbol_proc(lf[258]))(2,*((C_word*)lf[258]+1),t22);}

/* k5218 in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5223,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5226,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[355]))(2,*((C_word*)lf[355]+1),t3);}

/* k5224 in k5218 in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5221 in k5218 in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4198,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5214,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 737  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[42]))(3,*((C_word*)lf[42]+1),t3,lf[354]);}

/* k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5214,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[347]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2195,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 365  open-input-string */
((C_proc3)C_retrieve_symbol_proc(lf[261]))(3,*((C_word*)lf[261]+1),t3,t2);}

/* k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2195,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2202,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2259,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[353]+1)))(3,*((C_word*)lf[353]+1),t6,t7);}

/* a2258 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2259(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2259,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2265,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2277,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[352]))(4,*((C_word*)lf[352]+1),t1,t3,t4);}

/* a2276 in a2258 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2283,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2316,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2315 in a2276 in a2258 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2316r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2316r(t0,t1,t2);}}

static void C_ccall f_2316r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2322,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k337342 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2321 in a2315 in a2276 in a2258 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2322,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2282 in a2276 in a2258 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2291,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 373  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[23]+1)))(3,*((C_word*)lf[23]+1),t2,((C_word*)t0)[2]);}

/* k2289 in a2282 in a2276 in a2258 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2291,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2293,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2293(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* doloop344 in k2289 in a2282 in a2276 in a2258 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_2293(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2293,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eofp(t2))){
/* csi.scm: 375  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[351]+1)))(3,*((C_word*)lf[351]+1),t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2310,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 373  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[23]+1)))(3,*((C_word*)lf[23]+1),t4,((C_word*)t0)[2]);}}

/* k2308 in doloop344 in k2289 in a2282 in a2276 in a2258 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2310,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2293(t3,((C_word*)t0)[2],t1,t2);}

/* a2264 in a2258 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2265,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2271,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* k337342 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2270 in a2264 in a2258 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2271,2,t0,t1);}
/* csi.scm: 372  ##sys#error */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[350],((C_word*)t0)[2]);}

/* k2200 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g340341 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2203 in k2200 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2205,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2207,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2207(t5,((C_word*)t0)[2],t1);}

/* loop313 in k2203 in k2200 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_2207(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2207,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2217,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2253,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_slot(t2,C_fix(0));
if(C_truep(C_i_stringp(t5))){
t6=t3;
f_2217(t6,C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST));}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2244,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 369  open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[349]))(2,*((C_word*)lf[349]+1),t6);}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2242 in loop313 in k2203 in k2200 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2247,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 370  write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[62]+1)))(4,*((C_word*)lf[62]+1),t2,((C_word*)t0)[2],t1);}

/* k2245 in k2242 in loop313 in k2203 in k2200 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 371  get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[348]))(3,*((C_word*)lf[348]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2251 in loop313 in k2203 in k2200 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2253,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2217(t2,C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST));}

/* k2215 in loop313 in k2203 in k2200 in k2193 in k5212 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_2217(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop313326 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2207(t5,((C_word*)t0)[3],t4);}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop313326 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2207(t5,((C_word*)t0)[3],t4);}}

/* k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4201,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5210,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 738  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[283]))(2,*((C_word*)lf[283]+1),t3);}

/* k5208 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 738  canonicalize-args */
f_4049(((C_word*)t0)[2],t1);}

/* k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4201,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 740  member* */
f_3992(t4,lf[346],((C_word*)t3)[1]);}

/* k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4207,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 741  member* */
f_3992(t2,lf[345],((C_word*)((C_word*)t0)[4])[1]);}

/* k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4210,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5103,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(t1);
t5=C_i_pairp(t4);
t6=C_i_not(t5);
if(C_truep(t6)){
if(C_truep(t6)){
/* csi.scm: 746  ##sys#error */
t7=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t3,lf[343]);}
else{
t7=t3;
f_5103(2,t7,C_SCHEME_UNDEFINED);}}
else{
t7=C_i_cadr(t1);
t8=C_i_string_length(t7);
t9=C_i_zerop(t8);
if(C_truep(t9)){
if(C_truep(t9)){
/* csi.scm: 746  ##sys#error */
t10=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t3,lf[343]);}
else{
t10=t3;
f_5103(2,t10,C_SCHEME_UNDEFINED);}}
else{
t10=C_i_cadr(t1);
t11=C_i_string_ref(t10,C_fix(0));
t12=C_eqp(C_make_character(45),t11);
if(C_truep(t12)){
/* csi.scm: 746  ##sys#error */
t13=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t3,lf[343]);}
else{
t13=t3;
f_5103(2,t13,C_SCHEME_UNDEFINED);}}}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5193,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5206,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 755  canonicalize-args */
f_4049(t4,((C_word*)t0)[2]);}}

/* k5204 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 755  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[220]+1)))(4,*((C_word*)lf[220]+1),((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5191 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=C_i_member(lf[344],((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
f_4210(t4,(C_truep(t3)?C_i_set_cdr(t3,C_SCHEME_END_OF_LIST):C_SCHEME_FALSE));}

/* k5101 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 747  program-name */
((C_proc3)C_retrieve_symbol_proc(lf[342]))(3,*((C_word*)lf[342]+1),t2,t3);}

/* k5104 in k5101 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cddr(((C_word*)t0)[3]);
/* csi.scm: 748  command-line-arguments */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t2,t3);}

/* k5107 in k5104 in k5101 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 749  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[318]))(3,*((C_word*)lf[318]+1),t2,lf[341]);}

/* k5110 in k5107 in k5104 in k5101 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5112,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[3]);
t3=C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[340]+1))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 752  lookup-script-file */
((C_proc3)C_retrieve_symbol_proc(lf[36]))(3,*((C_word*)lf[36]+1),t4,t5);}
else{
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];
f_4210(t5,t4);}}

/* k5119 in k5110 in k5107 in k5104 in k5101 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4210(t3,C_i_set_car(t2,t1));}
else{
t2=((C_word*)t0)[2];
f_4210(t2,C_SCHEME_FALSE);}}

/* k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4210,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 758  member* */
f_3992(t2,lf[339],((C_word*)((C_word*)t0)[5])[1]);}

/* k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4216,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_4216(t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5097,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 759  member* */
f_3992(t3,lf[338],((C_word*)((C_word*)t0)[5])[1]);}}

/* k5095 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_4216(t3,t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
f_4216(t3,t2);}}

/* k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4216(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4216,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4219,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 760  member* */
f_3992(t2,lf[337],((C_word*)((C_word*)t0)[6])[1]);}

/* k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4222,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_4222(t3,((C_word*)t0)[5]);}
else{
if(C_truep(t1)){
t3=t1;
t4=t2;
f_4222(t4,t3);}
else{
t3=((C_word*)t0)[2];
t4=t2;
f_4222(t4,t3);}}}

/* k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4222(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4222,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5049,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5088,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 762  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[42]))(3,*((C_word*)lf[42]+1),t8,lf[336]);}

/* k5086 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* csi.scm: 762  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[39]))(4,*((C_word*)lf[39]+1),((C_word*)t0)[2],t2,lf[334]);}
else{
/* csi.scm: 762  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[39]))(4,*((C_word*)lf[39]+1),((C_word*)t0)[2],lf[335],lf[334]);}}

/* k5047 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5049,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5051,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5051(t5,((C_word*)t0)[2],t1);}

/* loop925 in k5047 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_5051(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5051,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[31]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5080,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g941942 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5078 in loop925 in k5047 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5080,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop925938 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5051(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop925938 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5051(t6,((C_word*)t0)[3],t5);}}

/* k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4225,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4227,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4312,tmp=(C_word)a,a+=2,tmp));
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4382,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t5,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t9=C_set_block_item(lf[333] /* eval-debug-level */,0,C_fix(0));
t10=t8;
f_4382(t10,t9);}
else{
t9=t8;
f_4382(t9,C_SCHEME_UNDEFINED);}}

/* k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4382(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4382,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5038,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 786  member* */
f_3992(t3,lf[332],((C_word*)((C_word*)t0)[6])[1]);}

/* k5036 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5038,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5041,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 787  print-usage */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_4385(2,t2,C_SCHEME_UNDEFINED);}}

/* k5039 in k5036 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 788  exit */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],C_fix(0));}

/* k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5029,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 789  member* */
f_3992(t3,lf[331],((C_word*)((C_word*)t0)[6])[1]);}

/* k5027 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5029,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5032,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 790  print-banner */
((C_proc2)C_retrieve_symbol_proc(lf[15]))(2,*((C_word*)lf[15]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_4388(2,t2,C_SCHEME_UNDEFINED);}}

/* k5030 in k5027 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 791  exit */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],C_fix(0));}

/* k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_member(lf[329],((C_word*)((C_word*)t0)[6])[1]))){
t3=C_set_block_item(lf[330] /* setup-mode */,0,C_SCHEME_TRUE);
t4=t2;
f_4391(t4,t3);}
else{
t3=t2;
f_4391(t3,C_SCHEME_UNDEFINED);}}

/* k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4391,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4394,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_member(lf[328],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5015,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5022,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 795  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[19]))(2,*((C_word*)lf[19]+1),t4);}
else{
t3=t2;
f_4394(2,t3,C_SCHEME_UNDEFINED);}}

/* k5020 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 795  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[16]+1)))(3,*((C_word*)lf[16]+1),((C_word*)t0)[2],t1);}

/* k5013 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 796  exit */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],C_fix(0));}

/* k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5002,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 797  member* */
f_3992(t3,lf[327],((C_word*)((C_word*)t0)[6])[1]);}

/* k5000 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5002,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5005,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_set_block_item(lf[325] /* warnings-enabled */,0,C_SCHEME_FALSE);
t4=((C_word*)t0)[3];
f_4397(t4,t3);}
else{
/* csi.scm: 798  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,lf[326]);}}
else{
t2=((C_word*)t0)[3];
f_4397(t2,C_SCHEME_UNDEFINED);}}

/* k5003 in k5000 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_5005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[325] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_4397(t3,t2);}

/* k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4397(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4397,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_4400(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4996,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 801  load-verbose */
((C_proc3)C_retrieve_symbol_proc(lf[324]))(3,*((C_word*)lf[324]+1),t3,C_SCHEME_TRUE);}}

/* k4994 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 802  print-banner */
((C_proc2)C_retrieve_symbol_proc(lf[15]))(2,*((C_word*)lf[15]+1),((C_word*)t0)[2]);}

/* k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4981,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 803  member* */
f_3992(t3,lf[323],((C_word*)((C_word*)t0)[6])[1]);}

/* k4979 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4981,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4984,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5767,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 805  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[318]))(3,*((C_word*)lf[318]+1),t3,lf[321]);}
else{
/* csi.scm: 804  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,lf[322]);}}
else{
t2=((C_word*)t0)[3];
f_4403(2,t2,C_SCHEME_UNDEFINED);}}

/* f5767 in k4979 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f5767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 806  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[302]))(3,*((C_word*)lf[302]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4982 in k4979 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4987,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 805  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[318]))(3,*((C_word*)lf[318]+1),t2,lf[321]);}

/* k4985 in k4982 in k4979 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 806  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[302]))(3,*((C_word*)lf[302]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4955,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 807  collect-options */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4227(t4,t3,lf[320]);}

/* k4953 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4955,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4957,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4957(t5,((C_word*)t0)[2],t1);}

/* loop1033 in k4953 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4957(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4957,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[318]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4967,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g10401041 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4965 in loop1033 in k4953 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4957(t3,((C_word*)t0)[2],t2);}

/* k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4928,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 808  collect-options */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4227(t4,t3,lf[319]);}

/* k4926 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4928,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4930,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4930(t5,((C_word*)t0)[2],t1);}

/* loop1046 in k4926 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4930(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4930,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[318]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4940,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g10531054 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4938 in loop1046 in k4926 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4930(t3,((C_word*)t0)[2],t2);}

/* k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4413,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4838,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4889,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 811  collect-options */
t10=((C_word*)((C_word*)t0)[2])[1];
f_4227(t10,t9,lf[317]);}

/* k4887 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4889,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4891,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4891(t5,((C_word*)t0)[2],t1);}

/* loop1059 in k4887 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4891(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4891,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[31]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4920,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g10751076 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4918 in loop1059 in k4887 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4920,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10591072 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4891(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10591072 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4891(t6,((C_word*)t0)[3],t5);}}

/* k4840 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4842,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4846,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4850,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 812  collect-options */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4227(t8,t7,lf[316]);}

/* k4848 in k4840 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4850,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4852,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4852(t5,((C_word*)t0)[2],t1);}

/* loop1082 in k4848 in k4840 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4852(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4852,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[31]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4881,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g10981099 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4879 in loop1082 in k4848 in k4840 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4881,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10821095 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4852(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10821095 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4852(t6,((C_word*)t0)[3],t5);}}

/* k4844 in k4840 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 811  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[220]+1)))(6,*((C_word*)lf[220]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,C_retrieve(lf[119]),((C_word*)t0)[2]);}

/* k4836 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 810  deldups */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),((C_word*)t0)[2],t1,*((C_word*)lf[315]+1));}

/* k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4413,2,t0,t1);}
t2=C_mutate((C_word*)lf[119]+1 /* (set! ##sys#include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4416,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=C_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t4))){
t5=C_i_cadr(((C_word*)t0)[2]);
if(C_truep(C_i_string_equal_p(lf[309],t5))){
/* csi.scm: 820  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[300]))(3,*((C_word*)lf[300]+1),t3,lf[310]);}
else{
t6=C_i_cadr(((C_word*)t0)[2]);
if(C_truep(C_i_string_equal_p(lf[311],t6))){
/* csi.scm: 822  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[300]))(3,*((C_word*)lf[300]+1),t3,lf[301]);}
else{
t7=C_i_cadr(((C_word*)t0)[2]);
if(C_truep(C_i_string_equal_p(lf[312],t7))){
/* csi.scm: 824  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[300]))(3,*((C_word*)lf[300]+1),t3,lf[313]);}
else{
t8=t3;
f_4416(2,t8,C_SCHEME_UNDEFINED);}}}}
else{
/* csi.scm: 818  ##sys#error */
t5=*((C_word*)lf[48]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,lf[314]);}}
else{
t4=t3;
f_4416(2,t4,C_SCHEME_UNDEFINED);}}

/* k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4769,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 825  member* */
f_3992(t3,lf[308],((C_word*)((C_word*)t0)[3])[1]);}

/* k4767 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4769,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4772,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 827  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[299]))(3,*((C_word*)lf[299]+1),((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
/* csi.scm: 826  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,lf[307]);}}
else{
t2=((C_word*)t0)[3];
f_4419(2,t2,C_SCHEME_UNDEFINED);}}

/* k4770 in k4767 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 827  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[299]))(3,*((C_word*)lf[299]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4757,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 828  member* */
f_3992(t3,lf[306],((C_word*)((C_word*)t0)[3])[1]);}

/* k4755 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4757,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4760,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 830  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[298]))(3,*((C_word*)lf[298]+1),((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
/* csi.scm: 829  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,lf[305]);}}
else{
t2=((C_word*)t0)[3];
f_4422(2,t2,C_SCHEME_UNDEFINED);}}

/* k4758 in k4755 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 830  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[298]))(3,*((C_word*)lf[298]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4425,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4736,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 831  member* */
f_3992(t3,lf[304],((C_word*)((C_word*)t0)[3])[1]);}

/* k4734 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4736,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4739,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4739(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 832  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,lf[303]);}}
else{
t2=((C_word*)t0)[3];
f_4425(2,t2,C_SCHEME_UNDEFINED);}}

/* k4737 in k4734 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4742,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 833  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[302]))(3,*((C_word*)lf[302]+1),t2,C_SCHEME_FALSE);}

/* k4740 in k4737 in k4734 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4745,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 834  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[300]))(3,*((C_word*)lf[300]+1),t2,lf[301]);}

/* k4743 in k4740 in k4737 in k4734 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4748,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 835  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[299]))(3,*((C_word*)lf[299]+1),t2,C_SCHEME_FALSE);}

/* k4746 in k4743 in k4740 in k4737 in k4734 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 836  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[298]))(3,*((C_word*)lf[298]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4727,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 837  member* */
f_3992(t3,lf[297],((C_word*)((C_word*)t0)[2])[1]);}

/* k4725 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4727,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_4428(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4279,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 772  ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[295]))(4,*((C_word*)lf[295]+1),t3,lf[296],lf[2]);}}

/* k4277 in k4725 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4285,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 773  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),t2,t1);}

/* k4283 in k4277 in k4725 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4285,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 774  load */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4291,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4307,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 775  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[42]))(3,*((C_word*)lf[42]+1),t3,lf[294]);}}

/* k4305 in k4283 in k4277 in k4725 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* csi.scm: 775  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[31]))(3,*((C_word*)lf[31]+1),((C_word*)t0)[2],t2);}
else{
/* csi.scm: 775  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[31]))(3,*((C_word*)lf[31]+1),((C_word*)t0)[2],lf[293]);}}

/* k4289 in k4283 in k4277 in k4725 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4294,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 776  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[34]+1)))(5,*((C_word*)lf[34]+1),t2,t1,lf[292],lf[2]);}

/* k4292 in k4289 in k4283 in k4277 in k4725 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4300,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 777  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),t2,t1);}

/* k4298 in k4292 in k4289 in k4283 in k4277 in k4725 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 778  load */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_4428(2,t2,C_SCHEME_UNDEFINED);}}

/* k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=C_set_block_item(lf[7] /* notices-enabled */,0,C_SCHEME_FALSE);
t4=t2;
f_4431(t4,t3);}
else{
t3=t2;
f_4431(t3,C_SCHEME_UNDEFINED);}}

/* k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4431(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4431,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4436,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4436(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* doloop1138 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4436(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word *a;
loop:
a=C_alloc(17);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4436,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_nullp(((C_word*)t3)[1]))){
if(C_truep(((C_word*)t0)[5])){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4449,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 843  repl */
((C_proc2)C_retrieve_symbol_proc(lf[262]))(2,*((C_word*)lf[262]+1),t4);}}
else{
t4=C_i_car(((C_word*)t3)[1]);
t5=C_i_member(t4,lf[263]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4461,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=C_i_cdr(((C_word*)t3)[1]);
t35=t1;
t36=t7;
t1=t35;
t2=t36;
goto loop;}
else{
if(C_truep((C_truep(C_i_equalp(t4,lf[264]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[265]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[266]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[267]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[268]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[269]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t7=C_i_cdr(((C_word*)t3)[1]);
t8=C_set_block_item(t3,0,t7);
t9=C_i_cdr(((C_word*)t3)[1]);
t35=t1;
t36=t9;
t1=t35;
t2=t36;
goto loop;}
else{
t7=C_i_string_equal_p(lf[270],t4);
t8=(C_truep(t7)?t7:C_i_string_equal_p(lf[271],t4));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4490,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4514,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 850  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[273]+1)))(3,*((C_word*)lf[273]+1),t10,t11);}
else{
t9=C_i_string_equal_p(lf[274],t4);
t10=(C_truep(t9)?t9:C_i_string_equal_p(lf[275],t4));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4530,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t12=C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 853  evalstring */
f_4312(t11,t12,C_SCHEME_END_OF_LIST);}
else{
t11=C_i_string_equal_p(lf[276],t4);
t12=(C_truep(t11)?t11:C_i_string_equal_p(lf[277],t4));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4550,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t14=C_i_cadr(((C_word*)t3)[1]);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4560,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 856  evalstring */
f_4312(t13,t14,C_a_i_list(&a,1,t15));}
else{
t13=C_i_string_equal_p(lf[279],t4);
t14=(C_truep(t13)?t13:C_i_string_equal_p(lf[280],t4));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4576,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t16=C_i_cadr(((C_word*)t3)[1]);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4586,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 859  evalstring */
f_4312(t15,t16,C_a_i_list(&a,1,t17));}
else{
t15=(C_truep(((C_word*)t0)[2])?C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4596,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t6,a[6]=t15,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_equalp(lf[284],t15))){
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4649,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 863  ##sys#load */
((C_proc5)C_retrieve_symbol_proc(lf[291]))(5,*((C_word*)lf[291]+1),t16,t4,t17,C_SCHEME_FALSE);}
else{
/* csi.scm: 863  ##sys#load */
((C_proc5)C_retrieve_symbol_proc(lf[291]))(5,*((C_word*)lf[291]+1),t16,t4,C_SCHEME_FALSE,C_SCHEME_FALSE);}}}}}}}}}

/* f_4649 in doloop1138 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4649,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4653,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4704,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 867  with-output-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[290]))(3,*((C_word*)lf[290]+1),t3,t4);}

/* a4703 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4704,2,t0,t1);}
t2=C_retrieve(lf[65]);
/* g12131214 */
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[2]);}

/* k4651 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4653,2,t0,t1);}
t2=C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4659,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 869  flush-output */
((C_proc3)C_retrieve_proc(*((C_word*)lf[289]+1)))(3,*((C_word*)lf[289]+1),t3,*((C_word*)lf[111]+1));}

/* k4657 in k4651 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 870  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[9]+1)))(4,*((C_word*)lf[9]+1),t2,lf[288],*((C_word*)lf[285]+1));}

/* k4660 in k4657 in k4651 */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4665,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4673,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4673(t6,t2,C_fix(0));}

/* doloop1216 in k4660 in k4657 in k4651 */
static void C_fcall f_4673(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4673,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_i_string_ref(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4686,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t5=C_retrieve(lf[287]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,*((C_word*)lf[285]+1));}}

/* k4684 in doloop1216 in k4660 in k4657 in k4651 */
static void C_ccall f_4686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4689,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_eqp(C_make_character(10),((C_word*)t0)[2]);
if(C_truep(t3)){
/* csi.scm: 876  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[9]+1)))(4,*((C_word*)lf[9]+1),t2,lf[286],*((C_word*)lf[285]+1));}
else{
t4=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[4])[1];
f_4673(t5,((C_word*)t0)[3],t4);}}

/* k4687 in k4684 in doloop1216 in k4660 in k4657 in k4651 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4673(t3,((C_word*)t0)[2],t2);}

/* k4663 in k4660 in k4657 in k4651 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 877  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[21]+1)))(3,*((C_word*)lf[21]+1),t2,*((C_word*)lf[285]+1));}

/* k4666 in k4663 in k4660 in k4657 in k4651 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 878  eval */
((C_proc3)C_retrieve_symbol_proc(lf[58]))(3,*((C_word*)lf[58]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4594 in doloop1138 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4596,2,t0,t1);}
if(C_truep(C_i_equalp(lf[281],((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4607,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4617,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 881  call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t2,t3);}
else{
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4436(t3,((C_word*)t0)[2],t2);}}

/* a4616 in k4594 in doloop1138 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4617(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4617r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4617r(t0,t1,t2);}}

static void C_ccall f_4617r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
if(C_truep(C_i_pairp(t2))){
t3=C_i_car(t2);
if(C_truep(C_fixnump(t3))){
t4=C_i_car(t2);
/* csi.scm: 883  exit */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),t1,t4);}
else{
/* csi.scm: 883  exit */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),t1,C_fix(0));}}
else{
/* csi.scm: 883  exit */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),t1,C_fix(0));}}

/* a4606 in k4594 in doloop1138 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4607,2,t0,t1);}
t2=C_retrieve(lf[282]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4615,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 881  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[283]))(2,*((C_word*)lf[283]+1),t3);}

/* k4613 in a4606 in k4594 in doloop1138 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g12371238 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* a4585 in doloop1138 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4586r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4586r(t0,t1,t2);}}

static void C_ccall f_4586r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[278]+1),C_retrieve(lf[65]),t2);}

/* k4574 in doloop1138 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_4436(t5,((C_word*)t0)[2],t4);}

/* a4559 in doloop1138 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4560r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4560r(t0,t1,t2);}}

static void C_ccall f_4560r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[278]+1),*((C_word*)lf[16]+1),t2);}

/* k4548 in doloop1138 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_4436(t5,((C_word*)t0)[2],t4);}

/* k4528 in doloop1138 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_4436(t5,((C_word*)t0)[2],t4);}

/* k4512 in doloop1138 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4514,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t2,t3);
t5=C_a_i_cons(&a,2,lf[272],t4);
/* csi.scm: 850  eval */
((C_proc3)C_retrieve_symbol_proc(lf[58]))(3,*((C_word*)lf[58]+1),((C_word*)t0)[2],t5);}

/* k4488 in doloop1138 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_4436(t5,((C_word*)t0)[2],t4);}

/* k4459 in doloop1138 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4436(t3,((C_word*)t0)[2],t2);}

/* k4447 in doloop1138 in k4429 in k4426 in k4423 in k4420 in k4417 in k4414 in k4411 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 844  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[111]+1));}

/* evalstring in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4312(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4312,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4316,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_4316(2,t5,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4359,tmp=(C_word)a,a+=2,tmp));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_4316(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* f_4359 in evalstring in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4359(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4359,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* k4314 in evalstring in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4319,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 780  open-input-string */
((C_proc3)C_retrieve_symbol_proc(lf[261]))(3,*((C_word*)lf[261]+1),t2,((C_word*)t0)[2]);}

/* k4317 in k4314 in evalstring in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 781  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[23]+1)))(3,*((C_word*)lf[23]+1),t2,t1);}

/* k4324 in k4317 in k4314 in evalstring in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4326,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4328,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4328(t5,((C_word*)t0)[2],t1);}

/* doloop997 in k4324 in k4317 in k4314 in evalstring in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4328(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4328,NULL,3,t0,t1,t2);}
if(C_truep(C_eofp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4338,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4349,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4351,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,*((C_word*)lf[260]+1));}}

/* a4350 in doloop997 in k4324 in k4317 in k4314 in evalstring in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4351,2,t0,t1);}
/* csi.scm: 783  eval */
((C_proc3)C_retrieve_symbol_proc(lf[58]))(3,*((C_word*)lf[58]+1),t1,((C_word*)t0)[2]);}

/* k4347 in doloop997 in k4324 in k4317 in k4314 in evalstring in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 783  rec */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4336 in doloop997 in k4324 in k4317 in k4314 in evalstring in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4345,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 781  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[23]+1)))(3,*((C_word*)lf[23]+1),t2,((C_word*)t0)[2]);}

/* k4343 in k4336 in doloop997 in k4324 in k4317 in k4314 in evalstring in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_4328(t2,((C_word*)t0)[2],t1);}

/* collect-options in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4227(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4227,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4233,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4233(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in collect-options in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4233(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4233,NULL,3,t0,t1,t2);}
t3=C_i_member(((C_word*)t0)[3],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* g967968 */
t5=t4;
f_4241(t5,t1,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* g967 in loop in collect-options in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4241(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4241,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
/* csi.scm: 768  ##sys#error */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[259],((C_word*)t0)[3]);}
else{
t4=C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4262,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cddr(t2);
/* csi.scm: 769  loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_4233(t7,t5,t6);}}

/* k4260 in g967 in loop in collect-options in k4223 in k4220 in k4217 in k4214 in k4211 in k4208 in k4205 in k4202 in k4199 in k4196 in ##csi#run in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4262,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* canonicalize-args in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4049(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4049,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4055,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4055(t6,t1,t2);}

/* loop in canonicalize-args in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4055(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4055,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
if(C_truep((C_truep(C_i_equalp(t3,lf[248]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[249]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[250]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[251]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[252]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4077,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=C_block_size(t3);
if(C_truep(C_fixnum_greaterp(t5,C_fix(2)))){
t6=C_eqp(C_make_character(45),C_subchar(t3,C_fix(0)));
if(C_truep(t6)){
t7=C_i_member(t3,lf[257]);
t8=t4;
f_4077(t8,C_i_not(t7));}
else{
t7=t4;
f_4077(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_4077(t6,C_SCHEME_FALSE);}}}}

/* k4075 in loop in canonicalize-args in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4077(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4077,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_eqp(C_make_character(58),C_subchar(((C_word*)t0)[5],C_fix(1)));
if(C_truep(t2)){
t3=C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 714  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4055(t4,((C_word*)t0)[2],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4093,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4127,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 715  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[30]+1)))(4,*((C_word*)lf[30]+1),t4,((C_word*)t0)[5],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4134,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 719  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4055(t4,t2,t3);}}

/* k4132 in k4075 in loop in canonicalize-args in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4134,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4125 in k4075 in loop in canonicalize-args in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[256]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4091 in k4075 in loop in canonicalize-args in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4093,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4166,tmp=(C_word)a,a+=2,tmp);
t4=f_4166(t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4106,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4116,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[254]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}
else{
/* csi.scm: 718  ##sys#error */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[255],((C_word*)t0)[2]);}}

/* a4115 in k4091 in k4075 in loop in canonicalize-args in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4116(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4116,3,t0,t1,t2);}
t3=*((C_word*)lf[253]+1);
/* g821822 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,C_make_character(45),t2);}

/* k4104 in k4091 in k4075 in loop in canonicalize-args in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4110,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 717  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4055(t4,t2,t3);}

/* k4108 in k4104 in k4091 in k4075 in loop in canonicalize-args in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 717  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[220]+1)))(4,*((C_word*)lf[220]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4091 in k4075 in loop in canonicalize-args in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static C_word C_fcall f_4166(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=C_i_car(t1);
if(C_truep((C_truep(C_eqp(t3,C_make_character(107)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(115)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(118)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(104)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(68)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(101)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(105)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(82)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(98)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(110)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(113)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(119)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(45)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(73)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(112)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(80)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))))){
t4=C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* member* in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3992(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3992,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3998,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3998(t7,t1,t3);}

/* loop in member* in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3998(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3998,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4010,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4010(t6,t1,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* find in loop in member* in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_4010(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4010,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 690  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3998(t4,t1,t3);}
else{
t3=C_i_car(t2);
t4=C_i_car(((C_word*)t0)[4]);
if(C_truep(C_i_equalp(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=C_i_cdr(t2);
/* csi.scm: 692  find */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}}

/* ##csi#deldups in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3933r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3933r(t0,t1,t2,t3);}}

static void C_ccall f_3933r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3937,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_3937(2,t5,*((C_word*)lf[245]+1));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_3937(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3935 in ##csi#deldups in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3937,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3942,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3942(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* recur in k3935 in ##csi#deldups in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3942(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3942,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_i_car(t2);
t4=C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3958,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3971,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 683  del */
((C_proc5)C_retrieve_symbol_proc(lf[243]))(5,*((C_word*)lf[243]+1),t6,t3,t4,((C_word*)t0)[2]);}}

/* k3969 in recur in k3935 in ##csi#deldups in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 683  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3942(t2,((C_word*)t0)[2],t1);}

/* k3956 in recur in k3935 in ##csi#deldups in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3958,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* ##csi#del in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3895,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3901,a[2]=t2,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3901(t8,t1,t3);}

/* loop in ##csi#del in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3901(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3901,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 673  tst */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k3915 in loop in ##csi#del in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3917,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 675  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3901(t4,t2,t3);}}

/* k3925 in k3915 in loop in ##csi#del in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3927,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3686,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3689,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3718,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t8,a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_3718(t10,t1,C_fix(0));}

/* doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3718(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3718,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3893,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 642  justify */
t5=((C_word*)t0)[2];
f_3689(t5,t4,t2,C_fix(4),C_fix(10),C_make_character(32));}}

/* k3891 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 642  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* csi.scm: 643  write-char */
t3=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(58),((C_word*)t0)[8]);}

/* k3729 in k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3734,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3803,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3803(t6,t2,C_fix(0),((C_word*)t0)[11]);}

/* doloop686 in k3729 in k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3803(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3803,NULL,4,t0,t1,t2,t3);}
t4=C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]));
if(C_truep(t5)){
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3822,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 648  fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[242]+1)))(4,*((C_word*)lf[242]+1),t6,((C_word*)t0)[9],C_fix(16));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3864,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 653  write-char */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_make_character(32),((C_word*)t0)[7]);}}

/* k3862 in doloop686 in k3729 in k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3867,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3882,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3886,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 654  ref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[9]);}

/* k3884 in k3862 in doloop686 in k3729 in k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 654  justify */
t2=((C_word*)t0)[3];
f_3689(t2,((C_word*)t0)[2],t1,C_fix(2),C_fix(16),C_make_character(48));}

/* k3880 in k3862 in doloop686 in k3729 in k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 654  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3865 in k3862 in doloop686 in k3729 in k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3803(t4,((C_word*)t0)[2],t2,t3);}

/* k3820 in doloop686 in k3729 in k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3822,2,t0,t1);}
if(C_truep(t1)){
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=C_fixnum_difference(C_fix(16),t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3840(t7,((C_word*)t0)[4],t3);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* doloop701 in k3820 in doloop686 in k3729 in k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3840(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3840,NULL,3,t0,t1,t2);}
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3850,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 652  display */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[241],((C_word*)t0)[2]);}}

/* k3848 in doloop701 in k3820 in doloop686 in k3729 in k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3840(t3,((C_word*)t0)[2],t2);}

/* k3732 in k3729 in k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 655  write-char */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(32),((C_word*)t0)[6]);}

/* k3735 in k3732 in k3729 in k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3740,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3752(t6,t2,C_fix(0),((C_word*)t0)[9]);}

/* doloop711 in k3735 in k3732 in k3729 in k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3752(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3752,NULL,4,t0,t1,t2,t3);}
t4=C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[7]));
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3765,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 659  ref */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t3);}}

/* k3763 in doloop711 in k3735 in k3732 in k3729 in k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3768,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=C_fixnum_greater_or_equal_p(t1,C_fix(32));
t4=(C_truep(t3)?C_fixnum_lessp(t1,C_fix(128)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_make_character(C_unfix(t1));
/* csi.scm: 661  write-char */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,t5,((C_word*)t0)[2]);}
else{
/* csi.scm: 662  write-char */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(46),((C_word*)t0)[2]);}}

/* k3766 in k3763 in doloop711 in k3735 in k3732 in k3729 in k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3752(t4,((C_word*)t0)[2],t2,t3);}

/* k3738 in k3735 in k3732 in k3729 in k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3743,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 663  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t2,C_make_character(10),((C_word*)t0)[2]);}

/* k3741 in k3738 in k3735 in k3732 in k3729 in k3726 in doloop673 in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(16));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3718(t3,((C_word*)t0)[2],t2);}

/* justify in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3689(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3689,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3693,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 634  number->string */
C_number_to_string(4,0,t6,t2,t4);}

/* k3691 in justify in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3693,2,t0,t1);}
t2=C_block_size(t1);
if(C_truep(C_fixnum_lessp(t2,((C_word*)t0)[6]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3709,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_difference(((C_word*)t0)[6],t2);
/* csi.scm: 637  make-string */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t3=t1;
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3707 in k3691 in justify in ##csi#hexdump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 637  string-append */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##csi#dump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3525(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3525r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3525r(t0,t1,t2,t3);}}

static void C_ccall f_3525r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3527,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3633,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3638,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t3))){
/* def-len635660 */
t7=t6;
f_3638(t7,t1);}
else{
t7=C_i_car(t3);
t8=C_i_cdr(t3);
if(C_truep(C_i_nullp(t8))){
/* def-out636658 */
t9=t5;
f_3633(t9,t1,t7);}
else{
t9=C_i_car(t8);
t10=C_i_cdr(t8);
if(C_truep(C_i_nullp(t10))){
/* body633641 */
t11=t4;
f_3527(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-len635 in ##csi#dump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3638(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3638,NULL,2,t0,t1);}
/* def-out636658 */
t2=((C_word*)t0)[2];
f_3633(t2,t1,C_SCHEME_FALSE);}

/* def-out636 in ##csi#dump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3633(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3633,NULL,3,t0,t1,t2);}
/* body633641 */
t3=((C_word*)t0)[2];
f_3527(t3,t1,t2,*((C_word*)lf[111]+1));}

/* body633 in ##csi#dump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3527(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3527,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3530,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_immp(((C_word*)t0)[2]))){
/* csi.scm: 616  ##sys#error */
t5=*((C_word*)lf[48]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[236],lf[237],((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3552,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 617  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[226]+1)))(3,*((C_word*)lf[226]+1),t5,((C_word*)t0)[2]);}}

/* k3550 in body633 in ##csi#dump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3552,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3559,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_block_size(((C_word*)t0)[4]);
/* csi.scm: 617  bestlen */
t4=((C_word*)t0)[2];
f_3530(t4,t2,t3);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3576,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_block_size(((C_word*)t0)[4]);
/* csi.scm: 618  bestlen */
t4=((C_word*)t0)[2];
f_3530(t4,t2,t3);}
else{
t2=C_immp(((C_word*)t0)[4]);
t3=(C_truep(t2)?C_SCHEME_FALSE:C_anypointerp(((C_word*)t0)[4]));
if(C_truep(t3)){
/* csi.scm: 620  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[201]))(6,*((C_word*)lf[201]+1),((C_word*)t0)[5],((C_word*)t0)[4],C_fix(32),*((C_word*)lf[238]+1),((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_structurep(((C_word*)t0)[4]))){
t5=C_slot(((C_word*)t0)[4],C_fix(0));
t6=t4;
f_3595(t6,C_i_assq(t5,C_retrieve2(lf[135],"bytevector-data")));}
else{
t5=t4;
f_3595(t5,C_SCHEME_FALSE);}}}}}

/* k3593 in k3550 in body633 in ##csi#dump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3595(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3595,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3605,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_block_size(t2);
/* csi.scm: 623  bestlen */
t5=((C_word*)t0)[2];
f_3530(t5,t3,t4);}
else{
/* csi.scm: 624  ##sys#error */
t2=*((C_word*)lf[48]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[236],lf[239],((C_word*)t0)[5]);}}

/* k3603 in k3593 in k3550 in body633 in ##csi#dump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 623  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[201]))(6,*((C_word*)lf[201]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[202]+1),((C_word*)t0)[2]);}

/* k3574 in k3550 in body633 in ##csi#dump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 618  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[201]))(6,*((C_word*)lf[201]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[202]+1),((C_word*)t0)[2]);}

/* k3557 in k3550 in body633 in ##csi#dump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 617  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[201]))(6,*((C_word*)lf[201]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[202]+1),((C_word*)t0)[2]);}

/* bestlen in body633 in ##csi#dump in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3530(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3530,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 615  min */
((C_proc4)C_retrieve_proc(*((C_word*)lf[235]+1)))(4,*((C_word*)lf[235]+1),t1,((C_word*)t0)[2],t2);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* set-describer! in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3516,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3520,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 604  ##sys#check-symbol */
((C_proc5)C_retrieve_proc(*((C_word*)lf[233]+1)))(5,*((C_word*)lf[233]+1),t4,t2,lf[234],lf[232]);}

/* k3518 in set-describer! in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 605  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),((C_word*)t0)[4],C_retrieve2(lf[137],"describer-table"),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2613(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_2613r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2613r(t0,t1,t2,t3);}}

static void C_ccall f_2613r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_2617(2,t5,*((C_word*)lf[111]+1));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_2617(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2619,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_permanentp(((C_word*)t0)[7]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3495,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 485  ##sys#block-address */
((C_proc3)C_retrieve_symbol_proc(lf[231]))(3,*((C_word*)lf[231]+1),t4,((C_word*)t0)[7]);}
else{
t4=t3;
f_2745(2,t4,C_SCHEME_UNDEFINED);}}

/* k3493 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 485  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[230],t1);}

/* k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2748,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_charp(((C_word*)t0)[9]))){
t3=C_fix(C_character_code(((C_word*)t0)[9]));
/* csi.scm: 488  fprintf */
t4=((C_word*)t0)[8];
((C_proc8)C_retrieve_proc(t4))(8,t4,t2,((C_word*)t0)[7],lf[148],((C_word*)t0)[9],t3,t3,t3);}
else{
switch(((C_word*)t0)[9]){
case C_SCHEME_TRUE:
/* csi.scm: 489  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[149]);
case C_SCHEME_FALSE:
/* csi.scm: 490  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[150]);
default:
if(C_truep(C_i_nullp(((C_word*)t0)[9]))){
/* csi.scm: 491  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[151]);}
else{
if(C_truep(C_eofp(((C_word*)t0)[9]))){
/* csi.scm: 492  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[152]);}
else{
t3=C_retrieve(lf[47]);
t4=C_eqp(t3,((C_word*)t0)[9]);
if(C_truep(t4)){
/* csi.scm: 493  fprintf */
t5=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[7],lf[153]);}
else{
if(C_truep(C_fixnump(((C_word*)t0)[9]))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2814,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t2,a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 495  fprintf */
t6=((C_word*)t0)[8];
((C_proc8)C_retrieve_proc(t6))(8,t6,t5,((C_word*)t0)[7],lf[155],((C_word*)t0)[9],((C_word*)t0)[9],((C_word*)t0)[9],((C_word*)t0)[9]);}
else{
t5=C_slot(lf[156],C_fix(0));
t6=C_eqp(((C_word*)t0)[9],t5);
if(C_truep(t6)){
/* csi.scm: 500  fprintf */
t7=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,((C_word*)t0)[7],lf[157]);}
else{
if(C_truep(C_i_flonump(((C_word*)t0)[9]))){
/* csi.scm: 501  fprintf */
t7=((C_word*)t0)[8];
((C_proc5)C_retrieve_proc(t7))(5,t7,t2,((C_word*)t0)[7],lf[158],((C_word*)t0)[9]);}
else{
if(C_truep(C_i_numberp(((C_word*)t0)[9]))){
/* csi.scm: 502  fprintf */
t7=((C_word*)t0)[8];
((C_proc5)C_retrieve_proc(t7))(5,t7,t2,((C_word*)t0)[7],lf[159],((C_word*)t0)[9]);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[9]))){
/* csi.scm: 503  descseq */
t7=((C_word*)t0)[6];
f_2619(6,t7,t2,lf[160],*((C_word*)lf[161]+1),((C_word*)t0)[5],C_fix(0));}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[9]))){
/* csi.scm: 504  descseq */
t7=((C_word*)t0)[6];
f_2619(6,t7,t2,lf[162],*((C_word*)lf[161]+1),*((C_word*)lf[163]+1),C_fix(0));}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[9]))){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2883,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2990,a[2]=((C_word*)t0)[7],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 506  ##sys#symbol-has-toplevel-binding? */
((C_proc3)C_retrieve_symbol_proc(lf[178]))(3,*((C_word*)lf[178]+1),t8,((C_word*)t0)[9]);}
else{
if(C_truep(C_i_listp(((C_word*)t0)[9]))){
/* csi.scm: 528  descseq */
t7=((C_word*)t0)[6];
f_2619(6,t7,t2,lf[179],((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0));}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[9]))){
t7=C_i_car(((C_word*)t0)[9]);
t8=C_i_cdr(((C_word*)t0)[9]);
/* csi.scm: 529  fprintf */
t9=((C_word*)t0)[8];
((C_proc6)C_retrieve_proc(t9))(6,t9,t2,((C_word*)t0)[7],lf[180],t7,t8);}
else{
if(C_truep(C_i_closurep(((C_word*)t0)[9]))){
t7=C_block_size(((C_word*)t0)[9]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_greaterp(t7,C_fix(3)))){
if(C_truep(C_i_memq(lf[184],C_retrieve(lf[6])))){
t9=C_fixnum_difference(t7,C_fix(1));
t10=C_slot(((C_word*)t0)[9],t9);
t11=t8;
f_3034(t11,C_eqp(C_retrieve(lf[185]),t10));}
else{
t9=t8;
f_3034(t9,C_SCHEME_FALSE);}}
else{
t9=t8;
f_3034(t9,C_SCHEME_FALSE);}}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3074,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 539  port? */
((C_proc3)C_retrieve_symbol_proc(lf[229]))(3,*((C_word*)lf[229]+1),t7,((C_word*)t0)[9]);}}}}}}}}}}}}}}}}

/* k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3074,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_truep(t2)?lf[186]:lf[187]);
t4=C_slot(((C_word*)t0)[6],C_fix(7));
t5=C_slot(((C_word*)t0)[6],C_fix(3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3093,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 545  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[183]))(4,*((C_word*)lf[183]+1),t6,((C_word*)t0)[6],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3102,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_memq(lf[184],C_retrieve(lf[6])))){
/* csi.scm: 546  instance? */
((C_proc3)C_retrieve_symbol_proc(lf[228]))(3,*((C_word*)lf[228]+1),t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_3102(2,t3,C_SCHEME_FALSE);}}}

/* k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3102,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 547  describe-object */
((C_proc4)C_retrieve_symbol_proc(lf[181]))(4,*((C_word*)lf[181]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 548  ##sys#locative? */
((C_proc3)C_retrieve_symbol_proc(lf[227]))(3,*((C_word*)lf[227]+1),t2,((C_word*)t0)[5]);}}

/* k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3111,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3118,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 550  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[183]))(4,*((C_word*)lf[183]+1),t2,((C_word*)t0)[6],C_fix(0));}
else{
if(C_truep(C_anypointerp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3199,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 563  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[183]))(4,*((C_word*)lf[183]+1),t2,((C_word*)t0)[6],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 564  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[226]+1)))(3,*((C_word*)lf[226]+1),t2,((C_word*)t0)[6]);}}}

/* k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3205,2,t0,t1);}
if(C_truep(t1)){
t2=C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3211,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 566  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],lf[203],t2);}
else{
if(C_truep(C_lambdainfop(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3224,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 569  ##sys#lambda-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[205]))(3,*((C_word*)lf[205]+1),t2,((C_word*)t0)[6]);}
else{
if(C_truep(C_i_structurep(((C_word*)t0)[6],lf[206]))){
t2=C_slot(((C_word*)t0)[6],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3236,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=C_eqp(t2,C_fix(1));
t5=(C_truep(t4)?lf[210]:lf[211]);
t6=C_slot(((C_word*)t0)[6],C_fix(3));
/* csi.scm: 572  fprintf */
t7=((C_word*)t0)[3];
((C_proc7)C_retrieve_proc(t7))(7,t7,t3,((C_word*)t0)[4],lf[212],t2,t5,t6);}
else{
if(C_truep(C_i_structurep(((C_word*)t0)[6],lf[213]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3272,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_slot(((C_word*)t0)[6],C_fix(1));
/* csi.scm: 579  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[4],lf[218],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3361,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_structurep(((C_word*)t0)[6],lf[223]))){
/* csi.scm: 589  provided? */
((C_proc3)C_retrieve_symbol_proc(lf[224]))(3,*((C_word*)lf[224]+1),t2,lf[225]);}
else{
t3=t2;
f_3361(2,t3,C_SCHEME_FALSE);}}}}}}

/* k3359 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3361,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 590  unveil */
((C_proc4)C_retrieve_symbol_proc(lf[219]))(4,*((C_word*)lf[219]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep(C_structurep(((C_word*)t0)[5]))){
t2=C_slot(((C_word*)t0)[5],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 593  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[101]))(4,*((C_word*)lf[101]+1),t3,C_retrieve2(lf[137],"describer-table"),t2);}
else{
/* csi.scm: 600  fprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[4],lf[222]);}}}

/* k3374 in k3359 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3376,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3380,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* g580581 */
t3=t2;
f_3380(t3,((C_word*)t0)[5],t1);}
else{
t2=C_i_assq(((C_word*)t0)[4],C_retrieve2(lf[135],"bytevector-data"));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3394,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* g592593 */
t4=t3;
f_3394(t4,((C_word*)t0)[5],t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3455,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_slot(((C_word*)t0)[7],C_fix(0));
/* csi.scm: 598  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],lf[221],t4);}}}

/* k3453 in k3374 in k3359 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 599  descseq */
t2=((C_word*)t0)[3];
f_2619(6,t2,((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[161]+1),*((C_word*)lf[163]+1),C_fix(1));}

/* g592 in k3374 in k3359 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3394(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3394,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3402,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3406,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_i_cdr(t2);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3416,a[2]=t5,a[3]=t11,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_3416(t13,t8,t9);}

/* loop597 in g592 in k3374 in k3359 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3416(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3416,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[58]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g613614 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3443 in loop597 in g592 in k3374 in k3359 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3445,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop597610 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3416(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop597610 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3416(t6,((C_word*)t0)[3],t5);}}

/* k3404 in g592 in k3374 in k3359 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3406,2,t0,t1);}
t2=C_a_i_list(&a,1,C_fix(0));
/* csi.scm: 596  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[220]+1)))(4,*((C_word*)lf[220]+1),((C_word*)t0)[2],t1,t2);}

/* k3400 in g592 in k3374 in k3359 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* g580 in k3374 in k3359 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3380(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3380,NULL,3,t0,t1,t2);}
/* g589590 */
t3=t2;
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3270 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3272,2,t0,t1);}
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3281,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3281(t6,((C_word*)t0)[2],t2);}

/* loop547 in k3270 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3281(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3281,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3289,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3340,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g554555 */
t6=t3;
f_3289(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3338 in loop547 in k3270 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3281(t3,((C_word*)t0)[2],t2);}

/* g554 in loop547 in k3270 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3289(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3289,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3293,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 582  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[217],t2);}

/* k3291 in g554 in loop547 in k3270 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3293,2,t0,t1);}
t2=C_slot(((C_word*)t0)[6],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3302,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3302(t6,((C_word*)t0)[2],t2);}

/* loop in k3291 in g554 in loop547 in k3270 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3302(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3302,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3312,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3337,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 585  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[216]+1)))(3,*((C_word*)lf[216]+1),t4,t2);}}

/* k3335 in loop in k3291 in g554 in loop547 in k3270 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3337,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[8],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3329,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 586  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[215]+1)))(3,*((C_word*)lf[215]+1),t3,((C_word*)t0)[7]);}
else{
t3=C_i_cddr(((C_word*)t0)[7]);
/* csi.scm: 587  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3302(t4,((C_word*)t0)[2],t3);}}

/* k3327 in k3335 in loop in k3291 in g554 in loop547 in k3270 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[5]);
/* csi.scm: 586  fprintf */
t3=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[214],t1,t2);}

/* k3310 in loop in k3291 in g554 in loop547 in k3270 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cddr(((C_word*)t0)[4]);
/* csi.scm: 587  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3302(t3,((C_word*)t0)[2],t2);}

/* k3234 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(4));
/* csi.scm: 574  fprintf */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[4],lf[209],t3);}

/* k3237 in k3234 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3244,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 575  hash-table-walk */
((C_proc4)C_retrieve_symbol_proc(lf[208]))(4,*((C_word*)lf[208]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3243 in k3237 in k3234 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3244(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3244,4,t0,t1,t2,t3);}
/* csi.scm: 577  fprintf */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],lf[207],t2,t3);}

/* k3222 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 569  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[204],t1);}

/* k3209 in k3203 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 567  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[201]))(6,*((C_word*)lf[201]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],*((C_word*)lf[202]+1),((C_word*)t0)[2]);}

/* k3197 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 563  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[200],t1);}

/* k3116 in k3109 in k3100 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[5],C_fix(2));
switch(t3){
case C_fix(0):
/* csi.scm: 549  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[189],t1,t2,lf[190]);
case C_fix(1):
/* csi.scm: 549  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[189],t1,t2,lf[191]);
case C_fix(2):
/* csi.scm: 549  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[189],t1,t2,lf[192]);
case C_fix(3):
/* csi.scm: 549  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[189],t1,t2,lf[193]);
case C_fix(4):
/* csi.scm: 549  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[189],t1,t2,lf[194]);
case C_fix(5):
/* csi.scm: 549  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[189],t1,t2,lf[195]);
case C_fix(6):
/* csi.scm: 549  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[189],t1,t2,lf[196]);
case C_fix(7):
/* csi.scm: 549  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[189],t1,t2,lf[197]);
case C_fix(8):
/* csi.scm: 549  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[189],t1,t2,lf[198]);
case C_fix(9):
/* csi.scm: 549  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[189],t1,t2,lf[199]);
default:
t4=C_SCHEME_UNDEFINED;
/* csi.scm: 549  fprintf */
t5=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[189],t1,t2,t4);}}

/* k3091 in k3072 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 540  fprintf */
t2=((C_word*)t0)[7];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[188],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3032 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_3034(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3034,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 535  describe-object */
((C_proc4)C_retrieve_symbol_proc(lf[181]))(4,*((C_word*)lf[181]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3044,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3048,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 537  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[183]))(4,*((C_word*)lf[183]+1),t3,((C_word*)t0)[5],C_fix(0));}}

/* k3046 in k3032 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 537  sprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[182],t1);}

/* k3042 in k3032 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 536  descseq */
t2=((C_word*)t0)[3];
f_2619(6,t2,((C_word*)t0)[2],t1,*((C_word*)lf[161]+1),*((C_word*)lf[163]+1),C_fix(1));}

/* k2988 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2883(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 507  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[9]+1)))(4,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[177],((C_word*)t0)[2]);}}

/* k2881 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[6]))){
t3=C_slot(((C_word*)t0)[6],C_fix(1));
t4=C_subbyte(t3,C_fix(0));
t5=C_eqp(C_fix(0),t4);
if(C_truep(t5)){
/* csi.scm: 509  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[9]+1)))(4,*((C_word*)lf[9]+1),t2,lf[176],((C_word*)t0)[4]);}
else{
t6=t2;
f_2886(2,t6,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_2886(2,t3,C_SCHEME_UNDEFINED);}}

/* k2884 in k2881 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 510  ##sys#qualified-symbol? */
((C_proc3)C_retrieve_symbol_proc(lf[175]))(3,*((C_word*)lf[175]+1),t2,((C_word*)t0)[6]);}

/* k2887 in k2884 in k2881 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2967,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 512  ##sys#interned-symbol? */
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t3,((C_word*)t0)[6]);}

/* k2965 in k2887 in k2884 in k2881 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2967,2,t0,t1);}
t2=(C_truep(t1)?lf[167]:lf[168]);
t3=(C_truep(((C_word*)t0)[6])?lf[169]:lf[170]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2958,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[6])){
/* csi.scm: 515  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t4,((C_word*)t0)[2]);}
else{
/* csi.scm: 516  ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t4,((C_word*)t0)[2]);}}

/* k2956 in k2965 in k2887 in k2884 in k2881 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 511  fprintf */
t2=((C_word*)t0)[6];
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[171],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2890 in k2887 in k2884 in k2881 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2892,2,t0,t1);}
t2=C_slot(((C_word*)t0)[6],C_fix(2));
if(C_truep(C_i_nullp(t2))){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve(lf[47]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2904,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 519  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[9]+1)))(4,*((C_word*)lf[9]+1),t3,lf[166],((C_word*)t0)[4]);}}

/* k2902 in k2890 in k2887 in k2884 in k2881 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2904,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2909,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2909(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop513 in k2902 in k2890 in k2887 in k2884 in k2881 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_2909(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2909,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2919,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=C_i_car(t2);
/* csi.scm: 522  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[3],lf[165],t4);}}

/* k2917 in doloop513 in k2902 in k2890 in k2887 in k2884 in k2881 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 523  ##sys#with-print-length-limit */
((C_proc4)C_retrieve_symbol_proc(lf[164]))(4,*((C_word*)lf[164]+1),t2,C_fix(1000),t3);}

/* a2933 in k2917 in doloop513 in k2902 in k2890 in k2887 in k2884 in k2881 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2934,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 526  write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[62]+1)))(4,*((C_word*)lf[62]+1),t1,t2,((C_word*)t0)[2]);}

/* k2920 in k2917 in doloop513 in k2902 in k2890 in k2887 in k2884 in k2881 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2925,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 527  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[21]+1)))(3,*((C_word*)lf[21]+1),t2,((C_word*)t0)[2]);}

/* k2923 in k2920 in k2917 in doloop513 in k2902 in k2890 in k2887 in k2884 in k2881 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cddr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2909(t3,((C_word*)t0)[2],t2);}

/* k2812 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2814,2,t0,t1);}
t2=C_make_character(C_unfix(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2820,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[5],C_fix(65536)))){
/* csi.scm: 497  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[154],t2);}
else{
/* csi.scm: 498  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),((C_word*)t0)[4],C_make_character(10),*((C_word*)lf[111]+1));}}

/* k2818 in k2812 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 498  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[111]+1));}

/* k2746 in k2743 in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* descseq in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2619,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2742,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 465  plen */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k2740 in descseq in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2742,2,t0,t1);}
t2=C_fixnum_difference(t1,((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 466  fprintf */
t4=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[6],lf[147],((C_word*)t0)[2],t2);}
else{
t4=t3;
f_2626(2,t4,C_SCHEME_UNDEFINED);}}

/* k2624 in k2740 in descseq in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2626,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_2631(t5,((C_word*)t0)[2],C_fix(0));}

/* loop1 in k2624 in k2740 in descseq in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_2631(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2631,NULL,3,t0,t1,t2);}
t3=C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_fixnum_greater_or_equal_p(t2,C_fix(40)))){
t4=C_fixnum_difference(((C_word*)t0)[8],t2);
/* csi.scm: 470  fprintf */
t5=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[6],lf[142],t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2654,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
t5=C_fixnum_plus(((C_word*)t0)[5],t2);
/* csi.scm: 472  pref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}}

/* k2652 in loop1 in k2624 in k2740 in descseq in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2654,2,t0,t1);}
t2=C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[9],t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2663,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_2663(t7,((C_word*)t0)[2],C_fix(1),t3);}

/* loop2 in k2652 in loop1 in k2624 in k2740 in descseq in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_2663(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2663,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[10]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 475  fprintf */
t5=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[6],lf[146],((C_word*)t0)[9],((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2727,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 482  pref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k2725 in loop2 in k2652 in loop1 in k2624 in k2740 in descseq in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_eqp(((C_word*)t0)[7],t1);
if(C_truep(t2)){
t3=C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* csi.scm: 482  loop2 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2663(t5,((C_word*)t0)[3],t3,t4);}
else{
/* csi.scm: 483  loop2 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2663(t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k2671 in loop2 in k2652 in loop1 in k2624 in k2740 in descseq in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2676,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[6],C_fix(1)))){
t3=C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t4=C_eqp(((C_word*)t0)[6],C_fix(2));
if(C_truep(t4)){
/* csi.scm: 477  fprintf */
t5=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,((C_word*)t0)[2],lf[143],t3,lf[144]);}
else{
/* csi.scm: 477  fprintf */
t5=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,((C_word*)t0)[2],lf[143],t3,lf[145]);}}
else{
/* csi.scm: 480  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[21]+1)))(3,*((C_word*)lf[21]+1),t2,((C_word*)t0)[2]);}}

/* k2674 in k2671 in loop2 in k2652 in loop1 in k2624 in k2740 in descseq in k2615 in ##csi#describe in k2609 in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* csi.scm: 481  loop1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2631(t3,((C_word*)t0)[2],t2);}

/* ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2334(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2r,(void*)f_2334r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2334r(t0,t1,t2);}}

static void C_ccall f_2334r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2342,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t3;
f_2342(2,t4,C_i_car(t2));}
else{
/* csi.scm: 390  current-output-port */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2344,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 390  with-output-to-port */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 392  gc */
((C_proc2)C_retrieve_symbol_proc(lf[134]))(2,*((C_word*)lf[134]+1),t2);}

/* k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 393  ##sys#symbol-table-info */
((C_proc2)C_retrieve_symbol_proc(lf[133]))(2,*((C_word*)lf[133]+1),t2);}

/* k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 394  memory-statistics */
((C_proc2)C_retrieve_symbol_proc(lf[132]))(2,*((C_word*)lf[132]+1),t2);}

/* k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2356,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 396  printf */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[131]);}

/* k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2374,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2479,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2558,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2562,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2564,a[2]=t6,a[3]=t11,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_2564(t13,t9,C_retrieve(lf[6]));}

/* loop401 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_2564(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2564,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[130]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2593,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g417418 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2591 in loop401 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2593,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop401414 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2564(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop401414 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2564(t6,((C_word*)t0)[3],t5);}}

/* k2560 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 404  sort */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[129]+1));}

/* k2556 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 404  chop */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(5));}

/* k2477 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2479,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2481,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2481(t5,((C_word*)t0)[2],t1);}

/* loop372 in k2477 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_2481(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2481,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2489,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2543,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g379380 */
t6=t3;
f_2489(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2541 in loop372 in k2477 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2481(t3,((C_word*)t0)[2],t2);}

/* g379 in loop372 in k2477 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_2489(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2489,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2493,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 399  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t3,lf[128]);}

/* k2491 in g379 in loop372 in k2477 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2493,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2498,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2498(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop384 in k2491 in g379 in loop372 in k2477 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_2498(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2498,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2529,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g391392 */
t6=t3;
f_2506(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2527 in loop384 in k2491 in g379 in loop372 in k2477 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2498(t3,((C_word*)t0)[2],t2);}

/* g391 in loop384 in k2491 in g379 in loop372 in k2477 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_2506(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2506,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2514,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2518,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_string_length(t2);
t6=C_fixnum_difference(C_fix(16),t5);
/* csi.scm: 402  fxmax */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),t4,C_fix(1),t6);}

/* k2516 in g391 in loop384 in k2491 in g379 in loop372 in k2477 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 402  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[126]+1)))(4,*((C_word*)lf[126]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k2512 in g391 in loop384 in k2491 in g379 in loop372 in k2477 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 402  printf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[125],((C_word*)t0)[2],t1);}

/* k2372 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2377,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 418  machine-type */
((C_proc2)C_retrieve_symbol_proc(lf[124]))(2,*((C_word*)lf[124]+1),t3);}

/* k2400 in k2372 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=C_fudge(C_fix(3));
t3=(C_truep(t2)?lf[112]:lf[113]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 420  software-type */
((C_proc2)C_retrieve_symbol_proc(lf[123]))(2,*((C_word*)lf[123]+1),t4);}

/* k2408 in k2400 in k2372 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 421  software-version */
((C_proc2)C_retrieve_symbol_proc(lf[122]))(2,*((C_word*)lf[122]+1),t2);}

/* k2412 in k2408 in k2400 in k2372 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* csi.scm: 422  build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[121]))(2,*((C_word*)lf[121]+1),t2);}

/* k2416 in k2412 in k2408 in k2400 in k2372 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* csi.scm: 424  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[120]))(2,*((C_word*)lf[120]+1),t2);}

/* k2420 in k2416 in k2412 in k2408 in k2400 in k2372 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2426,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t3=C_i_vector_ref(((C_word*)t0)[12],C_fix(0));
/* csi.scm: 426  shorten */
f_2356(t2,t3);}

/* k2424 in k2420 in k2416 in k2412 in k2408 in k2400 in k2372 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2430,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=C_i_vector_ref(((C_word*)t0)[13],C_fix(1));
/* csi.scm: 427  shorten */
f_2356(t2,t3);}

/* k2428 in k2424 in k2420 in k2416 in k2412 in k2408 in k2400 in k2372 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=C_i_vector_ref(((C_word*)t0)[13],C_fix(2));
t3=C_i_vector_ref(((C_word*)t0)[12],C_fix(0));
t4=C_fudge(C_fix(17));
t5=(C_truep(t4)?lf[114]:lf[115]);
t6=C_i_vector_ref(((C_word*)t0)[12],C_fix(1));
t7=C_i_vector_ref(((C_word*)t0)[12],C_fix(2));
t8=C_fudge(C_fix(18));
t9=C_i_nequalp(C_fix(1),t8);
t10=(C_truep(t9)?lf[116]:lf[117]);
/* csi.scm: 405  printf */
t11=((C_word*)t0)[11];
((C_proc19)C_retrieve_proc(t11))(19,t11,((C_word*)t0)[10],lf[118],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_retrieve(lf[119]),((C_word*)t0)[2],t1,t2,t3,t5,t6,t7,t10);}

/* k2375 in k2372 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2380,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 434  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t2,C_make_character(10),*((C_word*)lf[111]+1));}

/* k2378 in k2375 in k2372 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2383,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fudge(C_fix(14)))){
/* csi.scm: 435  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,lf[109]);}
else{
t3=t2;
f_2383(2,t3,C_SCHEME_UNDEFINED);}}

/* k2381 in k2378 in k2375 in k2372 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fudge(C_fix(15)))){
/* csi.scm: 436  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,lf[108]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2384 in k2381 in k2378 in k2375 in k2372 in k2369 in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* shorten in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_2356(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2356,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2364,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_times(&a,2,t2,C_fix(100));
/* csi.scm: 395  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[107]+1)))(3,*((C_word*)lf[107]+1),t3,t4);}

/* k2362 in shorten in k2352 in k2349 in k2346 in a2343 in k2340 in ##csi#report in k2331 in k2328 in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2364,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_divide(&a,2,t1,C_fix(100)));}

/* ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1793(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1793,3,t0,t1,t2);}
if(C_truep(C_eofp(t2))){
/* csi.scm: 268  exit */
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t1);}
else{
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_i_pairp(t2))){
t4=C_slot(t2,C_fix(0));
t5=t3;
f_1809(t5,C_eqp(lf[102],t4));}
else{
t4=t3;
f_1809(t4,C_SCHEME_FALSE);}}}

/* k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_1809(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1809,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1815,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t2,a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_i_symbolp(t2))){
/* csi.scm: 272  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[101]))(4,*((C_word*)lf[101]+1),t3,C_retrieve2(lf[55],"command-table"),t2);}
else{
t4=t3;
f_1815(2,t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2152,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2158,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[12],t2,t3);}}

/* a2157 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2158r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2158r(t0,t1,t2);}}

static void C_ccall f_2158r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2162,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 355  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t2);}

/* k2160 in a2157 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2151 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2152,2,t0,t1);}
/* csi.scm: 354  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1815,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[14];
t3=t1;
t4=C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1826,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g213214 */
t6=t4;
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t2=C_eqp(((C_word*)t0)[13],lf[70]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 279  read */
t4=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=C_eqp(((C_word*)t0)[13],lf[72]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1864,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 283  read */
t5=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=C_eqp(((C_word*)t0)[13],lf[73]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 288  read */
t6=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=C_eqp(((C_word*)t0)[13],lf[75]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1897,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 292  read */
t7=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t6=C_eqp(((C_word*)t0)[13],lf[77]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1912,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 296  read */
t8=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t7=C_eqp(((C_word*)t0)[13],lf[78]);
if(C_truep(t7)){
/* csi.scm: 301  report */
((C_proc2)C_retrieve_symbol_proc(lf[79]))(2,*((C_word*)lf[79]+1),((C_word*)t0)[14]);}
else{
t8=C_eqp(((C_word*)t0)[13],lf[80]);
if(C_truep(t8)){
/* csi.scm: 302  exit */
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),((C_word*)t0)[14]);}
else{
t9=C_eqp(((C_word*)t0)[13],lf[81]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1984,a[2]=t10,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 304  read-line */
t12=((C_word*)t0)[7];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}
else{
t10=C_eqp(((C_word*)t0)[13],lf[83]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2018,a[2]=t11,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 308  read-line */
t13=((C_word*)t0)[7];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t11=C_eqp(((C_word*)t0)[13],lf[88]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2027,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 312  read */
t13=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=C_eqp(((C_word*)t0)[13],lf[92]);
if(C_truep(t12)){
if(C_truep(C_retrieve(lf[93]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2079,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
t14=C_a_i_list(&a,1,C_retrieve(lf[93]));
/* csi.scm: 318  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t13,t14);}
else{
t13=C_SCHEME_UNDEFINED;
t14=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}}
else{
t13=C_eqp(((C_word*)t0)[13],lf[94]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2095,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 321  read-line */
t15=((C_word*)t0)[7];
((C_proc2)C_retrieve_proc(t15))(2,t15,t14);}
else{
t14=C_eqp(((C_word*)t0)[13],lf[96]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2114,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 326  display */
t16=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,lf[99]);}
else{
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2138,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 351  printf */
t16=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t16))(4,t16,t15,lf[100],((C_word*)t0)[2]);}}}}}}}}}}}}}}}

/* k2136 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* k2112 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2117,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2122,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 342  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),t2,t3,C_retrieve2(lf[55],"command-table"));}

/* a2121 in k2112 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2122,4,t0,t1,t2,t3);}
t4=C_i_cdr(t3);
if(C_truep(t4)){
/* csi.scm: 346  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[16]+1)))(4,*((C_word*)lf[16]+1),t1,C_make_character(32),t4);}
else{
/* csi.scm: 347  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[16]+1)))(4,*((C_word*)lf[16]+1),t1,lf[97],t2);}}

/* k2115 in k2112 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* k2093 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2098,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 322  system */
((C_proc3)C_retrieve_symbol_proc(lf[95]))(3,*((C_word*)lf[95]+1),t2,t1);}

/* k2096 in k2093 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2101,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_list(&a,1,t1);
/* csi.scm: 323  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t2,t3);}

/* k2099 in k2096 in k2093 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2077 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 319  describe */
((C_proc3)C_retrieve_symbol_proc(lf[74]))(3,*((C_word*)lf[74]+1),((C_word*)t0)[2],C_retrieve(lf[93]));}

/* k2025 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2032,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2060,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2059 in k2025 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2060(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2060r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2060r(t0,t1,t2);}}

static void C_ccall f_2060r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2064,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 314  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t2);}

/* k2062 in a2059 in k2025 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2031 in k2025 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2036,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[91]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2034 in a2031 in k2025 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2041,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2047,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2046 in k2034 in a2031 in k2025 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2047r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2047r(t0,t1,t2);}}

static void C_ccall f_2047r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2051,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2058,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[90]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2056 in a2046 in k2034 in a2031 in k2025 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
((C_proc3)C_retrieve_symbol_proc(lf[89]))(3,*((C_word*)lf[89]+1),((C_word*)t0)[2],t1);}

/* k2049 in a2046 in k2034 in a2031 in k2025 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2040 in k2034 in a2031 in k2025 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2041,2,t0,t1);}
/* csi.scm: 313  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k2016 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 308  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1991 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1996,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[87]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2000 in k1991 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2001,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2007,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* g273274 */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t2,lf[86],t3);}

/* a2006 in a2000 in k1991 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2007,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2011,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 309  pretty-print */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2009 in a2006 in a2000 in k1991 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 309  print* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),((C_word*)t0)[2],lf[85]);}

/* k1994 in k1991 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* k1982 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 304  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1949 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1954,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1959,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1959(t6,t2,t1);}

/* loop241 in k1949 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_1959(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1959,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[82]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1969,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g248249 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1967 in loop241 in k1949 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1959(t3,((C_word*)t0)[2],t2);}

/* k1952 in k1949 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* k1910 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1915,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 297  read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1913 in k1910 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1918,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 298  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1916 in k1913 in k1910 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1921,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 299  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1919 in k1916 in k1913 in k1910 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 300  dump */
((C_proc4)C_retrieve_symbol_proc(lf[76]))(4,*((C_word*)lf[76]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1895 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 293  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1898 in k1895 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 294  dump */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k1880 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 289  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1883 in k1880 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 290  describe */
((C_proc3)C_retrieve_symbol_proc(lf[74]))(3,*((C_word*)lf[74]+1),((C_word*)t0)[2],t1);}

/* k1862 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 284  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1865 in k1862 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1870,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 285  pretty-print */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1868 in k1865 in k1862 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* k1839 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1844,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1851,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1855,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 280  expand */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k1853 in k1839 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 280  ##sys#strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[71]))(3,*((C_word*)lf[71]+1),((C_word*)t0)[2],t1);}

/* k1849 in k1839 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 280  pretty-print */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1842 in k1839 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* k1824 in k1813 in k1807 in ##sys#repl-eval-hook in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[47]));}

/* toplevel-command in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1752r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1752r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1752r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1756,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_1756(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_1756(2,t7,C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1754 in toplevel-command in k1748 in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1756,2,t0,t1);}
t2=C_i_check_symbol_2(((C_word*)t0)[4],lf[56]);
t3=(C_truep(t1)?C_i_check_string_2(t1,lf[56]):C_SCHEME_UNDEFINED);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* csi.scm: 251  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),((C_word*)t0)[2],C_retrieve2(lf[55],"command-table"),((C_word*)t0)[4],t4);}

/* ##sys#read-prompt-hook in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1743,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_fudge(C_fix(12));
if(C_truep(t3)){
if(C_truep(t3)){
/* csi.scm: 244  old */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
/* csi.scm: 237  ##sys#tty-port? */
((C_proc3)C_retrieve_symbol_proc(lf[51]))(3,*((C_word*)lf[51]+1),t2,*((C_word*)lf[52]+1));}}

/* k1741 in ##sys#read-prompt-hook in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 244  old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##csi#tty-input? in k1719 in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1723,2,t0,t1);}
t2=C_fudge(C_fix(12));
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csi.scm: 237  ##sys#tty-port? */
((C_proc3)C_retrieve_symbol_proc(lf[51]))(3,*((C_word*)lf[51]+1),t1,*((C_word*)lf[52]+1));}}

/* ##csi#history-ref in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1696,3,t0,t1,t2);}
t3=C_i_inexact_to_exact(t2);
t4=C_fixnum_greaterp(t3,C_fix(0));
t5=(C_truep(t4)?C_fixnum_less_or_equal_p(t3,C_retrieve(lf[26])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_vector_ref(C_retrieve(lf[44]),t3));}
else{
/* csi.scm: 229  ##sys#error */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[49],t2);}}

/* ##csi#history-add in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1657,3,t0,t1,t2);}
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_retrieve(lf[47]):C_slot(t2,C_fix(0)));
t5=C_block_size(C_retrieve(lf[44]));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1667,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(C_retrieve(lf[26]),t5))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1681,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=C_fixnum_times(C_fix(2),t5);
/* csi.scm: 220  vector-resize */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve(lf[44]),t8);}
else{
t7=t6;
f_1667(t7,C_SCHEME_UNDEFINED);}}

/* k1679 in ##csi#history-add in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[44]+1 /* (set! ##csi#history-list ...) */,t1);
t3=((C_word*)t0)[2];
f_1667(t3,t2);}

/* k1665 in ##csi#history-add in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_1667(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_vector_set(C_retrieve(lf[44]),C_retrieve(lf[26]),((C_word*)t0)[3]);
t3=C_fixnum_plus(C_retrieve(lf[26]),C_fix(1));
t4=C_mutate((C_word*)lf[26]+1 /* (set! ##csi#history-count ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##csi#lookup-script-file in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1551,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 193  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[42]))(3,*((C_word*)lf[42]+1),t3,lf[43]);}

/* k1553 in ##csi#lookup-script-file in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=C_block_size(((C_word*)t0)[5]);
if(C_truep(C_i_greaterp(t2,C_fix(0)))){
t3=C_i_string_ref(((C_word*)t0)[5],C_fix(0));
t4=C_eqp(t3,C_make_character(92));
t5=(C_truep(t4)?t4:C_eqp(t3,C_make_character(47)));
if(C_truep(t5)){
/* csi.scm: 195  addext */
f_1503(((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t6=C_retrieve2(lf[29],"dirseparator\077");
t7=((C_word*)t0)[5];
t8=C_block_size(t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1530,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=f_1530(t9,C_fix(0));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1579,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t12=((C_word*)t0)[2];
t13=C_a_i_bytevector(&a,1,C_fix(3));
t14=(C_truep(t12)?C_i_foreign_block_argumentp(t12):C_SCHEME_FALSE);
t15=C_i_foreign_fixnum_argumentp(C_fix(256));
t16=stub75(t13,t14,t15);
/* ##sys#peek-nonnull-c-string */
t17=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t11,t16,C_fix(0));}
else{
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1596,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 199  addext */
f_1503(t11,((C_word*)t0)[5]);}}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1594 in k1553 in ##csi#lookup-script-file in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1596,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1602,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 201  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[34]+1)))(4,*((C_word*)lf[34]+1),t2,lf[41],((C_word*)t0)[2]);}}

/* k1600 in k1594 in k1553 in ##csi#lookup-script-file in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1609,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 202  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[39]))(4,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2],lf[40]);}

/* k1607 in k1600 in k1594 in k1553 in ##csi#lookup-script-file in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1609,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1611(t5,((C_word*)t0)[2],t1);}

/* loop in k1607 in k1600 in k1594 in k1553 in ##csi#lookup-script-file in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_1611(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1611,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1621,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1638,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_slot(t2,C_fix(0));
/* csi.scm: 204  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[31]))(3,*((C_word*)lf[31]+1),t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1636 in loop in k1607 in k1600 in k1594 in k1553 in ##csi#lookup-script-file in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 204  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[34]+1)))(4,*((C_word*)lf[34]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1619 in loop in k1607 in k1600 in k1594 in k1553 in ##csi#lookup-script-file in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 205  addext */
f_1503(t2,t1);}

/* k1622 in k1619 in loop in k1607 in k1600 in k1594 in k1553 in ##csi#lookup-script-file in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 206  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1611(t3,((C_word*)t0)[4],t2);}}

/* k1577 in k1553 in ##csi#lookup-script-file in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1579,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1589,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1593,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 198  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[31]))(3,*((C_word*)lf[31]+1),t3,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1591 in k1577 in k1553 in ##csi#lookup-script-file in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 198  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[34]+1)))(5,*((C_word*)lf[34]+1),((C_word*)t0)[3],t1,lf[37],((C_word*)t0)[2]);}

/* k1587 in k1577 in k1553 in ##csi#lookup-script-file in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 198  addext */
f_1503(((C_word*)t0)[2],t1);}

/* loop in k1553 in ##csi#lookup-script-file in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static C_word C_fcall f_1530(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
return(C_SCHEME_FALSE);}
else{
t2=C_subchar(((C_word*)t0)[2],t1);
t3=C_eqp(t2,C_make_character(92));
t4=(C_truep(t3)?t3:C_eqp(t2,C_make_character(47)));
if(C_truep(t4)){
return(t1);}
else{
t5=C_fixnum_plus(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* addext in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_1503(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1503,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1510,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 182  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),t3,t2);}

/* k1508 in addext in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1510,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1513,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 184  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[34]+1)))(4,*((C_word*)lf[34]+1),t2,((C_word*)t0)[3],lf[35]);}}

/* k1511 in k1508 in addext in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1519,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 185  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),t2,t1);}

/* k1517 in k1511 in k1508 in addext in k1482 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##csi#chop-separator in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1453,3,t0,t1,t2);}
t3=C_block_size(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
t5=C_i_string_ref(t2,t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1466,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greaterp(t4,C_fix(0)))){
t7=C_eqp(t5,C_make_character(92));
t8=t6;
f_1466(t8,(C_truep(t7)?t7:C_eqp(t5,C_make_character(47))));}
else{
t7=t6;
f_1466(t7,C_SCHEME_FALSE);}}

/* k1464 in ##csi#chop-separator in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_fcall f_1466(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 170  substring */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* dirseparator? in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1441,3,t0,t1,t2);}
t3=C_eqp(t2,C_make_character(92));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:C_eqp(t2,C_make_character(47))));}

/* ##sys#sharp-number-hook in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1427,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1439,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 156  history-ref */
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t4,t3);}

/* k1437 in ##sys#sharp-number-hook in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1439,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[25],t2));}

/* ##sys#user-read-hook in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1394,4,t0,t1,t2,t3);}
t4=C_eqp(C_make_character(41),t2);
t5=(C_truep(t4)?t4:C_u_i_char_whitespacep(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1415,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_fixnum_difference(C_retrieve(lf[26]),C_fix(1));
/* csi.scm: 151  history-ref */
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t6,t7);}
else{
/* csi.scm: 152  old-hook */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t2,t3);}}

/* k1413 in ##sys#user-read-hook in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1415,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[25],t2));}

/* ##csi#print-banner in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1382,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 121  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[21]+1)))(2,*((C_word*)lf[21]+1),t2);}

/* k1380 in ##csi#print-banner in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1385,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 139  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[16]+1)))(3,*((C_word*)lf[16]+1),t2,lf[20]);}

/* k1383 in k1380 in ##csi#print-banner in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 140  chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,C_SCHEME_TRUE);}

/* k1390 in k1383 in k1380 in ##csi#print-banner in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 140  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[16]+1)))(5,*((C_word*)lf[16]+1),((C_word*)t0)[2],lf[17],t1,lf[18]);}

/* ##csi#print-usage in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1354,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 73   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t2,lf[14]);}

/* k1352 in ##csi#print-usage in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1357,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1364,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_cons(&a,2,lf[11],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[2],t4);
t6=C_a_i_cons(&a,2,lf[12],t5);
/* csi.scm: 93   ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[13]))(3,*((C_word*)lf[13]+1),t3,t6);}

/* k1362 in k1352 in ##csi#print-usage in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 93   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),((C_word*)t0)[2],t1);}

/* k1355 in k1352 in ##csi#print-usage in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 98   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[10]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[405] = {
{"toplevel:csi_scm",(void*)C_toplevel},
{"f_1324:csi_scm",(void*)f_1324},
{"f_1327:csi_scm",(void*)f_1327},
{"f_1330:csi_scm",(void*)f_1330},
{"f_1333:csi_scm",(void*)f_1333},
{"f_1336:csi_scm",(void*)f_1336},
{"f_1339:csi_scm",(void*)f_1339},
{"f_1484:csi_scm",(void*)f_1484},
{"f_5231:csi_scm",(void*)f_5231},
{"f_1721:csi_scm",(void*)f_1721},
{"f_1750:csi_scm",(void*)f_1750},
{"f_2330:csi_scm",(void*)f_2330},
{"f_2333:csi_scm",(void*)f_2333},
{"f_2611:csi_scm",(void*)f_2611},
{"f_5220:csi_scm",(void*)f_5220},
{"f_5226:csi_scm",(void*)f_5226},
{"f_5223:csi_scm",(void*)f_5223},
{"f_4194:csi_scm",(void*)f_4194},
{"f_5214:csi_scm",(void*)f_5214},
{"f_2195:csi_scm",(void*)f_2195},
{"f_2259:csi_scm",(void*)f_2259},
{"f_2277:csi_scm",(void*)f_2277},
{"f_2316:csi_scm",(void*)f_2316},
{"f_2322:csi_scm",(void*)f_2322},
{"f_2283:csi_scm",(void*)f_2283},
{"f_2291:csi_scm",(void*)f_2291},
{"f_2293:csi_scm",(void*)f_2293},
{"f_2310:csi_scm",(void*)f_2310},
{"f_2265:csi_scm",(void*)f_2265},
{"f_2271:csi_scm",(void*)f_2271},
{"f_2202:csi_scm",(void*)f_2202},
{"f_2205:csi_scm",(void*)f_2205},
{"f_2207:csi_scm",(void*)f_2207},
{"f_2244:csi_scm",(void*)f_2244},
{"f_2247:csi_scm",(void*)f_2247},
{"f_2253:csi_scm",(void*)f_2253},
{"f_2217:csi_scm",(void*)f_2217},
{"f_4198:csi_scm",(void*)f_4198},
{"f_5210:csi_scm",(void*)f_5210},
{"f_4201:csi_scm",(void*)f_4201},
{"f_4204:csi_scm",(void*)f_4204},
{"f_4207:csi_scm",(void*)f_4207},
{"f_5206:csi_scm",(void*)f_5206},
{"f_5193:csi_scm",(void*)f_5193},
{"f_5103:csi_scm",(void*)f_5103},
{"f_5106:csi_scm",(void*)f_5106},
{"f_5109:csi_scm",(void*)f_5109},
{"f_5112:csi_scm",(void*)f_5112},
{"f_5121:csi_scm",(void*)f_5121},
{"f_4210:csi_scm",(void*)f_4210},
{"f_4213:csi_scm",(void*)f_4213},
{"f_5097:csi_scm",(void*)f_5097},
{"f_4216:csi_scm",(void*)f_4216},
{"f_4219:csi_scm",(void*)f_4219},
{"f_4222:csi_scm",(void*)f_4222},
{"f_5088:csi_scm",(void*)f_5088},
{"f_5049:csi_scm",(void*)f_5049},
{"f_5051:csi_scm",(void*)f_5051},
{"f_5080:csi_scm",(void*)f_5080},
{"f_4225:csi_scm",(void*)f_4225},
{"f_4382:csi_scm",(void*)f_4382},
{"f_5038:csi_scm",(void*)f_5038},
{"f_5041:csi_scm",(void*)f_5041},
{"f_4385:csi_scm",(void*)f_4385},
{"f_5029:csi_scm",(void*)f_5029},
{"f_5032:csi_scm",(void*)f_5032},
{"f_4388:csi_scm",(void*)f_4388},
{"f_4391:csi_scm",(void*)f_4391},
{"f_5022:csi_scm",(void*)f_5022},
{"f_5015:csi_scm",(void*)f_5015},
{"f_4394:csi_scm",(void*)f_4394},
{"f_5002:csi_scm",(void*)f_5002},
{"f_5005:csi_scm",(void*)f_5005},
{"f_4397:csi_scm",(void*)f_4397},
{"f_4996:csi_scm",(void*)f_4996},
{"f_4400:csi_scm",(void*)f_4400},
{"f_4981:csi_scm",(void*)f_4981},
{"f5767:csi_scm",(void*)f5767},
{"f_4984:csi_scm",(void*)f_4984},
{"f_4987:csi_scm",(void*)f_4987},
{"f_4403:csi_scm",(void*)f_4403},
{"f_4955:csi_scm",(void*)f_4955},
{"f_4957:csi_scm",(void*)f_4957},
{"f_4967:csi_scm",(void*)f_4967},
{"f_4406:csi_scm",(void*)f_4406},
{"f_4928:csi_scm",(void*)f_4928},
{"f_4930:csi_scm",(void*)f_4930},
{"f_4940:csi_scm",(void*)f_4940},
{"f_4409:csi_scm",(void*)f_4409},
{"f_4889:csi_scm",(void*)f_4889},
{"f_4891:csi_scm",(void*)f_4891},
{"f_4920:csi_scm",(void*)f_4920},
{"f_4842:csi_scm",(void*)f_4842},
{"f_4850:csi_scm",(void*)f_4850},
{"f_4852:csi_scm",(void*)f_4852},
{"f_4881:csi_scm",(void*)f_4881},
{"f_4846:csi_scm",(void*)f_4846},
{"f_4838:csi_scm",(void*)f_4838},
{"f_4413:csi_scm",(void*)f_4413},
{"f_4416:csi_scm",(void*)f_4416},
{"f_4769:csi_scm",(void*)f_4769},
{"f_4772:csi_scm",(void*)f_4772},
{"f_4419:csi_scm",(void*)f_4419},
{"f_4757:csi_scm",(void*)f_4757},
{"f_4760:csi_scm",(void*)f_4760},
{"f_4422:csi_scm",(void*)f_4422},
{"f_4736:csi_scm",(void*)f_4736},
{"f_4739:csi_scm",(void*)f_4739},
{"f_4742:csi_scm",(void*)f_4742},
{"f_4745:csi_scm",(void*)f_4745},
{"f_4748:csi_scm",(void*)f_4748},
{"f_4425:csi_scm",(void*)f_4425},
{"f_4727:csi_scm",(void*)f_4727},
{"f_4279:csi_scm",(void*)f_4279},
{"f_4285:csi_scm",(void*)f_4285},
{"f_4307:csi_scm",(void*)f_4307},
{"f_4291:csi_scm",(void*)f_4291},
{"f_4294:csi_scm",(void*)f_4294},
{"f_4300:csi_scm",(void*)f_4300},
{"f_4428:csi_scm",(void*)f_4428},
{"f_4431:csi_scm",(void*)f_4431},
{"f_4436:csi_scm",(void*)f_4436},
{"f_4649:csi_scm",(void*)f_4649},
{"f_4704:csi_scm",(void*)f_4704},
{"f_4653:csi_scm",(void*)f_4653},
{"f_4659:csi_scm",(void*)f_4659},
{"f_4662:csi_scm",(void*)f_4662},
{"f_4673:csi_scm",(void*)f_4673},
{"f_4686:csi_scm",(void*)f_4686},
{"f_4689:csi_scm",(void*)f_4689},
{"f_4665:csi_scm",(void*)f_4665},
{"f_4668:csi_scm",(void*)f_4668},
{"f_4596:csi_scm",(void*)f_4596},
{"f_4617:csi_scm",(void*)f_4617},
{"f_4607:csi_scm",(void*)f_4607},
{"f_4615:csi_scm",(void*)f_4615},
{"f_4586:csi_scm",(void*)f_4586},
{"f_4576:csi_scm",(void*)f_4576},
{"f_4560:csi_scm",(void*)f_4560},
{"f_4550:csi_scm",(void*)f_4550},
{"f_4530:csi_scm",(void*)f_4530},
{"f_4514:csi_scm",(void*)f_4514},
{"f_4490:csi_scm",(void*)f_4490},
{"f_4461:csi_scm",(void*)f_4461},
{"f_4449:csi_scm",(void*)f_4449},
{"f_4312:csi_scm",(void*)f_4312},
{"f_4359:csi_scm",(void*)f_4359},
{"f_4316:csi_scm",(void*)f_4316},
{"f_4319:csi_scm",(void*)f_4319},
{"f_4326:csi_scm",(void*)f_4326},
{"f_4328:csi_scm",(void*)f_4328},
{"f_4351:csi_scm",(void*)f_4351},
{"f_4349:csi_scm",(void*)f_4349},
{"f_4338:csi_scm",(void*)f_4338},
{"f_4345:csi_scm",(void*)f_4345},
{"f_4227:csi_scm",(void*)f_4227},
{"f_4233:csi_scm",(void*)f_4233},
{"f_4241:csi_scm",(void*)f_4241},
{"f_4262:csi_scm",(void*)f_4262},
{"f_4049:csi_scm",(void*)f_4049},
{"f_4055:csi_scm",(void*)f_4055},
{"f_4077:csi_scm",(void*)f_4077},
{"f_4134:csi_scm",(void*)f_4134},
{"f_4127:csi_scm",(void*)f_4127},
{"f_4093:csi_scm",(void*)f_4093},
{"f_4116:csi_scm",(void*)f_4116},
{"f_4106:csi_scm",(void*)f_4106},
{"f_4110:csi_scm",(void*)f_4110},
{"f_4166:csi_scm",(void*)f_4166},
{"f_3992:csi_scm",(void*)f_3992},
{"f_3998:csi_scm",(void*)f_3998},
{"f_4010:csi_scm",(void*)f_4010},
{"f_3933:csi_scm",(void*)f_3933},
{"f_3937:csi_scm",(void*)f_3937},
{"f_3942:csi_scm",(void*)f_3942},
{"f_3971:csi_scm",(void*)f_3971},
{"f_3958:csi_scm",(void*)f_3958},
{"f_3895:csi_scm",(void*)f_3895},
{"f_3901:csi_scm",(void*)f_3901},
{"f_3917:csi_scm",(void*)f_3917},
{"f_3927:csi_scm",(void*)f_3927},
{"f_3686:csi_scm",(void*)f_3686},
{"f_3718:csi_scm",(void*)f_3718},
{"f_3893:csi_scm",(void*)f_3893},
{"f_3728:csi_scm",(void*)f_3728},
{"f_3731:csi_scm",(void*)f_3731},
{"f_3803:csi_scm",(void*)f_3803},
{"f_3864:csi_scm",(void*)f_3864},
{"f_3886:csi_scm",(void*)f_3886},
{"f_3882:csi_scm",(void*)f_3882},
{"f_3867:csi_scm",(void*)f_3867},
{"f_3822:csi_scm",(void*)f_3822},
{"f_3840:csi_scm",(void*)f_3840},
{"f_3850:csi_scm",(void*)f_3850},
{"f_3734:csi_scm",(void*)f_3734},
{"f_3737:csi_scm",(void*)f_3737},
{"f_3752:csi_scm",(void*)f_3752},
{"f_3765:csi_scm",(void*)f_3765},
{"f_3768:csi_scm",(void*)f_3768},
{"f_3740:csi_scm",(void*)f_3740},
{"f_3743:csi_scm",(void*)f_3743},
{"f_3689:csi_scm",(void*)f_3689},
{"f_3693:csi_scm",(void*)f_3693},
{"f_3709:csi_scm",(void*)f_3709},
{"f_3525:csi_scm",(void*)f_3525},
{"f_3638:csi_scm",(void*)f_3638},
{"f_3633:csi_scm",(void*)f_3633},
{"f_3527:csi_scm",(void*)f_3527},
{"f_3552:csi_scm",(void*)f_3552},
{"f_3595:csi_scm",(void*)f_3595},
{"f_3605:csi_scm",(void*)f_3605},
{"f_3576:csi_scm",(void*)f_3576},
{"f_3559:csi_scm",(void*)f_3559},
{"f_3530:csi_scm",(void*)f_3530},
{"f_3516:csi_scm",(void*)f_3516},
{"f_3520:csi_scm",(void*)f_3520},
{"f_2613:csi_scm",(void*)f_2613},
{"f_2617:csi_scm",(void*)f_2617},
{"f_3495:csi_scm",(void*)f_3495},
{"f_2745:csi_scm",(void*)f_2745},
{"f_3074:csi_scm",(void*)f_3074},
{"f_3102:csi_scm",(void*)f_3102},
{"f_3111:csi_scm",(void*)f_3111},
{"f_3205:csi_scm",(void*)f_3205},
{"f_3361:csi_scm",(void*)f_3361},
{"f_3376:csi_scm",(void*)f_3376},
{"f_3455:csi_scm",(void*)f_3455},
{"f_3394:csi_scm",(void*)f_3394},
{"f_3416:csi_scm",(void*)f_3416},
{"f_3445:csi_scm",(void*)f_3445},
{"f_3406:csi_scm",(void*)f_3406},
{"f_3402:csi_scm",(void*)f_3402},
{"f_3380:csi_scm",(void*)f_3380},
{"f_3272:csi_scm",(void*)f_3272},
{"f_3281:csi_scm",(void*)f_3281},
{"f_3340:csi_scm",(void*)f_3340},
{"f_3289:csi_scm",(void*)f_3289},
{"f_3293:csi_scm",(void*)f_3293},
{"f_3302:csi_scm",(void*)f_3302},
{"f_3337:csi_scm",(void*)f_3337},
{"f_3329:csi_scm",(void*)f_3329},
{"f_3312:csi_scm",(void*)f_3312},
{"f_3236:csi_scm",(void*)f_3236},
{"f_3239:csi_scm",(void*)f_3239},
{"f_3244:csi_scm",(void*)f_3244},
{"f_3224:csi_scm",(void*)f_3224},
{"f_3211:csi_scm",(void*)f_3211},
{"f_3199:csi_scm",(void*)f_3199},
{"f_3118:csi_scm",(void*)f_3118},
{"f_3093:csi_scm",(void*)f_3093},
{"f_3034:csi_scm",(void*)f_3034},
{"f_3048:csi_scm",(void*)f_3048},
{"f_3044:csi_scm",(void*)f_3044},
{"f_2990:csi_scm",(void*)f_2990},
{"f_2883:csi_scm",(void*)f_2883},
{"f_2886:csi_scm",(void*)f_2886},
{"f_2889:csi_scm",(void*)f_2889},
{"f_2967:csi_scm",(void*)f_2967},
{"f_2958:csi_scm",(void*)f_2958},
{"f_2892:csi_scm",(void*)f_2892},
{"f_2904:csi_scm",(void*)f_2904},
{"f_2909:csi_scm",(void*)f_2909},
{"f_2919:csi_scm",(void*)f_2919},
{"f_2934:csi_scm",(void*)f_2934},
{"f_2922:csi_scm",(void*)f_2922},
{"f_2925:csi_scm",(void*)f_2925},
{"f_2814:csi_scm",(void*)f_2814},
{"f_2820:csi_scm",(void*)f_2820},
{"f_2748:csi_scm",(void*)f_2748},
{"f_2619:csi_scm",(void*)f_2619},
{"f_2742:csi_scm",(void*)f_2742},
{"f_2626:csi_scm",(void*)f_2626},
{"f_2631:csi_scm",(void*)f_2631},
{"f_2654:csi_scm",(void*)f_2654},
{"f_2663:csi_scm",(void*)f_2663},
{"f_2727:csi_scm",(void*)f_2727},
{"f_2673:csi_scm",(void*)f_2673},
{"f_2676:csi_scm",(void*)f_2676},
{"f_2334:csi_scm",(void*)f_2334},
{"f_2342:csi_scm",(void*)f_2342},
{"f_2344:csi_scm",(void*)f_2344},
{"f_2348:csi_scm",(void*)f_2348},
{"f_2351:csi_scm",(void*)f_2351},
{"f_2354:csi_scm",(void*)f_2354},
{"f_2371:csi_scm",(void*)f_2371},
{"f_2564:csi_scm",(void*)f_2564},
{"f_2593:csi_scm",(void*)f_2593},
{"f_2562:csi_scm",(void*)f_2562},
{"f_2558:csi_scm",(void*)f_2558},
{"f_2479:csi_scm",(void*)f_2479},
{"f_2481:csi_scm",(void*)f_2481},
{"f_2543:csi_scm",(void*)f_2543},
{"f_2489:csi_scm",(void*)f_2489},
{"f_2493:csi_scm",(void*)f_2493},
{"f_2498:csi_scm",(void*)f_2498},
{"f_2529:csi_scm",(void*)f_2529},
{"f_2506:csi_scm",(void*)f_2506},
{"f_2518:csi_scm",(void*)f_2518},
{"f_2514:csi_scm",(void*)f_2514},
{"f_2374:csi_scm",(void*)f_2374},
{"f_2402:csi_scm",(void*)f_2402},
{"f_2410:csi_scm",(void*)f_2410},
{"f_2414:csi_scm",(void*)f_2414},
{"f_2418:csi_scm",(void*)f_2418},
{"f_2422:csi_scm",(void*)f_2422},
{"f_2426:csi_scm",(void*)f_2426},
{"f_2430:csi_scm",(void*)f_2430},
{"f_2377:csi_scm",(void*)f_2377},
{"f_2380:csi_scm",(void*)f_2380},
{"f_2383:csi_scm",(void*)f_2383},
{"f_2386:csi_scm",(void*)f_2386},
{"f_2356:csi_scm",(void*)f_2356},
{"f_2364:csi_scm",(void*)f_2364},
{"f_1793:csi_scm",(void*)f_1793},
{"f_1809:csi_scm",(void*)f_1809},
{"f_2158:csi_scm",(void*)f_2158},
{"f_2162:csi_scm",(void*)f_2162},
{"f_2152:csi_scm",(void*)f_2152},
{"f_1815:csi_scm",(void*)f_1815},
{"f_2138:csi_scm",(void*)f_2138},
{"f_2114:csi_scm",(void*)f_2114},
{"f_2122:csi_scm",(void*)f_2122},
{"f_2117:csi_scm",(void*)f_2117},
{"f_2095:csi_scm",(void*)f_2095},
{"f_2098:csi_scm",(void*)f_2098},
{"f_2101:csi_scm",(void*)f_2101},
{"f_2079:csi_scm",(void*)f_2079},
{"f_2027:csi_scm",(void*)f_2027},
{"f_2060:csi_scm",(void*)f_2060},
{"f_2064:csi_scm",(void*)f_2064},
{"f_2032:csi_scm",(void*)f_2032},
{"f_2036:csi_scm",(void*)f_2036},
{"f_2047:csi_scm",(void*)f_2047},
{"f_2058:csi_scm",(void*)f_2058},
{"f_2051:csi_scm",(void*)f_2051},
{"f_2041:csi_scm",(void*)f_2041},
{"f_2018:csi_scm",(void*)f_2018},
{"f_1993:csi_scm",(void*)f_1993},
{"f_2001:csi_scm",(void*)f_2001},
{"f_2007:csi_scm",(void*)f_2007},
{"f_2011:csi_scm",(void*)f_2011},
{"f_1996:csi_scm",(void*)f_1996},
{"f_1984:csi_scm",(void*)f_1984},
{"f_1951:csi_scm",(void*)f_1951},
{"f_1959:csi_scm",(void*)f_1959},
{"f_1969:csi_scm",(void*)f_1969},
{"f_1954:csi_scm",(void*)f_1954},
{"f_1912:csi_scm",(void*)f_1912},
{"f_1915:csi_scm",(void*)f_1915},
{"f_1918:csi_scm",(void*)f_1918},
{"f_1921:csi_scm",(void*)f_1921},
{"f_1897:csi_scm",(void*)f_1897},
{"f_1900:csi_scm",(void*)f_1900},
{"f_1882:csi_scm",(void*)f_1882},
{"f_1885:csi_scm",(void*)f_1885},
{"f_1864:csi_scm",(void*)f_1864},
{"f_1867:csi_scm",(void*)f_1867},
{"f_1870:csi_scm",(void*)f_1870},
{"f_1841:csi_scm",(void*)f_1841},
{"f_1855:csi_scm",(void*)f_1855},
{"f_1851:csi_scm",(void*)f_1851},
{"f_1844:csi_scm",(void*)f_1844},
{"f_1826:csi_scm",(void*)f_1826},
{"f_1752:csi_scm",(void*)f_1752},
{"f_1756:csi_scm",(void*)f_1756},
{"f_1736:csi_scm",(void*)f_1736},
{"f_1743:csi_scm",(void*)f_1743},
{"f_1723:csi_scm",(void*)f_1723},
{"f_1696:csi_scm",(void*)f_1696},
{"f_1657:csi_scm",(void*)f_1657},
{"f_1681:csi_scm",(void*)f_1681},
{"f_1667:csi_scm",(void*)f_1667},
{"f_1551:csi_scm",(void*)f_1551},
{"f_1555:csi_scm",(void*)f_1555},
{"f_1596:csi_scm",(void*)f_1596},
{"f_1602:csi_scm",(void*)f_1602},
{"f_1609:csi_scm",(void*)f_1609},
{"f_1611:csi_scm",(void*)f_1611},
{"f_1638:csi_scm",(void*)f_1638},
{"f_1621:csi_scm",(void*)f_1621},
{"f_1624:csi_scm",(void*)f_1624},
{"f_1579:csi_scm",(void*)f_1579},
{"f_1593:csi_scm",(void*)f_1593},
{"f_1589:csi_scm",(void*)f_1589},
{"f_1530:csi_scm",(void*)f_1530},
{"f_1503:csi_scm",(void*)f_1503},
{"f_1510:csi_scm",(void*)f_1510},
{"f_1513:csi_scm",(void*)f_1513},
{"f_1519:csi_scm",(void*)f_1519},
{"f_1453:csi_scm",(void*)f_1453},
{"f_1466:csi_scm",(void*)f_1466},
{"f_1441:csi_scm",(void*)f_1441},
{"f_1427:csi_scm",(void*)f_1427},
{"f_1439:csi_scm",(void*)f_1439},
{"f_1394:csi_scm",(void*)f_1394},
{"f_1415:csi_scm",(void*)f_1415},
{"f_1378:csi_scm",(void*)f_1378},
{"f_1382:csi_scm",(void*)f_1382},
{"f_1385:csi_scm",(void*)f_1385},
{"f_1392:csi_scm",(void*)f_1392},
{"f_1350:csi_scm",(void*)f_1350},
{"f_1354:csi_scm",(void*)f_1354},
{"f_1364:csi_scm",(void*)f_1364},
{"f_1357:csi_scm",(void*)f_1357},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
