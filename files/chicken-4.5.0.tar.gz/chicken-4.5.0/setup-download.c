/* Generated from setup-download.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:54
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: setup-download.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature chicken-compile-shared -dynamic -emit-import-library setup-download -ignore-repository -output-file setup-download.c
   used units: library eval extras regex posix utils srfi_1 data_structures tcp srfi_13 files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[190];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,34),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,100,32,102,115,116,114,49,53,49,32,97,114,103,115,49,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,40),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,103,101,116,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,57),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,101,120,105,115,116,105,110,103,45,118,101,114,115,105,111,110,32,101,103,103,49,54,52,32,118,101,114,115,105,111,110,49,54,53,32,118,115,49,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,20),40,98,111,100,121,50,49,51,32,118,101,114,115,105,111,110,50,50,50,41,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,100,101,115,116,105,110,97,116,105,111,110,50,49,54,32,37,118,101,114,115,105,111,110,50,49,49,50,51,57,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,118,101,114,115,105,111,110,50,49,53,41};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,59),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,108,111,99,97,108,32,101,103,103,50,48,53,32,100,105,114,50,48,54,32,46,32,116,109,112,50,48,52,50,48,55,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,7),40,97,49,48,56,57,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,7),40,97,49,49,52,55,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,13),40,97,49,49,52,49,32,101,120,50,55,48,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,7),40,97,49,49,54,50,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,7),40,97,49,49,55,52,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,20),40,97,49,49,54,56,32,46,32,97,114,103,115,50,54,53,50,55,50,41,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,7),40,97,49,49,53,54,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,15),40,97,49,49,51,53,32,107,50,54,52,50,54,57,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,17),40,97,49,49,49,48,32,114,101,116,117,114,110,50,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,37),40,97,49,48,57,53,32,108,111,99,50,53,50,50,53,51,50,53,54,32,118,101,114,115,105,111,110,50,53,52,50,53,53,50,53,55,41,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,14),40,97,49,48,56,51,32,101,103,103,50,52,57,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,103,97,116,104,101,114,45,101,103,103,45,105,110,102,111,114,109,97,116,105,111,110,32,100,105,114,50,52,55,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,66),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,109,97,107,101,45,115,118,110,45,108,115,45,99,109,100,32,117,97,114,103,50,56,48,32,112,97,114,103,50,56,49,32,112,110,97,109,50,56,50,32,116,109,112,50,55,57,50,56,51,41,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,7),40,97,49,51,54,51,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,37),40,97,49,51,57,49,32,102,105,108,101,100,105,114,51,57,55,51,57,56,52,48,50,32,118,101,114,51,57,57,52,48,48,52,48,51,41,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,12),40,97,49,52,51,52,32,102,51,57,48,41,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,59),40,98,111,100,121,51,54,56,32,118,101,114,115,105,111,110,51,55,57,32,100,101,115,116,105,110,97,116,105,111,110,51,56,48,32,117,115,101,114,110,97,109,101,51,56,49,32,112,97,115,115,119,111,114,100,51,56,50,41,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,67),40,100,101,102,45,112,97,115,115,119,111,114,100,51,55,51,32,37,118,101,114,115,105,111,110,51,54,52,52,49,55,32,37,100,101,115,116,105,110,97,116,105,111,110,51,54,53,52,49,56,32,37,117,115,101,114,110,97,109,101,51,54,54,52,49,57,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,51),40,100,101,102,45,117,115,101,114,110,97,109,101,51,55,50,32,37,118,101,114,115,105,111,110,51,54,52,52,50,49,32,37,100,101,115,116,105,110,97,116,105,111,110,51,54,53,52,50,50,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,100,101,115,116,105,110,97,116,105,111,110,51,55,49,32,37,118,101,114,115,105,111,110,51,54,52,52,50,52,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,118,101,114,115,105,111,110,51,55,48,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,115,118,110,32,101,103,103,51,53,56,32,114,101,112,111,51,53,57,32,46,32,116,109,112,51,53,55,51,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,7),40,97,49,54,48,57,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,7),40,97,49,56,55,52,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,50,48,50,53,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,20),40,103,101,116,45,102,105,108,101,115,32,102,105,108,101,115,54,50,56,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,20),40,103,101,116,45,99,104,117,110,107,115,32,100,97,116,97,54,55,52,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,7),40,97,49,56,49,56,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,7),40,97,49,56,50,49,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,7),40,97,49,56,50,52,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,7),40,97,49,56,50,55,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,32),40,97,49,56,56,56,32,105,110,53,56,54,53,56,55,54,48,48,32,111,117,116,53,56,56,53,56,57,54,48,49,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,49),40,97,49,54,49,53,32,104,111,115,116,52,56,55,52,56,56,52,57,51,32,112,111,114,116,52,56,57,52,57,48,52,57,52,32,108,111,99,110,52,57,49,52,57,50,52,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,72),40,98,111,100,121,52,54,50,32,118,101,114,115,105,111,110,52,55,52,32,100,101,115,116,105,110,97,116,105,111,110,52,55,53,32,116,101,115,116,115,52,55,54,32,112,114,111,120,121,45,104,111,115,116,52,55,55,32,112,114,111,120,121,45,112,111,114,116,52,55,56,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,84),40,100,101,102,45,112,114,111,120,121,45,112,111,114,116,52,54,56,32,37,118,101,114,115,105,111,110,52,53,55,53,49,49,32,37,100,101,115,116,105,110,97,116,105,111,110,52,53,56,53,49,50,32,37,116,101,115,116,115,52,53,57,53,49,51,32,37,112,114,111,120,121,45,104,111,115,116,52,54,48,53,49,52,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,66),40,100,101,102,45,112,114,111,120,121,45,104,111,115,116,52,54,55,32,37,118,101,114,115,105,111,110,52,53,55,53,49,54,32,37,100,101,115,116,105,110,97,116,105,111,110,52,53,56,53,49,55,32,37,116,101,115,116,115,52,53,57,53,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,48),40,100,101,102,45,116,101,115,116,115,52,54,54,32,37,118,101,114,115,105,111,110,52,53,55,53,50,48,32,37,100,101,115,116,105,110,97,116,105,111,110,52,53,56,53,50,49,41};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,100,101,115,116,105,110,97,116,105,111,110,52,54,53,32,37,118,101,114,115,105,111,110,52,53,55,53,50,51,41,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,118,101,114,115,105,111,110,52,54,52,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,104,116,116,112,32,101,103,103,52,53,49,32,117,114,108,52,53,50,32,46,32,116,109,112,52,53,48,52,53,51,41,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,7),40,97,50,50,49,52,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,50,50,50,49,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,7),40,97,50,50,54,48,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,80),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,114,101,116,114,105,101,118,101,45,101,120,116,101,110,115,105,111,110,32,110,97,109,101,54,56,54,32,116,114,97,110,115,112,111,114,116,54,56,55,32,108,111,99,97,116,105,111,110,54,56,56,32,46,32,116,109,112,54,56,53,54,56,57,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,7),40,97,50,50,56,50,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,17),40,97,57,52,50,32,103,49,57,51,49,57,52,49,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,51,50,49,32,103,51,51,49,51,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,33),40,98,111,100,121,51,48,53,32,117,115,101,114,110,97,109,101,51,49,52,32,112,97,115,115,119,111,114,100,51,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,112,97,115,115,119,111,114,100,51,48,56,32,37,117,115,101,114,110,97,109,101,51,48,51,51,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,117,115,101,114,110,97,109,101,51,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,7),40,97,50,50,56,55,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,7),40,97,50,51,49,49,41,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,69),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,105,115,116,45,101,120,116,101,110,115,105,111,110,115,32,116,114,97,110,115,112,111,114,116,55,51,55,32,108,111,99,97,116,105,111,110,55,51,56,32,46,32,116,109,112,55,51,54,55,51,57,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_813)
static void C_ccall f_813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_816)
static void C_ccall f_816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_819)
static void C_ccall f_819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_822)
static void C_ccall f_822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_825)
static void C_ccall f_825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_828)
static void C_ccall f_828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_831)
static void C_ccall f_831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_834)
static void C_ccall f_834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_837)
static void C_ccall f_837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_840)
static void C_ccall f_840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_843)
static void C_ccall f_843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_846)
static void C_ccall f_846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_849)
static void C_ccall f_849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_852)
static void C_ccall f_852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_857)
static void C_ccall f_857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_880)
static void C_ccall f_880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1290)
static void C_fcall f_1290(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_fcall f_1285(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1210)
static void C_fcall f_1210(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1217)
static void C_ccall f_1217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1220)
static void C_ccall f_1220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1223)
static void C_ccall f_1223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1234)
static void C_ccall f_1234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1236)
static void C_fcall f_1236(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1271)
static void C_ccall f_1271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1274)
static void C_ccall f_1274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_943)
static void C_ccall f_943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_941)
static void C_ccall f_941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2204)
static void C_ccall f_2204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2207)
static void C_ccall f_2207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1677)
static void C_fcall f_1677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_fcall f_1672(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1667)
static void C_fcall f_1667(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1662)
static void C_fcall f_1662(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1657)
static void C_fcall f_1657(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1601)
static void C_fcall f_1601(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1639)
static void C_ccall f_1639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1626)
static void C_ccall f_1626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2105)
static void C_ccall f_2105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2114)
static void C_ccall f_2114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1825)
static void C_ccall f_1825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2095)
static void C_ccall f_2095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2088)
static void C_fcall f_2088(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_fcall f_2062(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2066)
static void C_ccall f_2066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2072)
static void C_ccall f_2072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f2436)
static void C_ccall f2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f2432)
static void C_ccall f2432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_fcall f_2150(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2169)
static void C_ccall f_2169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2053)
static void C_ccall f_2053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1920)
static void C_fcall f_1920(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_fcall f_1928(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1938)
static void C_fcall f_1938(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1998)
static void C_ccall f_1998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1610)
static void C_ccall f_1610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1577)
static void C_ccall f_1577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1564)
static void C_ccall f_1564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1338)
static void C_ccall f_1338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1338)
static void C_ccall f_1338r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1471)
static void C_fcall f_1471(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1466)
static void C_fcall f_1466(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1461)
static void C_fcall f_1461(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1456)
static void C_fcall f_1456(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1340)
static void C_fcall f_1340(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1344)
static void C_ccall f_1344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1449)
static void C_ccall f_1449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1353)
static void C_ccall f_1353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1356)
static void C_ccall f_1356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1439)
static void C_ccall f_1439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1359)
static void C_ccall f_1359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1396)
static void C_ccall f_1396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1422)
static void C_ccall f_1422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1402)
static void C_ccall f_1402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1364)
static void C_ccall f_1364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1375)
static void C_ccall f_1375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1181)
static void C_fcall f_1181(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1075)
static void C_ccall f_1075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1079)
static void C_ccall f_1079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1084)
static void C_ccall f_1084(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1096)
static void C_ccall f_1096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1100)
static void C_ccall f_1100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1106)
static void C_ccall f_1106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1119)
static void C_ccall f_1119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1136)
static void C_ccall f_1136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1157)
static void C_ccall f_1157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1169)
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1169)
static void C_ccall f_1169r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1163)
static void C_ccall f_1163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1148)
static void C_ccall f_1148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1152)
static void C_ccall f_1152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1134)
static void C_ccall f_1134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1090)
static void C_ccall f_1090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_953)
static void C_ccall f_953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_953)
static void C_ccall f_953r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1027)
static void C_fcall f_1027(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1022)
static void C_fcall f_1022(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_955)
static void C_fcall f_955(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_962)
static void C_ccall f_962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1021)
static void C_ccall f_1021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_978)
static void C_ccall f_978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_981)
static void C_ccall f_981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_996)
static void C_ccall f_996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_987)
static void C_ccall f_987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_897)
static void C_fcall f_897(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_913)
static void C_ccall f_913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_882)
static void C_fcall f_882(C_word t0) C_noret;
C_noret_decl(f_886)
static void C_ccall f_886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_892)
static void C_ccall f_892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_895)
static void C_ccall f_895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_860)
static void C_fcall f_860(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_864)
static void C_ccall f_864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_867)
static void C_ccall f_867(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1290)
static void C_fcall trf_1290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1290(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1290(t0,t1);}

C_noret_decl(trf_1285)
static void C_fcall trf_1285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1285(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1285(t0,t1,t2);}

C_noret_decl(trf_1210)
static void C_fcall trf_1210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1210(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1210(t0,t1,t2,t3);}

C_noret_decl(trf_1236)
static void C_fcall trf_1236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1236(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1236(t0,t1,t2);}

C_noret_decl(trf_1677)
static void C_fcall trf_1677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1677(t0,t1);}

C_noret_decl(trf_1672)
static void C_fcall trf_1672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1672(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1672(t0,t1,t2);}

C_noret_decl(trf_1667)
static void C_fcall trf_1667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1667(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1667(t0,t1,t2,t3);}

C_noret_decl(trf_1662)
static void C_fcall trf_1662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1662(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1662(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1657)
static void C_fcall trf_1657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1657(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1657(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1601)
static void C_fcall trf_1601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1601(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1601(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2088)
static void C_fcall trf_2088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2088(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2088(t0,t1);}

C_noret_decl(trf_2062)
static void C_fcall trf_2062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2062(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2062(t0,t1);}

C_noret_decl(trf_2150)
static void C_fcall trf_2150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2150(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2150(t0,t1,t2);}

C_noret_decl(trf_1920)
static void C_fcall trf_1920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1920(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1920(t0,t1);}

C_noret_decl(trf_1928)
static void C_fcall trf_1928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1928(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1928(t0,t1,t2);}

C_noret_decl(trf_1938)
static void C_fcall trf_1938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1938(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1938(t0,t1);}

C_noret_decl(trf_1471)
static void C_fcall trf_1471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1471(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1471(t0,t1);}

C_noret_decl(trf_1466)
static void C_fcall trf_1466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1466(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1466(t0,t1,t2);}

C_noret_decl(trf_1461)
static void C_fcall trf_1461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1461(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1461(t0,t1,t2,t3);}

C_noret_decl(trf_1456)
static void C_fcall trf_1456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1456(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1456(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1340)
static void C_fcall trf_1340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1340(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1340(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1181)
static void C_fcall trf_1181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1181(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1181(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1027)
static void C_fcall trf_1027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1027(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1027(t0,t1);}

C_noret_decl(trf_1022)
static void C_fcall trf_1022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1022(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1022(t0,t1,t2);}

C_noret_decl(trf_955)
static void C_fcall trf_955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_955(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_955(t0,t1,t2);}

C_noret_decl(trf_897)
static void C_fcall trf_897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_897(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_897(t0,t1,t2,t3);}

C_noret_decl(trf_882)
static void C_fcall trf_882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_882(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_882(t0);}

C_noret_decl(trf_860)
static void C_fcall trf_860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_860(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_860(t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(910)){
C_save(t1);
C_rereclaim2(910*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,190);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[6]=C_h_intern(&lf[6],12,"flush-output");
lf[7]=C_h_intern(&lf[7],7,"fprintf");
lf[8]=C_h_intern(&lf[8],18,"current-error-port");
lf[9]=C_h_intern(&lf[9],19,"current-output-port");
lf[10]=C_h_intern(&lf[10],34,"setup-download#temporary-directory");
lf[12]=C_h_intern(&lf[12],36,"setup-api#create-temporary-directory");
lf[14]=C_h_intern(&lf[14],5,"error");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\021version not found");
lf[16]=C_h_intern(&lf[16],4,"sort");
lf[17]=C_h_intern(&lf[17],20,"setup-api#version>=\077");
lf[18]=C_h_intern(&lf[18],31,"setup-download#locate-egg/local");
lf[19]=C_h_intern(&lf[19],13,"make-pathname");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[22]=C_h_intern(&lf[22],10,"directory\077");
lf[23]=C_h_intern(&lf[23],12,"file-exists\077");
lf[24]=C_h_intern(&lf[24],7,"warning");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000-extension has no such version - using default");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[27]=C_h_intern(&lf[27],9,"directory");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\004tags");
lf[29]=C_h_intern(&lf[29],9,"\003syserror");
lf[30]=C_h_intern(&lf[30],37,"setup-download#gather-egg-information");
lf[31]=C_h_intern(&lf[31],7,"version");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000.extension has syntactically invalid .meta file");
lf[33]=C_h_intern(&lf[33],20,"with-input-from-file");
lf[34]=C_h_intern(&lf[34],4,"read");
lf[35]=C_h_intern(&lf[35],22,"with-exception-handler");
lf[36]=C_h_intern(&lf[36],30,"call-with-current-continuation");
lf[37]=C_h_intern(&lf[37],14,"string->symbol");
lf[38]=C_h_intern(&lf[38],7,"call/cc");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[40]=C_h_intern(&lf[40],10,"filter-map");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\004 -R ");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[44]=C_h_intern(&lf[44],4,"conc");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\007svn ls ");
lf[46]=C_h_intern(&lf[46],2,"qs");
lf[47]=C_h_intern(&lf[47],15,"\003sysget-keyword");
lf[48]=C_h_intern(&lf[48],11,"\000recursive\077");
lf[49]=C_h_intern(&lf[49],29,"setup-download#locate-egg/svn");
lf[50]=C_h_intern(&lf[50],13,"string-append");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\005tags/");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\006trunk/");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[58]=C_h_intern(&lf[58],6,"system");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\005 1>&2");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\013svn export ");
lf[63]=C_h_intern(&lf[63],13,"string-search");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\016^tags/([^/]+)/");
lf[65]=C_h_intern(&lf[65],20,"with-input-from-pipe");
lf[66]=C_h_intern(&lf[66],10,"read-lines");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\047checking available versions ...~%  ~a~%");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[74]=C_h_intern(&lf[74],30,"setup-download#locate-egg/http");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\020not a valid port");
lf[77]=C_h_intern(&lf[77],12,"string-match");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000#(http://)\077([^/:]+)(:([^:/]+))\077(/.+)");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[80]=C_h_intern(&lf[80],11,"tcp-connect");
lf[81]=C_h_intern(&lf[81],5,"abort");
lf[82]=C_h_intern(&lf[82],24,"make-composite-condition");
lf[83]=C_h_intern(&lf[83],23,"make-property-condition");
lf[84]=C_h_intern(&lf[84],20,"setup-download-error");
lf[85]=C_h_intern(&lf[85],3,"exn");
lf[86]=C_h_intern(&lf[86],7,"message");
lf[87]=C_h_intern(&lf[87],9,"arguments");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\011[Server] ");
lf[89]=C_h_intern(&lf[89],7,"reverse");
lf[90]=C_h_intern(&lf[90],17,"close-output-port");
lf[91]=C_h_intern(&lf[91],16,"close-input-port");
lf[92]=C_h_intern(&lf[92],16,"create-directory");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[94]=C_h_intern(&lf[94],7,"display");
lf[95]=C_h_intern(&lf[95],19,"with-output-to-file");
lf[96]=C_h_intern(&lf[96],20,"\003sysread-string/port");
lf[97]=C_h_intern(&lf[97],9,"read-line");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[99]=C_h_intern(&lf[99],14,"string-suffix\077");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\0001invalid file name - possibly corrupt transmission");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\023reading files ...~%");
lf[103]=C_h_intern(&lf[103],17,"open-input-string");
lf[104]=C_h_intern(&lf[104],26,"string-concatenate-reverse");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\024reading chunks ...~%");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~%");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000$[Tt]ransfer-[Ee]ncoding:\134s*chunked.*");
lf[108]=C_h_intern(&lf[108],12,"string-null\077");
lf[109]=C_h_intern(&lf[109],6,"signal");
lf[110]=C_h_intern(&lf[110],10,"http-fetch");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid response from server");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\003200");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~%");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\034HTTP/[0-9.]+\134s+([0-9]+)\134s+.*");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\026reading response ...~%");
lf[116]=C_h_intern(&lf[116],5,"\000port");
lf[117]=C_h_intern(&lf[117],7,"\000accept");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\003*/*");
lf[119]=C_h_intern(&lf[119],11,"\000proxy-host");
lf[120]=C_h_intern(&lf[120],11,"\000proxy-port");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\004GET ");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\011 HTTP/1.1");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\014Connection: ");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\014User-Agent: ");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\010Accept: ");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\006Host: ");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\020Content-length: ");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\007http://");
lf[136]=C_h_intern(&lf[136],15,"\000content-length");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\005close");
lf[139]=C_h_intern(&lf[139],11,"\000connection");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\023requesting ~s ...~%");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000&connecting to host ~s, port ~a ~a...~%");
lf[142]=C_h_intern(&lf[142],17,"get-output-string");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[144]=C_h_intern(&lf[144],19,"\003syswrite-char/port");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\005(via ");
lf[146]=C_h_intern(&lf[146],18,"open-output-string");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\006\077name=");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\012&tests=yes");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\011&version=");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[153]=C_h_intern(&lf[153],33,"setup-download#retrieve-extension");
lf[154]=C_h_intern(&lf[154],5,"local");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000)destination for transport `local\047 ignored");
lf[156]=C_h_intern(&lf[156],3,"svn");
lf[157]=C_h_intern(&lf[157],4,"http");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000/cannot retrieve extension unsupported transport");
lf[159]=C_h_intern(&lf[159],16,"\003sysdynamic-wind");
lf[160]=C_h_intern(&lf[160],6,"\000trunk");
lf[161]=C_h_intern(&lf[161],6,"\000tests");
lf[162]=C_h_intern(&lf[162],9,"\000password");
lf[163]=C_h_intern(&lf[163],9,"\000username");
lf[164]=C_h_intern(&lf[164],12,"\000destination");
lf[165]=C_h_intern(&lf[165],6,"\000quiet");
lf[166]=C_h_intern(&lf[166],8,"\000version");
lf[167]=C_h_intern(&lf[167],30,"setup-download#list-extensions");
lf[168]=C_h_intern(&lf[168],18,"string-concatenate");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[170]=C_h_intern(&lf[170],7,"\003sysmap");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[172]=C_h_intern(&lf[172],12,"string-chomp");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\047listing extension directory ...~%  ~a~%");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000.cannot list extensions - unsupported transport");
lf[182]=C_h_intern(&lf[182],14,"make-parameter");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-install ");
lf[184]=C_h_intern(&lf[184],15,"chicken-version");
lf[185]=C_h_intern(&lf[185],17,"tcp-write-timeout");
lf[186]=C_h_intern(&lf[186],16,"tcp-read-timeout");
lf[187]=C_h_intern(&lf[187],19,"tcp-connect-timeout");
lf[188]=C_h_intern(&lf[188],11,"\003sysrequire");
lf[189]=C_h_intern(&lf[189],9,"setup-api");
C_register_lf2(lf,190,create_ptable());
t2=C_mutate(&lf[0] /* (set! c245 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_810,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k808 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_813,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k811 in k808 */
static void C_ccall f_813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_816,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k814 in k811 in k808 */
static void C_ccall f_816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_819,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k817 in k814 in k811 in k808 */
static void C_ccall f_819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_822,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_825,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_828,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_831,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_834,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_837,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_840,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_843,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#require");
((C_proc3)C_retrieve_symbol_proc(lf[188]))(3,*((C_word*)lf[188]+1),t2,lf[189]);}

/* k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_846,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 45   tcp-connect-timeout");
((C_proc3)C_retrieve_symbol_proc(lf[187]))(3,*((C_word*)lf[187]+1),t2,C_fix(10000));}

/* k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_849,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 46   tcp-read-timeout");
((C_proc3)C_retrieve_symbol_proc(lf[186]))(3,*((C_word*)lf[186]+1),t2,C_fix(20000));}

/* k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_852,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 47   tcp-write-timeout");
((C_proc3)C_retrieve_symbol_proc(lf[185]))(3,*((C_word*)lf[185]+1),t2,C_fix(20000));}

/* k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_852,2,t0,t1);}
t2=lf[2] /* setup-download#*quiet* */ =C_SCHEME_FALSE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_857,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2319,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 50   chicken-version");
((C_proc2)C_retrieve_symbol_proc(lf[184]))(2,*((C_word*)lf[184]+1),t4);}

/* k2317 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 50   conc");
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[183],t1);}

/* k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_857,2,t0,t1);}
t2=C_mutate(&lf[3] /* (set! setup-download#*chicken-install-user-agent* ...) */,t1);
t3=lf[4] /* setup-download#*trunk* */ =C_SCHEME_FALSE;;
t4=C_mutate(&lf[5] /* (set! setup-download#d ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_860,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_880,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 58   make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[182]))(3,*((C_word*)lf[182]+1),t5,C_SCHEME_FALSE);}

/* k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_880,2,t0,t1);}
t2=C_mutate((C_word*)lf[10]+1 /* (set! setup-download#temporary-directory ...) */,t1);
t3=C_mutate(&lf[11] /* (set! setup-download#get-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_882,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[13] /* (set! setup-download#existing-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_897,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[18]+1 /* (set! setup-download#locate-egg/local ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_953,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[30]+1 /* (set! setup-download#gather-egg-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1075,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[41] /* (set! setup-download#make-svn-ls-cmd ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1181,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[49]+1 /* (set! setup-download#locate-egg/svn ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1338,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[74]+1 /* (set! setup-download#locate-egg/http ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1599,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[153]+1 /* (set! setup-download#retrieve-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2182,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[167]+1 /* (set! setup-download#list-extensions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2268,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}

/* setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2268r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2268r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2268r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2272,a[2]=t4,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t5,lf[165],t4);}

/* k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2275,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[163],((C_word*)t0)[2]);}

/* k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2278,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[162],((C_word*)t0)[2]);}

/* k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2278,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2283,a[2]=t3,a[3]=t5,a[4]=((C_word)li52),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2288,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li58),tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2312,a[2]=t5,a[3]=t3,a[4]=((C_word)li59),tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#dynamic-wind");
t9=*((C_word*)lf[159]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a2311 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2312,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2287 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[18],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2288,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=C_eqp(t2,lf[154]);
if(C_truep(t3)){
t4=t1;
t5=((C_word*)t0)[4];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_941,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_943,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_951,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 79   directory");
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t8,t5);}
else{
t4=C_eqp(t2,lf[156]);
if(C_truep(t4)){
t5=t1;
t6=((C_word*)t0)[4];
t7=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1210,a[2]=t6,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1285,a[2]=t8,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1290,a[2]=t9,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t7))){
C_trace("def-username307346");
t11=t10;
f_1290(t11,t5);}
else{
t11=C_i_car(t7);
t12=C_i_cdr(t7);
if(C_truep(C_i_nullp(t12))){
C_trace("def-password308344");
t13=t9;
f_1285(t13,t5,t11);}
else{
t13=C_i_car(t12);
t14=C_i_cdr(t12);
if(C_truep(C_i_nullp(t14))){
C_trace("body305313");
t15=t8;
f_1210(t15,t5,t11,t13);}
else{
C_trace("##sys#error");
t15=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t5,lf[0],t14);}}}}
else{
C_trace("setup-download.scm: 316  error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t1,lf[181],((C_word*)t0)[5]);}}}

/* def-username307 in a2287 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1290(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1290,NULL,2,t0,t1);}
C_trace("def-password308344");
t2=((C_word*)t0)[2];
f_1285(t2,t1,C_SCHEME_FALSE);}

/* def-password308 in a2287 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1285(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1285,NULL,3,t0,t1,t2);}
C_trace("body305313");
t3=((C_word*)t0)[2];
f_1210(t3,t1,t2,C_SCHEME_FALSE);}

/* body305 in a2287 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1210(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1210,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1214,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
C_trace("setup-download.scm: 121  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t4,lf[178],t2,lf[179]);}
else{
t5=t4;
f_1214(2,t5,lf[180]);}}

/* k1212 in body305 in a2287 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1217,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-download.scm: 122  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t2,lf[175],((C_word*)t0)[2],lf[176]);}
else{
t3=t2;
f_1217(2,t3,lf[177]);}}

/* k1215 in k1212 in body305 in a2287 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1220,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 123  make-svn-ls-cmd");
f_1181(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1218 in k1215 in k1212 in body305 in a2287 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1223,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 124  d");
f_860(t2,lf[174],C_a_i_list(&a,1,t1));}

/* k1221 in k1218 in k1215 in k1212 in body305 in a2287 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1223,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1230,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1234,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 127  with-input-from-pipe");
((C_proc4)C_retrieve_symbol_proc(lf[65]))(4,*((C_word*)lf[65]+1),t7,((C_word*)t0)[2],C_retrieve(lf[66]));}

/* k1232 in k1221 in k1218 in k1215 in k1212 in body305 in a2287 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1234,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1236,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li54),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1236(t5,((C_word*)t0)[2],t1);}

/* loop321 in k1232 in k1221 in k1218 in k1215 in k1212 in body305 in a2287 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1236(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1236,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1274,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1271,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 126  string-chomp");
((C_proc4)C_retrieve_symbol_proc(lf[172]))(4,*((C_word*)lf[172]+1),t5,t4,lf[173]);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1269 in loop321 in k1232 in k1221 in k1218 in k1215 in k1212 in body305 in a2287 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 126  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),((C_word*)t0)[2],t1,lf[171]);}

/* k1272 in loop321 in k1232 in k1221 in k1218 in k1215 in k1212 in body305 in a2287 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1274,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop321334");
t6=((C_word*)((C_word*)t0)[4])[1];
f_1236(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop321334");
t6=((C_word*)((C_word*)t0)[4])[1];
f_1236(t6,((C_word*)t0)[3],t5);}}

/* k1228 in k1221 in k1218 in k1215 in k1212 in body305 in a2287 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 125  string-concatenate");
((C_proc3)C_retrieve_symbol_proc(lf[168]))(3,*((C_word*)lf[168]+1),((C_word*)t0)[2],t1);}

/* k949 in a2287 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a942 in a2287 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_943,3,t0,t1,t2);}
t3=*((C_word*)lf[50]+1);
C_trace("g196197");
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[169]);}

/* k939 in a2287 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 79   string-concatenate");
((C_proc3)C_retrieve_symbol_proc(lf[168]))(3,*((C_word*)lf[168]+1),((C_word*)t0)[2],t1);}

/* a2282 in k2276 in k2273 in k2270 in setup-download#list-extensions in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2283,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* setup-download#retrieve-extension in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_2182r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2182r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2182r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2186,a[2]=t5,a[3]=t1,a[4]=t4,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t6,lf[166],t5);}

/* k2184 in setup-download#retrieve-extension in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[165],((C_word*)t0)[2]);}

/* k2187 in k2184 in setup-download#retrieve-extension in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[164],((C_word*)t0)[2]);}

/* k2190 in k2187 in k2184 in setup-download#retrieve-extension in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[163],((C_word*)t0)[2]);}

/* k2193 in k2190 in k2187 in k2184 in setup-download#retrieve-extension in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[162],((C_word*)t0)[2]);}

/* k2196 in k2193 in k2190 in k2187 in k2184 in setup-download#retrieve-extension in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[161],((C_word*)t0)[2]);}

/* k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in setup-download#retrieve-extension in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[119],((C_word*)t0)[2]);}

/* k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in setup-download#retrieve-extension in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2207,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[120],((C_word*)t0)[2]);}

/* k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in setup-download#retrieve-extension in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2210,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[160],((C_word*)t0)[2]);}

/* k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in setup-download#retrieve-extension in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2210,2,t0,t1);}
t2=((C_word*)t0)[13];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=t1;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2215,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t7,a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp);
t11=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2222,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word)li49),tmp=(C_word)a,a+=13,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2261,a[2]=t9,a[3]=t7,a[4]=t5,a[5]=t3,a[6]=((C_word)li50),tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#dynamic-wind");
t13=*((C_word*)lf[159]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,((C_word*)t0)[2],t10,t11,t12);}

/* a2260 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in setup-download#retrieve-extension in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2261,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,C_retrieve2(lf[4],"setup-download#*trunk*"));
t4=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(&lf[4] /* (set! setup-download#*trunk* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* a2221 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in setup-download#retrieve-extension in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2222,2,t0,t1);}
t2=((C_word*)t0)[11];
t3=C_eqp(t2,lf[154]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2232,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[7])){
C_trace("setup-download.scm: 299  warning");
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t4,lf[155]);}
else{
C_trace("setup-download.scm: 300  locate-egg/local");
((C_proc6)C_retrieve_symbol_proc(lf[18]))(6,*((C_word*)lf[18]+1),t1,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}
else{
t4=C_eqp(t2,lf[156]);
if(C_truep(t4)){
C_trace("setup-download.scm: 302  locate-egg/svn");
((C_proc8)C_retrieve_symbol_proc(lf[49]))(8,*((C_word*)lf[49]+1),t1,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t5=C_eqp(t2,lf[157]);
if(C_truep(t5)){
C_trace("setup-download.scm: 304  locate-egg/http");
((C_proc9)C_retrieve_symbol_proc(lf[74]))(9,*((C_word*)lf[74]+1),t1,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_trace("setup-download.scm: 306  error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t1,lf[158],((C_word*)t0)[11]);}}}}

/* k2230 in a2221 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in setup-download#retrieve-extension in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 300  locate-egg/local");
((C_proc6)C_retrieve_symbol_proc(lf[18]))(6,*((C_word*)lf[18]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2214 in k2208 in k2205 in k2202 in k2199 in k2196 in k2193 in k2190 in k2187 in k2184 in setup-download#retrieve-extension in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2215,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,C_retrieve2(lf[4],"setup-download#*trunk*"));
t4=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(&lf[4] /* (set! setup-download#*trunk* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+25)){
C_save_and_reclaim((void*)tr4r,(void*)f_1599r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1599r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1599r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(25);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1601,a[2]=t2,a[3]=t3,a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1657,a[2]=t5,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1662,a[2]=t6,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1667,a[2]=t7,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1672,a[2]=t8,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1677,a[2]=t9,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
C_trace("def-version464524");
t11=t10;
f_1677(t11,t1);}
else{
t11=C_i_car(t4);
t12=C_i_cdr(t4);
if(C_truep(C_i_nullp(t12))){
C_trace("def-destination465522");
t13=t9;
f_1672(t13,t1,t11);}
else{
t13=C_i_car(t12);
t14=C_i_cdr(t12);
if(C_truep(C_i_nullp(t14))){
C_trace("def-tests466519");
t15=t8;
f_1667(t15,t1,t11,t13);}
else{
t15=C_i_car(t14);
t16=C_i_cdr(t14);
if(C_truep(C_i_nullp(t16))){
C_trace("def-proxy-host467515");
t17=t7;
f_1662(t17,t1,t11,t13,t15);}
else{
t17=C_i_car(t16);
t18=C_i_cdr(t16);
if(C_truep(C_i_nullp(t18))){
C_trace("def-proxy-port468510");
t19=t6;
f_1657(t19,t1,t11,t13,t15,t17);}
else{
t19=C_i_car(t18);
t20=C_i_cdr(t18);
if(C_truep(C_i_nullp(t20))){
C_trace("body462473");
t21=t5;
f_1601(t21,t1,t11,t13,t15,t17,t19);}
else{
C_trace("##sys#error");
t21=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t1,lf[0],t20);}}}}}}}

/* def-version464 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1677,NULL,2,t0,t1);}
C_trace("def-destination465522");
t2=((C_word*)t0)[2];
f_1672(t2,t1,C_SCHEME_FALSE);}

/* def-destination465 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1672(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1672,NULL,3,t0,t1,t2);}
C_trace("def-tests466519");
t3=((C_word*)t0)[2];
f_1667(t3,t1,t2,C_SCHEME_FALSE);}

/* def-tests466 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1667(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1667,NULL,4,t0,t1,t2,t3);}
C_trace("def-proxy-host467515");
t4=((C_word*)t0)[2];
f_1662(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* def-proxy-host467 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1662(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1662,NULL,5,t0,t1,t2,t3,t4);}
C_trace("def-proxy-port468510");
t5=((C_word*)t0)[2];
f_1657(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* def-proxy-port468 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1657(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1657,NULL,6,t0,t1,t2,t3,t4,t5);}
C_trace("body462473");
t6=((C_word*)t0)[2];
f_1601(t6,t1,t2,t3,t4,t5,C_SCHEME_FALSE);}

/* body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1601(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1601,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1605,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t6,a[6]=t5,a[7]=t2,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t8=t7;
f_1605(2,t8,t3);}
else{
C_trace("setup-download.scm: 167  get-temporary-directory");
f_882(t7);}}

/* k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1610,a[2]=((C_word*)t0)[8],a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li40),tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1616,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1620,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[7])){
C_trace("setup-download.scm: 172  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t6,lf[151],((C_word*)t0)[7]);}
else{
t7=t6;
f_1646(2,t7,lf[152]);}}

/* k1644 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[5])){
C_trace("setup-download.scm: 169  string-append");
((C_proc7)C_retrieve_proc(*((C_word*)lf[50]+1)))(7,*((C_word*)lf[50]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[148],((C_word*)t0)[2],t1,lf[149]);}
else{
C_trace("setup-download.scm: 169  string-append");
((C_proc7)C_retrieve_proc(*((C_word*)lf[50]+1)))(7,*((C_word*)lf[50]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[148],((C_word*)t0)[2],t1,lf[150]);}}

/* k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1623,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm: 174  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1639,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 175  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t3,t1);}

/* k1637 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1626(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("setup-download.scm: 175  create-directory");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1629,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[7];
t7=((C_word*)t0)[3];
t8=((C_word*)t0)[2];
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1870,a[2]=t2,a[3]=t5,a[4]=t6,a[5]=t4,a[6]=t8,a[7]=t3,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2099,a[2]=t4,a[3]=t3,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t7)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2102,a[2]=t7,a[3]=t8,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[146]))(2,*((C_word*)lf[146]+1),t11);}
else{
C_trace("setup-download.scm: 220  d");
f_860(t9,lf[141],C_a_i_list(&a,3,t3,t4,lf[147]));}}

/* k2100 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[94]+1)))(4,*((C_word*)lf[94]+1),t2,lf[145],t1);}

/* k2103 in k2100 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2108,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[94]+1)))(4,*((C_word*)lf[94]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2106 in k2103 in k2100 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[144]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(58),((C_word*)t0)[3]);}

/* k2109 in k2106 in k2103 in k2100 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2114,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[94]+1)))(4,*((C_word*)lf[94]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2112 in k2109 in k2106 in k2103 in k2100 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[94]+1)))(4,*((C_word*)lf[94]+1),t2,lf[143],((C_word*)t0)[2]);}

/* k2115 in k2112 in k2109 in k2106 in k2103 in k2100 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[142]))(3,*((C_word*)lf[142]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2097 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2099,2,t0,t1);}
C_trace("setup-download.scm: 220  d");
f_860(((C_word*)t0)[4],lf[141],C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1875,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word)li30),tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[4],a[8]=((C_word)li39),tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1889,4,t0,t1,t2,t3);}
t4=t2;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
C_trace("setup-download.scm: 225  d");
f_860(t6,lf[140],C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[43],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2095,a[2]=((C_word*)t0)[10],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve2(lf[3],"setup-download#*chicken-install-user-agent*");
t5=C_a_i_list(&a,8,lf[116],((C_word*)t0)[6],lf[117],lf[118],lf[119],((C_word*)t0)[5],lf[120],((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1792,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1828,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t6,lf[116],t5,t7);}

/* a1827 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1828,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(80));}

/* k1790 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1825,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t2,lf[139],((C_word*)t0)[2],t3);}

/* a1824 in k1790 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1825,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[138]);}

/* k1793 in k1790 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1822,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t2,lf[117],((C_word*)t0)[2],t3);}

/* a1821 in k1793 in k1790 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1822,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[137]);}

/* k1796 in k1793 in k1790 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1819,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t2,lf[136],((C_word*)t0)[2],t3);}

/* a1818 in k1796 in k1793 in k1790 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1819,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* k1799 in k1796 in k1793 in k1790 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[119],((C_word*)t0)[2]);}

/* k1802 in k1799 in k1796 in k1793 in k1790 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1807,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[120],((C_word*)t0)[2]);}

/* k1805 in k1802 in k1799 in k1796 in k1793 in k1790 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1814,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("setup-download.scm: 199  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t2,lf[135],((C_word*)t0)[6],((C_word*)t0)[2]);}
else{
t3=t2;
f_1814(2,t3,((C_word*)t0)[2]);}}

/* k1812 in k1805 in k1802 in k1799 in k1796 in k1793 in k1790 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 196  conc");
((C_proc24)C_retrieve_symbol_proc(lf[44]))(24,*((C_word*)lf[44]+1),((C_word*)t0)[7],lf[121],t1,lf[122],lf[123],lf[124],((C_word*)t0)[6],lf[125],lf[126],C_retrieve2(lf[3],"setup-download#*chicken-install-user-agent*"),lf[127],lf[128],((C_word*)t0)[5],lf[129],lf[130],((C_word*)t0)[4],C_make_character(58),((C_word*)t0)[3],lf[131],lf[132],((C_word*)t0)[2],lf[133],lf[134]);}

/* k2093 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 226  display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[94]+1)))(4,*((C_word*)lf[94]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 230  flush-output");
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t2,((C_word*)t0)[5]);}

/* k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 231  d");
f_860(t2,lf[115],C_SCHEME_END_OF_LIST);}

/* k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1902,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1905,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm: 233  read-line");
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),t4,((C_word*)((C_word*)t0)[4])[1]);}

/* k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1908,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=t1;
if(C_truep(C_i_stringp(t3))){
C_trace("setup-download.scm: 211  string-match");
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t2,lf[114],t3);}
else{
t4=t2;
f_1908(2,t4,C_SCHEME_FALSE);}}

/* k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1911,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm: 235  d");
f_860(t2,lf[113],C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2088,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep(t4)){
t5=C_i_cadr(t4);
t6=t3;
f_2088(t6,C_i_string_equal_p(lf[112],t5));}
else{
t5=t3;
f_2088(t5,C_SCHEME_FALSE);}}

/* k2086 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_2088(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2088,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1914(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1778,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1782,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 183  make-property-condition");
((C_proc7)C_retrieve_symbol_proc(lf[83]))(7,*((C_word*)lf[83]+1),t4,lf[85],lf[86],lf[111],lf[87],t2);}}

/* k1780 in k2086 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1786,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 187  make-property-condition");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,lf[110]);}

/* k1784 in k1780 in k2086 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 182  make-composite-condition");
((C_proc4)C_retrieve_symbol_proc(lf[82]))(4,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1776 in k2086 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 181  signal");
((C_proc3)C_retrieve_symbol_proc(lf[109]))(3,*((C_word*)lf[109]+1),((C_word*)t0)[2],t1);}

/* k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2062,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li34),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2062(t6,t2);}

/* loop in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_2062(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2062,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2066,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 240  read-line");
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2064 in loop in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2072,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 241  string-null?");
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),t2,t1);}

/* k2070 in k2064 in loop in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2072,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
C_trace("setup-download.scm: 217  string-match");
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t2,lf[107],t3);}}

/* k2082 in k2070 in k2064 in loop in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2084,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f2432,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 243  d");
f_860(t3,lf[106],C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f2436,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 243  d");
f_860(t2,lf[106],C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* f2436 in k2082 in k2070 in k2064 in loop in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 244  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_2062(t2,((C_word*)t0)[2]);}

/* f2432 in k2082 in k2070 in k2064 in loop in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f2432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 244  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_2062(t2,((C_word*)t0)[2]);}

/* k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1920,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2050,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 246  d");
f_860(t3,lf[105],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1920(t3,C_SCHEME_UNDEFINED);}}

/* k2048 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2150,a[2]=t3,a[3]=t5,a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2150(t7,t2,C_SCHEME_END_OF_LIST);}

/* get-chunks in k2048 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_2150(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2150,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2180,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 285  read-line");
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),t4,((C_word*)t0)[2]);}

/* k2178 in get-chunks in k2048 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 285  string->number");
C_string_to_number(4,0,((C_word*)t0)[2],t1,C_fix(16));}

/* k2152 in get-chunks in k2048 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2154,2,t0,t1);}
if(C_truep(C_i_zerop(t1))){
C_trace("setup-download.scm: 287  string-concatenate-reverse");
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("read-string/port");
t3=C_retrieve(lf[96]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}}

/* k2164 in k2152 in get-chunks in k2048 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 289  read-line");
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),t2,((C_word*)t0)[2]);}

/* k2167 in k2164 in k2152 in get-chunks in k2048 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2169,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
C_trace("setup-download.scm: 290  get-chunks");
t3=((C_word*)((C_word*)t0)[3])[1];
f_2150(t3,((C_word*)t0)[2],t2);}

/* k2051 in k2048 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2056,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 248  close-input-port");
((C_proc3)C_retrieve_proc(*((C_word*)lf[91]+1)))(3,*((C_word*)lf[91]+1),t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k2054 in k2051 in k2048 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2060,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 249  open-input-string");
((C_proc3)C_retrieve_symbol_proc(lf[103]))(3,*((C_word*)lf[103]+1),t2,((C_word*)t0)[2]);}

/* k2058 in k2054 in k2051 in k2048 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1920(t3,t2);}

/* k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1920(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1920,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 250  d");
f_860(t2,lf[102],C_SCHEME_END_OF_LIST);}

/* k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li32),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1928(t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1928(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1928,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm: 252  read");
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_pairp(t1))){
t3=C_i_car(t1);
t4=t2;
f_1938(t4,C_eqp(lf[14],t3));}
else{
t3=t2;
f_1938(t3,C_SCHEME_FALSE);}}

/* k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1938(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1938,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[8]);
t3=C_i_cddr(((C_word*)t0)[8]);
t4=((C_word*)t0)[7];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2130,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2134,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2142,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 279  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t7,lf[88],t2);}
else{
t2=C_eofp(((C_word*)t0)[8]);
t3=(C_truep(t2)?t2:C_i_not(((C_word*)t0)[8]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1961,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 256  close-input-port");
((C_proc3)C_retrieve_proc(*((C_word*)lf[91]+1)))(3,*((C_word*)lf[91]+1),t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[8]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm: 261  string-suffix?");
((C_proc4)C_retrieve_symbol_proc(lf[99]))(4,*((C_word*)lf[99]+1),t4,lf[100],((C_word*)t0)[8]);}
else{
C_trace("setup-download.scm: 260  error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),((C_word*)t0)[7],lf[101],((C_word*)t0)[8]);}}}}

/* k1980 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm: 262  read");
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm: 267  d");
f_860(t2,lf[98],C_a_i_list(&a,1,((C_word*)t0)[3]));}}

/* k1999 in k1980 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm: 268  read");
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2002 in k1999 in k1980 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2007,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm: 269  read-line");
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2005 in k2002 in k1999 in k1980 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2010,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
C_trace("read-string/port");
t3=C_retrieve(lf[96]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2008 in k2005 in k2002 in k1999 in k1980 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2024,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 271  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2022 in k2008 in k2005 in k2002 in k1999 in k1980 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2026,a[2]=((C_word*)t0)[3],a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 271  with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],t1,t2);}

/* a2025 in k2022 in k2008 in k2005 in k2002 in k1999 in k1980 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2026,2,t0,t1);}
t2=*((C_word*)lf[94]+1);
C_trace("g656657");
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[2]);}

/* k2011 in k2008 in k2005 in k2002 in k1999 in k1980 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2013,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
C_trace("setup-download.scm: 272  get-files");
t3=((C_word*)((C_word*)t0)[3])[1];
f_1928(t3,((C_word*)t0)[2],t2);}

/* k1983 in k1980 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm: 263  d");
f_860(t2,lf[93],C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* k1986 in k1983 in k1980 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1991,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1998,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 264  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1996 in k1986 in k1983 in k1980 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 264  create-directory");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t1);}

/* k1989 in k1986 in k1983 in k1980 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 265  get-files");
t2=((C_word*)((C_word*)t0)[4])[1];
f_1928(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1959 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 257  close-output-port");
((C_proc3)C_retrieve_proc(*((C_word*)lf[90]+1)))(3,*((C_word*)lf[90]+1),t2,((C_word*)t0)[2]);}

/* k1962 in k1959 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 258  reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[89]+1)))(3,*((C_word*)lf[89]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2140 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 277  make-property-condition");
((C_proc7)C_retrieve_symbol_proc(lf[83]))(7,*((C_word*)lf[83]+1),((C_word*)t0)[3],lf[85],lf[86],t1,lf[87],((C_word*)t0)[2]);}

/* k2132 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2138,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 281  make-property-condition");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,lf[84]);}

/* k2136 in k2132 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 276  make-composite-condition");
((C_proc4)C_retrieve_symbol_proc(lf[82]))(4,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2128 in k1936 in k1930 in get-files in k1921 in k1918 in k1915 in k1912 in k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in a1888 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_2130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 275  abort");
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),((C_word*)t0)[2],t1);}

/* a1874 in k1868 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1875,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:((C_word*)t0)[4]);
if(C_truep(((C_word*)t0)[3])){
C_trace("setup-download.scm: 224  tcp-connect");
((C_proc4)C_retrieve_symbol_proc(lf[80]))(4,*((C_word*)lf[80]+1),t1,t2,((C_word*)t0)[3]);}
else{
C_trace("setup-download.scm: 224  tcp-connect");
((C_proc4)C_retrieve_symbol_proc(lf[80]))(4,*((C_word*)lf[80]+1),t1,t2,((C_word*)t0)[2]);}}

/* k1627 in k1624 in k1621 in k1618 in a1615 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[4];
if(C_truep(t2)){
C_trace("setup-download.scm: 178  values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
C_trace("setup-download.scm: 178  values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],lf[79]);}}

/* a1609 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1610,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1553,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 156  string-match");
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t3,lf[78],t2);}

/* k1551 in a1609 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1553,2,t0,t1);}
t2=(C_truep(t1)?C_i_caddr(t1):((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1564,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(t1)?C_i_cadddr(t1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1577,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=C_i_list_ref(t1,C_fix(4));
C_trace("setup-download.scm: 160  string->number");
C_string_to_number(3,0,t5,t6);}
else{
t5=t3;
f_1564(2,t5,C_fix(80));}}

/* k1575 in k1551 in a1609 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_1564(2,t3,t2);}
else{
t2=C_i_list_ref(((C_word*)t0)[2],C_fix(4));
C_trace("setup-download.scm: 161  error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),((C_word*)t0)[3],lf[76],t2);}}

/* k1562 in k1551 in a1609 in k1603 in body462 in setup-download#locate-egg/http in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
t2=C_i_list_ref(((C_word*)t0)[4],C_fix(5));
C_trace("setup-download.scm: 157  values");
C_values(5,0,((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}
else{
C_trace("setup-download.scm: 157  values");
C_values(5,0,((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[75]);}}

/* setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_1338r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1338r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1338r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1340,a[2]=t3,a[3]=t2,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1456,a[2]=t5,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1461,a[2]=t6,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1466,a[2]=t7,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1471,a[2]=t8,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
C_trace("def-version370425");
t10=t9;
f_1471(t10,t1);}
else{
t10=C_i_car(t4);
t11=C_i_cdr(t4);
if(C_truep(C_i_nullp(t11))){
C_trace("def-destination371423");
t12=t8;
f_1466(t12,t1,t10);}
else{
t12=C_i_car(t11);
t13=C_i_cdr(t11);
if(C_truep(C_i_nullp(t13))){
C_trace("def-username372420");
t14=t7;
f_1461(t14,t1,t10,t12);}
else{
t14=C_i_car(t13);
t15=C_i_cdr(t13);
if(C_truep(C_i_nullp(t15))){
C_trace("def-password373416");
t16=t6;
f_1456(t16,t1,t10,t12,t14);}
else{
t16=C_i_car(t15);
t17=C_i_cdr(t15);
if(C_truep(C_i_nullp(t17))){
C_trace("body368378");
t18=t5;
f_1340(t18,t1,t10,t12,t14,t16);}
else{
C_trace("##sys#error");
t18=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t1,lf[0],t17);}}}}}}

/* def-version370 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1471(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1471,NULL,2,t0,t1);}
C_trace("def-destination371423");
t2=((C_word*)t0)[2];
f_1466(t2,t1,C_SCHEME_FALSE);}

/* def-destination371 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1466(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1466,NULL,3,t0,t1,t2);}
C_trace("def-username372420");
t3=((C_word*)t0)[2];
f_1461(t3,t1,t2,C_SCHEME_FALSE);}

/* def-username372 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1461(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1461,NULL,4,t0,t1,t2,t3);}
C_trace("def-password373416");
t4=((C_word*)t0)[2];
f_1456(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* def-password373 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1456(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1456,NULL,5,t0,t1,t2,t3,t4);}
C_trace("body368378");
t5=((C_word*)t0)[2];
f_1340(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1340(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1340,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1344,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
C_trace("setup-download.scm: 130  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t6,lf[71],t4,lf[72]);}
else{
t7=t6;
f_1344(2,t7,lf[73]);}}

/* k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1347,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-download.scm: 131  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t2,lf[68],((C_word*)t0)[2],lf[69]);}
else{
t3=t2;
f_1347(2,t3,lf[70]);}}

/* k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1449,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 132  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),t3,((C_word*)t0)[4],((C_word*)t0)[7]);}

/* k1447 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1449,2,t0,t1);}
C_trace("setup-download.scm: 132  make-svn-ls-cmd");
f_1181(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_a_i_list(&a,2,lf[48],C_SCHEME_TRUE));}

/* k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1353,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("setup-download.scm: 133  d");
f_860(t2,lf[67],C_a_i_list(&a,1,t1));}

/* k1351 in k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1356,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm: 134  with-input-from-pipe");
((C_proc4)C_retrieve_symbol_proc(lf[65]))(4,*((C_word*)lf[65]+1),t2,((C_word*)t0)[2],C_retrieve(lf[66]));}

/* k1354 in k1351 in k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1433,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1435,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 137  filter-map");
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),t3,t4,t1);}

/* a1434 in k1354 in k1351 in k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1435(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1435,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1439,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 138  string-search");
((C_proc4)C_retrieve_symbol_proc(lf[63]))(4,*((C_word*)lf[63]+1),t3,lf[64],t2);}

/* k1437 in a1434 in k1354 in k1351 in k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_i_cadr(t1):C_SCHEME_FALSE));}

/* k1431 in k1354 in k1351 in k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 135  existing-version");
f_897(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1364,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t1,a[6]=((C_word)li20),tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1392,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li21),tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1391 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1392,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1396,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1426,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
C_trace("setup-download.scm: 148  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),t4,t5,((C_word*)t0)[3]);}
else{
C_trace("setup-download.scm: 148  get-temporary-directory");
f_882(t6);}}

/* k1424 in a1391 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 148  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1394 in a1391 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1399,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1422,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 149  conc");
((C_proc7)C_retrieve_symbol_proc(lf[44]))(7,*((C_word*)lf[44]+1),t3,((C_word*)t0)[4],C_make_character(47),((C_word*)t0)[3],C_make_character(47),((C_word*)t0)[2]);}

/* k1420 in k1394 in a1391 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_truep(C_retrieve2(lf[2],"setup-download#*quiet*"))?lf[60]:lf[61]);
C_trace("setup-download.scm: 117  conc");
((C_proc15)C_retrieve_symbol_proc(lf[44]))(15,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[62],t2,C_make_character(32),t3,C_make_character(32),C_make_character(34),t1,C_make_character(34),C_make_character(32),C_make_character(34),t4,C_make_character(34),t5);}

/* k1397 in k1394 in a1391 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1402,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 150  d");
f_860(t2,lf[59],C_a_i_list(&a,1,t1));}

/* k1400 in k1397 in k1394 in a1391 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1418,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 151  system");
((C_proc3)C_retrieve_symbol_proc(lf[58]))(3,*((C_word*)lf[58]+1),t2,((C_word*)t0)[2]);}

/* k1416 in k1400 in k1397 in k1394 in a1391 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_zerop(t1))){
C_trace("setup-download.scm: 152  values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_trace("setup-download.scm: 153  values");
C_values(4,0,((C_word*)t0)[4],C_SCHEME_FALSE,lf[57]);}}

/* a1363 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1364,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1375,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 142  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t2,lf[51],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1378,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
if(C_truep(t4)){
C_trace("setup-download.scm: 76   warning");
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t2,lf[25],t3,t4);}
else{
if(C_truep(C_i_member(lf[52],((C_word*)t0)[4]))){
C_trace("setup-download.scm: 146  values");
C_values(4,0,t1,lf[53],lf[54]);}
else{
C_trace("setup-download.scm: 147  values");
C_values(4,0,t1,lf[55],lf[56]);}}}}

/* k1376 in a1363 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_member(lf[52],((C_word*)t0)[3]))){
C_trace("setup-download.scm: 146  values");
C_values(4,0,((C_word*)t0)[2],lf[53],lf[54]);}
else{
C_trace("setup-download.scm: 147  values");
C_values(4,0,((C_word*)t0)[2],lf[55],lf[56]);}}

/* k1373 in a1363 in k1357 in k1354 in k1351 in k1348 in k1345 in k1342 in body368 in setup-download#locate-egg/svn in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 142  values");
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* setup-download#make-svn-ls-cmd in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1181(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1181,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1185,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t6,lf[48],t5);}

/* k1183 in setup-download#make-svn-ls-cmd in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1185,2,t0,t1);}
t2=(C_truep(t1)?lf[42]:lf[43]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1196,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 114  qs");
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,((C_word*)t0)[2]);}

/* k1194 in k1183 in setup-download#make-svn-ls-cmd in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 114  conc");
((C_proc8)C_retrieve_symbol_proc(lf[44]))(8,*((C_word*)lf[44]+1),((C_word*)t0)[5],lf[45],((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1075,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1079,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 96   directory");
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t3,t2);}

/* k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1084,a[2]=((C_word*)t0)[3],a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 97   filter-map");
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),((C_word*)t0)[2],t2,t1);}

/* a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1084(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1084,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1090,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li7),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1096,a[2]=t2,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t3,t4);}

/* a1095 in a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1096,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1100,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 100  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[19]))(5,*((C_word*)lf[19]+1),t4,t2,((C_word*)t0)[2],lf[39]);}

/* k1098 in a1095 in a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1106,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 101  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t2,t1);}

/* k1104 in k1098 in a1095 in a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1106,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1111,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li15),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 102  call/cc");
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1110 in k1104 in k1098 in a1095 in a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1111,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm: 104  string->symbol");
((C_proc3)C_retrieve_proc(*((C_word*)lf[37]+1)))(3,*((C_word*)lf[37]+1),t3,((C_word*)t0)[3]);}

/* k1117 in a1110 in k1104 in k1098 in a1095 in a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1119,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[31],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1131,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li14),tmp=(C_word)a,a+=6,tmp);
C_trace("call-with-current-continuation");
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t3,t4);}

/* a1135 in k1117 in a1110 in k1104 in k1098 in a1095 in a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1136,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1142,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li9),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1157,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
C_trace("with-exception-handler");
((C_proc4)C_retrieve_symbol_proc(lf[35]))(4,*((C_word*)lf[35]+1),t1,t3,t4);}

/* a1156 in a1135 in k1117 in a1110 in k1104 in k1098 in a1095 in a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1163,a[2]=((C_word*)t0)[3],a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1169,a[2]=((C_word*)t0)[2],a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a1168 in a1156 in a1135 in k1117 in a1110 in k1104 in k1098 in a1095 in a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1169r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1169r(t0,t1,t2);}}

static void C_ccall f_1169r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1175,a[2]=t2,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
C_trace("k264269");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1174 in a1168 in a1156 in a1135 in k1117 in a1110 in k1104 in k1098 in a1095 in a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1175,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1162 in a1156 in a1135 in k1117 in a1110 in k1104 in k1098 in a1095 in a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1163,2,t0,t1);}
C_trace("setup-download.scm: 110  with-input-from-file");
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t1,((C_word*)t0)[2],*((C_word*)lf[34]+1));}

/* a1141 in a1135 in k1117 in a1110 in k1104 in k1098 in a1095 in a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1142,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1148,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp);
C_trace("k264269");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1147 in a1141 in a1135 in k1117 in a1110 in k1104 in k1098 in a1095 in a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1152,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 108  warning");
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t2,lf[32],((C_word*)t0)[2]);}

/* k1150 in a1147 in a1141 in a1135 in k1117 in a1110 in k1104 in k1098 in a1095 in a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 109  return");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1129 in k1117 in a1110 in k1104 in k1098 in a1095 in a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("g267268");
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1132 in k1129 in k1117 in a1110 in k1104 in k1098 in a1095 in a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1134,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* a1089 in a1083 in k1077 in setup-download#gather-egg-information in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1090,2,t0,t1);}
C_trace("setup-download.scm: 99   locate-egg/local");
((C_proc4)C_retrieve_symbol_proc(lf[18]))(4,*((C_word*)lf[18]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-download#locate-egg/local in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_953r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_953r(t0,t1,t2,t3,t4);}}

static void C_ccall f_953r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_955,a[2]=t3,a[3]=t2,a[4]=((C_word)li3),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1022,a[2]=t5,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1027,a[2]=t6,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
C_trace("def-version215240");
t8=t7;
f_1027(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
C_trace("def-destination216238");
t10=t6;
f_1022(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
C_trace("body213221");
t12=t5;
f_955(t12,t1,t8);}
else{
C_trace("##sys#error");
t12=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-version215 in setup-download#locate-egg/local in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1027(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1027,NULL,2,t0,t1);}
C_trace("def-destination216238");
t2=((C_word*)t0)[2];
f_1022(t2,t1,C_SCHEME_FALSE);}

/* def-destination216 in setup-download#locate-egg/local in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_1022(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1022,NULL,3,t0,t1,t2);}
C_trace("body213221");
t3=((C_word*)t0)[2];
f_955(t3,t1,t2);}

/* body213 in setup-download#locate-egg/local in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_955(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_955,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_959,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 82   make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k957 in body213 in setup-download#locate-egg/local in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 83   make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),t2,t1,lf[28]);}

/* k960 in k957 in body213 in setup-download#locate-egg/local in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=C_retrieve2(lf[4],"setup-download#*trunk*");
if(C_truep(t3)){
t4=t2;
f_965(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1008,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 85   file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t4,t1);}}

/* k1006 in k960 in k957 in body213 in setup-download#locate-egg/local in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1008,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 85   directory?");
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_965(2,t2,C_SCHEME_FALSE);}}

/* k1012 in k1006 in k960 in k957 in body213 in setup-download#locate-egg/local in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1014,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1021,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm: 86   directory");
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_965(2,t2,C_SCHEME_FALSE);}}

/* k1019 in k1012 in k1006 in k960 in k957 in body213 in setup-download#locate-egg/local in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_1021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 86   existing-version");
f_897(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k963 in k960 in k957 in body213 in setup-download#locate-egg/local in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_965,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_975,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 88   make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),t2,((C_word*)t0)[5],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 89   make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),t2,((C_word*)t0)[4],lf[26]);}}

/* k976 in k963 in k960 in k957 in body213 in setup-download#locate-egg/local in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_981,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
if(C_truep(t4)){
C_trace("setup-download.scm: 76   warning");
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t2,lf[25],t3,t4);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t2;
f_981(2,t6,t5);}}

/* k979 in k976 in k963 in k960 in k957 in body213 in setup-download#locate-egg/local in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm: 91   file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t3,((C_word*)t0)[3]);}

/* k994 in k979 in k976 in k963 in k960 in k957 in body213 in setup-download#locate-egg/local in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-download.scm: 91   directory?");
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
C_trace("setup-download.scm: 93   values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],lf[21]);}}

/* k985 in k979 in k976 in k963 in k960 in k957 in body213 in setup-download#locate-egg/local in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-download.scm: 92   values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],lf[20]);}
else{
C_trace("setup-download.scm: 93   values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[2],lf[21]);}}

/* k973 in k963 in k960 in k957 in body213 in setup-download#locate-egg/local in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 88   values");
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* setup-download#existing-version in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_897(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_897,NULL,4,t1,t2,t3,t4);}
if(C_truep(t3)){
if(C_truep(C_i_member(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
C_trace("setup-download.scm: 70   error");
((C_proc5)C_retrieve_proc(*((C_word*)lf[14]+1)))(5,*((C_word*)lf[14]+1),t1,lf[15],t2,t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_913,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 71   sort");
((C_proc4)C_retrieve_symbol_proc(lf[16]))(4,*((C_word*)lf[16]+1),t5,t4,C_retrieve(lf[17]));}}

/* k911 in setup-download#existing-version in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_pairp(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_i_car(t1):C_SCHEME_FALSE));}

/* setup-download#get-temporary-directory in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_882(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_882,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_886,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 61   temporary-directory");
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t2);}

/* k884 in setup-download#get-temporary-directory in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_886,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_892,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm: 62   setup-api#create-temporary-directory");
((C_proc2)C_retrieve_symbol_proc(lf[12]))(2,*((C_word*)lf[12]+1),t2);}}

/* k890 in k884 in setup-download#get-temporary-directory in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_895,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm: 63   temporary-directory");
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),t2,t1);}

/* k893 in k890 in k884 in setup-download#get-temporary-directory in k878 in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* setup-download#d in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_fcall f_860(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_860,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_864,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[2],"setup-download#*quiet*"))){
C_trace("setup-download.scm: 54   current-error-port");
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t4);}
else{
C_trace("setup-download.scm: 54   current-output-port");
((C_proc2)C_retrieve_proc(*((C_word*)lf[9]+1)))(2,*((C_word*)lf[9]+1),t4);}}

/* k862 in setup-download#d in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_867,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t2,C_retrieve(lf[7]),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k865 in k862 in setup-download#d in k855 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 in k826 in k823 in k820 in k817 in k814 in k811 in k808 */
static void C_ccall f_867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm: 56   flush-output");
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[220] = {
{"toplevel:setup_download_scm",(void*)C_toplevel},
{"f_810:setup_download_scm",(void*)f_810},
{"f_813:setup_download_scm",(void*)f_813},
{"f_816:setup_download_scm",(void*)f_816},
{"f_819:setup_download_scm",(void*)f_819},
{"f_822:setup_download_scm",(void*)f_822},
{"f_825:setup_download_scm",(void*)f_825},
{"f_828:setup_download_scm",(void*)f_828},
{"f_831:setup_download_scm",(void*)f_831},
{"f_834:setup_download_scm",(void*)f_834},
{"f_837:setup_download_scm",(void*)f_837},
{"f_840:setup_download_scm",(void*)f_840},
{"f_843:setup_download_scm",(void*)f_843},
{"f_846:setup_download_scm",(void*)f_846},
{"f_849:setup_download_scm",(void*)f_849},
{"f_852:setup_download_scm",(void*)f_852},
{"f_2319:setup_download_scm",(void*)f_2319},
{"f_857:setup_download_scm",(void*)f_857},
{"f_880:setup_download_scm",(void*)f_880},
{"f_2268:setup_download_scm",(void*)f_2268},
{"f_2272:setup_download_scm",(void*)f_2272},
{"f_2275:setup_download_scm",(void*)f_2275},
{"f_2278:setup_download_scm",(void*)f_2278},
{"f_2312:setup_download_scm",(void*)f_2312},
{"f_2288:setup_download_scm",(void*)f_2288},
{"f_1290:setup_download_scm",(void*)f_1290},
{"f_1285:setup_download_scm",(void*)f_1285},
{"f_1210:setup_download_scm",(void*)f_1210},
{"f_1214:setup_download_scm",(void*)f_1214},
{"f_1217:setup_download_scm",(void*)f_1217},
{"f_1220:setup_download_scm",(void*)f_1220},
{"f_1223:setup_download_scm",(void*)f_1223},
{"f_1234:setup_download_scm",(void*)f_1234},
{"f_1236:setup_download_scm",(void*)f_1236},
{"f_1271:setup_download_scm",(void*)f_1271},
{"f_1274:setup_download_scm",(void*)f_1274},
{"f_1230:setup_download_scm",(void*)f_1230},
{"f_951:setup_download_scm",(void*)f_951},
{"f_943:setup_download_scm",(void*)f_943},
{"f_941:setup_download_scm",(void*)f_941},
{"f_2283:setup_download_scm",(void*)f_2283},
{"f_2182:setup_download_scm",(void*)f_2182},
{"f_2186:setup_download_scm",(void*)f_2186},
{"f_2189:setup_download_scm",(void*)f_2189},
{"f_2192:setup_download_scm",(void*)f_2192},
{"f_2195:setup_download_scm",(void*)f_2195},
{"f_2198:setup_download_scm",(void*)f_2198},
{"f_2201:setup_download_scm",(void*)f_2201},
{"f_2204:setup_download_scm",(void*)f_2204},
{"f_2207:setup_download_scm",(void*)f_2207},
{"f_2210:setup_download_scm",(void*)f_2210},
{"f_2261:setup_download_scm",(void*)f_2261},
{"f_2222:setup_download_scm",(void*)f_2222},
{"f_2232:setup_download_scm",(void*)f_2232},
{"f_2215:setup_download_scm",(void*)f_2215},
{"f_1599:setup_download_scm",(void*)f_1599},
{"f_1677:setup_download_scm",(void*)f_1677},
{"f_1672:setup_download_scm",(void*)f_1672},
{"f_1667:setup_download_scm",(void*)f_1667},
{"f_1662:setup_download_scm",(void*)f_1662},
{"f_1657:setup_download_scm",(void*)f_1657},
{"f_1601:setup_download_scm",(void*)f_1601},
{"f_1605:setup_download_scm",(void*)f_1605},
{"f_1616:setup_download_scm",(void*)f_1616},
{"f_1646:setup_download_scm",(void*)f_1646},
{"f_1620:setup_download_scm",(void*)f_1620},
{"f_1623:setup_download_scm",(void*)f_1623},
{"f_1639:setup_download_scm",(void*)f_1639},
{"f_1626:setup_download_scm",(void*)f_1626},
{"f_2102:setup_download_scm",(void*)f_2102},
{"f_2105:setup_download_scm",(void*)f_2105},
{"f_2108:setup_download_scm",(void*)f_2108},
{"f_2111:setup_download_scm",(void*)f_2111},
{"f_2114:setup_download_scm",(void*)f_2114},
{"f_2117:setup_download_scm",(void*)f_2117},
{"f_2099:setup_download_scm",(void*)f_2099},
{"f_1870:setup_download_scm",(void*)f_1870},
{"f_1889:setup_download_scm",(void*)f_1889},
{"f_1893:setup_download_scm",(void*)f_1893},
{"f_1828:setup_download_scm",(void*)f_1828},
{"f_1792:setup_download_scm",(void*)f_1792},
{"f_1825:setup_download_scm",(void*)f_1825},
{"f_1795:setup_download_scm",(void*)f_1795},
{"f_1822:setup_download_scm",(void*)f_1822},
{"f_1798:setup_download_scm",(void*)f_1798},
{"f_1819:setup_download_scm",(void*)f_1819},
{"f_1801:setup_download_scm",(void*)f_1801},
{"f_1804:setup_download_scm",(void*)f_1804},
{"f_1807:setup_download_scm",(void*)f_1807},
{"f_1814:setup_download_scm",(void*)f_1814},
{"f_2095:setup_download_scm",(void*)f_2095},
{"f_1896:setup_download_scm",(void*)f_1896},
{"f_1899:setup_download_scm",(void*)f_1899},
{"f_1902:setup_download_scm",(void*)f_1902},
{"f_1905:setup_download_scm",(void*)f_1905},
{"f_1908:setup_download_scm",(void*)f_1908},
{"f_1911:setup_download_scm",(void*)f_1911},
{"f_2088:setup_download_scm",(void*)f_2088},
{"f_1782:setup_download_scm",(void*)f_1782},
{"f_1786:setup_download_scm",(void*)f_1786},
{"f_1778:setup_download_scm",(void*)f_1778},
{"f_1914:setup_download_scm",(void*)f_1914},
{"f_2062:setup_download_scm",(void*)f_2062},
{"f_2066:setup_download_scm",(void*)f_2066},
{"f_2072:setup_download_scm",(void*)f_2072},
{"f_2084:setup_download_scm",(void*)f_2084},
{"f2436:setup_download_scm",(void*)f2436},
{"f2432:setup_download_scm",(void*)f2432},
{"f_1917:setup_download_scm",(void*)f_1917},
{"f_2050:setup_download_scm",(void*)f_2050},
{"f_2150:setup_download_scm",(void*)f_2150},
{"f_2180:setup_download_scm",(void*)f_2180},
{"f_2154:setup_download_scm",(void*)f_2154},
{"f_2166:setup_download_scm",(void*)f_2166},
{"f_2169:setup_download_scm",(void*)f_2169},
{"f_2053:setup_download_scm",(void*)f_2053},
{"f_2056:setup_download_scm",(void*)f_2056},
{"f_2060:setup_download_scm",(void*)f_2060},
{"f_1920:setup_download_scm",(void*)f_1920},
{"f_1923:setup_download_scm",(void*)f_1923},
{"f_1928:setup_download_scm",(void*)f_1928},
{"f_1932:setup_download_scm",(void*)f_1932},
{"f_1938:setup_download_scm",(void*)f_1938},
{"f_1982:setup_download_scm",(void*)f_1982},
{"f_2001:setup_download_scm",(void*)f_2001},
{"f_2004:setup_download_scm",(void*)f_2004},
{"f_2007:setup_download_scm",(void*)f_2007},
{"f_2010:setup_download_scm",(void*)f_2010},
{"f_2024:setup_download_scm",(void*)f_2024},
{"f_2026:setup_download_scm",(void*)f_2026},
{"f_2013:setup_download_scm",(void*)f_2013},
{"f_1985:setup_download_scm",(void*)f_1985},
{"f_1988:setup_download_scm",(void*)f_1988},
{"f_1998:setup_download_scm",(void*)f_1998},
{"f_1991:setup_download_scm",(void*)f_1991},
{"f_1961:setup_download_scm",(void*)f_1961},
{"f_1964:setup_download_scm",(void*)f_1964},
{"f_2142:setup_download_scm",(void*)f_2142},
{"f_2134:setup_download_scm",(void*)f_2134},
{"f_2138:setup_download_scm",(void*)f_2138},
{"f_2130:setup_download_scm",(void*)f_2130},
{"f_1875:setup_download_scm",(void*)f_1875},
{"f_1629:setup_download_scm",(void*)f_1629},
{"f_1610:setup_download_scm",(void*)f_1610},
{"f_1553:setup_download_scm",(void*)f_1553},
{"f_1577:setup_download_scm",(void*)f_1577},
{"f_1564:setup_download_scm",(void*)f_1564},
{"f_1338:setup_download_scm",(void*)f_1338},
{"f_1471:setup_download_scm",(void*)f_1471},
{"f_1466:setup_download_scm",(void*)f_1466},
{"f_1461:setup_download_scm",(void*)f_1461},
{"f_1456:setup_download_scm",(void*)f_1456},
{"f_1340:setup_download_scm",(void*)f_1340},
{"f_1344:setup_download_scm",(void*)f_1344},
{"f_1347:setup_download_scm",(void*)f_1347},
{"f_1449:setup_download_scm",(void*)f_1449},
{"f_1350:setup_download_scm",(void*)f_1350},
{"f_1353:setup_download_scm",(void*)f_1353},
{"f_1356:setup_download_scm",(void*)f_1356},
{"f_1435:setup_download_scm",(void*)f_1435},
{"f_1439:setup_download_scm",(void*)f_1439},
{"f_1433:setup_download_scm",(void*)f_1433},
{"f_1359:setup_download_scm",(void*)f_1359},
{"f_1392:setup_download_scm",(void*)f_1392},
{"f_1426:setup_download_scm",(void*)f_1426},
{"f_1396:setup_download_scm",(void*)f_1396},
{"f_1422:setup_download_scm",(void*)f_1422},
{"f_1399:setup_download_scm",(void*)f_1399},
{"f_1402:setup_download_scm",(void*)f_1402},
{"f_1418:setup_download_scm",(void*)f_1418},
{"f_1364:setup_download_scm",(void*)f_1364},
{"f_1378:setup_download_scm",(void*)f_1378},
{"f_1375:setup_download_scm",(void*)f_1375},
{"f_1181:setup_download_scm",(void*)f_1181},
{"f_1185:setup_download_scm",(void*)f_1185},
{"f_1196:setup_download_scm",(void*)f_1196},
{"f_1075:setup_download_scm",(void*)f_1075},
{"f_1079:setup_download_scm",(void*)f_1079},
{"f_1084:setup_download_scm",(void*)f_1084},
{"f_1096:setup_download_scm",(void*)f_1096},
{"f_1100:setup_download_scm",(void*)f_1100},
{"f_1106:setup_download_scm",(void*)f_1106},
{"f_1111:setup_download_scm",(void*)f_1111},
{"f_1119:setup_download_scm",(void*)f_1119},
{"f_1136:setup_download_scm",(void*)f_1136},
{"f_1157:setup_download_scm",(void*)f_1157},
{"f_1169:setup_download_scm",(void*)f_1169},
{"f_1175:setup_download_scm",(void*)f_1175},
{"f_1163:setup_download_scm",(void*)f_1163},
{"f_1142:setup_download_scm",(void*)f_1142},
{"f_1148:setup_download_scm",(void*)f_1148},
{"f_1152:setup_download_scm",(void*)f_1152},
{"f_1131:setup_download_scm",(void*)f_1131},
{"f_1134:setup_download_scm",(void*)f_1134},
{"f_1090:setup_download_scm",(void*)f_1090},
{"f_953:setup_download_scm",(void*)f_953},
{"f_1027:setup_download_scm",(void*)f_1027},
{"f_1022:setup_download_scm",(void*)f_1022},
{"f_955:setup_download_scm",(void*)f_955},
{"f_959:setup_download_scm",(void*)f_959},
{"f_962:setup_download_scm",(void*)f_962},
{"f_1008:setup_download_scm",(void*)f_1008},
{"f_1014:setup_download_scm",(void*)f_1014},
{"f_1021:setup_download_scm",(void*)f_1021},
{"f_965:setup_download_scm",(void*)f_965},
{"f_978:setup_download_scm",(void*)f_978},
{"f_981:setup_download_scm",(void*)f_981},
{"f_996:setup_download_scm",(void*)f_996},
{"f_987:setup_download_scm",(void*)f_987},
{"f_975:setup_download_scm",(void*)f_975},
{"f_897:setup_download_scm",(void*)f_897},
{"f_913:setup_download_scm",(void*)f_913},
{"f_882:setup_download_scm",(void*)f_882},
{"f_886:setup_download_scm",(void*)f_886},
{"f_892:setup_download_scm",(void*)f_892},
{"f_895:setup_download_scm",(void*)f_895},
{"f_860:setup_download_scm",(void*)f_860},
{"f_864:setup_download_scm",(void*)f_864},
{"f_867:setup_download_scm",(void*)f_867},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
