/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:53
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: support.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[504];
static double C_possibly_force_alignment;


/* from k4627 */
static C_word C_fcall stub273(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub273(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k4620 */
static C_word C_fcall stub269(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub269(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4018)
static void C_ccall f_4018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4021)
static void C_ccall f_4021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5086)
static void C_ccall f_5086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13422)
static void C_ccall f_13422(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13426)
static void C_ccall f_13426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13516)
static void C_ccall f_13516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13432)
static void C_ccall f_13432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13503)
static void C_ccall f_13503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13506)
static void C_ccall f_13506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13509)
static void C_ccall f_13509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13438)
static void C_ccall f_13438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13445)
static void C_ccall f_13445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13447)
static void C_fcall f_13447(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13471)
static void C_ccall f_13471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13467)
static void C_ccall f_13467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13489)
static void C_ccall f_13489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13411)
static void C_ccall f_13411(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13400)
static void C_ccall f_13400(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13394)
static void C_ccall f_13394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13366)
static void C_ccall f_13366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_13366)
static void C_ccall f_13366r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_13370)
static void C_ccall f_13370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13345)
static void C_ccall f_13345(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13349)
static void C_ccall f_13349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13312)
static void C_ccall f_13312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13318)
static void C_ccall f_13318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13279)
static void C_ccall f_13279(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13285)
static void C_ccall f_13285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13255)
static void C_ccall f_13255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13186)
static void C_ccall f_13186(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13190)
static void C_ccall f_13190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13195)
static void C_fcall f_13195(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13199)
static void C_ccall f_13199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13250)
static void C_ccall f_13250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13229)
static void C_ccall f_13229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13241)
static void C_ccall f_13241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13244)
static void C_ccall f_13244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13217)
static void C_ccall f_13217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13153)
static void C_ccall f_13153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13163)
static void C_ccall f_13163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13166)
static void C_ccall f_13166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13147)
static void C_ccall f_13147(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13102)
static void C_ccall f_13102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13109)
static void C_fcall f_13109(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13124)
static void C_ccall f_13124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13128)
static void C_ccall f_13128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13120)
static void C_ccall f_13120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13106)
static void C_ccall f_13106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12979)
static void C_ccall f_12979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12988)
static void C_fcall f_12988(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13016)
static void C_ccall f_13016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13022)
static void C_ccall f_13022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13025)
static void C_ccall f_13025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13028)
static void C_ccall f_13028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13031)
static void C_ccall f_13031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13034)
static void C_ccall f_13034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13037)
static void C_ccall f_13037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13096)
static void C_ccall f_13096(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13040)
static void C_ccall f_13040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13055)
static void C_ccall f_13055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13058)
static void C_ccall f_13058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13066)
static void C_fcall f_13066(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13076)
static void C_ccall f_13076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13079)
static void C_ccall f_13079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13061)
static void C_ccall f_13061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13046)
static void C_ccall f_13046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12983)
static void C_ccall f_12983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12976)
static void C_ccall f_12976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12958)
static void C_ccall f_12958(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12924)
static void C_ccall f_12924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12948)
static void C_ccall f_12948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12944)
static void C_ccall f_12944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12903)
static void C_ccall f_12903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12909)
static void C_ccall f_12909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12913)
static void C_ccall f_12913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12916)
static void C_ccall f_12916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12919)
static void C_ccall f_12919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12891)
static void C_ccall f_12891(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12895)
static void C_ccall f_12895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12800)
static void C_ccall f_12800(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_12800)
static void C_ccall f_12800r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_12819)
static void C_ccall f_12819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12844)
static void C_ccall f_12844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12848)
static void C_ccall f_12848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12850)
static void C_fcall f_12850(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12857)
static void C_ccall f_12857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12870)
static void C_ccall f_12870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12873)
static void C_ccall f_12873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12876)
static void C_ccall f_12876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12879)
static void C_ccall f_12879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12882)
static void C_ccall f_12882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12886)
static void C_ccall f_12886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12803)
static void C_fcall f_12803(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12807)
static void C_ccall f_12807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12813)
static void C_ccall f_12813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12794)
static void C_ccall f_12794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12735)
static void C_ccall f_12735(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_12735)
static void C_ccall f_12735r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_12743)
static void C_ccall f_12743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12770)
static void C_ccall f_12770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12746)
static void C_ccall f_12746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12749)
static void C_ccall f_12749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12766)
static void C_ccall f_12766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12752)
static void C_ccall f_12752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12762)
static void C_ccall f_12762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12755)
static void C_ccall f_12755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12758)
static void C_ccall f_12758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12726)
static void C_ccall f_12726(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12720)
static void C_ccall f_12720(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12714)
static void C_ccall f_12714(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12702)
static void C_ccall f_12702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12706)
static void C_ccall f_12706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12709)
static void C_ccall f_12709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12664)
static void C_ccall f_12664(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_12664)
static void C_ccall f_12664r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_12668)
static void C_ccall f_12668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f14656)
static void C_ccall f14656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12671)
static void C_ccall f_12671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12678)
static void C_ccall f_12678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12622)
static void C_ccall f_12622(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12631)
static void C_fcall f_12631(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12593)
static void C_ccall f_12593(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12603)
static void C_fcall f_12603(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12384)
static void C_ccall f_12384(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12588)
static void C_ccall f_12588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12553)
static void C_fcall f_12553(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12559)
static void C_fcall f_12559(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12574)
static void C_ccall f_12574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12567)
static void C_fcall f_12567(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12387)
static void C_fcall f_12387(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12421)
static void C_fcall f_12421(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12515)
static void C_ccall f_12515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12527)
static void C_ccall f_12527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12485)
static void C_ccall f_12485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12496)
static void C_ccall f_12496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12476)
static void C_ccall f_12476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12440)
static void C_ccall f_12440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12446)
static void C_ccall f_12446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12450)
static void C_ccall f_12450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12245)
static void C_ccall f_12245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12251)
static void C_fcall f_12251(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12344)
static void C_fcall f_12344(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12349)
static void C_fcall f_12349(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12359)
static void C_ccall f_12359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12312)
static void C_fcall f_12312(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12283)
static void C_fcall f_12283(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12288)
static void C_fcall f_12288(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12298)
static void C_ccall f_12298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12249)
static void C_ccall f_12249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11876)
static void C_ccall f_11876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12075)
static void C_fcall f_12075(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12167)
static void C_fcall f_12167(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12078)
static void C_ccall f_12078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11555)
static void C_ccall f_11555(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11870)
static void C_ccall f_11870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11567)
static void C_ccall f_11567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11577)
static void C_fcall f_11577(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11595)
static void C_ccall f_11595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11634)
static void C_fcall f_11634(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11599)
static void C_fcall f_11599(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11225)
static void C_ccall f_11225(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11549)
static void C_ccall f_11549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11231)
static void C_ccall f_11231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11241)
static void C_fcall f_11241(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11250)
static void C_fcall f_11250(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11262)
static void C_fcall f_11262(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11274)
static void C_fcall f_11274(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11280)
static void C_ccall f_11280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11284)
static void C_fcall f_11284(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11180)
static void C_ccall f_11180(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11219)
static void C_ccall f_11219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11186)
static void C_ccall f_11186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11190)
static void C_ccall f_11190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11194)
static void C_fcall f_11194(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11149)
static void C_ccall f_11149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11162)
static void C_ccall f_11162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11118)
static void C_ccall f_11118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11131)
static void C_ccall f_11131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10060)
static void C_ccall f_10060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11112)
static void C_ccall f_11112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10066)
static void C_ccall f_10066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10072)
static void C_fcall f_10072(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10101)
static void C_fcall f_10101(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10120)
static void C_fcall f_10120(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10139)
static void C_fcall f_10139(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10209)
static void C_fcall f_10209(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10228)
static void C_fcall f_10228(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10310)
static void C_fcall f_10310(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10349)
static void C_fcall f_10349(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10368)
static void C_fcall f_10368(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10387)
static void C_fcall f_10387(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10467)
static void C_fcall f_10467(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10552)
static void C_fcall f_10552(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10627)
static void C_ccall f_10627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10666)
static void C_fcall f_10666(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10736)
static void C_ccall f_10736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10669)
static void C_ccall f_10669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10631)
static void C_fcall f_10631(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10470)
static void C_ccall f_10470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10501)
static void C_fcall f_10501(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10390)
static void C_ccall f_10390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10231)
static void C_ccall f_10231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10262)
static void C_fcall f_10262(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10142)
static void C_ccall f_10142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10173)
static void C_fcall f_10173(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10002)
static void C_ccall f_10002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10006)
static void C_ccall f_10006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10017)
static void C_ccall f_10017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10023)
static void C_fcall f_10023(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10035)
static void C_ccall f_10035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10041)
static void C_ccall f_10041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10009)
static void C_ccall f_10009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9921)
static void C_ccall f_9921(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9933)
static void C_ccall f_9933(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_9940)
static void C_ccall f_9940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9943)
static void C_ccall f_9943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9946)
static void C_ccall f_9946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9949)
static void C_ccall f_9949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9952)
static void C_ccall f_9952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9955)
static void C_ccall f_9955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9958)
static void C_ccall f_9958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9961)
static void C_ccall f_9961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9964)
static void C_ccall f_9964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9967)
static void C_ccall f_9967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9970)
static void C_ccall f_9970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9973)
static void C_ccall f_9973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9976)
static void C_ccall f_9976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9979)
static void C_ccall f_9979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9982)
static void C_ccall f_9982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9985)
static void C_ccall f_9985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9988)
static void C_ccall f_9988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9991)
static void C_ccall f_9991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9994)
static void C_ccall f_9994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9997)
static void C_ccall f_9997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9927)
static void C_ccall f_9927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9813)
static void C_ccall f_9813(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9822)
static void C_ccall f_9822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9828)
static void C_fcall f_9828(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9836)
static C_word C_fcall f_9836(C_word t0,C_word t1);
C_noret_decl(f_9817)
static void C_ccall f_9817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9792)
static void C_ccall f_9792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9802)
static void C_ccall f_9802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9743)
static void C_ccall f_9743(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9749)
static void C_ccall f_9749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9790)
static void C_ccall f_9790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9762)
static void C_ccall f_9762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9706)
static void C_ccall f_9706(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9712)
static void C_ccall f_9712(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9741)
static void C_ccall f_9741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9719)
static void C_fcall f_9719(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9722)
static void C_ccall f_9722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9665)
static void C_ccall f_9665(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9671)
static void C_ccall f_9671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9704)
static void C_ccall f_9704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9678)
static void C_fcall f_9678(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9681)
static void C_ccall f_9681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9543)
static void C_ccall f_9543(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9572)
static void C_ccall f_9572(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9442)
static void C_ccall f_9442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9448)
static void C_ccall f_9448(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9474)
static void C_fcall f_9474(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9488)
static void C_ccall f_9488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9496)
static void C_ccall f_9496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9217)
static void C_ccall f_9217(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9416)
static void C_ccall f_9416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9422)
static void C_ccall f_9422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9297)
static void C_fcall f_9297(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9319)
static void C_ccall f_9319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9337)
static void C_fcall f_9337(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9368)
static void C_ccall f_9368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9254)
static void C_fcall f_9254(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9276)
static void C_ccall f_9276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9220)
static void C_fcall f_9220(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9249)
static void C_ccall f_9249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9228)
static C_word C_fcall f_9228(C_word t0,C_word t1);
C_noret_decl(f_9148)
static void C_ccall f_9148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9154)
static void C_ccall f_9154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9160)
static void C_fcall f_9160(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9164)
static void C_ccall f_9164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9211)
static void C_ccall f_9211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9175)
static void C_ccall f_9175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9200)
static void C_ccall f_9200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8956)
static void C_ccall f_8956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8987)
static void C_ccall f_8987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9146)
static void C_ccall f_9146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8991)
static void C_ccall f_8991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8999)
static void C_ccall f_8999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9006)
static void C_ccall f_9006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9142)
static void C_ccall f_9142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9030)
static void C_fcall f_9030(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9109)
static void C_ccall f_9109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9064)
static void C_ccall f_9064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9067)
static void C_fcall f_9067(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9085)
static void C_ccall f_9085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9074)
static void C_ccall f_9074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8994)
static void C_ccall f_8994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8960)
static void C_ccall f_8960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8966)
static void C_ccall f_8966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8979)
static void C_ccall f_8979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8971)
static void C_ccall f_8971(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8888)
static void C_ccall f_8888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8894)
static void C_fcall f_8894(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8921)
static void C_fcall f_8921(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8950)
static void C_ccall f_8950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8915)
static void C_ccall f_8915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8802)
static void C_ccall f_8802(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8808)
static void C_fcall f_8808(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8853)
static void C_fcall f_8853(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8882)
static void C_ccall f_8882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8842)
static void C_ccall f_8842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8838)
static void C_ccall f_8838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8763)
static void C_ccall f_8763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8767)
static void C_ccall f_8767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8770)
static void C_ccall f_8770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8773)
static void C_ccall f_8773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8729)
static void C_ccall f_8729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8735)
static void C_fcall f_8735(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8749)
static void C_ccall f_8749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8753)
static void C_ccall f_8753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8330)
static void C_ccall f_8330(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8680)
static void C_fcall f_8680(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8713)
static void C_ccall f_8713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8693)
static void C_fcall f_8693(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8334)
static void C_ccall f_8334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8342)
static void C_fcall f_8342(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8665)
static void C_ccall f_8665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8671)
static void C_ccall f_8671(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8669)
static void C_ccall f_8669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8505)
static void C_ccall f_8505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8612)
static void C_fcall f_8612(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8649)
static void C_ccall f_8649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8639)
static void C_fcall f_8639(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8643)
static void C_ccall f_8643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8646)
static void C_ccall f_8646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8509)
static void C_ccall f_8509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8563)
static void C_fcall f_8563(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8596)
static void C_ccall f_8596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8576)
static void C_fcall f_8576(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8561)
static void C_ccall f_8561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8512)
static void C_ccall f_8512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8538)
static void C_ccall f_8538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8554)
static void C_ccall f_8554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8546)
static void C_ccall f_8546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8530)
static void C_ccall f_8530(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8528)
static void C_ccall f_8528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8456)
static void C_ccall f_8456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8459)
static void C_ccall f_8459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8462)
static void C_ccall f_8462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8482)
static void C_ccall f_8482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8440)
static void C_ccall f_8440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8432)
static void C_ccall f_8432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8403)
static void C_ccall f_8403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8393)
static void C_ccall f_8393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8400)
static void C_ccall f_8400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8182)
static void C_ccall f_8182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8188)
static void C_ccall f_8188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8200)
static void C_ccall f_8200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8295)
static void C_fcall f_8295(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8324)
static void C_ccall f_8324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8204)
static void C_ccall f_8204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8207)
static void C_ccall f_8207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8287)
static void C_ccall f_8287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8233)
static void C_fcall f_8233(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8237)
static void C_ccall f_8237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8212)
static void C_ccall f_8212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8194)
static void C_ccall f_8194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8128)
static void C_ccall f_8128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8134)
static void C_fcall f_8134(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8160)
static void C_ccall f_8160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8164)
static void C_ccall f_8164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7447)
static void C_ccall f_7447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7453)
static void C_fcall f_7453(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7487)
static void C_fcall f_7487(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7945)
static void C_fcall f_7945(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8063)
static void C_fcall f_8063(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8092)
static void C_ccall f_8092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8061)
static void C_ccall f_8061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8057)
static void C_ccall f_8057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8017)
static void C_fcall f_8017(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8046)
static void C_ccall f_8046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8015)
static void C_ccall f_8015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7952)
static void C_ccall f_7952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7962)
static void C_fcall f_7962(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7991)
static void C_ccall f_7991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7956)
static void C_ccall f_7956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7883)
static void C_fcall f_7883(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7932)
static void C_ccall f_7932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7901)
static void C_ccall f_7901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7909)
static void C_ccall f_7909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7826)
static void C_fcall f_7826(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7855)
static void C_ccall f_7855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7824)
static void C_ccall f_7824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7774)
static void C_fcall f_7774(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7803)
static void C_ccall f_7803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7756)
static void C_ccall f_7756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7700)
static void C_ccall f_7700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7702)
static void C_fcall f_7702(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7731)
static void C_ccall f_7731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7647)
static void C_ccall f_7647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7649)
static void C_fcall f_7649(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7682)
static void C_ccall f_7682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7662)
static void C_fcall f_7662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7631)
static void C_ccall f_7631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7643)
static void C_ccall f_7643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7639)
static void C_ccall f_7639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7552)
static void C_fcall f_7552(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7581)
static void C_ccall f_7581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7550)
static void C_ccall f_7550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7546)
static void C_ccall f_7546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7496)
static void C_fcall f_7496(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7525)
static void C_ccall f_7525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7494)
static void C_ccall f_7494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6524)
static void C_ccall f_6524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7442)
static void C_ccall f_7442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7445)
static void C_ccall f_7445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6527)
static void C_fcall f_6527(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7402)
static void C_fcall f_7402(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7431)
static void C_ccall f_7431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7400)
static void C_ccall f_7400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7140)
static void C_fcall f_7140(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7267)
static void C_ccall f_7267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7351)
static void C_ccall f_7351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7323)
static void C_fcall f_7323(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7330)
static void C_ccall f_7330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7337)
static void C_ccall f_7337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7327)
static void C_ccall f_7327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7286)
static void C_fcall f_7286(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7315)
static void C_ccall f_7315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7284)
static void C_ccall f_7284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7261)
static void C_ccall f_7261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7223)
static void C_fcall f_7223(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7252)
static void C_ccall f_7252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7217)
static void C_ccall f_7217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7166)
static void C_fcall f_7166(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7195)
static void C_ccall f_7195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7160)
static void C_ccall f_7160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7119)
static void C_ccall f_7119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7103)
static void C_ccall f_7103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7099)
static void C_ccall f_7099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7033)
static void C_fcall f_7033(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7062)
static void C_ccall f_7062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7027)
static void C_ccall f_7027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6943)
static void C_fcall f_6943(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6972)
static void C_ccall f_6972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6937)
static void C_ccall f_6937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6845)
static void C_fcall f_6845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6855)
static void C_fcall f_6855(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6884)
static void C_ccall f_6884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6849)
static void C_ccall f_6849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6812)
static void C_ccall f_6812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6719)
static void C_ccall f_6719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6741)
static void C_fcall f_6741(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6779)
static void C_ccall f_6779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6768)
static void C_fcall f_6768(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6727)
static void C_ccall f_6727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6735)
static void C_ccall f_6735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6723)
static void C_ccall f_6723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6660)
static void C_fcall f_6660(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6663)
static void C_ccall f_6663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6670)
static void C_ccall f_6670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6608)
static void C_fcall f_6608(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6637)
static void C_ccall f_6637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6602)
static void C_ccall f_6602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6509)
static void C_ccall f_6509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6494)
static void C_ccall f_6494(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6488)
static void C_ccall f_6488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6479)
static void C_ccall f_6479(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6470)
static void C_ccall f_6470(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6461)
static void C_ccall f_6461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6452)
static void C_ccall f_6452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6443)
static void C_ccall f_6443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6434)
static void C_ccall f_6434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5929)
static void C_ccall f_5929(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5933)
static void C_fcall f_5933(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5938)
static void C_ccall f_5938(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5948)
static void C_ccall f_5948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6111)
static void C_fcall f_6111(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6121)
static void C_ccall f_6121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6137)
static void C_fcall f_6137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6213)
static void C_fcall f_6213(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6253)
static void C_ccall f_6253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6243)
static void C_ccall f_6243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6216)
static void C_ccall f_6216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6233)
static void C_ccall f_6233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6219)
static void C_ccall f_6219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6222)
static void C_ccall f_6222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6229)
static void C_ccall f_6229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6204)
static void C_ccall f_6204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6194)
static void C_ccall f_6194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6178)
static void C_ccall f_6178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6155)
static void C_ccall f_6155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6124)
static void C_ccall f_6124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5951)
static void C_ccall f_5951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5992)
static void C_fcall f_5992(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6026)
static void C_fcall f_6026(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6060)
static void C_fcall f_6060(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6063)
static void C_ccall f_6063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6029)
static void C_ccall f_6029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5995)
static void C_ccall f_5995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5954)
static void C_ccall f_5954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5982)
static void C_ccall f_5982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5957)
static void C_ccall f_5957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5969)
static void C_ccall f_5969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5960)
static void C_ccall f_5960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5866)
static void C_ccall f_5866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5872)
static void C_ccall f_5872(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5879)
static void C_ccall f_5879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5882)
static void C_ccall f_5882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5894)
static void C_fcall f_5894(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5923)
static void C_ccall f_5923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5892)
static void C_ccall f_5892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5885)
static void C_ccall f_5885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5842)
static void C_ccall f_5842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5848)
static void C_fcall f_5848(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5858)
static void C_ccall f_5858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5801)
static void C_ccall f_5801(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5808)
static void C_ccall f_5808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5811)
static void C_fcall f_5811(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5815)
static void C_fcall f_5815(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5791)
static void C_ccall f_5791(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5782)
static void C_ccall f_5782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5786)
static void C_ccall f_5786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5725)
static void C_ccall f_5725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5725)
static void C_ccall f_5725r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5729)
static void C_ccall f_5729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5673)
static void C_ccall f_5673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5677)
static void C_ccall f_5677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5627)
static void C_ccall f_5627(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5631)
static void C_ccall f_5631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5653)
static void C_ccall f_5653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5613)
static void C_ccall f_5613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5621)
static void C_ccall f_5621(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5591)
static void C_ccall f_5591(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5595)
static void C_ccall f_5595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5500)
static void C_fcall f_5500(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5514)
static void C_ccall f_5514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5539)
static void C_ccall f_5539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5578)
static void C_ccall f_5578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5409)
static void C_fcall f_5409(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5423)
static void C_ccall f_5423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5459)
static void C_ccall f_5459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5487)
static void C_ccall f_5487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5349)
static void C_ccall f_5349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_fcall f_5354(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5368)
static void C_ccall f_5368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5396)
static void C_ccall f_5396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5342)
static void C_ccall f_5342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5197)
static void C_ccall f_5197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5194)
static void C_ccall f_5194(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5133)
static void C_ccall f_5133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5165)
static void C_ccall f_5165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5179)
static void C_ccall f_5179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5171)
static void C_ccall f_5171(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5137)
static void C_ccall f_5137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5159)
static void C_ccall f_5159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5116)
static void C_ccall f_5116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4992)
static void C_fcall f_4992(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5069)
static void C_ccall f_5069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5020)
static void C_fcall f_5020(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5046)
static void C_ccall f_5046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4984)
static void C_ccall f_4984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4880)
static void C_ccall f_4880(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4884)
static void C_fcall f_4884(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4850)
static void C_ccall f_4850(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4804)
static void C_ccall f_4804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4790)
static void C_ccall f_4790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4798)
static void C_ccall f_4798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4802)
static void C_ccall f_4802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4753)
static void C_ccall f_4753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4759)
static void C_fcall f_4759(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4706)
static void C_fcall f_4706(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4647)
static void C_ccall f_4647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_fcall f_4659(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4561)
static void C_ccall f_4561(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4467)
static void C_ccall f_4467(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4485)
static void C_fcall f_4485(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4507)
static void C_fcall f_4507(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_fcall f_4514(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4530)
static void C_ccall f_4530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4518)
static void C_ccall f_4518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4479)
static void C_ccall f_4479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4423)
static void C_ccall f_4423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4429)
static void C_fcall f_4429(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4453)
static void C_ccall f_4453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4418)
static void C_ccall f_4418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4365)
static void C_ccall f_4365(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4384)
static void C_ccall f_4384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4387)
static void C_ccall f_4387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4335)
static C_word C_fcall f_4335(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4261)
static void C_ccall f_4261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4285)
static void C_fcall f_4285(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4264)
static void C_fcall f_4264(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4272)
static void C_ccall f_4272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4276)
static void C_ccall f_4276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4224)
static void C_fcall f_4224(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4177)
static void C_fcall f_4177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4129)
static void C_fcall f_4129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4132)
static void C_ccall f_4132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4087)
static void C_fcall f_4087(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4109)
static void C_ccall f_4109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_13447)
static void C_fcall trf_13447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13447(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13447(t0,t1,t2);}

C_noret_decl(trf_13195)
static void C_fcall trf_13195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13195(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13195(t0,t1);}

C_noret_decl(trf_13109)
static void C_fcall trf_13109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13109(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13109(t0,t1);}

C_noret_decl(trf_12988)
static void C_fcall trf_12988(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12988(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12988(t0,t1,t2,t3);}

C_noret_decl(trf_13066)
static void C_fcall trf_13066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13066(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13066(t0,t1,t2);}

C_noret_decl(trf_12850)
static void C_fcall trf_12850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12850(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12850(t0,t1,t2,t3);}

C_noret_decl(trf_12803)
static void C_fcall trf_12803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12803(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12803(t0,t1);}

C_noret_decl(trf_12631)
static void C_fcall trf_12631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12631(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12631(t0,t1,t2);}

C_noret_decl(trf_12603)
static void C_fcall trf_12603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12603(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12603(t0,t1);}

C_noret_decl(trf_12553)
static void C_fcall trf_12553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12553(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12553(t0,t1,t2,t3);}

C_noret_decl(trf_12559)
static void C_fcall trf_12559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12559(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12559(t0,t1,t2);}

C_noret_decl(trf_12567)
static void C_fcall trf_12567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12567(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12567(t0,t1,t2);}

C_noret_decl(trf_12387)
static void C_fcall trf_12387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12387(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12387(t0,t1,t2,t3);}

C_noret_decl(trf_12421)
static void C_fcall trf_12421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12421(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12421(t0,t1);}

C_noret_decl(trf_12251)
static void C_fcall trf_12251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12251(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12251(t0,t1,t2);}

C_noret_decl(trf_12344)
static void C_fcall trf_12344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12344(t0,t1);}

C_noret_decl(trf_12349)
static void C_fcall trf_12349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12349(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12349(t0,t1,t2);}

C_noret_decl(trf_12312)
static void C_fcall trf_12312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12312(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12312(t0,t1);}

C_noret_decl(trf_12283)
static void C_fcall trf_12283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12283(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12283(t0,t1);}

C_noret_decl(trf_12288)
static void C_fcall trf_12288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12288(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12288(t0,t1,t2);}

C_noret_decl(trf_12075)
static void C_fcall trf_12075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12075(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12075(t0,t1);}

C_noret_decl(trf_12167)
static void C_fcall trf_12167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12167(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12167(t0,t1);}

C_noret_decl(trf_11577)
static void C_fcall trf_11577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11577(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11577(t0,t1);}

C_noret_decl(trf_11634)
static void C_fcall trf_11634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11634(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11634(t0,t1);}

C_noret_decl(trf_11599)
static void C_fcall trf_11599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11599(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11599(t0,t1,t2);}

C_noret_decl(trf_11241)
static void C_fcall trf_11241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11241(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11241(t0,t1);}

C_noret_decl(trf_11250)
static void C_fcall trf_11250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11250(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11250(t0,t1);}

C_noret_decl(trf_11262)
static void C_fcall trf_11262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11262(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11262(t0,t1);}

C_noret_decl(trf_11274)
static void C_fcall trf_11274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11274(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11274(t0,t1);}

C_noret_decl(trf_11284)
static void C_fcall trf_11284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11284(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11284(t0,t1,t2);}

C_noret_decl(trf_11194)
static void C_fcall trf_11194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11194(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11194(t0,t1,t2);}

C_noret_decl(trf_10072)
static void C_fcall trf_10072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10072(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10072(t0,t1,t2);}

C_noret_decl(trf_10101)
static void C_fcall trf_10101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10101(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10101(t0,t1);}

C_noret_decl(trf_10120)
static void C_fcall trf_10120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10120(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10120(t0,t1);}

C_noret_decl(trf_10139)
static void C_fcall trf_10139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10139(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10139(t0,t1);}

C_noret_decl(trf_10209)
static void C_fcall trf_10209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10209(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10209(t0,t1);}

C_noret_decl(trf_10228)
static void C_fcall trf_10228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10228(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10228(t0,t1);}

C_noret_decl(trf_10310)
static void C_fcall trf_10310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10310(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10310(t0,t1);}

C_noret_decl(trf_10349)
static void C_fcall trf_10349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10349(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10349(t0,t1);}

C_noret_decl(trf_10368)
static void C_fcall trf_10368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10368(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10368(t0,t1);}

C_noret_decl(trf_10387)
static void C_fcall trf_10387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10387(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10387(t0,t1);}

C_noret_decl(trf_10467)
static void C_fcall trf_10467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10467(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10467(t0,t1);}

C_noret_decl(trf_10552)
static void C_fcall trf_10552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10552(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10552(t0,t1);}

C_noret_decl(trf_10666)
static void C_fcall trf_10666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10666(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10666(t0,t1);}

C_noret_decl(trf_10631)
static void C_fcall trf_10631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10631(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10631(t0,t1,t2);}

C_noret_decl(trf_10501)
static void C_fcall trf_10501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10501(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10501(t0,t1);}

C_noret_decl(trf_10262)
static void C_fcall trf_10262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10262(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10262(t0,t1);}

C_noret_decl(trf_10173)
static void C_fcall trf_10173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10173(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10173(t0,t1);}

C_noret_decl(trf_10023)
static void C_fcall trf_10023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10023(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10023(t0,t1,t2);}

C_noret_decl(trf_9828)
static void C_fcall trf_9828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9828(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9828(t0,t1,t2);}

C_noret_decl(trf_9719)
static void C_fcall trf_9719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9719(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9719(t0,t1);}

C_noret_decl(trf_9678)
static void C_fcall trf_9678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9678(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9678(t0,t1);}

C_noret_decl(trf_9474)
static void C_fcall trf_9474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9474(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9474(t0,t1);}

C_noret_decl(trf_9297)
static void C_fcall trf_9297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9297(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9297(t0,t1,t2,t3);}

C_noret_decl(trf_9337)
static void C_fcall trf_9337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9337(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9337(t0,t1,t2,t3);}

C_noret_decl(trf_9254)
static void C_fcall trf_9254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9254(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9254(t0,t1,t2,t3);}

C_noret_decl(trf_9220)
static void C_fcall trf_9220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9220(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9220(t0,t1,t2,t3);}

C_noret_decl(trf_9160)
static void C_fcall trf_9160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9160(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9160(t0,t1);}

C_noret_decl(trf_9030)
static void C_fcall trf_9030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9030(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9030(t0,t1);}

C_noret_decl(trf_9067)
static void C_fcall trf_9067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9067(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9067(t0,t1);}

C_noret_decl(trf_8894)
static void C_fcall trf_8894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8894(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8894(t0,t1,t2);}

C_noret_decl(trf_8921)
static void C_fcall trf_8921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8921(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8921(t0,t1,t2);}

C_noret_decl(trf_8808)
static void C_fcall trf_8808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8808(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8808(t0,t1,t2);}

C_noret_decl(trf_8853)
static void C_fcall trf_8853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8853(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8853(t0,t1,t2);}

C_noret_decl(trf_8735)
static void C_fcall trf_8735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8735(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8735(t0,t1,t2);}

C_noret_decl(trf_8680)
static void C_fcall trf_8680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8680(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8680(t0,t1,t2,t3);}

C_noret_decl(trf_8693)
static void C_fcall trf_8693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8693(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8693(t0,t1);}

C_noret_decl(trf_8342)
static void C_fcall trf_8342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8342(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8342(t0,t1,t2,t3);}

C_noret_decl(trf_8612)
static void C_fcall trf_8612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8612(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8612(t0,t1,t2);}

C_noret_decl(trf_8639)
static void C_fcall trf_8639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8639(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8639(t0,t1,t2);}

C_noret_decl(trf_8563)
static void C_fcall trf_8563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8563(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8563(t0,t1,t2,t3);}

C_noret_decl(trf_8576)
static void C_fcall trf_8576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8576(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8576(t0,t1);}

C_noret_decl(trf_8295)
static void C_fcall trf_8295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8295(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8295(t0,t1,t2);}

C_noret_decl(trf_8233)
static void C_fcall trf_8233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8233(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8233(t0,t1);}

C_noret_decl(trf_8134)
static void C_fcall trf_8134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8134(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8134(t0,t1,t2);}

C_noret_decl(trf_7453)
static void C_fcall trf_7453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7453(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7453(t0,t1,t2);}

C_noret_decl(trf_7487)
static void C_fcall trf_7487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7487(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7487(t0,t1);}

C_noret_decl(trf_7945)
static void C_fcall trf_7945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7945(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7945(t0,t1);}

C_noret_decl(trf_8063)
static void C_fcall trf_8063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8063(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8063(t0,t1,t2);}

C_noret_decl(trf_8017)
static void C_fcall trf_8017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8017(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8017(t0,t1,t2);}

C_noret_decl(trf_7962)
static void C_fcall trf_7962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7962(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7962(t0,t1,t2);}

C_noret_decl(trf_7883)
static void C_fcall trf_7883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7883(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7883(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7826)
static void C_fcall trf_7826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7826(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7826(t0,t1,t2);}

C_noret_decl(trf_7774)
static void C_fcall trf_7774(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7774(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7774(t0,t1,t2);}

C_noret_decl(trf_7702)
static void C_fcall trf_7702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7702(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7702(t0,t1,t2);}

C_noret_decl(trf_7649)
static void C_fcall trf_7649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7649(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7649(t0,t1,t2,t3);}

C_noret_decl(trf_7662)
static void C_fcall trf_7662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7662(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7662(t0,t1);}

C_noret_decl(trf_7552)
static void C_fcall trf_7552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7552(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7552(t0,t1,t2);}

C_noret_decl(trf_7496)
static void C_fcall trf_7496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7496(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7496(t0,t1,t2);}

C_noret_decl(trf_6527)
static void C_fcall trf_6527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6527(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6527(t0,t1,t2);}

C_noret_decl(trf_7402)
static void C_fcall trf_7402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7402(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7402(t0,t1,t2);}

C_noret_decl(trf_7140)
static void C_fcall trf_7140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7140(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7140(t0,t1);}

C_noret_decl(trf_7323)
static void C_fcall trf_7323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7323(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7323(t0,t1);}

C_noret_decl(trf_7286)
static void C_fcall trf_7286(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7286(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7286(t0,t1,t2);}

C_noret_decl(trf_7223)
static void C_fcall trf_7223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7223(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7223(t0,t1,t2);}

C_noret_decl(trf_7166)
static void C_fcall trf_7166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7166(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7166(t0,t1,t2);}

C_noret_decl(trf_7033)
static void C_fcall trf_7033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7033(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7033(t0,t1,t2);}

C_noret_decl(trf_6943)
static void C_fcall trf_6943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6943(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6943(t0,t1,t2);}

C_noret_decl(trf_6845)
static void C_fcall trf_6845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6845(t0,t1);}

C_noret_decl(trf_6855)
static void C_fcall trf_6855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6855(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6855(t0,t1,t2);}

C_noret_decl(trf_6741)
static void C_fcall trf_6741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6741(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6741(t0,t1,t2);}

C_noret_decl(trf_6768)
static void C_fcall trf_6768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6768(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6768(t0,t1,t2);}

C_noret_decl(trf_6660)
static void C_fcall trf_6660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6660(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6660(t0,t1);}

C_noret_decl(trf_6608)
static void C_fcall trf_6608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6608(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6608(t0,t1,t2);}

C_noret_decl(trf_5933)
static void C_fcall trf_5933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5933(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5933(t0,t1);}

C_noret_decl(trf_6111)
static void C_fcall trf_6111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6111(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6111(t0,t1,t2);}

C_noret_decl(trf_6137)
static void C_fcall trf_6137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6137(t0,t1);}

C_noret_decl(trf_6213)
static void C_fcall trf_6213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6213(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6213(t0,t1);}

C_noret_decl(trf_5992)
static void C_fcall trf_5992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5992(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5992(t0,t1);}

C_noret_decl(trf_6026)
static void C_fcall trf_6026(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6026(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6026(t0,t1);}

C_noret_decl(trf_6060)
static void C_fcall trf_6060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6060(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6060(t0,t1);}

C_noret_decl(trf_5894)
static void C_fcall trf_5894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5894(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5894(t0,t1,t2);}

C_noret_decl(trf_5848)
static void C_fcall trf_5848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5848(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5848(t0,t1,t2);}

C_noret_decl(trf_5811)
static void C_fcall trf_5811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5811(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5811(t0,t1);}

C_noret_decl(trf_5815)
static void C_fcall trf_5815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5815(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5815(t0,t1,t2);}

C_noret_decl(trf_5500)
static void C_fcall trf_5500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5500(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5500(t0,t1,t2);}

C_noret_decl(trf_5409)
static void C_fcall trf_5409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5409(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5409(t0,t1,t2);}

C_noret_decl(trf_5354)
static void C_fcall trf_5354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5354(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5354(t0,t1,t2);}

C_noret_decl(trf_4992)
static void C_fcall trf_4992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4992(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4992(t0,t1,t2);}

C_noret_decl(trf_5020)
static void C_fcall trf_5020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5020(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5020(t0,t1);}

C_noret_decl(trf_4884)
static void C_fcall trf_4884(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4884(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4884(t0,t1);}

C_noret_decl(trf_4759)
static void C_fcall trf_4759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4759(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4759(t0,t1,t2,t3);}

C_noret_decl(trf_4706)
static void C_fcall trf_4706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4706(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4706(t0,t1,t2);}

C_noret_decl(trf_4659)
static void C_fcall trf_4659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4659(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4659(t0,t1);}

C_noret_decl(trf_4485)
static void C_fcall trf_4485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4485(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4485(t0,t1,t2);}

C_noret_decl(trf_4507)
static void C_fcall trf_4507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4507(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4507(t0,t1);}

C_noret_decl(trf_4514)
static void C_fcall trf_4514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4514(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4514(t0,t1);}

C_noret_decl(trf_4429)
static void C_fcall trf_4429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4429(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4429(t0,t1,t2,t3);}

C_noret_decl(trf_4285)
static void C_fcall trf_4285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4285(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4285(t0,t1,t2,t3);}

C_noret_decl(trf_4264)
static void C_fcall trf_4264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4264(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4264(t0,t1);}

C_noret_decl(trf_4224)
static void C_fcall trf_4224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4224(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4224(t0,t1,t2);}

C_noret_decl(trf_4177)
static void C_fcall trf_4177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4177(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4177(t0,t1);}

C_noret_decl(trf_4129)
static void C_fcall trf_4129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4129(t0,t1);}

C_noret_decl(trf_4087)
static void C_fcall trf_4087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4087(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4087(t0,t1,t2);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5210)){
C_save(t1);
C_rereclaim2(5210*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,504);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],30,"\010compilercompiler-cleanup-hook");
lf[3]=C_h_intern(&lf[3],26,"\010compilerdebugging-chicken");
lf[4]=C_h_intern(&lf[4],26,"\010compilerdisabled-warnings");
lf[5]=C_h_intern(&lf[5],13,"\010compilerbomb");
lf[6]=C_h_intern(&lf[6],5,"error");
lf[7]=C_h_intern(&lf[7],13,"string-append");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[10]=C_h_intern(&lf[10],18,"\010compilerdebugging");
lf[11]=C_h_intern(&lf[11],19,"\003sysstandard-output");
lf[12]=C_h_intern(&lf[12],12,"flush-output");
lf[13]=C_h_intern(&lf[13],7,"newline");
lf[14]=C_h_intern(&lf[14],19,"\003syswrite-char/port");
lf[15]=C_h_intern(&lf[15],5,"write");
lf[16]=C_h_intern(&lf[16],5,"force");
lf[17]=C_h_intern(&lf[17],7,"display");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[19]=C_h_intern(&lf[19],25,"\010compilercompiler-warning");
lf[20]=C_h_intern(&lf[20],7,"fprintf");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\012\012Warning: ");
lf[22]=C_h_intern(&lf[22],18,"current-error-port");
lf[23]=C_h_intern(&lf[23],20,"\003syswarnings-enabled");
lf[24]=C_h_intern(&lf[24],4,"quit");
lf[25]=C_h_intern(&lf[25],4,"exit");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\010\012Error: ");
lf[27]=C_h_intern(&lf[27],21,"\003syssyntax-error-hook");
lf[28]=C_h_intern(&lf[28],16,"print-call-chain");
lf[29]=C_h_intern(&lf[29],18,"\003syscurrent-thread");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[32]=C_h_intern(&lf[32],12,"\003sysfor-each");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\031Syntax error (~a): ~a~%~%");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\024Syntax error: ~a~%~%");
lf[35]=C_h_intern(&lf[35],12,"syntax-error");
lf[36]=C_h_intern(&lf[36],31,"\010compileremit-syntax-trace-info");
lf[37]=C_h_intern(&lf[37],9,"map-llist");
lf[38]=C_h_intern(&lf[38],24,"\010compilercheck-signature");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[40]=C_h_intern(&lf[40],18,"\010compilerreal-name");
lf[41]=C_h_intern(&lf[41],13,"\010compilerposq");
lf[42]=C_h_intern(&lf[42],18,"\010compilerstringify");
lf[43]=C_h_intern(&lf[43],14,"symbol->string");
lf[44]=C_h_intern(&lf[44],17,"get-output-string");
lf[45]=C_h_intern(&lf[45],18,"open-output-string");
lf[46]=C_h_intern(&lf[46],18,"\010compilersymbolify");
lf[47]=C_h_intern(&lf[47],14,"string->symbol");
lf[48]=C_h_intern(&lf[48],26,"\010compilerbuild-lambda-list");
lf[49]=C_h_intern(&lf[49],29,"\010compilerstring->c-identifier");
lf[50]=C_h_intern(&lf[50],24,"\003sysstring->c-identifier");
lf[51]=C_h_intern(&lf[51],21,"\010compilerc-ify-string");
lf[52]=C_h_intern(&lf[52],16,"\003syslist->string");
lf[53]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[54]=C_h_intern(&lf[54],6,"append");
lf[55]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[56]=C_h_intern(&lf[56],16,"\003sysstring->list");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[60]=C_h_intern(&lf[60],28,"\010compilervalid-c-identifier\077");
lf[61]=C_h_intern(&lf[61],3,"any");
lf[62]=C_h_intern(&lf[62],8,"->string");
lf[63]=C_h_intern(&lf[63],14,"\010compilerwords");
lf[64]=C_h_intern(&lf[64],21,"\010compilerwords->bytes");
lf[65]=C_h_intern(&lf[65],34,"\010compilercheck-and-open-input-file");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[67]=C_h_intern(&lf[67],18,"current-input-port");
lf[68]=C_h_intern(&lf[68],15,"open-input-file");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\031(~a) can not open file ~s");
lf[71]=C_h_intern(&lf[71],12,"file-exists\077");
lf[72]=C_h_intern(&lf[72],33,"\010compilerclose-checked-input-file");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[74]=C_h_intern(&lf[74],16,"close-input-port");
lf[75]=C_h_intern(&lf[75],19,"\010compilerfold-inner");
lf[76]=C_h_intern(&lf[76],7,"reverse");
lf[77]=C_h_intern(&lf[77],28,"\010compilerfollow-without-loop");
lf[78]=C_h_intern(&lf[78],21,"\010compilersort-symbols");
lf[79]=C_h_intern(&lf[79],8,"string<\077");
lf[80]=C_h_intern(&lf[80],4,"sort");
lf[81]=C_h_intern(&lf[81],18,"\010compilerconstant\077");
lf[82]=C_h_intern(&lf[82],5,"quote");
lf[83]=C_h_intern(&lf[83],29,"\010compilercollapsable-literal\077");
lf[84]=C_h_intern(&lf[84],19,"\010compilerimmediate\077");
lf[85]=C_h_intern(&lf[85],20,"\010compilerbig-fixnum\077");
lf[86]=C_h_intern(&lf[86],23,"\010compilerbasic-literal\077");
lf[87]=C_h_intern(&lf[87],5,"every");
lf[88]=C_h_intern(&lf[88],12,"vector->list");
lf[89]=C_h_intern(&lf[89],32,"\010compilercanonicalize-begin-body");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[91]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[92]=C_h_intern(&lf[92],3,"let");
lf[93]=C_h_intern(&lf[93],6,"gensym");
lf[94]=C_h_intern(&lf[94],1,"t");
lf[95]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[96]=C_h_intern(&lf[96],21,"\010compilerstring->expr");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot parse expression: ~s [~a]~%");
lf[98]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[99]=C_h_intern(&lf[99],5,"begin");
lf[100]=C_h_intern(&lf[100],10,"\003sysappend");
lf[101]=C_h_intern(&lf[101],4,"read");
lf[102]=C_h_intern(&lf[102],6,"unfold");
lf[103]=C_h_intern(&lf[103],11,"eof-object\077");
lf[104]=C_h_intern(&lf[104],6,"values");
lf[105]=C_h_intern(&lf[105],22,"with-input-from-string");
lf[106]=C_h_intern(&lf[106],22,"with-exception-handler");
lf[107]=C_h_intern(&lf[107],30,"call-with-current-continuation");
lf[108]=C_h_intern(&lf[108],30,"\010compilerdecompose-lambda-list");
lf[109]=C_h_intern(&lf[109],25,"\003sysdecompose-lambda-list");
lf[110]=C_h_intern(&lf[110],21,"\010compilerllist-length");
lf[111]=C_h_intern(&lf[111],30,"\010compilerexpand-profile-lambda");
lf[112]=C_h_intern(&lf[112],29,"\010compilerprofile-lambda-index");
lf[113]=C_h_intern(&lf[113],28,"\010compilerprofile-lambda-list");
lf[114]=C_h_intern(&lf[114],33,"\010compilerprofile-info-vector-name");
lf[115]=C_h_intern(&lf[115],17,"\003sysprofile-entry");
lf[116]=C_h_intern(&lf[116],6,"lambda");
lf[117]=C_h_intern(&lf[117],5,"apply");
lf[118]=C_h_intern(&lf[118],16,"\003sysprofile-exit");
lf[119]=C_h_intern(&lf[119],16,"\003sysdynamic-wind");
lf[120]=C_h_intern(&lf[120],10,"alist-cons");
lf[121]=C_h_intern(&lf[121],37,"\010compilerinitialize-analysis-database");
lf[122]=C_h_intern(&lf[122],8,"internal");
lf[123]=C_h_intern(&lf[123],8,"\003sysput!");
lf[124]=C_h_intern(&lf[124],18,"\010compilerintrinsic");
lf[125]=C_h_intern(&lf[125],9,"\003syserror");
lf[126]=C_h_intern(&lf[126],26,"\010compilerinternal-bindings");
lf[127]=C_h_intern(&lf[127],26,"\010compilerfoldable-bindings");
lf[128]=C_h_intern(&lf[128],17,"\010compilerfoldable");
lf[129]=C_h_intern(&lf[129],8,"extended");
lf[130]=C_h_intern(&lf[130],17,"extended-bindings");
lf[131]=C_h_intern(&lf[131],8,"standard");
lf[132]=C_h_intern(&lf[132],17,"standard-bindings");
lf[133]=C_h_intern(&lf[133],12,"\010compilerget");
lf[134]=C_h_intern(&lf[134],18,"\003syshash-table-ref");
lf[135]=C_h_intern(&lf[135],16,"\010compilerget-all");
lf[136]=C_h_intern(&lf[136],10,"filter-map");
lf[137]=C_h_intern(&lf[137],13,"\010compilerput!");
lf[138]=C_h_intern(&lf[138],19,"\003syshash-table-set!");
lf[139]=C_h_intern(&lf[139],17,"\010compilercollect!");
lf[140]=C_h_intern(&lf[140],15,"\010compilercount!");
lf[141]=C_h_intern(&lf[141],17,"\010compilerget-list");
lf[142]=C_h_intern(&lf[142],17,"\010compilerget-line");
lf[143]=C_h_intern(&lf[143],24,"\003sysline-number-database");
lf[144]=C_h_intern(&lf[144],19,"\010compilerget-line-2");
lf[145]=C_h_intern(&lf[145],30,"\010compilerfind-lambda-container");
lf[146]=C_h_intern(&lf[146],12,"contained-in");
lf[147]=C_h_intern(&lf[147],37,"\010compilerdisplay-line-number-database");
lf[148]=C_h_intern(&lf[148],3,"cdr");
lf[149]=C_h_intern(&lf[149],23,"\003syshash-table-for-each");
lf[150]=C_h_intern(&lf[150],34,"\010compilerdisplay-analysis-database");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\005\011css=");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\006\011refs=");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\005\011val=");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\006\011lval=");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\006\011pval=");
lf[156]=C_h_intern(&lf[156],7,"unknown");
lf[157]=C_h_intern(&lf[157],8,"captured");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376"
"\001\000\000\003col\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\015inline-target\376\001\000\000\003ilt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020inline-transient\376\001\000\000\003itr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"undefined\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003uud\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\012boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[159]=C_h_intern(&lf[159],4,"caar");
lf[160]=C_h_intern(&lf[160],5,"value");
lf[161]=C_h_intern(&lf[161],4,"cdar");
lf[162]=C_h_intern(&lf[162],11,"local-value");
lf[163]=C_h_intern(&lf[163],15,"potential-value");
lf[164]=C_h_intern(&lf[164],10,"replacable");
lf[165]=C_h_intern(&lf[165],10,"references");
lf[166]=C_h_intern(&lf[166],10,"call-sites");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[168]=C_h_intern(&lf[168],4,"home");
lf[169]=C_h_intern(&lf[169],8,"contains");
lf[170]=C_h_intern(&lf[170],8,"use-expr");
lf[171]=C_h_intern(&lf[171],12,"closure-size");
lf[172]=C_h_intern(&lf[172],14,"rest-parameter");
lf[173]=C_h_intern(&lf[173],18,"captured-variables");
lf[174]=C_h_intern(&lf[174],13,"explicit-rest");
lf[175]=C_h_intern(&lf[175],8,"assigned");
lf[176]=C_h_intern(&lf[176],5,"boxed");
lf[177]=C_h_intern(&lf[177],6,"global");
lf[178]=C_h_intern(&lf[178],12,"contractable");
lf[179]=C_h_intern(&lf[179],16,"standard-binding");
lf[180]=C_h_intern(&lf[180],16,"assigned-locally");
lf[181]=C_h_intern(&lf[181],11,"collapsable");
lf[182]=C_h_intern(&lf[182],9,"removable");
lf[183]=C_h_intern(&lf[183],9,"undefined");
lf[184]=C_h_intern(&lf[184],9,"replacing");
lf[185]=C_h_intern(&lf[185],6,"unused");
lf[186]=C_h_intern(&lf[186],6,"simple");
lf[187]=C_h_intern(&lf[187],9,"inlinable");
lf[188]=C_h_intern(&lf[188],13,"inline-export");
lf[189]=C_h_intern(&lf[189],21,"has-unused-parameters");
lf[190]=C_h_intern(&lf[190],16,"extended-binding");
lf[191]=C_h_intern(&lf[191],12,"customizable");
lf[192]=C_h_intern(&lf[192],8,"constant");
lf[193]=C_h_intern(&lf[193],10,"boxed-rest");
lf[194]=C_h_intern(&lf[194],11,"hidden-refs");
lf[195]=C_h_intern(&lf[195],34,"\010compilerdefault-standard-bindings");
lf[196]=C_h_intern(&lf[196],34,"\010compilerdefault-extended-bindings");
lf[197]=C_h_intern(&lf[197],5,"node\077");
lf[198]=C_h_intern(&lf[198],4,"node");
lf[199]=C_h_intern(&lf[199],15,"node-class-set!");
lf[200]=C_h_intern(&lf[200],14,"\003sysblock-set!");
lf[201]=C_h_intern(&lf[201],10,"node-class");
lf[202]=C_h_intern(&lf[202],20,"node-parameters-set!");
lf[203]=C_h_intern(&lf[203],15,"node-parameters");
lf[204]=C_h_intern(&lf[204],24,"node-subexpressions-set!");
lf[205]=C_h_intern(&lf[205],19,"node-subexpressions");
lf[206]=C_h_intern(&lf[206],9,"make-node");
lf[207]=C_h_intern(&lf[207],16,"\010compilervarnode");
lf[208]=C_h_intern(&lf[208],13,"\004corevariable");
lf[209]=C_h_intern(&lf[209],14,"\010compilerqnode");
lf[210]=C_h_intern(&lf[210],25,"\010compilerbuild-node-graph");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[212]=C_h_intern(&lf[212],15,"\004coreglobal-ref");
lf[213]=C_h_intern(&lf[213],2,"if");
lf[214]=C_h_intern(&lf[214],14,"\004coreundefined");
lf[215]=C_h_intern(&lf[215],8,"truncate");
lf[216]=C_h_intern(&lf[216],4,"type");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000;literal \047~s\047 is out of range - will be truncated to integer");
lf[218]=C_h_intern(&lf[218],6,"fixnum");
lf[219]=C_h_intern(&lf[219],11,"number-type");
lf[220]=C_h_intern(&lf[220],6,"unzip1");
lf[221]=C_h_intern(&lf[221],11,"\004corelambda");
lf[222]=C_h_intern(&lf[222],14,"\004coreprimitive");
lf[223]=C_h_intern(&lf[223],11,"\004coreinline");
lf[224]=C_h_intern(&lf[224],13,"\004corecallunit");
lf[225]=C_h_intern(&lf[225],9,"\004coreproc");
lf[226]=C_h_intern(&lf[226],4,"set!");
lf[227]=C_h_intern(&lf[227],9,"\004coreset!");
lf[228]=C_h_intern(&lf[228],29,"\004coreforeign-callback-wrapper");
lf[229]=C_h_intern(&lf[229],5,"sixth");
lf[230]=C_h_intern(&lf[230],5,"fifth");
lf[231]=C_h_intern(&lf[231],20,"\004coreinline_allocate");
lf[232]=C_h_intern(&lf[232],8,"\004coreapp");
lf[233]=C_h_intern(&lf[233],9,"\004corecall");
lf[234]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[235]=C_h_intern(&lf[235],28,"\003syssymbol->qualified-string");
lf[236]=C_h_intern(&lf[236],7,"\003sysget");
lf[237]=C_h_intern(&lf[237],34,"\010compileralways-bound-to-procedure");
lf[238]=C_h_intern(&lf[238],15,"\004coreinline_ref");
lf[239]=C_h_intern(&lf[239],18,"\004coreinline_update");
lf[240]=C_h_intern(&lf[240],19,"\004coreinline_loc_ref");
lf[241]=C_h_intern(&lf[241],22,"\004coreinline_loc_update");
lf[242]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[243]=C_h_intern(&lf[243],1,"o");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[245]=C_h_intern(&lf[245],30,"\010compilerbuild-expression-tree");
lf[246]=C_h_intern(&lf[246],12,"\004coreclosure");
lf[247]=C_h_intern(&lf[247],4,"last");
lf[248]=C_h_intern(&lf[248],4,"list");
lf[249]=C_h_intern(&lf[249],7,"butlast");
lf[250]=C_h_intern(&lf[250],5,"cons*");
lf[251]=C_h_intern(&lf[251],9,"\004corebind");
lf[252]=C_h_intern(&lf[252],10,"\004coreunbox");
lf[253]=C_h_intern(&lf[253],16,"\004corelet_unboxed");
lf[254]=C_h_intern(&lf[254],8,"\004coreref");
lf[255]=C_h_intern(&lf[255],11,"\004coreupdate");
lf[256]=C_h_intern(&lf[256],13,"\004coreupdate_i");
lf[257]=C_h_intern(&lf[257],8,"\004corebox");
lf[258]=C_h_intern(&lf[258],9,"\004corecond");
lf[259]=C_h_intern(&lf[259],21,"\010compilerfold-boolean");
lf[260]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[261]=C_h_intern(&lf[261],31,"\010compilerinline-lambda-bindings");
lf[262]=C_h_intern(&lf[262],8,"split-at");
lf[263]=C_h_intern(&lf[263],10,"fold-right");
lf[264]=C_h_intern(&lf[264],4,"take");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[266]=C_h_intern(&lf[266],34,"\010compilercopy-node-tree-and-rename");
lf[267]=C_h_intern(&lf[267],9,"alist-ref");
lf[268]=C_h_intern(&lf[268],3,"eq\077");
lf[269]=C_h_intern(&lf[269],7,"\003sysmap");
lf[270]=C_h_intern(&lf[270],1,"f");
lf[271]=C_h_intern(&lf[271],4,"cons");
lf[272]=C_h_intern(&lf[272],16,"inline-transient");
lf[273]=C_h_intern(&lf[273],18,"\010compilertree-copy");
lf[274]=C_h_intern(&lf[274],19,"\010compilercopy-node!");
lf[275]=C_h_intern(&lf[275],20,"\010compilernode->sexpr");
lf[276]=C_h_intern(&lf[276],20,"\010compilersexpr->node");
lf[277]=C_h_intern(&lf[277],32,"\010compileremit-global-inline-file");
lf[278]=C_h_intern(&lf[278],5,"print");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[280]=C_h_intern(&lf[280],1,"i");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\0001the following procedures can be globally inlined:");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\015; END OF FILE");
lf[283]=C_h_intern(&lf[283],2,"pp");
lf[284]=C_h_intern(&lf[284],3,"yes");
lf[285]=C_h_intern(&lf[285],2,"no");
lf[286]=C_h_intern(&lf[286],24,"\010compilerinline-max-size");
lf[287]=C_h_intern(&lf[287],15,"\010compilerinline");
lf[288]=C_h_intern(&lf[288],22,"\010compilerinline-global");
lf[289]=C_h_intern(&lf[289],26,"\010compilervariable-visible\077");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\027; GENERATED BY CHICKEN ");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\006 FROM ");
lf[292]=C_h_intern(&lf[292],24,"\010compilersource-filename");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[294]=C_h_intern(&lf[294],15,"chicken-version");
lf[295]=C_h_intern(&lf[295],19,"with-output-to-file");
lf[296]=C_h_intern(&lf[296],25,"\010compilerload-inline-file");
lf[297]=C_h_intern(&lf[297],20,"with-input-from-file");
lf[298]=C_h_intern(&lf[298],19,"\010compilermatch-node");
lf[299]=C_h_intern(&lf[299],1,"a");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[301]=C_h_intern(&lf[301],37,"\010compilerexpression-has-side-effects\077");
lf[302]=C_h_intern(&lf[302],24,"foreign-callback-stub-id");
lf[303]=C_h_intern(&lf[303],4,"find");
lf[304]=C_h_intern(&lf[304],22,"foreign-callback-stubs");
lf[305]=C_h_intern(&lf[305],28,"\010compilersimple-lambda-node\077");
lf[306]=C_h_intern(&lf[306],31,"\010compilerdump-undefined-globals");
lf[307]=C_h_intern(&lf[307],8,"keyword\077");
lf[308]=C_h_intern(&lf[308],29,"\010compilerdump-defined-globals");
lf[309]=C_h_intern(&lf[309],25,"\010compilerdump-global-refs");
lf[310]=C_h_intern(&lf[310],28,"\003systoplevel-definition-hook");
lf[311]=C_h_intern(&lf[311],22,"\010compilerhide-variable");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[313]=C_h_intern(&lf[313],36,"\010compilercompute-database-statistics");
lf[314]=C_h_intern(&lf[314],29,"\010compilercurrent-program-size");
lf[315]=C_h_intern(&lf[315],30,"\010compileroriginal-program-size");
lf[316]=C_h_intern(&lf[316],33,"\010compilerprint-program-statistics");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\027;   database entries: \011");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\027;   known call sites: \011");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\027;   global variables: \011");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\027;   known procedures: \011");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\042;   variables with known values: \011");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\032 \011original program size: \011");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\023;   program size: \011");
lf[324]=C_h_intern(&lf[324],1,"s");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[326]=C_h_intern(&lf[326],35,"\010compilerpprint-expressions-to-file");
lf[327]=C_h_intern(&lf[327],17,"close-output-port");
lf[328]=C_h_intern(&lf[328],12,"pretty-print");
lf[329]=C_h_intern(&lf[329],19,"with-output-to-port");
lf[330]=C_h_intern(&lf[330],16,"open-output-file");
lf[331]=C_h_intern(&lf[331],19,"current-output-port");
lf[332]=C_h_intern(&lf[332],27,"\010compilerforeign-type-check");
lf[333]=C_h_intern(&lf[333],4,"char");
lf[334]=C_h_intern(&lf[334],13,"unsigned-char");
lf[335]=C_h_intern(&lf[335],6,"unsafe");
lf[336]=C_h_intern(&lf[336],25,"\003sysforeign-char-argument");
lf[337]=C_h_intern(&lf[337],3,"int");
lf[338]=C_h_intern(&lf[338],27,"\003sysforeign-fixnum-argument");
lf[339]=C_h_intern(&lf[339],5,"float");
lf[340]=C_h_intern(&lf[340],27,"\003sysforeign-flonum-argument");
lf[341]=C_h_intern(&lf[341],7,"pointer");
lf[342]=C_h_intern(&lf[342],26,"\003sysforeign-block-argument");
lf[343]=C_h_intern(&lf[343],15,"nonnull-pointer");
lf[344]=C_h_intern(&lf[344],8,"u8vector");
lf[345]=C_h_intern(&lf[345],34,"\003sysforeign-number-vector-argument");
lf[346]=C_h_intern(&lf[346],16,"nonnull-u8vector");
lf[347]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[348]=C_h_intern(&lf[348],7,"integer");
lf[349]=C_h_intern(&lf[349],28,"\003sysforeign-integer-argument");
lf[350]=C_h_intern(&lf[350],16,"unsigned-integer");
lf[351]=C_h_intern(&lf[351],37,"\003sysforeign-unsigned-integer-argument");
lf[352]=C_h_intern(&lf[352],9,"c-pointer");
lf[353]=C_h_intern(&lf[353],28,"\003sysforeign-pointer-argument");
lf[354]=C_h_intern(&lf[354],17,"nonnull-c-pointer");
lf[355]=C_h_intern(&lf[355],8,"c-string");
lf[356]=C_h_intern(&lf[356],17,"\003sysmake-c-string");
lf[357]=C_h_intern(&lf[357],27,"\003sysforeign-string-argument");
lf[358]=C_h_intern(&lf[358],16,"nonnull-c-string");
lf[359]=C_h_intern(&lf[359],6,"symbol");
lf[360]=C_h_intern(&lf[360],18,"\003syssymbol->string");
lf[361]=C_h_intern(&lf[361],3,"ref");
lf[362]=C_h_intern(&lf[362],8,"instance");
lf[363]=C_h_intern(&lf[363],12,"instance-ref");
lf[364]=C_h_intern(&lf[364],4,"this");
lf[365]=C_h_intern(&lf[365],8,"slot-ref");
lf[366]=C_h_intern(&lf[366],16,"nonnull-instance");
lf[367]=C_h_intern(&lf[367],5,"const");
lf[368]=C_h_intern(&lf[368],4,"enum");
lf[369]=C_h_intern(&lf[369],8,"function");
lf[370]=C_h_intern(&lf[370],27,"\010compilerforeign-type-table");
lf[371]=C_h_intern(&lf[371],17,"nonnull-c-string*");
lf[372]=C_h_intern(&lf[372],26,"nonnull-unsigned-c-string*");
lf[373]=C_h_intern(&lf[373],9,"c-string*");
lf[374]=C_h_intern(&lf[374],17,"unsigned-c-string");
lf[375]=C_h_intern(&lf[375],18,"unsigned-c-string*");
lf[376]=C_h_intern(&lf[376],13,"c-string-list");
lf[377]=C_h_intern(&lf[377],14,"c-string-list*");
lf[378]=C_h_intern(&lf[378],18,"unsigned-integer32");
lf[379]=C_h_intern(&lf[379],13,"unsigned-long");
lf[380]=C_h_intern(&lf[380],4,"long");
lf[381]=C_h_intern(&lf[381],9,"integer32");
lf[382]=C_h_intern(&lf[382],17,"nonnull-u16vector");
lf[383]=C_h_intern(&lf[383],16,"nonnull-s8vector");
lf[384]=C_h_intern(&lf[384],17,"nonnull-s16vector");
lf[385]=C_h_intern(&lf[385],17,"nonnull-u32vector");
lf[386]=C_h_intern(&lf[386],17,"nonnull-s32vector");
lf[387]=C_h_intern(&lf[387],17,"nonnull-f32vector");
lf[388]=C_h_intern(&lf[388],17,"nonnull-f64vector");
lf[389]=C_h_intern(&lf[389],9,"u16vector");
lf[390]=C_h_intern(&lf[390],8,"s8vector");
lf[391]=C_h_intern(&lf[391],9,"s16vector");
lf[392]=C_h_intern(&lf[392],9,"u32vector");
lf[393]=C_h_intern(&lf[393],9,"s32vector");
lf[394]=C_h_intern(&lf[394],9,"f32vector");
lf[395]=C_h_intern(&lf[395],9,"f64vector");
lf[396]=C_h_intern(&lf[396],22,"nonnull-scheme-pointer");
lf[397]=C_h_intern(&lf[397],12,"nonnull-blob");
lf[398]=C_h_intern(&lf[398],19,"nonnull-byte-vector");
lf[399]=C_h_intern(&lf[399],11,"byte-vector");
lf[400]=C_h_intern(&lf[400],4,"blob");
lf[401]=C_h_intern(&lf[401],14,"scheme-pointer");
lf[402]=C_h_intern(&lf[402],6,"double");
lf[403]=C_h_intern(&lf[403],6,"number");
lf[404]=C_h_intern(&lf[404],12,"unsigned-int");
lf[405]=C_h_intern(&lf[405],5,"short");
lf[406]=C_h_intern(&lf[406],14,"unsigned-short");
lf[407]=C_h_intern(&lf[407],4,"byte");
lf[408]=C_h_intern(&lf[408],13,"unsigned-byte");
lf[409]=C_h_intern(&lf[409],5,"int32");
lf[410]=C_h_intern(&lf[410],14,"unsigned-int32");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[412]=C_h_intern(&lf[412],36,"\010compilerforeign-type-convert-result");
lf[413]=C_h_intern(&lf[413],38,"\010compilerforeign-type-convert-argument");
lf[414]=C_h_intern(&lf[414],27,"\010compilerfinal-foreign-type");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[416]=C_h_intern(&lf[416],37,"\010compilerestimate-foreign-result-size");
lf[417]=C_h_intern(&lf[417],9,"integer64");
lf[418]=C_h_intern(&lf[418],4,"bool");
lf[419]=C_h_intern(&lf[419],4,"void");
lf[420]=C_h_intern(&lf[420],13,"scheme-object");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[422]=C_h_intern(&lf[422],46,"\010compilerestimate-foreign-result-location-size");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\0005cannot compute size of location for foreign type `~S\047");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[425]=C_h_intern(&lf[425],30,"\010compilerfinish-foreign-result");
lf[426]=C_h_intern(&lf[426],17,"\003syspeek-c-string");
lf[427]=C_h_intern(&lf[427],25,"\003syspeek-nonnull-c-string");
lf[428]=C_h_intern(&lf[428],26,"\003syspeek-and-free-c-string");
lf[429]=C_h_intern(&lf[429],34,"\003syspeek-and-free-nonnull-c-string");
lf[430]=C_h_intern(&lf[430],17,"\003sysintern-symbol");
lf[431]=C_h_intern(&lf[431],22,"\003syspeek-c-string-list");
lf[432]=C_h_intern(&lf[432],31,"\003syspeek-and-free-c-string-list");
lf[433]=C_h_intern(&lf[433],17,"\003sysnull-pointer\077");
lf[434]=C_h_intern(&lf[434],3,"not");
lf[435]=C_h_intern(&lf[435],4,"make");
lf[436]=C_h_intern(&lf[436],3,"and");
lf[437]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\014instance-ref\376\377\016");
lf[438]=C_h_intern(&lf[438],28,"\010compilerscan-used-variables");
lf[439]=C_h_intern(&lf[439],28,"\010compilerscan-free-variables");
lf[440]=C_h_intern(&lf[440],11,"lset-adjoin");
lf[441]=C_h_intern(&lf[441],23,"\010compilerchop-separator");
lf[442]=C_h_intern(&lf[442],9,"substring");
lf[443]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[444]=C_h_intern(&lf[444],23,"\010compilerchop-extension");
lf[445]=C_h_intern(&lf[445],22,"\010compilerprint-version");
lf[446]=C_h_intern(&lf[446],6,"print*");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\077(c)2008-2010 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[448]=C_h_intern(&lf[448],20,"\010compilerprint-usage");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\030\006Usage: chicken FILENAME OPTION ...\012\012  `chicken\047 is the CHICKEN compiler.\012  "
"\012  FILENAME should be a complete source file name with extension, or \042-\042 for\012  s"
"tandard input. OPTION may be one of the following:\012\012  General options:\012\012    -hel"
"p                        display this text and exit\012    -version                "
"     display compiler version and exit\012    -release                     print re"
"lease number and exit\012    -verbose                     display information on co"
"mpilation progress\012\012  File and pathname options:\012\012    -output-file FILENAME     "
"   specifies output-filename, default is \047out.c\047\012    -include-path PATHNAME     "
"  specifies alternative path for included files\012    -to-stdout                  "
" write compiled file to stdout instead of file\012\012  Language options:\012\012    -featur"
"e SYMBOL              register feature identifier\012\012  Syntax related options:\012\012  "
"  -case-insensitive            don\047t preserve case of read symbols\012    -keyword-"
"style STYLE         allow alternative keyword syntax\012                           "
"       (prefix, suffix or none)\012    -no-parentheses-synonyms     disables list d"
"elimiter synonyms\012    -no-symbol-escape            disables support for escaped "
"symbols\012    -r5rs-syntax                 disables the Chicken extensions to\012    "
"                              R5RS syntax\012    -compile-syntax              macro"
"s are made available at run-time\012    -emit-import-library MODULE  write compile-"
"time module information into\012                                  separate file\012   "
" -emit-all-import-libraries   emit import-libraries for all defined modules\012    "
"-no-compiler-syntax          disable expansion of compiler-macros\012\012  Translation"
" options:\012\012    -explicit-use                do not use units \047library\047 and \047eval"
"\047 by\012                                  default\012    -check-syntax                "
"stop compilation after macro-expansion\012    -analyze-only                stop com"
"pilation after first analysis pass\012\012  Debugging options:\012\012    -no-warnings      "
"           disable warnings\012    -disable-warning CLASS       disable specific cl"
"ass of warnings\012    -debug-level NUMBER          set level of available debuggin"
"g information\012    -no-trace                    disable tracing information\012    -"
"profile                     executable emits profiling information \012    -profile"
"-name FILENAME       name of the generated profile information file\012    -accumul"
"ate-profile          executable emits profiling information in\012                 "
"                 append mode\012    -no-lambda-info              omit additional pr"
"ocedure-information\012    -scrutinize                  perform local flow analysis"
"\012    -types FILENAME              load additional type database\012\012  Optimization "
"options:\012\012    -optimize-level NUMBER       enable certain sets of optimization o"
"ptions\012    -optimize-leaf-routines      enable leaf routine optimization\012    -la"
"mbda-lift                 enable lambda-lifting\012    -no-usual-integrations      "
" standard procedures may be redefined\012    -unsafe                      disable a"
"ll safety checks\012    -local                       assume globals are only modifi"
"ed in current\012                                  file\012    -block                 "
"      enable block-compilation\012    -disable-interrupts          disable interrup"
"ts in compiled code\012    -fixnum-arithmetic           assume all numbers are fixn"
"ums\012    -benchmark-mode              equivalent to \047block -optimize-level 4\012    "
"                              -debug-level 0 -fixnum-arithmetic -lambda-lift\012   "
"                               -inline -disable-interrupts\047\012    -disable-stack-o"
"verflow-checks  disables detection of stack-overflows\012    -inline               "
"       enable inlining\012    -inline-limit                set inlining threshold\012 "
"   -inline-global               enable cross-module inlining\012    -unboxing      "
"              use unboxed temporaries if possible\012    -emit-inline-file FILENAME"
"   generate file with globally inlinable\012                                  proce"
"dures (implies -inline -local)\012    -consult-inline-file FILENAME  explicitly loa"
"d inline file\012    -no-argc-checks              disable argument count checks\012   "
" -no-bound-checks             disable bound variable checks\012    -no-procedure-ch"
"ecks         disable procedure call checks\012    -no-procedure-checks-for-usual-bi"
"ndings\012                                 disable procedure call checks only for u"
"sual\012                                  bindings\012\012  Configuration options:\012\012    -"
"unit NAME                   compile file as a library unit\012    -uses NAME       "
"            declare library unit as used.\012    -heap-size NUMBER            speci"
"fies heap-size of compiled executable\012    -heap-initial-size NUMBER    specifies"
" heap-size at startup time\012    -heap-growth PERCENTAGE      specifies growth-rat"
"e of expanding heap\012    -heap-shrinkage PERCENTAGE   specifies shrink-rate of co"
"ntracting heap\012    -nursery NUMBER  -stack-size NUMBER\012                         "
"        specifies nursery size of compiled executable\012    -extend FILENAME      "
"       load file before compilation commences\012    -prelude EXPRESSION          a"
"dd expression to front of source file\012    -postlude EXPRESSION         add expre"
"ssion to end of source file\012    -prologue FILENAME           include file before"
" main source file\012    -epilogue FILENAME           include file after main sourc"
"e file\012    -dynamic                     compile as dynamically loadable code\012   "
" -require-extension NAME      require and import extension NAME\012    -static-exte"
"nsion NAME       import extension NAME but link statically\012                     "
"             (if available)\012\012  Obscure options:\012\012    -debug MODES               "
"  display debugging output for the given modes\012    -raw                         "
"do not generate implicit init- and exit code                           \012    -emi"
"t-external-prototypes-first\012                                 emit prototypes for"
" callbacks before foreign\012                                  declarations\012    -ig"
"nore-repository           do not refer to repository for extensions\012    -setup-m"
"ode                  prefer the current directory when locating extensions\012");
lf[450]=C_h_intern(&lf[450],36,"\010compilermake-block-variable-literal");
lf[451]=C_h_intern(&lf[451],22,"block-variable-literal");
lf[452]=C_h_intern(&lf[452],32,"\010compilerblock-variable-literal\077");
lf[453]=C_h_intern(&lf[453],36,"\010compilerblock-variable-literal-name");
lf[454]=C_h_intern(&lf[454],25,"\010compilermake-random-name");
lf[455]=C_h_intern(&lf[455],6,"random");
lf[456]=C_h_intern(&lf[456],15,"current-seconds");
lf[457]=C_h_intern(&lf[457],23,"\010compilerset-real-name!");
lf[458]=C_h_intern(&lf[458],24,"\010compilerreal-name-table");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\004 in ");
lf[460]=C_h_intern(&lf[460],19,"\010compilerreal-name2");
lf[461]=C_h_intern(&lf[461],32,"\010compilerdisplay-real-name-table");
lf[462]=C_h_intern(&lf[462],28,"\010compilersource-info->string");
lf[463]=C_h_intern(&lf[463],4,"conc");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[466]=C_h_intern(&lf[466],11,"make-string");
lf[467]=C_h_intern(&lf[467],3,"max");
lf[468]=C_h_intern(&lf[468],26,"\010compilersource-info->line");
lf[469]=C_h_intern(&lf[469],12,"string-null\077");
lf[470]=C_h_intern(&lf[470],19,"\010compilerdump-nodes");
lf[471]=C_h_intern(&lf[471],23,"\010compilerread-info-hook");
lf[472]=C_h_intern(&lf[472],27,"\003syscurrent-source-filename");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[474]=C_h_intern(&lf[474],9,"list-info");
lf[475]=C_h_intern(&lf[475],25,"\010compilerread/source-info");
lf[476]=C_h_intern(&lf[476],8,"\003sysread");
lf[477]=C_h_intern(&lf[477],18,"\003sysuser-read-hook");
lf[478]=C_h_intern(&lf[478],15,"foreign-declare");
lf[479]=C_h_intern(&lf[479],7,"declare");
lf[480]=C_h_intern(&lf[480],34,"\010compilerscan-sharp-greater-string");
lf[481]=C_h_intern(&lf[481],18,"\003sysread-char/port");
lf[482]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[483]=C_h_intern(&lf[483],6,"hidden");
lf[484]=C_h_intern(&lf[484],19,"\010compilervisibility");
lf[485]=C_h_intern(&lf[485],24,"\010compilerexport-variable");
lf[486]=C_h_intern(&lf[486],8,"exported");
lf[487]=C_h_intern(&lf[487],26,"\010compilerblock-compilation");
lf[488]=C_h_intern(&lf[488],22,"\010compilermark-variable");
lf[489]=C_h_intern(&lf[489],22,"\010compilervariable-mark");
lf[490]=C_h_intern(&lf[490],19,"\010compilerintrinsic\077");
lf[491]=C_h_intern(&lf[491],9,"foldable\077");
lf[492]=C_h_intern(&lf[492],33,"\010compilerload-identifier-database");
lf[493]=C_h_intern(&lf[493],7,"\004coredb");
lf[494]=C_h_intern(&lf[494],9,"read-file");
lf[495]=C_h_intern(&lf[495],21,"\010compilerverbose-mode");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000\034loading identifier database ");
lf[498]=C_h_intern(&lf[498],13,"make-pathname");
lf[499]=C_h_intern(&lf[499],15,"repository-path");
lf[500]=C_h_intern(&lf[500],27,"condition-property-accessor");
lf[501]=C_h_intern(&lf[501],3,"exn");
lf[502]=C_h_intern(&lf[502],7,"message");
lf[503]=C_h_intern(&lf[503],19,"condition-predicate");
C_register_lf2(lf,504,create_ptable());
t2=C_mutate(&lf[0] /* (set! c521 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4018,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k4016 */
static void C_ccall f_4018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4021,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k4019 in k4016 */
static void C_ccall f_4021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4021,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! ##compiler#compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4025,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[3] /* debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[4] /* disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[5]+1 /* (set! ##compiler#bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4030,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! ##compiler#debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4057,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[19]+1 /* (set! ##compiler#compiler-warning ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4122,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[24]+1 /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4151,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[27]+1 /* (set! ##sys#syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4170,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[35]+1 /* (set! syntax-error ...) */,*((C_word*)lf[27]+1));
t11=C_mutate((C_word*)lf[36]+1 /* (set! ##compiler#emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4215,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[37]+1 /* (set! map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4218,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[38]+1 /* (set! ##compiler#check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4261,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[41]+1 /* (set! ##compiler#posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4329,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[42]+1 /* (set! ##compiler#stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4365,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[46]+1 /* (set! ##compiler#symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4392,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[48]+1 /* (set! ##compiler#build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4423,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[49]+1 /* (set! ##compiler#string->c-identifier ...) */,C_retrieve(lf[50]));
t19=C_mutate((C_word*)lf[51]+1 /* (set! ##compiler#c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4467,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[60]+1 /* (set! ##compiler#valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4561,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[63]+1 /* (set! ##compiler#words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4617,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[64]+1 /* (set! ##compiler#words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4624,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[65]+1 /* (set! ##compiler#check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4631,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[72]+1 /* (set! ##compiler#close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4678,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[75]+1 /* (set! ##compiler#fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4690,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[77]+1 /* (set! ##compiler#follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4753,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[78]+1 /* (set! ##compiler#sort-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4784,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[81]+1 /* (set! ##compiler#constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4804,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[83]+1 /* (set! ##compiler#collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4850,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[84]+1 /* (set! ##compiler#immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4880,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[86]+1 /* (set! ##compiler#basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4926,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[89]+1 /* (set! ##compiler#canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4986,tmp=(C_word)a,a+=2,tmp));
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5083,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 255  condition-predicate */
((C_proc3)C_retrieve_symbol_proc(lf[503]))(3,*((C_word*)lf[503]+1),t33,lf[501]);}

/* k5081 in k4019 in k4016 */
static void C_ccall f_5083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5086,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 256  condition-property-accessor */
((C_proc4)C_retrieve_symbol_proc(lf[500]))(4,*((C_word*)lf[500]+1),t2,lf[501],lf[502]);}

/* k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word ab[177],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5086,2,t0,t1);}
t2=C_mutate((C_word*)lf[96]+1 /* (set! ##compiler#string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5087,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[108]+1 /* (set! ##compiler#decompose-lambda-list ...) */,C_retrieve(lf[109]));
t4=C_mutate((C_word*)lf[110]+1 /* (set! ##compiler#llist-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5194,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[111]+1 /* (set! ##compiler#expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5197,tmp=(C_word)a,a+=2,tmp));
t6=C_SCHEME_TRUE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_mutate((C_word*)lf[121]+1 /* (set! ##compiler#initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5338,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[133]+1 /* (set! ##compiler#get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5591,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[135]+1 /* (set! ##compiler#get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5609,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[137]+1 /* (set! ##compiler#put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5627,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[139]+1 /* (set! ##compiler#collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5673,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[140]+1 /* (set! ##compiler#count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5725,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[141]+1 /* (set! ##compiler#get-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5782,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[142]+1 /* (set! ##compiler#get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5791,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[144]+1 /* (set! ##compiler#get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5801,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[145]+1 /* (set! ##compiler#find-lambda-container ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5842,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[147]+1 /* (set! ##compiler#display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5866,tmp=(C_word)a,a+=2,tmp));
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_mutate((C_word*)lf[150]+1 /* (set! ##compiler#display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5929,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[197]+1 /* (set! node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6428,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[199]+1 /* (set! node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6434,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[201]+1 /* (set! node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6443,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[202]+1 /* (set! node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6452,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[203]+1 /* (set! node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6461,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[204]+1 /* (set! node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6470,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[205]+1 /* (set! node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6479,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[206]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6488,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[207]+1 /* (set! ##compiler#varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6494,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[209]+1 /* (set! ##compiler#qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6509,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[210]+1 /* (set! ##compiler#build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6524,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[245]+1 /* (set! ##compiler#build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7447,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[259]+1 /* (set! ##compiler#fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8128,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[261]+1 /* (set! ##compiler#inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8182,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[266]+1 /* (set! ##compiler#copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8330,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[273]+1 /* (set! ##compiler#tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8729,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[274]+1 /* (set! ##compiler#copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8763,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[275]+1 /* (set! ##compiler#node->sexpr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8802,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[276]+1 /* (set! ##compiler#sexpr->node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8888,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[277]+1 /* (set! ##compiler#emit-global-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8956,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[296]+1 /* (set! ##compiler#load-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9148,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[298]+1 /* (set! ##compiler#match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9217,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[301]+1 /* (set! ##compiler#expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9442,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[305]+1 /* (set! ##compiler#simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9543,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[306]+1 /* (set! ##compiler#dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9665,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[308]+1 /* (set! ##compiler#dump-defined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9706,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[309]+1 /* (set! ##compiler#dump-global-refs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9743,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[310]+1 /* (set! ##sys#toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9792,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[313]+1 /* (set! ##compiler#compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9813,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[316]+1 /* (set! ##compiler#print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9921,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[326]+1 /* (set! ##compiler#pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10002,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[332]+1 /* (set! ##compiler#foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10060,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[412]+1 /* (set! ##compiler#foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11118,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[413]+1 /* (set! ##compiler#foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11149,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[414]+1 /* (set! ##compiler#final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11180,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[416]+1 /* (set! ##compiler#estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11225,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[422]+1 /* (set! ##compiler#estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11555,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[425]+1 /* (set! ##compiler#finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11876,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[438]+1 /* (set! ##compiler#scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12245,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[439]+1 /* (set! ##compiler#scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12384,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[441]+1 /* (set! ##compiler#chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12593,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[444]+1 /* (set! ##compiler#chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12622,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[445]+1 /* (set! ##compiler#print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12664,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[448]+1 /* (set! ##compiler#print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12702,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[450]+1 /* (set! ##compiler#make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12714,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[452]+1 /* (set! ##compiler#block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12720,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[453]+1 /* (set! ##compiler#block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12726,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[454]+1 /* (set! ##compiler#make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12735,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[457]+1 /* (set! ##compiler#set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12794,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[40]+1 /* (set! ##compiler#real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12800,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[460]+1 /* (set! ##compiler#real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12891,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[461]+1 /* (set! ##compiler#display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12903,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[462]+1 /* (set! ##compiler#source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12924,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[468]+1 /* (set! ##compiler#source-info->line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12958,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[469]+1 /* (set! string-null? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12976,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[470]+1 /* (set! ##compiler#dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12979,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[471]+1 /* (set! ##compiler#read-info-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13102,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[475]+1 /* (set! ##compiler#read/source-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13147,tmp=(C_word)a,a+=2,tmp));
t80=C_retrieve(lf[477]);
t81=C_mutate((C_word*)lf[477]+1 /* (set! ##sys#user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13153,a[2]=t80,tmp=(C_word)a,a+=3,tmp));
t82=C_mutate((C_word*)lf[480]+1 /* (set! ##compiler#scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13186,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[85]+1 /* (set! ##compiler#big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13255,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[311]+1 /* (set! ##compiler#hide-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13279,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[485]+1 /* (set! ##compiler#export-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13312,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[289]+1 /* (set! ##compiler#variable-visible? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13345,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[488]+1 /* (set! ##compiler#mark-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13366,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[489]+1 /* (set! ##compiler#variable-mark ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13394,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[490]+1 /* (set! ##compiler#intrinsic? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13400,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[491]+1 /* (set! foldable? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13411,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[492]+1 /* (set! ##compiler#load-identifier-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13422,tmp=(C_word)a,a+=2,tmp));
t92=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t92+1)))(2,t92,C_SCHEME_UNDEFINED);}

/* ##compiler#load-identifier-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13422(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13422,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13426,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1500 repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[499]))(2,*((C_word*)lf[499]+1),t3);}

/* k13424 in ##compiler#load-identifier-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13426,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13432,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13516,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1501 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[498]))(4,*((C_word*)lf[498]+1),t3,t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k13514 in k13424 in ##compiler#load-identifier-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1501 file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[71]))(3,*((C_word*)lf[71]+1),((C_word*)t0)[2],t1);}

/* k13430 in k13424 in ##compiler#load-identifier-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13432,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13438,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[495]))){
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13503,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t4,lf[497],t3);}
else{
t3=t2;
f_13438(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k13501 in k13430 in k13424 in ##compiler#load-identifier-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13506,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k13504 in k13501 in k13430 in k13424 in ##compiler#load-identifier-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,lf[496],((C_word*)t0)[2]);}

/* k13507 in k13504 in k13501 in k13430 in k13424 in ##compiler#load-identifier-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k13436 in k13430 in k13424 in ##compiler#load-identifier-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13445,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1509 read-file */
((C_proc3)C_retrieve_symbol_proc(lf[494]))(3,*((C_word*)lf[494]+1),t2,((C_word*)t0)[2]);}

/* k13443 in k13436 in k13430 in k13424 in ##compiler#load-identifier-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13445,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13447,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_13447(t5,((C_word*)t0)[2],t1);}

/* loop3883 in k13443 in k13436 in k13430 in k13424 in ##compiler#load-identifier-database in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_13447(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13447,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13489,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13467,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13471,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t8=C_i_car(t4);
/* support.scm: 1508 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[236]))(4,*((C_word*)lf[236]+1),t7,t8,lf[493]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k13469 in loop3883 in k13443 in k13436 in k13430 in k13424 in ##compiler#load-identifier-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13471,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_i_cdr(((C_word*)t0)[3]);
t4=C_a_i_list(&a,1,t3);
/* support.scm: 1508 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),((C_word*)t0)[2],t2,t4);}

/* k13465 in loop3883 in k13443 in k13436 in k13430 in k13424 in ##compiler#load-identifier-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1506 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[493],t1);}

/* k13487 in loop3883 in k13443 in k13436 in k13430 in k13424 in ##compiler#load-identifier-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_13447(t3,((C_word*)t0)[2],t2);}

/* foldable? in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13411(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13411,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[236]))(4,*((C_word*)lf[236]+1),t1,t2,lf[128]);}

/* ##compiler#intrinsic? in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13400(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13400,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[236]))(4,*((C_word*)lf[236]+1),t1,t2,lf[124]);}

/* ##compiler#variable-mark in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13394,4,t0,t1,t2,t3);}
/* support.scm: 1491 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[236]))(4,*((C_word*)lf[236]+1),t1,t2,t3);}

/* ##compiler#mark-variable in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_13366r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_13366r(t0,t1,t2,t3,t4);}}

static void C_ccall f_13366r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13370,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
/* support.scm: 1488 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t1,t2,t3,C_SCHEME_TRUE);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=C_i_car(t4);
/* support.scm: 1488 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t1,t2,t3,t7);}
else{
/* ##sys#error */
t7=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k13368 in ##compiler#mark-variable in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1488 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#variable-visible? in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13345(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13345,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13349,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1481 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[236]))(4,*((C_word*)lf[236]+1),t3,t2,lf[484]);}

/* k13347 in ##compiler#variable-visible? in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_eqp(t1,lf[483]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=C_eqp(t1,lf[486]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_TRUE:C_i_not(C_retrieve(lf[487]))));}}

/* ##compiler#export-variable in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13312,3,t0,t1,t2);}
t3=C_a_i_list(&a,1,lf[486]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13318,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t1,t2,lf[484],C_SCHEME_TRUE);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=C_i_car(t3);
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t1,t2,lf[484],t6);}
else{
/* ##sys#error */
t6=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k13316 in ##compiler#export-variable in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[484],t1);}

/* ##compiler#hide-variable in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13279(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13279,3,t0,t1,t2);}
t3=C_a_i_list(&a,1,lf[483]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13285,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t1,t2,lf[484],C_SCHEME_TRUE);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=C_i_car(t3);
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t1,t2,lf[484],t6);}
else{
/* ##sys#error */
t6=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k13283 in ##compiler#hide-variable in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[484],t1);}

/* ##compiler#big-fixnum? in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13255,3,t0,t1,t2);}
if(C_truep(C_fixnump(t2))){
if(C_truep(C_fudge(C_fix(3)))){
t3=C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#scan-sharp-greater-string in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13186(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13186,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13190,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1443 open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[45]))(2,*((C_word*)lf[45]+1),t3);}

/* k13188 in ##compiler#scan-sharp-greater-string in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13190,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13195,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_13195(t5,((C_word*)t0)[2]);}

/* loop in k13188 in ##compiler#scan-sharp-greater-string in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_13195(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13195,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13199,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=C_retrieve(lf[481]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k13197 in loop in k13188 in ##compiler#scan-sharp-greater-string in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13199,2,t0,t1);}
if(C_truep(C_eofp(t1))){
/* support.scm: 1446 quit */
((C_proc3)C_retrieve_proc(*((C_word*)lf[24]+1)))(3,*((C_word*)lf[24]+1),((C_word*)t0)[5],lf[482]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13217,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1448 newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13229,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=C_retrieve(lf[481]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13250,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k13248 in k13197 in loop in k13188 in ##compiler#scan-sharp-greater-string in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1460 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_13195(t2,((C_word*)t0)[2]);}

/* k13227 in k13197 in loop in k13188 in ##compiler#scan-sharp-greater-string in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13229,2,t0,t1);}
t2=C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
/* support.scm: 1453 get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[44]))(3,*((C_word*)lf[44]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13241,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t4=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k13239 in k13227 in k13197 in loop in k13188 in ##compiler#scan-sharp-greater-string in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13244,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k13242 in k13239 in k13227 in k13197 in loop in k13188 in ##compiler#scan-sharp-greater-string in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1457 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_13195(t2,((C_word*)t0)[2]);}

/* k13215 in k13197 in loop in k13188 in ##compiler#scan-sharp-greater-string in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1449 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_13195(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13153,4,t0,t1,t2,t3);}
t4=C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13163,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t6=C_retrieve(lf[481]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* support.scm: 1440 old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k13161 in ##sys#user-read-hook in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13166,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1438 scan-sharp-greater-string */
((C_proc3)C_retrieve_symbol_proc(lf[480]))(3,*((C_word*)lf[480]+1),t2,((C_word*)t0)[2]);}

/* k13164 in k13161 in ##sys#user-read-hook in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13166,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[478],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[479],t4));}

/* ##compiler#read/source-info in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13147(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13147,3,t0,t1,t2);}
/* support.scm: 1428 ##sys#read */
((C_proc4)C_retrieve_symbol_proc(lf[476]))(4,*((C_word*)lf[476]+1),t1,t2,C_retrieve(lf[471]));}

/* ##compiler#read-info-hook in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13102,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13106,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13109,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=C_eqp(lf[474],t2);
if(C_truep(t7)){
t8=C_i_car(t3);
t9=t6;
f_13109(t9,C_i_symbolp(t8));}
else{
t8=t6;
f_13109(t8,C_SCHEME_FALSE);}}

/* k13107 in ##compiler#read-info-hook in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_13109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13109,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13120,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13124,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1422 conc */
((C_proc5)C_retrieve_symbol_proc(lf[463]))(5,*((C_word*)lf[463]+1),t4,C_retrieve(lf[472]),lf[473],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* k13122 in k13107 in ##compiler#read-info-hook in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13128,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* support.scm: 1423 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t2,C_retrieve(lf[143]),t3);}

/* k13126 in k13122 in k13107 in ##compiler#read-info-hook in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* support.scm: 1421 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
/* support.scm: 1421 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k13118 in k13107 in ##compiler#read-info-hook in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1418 ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),((C_word*)t0)[3],C_retrieve(lf[143]),((C_word*)t0)[2],t1);}

/* k13104 in ##compiler#read-info-hook in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12979,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12983,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12988,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_12988(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12988(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12988,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=C_slot(t4,C_fix(1));
t6=t3;
t7=C_slot(t6,C_fix(2));
t8=t3;
t9=C_slot(t8,C_fix(3));
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13016,a[2]=t5,a[3]=t7,a[4]=t9,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 1399 make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[466]+1)))(4,*((C_word*)lf[466]+1),t10,t2,C_make_character(32));}

/* k13014 in loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13016,2,t0,t1);}
t2=C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_13022,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* write-char/port */
t5=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(10),t3);}

/* k13020 in k13014 in loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13025,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k13023 in k13020 in k13014 in loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(60),((C_word*)t0)[3]);}

/* k13026 in k13023 in k13020 in k13014 in loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13031,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k13029 in k13026 in k13023 in k13020 in k13014 in loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[2]);}

/* k13032 in k13029 in k13026 in k13023 in k13020 in k13014 in loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13037,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k13035 in k13032 in k13029 in k13026 in k13023 in k13020 in k13014 in loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13040,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13096,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a13095 in k13035 in k13032 in k13029 in k13026 in k13023 in k13020 in k13014 in loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13096(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13096,3,t0,t1,t2);}
/* g37013702 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12988(t3,t1,((C_word*)t0)[2],t2);}

/* k13038 in k13035 in k13032 in k13029 in k13026 in k13023 in k13020 in k13014 in loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13040,2,t0,t1);}
t2=C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13046,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fixnum_greaterp(t2,C_fix(4)))){
t4=*((C_word*)lf[11]+1);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13055,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t6=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_make_character(91),t4);}
else{
/* write-char/port */
t4=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[11]+1));}}

/* k13053 in k13038 in k13035 in k13032 in k13029 in k13026 in k13023 in k13020 in k13014 in loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13058,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[3],C_fix(4));
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,t3,((C_word*)t0)[2]);}

/* k13056 in k13053 in k13038 in k13035 in k13032 in k13029 in k13026 in k13023 in k13020 in k13014 in loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13061,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13066,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_13066(t6,t2,C_fix(5));}

/* doloop3710 in k13056 in k13053 in k13038 in k13035 in k13032 in k13029 in k13026 in k13023 in k13020 in k13014 in loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_13066(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13066,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13076,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* write-char/port */
t5=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(32),t3);}}

/* k13074 in doloop3710 in k13056 in k13053 in k13038 in k13035 in k13032 in k13029 in k13026 in k13023 in k13020 in k13014 in loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13079,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[3],((C_word*)t0)[6]);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,t3,((C_word*)t0)[2]);}

/* k13077 in k13074 in doloop3710 in k13056 in k13053 in k13038 in k13035 in k13032 in k13029 in k13026 in k13023 in k13020 in k13014 in loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_13066(t3,((C_word*)t0)[2],t2);}

/* k13059 in k13056 in k13053 in k13038 in k13035 in k13032 in k13029 in k13026 in k13023 in k13020 in k13014 in loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[11]+1));}

/* k13044 in k13038 in k13035 in k13032 in k13029 in k13026 in k13023 in k13020 in k13014 in loop in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_13046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[11]+1));}

/* k12981 in ##compiler#dump-nodes in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1411 newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* string-null? in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12976,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_string_null_p(C_retrieve(lf[324])));}

/* ##compiler#source-info->line in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12958(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12958,3,t0,t1,t2);}
if(C_truep(C_i_listp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_car(t2));}
else{
if(C_truep(t2)){
/* support.scm: 1383 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* ##compiler#source-info->string in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12924,3,t0,t1,t2);}
if(C_truep(C_i_listp(t2))){
t3=C_i_car(t2);
t4=C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12944,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12948,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=C_i_string_length(t3);
t8=C_fixnum_difference(C_fix(4),t7);
/* support.scm: 1377 max */
((C_proc4)C_retrieve_proc(*((C_word*)lf[467]+1)))(4,*((C_word*)lf[467]+1),t6,C_fix(0),t8);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12946 in ##compiler#source-info->string in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1377 make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[466]+1)))(4,*((C_word*)lf[466]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k12942 in ##compiler#source-info->string in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1377 conc */
((C_proc7)C_retrieve_symbol_proc(lf[463]))(7,*((C_word*)lf[463]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[464],t1,lf[465],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12909,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 1368 ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[149]))(4,*((C_word*)lf[149]+1),t1,t2,C_retrieve(lf[458]));}

/* a12908 in ##compiler#display-real-name-table in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12909,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[11]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12913,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t5,t2,t4);}

/* k12911 in a12908 in ##compiler#display-real-name-table in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(9),((C_word*)t0)[3]);}

/* k12914 in k12911 in a12908 in ##compiler#display-real-name-table in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12919,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k12917 in k12914 in k12911 in a12908 in ##compiler#display-real-name-table in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##compiler#real-name2 in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12891(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12891,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12895,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1364 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[458]),t2);}

/* k12893 in ##compiler#real-name2 in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1365 real-name */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12800(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_12800r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_12800r(t0,t1,t2,t3);}}

static void C_ccall f_12800r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12803,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12819,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1348 resolve */
f_12803(t5,t2);}

/* k12817 in ##compiler#real-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12819,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t3=C_i_car(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1352 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[235]))(3,*((C_word*)lf[235]+1),t4,t1);}
else{
/* support.scm: 1361 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[235]))(3,*((C_word*)lf[235]+1),((C_word*)t0)[3],t1);}}
else{
/* support.scm: 1349 ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[235]))(3,*((C_word*)lf[235]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k12842 in k12817 in ##compiler#real-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12848,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1353 get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[146]);}

/* k12846 in k12842 in k12817 in ##compiler#real-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12848,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12850,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_12850(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k12846 in k12842 in k12817 in ##compiler#real-name in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12850(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12850,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12857,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1355 resolve */
f_12803(t4,t3);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k12855 in loop in k12846 in k12842 in k12817 in ##compiler#real-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12857,2,t0,t1);}
t2=C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12870,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[45]))(2,*((C_word*)lf[45]+1),t3);}}

/* k12868 in k12855 in loop in k12846 in k12842 in k12817 in ##compiler#real-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12873,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],t1);}

/* k12871 in k12868 in k12855 in loop in k12846 in k12842 in k12817 in ##compiler#real-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,lf[459],((C_word*)t0)[3]);}

/* k12874 in k12871 in k12868 in k12855 in loop in k12846 in k12842 in k12817 in ##compiler#real-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12879,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k12877 in k12874 in k12871 in k12868 in k12855 in loop in k12846 in k12842 in k12817 in ##compiler#real-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12882,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[44]))(3,*((C_word*)lf[44]+1),t2,((C_word*)t0)[2]);}

/* k12880 in k12877 in k12874 in k12871 in k12868 in k12855 in loop in k12846 in k12842 in k12817 in ##compiler#real-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12886,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1359 get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[146]);}

/* k12884 in k12880 in k12877 in k12874 in k12871 in k12868 in k12855 in loop in k12846 in k12842 in k12817 in ##compiler#real-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1358 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_12850(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12803(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12803,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12807,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1343 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t3,C_retrieve(lf[458]),t2);}

/* k12805 in resolve in ##compiler#real-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12807,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12813,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1345 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t2,C_retrieve(lf[458]),t1);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k12811 in k12805 in resolve in ##compiler#real-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12794,4,t0,t1,t2,t3);}
/* support.scm: 1339 ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),t1,C_retrieve(lf[458]),t2,t3);}

/* ##compiler#make-random-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12735(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_12735r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_12735r(t0,t1,t2);}}

static void C_ccall f_12735r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12743,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[45]))(2,*((C_word*)lf[45]+1),t3);}

/* k12741 in ##compiler#make-random-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12746,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12770,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* support.scm: 1326 gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t4);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=C_i_car(t3);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,t6,t1);}
else{
/* ##sys#error */
t6=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k12768 in k12741 in ##compiler#make-random-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k12744 in k12741 in ##compiler#make-random-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12749,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(45),((C_word*)t0)[2]);}

/* k12747 in k12744 in k12741 in ##compiler#make-random-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12766,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1327 current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[456]))(2,*((C_word*)lf[456]+1),t3);}

/* k12764 in k12747 in k12744 in k12741 in ##compiler#make-random-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k12750 in k12747 in k12744 in k12741 in ##compiler#make-random-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12762,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1328 random */
((C_proc3)C_retrieve_symbol_proc(lf[455]))(3,*((C_word*)lf[455]+1),t3,C_fix(1000));}

/* k12760 in k12750 in k12747 in k12744 in k12741 in ##compiler#make-random-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k12753 in k12750 in k12747 in k12744 in k12741 in ##compiler#make-random-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12758,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[44]))(3,*((C_word*)lf[44]+1),t2,((C_word*)t0)[2]);}

/* k12756 in k12753 in k12750 in k12747 in k12744 in k12741 in ##compiler#make-random-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1324 string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12726(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12726,3,t0,t1,t2);}
t3=C_i_check_structure(t2,lf[451]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(1)));}

/* ##compiler#block-variable-literal? in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12720(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12720,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[451]));}

/* ##compiler#make-block-variable-literal in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12714(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12714,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,2,lf[451],t2));}

/* ##compiler#print-usage in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12706,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1186 print-version */
((C_proc2)C_retrieve_symbol_proc(lf[445]))(2,*((C_word*)lf[445]+1),t2);}

/* k12704 in ##compiler#print-usage in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12709,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1187 newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),t2);}

/* k12707 in k12704 in ##compiler#print-usage in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1188 display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),((C_word*)t0)[2],lf[449]);}

/* ##compiler#print-version in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12664(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_12664r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_12664r(t0,t1,t2);}}

static void C_ccall f_12664r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12668,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t2))){
t4=t3;
f_12668(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_12668(2,t5,C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k12666 in ##compiler#print-version in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12671,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* support.scm: 1182 print* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[446]+1)))(3,*((C_word*)lf[446]+1),t2,lf[447]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f14656,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1183 chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[294]))(3,*((C_word*)lf[294]+1),t3,C_SCHEME_TRUE);}}

/* f14656 in k12666 in ##compiler#print-version in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f14656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1183 print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[278]+1)))(3,*((C_word*)lf[278]+1),((C_word*)t0)[2],t1);}

/* k12669 in k12666 in ##compiler#print-version in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12678,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1183 chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[294]))(3,*((C_word*)lf[294]+1),t2,C_SCHEME_TRUE);}

/* k12676 in k12669 in k12666 in ##compiler#print-version in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1183 print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[278]+1)))(3,*((C_word*)lf[278]+1),((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12622(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12622,3,t0,t1,t2);}
t3=C_i_string_length(t2);
t4=C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12631,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_12631(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12631(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12631,NULL,3,t0,t1,t2);}
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=((C_word*)t0)[3];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_i_string_ref(((C_word*)t0)[3],t2);
t5=C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
/* support.scm: 1175 substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[442]+1)))(5,*((C_word*)lf[442]+1),t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=C_fixnum_decrease(t2);
/* support.scm: 1176 loop */
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}}

/* ##compiler#chop-separator in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12593(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12593,3,t0,t1,t2);}
t3=C_i_string_length(t2);
t4=C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12603,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_fixnum_greaterp(t4,C_fix(0)))){
t6=C_i_string_ref(t2,t4);
t7=t5;
f_12603(t7,C_i_memq(t6,lf[443]));}
else{
t6=t5;
f_12603(t6,C_SCHEME_FALSE);}}

/* k12601 in ##compiler#chop-separator in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12603(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 1168 substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[442]+1)))(5,*((C_word*)lf[442]+1),((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#scan-free-variables in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12384(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12384,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12387,a[2]=t10,a[3]=t8,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12553,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12588,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1158 walk */
t14=((C_word*)t8)[1];
f_12387(t14,t13,t2,C_SCHEME_END_OF_LIST);}

/* k12586 in ##compiler#scan-free-variables in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1159 values */
C_values(4,0,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12553(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12553,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12559,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_12559(t7,t1,t2);}

/* loop3518 in walkeach in ##compiler#scan-free-variables in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12559(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12559,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12567,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12574,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g35253526 */
t6=t3;
f_12567(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12572 in loop3518 in walkeach in ##compiler#scan-free-variables in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12559(t3,((C_word*)t0)[2],t2);}

/* g3525 in loop3518 in walkeach in ##compiler#scan-free-variables in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12567(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12567,NULL,3,t0,t1,t2);}
/* support.scm: 1156 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12387(t3,t1,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#scan-free-variables in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12387(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12387,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t2;
t9=C_slot(t8,C_fix(1));
t10=C_eqp(t9,lf[82]);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t7,a[9]=t9,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t10)){
t12=t11;
f_12421(t12,t10);}
else{
t12=C_eqp(t9,lf[214]);
if(C_truep(t12)){
t13=t11;
f_12421(t13,t12);}
else{
t13=C_eqp(t9,lf[222]);
if(C_truep(t13)){
t14=t11;
f_12421(t14,t13);}
else{
t14=C_eqp(t9,lf[225]);
t15=t11;
f_12421(t15,(C_truep(t14)?t14:C_eqp(t9,lf[238])));}}}}

/* k12419 in walk in ##compiler#scan-free-variables in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12421(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12421,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[9],lf[208]);
if(C_truep(t2)){
t3=C_i_car(((C_word*)t0)[8]);
if(C_truep(C_i_memq(t3,((C_word*)t0)[7]))){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12440,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 1138 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[440]))(5,*((C_word*)lf[440]+1),t4,*((C_word*)lf[268]+1),((C_word*)((C_word*)t0)[6])[1],t3);}}
else{
t3=C_eqp(((C_word*)t0)[9],lf[226]);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[8]);
if(C_truep(C_i_memq(t4,((C_word*)t0)[7]))){
t5=C_i_car(((C_word*)t0)[4]);
/* support.scm: 1144 walk */
t6=((C_word*)((C_word*)t0)[3])[1];
f_12387(t6,((C_word*)t0)[10],t5,((C_word*)t0)[7]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12476,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 1143 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[440]))(5,*((C_word*)lf[440]+1),t5,*((C_word*)lf[268]+1),((C_word*)((C_word*)t0)[6])[1],t4);}}
else{
t4=C_eqp(((C_word*)t0)[9],lf[92]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12485,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(((C_word*)t0)[4]);
/* support.scm: 1146 walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_12387(t7,t5,t6,((C_word*)t0)[7]);}
else{
t5=C_eqp(((C_word*)t0)[9],lf[221]);
if(C_truep(t5)){
t6=C_i_caddr(((C_word*)t0)[8]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12515,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1149 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[108]))(4,*((C_word*)lf[108]+1),((C_word*)t0)[10],t6,t7);}
else{
/* support.scm: 1153 walkeach */
t6=((C_word*)((C_word*)t0)[2])[1];
f_12553(t6,((C_word*)t0)[10],((C_word*)t0)[4],((C_word*)t0)[7]);}}}}}}

/* a12514 in k12419 in walk in ##compiler#scan-free-variables in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12515,5,t0,t1,t2,t3,t4);}
t5=C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12527,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1152 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),t6,t2,((C_word*)t0)[2]);}

/* k12525 in a12514 in k12419 in walk in ##compiler#scan-free-variables in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1152 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_12387(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k12483 in k12419 in walk in ##compiler#scan-free-variables in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12485,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12496,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1147 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12494 in k12483 in k12419 in walk in ##compiler#scan-free-variables in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 1147 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_12387(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k12474 in k12419 in walk in ##compiler#scan-free-variables in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=C_i_car(((C_word*)t0)[5]);
/* support.scm: 1144 walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_12387(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k12438 in k12419 in walk in ##compiler#scan-free-variables in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12440,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1139 variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[289]))(3,*((C_word*)lf[289]+1),t3,((C_word*)t0)[2]);}

/* k12444 in k12438 in k12419 in walk in ##compiler#scan-free-variables in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12446,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12450,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1140 lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[440]))(5,*((C_word*)lf[440]+1),t2,*((C_word*)lf[268]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k12448 in k12444 in k12438 in k12419 in walk in ##compiler#scan-free-variables in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12245,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12249,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12251,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_12251(t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12251(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12251,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t2;
t6=C_slot(t5,C_fix(1));
t7=C_eqp(t6,lf[208]);
t8=(C_truep(t7)?t7:C_eqp(t6,lf[226]));
if(C_truep(t8)){
t9=t2;
t10=C_slot(t9,C_fix(2));
t11=C_i_car(t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12283,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12312,a[2]=t12,a[3]=((C_word*)t0)[3],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_memq(t11,((C_word*)t0)[2]))){
t14=C_i_memq(t11,((C_word*)((C_word*)t0)[3])[1]);
t15=t13;
f_12312(t15,C_i_not(t14));}
else{
t14=t13;
f_12312(t14,C_SCHEME_FALSE);}}
else{
t9=C_eqp(t6,lf[82]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12344,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_12344(t11,t9);}
else{
t11=C_eqp(t6,lf[214]);
t12=t10;
f_12344(t12,(C_truep(t11)?t11:C_eqp(t6,lf[222])));}}}

/* k12342 in walk in ##compiler#scan-used-variables in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12344(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12344,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12349,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_12349(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop3443 in k12342 in walk in ##compiler#scan-used-variables in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12349(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12349,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12359,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g34503451 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12251(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12357 in loop3443 in k12342 in walk in ##compiler#scan-used-variables in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12349(t3,((C_word*)t0)[2],t2);}

/* k12310 in walk in ##compiler#scan-used-variables in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12312(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12312,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_12283(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_12283(t2,C_SCHEME_UNDEFINED);}}

/* k12281 in walk in ##compiler#scan-used-variables in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12283(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12283,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12288,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_12288(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop3419 in k12281 in walk in ##compiler#scan-used-variables in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12288(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12288,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12298,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g34263427 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12251(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12296 in loop3419 in k12281 in walk in ##compiler#scan-used-variables in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12288(t3,((C_word*)t0)[2],t2);}

/* k12247 in ##compiler#scan-used-variables in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11876,4,t0,t1,t2,t3);}
t4=t2;
t5=C_eqp(t4,lf[355]);
t6=(C_truep(t5)?t5:C_eqp(t4,lf[374]));
if(C_truep(t6)){
t7=C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,lf[82],t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,t3,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_cons(&a,2,lf[426],t10));}
else{
t7=C_eqp(t4,lf[358]);
if(C_truep(t7)){
t8=C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,lf[82],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t3,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_a_i_cons(&a,2,lf[427],t11));}
else{
t8=C_eqp(t4,lf[373]);
t9=(C_truep(t8)?t8:C_eqp(t4,lf[375]));
if(C_truep(t9)){
t10=C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,lf[82],t10);
t12=C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,t3,t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_a_i_cons(&a,2,lf[428],t13));}
else{
t10=C_eqp(t4,lf[371]);
t11=(C_truep(t10)?t10:C_eqp(t4,lf[372]));
if(C_truep(t11)){
t12=C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,lf[82],t12);
t14=C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,t3,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_a_i_cons(&a,2,lf[429],t15));}
else{
t12=C_eqp(t4,lf[359]);
if(C_truep(t12)){
t13=C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t14=C_a_i_cons(&a,2,lf[82],t13);
t15=C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=C_a_i_cons(&a,2,t3,t15);
t17=C_a_i_cons(&a,2,lf[426],t16);
t18=C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,C_a_i_cons(&a,2,lf[430],t18));}
else{
t13=C_eqp(t4,lf[376]);
if(C_truep(t13)){
t14=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,lf[82],t14);
t16=C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=C_a_i_cons(&a,2,t3,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_a_i_cons(&a,2,lf[431],t17));}
else{
t14=C_eqp(t4,lf[377]);
if(C_truep(t14)){
t15=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t16=C_a_i_cons(&a,2,lf[82],t15);
t17=C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=C_a_i_cons(&a,2,t3,t17);
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,C_a_i_cons(&a,2,lf[432],t18));}
else{
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12075,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(t2))){
t16=C_i_length(t2);
t17=C_eqp(C_fix(3),t16);
if(C_truep(t17)){
t18=C_i_car(t2);
t19=t15;
f_12075(t19,C_i_memq(t18,lf[437]));}
else{
t18=t15;
f_12075(t18,C_SCHEME_FALSE);}}
else{
t16=t15;
f_12075(t16,C_SCHEME_FALSE);}}}}}}}}}

/* k12073 in ##compiler#finish-foreign-result in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12075(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12075,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 1097 gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[3]))){
t3=C_i_length(((C_word*)t0)[3]);
t4=C_eqp(C_fix(3),t3);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[3]);
t6=t2;
f_12167(t6,C_eqp(lf[366],t5));}
else{
t5=t2;
f_12167(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_12167(t3,C_SCHEME_FALSE);}}}

/* k12165 in k12073 in ##compiler#finish-foreign-result in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_12167(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12167,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[4]);
t3=C_a_i_cons(&a,2,lf[364],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[82],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[435],t7));}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k12076 in k12073 in ##compiler#finish-foreign-result in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_12078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12078,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[433],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,lf[434],t7);
t9=C_i_caddr(((C_word*)t0)[3]);
t10=C_a_i_cons(&a,2,lf[364],C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,lf[82],t10);
t12=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,t11,t12);
t14=C_a_i_cons(&a,2,t9,t13);
t15=C_a_i_cons(&a,2,lf[435],t14);
t16=C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=C_a_i_cons(&a,2,t8,t16);
t18=C_a_i_cons(&a,2,t1,t17);
t19=C_a_i_cons(&a,2,lf[436],t18);
t20=C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=C_a_i_cons(&a,2,t4,t20);
t22=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_a_i_cons(&a,2,lf[92],t21));}

/* ##compiler#estimate-foreign-result-location-size in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11555(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11555,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11567,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11870,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1058 follow-without-loop */
((C_proc5)C_retrieve_proc(*((C_word*)lf[77]+1)))(5,*((C_word*)lf[77]+1),t1,t2,t3,t4);}

/* a11869 in ##compiler#estimate-foreign-result-location-size in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11870,2,t0,t1);}
/* support.scm: 1079 quit */
((C_proc4)C_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),t1,lf[424],((C_word*)t0)[2]);}

/* a11566 in ##compiler#estimate-foreign-result-location-size in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11567,4,t0,t1,t2,t3);}
t4=t2;
t5=C_eqp(t4,lf[333]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11577,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_11577(t7,t5);}
else{
t7=C_eqp(t4,lf[337]);
if(C_truep(t7)){
t8=t6;
f_11577(t8,t7);}
else{
t8=C_eqp(t4,lf[405]);
if(C_truep(t8)){
t9=t6;
f_11577(t9,t8);}
else{
t9=C_eqp(t4,lf[418]);
if(C_truep(t9)){
t10=t6;
f_11577(t10,t9);}
else{
t10=C_eqp(t4,lf[406]);
if(C_truep(t10)){
t11=t6;
f_11577(t11,t10);}
else{
t11=C_eqp(t4,lf[334]);
if(C_truep(t11)){
t12=t6;
f_11577(t12,t11);}
else{
t12=C_eqp(t4,lf[404]);
if(C_truep(t12)){
t13=t6;
f_11577(t13,t12);}
else{
t13=C_eqp(t4,lf[380]);
if(C_truep(t13)){
t14=t6;
f_11577(t14,t13);}
else{
t14=C_eqp(t4,lf[379]);
if(C_truep(t14)){
t15=t6;
f_11577(t15,t14);}
else{
t15=C_eqp(t4,lf[407]);
if(C_truep(t15)){
t16=t6;
f_11577(t16,t15);}
else{
t16=C_eqp(t4,lf[408]);
if(C_truep(t16)){
t17=t6;
f_11577(t17,t16);}
else{
t17=C_eqp(t4,lf[352]);
if(C_truep(t17)){
t18=t6;
f_11577(t18,t17);}
else{
t18=C_eqp(t4,lf[341]);
if(C_truep(t18)){
t19=t6;
f_11577(t19,t18);}
else{
t19=C_eqp(t4,lf[354]);
if(C_truep(t19)){
t20=t6;
f_11577(t20,t19);}
else{
t20=C_eqp(t4,lf[350]);
if(C_truep(t20)){
t21=t6;
f_11577(t21,t20);}
else{
t21=C_eqp(t4,lf[348]);
if(C_truep(t21)){
t22=t6;
f_11577(t22,t21);}
else{
t22=C_eqp(t4,lf[339]);
if(C_truep(t22)){
t23=t6;
f_11577(t23,t22);}
else{
t23=C_eqp(t4,lf[355]);
if(C_truep(t23)){
t24=t6;
f_11577(t24,t23);}
else{
t24=C_eqp(t4,lf[359]);
if(C_truep(t24)){
t25=t6;
f_11577(t25,t24);}
else{
t25=C_eqp(t4,lf[401]);
if(C_truep(t25)){
t26=t6;
f_11577(t26,t25);}
else{
t26=C_eqp(t4,lf[396]);
if(C_truep(t26)){
t27=t6;
f_11577(t27,t26);}
else{
t27=C_eqp(t4,lf[409]);
if(C_truep(t27)){
t28=t6;
f_11577(t28,t27);}
else{
t28=C_eqp(t4,lf[410]);
if(C_truep(t28)){
t29=t6;
f_11577(t29,t28);}
else{
t29=C_eqp(t4,lf[381]);
if(C_truep(t29)){
t30=t6;
f_11577(t30,t29);}
else{
t30=C_eqp(t4,lf[378]);
if(C_truep(t30)){
t31=t6;
f_11577(t31,t30);}
else{
t31=C_eqp(t4,lf[374]);
if(C_truep(t31)){
t32=t6;
f_11577(t32,t31);}
else{
t32=C_eqp(t4,lf[375]);
if(C_truep(t32)){
t33=t6;
f_11577(t33,t32);}
else{
t33=C_eqp(t4,lf[372]);
if(C_truep(t33)){
t34=t6;
f_11577(t34,t33);}
else{
t34=C_eqp(t4,lf[358]);
if(C_truep(t34)){
t35=t6;
f_11577(t35,t34);}
else{
t35=C_eqp(t4,lf[373]);
if(C_truep(t35)){
t36=t6;
f_11577(t36,t35);}
else{
t36=C_eqp(t4,lf[371]);
if(C_truep(t36)){
t37=t6;
f_11577(t37,t36);}
else{
t37=C_eqp(t4,lf[376]);
t38=t6;
f_11577(t38,(C_truep(t37)?t37:C_eqp(t4,lf[377])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k11575 in a11566 in ##compiler#estimate-foreign-result-location-size in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_11577(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11577,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub273(C_SCHEME_UNDEFINED,t3));}
else{
t2=C_eqp(((C_word*)t0)[4],lf[402]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[403]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
t5=C_i_foreign_fixnum_argumentp(C_fix(2));
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,stub273(C_SCHEME_UNDEFINED,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm: 1071 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[370]),((C_word*)t0)[2]);}
else{
t5=t4;
f_11595(2,t5,C_SCHEME_FALSE);}}}}

/* k11593 in k11575 in a11566 in ##compiler#estimate-foreign-result-location-size in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11595,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11599,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* g32783279 */
t3=t2;
f_11599(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_eqp(t2,lf[361]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_11634(t5,t3);}
else{
t5=C_eqp(t2,lf[343]);
if(C_truep(t5)){
t6=t4;
f_11634(t6,t5);}
else{
t6=C_eqp(t2,lf[341]);
if(C_truep(t6)){
t7=t4;
f_11634(t7,t6);}
else{
t7=C_eqp(t2,lf[352]);
if(C_truep(t7)){
t8=t4;
f_11634(t8,t7);}
else{
t8=C_eqp(t2,lf[354]);
t9=t4;
f_11634(t9,(C_truep(t8)?t8:C_eqp(t2,lf[369])));}}}}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
/* support.scm: 1057 quit */
((C_proc4)C_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),t2,lf[423],t3);}}}

/* k11632 in k11593 in k11575 in a11566 in ##compiler#estimate-foreign-result-location-size in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_11634(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub273(C_SCHEME_UNDEFINED,t3));}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
/* support.scm: 1057 quit */
((C_proc4)C_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),t2,lf[423],t3);}}

/* g3278 in k11593 in k11575 in a11566 in ##compiler#estimate-foreign-result-location-size in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_11599(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11599,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm: 1073 next */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t3=t2;
/* support.scm: 1073 next */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}

/* ##compiler#estimate-foreign-result-size in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11225(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11225,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11231,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11549,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1028 follow-without-loop */
((C_proc5)C_retrieve_proc(*((C_word*)lf[77]+1)))(5,*((C_word*)lf[77]+1),t1,t2,t3,t4);}

/* a11548 in ##compiler#estimate-foreign-result-size in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11549,2,t0,t1);}
/* support.scm: 1053 quit */
((C_proc4)C_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),t1,lf[421],((C_word*)t0)[2]);}

/* a11230 in ##compiler#estimate-foreign-result-size in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11231,4,t0,t1,t2,t3);}
t4=t2;
t5=C_eqp(t4,lf[333]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11241,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_11241(t7,t5);}
else{
t7=C_eqp(t4,lf[337]);
if(C_truep(t7)){
t8=t6;
f_11241(t8,t7);}
else{
t8=C_eqp(t4,lf[405]);
if(C_truep(t8)){
t9=t6;
f_11241(t9,t8);}
else{
t9=C_eqp(t4,lf[418]);
if(C_truep(t9)){
t10=t6;
f_11241(t10,t9);}
else{
t10=C_eqp(t4,lf[419]);
if(C_truep(t10)){
t11=t6;
f_11241(t11,t10);}
else{
t11=C_eqp(t4,lf[406]);
if(C_truep(t11)){
t12=t6;
f_11241(t12,t11);}
else{
t12=C_eqp(t4,lf[420]);
if(C_truep(t12)){
t13=t6;
f_11241(t13,t12);}
else{
t13=C_eqp(t4,lf[334]);
if(C_truep(t13)){
t14=t6;
f_11241(t14,t13);}
else{
t14=C_eqp(t4,lf[404]);
if(C_truep(t14)){
t15=t6;
f_11241(t15,t14);}
else{
t15=C_eqp(t4,lf[407]);
if(C_truep(t15)){
t16=t6;
f_11241(t16,t15);}
else{
t16=C_eqp(t4,lf[408]);
if(C_truep(t16)){
t17=t6;
f_11241(t17,t16);}
else{
t17=C_eqp(t4,lf[409]);
t18=t6;
f_11241(t18,(C_truep(t17)?t17:C_eqp(t4,lf[410])));}}}}}}}}}}}}

/* k11239 in a11230 in ##compiler#estimate-foreign-result-size in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_11241(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11241,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=C_eqp(((C_word*)t0)[4],lf[355]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_11250(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[358]);
if(C_truep(t4)){
t5=t3;
f_11250(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[352]);
if(C_truep(t5)){
t6=t3;
f_11250(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[354]);
if(C_truep(t6)){
t7=t3;
f_11250(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[359]);
if(C_truep(t7)){
t8=t3;
f_11250(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[373]);
if(C_truep(t8)){
t9=t3;
f_11250(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[371]);
if(C_truep(t9)){
t10=t3;
f_11250(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[374]);
if(C_truep(t10)){
t11=t3;
f_11250(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[375]);
if(C_truep(t11)){
t12=t3;
f_11250(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[372]);
if(C_truep(t12)){
t13=t3;
f_11250(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[376]);
t14=t3;
f_11250(t14,(C_truep(t13)?t13:C_eqp(((C_word*)t0)[4],lf[377])));}}}}}}}}}}}}

/* k11248 in k11239 in a11230 in ##compiler#estimate-foreign-result-size in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_11250(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11250,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub273(C_SCHEME_UNDEFINED,t3));}
else{
t2=C_eqp(((C_word*)t0)[4],lf[350]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11262,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_11262(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[380]);
if(C_truep(t4)){
t5=t3;
f_11262(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[348]);
if(C_truep(t5)){
t6=t3;
f_11262(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[379]);
if(C_truep(t6)){
t7=t3;
f_11262(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[381]);
t8=t3;
f_11262(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[4],lf[378])));}}}}}}

/* k11260 in k11248 in k11239 in a11230 in ##compiler#estimate-foreign-result-size in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_11262(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11262,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub273(C_SCHEME_UNDEFINED,t3));}
else{
t2=C_eqp(((C_word*)t0)[4],lf[339]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_11274(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[402]);
if(C_truep(t4)){
t5=t3;
f_11274(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[403]);
t6=t3;
f_11274(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[4],lf[417])));}}}}

/* k11272 in k11260 in k11248 in k11239 in a11230 in ##compiler#estimate-foreign-result-size in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_11274(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11274,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub273(C_SCHEME_UNDEFINED,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm: 1044 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t2,C_retrieve(lf[370]),((C_word*)t0)[2]);}
else{
t3=t2;
f_11280(2,t3,C_SCHEME_FALSE);}}}

/* k11278 in k11272 in k11260 in k11248 in k11239 in a11230 in ##compiler#estimate-foreign-result-size in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11280,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11284,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* g30443045 */
t3=t2;
f_11284(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_eqp(t2,lf[361]);
if(C_truep(t3)){
if(C_truep(t3)){
t4=((C_word*)t0)[3];
t5=C_i_foreign_fixnum_argumentp(C_fix(3));
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,stub273(C_SCHEME_UNDEFINED,t5));}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}}
else{
t4=C_eqp(t2,lf[343]);
if(C_truep(t4)){
if(C_truep(t4)){
t5=((C_word*)t0)[3];
t6=C_i_foreign_fixnum_argumentp(C_fix(3));
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,stub273(C_SCHEME_UNDEFINED,t6));}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(0));}}
else{
t5=C_eqp(t2,lf[341]);
if(C_truep(t5)){
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=C_i_foreign_fixnum_argumentp(C_fix(3));
t8=t6;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,stub273(C_SCHEME_UNDEFINED,t7));}
else{
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_fix(0));}}
else{
t6=C_eqp(t2,lf[352]);
if(C_truep(t6)){
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=C_i_foreign_fixnum_argumentp(C_fix(3));
t9=t7;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,stub273(C_SCHEME_UNDEFINED,t8));}
else{
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_fix(0));}}
else{
t7=C_eqp(t2,lf[354]);
if(C_truep(t7)){
if(C_truep(t7)){
t8=((C_word*)t0)[3];
t9=C_i_foreign_fixnum_argumentp(C_fix(3));
t10=t8;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,stub273(C_SCHEME_UNDEFINED,t9));}
else{
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fix(0));}}
else{
t8=C_eqp(t2,lf[369]);
if(C_truep(t8)){
if(C_truep(t8)){
t9=((C_word*)t0)[3];
t10=C_i_foreign_fixnum_argumentp(C_fix(3));
t11=t9;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,stub273(C_SCHEME_UNDEFINED,t10));}
else{
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_fix(0));}}
else{
t9=C_eqp(t2,lf[362]);
if(C_truep(t9)){
if(C_truep(t9)){
t10=((C_word*)t0)[3];
t11=C_i_foreign_fixnum_argumentp(C_fix(3));
t12=t10;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,stub273(C_SCHEME_UNDEFINED,t11));}
else{
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_fix(0));}}
else{
t10=C_eqp(t2,lf[363]);
if(C_truep(t10)){
if(C_truep(t10)){
t11=((C_word*)t0)[3];
t12=C_i_foreign_fixnum_argumentp(C_fix(3));
t13=t11;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,stub273(C_SCHEME_UNDEFINED,t12));}
else{
t11=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_fix(0));}}
else{
t11=C_eqp(t2,lf[366]);
if(C_truep(t11)){
t12=((C_word*)t0)[3];
t13=C_i_foreign_fixnum_argumentp(C_fix(3));
t14=t12;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,stub273(C_SCHEME_UNDEFINED,t13));}
else{
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_fix(0));}}}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* g3044 in k11278 in k11272 in k11260 in k11248 in k11239 in a11230 in ##compiler#estimate-foreign-result-size in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_11284(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11284,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm: 1046 next */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t3=t2;
/* support.scm: 1046 next */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}

/* ##compiler#final-foreign-type in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11180(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11180,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11186,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11219,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 1015 follow-without-loop */
((C_proc5)C_retrieve_proc(*((C_word*)lf[77]+1)))(5,*((C_word*)lf[77]+1),t1,t2,t3,t4);}

/* a11218 in ##compiler#final-foreign-type in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11219,2,t0,t1);}
/* support.scm: 1022 quit */
((C_proc4)C_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),t1,lf[415],((C_word*)t0)[2]);}

/* a11185 in ##compiler#final-foreign-type in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11186,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11190,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(t2))){
/* support.scm: 1018 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[370]),t2);}
else{
t5=t4;
f_11190(2,t5,C_SCHEME_FALSE);}}

/* k11188 in a11185 in ##compiler#final-foreign-type in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11190,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11194,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* g28672868 */
t3=t2;
f_11194(t3,((C_word*)t0)[3],t1);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* g2867 in k11188 in a11185 in ##compiler#final-foreign-type in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_11194(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11194,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm: 1020 next */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t3=t2;
/* support.scm: 1020 next */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}

/* ##compiler#foreign-type-convert-argument in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11149,4,t0,t1,t2,t3);}
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11162,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1009 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[370]),t3);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k11160 in ##compiler#foreign-type-convert-argument in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11162,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_vectorp(t1))){
t2=C_i_vector_ref(t1,C_fix(1));
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#foreign-type-convert-result in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11118,4,t0,t1,t2,t3);}
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11131,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 1002 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[370]),t3);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k11129 in ##compiler#foreign-type-convert-result in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11131,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_vectorp(t1))){
t2=C_i_vector_ref(t1,C_fix(2));
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_10060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10060,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10066,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11112,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 903  follow-without-loop */
((C_proc5)C_retrieve_proc(*((C_word*)lf[77]+1)))(5,*((C_word*)lf[77]+1),t1,t3,t4,t5);}

/* a11111 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_11112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11112,2,t0,t1);}
/* support.scm: 995  quit */
((C_proc4)C_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),t1,lf[411],((C_word*)t0)[2]);}

/* a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_10066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10066,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10072,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_10072(t7,t1,t2);}

/* repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10072(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10072,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_eqp(t3,lf[333]);
t5=(C_truep(t4)?t4:C_eqp(t3,lf[334]));
if(C_truep(t5)){
if(C_truep(C_retrieve(lf[335]))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[4]);}
else{
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_cons(&a,2,lf[336],t6));}}
else{
t6=C_eqp(t3,lf[337]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_10101(t8,t6);}
else{
t8=C_eqp(t3,lf[404]);
if(C_truep(t8)){
t9=t7;
f_10101(t9,t8);}
else{
t9=C_eqp(t3,lf[405]);
if(C_truep(t9)){
t10=t7;
f_10101(t10,t9);}
else{
t10=C_eqp(t3,lf[406]);
if(C_truep(t10)){
t11=t7;
f_10101(t11,t10);}
else{
t11=C_eqp(t3,lf[407]);
if(C_truep(t11)){
t12=t7;
f_10101(t12,t11);}
else{
t12=C_eqp(t3,lf[408]);
if(C_truep(t12)){
t13=t7;
f_10101(t13,t12);}
else{
t13=C_eqp(t3,lf[409]);
t14=t7;
f_10101(t14,(C_truep(t13)?t13:C_eqp(t3,lf[410])));}}}}}}}}

/* k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10101(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10101,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[335]))){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[338],t2));}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[339]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_10120(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[402]);
t5=t3;
f_10120(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[5],lf[403])));}}}

/* k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10120(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10120,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[335]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[340],t2));}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[341]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_10139(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[399]);
if(C_truep(t4)){
t5=t3;
f_10139(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[400]);
t6=t3;
f_10139(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[5],lf[401])));}}}}

/* k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10139(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10139,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10142,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 913  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[343]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_10209(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[396]);
if(C_truep(t4)){
t5=t3;
f_10209(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[397]);
t6=t3;
f_10209(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[5],lf[398])));}}}}

/* k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10209(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10209,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[335]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[342],t2));}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[344]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_10228(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[389]);
if(C_truep(t4)){
t5=t3;
f_10228(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[390]);
if(C_truep(t5)){
t6=t3;
f_10228(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[391]);
if(C_truep(t6)){
t7=t3;
f_10228(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[5],lf[392]);
if(C_truep(t7)){
t8=t3;
f_10228(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[393]);
if(C_truep(t8)){
t9=t3;
f_10228(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[394]);
t10=t3;
f_10228(t10,(C_truep(t9)?t9:C_eqp(((C_word*)t0)[5],lf[395])));}}}}}}}}

/* k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10228(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10228,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10231,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 925  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[346]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_10310(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[382]);
if(C_truep(t4)){
t5=t3;
f_10310(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[383]);
if(C_truep(t5)){
t6=t3;
f_10310(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[384]);
if(C_truep(t6)){
t7=t3;
f_10310(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[385]);
if(C_truep(t7)){
t8=t3;
f_10310(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[386]);
if(C_truep(t8)){
t9=t3;
f_10310(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[387]);
t10=t3;
f_10310(t10,(C_truep(t9)?t9:C_eqp(((C_word*)t0)[4],lf[388])));}}}}}}}}

/* k10308 in k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10310(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10310,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[335]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=C_i_assq(((C_word*)t0)[5],lf[347]);
t3=C_slot(t2,C_fix(1));
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[82],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[345],t7));}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[348]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_10349(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[380]);
t5=t3;
f_10349(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[381])));}}}

/* k10347 in k10308 in k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10349(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10349,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[335]))){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[349],t2));}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[350]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_10368(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[378]);
t5=t3;
f_10368(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[5],lf[379])));}}}

/* k10366 in k10347 in k10308 in k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10368(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10368,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[335]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[351],t2));}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[352]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_10387(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[376]);
t5=t3;
f_10387(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[5],lf[377])));}}}

/* k10385 in k10366 in k10347 in k10308 in k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10387(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10387,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10390,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 945  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[354]);
if(C_truep(t2)){
t3=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[353],t3));}
else{
t3=C_eqp(((C_word*)t0)[5],lf[355]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_10467(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[373]);
if(C_truep(t5)){
t6=t4;
f_10467(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[374]);
t7=t4;
f_10467(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[5],lf[375])));}}}}}

/* k10465 in k10385 in k10366 in k10347 in k10308 in k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10467(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10467,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10470,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 953  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[358]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_10552(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[371]);
t5=t3;
f_10552(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[5],lf[372])));}}}

/* k10550 in k10465 in k10385 in k10366 in k10347 in k10308 in k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10552(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10552,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[335]))){
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[356],t2));}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[357],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[356],t4));}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[359]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[335]))){
t3=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[360],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[356],t5));}
else{
t3=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[360],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[357],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[356],t7));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm: 969  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t3,C_retrieve(lf[370]),((C_word*)t0)[3]);}
else{
t4=t3;
f_10627(2,t4,C_SCHEME_FALSE);}}}}

/* k10625 in k10550 in k10465 in k10385 in k10366 in k10347 in k10308 in k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_10627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10627,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10631,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* g27732774 */
t3=t2;
f_10631(t3,((C_word*)t0)[5],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=C_i_car(((C_word*)t0)[4]);
t3=C_eqp(t2,lf[361]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_10666(t5,t3);}
else{
t5=C_eqp(t2,lf[341]);
if(C_truep(t5)){
t6=t4;
f_10666(t6,t5);}
else{
t6=C_eqp(t2,lf[369]);
t7=t4;
f_10666(t7,(C_truep(t6)?t6:C_eqp(t2,lf[352])));}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k10664 in k10625 in k10550 in k10465 in k10385 in k10366 in k10347 in k10308 in k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10666(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10666,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10669,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 975  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t2);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[362]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[363]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10736,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 981  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t4);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[366]);
if(C_truep(t4)){
t5=C_a_i_cons(&a,2,lf[364],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[82],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[6],t7);
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_cons(&a,2,lf[365],t8));}
else{
t5=C_eqp(((C_word*)t0)[4],lf[367]);
if(C_truep(t5)){
t6=C_i_cadr(((C_word*)t0)[3]);
/* support.scm: 988  repeat */
t7=((C_word*)((C_word*)t0)[2])[1];
f_10072(t7,((C_word*)t0)[5],t6);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[368]);
if(C_truep(t6)){
if(C_truep(C_retrieve(lf[335]))){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[6]);}
else{
t7=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[349],t7));}}
else{
t7=C_eqp(((C_word*)t0)[4],lf[343]);
t8=(C_truep(t7)?t7:C_eqp(((C_word*)t0)[4],lf[354]));
if(C_truep(t8)){
t9=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,lf[353],t9));}
else{
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[6]);}}}}}}}

/* k10734 in k10664 in k10625 in k10550 in k10465 in k10385 in k10366 in k10347 in k10308 in k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_10736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10736,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[364],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[82],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=C_a_i_cons(&a,2,lf[365],t8);
t10=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,lf[82],t10);
t12=C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,t9,t12);
t14=C_a_i_cons(&a,2,t1,t13);
t15=C_a_i_cons(&a,2,lf[213],t14);
t16=C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=C_a_i_cons(&a,2,t4,t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_a_i_cons(&a,2,lf[92],t17));}

/* k10667 in k10664 in k10625 in k10550 in k10465 in k10385 in k10366 in k10347 in k10308 in k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_10669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10669,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[353],t5);
t7=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,lf[82],t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,t6,t9);
t11=C_a_i_cons(&a,2,t1,t10);
t12=C_a_i_cons(&a,2,lf[213],t11);
t13=C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_a_i_cons(&a,2,lf[92],t14));}

/* g2773 in k10625 in k10550 in k10465 in k10385 in k10366 in k10347 in k10308 in k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10631(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10631,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm: 971  next */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t3=t2;
/* support.scm: 971  next */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}

/* k10468 in k10465 in k10385 in k10366 in k10347 in k10308 in k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_10470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10470,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10501,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[335]))){
t6=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_10501(t7,C_a_i_cons(&a,2,lf[356],t6));}
else{
t6=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[357],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t5;
f_10501(t9,C_a_i_cons(&a,2,lf[356],t8));}}

/* k10499 in k10468 in k10465 in k10385 in k10366 in k10347 in k10308 in k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10501,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[82],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t1,t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_cons(&a,2,lf[213],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,lf[92],t9));}

/* k10388 in k10385 in k10366 in k10347 in k10308 in k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_10390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10390,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[353],t5);
t7=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,lf[82],t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,t6,t9);
t11=C_a_i_cons(&a,2,t1,t10);
t12=C_a_i_cons(&a,2,lf[213],t11);
t13=C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_a_i_cons(&a,2,lf[92],t14));}

/* k10229 in k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_10231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10231,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10262,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[335]))){
t6=t5;
f_10262(t6,t1);}
else{
t6=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[82],t6);
t8=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t7,t8);
t10=t5;
f_10262(t10,C_a_i_cons(&a,2,lf[345],t9));}}

/* k10260 in k10229 in k10226 in k10207 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10262(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10262,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[82],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t1,t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_cons(&a,2,lf[213],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,lf[92],t9));}

/* k10140 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_10142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10142,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10173,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[335]))){
t6=t5;
f_10173(t6,t1);}
else{
t6=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_10173(t7,C_a_i_cons(&a,2,lf[342],t6));}}

/* k10171 in k10140 in k10137 in k10118 in k10099 in repeat in a10065 in ##compiler#foreign-type-check in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10173(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10173,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[82],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t1,t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_cons(&a,2,lf[213],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,lf[92],t9));}

/* ##compiler#pprint-expressions-to-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_10002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10002,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10006,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm: 884  open-output-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[330]+1)))(3,*((C_word*)lf[330]+1),t4,t3);}
else{
/* support.scm: 884  current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[331]+1)))(2,*((C_word*)lf[331]+1),t4);}}

/* k10004 in ##compiler#pprint-expressions-to-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_10006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10009,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10017,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 885  with-output-to-port */
((C_proc4)C_retrieve_symbol_proc(lf[329]))(4,*((C_word*)lf[329]+1),t2,t1,t3);}

/* a10016 in k10004 in ##compiler#pprint-expressions-to-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_10017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10017,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10023,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_10023(t5,t1,((C_word*)t0)[2]);}

/* loop2446 in a10016 in k10004 in ##compiler#pprint-expressions-to-file in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_10023(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10023,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10041,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10035,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 889  pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[328]))(3,*((C_word*)lf[328]+1),t5,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10033 in loop2446 in a10016 in k10004 in ##compiler#pprint-expressions-to-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_10035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 890  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* k10039 in loop2446 in a10016 in k10004 in ##compiler#pprint-expressions-to-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_10041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10023(t3,((C_word*)t0)[2],t2);}

/* k10007 in k10004 in ##compiler#pprint-expressions-to-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_10009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* support.scm: 892  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[327]+1)))(3,*((C_word*)lf[327]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9921(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9921,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9927,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9933,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9933(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_9933,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9940,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 872  debugging */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t9,lf[324],lf[325]);}

/* k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9940,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[323],t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9946,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,lf[322],((C_word*)t0)[3]);}

/* k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9952,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9950 in k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9955,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k9953 in k9950 in k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9955,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9958,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[321],t2);}

/* k9956 in k9953 in k9950 in k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9961,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9959 in k9956 in k9953 in k9950 in k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k9962 in k9959 in k9956 in k9953 in k9950 in k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9964,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9967,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[320],t2);}

/* k9965 in k9962 in k9959 in k9956 in k9953 in k9950 in k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9970,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9968 in k9965 in k9962 in k9959 in k9956 in k9953 in k9950 in k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9973,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k9971 in k9968 in k9965 in k9962 in k9959 in k9956 in k9953 in k9950 in k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9973,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9976,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[319],t2);}

/* k9974 in k9971 in k9968 in k9965 in k9962 in k9959 in k9956 in k9953 in k9950 in k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9979,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9977 in k9974 in k9971 in k9968 in k9965 in k9962 in k9959 in k9956 in k9953 in k9950 in k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9982,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k9980 in k9977 in k9974 in k9971 in k9968 in k9965 in k9962 in k9959 in k9956 in k9953 in k9950 in k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9982,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9985,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[318],t2);}

/* k9983 in k9980 in k9977 in k9974 in k9971 in k9968 in k9965 in k9962 in k9959 in k9956 in k9953 in k9950 in k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9986 in k9983 in k9980 in k9977 in k9974 in k9971 in k9968 in k9965 in k9962 in k9959 in k9956 in k9953 in k9950 in k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k9989 in k9986 in k9983 in k9980 in k9977 in k9974 in k9971 in k9968 in k9965 in k9962 in k9959 in k9956 in k9953 in k9950 in k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9991,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9994,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[317],t2);}

/* k9992 in k9989 in k9986 in k9983 in k9980 in k9977 in k9974 in k9971 in k9968 in k9965 in k9962 in k9959 in k9956 in k9953 in k9950 in k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9997,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9995 in k9992 in k9989 in k9986 in k9983 in k9980 in k9977 in k9974 in k9971 in k9968 in k9965 in k9962 in k9959 in k9956 in k9953 in k9950 in k9947 in k9944 in k9941 in k9938 in a9932 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* a9926 in ##compiler#print-program-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9927,2,t0,t1);}
/* support.scm: 871  compute-database-statistics */
((C_proc3)C_retrieve_symbol_proc(lf[313]))(3,*((C_word*)lf[313]+1),t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9813(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9813,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9817,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9822,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 847  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[149]))(4,*((C_word*)lf[149]+1),t13,t14,t2);}

/* a9821 in ##compiler#compute-database-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9822,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9828,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_9828(t7,t1,t3);}

/* loop2367 in a9821 in ##compiler#compute-database-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_9828(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9828,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9836,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_9836(t3,t4);
t6=C_slot(t2,C_fix(1));
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g2374 in loop2367 in a9821 in ##compiler#compute-database-statistics in k5084 in k5081 in k4019 in k4016 */
static C_word C_fcall f_9836(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_stack_check;
t2=C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_i_car(t1);
t5=C_eqp(t4,lf[177]);
if(C_truep(t5)){
t6=C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,t6);
return(t7);}
else{
t6=C_eqp(t4,lf[160]);
if(C_truep(t6)){
t7=C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t9=C_i_cdr(t1);
t10=C_slot(t9,C_fix(1));
t11=C_eqp(lf[221],t10);
if(C_truep(t11)){
t12=C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t13=C_mutate(((C_word *)((C_word*)t0)[3])+1,t12);
return(t13);}
else{
t12=C_SCHEME_UNDEFINED;
return(t12);}}
else{
t7=C_eqp(t4,lf[166]);
if(C_truep(t7)){
t8=C_i_cdr(t1);
t9=C_i_length(t8);
t10=C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t9);
t11=C_mutate(((C_word *)((C_word*)t0)[2])+1,t10);
return(t11);}
else{
t8=C_SCHEME_UNDEFINED;
return(t8);}}}}

/* k9815 in ##compiler#compute-database-statistics in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 861  values */
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[314]),C_retrieve(lf[315]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#toplevel-definition-hook in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9792,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9802,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 824  debugging */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),t7,lf[243],lf[312],t2);}
else{
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k9800 in ##sys#toplevel-definition-hook in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 825  hide-variable */
((C_proc3)C_retrieve_symbol_proc(lf[311]))(3,*((C_word*)lf[311]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#dump-global-refs in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9743(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9743,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9749,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 810  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[149]))(4,*((C_word*)lf[149]+1),t1,t3,t2);}

/* a9748 in ##compiler#dump-global-refs in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9749,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9790,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 812  keyword? */
((C_proc3)C_retrieve_symbol_proc(lf[307]))(3,*((C_word*)lf[307]+1),t4,t2);}

/* k9788 in a9748 in ##compiler#dump-global-refs in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9790,2,t0,t1);}
t2=(C_truep(t1)?C_SCHEME_FALSE:C_i_assq(lf[177],((C_word*)t0)[4]));
if(C_truep(t2)){
t3=C_i_assq(lf[165],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9762,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=C_i_cdr(t3);
t6=C_i_length(t5);
t7=C_a_i_list(&a,2,((C_word*)t0)[2],t6);
/* support.scm: 814  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t4,t7);}
else{
t5=C_a_i_list(&a,2,((C_word*)t0)[2],C_fix(0));
/* support.scm: 814  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t4,t5);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9760 in k9788 in a9748 in ##compiler#dump-global-refs in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 815  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* ##compiler#dump-defined-globals in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9706(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9706,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9712,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 800  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[149]))(4,*((C_word*)lf[149]+1),t1,t3,t2);}

/* a9711 in ##compiler#dump-defined-globals in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9712(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9712,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9719,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9741,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 802  keyword? */
((C_proc3)C_retrieve_symbol_proc(lf[307]))(3,*((C_word*)lf[307]+1),t5,t2);}

/* k9739 in a9711 in ##compiler#dump-defined-globals in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_9719(t2,C_SCHEME_FALSE);}
else{
t2=C_i_assq(lf[177],((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_9719(t3,(C_truep(t2)?C_i_assq(lf[175],((C_word*)t0)[2]):C_SCHEME_FALSE));}}

/* k9717 in a9711 in ##compiler#dump-defined-globals in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_9719(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9719,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9722,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 805  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k9720 in k9717 in a9711 in ##compiler#dump-defined-globals in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 806  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* ##compiler#dump-undefined-globals in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9665(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9665,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9671,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 790  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[149]))(4,*((C_word*)lf[149]+1),t1,t3,t2);}

/* a9670 in ##compiler#dump-undefined-globals in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9671,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9678,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9704,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 792  keyword? */
((C_proc3)C_retrieve_symbol_proc(lf[307]))(3,*((C_word*)lf[307]+1),t5,t2);}

/* k9702 in a9670 in ##compiler#dump-undefined-globals in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_9678(t2,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_assq(lf[177],((C_word*)t0)[2]))){
t2=C_i_assq(lf[175],((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_9678(t3,C_i_not(t2));}
else{
t2=((C_word*)t0)[3];
f_9678(t2,C_SCHEME_FALSE);}}}

/* k9676 in a9670 in ##compiler#dump-undefined-globals in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_9678(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9678,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9681,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 795  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k9679 in k9676 in a9670 in ##compiler#dump-undefined-globals in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 796  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* ##compiler#simple-lambda-node? in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9543(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9543,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(2));
t5=C_i_caddr(t4);
t6=C_i_pairp(t5);
t7=(C_truep(t6)?C_i_car(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
if(C_truep(C_i_cadr(t4))){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9572,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_9572(3,t11,t1,t2);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* rec in ##compiler#simple-lambda-node? in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9572(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9572,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(t4,lf[233]);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(3));
t8=C_i_car(t7);
t9=C_slot(t8,C_fix(1));
t10=C_eqp(lf[208],t9);
if(C_truep(t10)){
t11=C_slot(t8,C_fix(2));
t12=C_i_car(t11);
t13=C_eqp(((C_word*)t0)[3],t12);
if(C_truep(t13)){
t14=C_i_cdr(t7);
/* support.scm: 782  every */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),t1,((C_word*)((C_word*)t0)[2])[1],t14);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t6=C_eqp(t4,lf[224]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=t2;
t8=C_slot(t7,C_fix(3));
/* support.scm: 784  every */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* ##compiler#expression-has-side-effects? in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9442,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9448,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_9448(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9448(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9448,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t2;
t6=C_slot(t5,C_fix(1));
t7=C_eqp(t6,lf[208]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9474,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_9474(t9,t7);}
else{
t9=C_eqp(t6,lf[82]);
if(C_truep(t9)){
t10=t8;
f_9474(t10,t9);}
else{
t10=C_eqp(t6,lf[214]);
if(C_truep(t10)){
t11=t8;
f_9474(t11,t10);}
else{
t11=C_eqp(t6,lf[225]);
t12=t8;
f_9474(t12,(C_truep(t11)?t11:C_eqp(t6,lf[212])));}}}}

/* k9472 in walk in ##compiler#expression-has-side-effects? in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_9474(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9474,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[221]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(2));
t5=C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9488,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 765  find */
((C_proc4)C_retrieve_symbol_proc(lf[303]))(4,*((C_word*)lf[303]+1),((C_word*)t0)[6],t6,C_retrieve(lf[304]));}
else{
t3=C_eqp(((C_word*)t0)[5],lf[213]);
if(C_truep(t3)){
if(C_truep(t3)){
/* support.scm: 766  any */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}}
else{
t4=C_eqp(((C_word*)t0)[5],lf[92]);
if(C_truep(t4)){
/* support.scm: 766  any */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}}

/* a9487 in k9472 in walk in ##compiler#expression-has-side-effects? in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9488,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9496,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 765  foreign-callback-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[302]))(3,*((C_word*)lf[302]+1),t3,t2);}

/* k9494 in a9487 in k9472 in walk in ##compiler#expression-has-side-effects? in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9217(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[27],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9217,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9220,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t14=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9254,a[2]=t10,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t15=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9297,a[2]=t10,a[3]=t12,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9416,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 749  matchn */
t17=((C_word*)t12)[1];
f_9297(t17,t16,t2,t3);}

/* k9414 in ##compiler#match-node in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9416,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9422,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_slot(t3,C_fix(1));
t5=((C_word*)t0)[3];
t6=C_slot(t5,C_fix(2));
/* support.scm: 752  debugging */
((C_proc7)C_retrieve_proc(*((C_word*)lf[10]+1)))(7,*((C_word*)lf[10]+1),t2,lf[299],lf[300],t4,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9420 in k9414 in ##compiler#match-node in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* matchn in ##compiler#match-node in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_9297(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9297,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm: 738  resolve */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9220(t4,t1,t3,t2);}
else{
t4=t2;
t5=C_slot(t4,C_fix(1));
t6=C_i_car(t3);
t7=C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9319,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t9=t2;
t10=C_slot(t9,C_fix(2));
t11=C_i_cadr(t3);
/* support.scm: 740  match1 */
t12=((C_word*)((C_word*)t0)[2])[1];
f_9254(t12,t8,t10,t11);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}

/* k9317 in matchn in ##compiler#match-node in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9319,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=C_slot(t2,C_fix(3));
t4=C_i_cddr(((C_word*)t0)[5]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9337,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_9337(t8,((C_word*)t0)[2],t3,t4);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop in k9317 in matchn in ##compiler#match-node in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_9337(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9337,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_nullp(t2));}
else{
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm: 744  resolve */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9220(t4,t1,t3,t2);}
else{
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9368,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t2);
t6=C_i_car(t3);
/* support.scm: 746  matchn */
t7=((C_word*)((C_word*)t0)[2])[1];
f_9297(t7,t4,t5,t6);}}}}

/* k9366 in loop in k9317 in matchn in ##compiler#match-node in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 747  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9337(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_9254(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9254,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm: 731  resolve */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9220(t4,t1,t3,t2);}
else{
if(C_truep(C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9276,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t2);
t6=C_i_car(t3);
/* support.scm: 733  match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k9274 in match1 in ##compiler#match-node in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 733  match1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9254(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_9220(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9220,NULL,4,t0,t1,t2,t3);}
t4=C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9228,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* g21702171 */
t6=t1;
((C_proc2)C_retrieve_proc(t6))(2,t6,f_9228(t5,t4));}
else{
if(C_truep(C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9249,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 726  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_eqp(t2,t3));}}}

/* k9247 in resolve in ##compiler#match-node in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* g2170 in resolve in ##compiler#match-node in k5084 in k5081 in k4019 in k4016 */
static C_word C_fcall f_9228(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_i_cdr(t1);
return(C_i_equalp(((C_word*)t0)[2],t2));}

/* ##compiler#load-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9148,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9154,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 706  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[297]))(4,*((C_word*)lf[297]+1),t1,t2,t3);}

/* a9153 in ##compiler#load-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9154,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9160,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_9160(t5,t1);}

/* loop in a9153 in ##compiler#load-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_9160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9160,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9164,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 709  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[101]+1)))(2,*((C_word*)lf[101]+1),t2);}

/* k9162 in loop in a9153 in ##compiler#load-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9164,2,t0,t1);}
if(C_truep(C_eofp(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9200,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9211,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cadr(t1);
/* support.scm: 714  sexpr->node */
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t4,t5);}}

/* k9209 in k9162 in loop in a9153 in ##compiler#load-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9211,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t2))){
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[288],C_SCHEME_TRUE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=C_i_car(t2);
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[288],t5);}
else{
/* ##sys#error */
t5=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k9173 in k9209 in k9162 in loop in a9153 in ##compiler#load-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[288],t1);}

/* k9198 in k9162 in loop in a9153 in ##compiler#load-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 715  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9160(t2,((C_word*)t0)[2]);}

/* ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8956,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8960,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8987,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 675  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[295]))(4,*((C_word*)lf[295]+1),t6,t2,t7);}

/* a8986 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9146,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 677  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[294]))(2,*((C_word*)lf[294]+1),t3);}

/* k9144 in a8986 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 677  print */
((C_proc7)C_retrieve_proc(*((C_word*)lf[278]+1)))(7,*((C_word*)lf[278]+1),((C_word*)t0)[2],lf[290],t1,lf[291],C_retrieve(lf[292]),lf[293]);}

/* k8989 in a8986 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8994,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 679  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[149]))(4,*((C_word*)lf[149]+1),t2,t3,((C_word*)t0)[2]);}

/* a8998 in k8989 in a8986 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8999,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 681  variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[289]))(3,*((C_word*)lf[289]+1),t4,t2);}

/* k9004 in a8998 in k8989 in a8986 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9006,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_assq(lf[162],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[4];
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[236]))(4,*((C_word*)lf[236]+1),t3,t4,lf[288]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k9140 in k9004 in a8998 in k8989 in a8986 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9142,2,t0,t1);}
if(C_truep(C_i_structurep(t1,lf[198]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_i_assq(lf[160],((C_word*)t0)[6]);
t3=C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_9030(t5,t3);}
else{
t5=C_i_cdr(t2);
t6=C_eqp(lf[156],t5);
t7=t4;
f_9030(t7,C_i_not(t6));}}}

/* k9028 in k9140 in k9004 in a8998 in k8989 in a8986 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_9030(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9030,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_assq(lf[187],((C_word*)t0)[7]))){
t2=C_i_cdr(((C_word*)t0)[6]);
t3=C_slot(t2,C_fix(2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9109,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 690  get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t4,((C_word*)t0)[2],((C_word*)t0)[4],lf[194]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9107 in k9028 in k9140 in k9004 in a8998 in k8989 in a8986 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9109,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9064,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[5];
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[236]))(4,*((C_word*)lf[236]+1),t2,t3,lf[287]);}}

/* k9062 in k9107 in k9028 in k9140 in k9004 in a8998 in k8989 in a8986 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9067,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_eqp(t1,lf[284]);
if(C_truep(t3)){
t4=t2;
f_9067(t4,C_SCHEME_TRUE);}
else{
t4=C_eqp(t1,lf[285]);
if(C_truep(t4)){
t5=t2;
f_9067(t5,C_SCHEME_FALSE);}
else{
t5=C_i_cadddr(((C_word*)t0)[2]);
t6=C_retrieve(lf[286]);
t7=t2;
f_9067(t7,C_fixnum_lessp(t5,t6));}}}

/* k9065 in k9062 in k9107 in k9028 in k9140 in k9004 in a8998 in k8989 in a8986 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_9067(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9067,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9074,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9085,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 697  node->sexpr */
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9083 in k9065 in k9062 in k9107 in k9028 in k9140 in k9004 in a8998 in k8989 in a8986 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9085,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* support.scm: 697  pp */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),((C_word*)t0)[2],t2);}

/* k9072 in k9065 in k9062 in k9107 in k9028 in k9140 in k9004 in a8998 in k8989 in a8986 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_9074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 698  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* k8992 in k8989 in a8986 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 700  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[278]+1)))(3,*((C_word*)lf[278]+1),((C_word*)t0)[2],lf[282]);}

/* k8958 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* support.scm: 702  debugging */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t2,lf[280],lf[281]);}
else{
t3=t2;
f_8966(2,t3,C_SCHEME_FALSE);}}

/* k8964 in k8958 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8966,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8971,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8979,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 703  sort-symbols */
((C_proc3)C_retrieve_proc(*((C_word*)lf[78]+1)))(3,*((C_word*)lf[78]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k8977 in k8964 in k8958 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8970 in k8964 in k8958 in ##compiler#emit-global-inline-file in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8971(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8971,3,t0,t1,t2);}
t3=*((C_word*)lf[278]+1);
/* g21252126 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,lf[279],t2);}

/* ##compiler#sexpr->node in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8888,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8894,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_8894(t6,t1,t2);}

/* walk in ##compiler#sexpr->node in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8894(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8894,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=C_i_cadr(t2);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8915,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_i_cddr(t2);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8921,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t12,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_8921(t14,t9,t10);}

/* loop2044 in walk in ##compiler#sexpr->node in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8921(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8921,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8950,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g20602061 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_8894(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8948 in loop2044 in walk in ##compiler#sexpr->node in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8950,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop20442057 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8921(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop20442057 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8921(t6,((C_word*)t0)[3],t5);}}

/* k8913 in walk in ##compiler#sexpr->node in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8915,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[198],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* ##compiler#node->sexpr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8802(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8802,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8808,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_8808(t6,t1,t2);}

/* walk in ##compiler#node->sexpr in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8808(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8808,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t2;
t6=C_slot(t5,C_fix(2));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8838,a[2]=t4,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8842,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t13=t2;
t14=C_slot(t13,C_fix(3));
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8853,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t16,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t18=((C_word*)t16)[1];
f_8853(t18,t12,t14);}

/* loop2008 in walk in ##compiler#node->sexpr in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8853(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8853,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8882,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g20242025 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_8808(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8880 in loop2008 in walk in ##compiler#node->sexpr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8882,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop20082021 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8853(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop20082021 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8853(t6,((C_word*)t0)[3],t5);}}

/* k8840 in walk in ##compiler#node->sexpr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8836 in walk in ##compiler#node->sexpr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8838,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* ##compiler#copy-node! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8763,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8767,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=C_slot(t5,C_fix(1));
t7=t3;
t8=C_i_check_structure(t7,lf[198]);
/* ##sys#block-set! */
t9=*((C_word*)lf[200]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t4,t7,C_fix(1),t6);}

/* k8765 in ##compiler#copy-node! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=C_slot(t3,C_fix(2));
t5=((C_word*)t0)[3];
t6=C_i_check_structure(t5,lf[198]);
/* ##sys#block-set! */
t7=*((C_word*)lf[200]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,t5,C_fix(2),t4);}

/* k8768 in k8765 in ##compiler#copy-node! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8773,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=C_slot(t3,C_fix(3));
t5=((C_word*)t0)[3];
t6=C_i_check_structure(t5,lf[198]);
/* ##sys#block-set! */
t7=*((C_word*)lf[200]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,t5,C_fix(3),t4);}

/* k8771 in k8768 in k8765 in ##compiler#copy-node! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#tree-copy in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8729,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8735,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_8735(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8735(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8735,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8749,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* support.scm: 654  rec */
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8747 in rec in ##compiler#tree-copy in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8753,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 654  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8735(t4,t2,t3);}

/* k8751 in k8747 in rec in ##compiler#tree-copy in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8753,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8330(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[16],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8330,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8334,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8680,a[2]=t7,a[3]=t12,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_8680(t14,t10,t3,t4);}

/* loop1785 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8680(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8680,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[271]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8713,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g18051806 */
t10=t6;
((C_proc4)C_retrieve_proc(t10))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8711 in loop1785 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8713,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8693,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_8693(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_8693(t5,t4);}}

/* k8691 in k8711 in loop1785 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8693(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop17851799 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8680(t5,((C_word*)t0)[2],t3,t4);}

/* k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8334,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8342,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
/* support.scm: 649  walk */
t5=((C_word*)t3)[1];
f_8342(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8342(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8342,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t2;
t9=C_slot(t8,C_fix(1));
t10=C_eqp(t9,lf[82]);
if(C_truep(t10)){
t11=t1;
t12=t11;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_a_i_record(&a,4,lf[198],t9,t7,C_SCHEME_END_OF_LIST));}
else{
t11=C_eqp(t9,lf[208]);
if(C_truep(t11)){
t12=C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8393,a[2]=t12,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8403,a[2]=t12,a[3]=((C_word*)t0)[3],a[4]=t13,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 617  get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t14,((C_word*)t0)[3],t12,lf[178]);}
else{
t12=C_eqp(t9,lf[226]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8440,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t14=C_i_car(t7);
t15=t3;
/* support.scm: 607  alist-ref */
((C_proc6)C_retrieve_symbol_proc(lf[267]))(6,*((C_word*)lf[267]+1),t13,t14,t15,*((C_word*)lf[268]+1),t14);}
else{
t13=C_eqp(t9,lf[92]);
if(C_truep(t13)){
t14=C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8456,a[2]=t3,a[3]=t14,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t16=C_i_car(t5);
/* support.scm: 626  walk */
t29=t15;
t30=t16;
t31=t3;
t1=t29;
t2=t30;
t3=t31;
goto loop;}
else{
t14=C_eqp(t9,lf[221]);
if(C_truep(t14)){
t15=C_i_caddr(t7);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8505,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 633  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[108]))(4,*((C_word*)lf[108]+1),t1,t15,t16);}
else{
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8665,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 648  tree-copy */
((C_proc3)C_retrieve_symbol_proc(lf[273]))(3,*((C_word*)lf[273]+1),t15,t7);}}}}}}

/* k8663 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8669,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8671,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[269]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8670 in k8663 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8671(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8671,3,t0,t1,t2);}
/* g19681969 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8342(t3,t1,t2,((C_word*)t0)[2]);}

/* k8667 in k8663 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8669,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[198],((C_word*)t0)[2],t3,t1));}

/* a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8505,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8509,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8612,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_8612(t13,t9,t2);}

/* loop1864 in a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8612(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8612,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8639,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8649,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g18801881 */
t6=t3;
f_8639(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8647 in loop1864 in a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8649,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop18641877 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8612(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop18641877 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8612(t6,((C_word*)t0)[3],t5);}}

/* g1880 in loop1864 in a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8639(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8639,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8643,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 637  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t3,t2);}

/* k8641 in g1880 in loop1864 in a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8646,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 638  put! */
((C_proc6)C_retrieve_symbol_proc(lf[137]))(6,*((C_word*)lf[137]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[272],C_SCHEME_TRUE);}

/* k8644 in k8641 in g1880 in loop1864 in a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k8507 in a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8512,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8561,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8563,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_8563(t11,t7,((C_word*)t0)[2],t1);}

/* loop1891 in k8507 in a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8563(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8563,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[271]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8596,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g19111912 */
t10=t6;
((C_proc4)C_retrieve_proc(t10))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8594 in loop1891 in k8507 in a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8596,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8576,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_8576(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_8576(t5,t4);}}

/* k8574 in k8594 in loop1891 in k8507 in a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8576(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop18911905 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8563(t5,((C_word*)t0)[2],t3,t4);}

/* k8559 in k8507 in a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 641  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8510 in k8507 in a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* support.scm: 644  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t2,lf[270]);}

/* k8536 in k8510 in k8507 in a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8538,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8546,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8554,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=((C_word*)t0)[2];
t6=((C_word*)t0)[6];
/* support.scm: 607  alist-ref */
((C_proc6)C_retrieve_symbol_proc(lf[267]))(6,*((C_word*)lf[267]+1),t4,t5,t6,*((C_word*)lf[268]+1),t5);}
else{
/* support.scm: 645  build-lambda-list */
((C_proc5)C_retrieve_proc(*((C_word*)lf[48]+1)))(5,*((C_word*)lf[48]+1),t3,((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* k8552 in k8536 in k8510 in k8507 in a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 645  build-lambda-list */
((C_proc5)C_retrieve_proc(*((C_word*)lf[48]+1)))(5,*((C_word*)lf[48]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8544 in k8536 in k8510 in k8507 in a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8546,2,t0,t1);}
t2=C_i_cadddr(((C_word*)t0)[8]);
t3=C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8528,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8530,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[269]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a8529 in k8544 in k8536 in k8510 in k8507 in a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8530(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8530,3,t0,t1,t2);}
/* g19421943 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8342(t3,t1,t2,((C_word*)t0)[2]);}

/* k8526 in k8544 in k8536 in k8510 in k8507 in a8504 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8528,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[198],lf[221],((C_word*)t0)[2],t1));}

/* k8454 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 627  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t2,((C_word*)t0)[3]);}

/* k8457 in k8454 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8462,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 628  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8460 in k8457 in k8454 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8462,2,t0,t1);}
t2=C_a_i_list(&a,1,((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8482,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=C_i_cadr(((C_word*)t0)[3]);
/* support.scm: 631  walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_8342(t5,t3,t4,t1);}

/* k8480 in k8460 in k8457 in k8454 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8482,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[198],lf[92],((C_word*)t0)[2],t2));}

/* k8438 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8440,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8432,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(((C_word*)t0)[4]);
/* support.scm: 623  walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8342(t5,t3,t4,((C_word*)t0)[2]);}

/* k8430 in k8438 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8432,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[198],lf[226],((C_word*)t0)[2],t2));}

/* k8401 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 618  put! */
((C_proc6)C_retrieve_symbol_proc(lf[137]))(6,*((C_word*)lf[137]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[178],C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[4];
f_8393(2,t2,C_SCHEME_UNDEFINED);}}

/* k8391 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8400,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
/* support.scm: 607  alist-ref */
((C_proc6)C_retrieve_symbol_proc(lf[267]))(6,*((C_word*)lf[267]+1),t2,((C_word*)t0)[2],t3,*((C_word*)lf[268]+1),((C_word*)t0)[2]);}

/* k8398 in k8391 in walk in k8332 in ##compiler#copy-node-tree-and-rename in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8400,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_a_i_list(&a,1,t1);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[198],lf[208],t3,C_SCHEME_END_OF_LIST));}

/* ##compiler#inline-lambda-bindings in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_8182,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8188,a[2]=t6,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 584  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[108]))(4,*((C_word*)lf[108]+1),t1,t2,t7);}

/* a8187 in ##compiler#inline-lambda-bindings in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8188,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8194,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8200,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a8199 in a8187 in ##compiler#inline-lambda-bindings in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8200,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8295,a[2]=t6,a[3]=t10,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_8295(t12,t4,((C_word*)t0)[3]);}
else{
t5=t4;
f_8204(2,t5,((C_word*)t0)[3]);}}

/* loop1737 in a8199 in a8187 in ##compiler#inline-lambda-bindings in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8295(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8295,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[93]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8324,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g17531754 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8322 in loop1737 in a8199 in a8187 in ##compiler#inline-lambda-bindings in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8324,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop17371750 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8295(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop17371750 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8295(t6,((C_word*)t0)[3],t5);}}

/* k8202 in a8199 in a8187 in ##compiler#inline-lambda-bindings in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8207,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* support.scm: 590  copy-node-tree-and-rename */
((C_proc6)C_retrieve_symbol_proc(lf[266]))(6,*((C_word*)lf[266]+1),t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t3=t2;
f_8207(2,t3,((C_word*)t0)[4]);}}

/* k8205 in k8202 in a8199 in a8187 in ##compiler#inline-lambda-bindings in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8212,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8233,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8287,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 596  last */
((C_proc3)C_retrieve_symbol_proc(lf[247]))(3,*((C_word*)lf[247]+1),t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_8233(t4,t1);}}

/* k8285 in k8205 in k8202 in a8199 in a8187 in ##compiler#inline-lambda-bindings in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8287,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
if(C_truep(C_i_nullp(((C_word*)t0)[4]))){
t3=C_a_i_list(&a,1,C_SCHEME_END_OF_LIST);
t4=C_a_i_record(&a,4,lf[198],lf[82],t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_list(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
f_8233(t6,C_a_i_record(&a,4,lf[198],lf[92],t2,t5));}
else{
t3=C_i_length(((C_word*)t0)[4]);
t4=C_fixnum_times(C_fix(3),t3);
t5=C_a_i_list(&a,2,lf[265],t4);
t6=((C_word*)t0)[4];
t7=C_a_i_record(&a,4,lf[198],lf[231],t5,t6);
t8=C_a_i_list(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
f_8233(t9,C_a_i_record(&a,4,lf[198],lf[92],t2,t8));}}

/* k8231 in k8205 in k8202 in a8199 in a8187 in ##compiler#inline-lambda-bindings in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8233(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8233,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8237,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 602  take */
((C_proc4)C_retrieve_symbol_proc(lf[264]))(4,*((C_word*)lf[264]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8235 in k8231 in k8205 in k8202 in a8199 in a8187 in ##compiler#inline-lambda-bindings in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 592  fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[263]))(6,*((C_word*)lf[263]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a8211 in k8205 in k8202 in a8199 in a8187 in ##compiler#inline-lambda-bindings in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8212,5,t0,t1,t2,t3,t4);}
t5=C_a_i_list(&a,1,t2);
t6=C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record(&a,4,lf[198],lf[92],t5,t6));}

/* a8193 in a8187 in ##compiler#inline-lambda-bindings in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8194,2,t0,t1);}
/* support.scm: 587  split-at */
((C_proc4)C_retrieve_symbol_proc(lf[262]))(4,*((C_word*)lf[262]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8128,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8134,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_8134(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8134(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8134,NULL,3,t0,t1,t2);}
t3=C_i_cddr(t2);
if(C_truep(C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8160,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_i_car(t2);
t6=C_i_cadr(t2);
/* support.scm: 580  proc */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k8158 in fold in ##compiler#fold-boolean in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8164,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 581  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8134(t4,t2,t3);}

/* k8162 in k8158 in fold in ##compiler#fold-boolean in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8164,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[198],lf[223],lf[260],t2));}

/* ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7447,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7453,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7453(t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7453(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7453,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t2;
t6=C_slot(t5,C_fix(2));
t7=t2;
t8=C_slot(t7,C_fix(1));
t9=C_eqp(t8,lf[213]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7487,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t8,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_7487(t11,t9);}
else{
t11=C_eqp(t8,lf[257]);
t12=t10;
f_7487(t12,(C_truep(t11)?t11:C_eqp(t8,lf[258])));}}

/* k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7487(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7487,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7494,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7496,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t8,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_7496(t10,t6,((C_word*)t0)[3]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[246]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7546,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7550,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7552,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t10,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_7552(t12,t8,((C_word*)t0)[3]);}
else{
t3=C_eqp(((C_word*)t0)[5],lf[208]);
t4=(C_truep(t3)?t3:C_eqp(((C_word*)t0)[5],lf[212]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_car(((C_word*)t0)[2]));}
else{
t5=C_eqp(((C_word*)t0)[5],lf[82]);
if(C_truep(t5)){
t6=C_i_car(((C_word*)t0)[2]);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[82],t7));}
else{
t6=C_eqp(((C_word*)t0)[5],lf[92]);
if(C_truep(t6)){
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7647,a[2]=((C_word*)t0)[2],a[3]=t11,a[4]=t8,a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7700,a[2]=t16,a[3]=((C_word*)t0)[4],a[4]=t13,a[5]=t15,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 552  butlast */
((C_proc3)C_retrieve_symbol_proc(lf[249]))(3,*((C_word*)lf[249]+1),t17,((C_word*)t0)[3]);}
else{
t7=C_eqp(((C_word*)t0)[5],lf[221]);
if(C_truep(t7)){
t8=C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[116]:lf[221]);
t10=C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7756,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=C_i_car(((C_word*)t0)[3]);
/* support.scm: 559  walk */
t13=((C_word*)((C_word*)t0)[4])[1];
f_7453(t13,t11,t12);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[233]);
if(C_truep(t8)){
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7774,a[2]=((C_word*)t0)[4],a[3]=t10,a[4]=t14,a[5]=t12,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_7774(t16,((C_word*)t0)[6],((C_word*)t0)[3]);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[224]);
if(C_truep(t9)){
t10=C_i_car(((C_word*)t0)[2]);
t11=C_SCHEME_END_OF_LIST;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7824,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7826,a[2]=((C_word*)t0)[4],a[3]=t12,a[4]=t17,a[5]=t14,tmp=(C_word)a,a+=6,tmp));
t19=((C_word*)t17)[1];
f_7826(t19,t15,((C_word*)t0)[3]);}
else{
t10=C_eqp(((C_word*)t0)[5],lf[214]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=C_eqp(((C_word*)t0)[5],lf[251]);
if(C_truep(t11)){
t12=C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7883,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_7883(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=C_eqp(((C_word*)t0)[5],lf[252]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7945,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_7945(t14,t12);}
else{
t14=C_eqp(((C_word*)t0)[5],lf[254]);
if(C_truep(t14)){
t15=t13;
f_7945(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[5],lf[255]);
t16=t13;
f_7945(t16,(C_truep(t15)?t15:C_eqp(((C_word*)t0)[5],lf[256])));}}}}}}}}}}}}}

/* k7943 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7945(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7945,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* support.scm: 569  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7453(t4,t2,t3);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[231]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[5],lf[253]));
if(C_truep(t3)){
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8015,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8017,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t10,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8017(t12,t8,((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8057,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8061,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8063,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t11,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_8063(t13,t9,((C_word*)t0)[3]);}}}

/* loop1687 in k7943 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8063(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8063,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8092,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g17031704 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7453(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8090 in loop1687 in k7943 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8092,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop16871700 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8063(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop16871700 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8063(t6,((C_word*)t0)[3],t5);}}

/* k8059 in k7943 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 572  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8055 in k7943 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8057,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop1664 in k7943 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_8017(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8017,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8046,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g16801681 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7453(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8044 in loop1664 in k7943 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8046,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop16641677 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8017(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop16641677 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8017(t6,((C_word*)t0)[3],t5);}}

/* k8013 in k7943 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_8015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 571  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[250]))(5,*((C_word*)lf[250]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7950 in k7943 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7952,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7956,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=C_i_cdr(((C_word*)t0)[3]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7962,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t9,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_7962(t11,t6,t7);}

/* loop1636 in k7950 in k7943 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7962(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7962,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7991,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g16521653 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7453(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7989 in loop1636 in k7950 in k7943 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7991,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop16361649 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7962(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop16361649 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7962(t6,((C_word*)t0)[3],t5);}}

/* k7954 in k7950 in k7943 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 569  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[250]))(6,*((C_word*)lf[250]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7883(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7883,NULL,5,t0,t1,t2,t3,t4);}
t5=C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7901,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 566  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[76]+1)))(3,*((C_word*)lf[76]+1),t6,t4);}
else{
t6=C_fixnum_difference(t2,C_fix(1));
t7=C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7932,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=C_i_car(t3);
/* support.scm: 567  walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_7453(t10,t8,t9);}}

/* k7930 in loop in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7932,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* support.scm: 567  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7883(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7899 in loop in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7909,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* support.scm: 566  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7453(t4,t2,t3);}

/* k7907 in k7899 in loop in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7909,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[251],t3));}

/* loop1589 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7826(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7826,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7855,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g16051606 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7453(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7853 in loop1589 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7855,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop15891602 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7826(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop15891602 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7826(t6,((C_word*)t0)[3],t5);}}

/* k7822 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 561  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[250]))(5,*((C_word*)lf[250]+1),((C_word*)t0)[3],lf[224],((C_word*)t0)[2],t1);}

/* loop1566 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7774(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7774,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7803,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g15821583 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7453(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7801 in loop1566 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7803,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop15661579 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7774(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop15661579 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7774(t6,((C_word*)t0)[3],t5);}}

/* k7754 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7756,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k7698 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7700,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7702,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7702(t5,((C_word*)t0)[2],t1);}

/* loop1543 in k7698 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7702(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7702,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7731,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g15591560 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7453(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7729 in loop1543 in k7698 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7731,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop15431556 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7702(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop15431556 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7702(t6,((C_word*)t0)[3],t5);}}

/* k7645 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7647,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7649,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7649(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop1516 in k7645 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7649(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7649,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[248]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7682,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g15361537 */
t10=t6;
((C_proc4)C_retrieve_proc(t10))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k7680 in loop1516 in k7645 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7682,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7662,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_7662(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_7662(t5,t4);}}

/* k7660 in k7680 in loop1516 in k7645 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7662(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop15161530 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7649(t5,((C_word*)t0)[2],t3,t4);}

/* k7629 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7639,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7643,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 553  last */
((C_proc3)C_retrieve_symbol_proc(lf[247]))(3,*((C_word*)lf[247]+1),t3,((C_word*)t0)[2]);}

/* k7641 in k7629 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 553  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7453(t2,((C_word*)t0)[2],t1);}

/* k7637 in k7629 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7639,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[92],t3));}

/* loop1480 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7552(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7552,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7581,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g14961497 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7453(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7579 in loop1480 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7581,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14801493 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7552(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14801493 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7552(t6,((C_word*)t0)[3],t5);}}

/* k7548 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7544 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7546,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[246],t2));}

/* loop1453 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7496(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7496,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7525,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g14691470 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7453(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7523 in loop1453 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7525,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14531466 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7496(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14531466 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7496(t6,((C_word*)t0)[3],t5);}}

/* k7492 in k7485 in walk in ##compiler#build-expression-tree in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7494,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6524,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6527,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7442,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 536  walk */
t9=((C_word*)t6)[1];
f_6527(t9,t8,t2);}

/* k7440 in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7445,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 537  debugging */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),t2,lf[243],lf[244],((C_word*)((C_word*)t0)[2])[1]);}

/* k7443 in k7440 in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_6527(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word *a;
loop:
a=C_alloc(20);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6527,NULL,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=t1;
t4=t2;
t5=C_a_i_list(&a,1,t4);
t6=t3;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record(&a,4,lf[198],lf[208],t5,C_SCHEME_END_OF_LIST));}
else{
if(C_truep(C_i_not_pair_p(t2))){
/* support.scm: 470  bomb */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t1,lf[211],t2);}
else{
t3=C_i_car(t2);
if(C_truep(C_i_symbolp(t3))){
t4=C_i_car(t2);
t5=C_eqp(t4,lf[212]);
if(C_truep(t5)){
t6=C_i_cadr(t2);
t7=C_a_i_list(&a,1,t6);
t8=t1;
t9=t8;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_record(&a,4,lf[198],lf[212],t7,C_SCHEME_END_OF_LIST));}
else{
t6=C_eqp(t4,lf[213]);
t7=(C_truep(t6)?t6:C_eqp(t4,lf[214]));
if(C_truep(t7)){
t8=C_i_car(t2);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6602,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t14=C_i_cdr(t2);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6608,a[2]=((C_word*)t0)[3],a[3]=t10,a[4]=t16,a[5]=t12,tmp=(C_word)a,a+=6,tmp));
t18=((C_word*)t16)[1];
f_6608(t18,t13,t14);}
else{
t8=C_eqp(t4,lf[82]);
if(C_truep(t8)){
t9=C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6660,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_numberp(t9))){
t11=C_eqp(lf[218],C_retrieve(lf[219]));
if(C_truep(t11)){
t12=C_i_integerp(t9);
t13=t10;
f_6660(t13,C_i_not(t12));}
else{
t12=t10;
f_6660(t12,C_SCHEME_FALSE);}}
else{
t11=t10;
f_6660(t11,C_SCHEME_FALSE);}}
else{
t9=C_eqp(t4,lf[92]);
if(C_truep(t9)){
t10=C_i_cadr(t2);
t11=C_i_caddr(t2);
if(C_truep(C_i_nullp(t10))){
/* support.scm: 490  walk */
t99=t1;
t100=t11;
t1=t99;
t2=t100;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6719,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm: 491  unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[220]))(3,*((C_word*)lf[220]+1),t12,t10);}}
else{
t10=C_eqp(t4,lf[116]);
t11=(C_truep(t10)?t10:C_eqp(t4,lf[221]));
if(C_truep(t11)){
t12=C_i_cadr(t2);
t13=C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6812,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t15=C_i_caddr(t2);
/* support.scm: 495  walk */
t99=t14;
t100=t15;
t1=t99;
t2=t100;
goto loop;}
else{
t12=C_eqp(t4,lf[222]);
if(C_truep(t12)){
t13=C_i_cadr(t2);
t14=C_i_car(t2);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6845,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t14,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t13))){
t16=C_i_car(t13);
t17=C_eqp(lf[82],t16);
if(C_truep(t17)){
t18=C_i_cadr(t13);
t19=t15;
f_6845(t19,C_a_i_list(&a,1,t18));}
else{
t18=t15;
f_6845(t18,C_a_i_list(&a,1,t13));}}
else{
t16=t15;
f_6845(t16,C_a_i_list(&a,1,t13));}}
else{
t13=C_eqp(t4,lf[223]);
t14=(C_truep(t13)?t13:C_eqp(t4,lf[224]));
if(C_truep(t14)){
t15=C_i_car(t2);
t16=C_i_cadr(t2);
t17=C_a_i_list(&a,1,t16);
t18=C_SCHEME_END_OF_LIST;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6937,a[2]=t17,a[3]=t15,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t23=C_i_cddr(t2);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6943,a[2]=((C_word*)t0)[3],a[3]=t19,a[4]=t25,a[5]=t21,tmp=(C_word)a,a+=6,tmp));
t27=((C_word*)t25)[1];
f_6943(t27,t22,t23);}
else{
t15=C_eqp(t4,lf[225]);
if(C_truep(t15)){
t16=C_i_cadr(t2);
t17=C_a_i_list(&a,2,t16,C_SCHEME_TRUE);
t18=t1;
t19=t18;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,C_a_i_record(&a,4,lf[198],lf[225],t17,C_SCHEME_END_OF_LIST));}
else{
t16=C_eqp(t4,lf[226]);
t17=(C_truep(t16)?t16:C_eqp(t4,lf[227]));
if(C_truep(t17)){
t18=C_i_cadr(t2);
t19=C_a_i_list(&a,1,t18);
t20=C_SCHEME_END_OF_LIST;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_FALSE;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7027,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t25=C_i_cddr(t2);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7033,a[2]=((C_word*)t0)[3],a[3]=t21,a[4]=t27,a[5]=t23,tmp=(C_word)a,a+=6,tmp));
t29=((C_word*)t27)[1];
f_7033(t29,t24,t25);}
else{
t18=C_eqp(t4,lf[228]);
if(C_truep(t18)){
t19=C_i_cadr(t2);
t20=C_i_cadr(t19);
t21=C_i_caddr(t2);
t22=C_i_cadr(t21);
t23=C_i_cadddr(t2);
t24=C_i_cadr(t23);
t25=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7119,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t24,a[6]=t22,a[7]=t20,tmp=(C_word)a,a+=8,tmp);
/* support.scm: 514  fifth */
((C_proc3)C_retrieve_symbol_proc(lf[230]))(3,*((C_word*)lf[230]+1),t25,t2);}
else{
t19=C_eqp(t4,lf[231]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7140,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_7140(t21,t19);}
else{
t21=C_eqp(t4,lf[238]);
if(C_truep(t21)){
t22=t20;
f_7140(t22,t21);}
else{
t22=C_eqp(t4,lf[239]);
if(C_truep(t22)){
t23=t20;
f_7140(t23,t22);}
else{
t23=C_eqp(t4,lf[240]);
t24=t20;
f_7140(t24,(C_truep(t23)?t23:C_eqp(t4,lf[241])));}}}}}}}}}}}}}}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7400,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7402,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t10,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_7402(t12,t8,t2);}}}}

/* loop1396 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7402(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7402,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7431,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g14121413 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6527(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7429 in loop1396 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7431,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13961409 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7402(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13961409 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7402(t6,((C_word*)t0)[3],t5);}}

/* k7398 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7400,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[198],lf[233],lf[242],t1));}

/* k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7140(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7140,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[6]);
t3=C_i_cadr(((C_word*)t0)[6]);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7160,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=C_i_cddr(((C_word*)t0)[6]);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7166,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t11,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_7166(t13,t8,t9);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[232]);
if(C_truep(t2)){
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7217,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t8=C_i_cdr(((C_word*)t0)[6]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7223,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t10,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_7223(t12,t7,t8);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7261,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a7266 in k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7267,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7323,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7351,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=t2;
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[236]))(4,*((C_word*)lf[236]+1),t5,t6,lf[237]);}

/* k7349 in a7266 in k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_7323(t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
f_7323(t2,C_SCHEME_FALSE);}}

/* k7321 in a7266 in k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7323(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7323,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7327,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7330,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 530  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),t3,((C_word*)t0)[2]);}
else{
/* support.scm: 533  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[235]))(3,*((C_word*)lf[235]+1),t2,((C_word*)t0)[2]);}}

/* k7328 in k7321 in a7266 in k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7337,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t1;
t4=((C_word*)t0)[4];
f_7327(2,t4,C_a_i_list(&a,2,((C_word*)t0)[3],t3));}
else{
/* support.scm: 532  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[235]))(3,*((C_word*)lf[235]+1),t2,((C_word*)t0)[2]);}}

/* k7335 in k7328 in k7321 in a7266 in k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7337,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7327(2,t2,C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k7325 in k7321 in a7266 in k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7327,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7284,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7286,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t9,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_7286(t11,t7,((C_word*)t0)[2]);}

/* loop1368 in k7325 in k7321 in a7266 in k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7286(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7286,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7315,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g13841385 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6527(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7313 in loop1368 in k7325 in k7321 in a7266 in k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7315,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13681381 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7286(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13681381 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7286(t6,((C_word*)t0)[3],t5);}}

/* k7282 in k7325 in k7321 in a7266 in k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7284,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[198],lf[233],((C_word*)t0)[2],t1));}

/* a7260 in k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7261,2,t0,t1);}
/* support.scm: 522  get-line-2 */
((C_proc3)C_retrieve_symbol_proc(lf[144]))(3,*((C_word*)lf[144]+1),t1,((C_word*)t0)[2]);}

/* loop1319 in k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7223(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7223,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7252,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g13351336 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6527(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7250 in loop1319 in k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7252,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13191332 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7223(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13191332 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7223(t6,((C_word*)t0)[3],t5);}}

/* k7215 in k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7217,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[198],lf[233],lf[234],t1));}

/* loop1291 in k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7166(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7166,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7195,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g13071308 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6527(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7193 in loop1291 in k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7195,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12911304 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7166(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12911304 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7166(t6,((C_word*)t0)[3],t5);}}

/* k7158 in k7138 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7160,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[198],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k7117 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7119,2,t0,t1);}
t2=C_i_cadr(t1);
t3=C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7099,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7103,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 515  sixth */
((C_proc3)C_retrieve_symbol_proc(lf[229]))(3,*((C_word*)lf[229]+1),t5,((C_word*)t0)[2]);}

/* k7101 in k7117 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 515  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6527(t2,((C_word*)t0)[2],t1);}

/* k7097 in k7117 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7099,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[198],lf[228],((C_word*)t0)[2],t2));}

/* loop1237 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_7033(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7033,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7062,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g12531254 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6527(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7060 in loop1237 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7062,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12371250 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7033(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12371250 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7033(t6,((C_word*)t0)[3],t5);}}

/* k7025 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_7027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7027,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[198],lf[226],((C_word*)t0)[2],t1));}

/* loop1199 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_6943(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6943,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6972,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g12151216 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6527(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6970 in loop1199 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6972,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop11991212 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6943(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop11991212 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6943(t6,((C_word*)t0)[3],t5);}}

/* k6935 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6937,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[198],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6843 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_6845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6845,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6849,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=C_i_cddr(((C_word*)t0)[3]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6855,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t9,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_6855(t11,t6,t7);}

/* loop1166 in k6843 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_6855(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6855,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6884,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g11821183 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6527(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6882 in loop1166 in k6843 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6884,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop11661179 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6855(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop11661179 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6855(t6,((C_word*)t0)[3],t5);}}

/* k6847 in k6843 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6849,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[198],((C_word*)t0)[2],t3,t1));}

/* k6810 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6812,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[198],lf[116],((C_word*)t0)[2],t2));}

/* k6717 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6723,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6727,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=C_i_cadr(((C_word*)t0)[2]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6741,a[2]=t4,a[3]=t10,a[4]=t6,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_6741(t12,t7,t8);}

/* loop1124 in k6717 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_6741(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6741,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6768,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6779,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g11401141 */
t6=t3;
f_6768(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6777 in loop1124 in k6717 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6779,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop11241137 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6741(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop11241137 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6741(t6,((C_word*)t0)[3],t5);}}

/* g1140 in loop1124 in k6717 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_6768(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6768,NULL,3,t0,t1,t2);}
t3=C_i_cadr(t2);
/* support.scm: 492  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6527(t4,t1,t3);}

/* k6725 in k6717 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6735,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 493  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6527(t3,t2,((C_word*)t0)[2]);}

/* k6733 in k6725 in k6717 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6735,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* support.scm: 492  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6721 in k6717 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6723,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[198],lf[92],t3,t1));}

/* k6658 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_6660(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6660,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 481  compiler-warning */
((C_proc5)C_retrieve_proc(*((C_word*)lf[19]+1)))(5,*((C_word*)lf[19]+1),t2,lf[216],lf[217],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
t3=C_a_i_list(&a,1,((C_word*)t0)[2]);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[198],lf[82],t3,C_SCHEME_END_OF_LIST));}}

/* k6661 in k6658 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6670,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 484  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[215]+1)))(3,*((C_word*)lf[215]+1),t2,((C_word*)t0)[2]);}

/* k6668 in k6661 in k6658 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6670,2,t0,t1);}
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
t4=C_a_i_list(&a,1,t2);
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record(&a,4,lf[198],lf[82],t4,C_SCHEME_END_OF_LIST));}

/* loop1088 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_6608(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6608,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6637,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g11041105 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6527(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6635 in loop1088 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6637,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10881101 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6608(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10881101 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6608(t6,((C_word*)t0)[3],t5);}}

/* k6600 in walk in ##compiler#build-node-graph in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6602,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[198],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1));}

/* ##compiler#qnode in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6509,3,t0,t1,t2);}
t3=C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[198],lf[82],t3,C_SCHEME_END_OF_LIST));}

/* ##compiler#varnode in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6494(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6494,3,t0,t1,t2);}
t3=C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[198],lf[208],t3,C_SCHEME_END_OF_LIST));}

/* make-node in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6488,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record(&a,4,lf[198],t2,t3,t4));}

/* node-subexpressions in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6479(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6479,3,t0,t1,t2);}
t3=C_i_check_structure(t2,lf[198]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(3)));}

/* node-subexpressions-set! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6470(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6470,4,t0,t1,t2,t3);}
t4=C_i_check_structure(t2,lf[198]);
/* ##sys#block-set! */
t5=*((C_word*)lf[200]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-parameters in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6461,3,t0,t1,t2);}
t3=C_i_check_structure(t2,lf[198]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(2)));}

/* node-parameters-set! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6452,4,t0,t1,t2,t3);}
t4=C_i_check_structure(t2,lf[198]);
/* ##sys#block-set! */
t5=*((C_word*)lf[200]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-class in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6443,3,t0,t1,t2);}
t3=C_i_check_structure(t2,lf[198]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(1)));}

/* node-class-set! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6434(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6434,4,t0,t1,t2,t3);}
t4=C_i_check_structure(t2,lf[198]);
/* ##sys#block-set! */
t5=*((C_word*)lf[200]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node? in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6428(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6428,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[198]));}

/* ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5929(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5929,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5933,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_5933(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6426,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 400  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[54]+1)))(5,*((C_word*)lf[54]+1),t4,C_retrieve(lf[195]),C_retrieve(lf[196]),C_retrieve(lf[126]));}}

/* k6424 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5933(t3,t2);}

/* k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_5933(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5933,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5938,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 403  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[149]))(4,*((C_word*)lf[149]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5938(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5938,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t14=C_SCHEME_UNDEFINED;
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}
else{
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5948,a[2]=t3,a[3]=t9,a[4]=t7,a[5]=t5,a[6]=t13,a[7]=t11,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* support.scm: 411  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t14,t2);}}

/* k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5951,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6111,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_6111(t6,t2,((C_word*)t0)[2]);}

/* loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_6111(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6111,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* support.scm: 415  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[159]+1)))(3,*((C_word*)lf[159]+1),t3,t2);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6119 in loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6124,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=C_eqp(t1,lf[157]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_6137(t5,t3);}
else{
t5=C_eqp(t1,lf[175]);
if(C_truep(t5)){
t6=t4;
f_6137(t6,t5);}
else{
t6=C_eqp(t1,lf[176]);
if(C_truep(t6)){
t7=t4;
f_6137(t7,t6);}
else{
t7=C_eqp(t1,lf[177]);
if(C_truep(t7)){
t8=t4;
f_6137(t8,t7);}
else{
t8=C_eqp(t1,lf[178]);
if(C_truep(t8)){
t9=t4;
f_6137(t9,t8);}
else{
t9=C_eqp(t1,lf[179]);
if(C_truep(t9)){
t10=t4;
f_6137(t10,t9);}
else{
t10=C_eqp(t1,lf[180]);
if(C_truep(t10)){
t11=t4;
f_6137(t11,t10);}
else{
t11=C_eqp(t1,lf[181]);
if(C_truep(t11)){
t12=t4;
f_6137(t12,t11);}
else{
t12=C_eqp(t1,lf[182]);
if(C_truep(t12)){
t13=t4;
f_6137(t13,t12);}
else{
t13=C_eqp(t1,lf[183]);
if(C_truep(t13)){
t14=t4;
f_6137(t14,t13);}
else{
t14=C_eqp(t1,lf[184]);
if(C_truep(t14)){
t15=t4;
f_6137(t15,t14);}
else{
t15=C_eqp(t1,lf[185]);
if(C_truep(t15)){
t16=t4;
f_6137(t16,t15);}
else{
t16=C_eqp(t1,lf[186]);
if(C_truep(t16)){
t17=t4;
f_6137(t17,t16);}
else{
t17=C_eqp(t1,lf[187]);
if(C_truep(t17)){
t18=t4;
f_6137(t18,t17);}
else{
t18=C_eqp(t1,lf[188]);
if(C_truep(t18)){
t19=t4;
f_6137(t19,t18);}
else{
t19=C_eqp(t1,lf[189]);
if(C_truep(t19)){
t20=t4;
f_6137(t20,t19);}
else{
t20=C_eqp(t1,lf[190]);
if(C_truep(t20)){
t21=t4;
f_6137(t21,t20);}
else{
t21=C_eqp(t1,lf[191]);
if(C_truep(t21)){
t22=t4;
f_6137(t22,t21);}
else{
t22=C_eqp(t1,lf[192]);
if(C_truep(t22)){
t23=t4;
f_6137(t23,t22);}
else{
t23=C_eqp(t1,lf[193]);
t24=t4;
f_6137(t24,(C_truep(t23)?t23:C_eqp(t1,lf[194])));}}}}}}}}}}}}}}}}}}}}

/* k6135 in k6119 in loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_6137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6137,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6140,a[2]=((C_word*)t0)[10],a[3]=t2,a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(9),t2);}
else{
t2=C_eqp(((C_word*)t0)[9],lf[156]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,lf[156]);
t4=C_i_cdr(((C_word*)t0)[10]);
/* support.scm: 436  loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_6111(t5,((C_word*)t0)[6],t4);}
else{
t3=C_eqp(((C_word*)t0)[9],lf[160]);
if(C_truep(t3)){
t4=C_eqp(((C_word*)((C_word*)t0)[8])[1],lf[156]);
if(C_truep(t4)){
t5=C_i_cdr(((C_word*)t0)[10]);
/* support.scm: 436  loop */
t6=((C_word*)((C_word*)t0)[7])[1];
f_6111(t6,((C_word*)t0)[6],t5);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6178,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 423  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[161]+1)))(3,*((C_word*)lf[161]+1),t5,((C_word*)t0)[10]);}}
else{
t4=C_eqp(((C_word*)t0)[9],lf[162]);
if(C_truep(t4)){
t5=C_eqp(((C_word*)((C_word*)t0)[8])[1],lf[156]);
if(C_truep(t5)){
t6=C_i_cdr(((C_word*)t0)[10]);
/* support.scm: 436  loop */
t7=((C_word*)((C_word*)t0)[7])[1];
f_6111(t7,((C_word*)t0)[6],t6);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6194,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 425  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[161]+1)))(3,*((C_word*)lf[161]+1),t6,((C_word*)t0)[10]);}}
else{
t5=C_eqp(((C_word*)t0)[9],lf[163]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6204,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 427  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[161]+1)))(3,*((C_word*)lf[161]+1),t6,((C_word*)t0)[10]);}
else{
t6=C_eqp(((C_word*)t0)[9],lf[164]);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t6)){
t8=t7;
f_6213(t8,t6);}
else{
t8=C_eqp(((C_word*)t0)[9],lf[168]);
if(C_truep(t8)){
t9=t7;
f_6213(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[9],lf[169]);
if(C_truep(t9)){
t10=t7;
f_6213(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[9],lf[146]);
if(C_truep(t10)){
t11=t7;
f_6213(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[9],lf[170]);
if(C_truep(t11)){
t12=t7;
f_6213(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[9],lf[171]);
if(C_truep(t12)){
t13=t7;
f_6213(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[9],lf[172]);
if(C_truep(t13)){
t14=t7;
f_6213(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[9],lf[173]);
t15=t7;
f_6213(t15,(C_truep(t14)?t14:C_eqp(((C_word*)t0)[9],lf[174])));}}}}}}}}}}}}}

/* k6211 in k6135 in k6119 in loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_6213(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6213,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6216,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(9),t2);}
else{
t2=C_eqp(((C_word*)t0)[6],lf[165]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 432  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[161]+1)))(3,*((C_word*)lf[161]+1),t3,((C_word*)t0)[7]);}
else{
t3=C_eqp(((C_word*)t0)[6],lf[166]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6253,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* support.scm: 434  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[161]+1)))(3,*((C_word*)lf[161]+1),t4,((C_word*)t0)[7]);}
else{
t4=C_i_car(((C_word*)t0)[7]);
/* support.scm: 435  bomb */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),((C_word*)t0)[8],lf[167],t4);}}}}

/* k6251 in k6211 in k6135 in k6119 in loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 436  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6111(t4,((C_word*)t0)[2],t3);}

/* k6241 in k6211 in k6135 in k6119 in loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 436  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6111(t4,((C_word*)t0)[2],t3);}

/* k6214 in k6211 in k6135 in k6119 in loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6219,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6233,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 430  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[159]+1)))(3,*((C_word*)lf[159]+1),t3,((C_word*)t0)[2]);}

/* k6231 in k6214 in k6211 in k6135 in k6119 in loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6217 in k6214 in k6211 in k6135 in k6119 in loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(61),((C_word*)t0)[3]);}

/* k6220 in k6217 in k6214 in k6211 in k6135 in k6119 in loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6229,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 430  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[161]+1)))(3,*((C_word*)lf[161]+1),t2,((C_word*)t0)[2]);}

/* k6227 in k6220 in k6217 in k6214 in k6211 in k6135 in k6119 in loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6202 in k6135 in k6119 in loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 436  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6111(t4,((C_word*)t0)[2],t3);}

/* k6192 in k6135 in k6119 in loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 436  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6111(t4,((C_word*)t0)[2],t3);}

/* k6176 in k6135 in k6119 in loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 436  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6111(t4,((C_word*)t0)[2],t3);}

/* k6138 in k6135 in k6119 in loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6155,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 419  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[159]+1)))(3,*((C_word*)lf[159]+1),t2,((C_word*)t0)[2]);}

/* k6153 in k6138 in k6135 in k6119 in loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_assq(t1,lf[158]);
t3=C_i_cdr(t2);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k6122 in k6119 in loop in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 436  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6111(t3,((C_word*)t0)[2],t2);}

/* k5949 in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5954,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[156]);
t5=t3;
f_5992(t5,C_i_not(t4));}
else{
t4=t3;
f_5992(t4,C_SCHEME_FALSE);}}

/* k5990 in k5949 in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_5992(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5992,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5995,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[153],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6026,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[156]);
t4=t2;
f_6026(t4,C_i_not(t3));}
else{
t3=t2;
f_6026(t3,C_SCHEME_FALSE);}}}

/* k6024 in k5990 in k5949 in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_6026(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6026,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6029,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[154],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6060,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[156]);
t4=t2;
f_6060(t4,C_i_not(t3));}
else{
t3=t2;
f_6060(t3,C_SCHEME_FALSE);}}}

/* k6058 in k6024 in k5990 in k5949 in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_6060(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6060,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6063,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[155],t2);}
else{
t2=((C_word*)t0)[2];
f_5954(2,t2,C_SCHEME_UNDEFINED);}}

/* k6061 in k6058 in k6024 in k5990 in k5949 in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6063,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=C_slot(t4,C_fix(2));
t6=C_a_i_cons(&a,2,t3,t5);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t6,((C_word*)t0)[2]);}

/* k6027 in k6024 in k5990 in k5949 in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_6029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6029,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=C_slot(t4,C_fix(2));
t6=C_a_i_cons(&a,2,t3,t5);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t6,((C_word*)t0)[2]);}

/* k5993 in k5990 in k5949 in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5995,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=C_slot(t4,C_fix(2));
t6=C_a_i_cons(&a,2,t3,t5);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t6,((C_word*)t0)[2]);}

/* k5952 in k5949 in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5957,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5982,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t4,lf[152],t3);}
else{
t3=t2;
f_5957(2,t3,C_SCHEME_UNDEFINED);}}

/* k5980 in k5952 in k5949 in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_length(((C_word*)((C_word*)t0)[4])[1]);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5955 in k5952 in k5949 in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5960,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5969,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t4,lf[151],t3);}
else{
/* support.scm: 445  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[3]);}}

/* k5967 in k5955 in k5952 in k5949 in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_length(((C_word*)((C_word*)t0)[4])[1]);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5958 in k5955 in k5952 in k5949 in k5946 in a5937 in k5931 in ##compiler#display-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 445  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5872,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 381  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[149]))(4,*((C_word*)lf[149]+1),t1,t2,C_retrieve(lf[143]));}

/* a5871 in ##compiler#display-line-number-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5872(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5872,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=*((C_word*)lf[11]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5879,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t5,t2,t4);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5877 in a5871 in ##compiler#display-line-number-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k5880 in k5877 in a5871 in ##compiler#display-line-number-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5885,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5892,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5894,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_5894(t11,t7,((C_word*)t0)[2]);}

/* loop738 in k5880 in k5877 in a5871 in ##compiler#display-line-number-database in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_5894(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5894,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[148]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5923,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g754755 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5921 in loop738 in k5880 in k5877 in a5871 in ##compiler#display-line-number-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5923,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop738751 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5894(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop738751 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5894(t6,((C_word*)t0)[3],t5);}}

/* k5890 in k5880 in k5877 in a5871 in ##compiler#display-line-number-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5883 in k5880 in k5877 in a5871 in ##compiler#display-line-number-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##compiler#find-lambda-container in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5842,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5848,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5848(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_5848(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5848,NULL,3,t0,t1,t2);}
t3=C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5858,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 377  get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t4,((C_word*)t0)[2],t2,lf[146]);}}

/* k5856 in loop in ##compiler#find-lambda-container in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 378  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5848(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5801(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5801,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5808,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 369  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[143]),t3);}

/* k5806 in ##compiler#get-line-2 in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5811,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=C_i_cdr(t1);
t4=t2;
f_5811(t4,C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_5811(t3,C_SCHEME_FALSE);}}

/* k5809 in k5806 in ##compiler#get-line-2 in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_5811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5811,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5815,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* g710711 */
t3=t2;
f_5815(t3,((C_word*)t0)[3],t1);}
else{
/* support.scm: 372  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* g710 in k5809 in k5806 in ##compiler#get-line-2 in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_5815(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5815,NULL,3,t0,t1,t2);}
t3=C_i_car(((C_word*)t0)[2]);
t4=C_i_cdr(t2);
/* support.scm: 371  values */
C_values(4,0,t1,t3,t4);}

/* ##compiler#get-line in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5791(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5791,3,t0,t1,t2);}
t3=C_i_car(t2);
/* support.scm: 365  get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t1,C_retrieve(lf[143]),t3,t2);}

/* ##compiler#get-list in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5782,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5786,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 358  get */
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t5,t2,t3,t4);}

/* k5784 in ##compiler#get-list in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* ##compiler#count! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_5725r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5725r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5725r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5729,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 349  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t6,t2,t3);}

/* k5727 in ##compiler#count! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5729,2,t0,t1);}
t2=C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=C_slot(t4,C_fix(1));
t6=C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5759,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=C_slot(t1,C_fix(1));
/* support.scm: 354  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=C_a_i_list(&a,1,t4);
/* support.scm: 355  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k5757 in k5727 in ##compiler#count! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5673,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5677,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 341  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t6,t2,t3);}

/* k5675 in ##compiler#collect! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5677,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=C_slot(t2,C_fix(1));
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5704,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=C_slot(t1,C_fix(1));
/* support.scm: 345  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=C_a_i_list(&a,1,t2);
/* support.scm: 346  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k5702 in k5675 in ##compiler#collect! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5627(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5627,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5631,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 333  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t6,t2,t3);}

/* k5629 in ##compiler#put! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5631,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5653,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=C_slot(t1,C_fix(1));
/* support.scm: 337  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=C_a_i_list(&a,1,t2);
/* support.scm: 338  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k5651 in k5629 in ##compiler#put! in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_5609r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5609r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5609r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5613,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 327  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t5,t2,t3);}

/* k5611 in ##compiler#get-all in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5613,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5621,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 329  filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a5620 in k5611 in ##compiler#get-all in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5621(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5621,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5591(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5591,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5595,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 321  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t5,t2,t3);}

/* k5593 in ##compiler#get in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5342,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5346,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5500,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5500(t7,t3,C_retrieve(lf[132]));}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* loop495 in ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_5500(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5500,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5578,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5539,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=C_a_i_list(&a,1,lf[131]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5514,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t6))){
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t5,t4,lf[124],C_SCHEME_TRUE);}
else{
t8=C_i_cdr(t6);
if(C_truep(C_i_nullp(t8))){
t9=C_i_car(t6);
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t5,t4,lf[124],t9);}
else{
/* ##sys#error */
t9=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,lf[0],t6);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5512 in loop495 in ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[124],t1);}

/* k5537 in loop495 in ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5539,2,t0,t1);}
if(C_truep(C_i_memq(((C_word*)t0)[6],C_retrieve(lf[127])))){
t2=C_a_i_list(&a,1,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5550,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t2))){
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[5],((C_word*)t0)[6],lf[128],C_SCHEME_TRUE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=C_i_car(t2);
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[5],((C_word*)t0)[6],lf[128],t5);}
else{
/* ##sys#error */
t5=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}
else{
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5500(t3,((C_word*)t0)[2],t2);}}

/* k5548 in k5537 in loop495 in ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[128],t1);}

/* k5576 in loop495 in ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5500(t3,((C_word*)t0)[2],t2);}

/* k5344 in ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5349,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5409,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5409(t6,t2,C_retrieve(lf[130]));}

/* loop545 in k5344 in ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_5409(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5409,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5487,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5448,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=C_a_i_list(&a,1,lf[129]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5423,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t6))){
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t5,t4,lf[124],C_SCHEME_TRUE);}
else{
t8=C_i_cdr(t6);
if(C_truep(C_i_nullp(t8))){
t9=C_i_car(t6);
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t5,t4,lf[124],t9);}
else{
/* ##sys#error */
t9=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,lf[0],t6);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5421 in loop545 in k5344 in ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[124],t1);}

/* k5446 in loop545 in k5344 in ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5448,2,t0,t1);}
if(C_truep(C_i_memq(((C_word*)t0)[6],C_retrieve(lf[127])))){
t2=C_a_i_list(&a,1,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5459,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t2))){
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[5],((C_word*)t0)[6],lf[128],C_SCHEME_TRUE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=C_i_car(t2);
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[5],((C_word*)t0)[6],lf[128],t5);}
else{
/* ##sys#error */
t5=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}
else{
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5409(t3,((C_word*)t0)[2],t2);}}

/* k5457 in k5446 in loop545 in k5344 in ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[128],t1);}

/* k5485 in loop545 in k5344 in ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5409(t3,((C_word*)t0)[2],t2);}

/* k5347 in k5344 in ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5349,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5354,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5354(t5,((C_word*)t0)[2],C_retrieve(lf[126]));}

/* loop594 in k5347 in k5344 in ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_fcall f_5354(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5354,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5396,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_list(&a,1,lf[122]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5368,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t5))){
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t3,t4,lf[124],C_SCHEME_TRUE);}
else{
t7=C_i_cdr(t5);
if(C_truep(C_i_nullp(t7))){
t8=C_i_car(t5);
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t3,t4,lf[124],t8);}
else{
/* ##sys#error */
t8=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5366 in loop594 in k5347 in k5344 in ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[124],t1);}

/* k5394 in loop594 in k5347 in k5344 in ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5354(t3,((C_word*)t0)[2],t2);}

/* k5340 in ##compiler#initialize-analysis-database in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#expand-profile-lambda in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5197,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[112]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5201,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm: 281  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[93]))(2,*((C_word*)lf[93]+1),t6);}

/* k5199 in ##compiler#expand-profile-lambda in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5205,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm: 282  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[113]));}

/* k5203 in k5199 in ##compiler#expand-profile-lambda in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5205,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1 /* (set! ##compiler#profile-lambda-list ...) */,t1);
t3=C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[112]+1 /* (set! ##compiler#profile-lambda-index ...) */,t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[82],t5);
t7=C_a_i_cons(&a,2,C_retrieve(lf[114]),C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,lf[115],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t10);
t12=C_a_i_cons(&a,2,lf[116],t11);
t13=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t14=C_a_i_cons(&a,2,((C_word*)t0)[4],t13);
t15=C_a_i_cons(&a,2,lf[116],t14);
t16=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t17=C_a_i_cons(&a,2,t15,t16);
t18=C_a_i_cons(&a,2,lf[117],t17);
t19=C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t19);
t21=C_a_i_cons(&a,2,lf[116],t20);
t22=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t23=C_a_i_cons(&a,2,lf[82],t22);
t24=C_a_i_cons(&a,2,C_retrieve(lf[114]),C_SCHEME_END_OF_LIST);
t25=C_a_i_cons(&a,2,t23,t24);
t26=C_a_i_cons(&a,2,lf[118],t25);
t27=C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t27);
t29=C_a_i_cons(&a,2,lf[116],t28);
t30=C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=C_a_i_cons(&a,2,t21,t30);
t32=C_a_i_cons(&a,2,t12,t31);
t33=C_a_i_cons(&a,2,lf[119],t32);
t34=C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=C_a_i_cons(&a,2,((C_word*)t0)[3],t34);
t36=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t36+1)))(2,t36,C_a_i_cons(&a,2,lf[116],t35));}

/* ##compiler#llist-length in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5194(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5194,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_length(t2));}

/* ##compiler#string->expr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5087,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5091,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[107]+1)))(3,*((C_word*)lf[107]+1),t3,t4);}

/* a5095 in ##compiler#string->expr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5096(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5096,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5102,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5127,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t1,t3,t4);}

/* a5126 in a5095 in ##compiler#string->expr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5133,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5181,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a5180 in a5126 in a5095 in ##compiler#string->expr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5181(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_5181r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5181r(t0,t1,t2);}}

static void C_ccall f_5181r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5187,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k456461 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a5186 in a5180 in a5126 in a5095 in ##compiler#string->expr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5187,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a5132 in a5126 in a5095 in ##compiler#string->expr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5137,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5165,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 264  with-input-from-string */
((C_proc4)C_retrieve_symbol_proc(lf[105]))(4,*((C_word*)lf[105]+1),t2,((C_word*)t0)[2],t3);}

/* a5164 in a5132 in a5126 in a5095 in ##compiler#string->expr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5171,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5179,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 266  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[101]+1)))(2,*((C_word*)lf[101]+1),t3);}

/* k5177 in a5164 in a5132 in a5126 in a5095 in ##compiler#string->expr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 266  unfold */
((C_proc6)C_retrieve_symbol_proc(lf[102]))(6,*((C_word*)lf[102]+1),((C_word*)t0)[3],*((C_word*)lf[103]+1),*((C_word*)lf[104]+1),((C_word*)t0)[2],t1);}

/* a5170 in a5164 in a5132 in a5126 in a5095 in ##compiler#string->expr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5171(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5171,3,t0,t1,t2);}
/* support.scm: 266  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[101]+1)))(2,*((C_word*)lf[101]+1),t1);}

/* k5135 in a5132 in a5126 in a5095 in ##compiler#string->expr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5137,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[98]);}
else{
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_car(t1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5159,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t4=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_END_OF_LIST);}}}

/* k5157 in k5135 in a5132 in a5126 in a5095 in ##compiler#string->expr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5159,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[99],t1));}

/* a5101 in a5095 in ##compiler#string->expr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5102(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5102,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5108,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* k456461 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a5107 in a5101 in a5095 in ##compiler#string->expr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5116,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5119,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 261  exn? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k5117 in a5107 in a5101 in a5095 in ##compiler#string->expr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm: 262  exn-msg */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* support.scm: 263  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5114 in a5107 in a5101 in a5095 in ##compiler#string->expr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 259  quit */
((C_proc5)C_retrieve_proc(*((C_word*)lf[24]+1)))(5,*((C_word*)lf[24]+1),((C_word*)t0)[3],lf[97],((C_word*)t0)[2],t1);}

/* k5089 in ##compiler#string->expr in k5084 in k5081 in k4019 in k4016 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g459460 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#canonicalize-begin-body in k4019 in k4016 */
static void C_ccall f_4986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4986,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4992,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4992(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k4019 in k4016 */
static void C_fcall f_4992(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4992,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[90]);}
else{
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_car(t2));}
else{
t4=C_i_car(t2);
t5=C_i_equalp(t4,lf[91]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5020,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_5020(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5069,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 248  constant? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[81]+1)))(3,*((C_word*)lf[81]+1),t7,t4);}}}}

/* k5067 in loop in ##compiler#canonicalize-begin-body in k4019 in k4016 */
static void C_ccall f_5069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_5020(t3,t2);}
else{
t2=((C_word*)t0)[3];
f_5020(t2,C_i_equalp(((C_word*)t0)[2],lf[95]));}}

/* k5018 in loop in ##compiler#canonicalize-begin-body in k4019 in k4016 */
static void C_fcall f_5020(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5020,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 250  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4992(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5058,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 251  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t2,lf[94]);}}

/* k5056 in k5018 in loop in ##compiler#canonicalize-begin-body in k4019 in k4016 */
static void C_ccall f_5058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5058,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[4]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5046,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cdr(((C_word*)t0)[4]);
/* support.scm: 252  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4992(t8,t6,t7);}

/* k5044 in k5056 in k5018 in loop in ##compiler#canonicalize-begin-body in k4019 in k4016 */
static void C_ccall f_5046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5046,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[92],t3));}

/* ##compiler#basic-literal? in k4019 in k4016 */
static void C_ccall f_4926(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4926,3,t0,t1,t2);}
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4942,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 233  constant? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[81]+1)))(3,*((C_word*)lf[81]+1),t5,t2);}}}

/* k4940 in ##compiler#basic-literal? in k4019 in k4016 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4942,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4984,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 234  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[88]+1)))(3,*((C_word*)lf[88]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4948(2,t3,C_SCHEME_FALSE);}}}

/* k4982 in k4940 in ##compiler#basic-literal? in k4019 in k4016 */
static void C_ccall f_4984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 234  every */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[2],*((C_word*)lf[86]+1),t1);}

/* k4946 in k4940 in ##compiler#basic-literal? in k4019 in k4016 */
static void C_ccall f_4948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4948,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* support.scm: 236  basic-literal? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[86]+1)))(3,*((C_word*)lf[86]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k4961 in k4946 in k4940 in ##compiler#basic-literal? in k4019 in k4016 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 237  basic-literal? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[86]+1)))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k4019 in k4016 */
static void C_ccall f_4880(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4880,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4884,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4924,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 223  big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),t4,t2);}
else{
t4=t3;
f_4884(t4,C_SCHEME_FALSE);}}

/* k4922 in ##compiler#immediate? in k4019 in k4016 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4884(t2,C_i_not(t1));}

/* k4882 in ##compiler#immediate? in k4019 in k4016 */
static void C_fcall f_4884(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k4019 in k4016 */
static void C_ccall f_4850(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4850,3,t0,t1,t2);}
t3=C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k4019 in k4016 */
static void C_ccall f_4804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4804,3,t0,t1,t2);}
t3=C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep(C_i_pairp(t2))){
t8=C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_eqp(lf[82],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#sort-symbols in k4019 in k4016 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4784,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4790,tmp=(C_word)a,a+=2,tmp);
/* support.scm: 202  sort */
((C_proc4)C_retrieve_symbol_proc(lf[80]))(4,*((C_word*)lf[80]+1),t1,t2,t3);}

/* a4789 in ##compiler#sort-symbols in k4019 in k4016 */
static void C_ccall f_4790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4790,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4798,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 202  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t4,t2);}

/* k4796 in a4789 in ##compiler#sort-symbols in k4019 in k4016 */
static void C_ccall f_4798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4802,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm: 202  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}

/* k4800 in k4796 in a4789 in ##compiler#sort-symbols in k4019 in k4016 */
static void C_ccall f_4802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 202  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[79]+1)))(4,*((C_word*)lf[79]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#follow-without-loop in k4019 in k4016 */
static void C_ccall f_4753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4753,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4759,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4759(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k4019 in k4016 */
static void C_fcall f_4759(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4759,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_member(t2,t3))){
/* support.scm: 198  abort */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4774,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 199  proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a4773 in loop in ##compiler#follow-without-loop in k4019 in k4016 */
static void C_ccall f_4774(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4774,3,t0,t1,t2);}
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* support.scm: 199  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4759(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k4019 in k4016 */
static void C_ccall f_4690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4690,4,t0,t1,t2,t3);}
t4=C_i_cdr(t3);
if(C_truep(C_i_nullp(t4))){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4704,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 188  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[76]+1)))(3,*((C_word*)lf[76]+1),t5,t3);}}

/* k4702 in ##compiler#fold-inner in k4019 in k4016 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4704,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4706,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4706(t5,((C_word*)t0)[2],t1);}

/* fold in k4702 in ##compiler#fold-inner in k4019 in k4016 */
static void C_fcall f_4706(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4706,NULL,3,t0,t1,t2);}
t3=C_i_cddr(t2);
if(C_truep(C_i_nullp(t3))){
t4=C_i_cadr(t2);
t5=C_i_car(t2);
t6=C_a_i_list(&a,2,t4,t5);
C_apply(4,0,t1,((C_word*)t0)[3],t6);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4735,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_i_cdr(t2);
/* support.scm: 193  fold */
t10=t4;
t11=t5;
t1=t10;
t2=t11;
goto loop;}}

/* k4733 in fold in k4702 in ##compiler#fold-inner in k4019 in k4016 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4735,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[4]);
t3=C_a_i_list(&a,2,t1,t2);
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* ##compiler#close-checked-input-file in k4019 in k4016 */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4678,4,t0,t1,t2,t3);}
if(C_truep(C_i_string_equal_p(t3,lf[73]))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* support.scm: 183  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[74]+1)))(3,*((C_word*)lf[74]+1),t1,t2);}}

/* ##compiler#check-and-open-input-file in k4019 in k4016 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4631r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4631r(t0,t1,t2,t3);}}

static void C_ccall f_4631r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep(C_i_string_equal_p(t2,lf[66]))){
/* support.scm: 177  current-input-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[67]+1)))(2,*((C_word*)lf[67]+1),t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4647,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 178  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[71]))(3,*((C_word*)lf[71]+1),t4,t2);}}

/* k4645 in ##compiler#check-and-open-input-file in k4019 in k4016 */
static void C_ccall f_4647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4647,2,t0,t1);}
if(C_truep(t1)){
/* support.scm: 178  open-input-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[68]+1)))(3,*((C_word*)lf[68]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=C_i_nullp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_4659(t4,t2);}
else{
t4=C_i_car(((C_word*)t0)[2]);
t5=t3;
f_4659(t5,C_i_not(t4));}}}

/* k4657 in k4645 in ##compiler#check-and-open-input-file in k4019 in k4016 */
static void C_fcall f_4659(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm: 179  quit */
((C_proc4)C_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),((C_word*)t0)[4],lf[69],((C_word*)t0)[3]);}
else{
t2=C_i_car(((C_word*)t0)[2]);
/* support.scm: 180  quit */
((C_proc5)C_retrieve_proc(*((C_word*)lf[24]+1)))(5,*((C_word*)lf[24]+1),((C_word*)t0)[4],lf[70],t2,((C_word*)t0)[3]);}}

/* ##compiler#words->bytes in k4019 in k4016 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4624,3,t0,t1,t2);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub273(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k4019 in k4016 */
static void C_ccall f_4617(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4617,3,t0,t1,t2);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub269(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k4019 in k4016 */
static void C_ccall f_4561(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4561,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4565,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4615,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 158  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t4,t2);}

/* k4613 in ##compiler#valid-c-identifier? in k4019 in k4016 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[56]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4563 in ##compiler#valid-c-identifier? in k4019 in k4016 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4565,2,t0,t1);}
if(C_truep(C_i_pairp(t1))){
t2=C_i_car(t1);
t3=C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4588,tmp=(C_word)a,a+=2,tmp);
t6=C_i_cdr(t1);
/* support.scm: 162  any */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4587 in k4563 in ##compiler#valid-c-identifier? in k4019 in k4016 */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4588,3,t0,t1,t2);}
t3=C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k4019 in k4016 */
static void C_ccall f_4467(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4467,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4479,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4483,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=C_retrieve(lf[56]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4481 in ##compiler#c-ify-string in k4019 in k4016 */
static void C_ccall f_4483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4483,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4485,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4485(t5,((C_word*)t0)[2],t1);}

/* loop in k4481 in ##compiler#c-ify-string in k4019 in k4016 */
static void C_fcall f_4485(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4485,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[53]);}
else{
t3=C_i_car(t2);
t4=C_fix(C_character_code(t3));
t5=C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4507,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_4507(t7,t5);}
else{
t7=C_fixnum_greater_or_equal_p(t4,C_fix(127));
t8=t6;
f_4507(t8,(C_truep(t7)?t7:C_i_memq(t3,lf[59])));}}}

/* k4505 in loop in k4481 in ##compiler#c-ify-string in k4019 in k4016 */
static void C_fcall f_4507(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4507,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4514,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_4514(t3,lf[57]);}
else{
t3=C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_4514(t4,(C_truep(t3)?lf[58]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[5]);
/* support.scm: 155  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4485(t4,t2,t3);}}

/* k4544 in k4505 in loop in k4481 in ##compiler#c-ify-string in k4019 in k4016 */
static void C_ccall f_4546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4546,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4512 in k4505 in loop in k4481 in ##compiler#c-ify-string in k4019 in k4016 */
static void C_fcall f_4514(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4514,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4518,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4530,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm: 153  number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k4528 in k4512 in k4505 in loop in k4481 in ##compiler#c-ify-string in k4019 in k4016 */
static void C_ccall f_4530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[56]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4516 in k4512 in k4505 in loop in k4481 in ##compiler#c-ify-string in k4019 in k4016 */
static void C_ccall f_4518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4522,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 154  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4485(t4,t2,t3);}

/* k4520 in k4516 in k4512 in k4505 in loop in k4481 in ##compiler#c-ify-string in k4019 in k4016 */
static void C_ccall f_4522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 149  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[54]+1)))(6,*((C_word*)lf[54]+1),((C_word*)t0)[4],lf[55],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4477 in ##compiler#c-ify-string in k4019 in k4016 */
static void C_ccall f_4479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4479,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=C_retrieve(lf[52]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k4019 in k4016 */
static void C_ccall f_4423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4423,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4429,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4429(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k4019 in k4016 */
static void C_fcall f_4429(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4429,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4453,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=C_i_cdr(t2);
t9=C_fixnum_decrease(t3);
/* support.scm: 135  loop */
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k4451 in loop in ##compiler#build-lambda-list in k4019 in k4016 */
static void C_ccall f_4453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4453,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k4019 in k4016 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4392,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_stringp(t2))){
/* support.scm: 129  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4415,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[45]))(2,*((C_word*)lf[45]+1),t3);}}}

/* k4413 in ##compiler#symbolify in k4019 in k4016 */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4418,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],t1);}

/* k4416 in k4413 in ##compiler#symbolify in k4019 in k4016 */
static void C_ccall f_4418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4421,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[44]))(3,*((C_word*)lf[44]+1),t2,((C_word*)t0)[2]);}

/* k4419 in k4416 in k4413 in ##compiler#symbolify in k4019 in k4016 */
static void C_ccall f_4421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 130  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k4019 in k4016 */
static void C_ccall f_4365(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4365,3,t0,t1,t2);}
if(C_truep(C_i_stringp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_symbolp(t2))){
/* support.scm: 124  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4384,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[45]))(2,*((C_word*)lf[45]+1),t3);}}}

/* k4382 in ##compiler#stringify in k4019 in k4016 */
static void C_ccall f_4384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4387,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],t1);}

/* k4385 in k4382 in ##compiler#stringify in k4019 in k4016 */
static void C_ccall f_4387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[44]))(3,*((C_word*)lf[44]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#posq in k4019 in k4016 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4329,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4335,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4335(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq in k4019 in k4016 */
static C_word C_fcall f_4335(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep(C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=C_i_car(t1);
t4=C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=C_i_cdr(t1);
t6=C_fixnum_increase(t2);
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#check-signature in k4019 in k4016 */
static void C_ccall f_4261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4261,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4264,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4285,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4285(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k4019 in k4016 */
static void C_fcall f_4285(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4285,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm: 108  err */
t4=((C_word*)t0)[3];
f_4264(t4,t1);}}
else{
t4=C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep(C_i_nullp(t2))){
/* support.scm: 110  err */
t5=((C_word*)t0)[3];
f_4264(t5,t1);}
else{
t5=C_i_cdr(t2);
t6=C_i_cdr(t3);
/* support.scm: 111  loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature in k4019 in k4016 */
static void C_fcall f_4264(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4264,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4272,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 105  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),t2,((C_word*)t0)[2]);}

/* k4270 in err in ##compiler#check-signature in k4019 in k4016 */
static void C_ccall f_4272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4276,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* support.scm: 106  map-llist */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t2,C_retrieve(lf[40]),t3);}

/* k4274 in k4270 in err in ##compiler#check-signature in k4019 in k4016 */
static void C_ccall f_4276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 104  quit */
((C_proc5)C_retrieve_proc(*((C_word*)lf[24]+1)))(5,*((C_word*)lf[24]+1),((C_word*)t0)[3],lf[39],((C_word*)t0)[2],t1);}

/* map-llist in k4019 in k4016 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4218,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4224,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4224(t7,t1,t3);}

/* loop in map-llist in k4019 in k4016 */
static void C_fcall f_4224(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4224,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep(C_i_symbolp(t2))){
/* support.scm: 99   proc */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4247,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* support.scm: 100  proc */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k4245 in loop in map-llist in k4019 in k4016 */
static void C_ccall f_4247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4251,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* support.scm: 100  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4224(t4,t2,t3);}

/* k4249 in k4245 in loop in map-llist in k4019 in k4016 */
static void C_ccall f_4251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4251,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k4019 in k4016 */
static void C_ccall f_4215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4215,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_emit_syntax_trace_info(t2,t3,C_retrieve(lf[29])));}

/* ##sys#syntax-error-hook in k4019 in k4016 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4170r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4170r(t0,t1,t2,t3);}}

static void C_ccall f_4170r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4174,a[2]=t4,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 78   current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[22]))(2,*((C_word*)lf[22]+1),t6);}

/* k4172 in ##sys#syntax-error-hook in k4019 in k4016 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_symbolp(((C_word*)((C_word*)t0)[2])[1]))){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t2;
f_4177(t8,t3);}
else{
t3=t2;
f_4177(t3,C_SCHEME_FALSE);}}

/* k4175 in k4172 in ##sys#syntax-error-hook in k4019 in k4016 */
static void C_fcall f_4177(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4177,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4180,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
/* support.scm: 85   fprintf */
((C_proc6)C_retrieve_symbol_proc(lf[20]))(6,*((C_word*)lf[20]+1),t2,((C_word*)t0)[4],lf[33],t1,((C_word*)((C_word*)t0)[2])[1]);}
else{
/* support.scm: 86   fprintf */
((C_proc5)C_retrieve_symbol_proc(lf[20]))(5,*((C_word*)lf[20]+1),t2,((C_word*)t0)[4],lf[34],((C_word*)((C_word*)t0)[2])[1]);}}

/* k4178 in k4175 in k4172 in ##sys#syntax-error-hook in k4019 in k4016 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4191,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a4190 in k4178 in k4175 in k4172 in ##sys#syntax-error-hook in k4019 in k4016 */
static void C_ccall f_4191(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4191,3,t0,t1,t2);}
t3=C_retrieve(lf[20]);
/* g108109 */
t4=t3;
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],lf[31],t2);}

/* k4181 in k4178 in k4175 in k4172 in ##sys#syntax-error-hook in k4019 in k4016 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4186,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 88   print-call-chain */
((C_proc6)C_retrieve_symbol_proc(lf[28]))(6,*((C_word*)lf[28]+1),t2,((C_word*)t0)[2],C_fix(0),C_retrieve(lf[29]),lf[30]);}

/* k4184 in k4181 in k4178 in k4175 in k4172 in ##sys#syntax-error-hook in k4019 in k4016 */
static void C_ccall f_4186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 89   exit */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],C_fix(70));}

/* quit in k4019 in k4016 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4151r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4151r(t0,t1,t2,t3);}}

static void C_ccall f_4151r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4155,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 71   current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[22]))(2,*((C_word*)lf[22]+1),t4);}

/* k4153 in quit in k4019 in k4016 */
static void C_ccall f_4155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4158,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4168,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 72   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[26],((C_word*)t0)[2]);}

/* k4166 in k4153 in quit in k4019 in k4016 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[20]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4156 in k4153 in quit in k4019 in k4016 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4161,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 73   newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t2,((C_word*)t0)[2]);}

/* k4159 in k4156 in k4153 in quit in k4019 in k4016 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 74   exit */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],C_fix(1));}

/* ##compiler#compiler-warning in k4019 in k4016 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4122r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4122r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4122r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4129,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[23]))){
t6=C_i_memq(t2,*((C_word*)lf[4]+1));
t7=t5;
f_4129(t7,C_i_not(t6));}
else{
t6=t5;
f_4129(t6,C_SCHEME_FALSE);}}

/* k4127 in ##compiler#compiler-warning in k4019 in k4016 */
static void C_fcall f_4129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4129,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm: 66   current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[22]))(2,*((C_word*)lf[22]+1),t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4130 in k4127 in ##compiler#compiler-warning in k4019 in k4016 */
static void C_ccall f_4132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4135,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4142,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm: 67   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[21],((C_word*)t0)[2]);}

/* k4140 in k4130 in k4127 in ##compiler#compiler-warning in k4019 in k4016 */
static void C_ccall f_4142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[20]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4133 in k4130 in k4127 in ##compiler#compiler-warning in k4019 in k4016 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm: 68   newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging in k4019 in k4016 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_4057r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4057r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4057r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
if(C_truep(C_i_memq(t2,*((C_word*)lf[3]+1)))){
t5=*((C_word*)lf[11]+1);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4067,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t6,t3,t5);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k4065 in ##compiler#debugging in k4019 in k4016 */
static void C_ccall f_4067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4082,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 58   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),t3,lf[18]);}
else{
t3=t2;
f_4070(2,t3,C_SCHEME_UNDEFINED);}}

/* k4080 in k4065 in ##compiler#debugging in k4019 in k4016 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4082,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4087,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4087(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop49 in k4080 in k4065 in ##compiler#debugging in k4019 in k4016 */
static void C_fcall f_4087(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4087,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4109,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[11]+1);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4099,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4106,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm: 59   force */
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t7,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4104 in loop49 in k4080 in k4065 in ##compiler#debugging in k4019 in k4016 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4097 in loop49 in k4080 in k4065 in ##compiler#debugging in k4019 in k4016 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2]);}

/* k4107 in loop49 in k4080 in k4065 in ##compiler#debugging in k4019 in k4016 */
static void C_ccall f_4109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4087(t3,((C_word*)t0)[2],t2);}

/* k4068 in k4065 in ##compiler#debugging in k4019 in k4016 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4073,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 60   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),t2);}

/* k4071 in k4068 in k4065 in ##compiler#debugging in k4019 in k4016 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm: 61   flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),t2);}

/* k4074 in k4071 in k4068 in k4065 in ##compiler#debugging in k4019 in k4016 */
static void C_ccall f_4076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k4019 in k4016 */
static void C_ccall f_4030(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4030r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4030r(t0,t1,t2);}}

static void C_ccall f_4030r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4044,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(t2);
/* support.scm: 49   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[8],t4);}
else{
/* support.scm: 50   error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t1,lf[9]);}}

/* k4042 in ##compiler#bomb in k4019 in k4016 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[6]+1),t1,t2);}

/* ##compiler#compiler-cleanup-hook in k4019 in k4016 */
static void C_ccall f_4025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4025,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[674] = {
{"toplevel:support_scm",(void*)C_support_toplevel},
{"f_4018:support_scm",(void*)f_4018},
{"f_4021:support_scm",(void*)f_4021},
{"f_5083:support_scm",(void*)f_5083},
{"f_5086:support_scm",(void*)f_5086},
{"f_13422:support_scm",(void*)f_13422},
{"f_13426:support_scm",(void*)f_13426},
{"f_13516:support_scm",(void*)f_13516},
{"f_13432:support_scm",(void*)f_13432},
{"f_13503:support_scm",(void*)f_13503},
{"f_13506:support_scm",(void*)f_13506},
{"f_13509:support_scm",(void*)f_13509},
{"f_13438:support_scm",(void*)f_13438},
{"f_13445:support_scm",(void*)f_13445},
{"f_13447:support_scm",(void*)f_13447},
{"f_13471:support_scm",(void*)f_13471},
{"f_13467:support_scm",(void*)f_13467},
{"f_13489:support_scm",(void*)f_13489},
{"f_13411:support_scm",(void*)f_13411},
{"f_13400:support_scm",(void*)f_13400},
{"f_13394:support_scm",(void*)f_13394},
{"f_13366:support_scm",(void*)f_13366},
{"f_13370:support_scm",(void*)f_13370},
{"f_13345:support_scm",(void*)f_13345},
{"f_13349:support_scm",(void*)f_13349},
{"f_13312:support_scm",(void*)f_13312},
{"f_13318:support_scm",(void*)f_13318},
{"f_13279:support_scm",(void*)f_13279},
{"f_13285:support_scm",(void*)f_13285},
{"f_13255:support_scm",(void*)f_13255},
{"f_13186:support_scm",(void*)f_13186},
{"f_13190:support_scm",(void*)f_13190},
{"f_13195:support_scm",(void*)f_13195},
{"f_13199:support_scm",(void*)f_13199},
{"f_13250:support_scm",(void*)f_13250},
{"f_13229:support_scm",(void*)f_13229},
{"f_13241:support_scm",(void*)f_13241},
{"f_13244:support_scm",(void*)f_13244},
{"f_13217:support_scm",(void*)f_13217},
{"f_13153:support_scm",(void*)f_13153},
{"f_13163:support_scm",(void*)f_13163},
{"f_13166:support_scm",(void*)f_13166},
{"f_13147:support_scm",(void*)f_13147},
{"f_13102:support_scm",(void*)f_13102},
{"f_13109:support_scm",(void*)f_13109},
{"f_13124:support_scm",(void*)f_13124},
{"f_13128:support_scm",(void*)f_13128},
{"f_13120:support_scm",(void*)f_13120},
{"f_13106:support_scm",(void*)f_13106},
{"f_12979:support_scm",(void*)f_12979},
{"f_12988:support_scm",(void*)f_12988},
{"f_13016:support_scm",(void*)f_13016},
{"f_13022:support_scm",(void*)f_13022},
{"f_13025:support_scm",(void*)f_13025},
{"f_13028:support_scm",(void*)f_13028},
{"f_13031:support_scm",(void*)f_13031},
{"f_13034:support_scm",(void*)f_13034},
{"f_13037:support_scm",(void*)f_13037},
{"f_13096:support_scm",(void*)f_13096},
{"f_13040:support_scm",(void*)f_13040},
{"f_13055:support_scm",(void*)f_13055},
{"f_13058:support_scm",(void*)f_13058},
{"f_13066:support_scm",(void*)f_13066},
{"f_13076:support_scm",(void*)f_13076},
{"f_13079:support_scm",(void*)f_13079},
{"f_13061:support_scm",(void*)f_13061},
{"f_13046:support_scm",(void*)f_13046},
{"f_12983:support_scm",(void*)f_12983},
{"f_12976:support_scm",(void*)f_12976},
{"f_12958:support_scm",(void*)f_12958},
{"f_12924:support_scm",(void*)f_12924},
{"f_12948:support_scm",(void*)f_12948},
{"f_12944:support_scm",(void*)f_12944},
{"f_12903:support_scm",(void*)f_12903},
{"f_12909:support_scm",(void*)f_12909},
{"f_12913:support_scm",(void*)f_12913},
{"f_12916:support_scm",(void*)f_12916},
{"f_12919:support_scm",(void*)f_12919},
{"f_12891:support_scm",(void*)f_12891},
{"f_12895:support_scm",(void*)f_12895},
{"f_12800:support_scm",(void*)f_12800},
{"f_12819:support_scm",(void*)f_12819},
{"f_12844:support_scm",(void*)f_12844},
{"f_12848:support_scm",(void*)f_12848},
{"f_12850:support_scm",(void*)f_12850},
{"f_12857:support_scm",(void*)f_12857},
{"f_12870:support_scm",(void*)f_12870},
{"f_12873:support_scm",(void*)f_12873},
{"f_12876:support_scm",(void*)f_12876},
{"f_12879:support_scm",(void*)f_12879},
{"f_12882:support_scm",(void*)f_12882},
{"f_12886:support_scm",(void*)f_12886},
{"f_12803:support_scm",(void*)f_12803},
{"f_12807:support_scm",(void*)f_12807},
{"f_12813:support_scm",(void*)f_12813},
{"f_12794:support_scm",(void*)f_12794},
{"f_12735:support_scm",(void*)f_12735},
{"f_12743:support_scm",(void*)f_12743},
{"f_12770:support_scm",(void*)f_12770},
{"f_12746:support_scm",(void*)f_12746},
{"f_12749:support_scm",(void*)f_12749},
{"f_12766:support_scm",(void*)f_12766},
{"f_12752:support_scm",(void*)f_12752},
{"f_12762:support_scm",(void*)f_12762},
{"f_12755:support_scm",(void*)f_12755},
{"f_12758:support_scm",(void*)f_12758},
{"f_12726:support_scm",(void*)f_12726},
{"f_12720:support_scm",(void*)f_12720},
{"f_12714:support_scm",(void*)f_12714},
{"f_12702:support_scm",(void*)f_12702},
{"f_12706:support_scm",(void*)f_12706},
{"f_12709:support_scm",(void*)f_12709},
{"f_12664:support_scm",(void*)f_12664},
{"f_12668:support_scm",(void*)f_12668},
{"f14656:support_scm",(void*)f14656},
{"f_12671:support_scm",(void*)f_12671},
{"f_12678:support_scm",(void*)f_12678},
{"f_12622:support_scm",(void*)f_12622},
{"f_12631:support_scm",(void*)f_12631},
{"f_12593:support_scm",(void*)f_12593},
{"f_12603:support_scm",(void*)f_12603},
{"f_12384:support_scm",(void*)f_12384},
{"f_12588:support_scm",(void*)f_12588},
{"f_12553:support_scm",(void*)f_12553},
{"f_12559:support_scm",(void*)f_12559},
{"f_12574:support_scm",(void*)f_12574},
{"f_12567:support_scm",(void*)f_12567},
{"f_12387:support_scm",(void*)f_12387},
{"f_12421:support_scm",(void*)f_12421},
{"f_12515:support_scm",(void*)f_12515},
{"f_12527:support_scm",(void*)f_12527},
{"f_12485:support_scm",(void*)f_12485},
{"f_12496:support_scm",(void*)f_12496},
{"f_12476:support_scm",(void*)f_12476},
{"f_12440:support_scm",(void*)f_12440},
{"f_12446:support_scm",(void*)f_12446},
{"f_12450:support_scm",(void*)f_12450},
{"f_12245:support_scm",(void*)f_12245},
{"f_12251:support_scm",(void*)f_12251},
{"f_12344:support_scm",(void*)f_12344},
{"f_12349:support_scm",(void*)f_12349},
{"f_12359:support_scm",(void*)f_12359},
{"f_12312:support_scm",(void*)f_12312},
{"f_12283:support_scm",(void*)f_12283},
{"f_12288:support_scm",(void*)f_12288},
{"f_12298:support_scm",(void*)f_12298},
{"f_12249:support_scm",(void*)f_12249},
{"f_11876:support_scm",(void*)f_11876},
{"f_12075:support_scm",(void*)f_12075},
{"f_12167:support_scm",(void*)f_12167},
{"f_12078:support_scm",(void*)f_12078},
{"f_11555:support_scm",(void*)f_11555},
{"f_11870:support_scm",(void*)f_11870},
{"f_11567:support_scm",(void*)f_11567},
{"f_11577:support_scm",(void*)f_11577},
{"f_11595:support_scm",(void*)f_11595},
{"f_11634:support_scm",(void*)f_11634},
{"f_11599:support_scm",(void*)f_11599},
{"f_11225:support_scm",(void*)f_11225},
{"f_11549:support_scm",(void*)f_11549},
{"f_11231:support_scm",(void*)f_11231},
{"f_11241:support_scm",(void*)f_11241},
{"f_11250:support_scm",(void*)f_11250},
{"f_11262:support_scm",(void*)f_11262},
{"f_11274:support_scm",(void*)f_11274},
{"f_11280:support_scm",(void*)f_11280},
{"f_11284:support_scm",(void*)f_11284},
{"f_11180:support_scm",(void*)f_11180},
{"f_11219:support_scm",(void*)f_11219},
{"f_11186:support_scm",(void*)f_11186},
{"f_11190:support_scm",(void*)f_11190},
{"f_11194:support_scm",(void*)f_11194},
{"f_11149:support_scm",(void*)f_11149},
{"f_11162:support_scm",(void*)f_11162},
{"f_11118:support_scm",(void*)f_11118},
{"f_11131:support_scm",(void*)f_11131},
{"f_10060:support_scm",(void*)f_10060},
{"f_11112:support_scm",(void*)f_11112},
{"f_10066:support_scm",(void*)f_10066},
{"f_10072:support_scm",(void*)f_10072},
{"f_10101:support_scm",(void*)f_10101},
{"f_10120:support_scm",(void*)f_10120},
{"f_10139:support_scm",(void*)f_10139},
{"f_10209:support_scm",(void*)f_10209},
{"f_10228:support_scm",(void*)f_10228},
{"f_10310:support_scm",(void*)f_10310},
{"f_10349:support_scm",(void*)f_10349},
{"f_10368:support_scm",(void*)f_10368},
{"f_10387:support_scm",(void*)f_10387},
{"f_10467:support_scm",(void*)f_10467},
{"f_10552:support_scm",(void*)f_10552},
{"f_10627:support_scm",(void*)f_10627},
{"f_10666:support_scm",(void*)f_10666},
{"f_10736:support_scm",(void*)f_10736},
{"f_10669:support_scm",(void*)f_10669},
{"f_10631:support_scm",(void*)f_10631},
{"f_10470:support_scm",(void*)f_10470},
{"f_10501:support_scm",(void*)f_10501},
{"f_10390:support_scm",(void*)f_10390},
{"f_10231:support_scm",(void*)f_10231},
{"f_10262:support_scm",(void*)f_10262},
{"f_10142:support_scm",(void*)f_10142},
{"f_10173:support_scm",(void*)f_10173},
{"f_10002:support_scm",(void*)f_10002},
{"f_10006:support_scm",(void*)f_10006},
{"f_10017:support_scm",(void*)f_10017},
{"f_10023:support_scm",(void*)f_10023},
{"f_10035:support_scm",(void*)f_10035},
{"f_10041:support_scm",(void*)f_10041},
{"f_10009:support_scm",(void*)f_10009},
{"f_9921:support_scm",(void*)f_9921},
{"f_9933:support_scm",(void*)f_9933},
{"f_9940:support_scm",(void*)f_9940},
{"f_9943:support_scm",(void*)f_9943},
{"f_9946:support_scm",(void*)f_9946},
{"f_9949:support_scm",(void*)f_9949},
{"f_9952:support_scm",(void*)f_9952},
{"f_9955:support_scm",(void*)f_9955},
{"f_9958:support_scm",(void*)f_9958},
{"f_9961:support_scm",(void*)f_9961},
{"f_9964:support_scm",(void*)f_9964},
{"f_9967:support_scm",(void*)f_9967},
{"f_9970:support_scm",(void*)f_9970},
{"f_9973:support_scm",(void*)f_9973},
{"f_9976:support_scm",(void*)f_9976},
{"f_9979:support_scm",(void*)f_9979},
{"f_9982:support_scm",(void*)f_9982},
{"f_9985:support_scm",(void*)f_9985},
{"f_9988:support_scm",(void*)f_9988},
{"f_9991:support_scm",(void*)f_9991},
{"f_9994:support_scm",(void*)f_9994},
{"f_9997:support_scm",(void*)f_9997},
{"f_9927:support_scm",(void*)f_9927},
{"f_9813:support_scm",(void*)f_9813},
{"f_9822:support_scm",(void*)f_9822},
{"f_9828:support_scm",(void*)f_9828},
{"f_9836:support_scm",(void*)f_9836},
{"f_9817:support_scm",(void*)f_9817},
{"f_9792:support_scm",(void*)f_9792},
{"f_9802:support_scm",(void*)f_9802},
{"f_9743:support_scm",(void*)f_9743},
{"f_9749:support_scm",(void*)f_9749},
{"f_9790:support_scm",(void*)f_9790},
{"f_9762:support_scm",(void*)f_9762},
{"f_9706:support_scm",(void*)f_9706},
{"f_9712:support_scm",(void*)f_9712},
{"f_9741:support_scm",(void*)f_9741},
{"f_9719:support_scm",(void*)f_9719},
{"f_9722:support_scm",(void*)f_9722},
{"f_9665:support_scm",(void*)f_9665},
{"f_9671:support_scm",(void*)f_9671},
{"f_9704:support_scm",(void*)f_9704},
{"f_9678:support_scm",(void*)f_9678},
{"f_9681:support_scm",(void*)f_9681},
{"f_9543:support_scm",(void*)f_9543},
{"f_9572:support_scm",(void*)f_9572},
{"f_9442:support_scm",(void*)f_9442},
{"f_9448:support_scm",(void*)f_9448},
{"f_9474:support_scm",(void*)f_9474},
{"f_9488:support_scm",(void*)f_9488},
{"f_9496:support_scm",(void*)f_9496},
{"f_9217:support_scm",(void*)f_9217},
{"f_9416:support_scm",(void*)f_9416},
{"f_9422:support_scm",(void*)f_9422},
{"f_9297:support_scm",(void*)f_9297},
{"f_9319:support_scm",(void*)f_9319},
{"f_9337:support_scm",(void*)f_9337},
{"f_9368:support_scm",(void*)f_9368},
{"f_9254:support_scm",(void*)f_9254},
{"f_9276:support_scm",(void*)f_9276},
{"f_9220:support_scm",(void*)f_9220},
{"f_9249:support_scm",(void*)f_9249},
{"f_9228:support_scm",(void*)f_9228},
{"f_9148:support_scm",(void*)f_9148},
{"f_9154:support_scm",(void*)f_9154},
{"f_9160:support_scm",(void*)f_9160},
{"f_9164:support_scm",(void*)f_9164},
{"f_9211:support_scm",(void*)f_9211},
{"f_9175:support_scm",(void*)f_9175},
{"f_9200:support_scm",(void*)f_9200},
{"f_8956:support_scm",(void*)f_8956},
{"f_8987:support_scm",(void*)f_8987},
{"f_9146:support_scm",(void*)f_9146},
{"f_8991:support_scm",(void*)f_8991},
{"f_8999:support_scm",(void*)f_8999},
{"f_9006:support_scm",(void*)f_9006},
{"f_9142:support_scm",(void*)f_9142},
{"f_9030:support_scm",(void*)f_9030},
{"f_9109:support_scm",(void*)f_9109},
{"f_9064:support_scm",(void*)f_9064},
{"f_9067:support_scm",(void*)f_9067},
{"f_9085:support_scm",(void*)f_9085},
{"f_9074:support_scm",(void*)f_9074},
{"f_8994:support_scm",(void*)f_8994},
{"f_8960:support_scm",(void*)f_8960},
{"f_8966:support_scm",(void*)f_8966},
{"f_8979:support_scm",(void*)f_8979},
{"f_8971:support_scm",(void*)f_8971},
{"f_8888:support_scm",(void*)f_8888},
{"f_8894:support_scm",(void*)f_8894},
{"f_8921:support_scm",(void*)f_8921},
{"f_8950:support_scm",(void*)f_8950},
{"f_8915:support_scm",(void*)f_8915},
{"f_8802:support_scm",(void*)f_8802},
{"f_8808:support_scm",(void*)f_8808},
{"f_8853:support_scm",(void*)f_8853},
{"f_8882:support_scm",(void*)f_8882},
{"f_8842:support_scm",(void*)f_8842},
{"f_8838:support_scm",(void*)f_8838},
{"f_8763:support_scm",(void*)f_8763},
{"f_8767:support_scm",(void*)f_8767},
{"f_8770:support_scm",(void*)f_8770},
{"f_8773:support_scm",(void*)f_8773},
{"f_8729:support_scm",(void*)f_8729},
{"f_8735:support_scm",(void*)f_8735},
{"f_8749:support_scm",(void*)f_8749},
{"f_8753:support_scm",(void*)f_8753},
{"f_8330:support_scm",(void*)f_8330},
{"f_8680:support_scm",(void*)f_8680},
{"f_8713:support_scm",(void*)f_8713},
{"f_8693:support_scm",(void*)f_8693},
{"f_8334:support_scm",(void*)f_8334},
{"f_8342:support_scm",(void*)f_8342},
{"f_8665:support_scm",(void*)f_8665},
{"f_8671:support_scm",(void*)f_8671},
{"f_8669:support_scm",(void*)f_8669},
{"f_8505:support_scm",(void*)f_8505},
{"f_8612:support_scm",(void*)f_8612},
{"f_8649:support_scm",(void*)f_8649},
{"f_8639:support_scm",(void*)f_8639},
{"f_8643:support_scm",(void*)f_8643},
{"f_8646:support_scm",(void*)f_8646},
{"f_8509:support_scm",(void*)f_8509},
{"f_8563:support_scm",(void*)f_8563},
{"f_8596:support_scm",(void*)f_8596},
{"f_8576:support_scm",(void*)f_8576},
{"f_8561:support_scm",(void*)f_8561},
{"f_8512:support_scm",(void*)f_8512},
{"f_8538:support_scm",(void*)f_8538},
{"f_8554:support_scm",(void*)f_8554},
{"f_8546:support_scm",(void*)f_8546},
{"f_8530:support_scm",(void*)f_8530},
{"f_8528:support_scm",(void*)f_8528},
{"f_8456:support_scm",(void*)f_8456},
{"f_8459:support_scm",(void*)f_8459},
{"f_8462:support_scm",(void*)f_8462},
{"f_8482:support_scm",(void*)f_8482},
{"f_8440:support_scm",(void*)f_8440},
{"f_8432:support_scm",(void*)f_8432},
{"f_8403:support_scm",(void*)f_8403},
{"f_8393:support_scm",(void*)f_8393},
{"f_8400:support_scm",(void*)f_8400},
{"f_8182:support_scm",(void*)f_8182},
{"f_8188:support_scm",(void*)f_8188},
{"f_8200:support_scm",(void*)f_8200},
{"f_8295:support_scm",(void*)f_8295},
{"f_8324:support_scm",(void*)f_8324},
{"f_8204:support_scm",(void*)f_8204},
{"f_8207:support_scm",(void*)f_8207},
{"f_8287:support_scm",(void*)f_8287},
{"f_8233:support_scm",(void*)f_8233},
{"f_8237:support_scm",(void*)f_8237},
{"f_8212:support_scm",(void*)f_8212},
{"f_8194:support_scm",(void*)f_8194},
{"f_8128:support_scm",(void*)f_8128},
{"f_8134:support_scm",(void*)f_8134},
{"f_8160:support_scm",(void*)f_8160},
{"f_8164:support_scm",(void*)f_8164},
{"f_7447:support_scm",(void*)f_7447},
{"f_7453:support_scm",(void*)f_7453},
{"f_7487:support_scm",(void*)f_7487},
{"f_7945:support_scm",(void*)f_7945},
{"f_8063:support_scm",(void*)f_8063},
{"f_8092:support_scm",(void*)f_8092},
{"f_8061:support_scm",(void*)f_8061},
{"f_8057:support_scm",(void*)f_8057},
{"f_8017:support_scm",(void*)f_8017},
{"f_8046:support_scm",(void*)f_8046},
{"f_8015:support_scm",(void*)f_8015},
{"f_7952:support_scm",(void*)f_7952},
{"f_7962:support_scm",(void*)f_7962},
{"f_7991:support_scm",(void*)f_7991},
{"f_7956:support_scm",(void*)f_7956},
{"f_7883:support_scm",(void*)f_7883},
{"f_7932:support_scm",(void*)f_7932},
{"f_7901:support_scm",(void*)f_7901},
{"f_7909:support_scm",(void*)f_7909},
{"f_7826:support_scm",(void*)f_7826},
{"f_7855:support_scm",(void*)f_7855},
{"f_7824:support_scm",(void*)f_7824},
{"f_7774:support_scm",(void*)f_7774},
{"f_7803:support_scm",(void*)f_7803},
{"f_7756:support_scm",(void*)f_7756},
{"f_7700:support_scm",(void*)f_7700},
{"f_7702:support_scm",(void*)f_7702},
{"f_7731:support_scm",(void*)f_7731},
{"f_7647:support_scm",(void*)f_7647},
{"f_7649:support_scm",(void*)f_7649},
{"f_7682:support_scm",(void*)f_7682},
{"f_7662:support_scm",(void*)f_7662},
{"f_7631:support_scm",(void*)f_7631},
{"f_7643:support_scm",(void*)f_7643},
{"f_7639:support_scm",(void*)f_7639},
{"f_7552:support_scm",(void*)f_7552},
{"f_7581:support_scm",(void*)f_7581},
{"f_7550:support_scm",(void*)f_7550},
{"f_7546:support_scm",(void*)f_7546},
{"f_7496:support_scm",(void*)f_7496},
{"f_7525:support_scm",(void*)f_7525},
{"f_7494:support_scm",(void*)f_7494},
{"f_6524:support_scm",(void*)f_6524},
{"f_7442:support_scm",(void*)f_7442},
{"f_7445:support_scm",(void*)f_7445},
{"f_6527:support_scm",(void*)f_6527},
{"f_7402:support_scm",(void*)f_7402},
{"f_7431:support_scm",(void*)f_7431},
{"f_7400:support_scm",(void*)f_7400},
{"f_7140:support_scm",(void*)f_7140},
{"f_7267:support_scm",(void*)f_7267},
{"f_7351:support_scm",(void*)f_7351},
{"f_7323:support_scm",(void*)f_7323},
{"f_7330:support_scm",(void*)f_7330},
{"f_7337:support_scm",(void*)f_7337},
{"f_7327:support_scm",(void*)f_7327},
{"f_7286:support_scm",(void*)f_7286},
{"f_7315:support_scm",(void*)f_7315},
{"f_7284:support_scm",(void*)f_7284},
{"f_7261:support_scm",(void*)f_7261},
{"f_7223:support_scm",(void*)f_7223},
{"f_7252:support_scm",(void*)f_7252},
{"f_7217:support_scm",(void*)f_7217},
{"f_7166:support_scm",(void*)f_7166},
{"f_7195:support_scm",(void*)f_7195},
{"f_7160:support_scm",(void*)f_7160},
{"f_7119:support_scm",(void*)f_7119},
{"f_7103:support_scm",(void*)f_7103},
{"f_7099:support_scm",(void*)f_7099},
{"f_7033:support_scm",(void*)f_7033},
{"f_7062:support_scm",(void*)f_7062},
{"f_7027:support_scm",(void*)f_7027},
{"f_6943:support_scm",(void*)f_6943},
{"f_6972:support_scm",(void*)f_6972},
{"f_6937:support_scm",(void*)f_6937},
{"f_6845:support_scm",(void*)f_6845},
{"f_6855:support_scm",(void*)f_6855},
{"f_6884:support_scm",(void*)f_6884},
{"f_6849:support_scm",(void*)f_6849},
{"f_6812:support_scm",(void*)f_6812},
{"f_6719:support_scm",(void*)f_6719},
{"f_6741:support_scm",(void*)f_6741},
{"f_6779:support_scm",(void*)f_6779},
{"f_6768:support_scm",(void*)f_6768},
{"f_6727:support_scm",(void*)f_6727},
{"f_6735:support_scm",(void*)f_6735},
{"f_6723:support_scm",(void*)f_6723},
{"f_6660:support_scm",(void*)f_6660},
{"f_6663:support_scm",(void*)f_6663},
{"f_6670:support_scm",(void*)f_6670},
{"f_6608:support_scm",(void*)f_6608},
{"f_6637:support_scm",(void*)f_6637},
{"f_6602:support_scm",(void*)f_6602},
{"f_6509:support_scm",(void*)f_6509},
{"f_6494:support_scm",(void*)f_6494},
{"f_6488:support_scm",(void*)f_6488},
{"f_6479:support_scm",(void*)f_6479},
{"f_6470:support_scm",(void*)f_6470},
{"f_6461:support_scm",(void*)f_6461},
{"f_6452:support_scm",(void*)f_6452},
{"f_6443:support_scm",(void*)f_6443},
{"f_6434:support_scm",(void*)f_6434},
{"f_6428:support_scm",(void*)f_6428},
{"f_5929:support_scm",(void*)f_5929},
{"f_6426:support_scm",(void*)f_6426},
{"f_5933:support_scm",(void*)f_5933},
{"f_5938:support_scm",(void*)f_5938},
{"f_5948:support_scm",(void*)f_5948},
{"f_6111:support_scm",(void*)f_6111},
{"f_6121:support_scm",(void*)f_6121},
{"f_6137:support_scm",(void*)f_6137},
{"f_6213:support_scm",(void*)f_6213},
{"f_6253:support_scm",(void*)f_6253},
{"f_6243:support_scm",(void*)f_6243},
{"f_6216:support_scm",(void*)f_6216},
{"f_6233:support_scm",(void*)f_6233},
{"f_6219:support_scm",(void*)f_6219},
{"f_6222:support_scm",(void*)f_6222},
{"f_6229:support_scm",(void*)f_6229},
{"f_6204:support_scm",(void*)f_6204},
{"f_6194:support_scm",(void*)f_6194},
{"f_6178:support_scm",(void*)f_6178},
{"f_6140:support_scm",(void*)f_6140},
{"f_6155:support_scm",(void*)f_6155},
{"f_6124:support_scm",(void*)f_6124},
{"f_5951:support_scm",(void*)f_5951},
{"f_5992:support_scm",(void*)f_5992},
{"f_6026:support_scm",(void*)f_6026},
{"f_6060:support_scm",(void*)f_6060},
{"f_6063:support_scm",(void*)f_6063},
{"f_6029:support_scm",(void*)f_6029},
{"f_5995:support_scm",(void*)f_5995},
{"f_5954:support_scm",(void*)f_5954},
{"f_5982:support_scm",(void*)f_5982},
{"f_5957:support_scm",(void*)f_5957},
{"f_5969:support_scm",(void*)f_5969},
{"f_5960:support_scm",(void*)f_5960},
{"f_5866:support_scm",(void*)f_5866},
{"f_5872:support_scm",(void*)f_5872},
{"f_5879:support_scm",(void*)f_5879},
{"f_5882:support_scm",(void*)f_5882},
{"f_5894:support_scm",(void*)f_5894},
{"f_5923:support_scm",(void*)f_5923},
{"f_5892:support_scm",(void*)f_5892},
{"f_5885:support_scm",(void*)f_5885},
{"f_5842:support_scm",(void*)f_5842},
{"f_5848:support_scm",(void*)f_5848},
{"f_5858:support_scm",(void*)f_5858},
{"f_5801:support_scm",(void*)f_5801},
{"f_5808:support_scm",(void*)f_5808},
{"f_5811:support_scm",(void*)f_5811},
{"f_5815:support_scm",(void*)f_5815},
{"f_5791:support_scm",(void*)f_5791},
{"f_5782:support_scm",(void*)f_5782},
{"f_5786:support_scm",(void*)f_5786},
{"f_5725:support_scm",(void*)f_5725},
{"f_5729:support_scm",(void*)f_5729},
{"f_5759:support_scm",(void*)f_5759},
{"f_5673:support_scm",(void*)f_5673},
{"f_5677:support_scm",(void*)f_5677},
{"f_5704:support_scm",(void*)f_5704},
{"f_5627:support_scm",(void*)f_5627},
{"f_5631:support_scm",(void*)f_5631},
{"f_5653:support_scm",(void*)f_5653},
{"f_5609:support_scm",(void*)f_5609},
{"f_5613:support_scm",(void*)f_5613},
{"f_5621:support_scm",(void*)f_5621},
{"f_5591:support_scm",(void*)f_5591},
{"f_5595:support_scm",(void*)f_5595},
{"f_5338:support_scm",(void*)f_5338},
{"f_5500:support_scm",(void*)f_5500},
{"f_5514:support_scm",(void*)f_5514},
{"f_5539:support_scm",(void*)f_5539},
{"f_5550:support_scm",(void*)f_5550},
{"f_5578:support_scm",(void*)f_5578},
{"f_5346:support_scm",(void*)f_5346},
{"f_5409:support_scm",(void*)f_5409},
{"f_5423:support_scm",(void*)f_5423},
{"f_5448:support_scm",(void*)f_5448},
{"f_5459:support_scm",(void*)f_5459},
{"f_5487:support_scm",(void*)f_5487},
{"f_5349:support_scm",(void*)f_5349},
{"f_5354:support_scm",(void*)f_5354},
{"f_5368:support_scm",(void*)f_5368},
{"f_5396:support_scm",(void*)f_5396},
{"f_5342:support_scm",(void*)f_5342},
{"f_5197:support_scm",(void*)f_5197},
{"f_5201:support_scm",(void*)f_5201},
{"f_5205:support_scm",(void*)f_5205},
{"f_5194:support_scm",(void*)f_5194},
{"f_5087:support_scm",(void*)f_5087},
{"f_5096:support_scm",(void*)f_5096},
{"f_5127:support_scm",(void*)f_5127},
{"f_5181:support_scm",(void*)f_5181},
{"f_5187:support_scm",(void*)f_5187},
{"f_5133:support_scm",(void*)f_5133},
{"f_5165:support_scm",(void*)f_5165},
{"f_5179:support_scm",(void*)f_5179},
{"f_5171:support_scm",(void*)f_5171},
{"f_5137:support_scm",(void*)f_5137},
{"f_5159:support_scm",(void*)f_5159},
{"f_5102:support_scm",(void*)f_5102},
{"f_5108:support_scm",(void*)f_5108},
{"f_5119:support_scm",(void*)f_5119},
{"f_5116:support_scm",(void*)f_5116},
{"f_5091:support_scm",(void*)f_5091},
{"f_4986:support_scm",(void*)f_4986},
{"f_4992:support_scm",(void*)f_4992},
{"f_5069:support_scm",(void*)f_5069},
{"f_5020:support_scm",(void*)f_5020},
{"f_5058:support_scm",(void*)f_5058},
{"f_5046:support_scm",(void*)f_5046},
{"f_4926:support_scm",(void*)f_4926},
{"f_4942:support_scm",(void*)f_4942},
{"f_4984:support_scm",(void*)f_4984},
{"f_4948:support_scm",(void*)f_4948},
{"f_4963:support_scm",(void*)f_4963},
{"f_4880:support_scm",(void*)f_4880},
{"f_4924:support_scm",(void*)f_4924},
{"f_4884:support_scm",(void*)f_4884},
{"f_4850:support_scm",(void*)f_4850},
{"f_4804:support_scm",(void*)f_4804},
{"f_4784:support_scm",(void*)f_4784},
{"f_4790:support_scm",(void*)f_4790},
{"f_4798:support_scm",(void*)f_4798},
{"f_4802:support_scm",(void*)f_4802},
{"f_4753:support_scm",(void*)f_4753},
{"f_4759:support_scm",(void*)f_4759},
{"f_4774:support_scm",(void*)f_4774},
{"f_4690:support_scm",(void*)f_4690},
{"f_4704:support_scm",(void*)f_4704},
{"f_4706:support_scm",(void*)f_4706},
{"f_4735:support_scm",(void*)f_4735},
{"f_4678:support_scm",(void*)f_4678},
{"f_4631:support_scm",(void*)f_4631},
{"f_4647:support_scm",(void*)f_4647},
{"f_4659:support_scm",(void*)f_4659},
{"f_4624:support_scm",(void*)f_4624},
{"f_4617:support_scm",(void*)f_4617},
{"f_4561:support_scm",(void*)f_4561},
{"f_4615:support_scm",(void*)f_4615},
{"f_4565:support_scm",(void*)f_4565},
{"f_4588:support_scm",(void*)f_4588},
{"f_4467:support_scm",(void*)f_4467},
{"f_4483:support_scm",(void*)f_4483},
{"f_4485:support_scm",(void*)f_4485},
{"f_4507:support_scm",(void*)f_4507},
{"f_4546:support_scm",(void*)f_4546},
{"f_4514:support_scm",(void*)f_4514},
{"f_4530:support_scm",(void*)f_4530},
{"f_4518:support_scm",(void*)f_4518},
{"f_4522:support_scm",(void*)f_4522},
{"f_4479:support_scm",(void*)f_4479},
{"f_4423:support_scm",(void*)f_4423},
{"f_4429:support_scm",(void*)f_4429},
{"f_4453:support_scm",(void*)f_4453},
{"f_4392:support_scm",(void*)f_4392},
{"f_4415:support_scm",(void*)f_4415},
{"f_4418:support_scm",(void*)f_4418},
{"f_4421:support_scm",(void*)f_4421},
{"f_4365:support_scm",(void*)f_4365},
{"f_4384:support_scm",(void*)f_4384},
{"f_4387:support_scm",(void*)f_4387},
{"f_4329:support_scm",(void*)f_4329},
{"f_4335:support_scm",(void*)f_4335},
{"f_4261:support_scm",(void*)f_4261},
{"f_4285:support_scm",(void*)f_4285},
{"f_4264:support_scm",(void*)f_4264},
{"f_4272:support_scm",(void*)f_4272},
{"f_4276:support_scm",(void*)f_4276},
{"f_4218:support_scm",(void*)f_4218},
{"f_4224:support_scm",(void*)f_4224},
{"f_4247:support_scm",(void*)f_4247},
{"f_4251:support_scm",(void*)f_4251},
{"f_4215:support_scm",(void*)f_4215},
{"f_4170:support_scm",(void*)f_4170},
{"f_4174:support_scm",(void*)f_4174},
{"f_4177:support_scm",(void*)f_4177},
{"f_4180:support_scm",(void*)f_4180},
{"f_4191:support_scm",(void*)f_4191},
{"f_4183:support_scm",(void*)f_4183},
{"f_4186:support_scm",(void*)f_4186},
{"f_4151:support_scm",(void*)f_4151},
{"f_4155:support_scm",(void*)f_4155},
{"f_4168:support_scm",(void*)f_4168},
{"f_4158:support_scm",(void*)f_4158},
{"f_4161:support_scm",(void*)f_4161},
{"f_4122:support_scm",(void*)f_4122},
{"f_4129:support_scm",(void*)f_4129},
{"f_4132:support_scm",(void*)f_4132},
{"f_4142:support_scm",(void*)f_4142},
{"f_4135:support_scm",(void*)f_4135},
{"f_4057:support_scm",(void*)f_4057},
{"f_4067:support_scm",(void*)f_4067},
{"f_4082:support_scm",(void*)f_4082},
{"f_4087:support_scm",(void*)f_4087},
{"f_4106:support_scm",(void*)f_4106},
{"f_4099:support_scm",(void*)f_4099},
{"f_4109:support_scm",(void*)f_4109},
{"f_4070:support_scm",(void*)f_4070},
{"f_4073:support_scm",(void*)f_4073},
{"f_4076:support_scm",(void*)f_4076},
{"f_4030:support_scm",(void*)f_4030},
{"f_4044:support_scm",(void*)f_4044},
{"f_4025:support_scm",(void*)f_4025},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
