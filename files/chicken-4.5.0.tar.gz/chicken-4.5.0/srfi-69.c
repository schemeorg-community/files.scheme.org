/* Generated from srfi-69.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:52
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: srfi-69.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -output-file srfi-69.c -extend ./private-namespace.scm
   unit: srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[120];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,110,117,109,98,101,114,45,104,97,115,104,45,104,111,111,107,32,111,98,106,54,48,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,29),40,110,117,109,98,101,114,45,104,97,115,104,32,111,98,106,55,48,32,46,32,116,109,112,54,57,55,49,41,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,36),40,111,98,106,101,99,116,45,117,105,100,45,104,97,115,104,32,111,98,106,49,53,55,32,46,32,116,109,112,49,53,54,49,53,56,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,32),40,115,121,109,98,111,108,45,104,97,115,104,32,111,98,106,49,56,53,32,46,32,116,109,112,49,56,52,49,56,54,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,99,104,101,99,107,45,107,101,121,119,111,114,100,32,120,50,49,48,32,46,32,121,50,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,33),40,107,101,121,119,111,114,100,45,104,97,115,104,32,111,98,106,50,50,52,32,46,32,116,109,112,50,50,51,50,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,29),40,101,113,63,45,104,97,115,104,32,111,98,106,50,55,54,32,46,32,116,109,112,50,55,53,50,55,55,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,30),40,101,113,118,63,45,104,97,115,104,32,111,98,106,51,55,48,32,46,32,116,109,112,51,54,57,51,55,49,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,104,115,104,52,48,51,32,105,52,48,52,32,108,101,110,52,48,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,46),40,118,101,99,116,111,114,45,104,97,115,104,32,111,98,106,51,57,55,32,115,101,101,100,51,57,56,32,100,101,112,116,104,51,57,57,32,115,116,97,114,116,52,48,48,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,39),40,114,101,99,117,114,115,105,118,101,45,97,116,111,109,105,99,45,104,97,115,104,32,111,98,106,52,48,55,32,100,101,112,116,104,52,48,56,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,13),40,103,53,48,56,32,111,98,106,53,49,48,41,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,13),40,103,53,49,49,32,111,98,106,53,49,51,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,13),40,103,53,50,51,32,111,98,106,53,50,53,41,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,13),40,103,53,50,54,32,111,98,106,53,50,56,41,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,32),40,114,101,99,117,114,115,105,118,101,45,104,97,115,104,32,111,98,106,52,51,54,32,100,101,112,116,104,52,51,55,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,21),40,42,101,113,117,97,108,63,45,104,97,115,104,32,111,98,106,51,57,51,41,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,32),40,101,113,117,97,108,63,45,104,97,115,104,32,111,98,106,53,51,57,32,46,32,116,109,112,53,51,56,53,52,48,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,53,56,49,32,115,116,97,114,116,53,57,48,32,101,110,100,53,57,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,110,100,53,56,52,32,37,115,116,97,114,116,53,55,57,53,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,115,116,97,114,116,53,56,51,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,32),40,115,116,114,105,110,103,45,104,97,115,104,32,115,116,114,53,54,51,32,46,32,116,109,112,53,54,50,53,54,52,41};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,54,52,48,32,115,116,97,114,116,54,52,57,32,101,110,100,54,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,110,100,54,52,51,32,37,115,116,97,114,116,54,51,56,54,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,115,116,97,114,116,54,52,50,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,35),40,115,116,114,105,110,103,45,99,105,45,104,97,115,104,32,115,116,114,54,50,50,32,46,32,116,109,112,54,50,49,54,50,51,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,43),40,104,97,115,104,45,116,97,98,108,101,45,99,97,110,111,110,105,99,97,108,45,108,101,110,103,116,104,32,116,97,98,54,56,56,32,114,101,113,54,56,57,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,86),40,42,109,97,107,101,45,104,97,115,104,45,116,97,98,108,101,32,116,101,115,116,55,48,55,32,104,97,115,104,55,48,56,32,108,101,110,55,48,57,32,109,105,110,45,108,111,97,100,55,49,48,32,109,97,120,45,108,111,97,100,55,49,49,32,105,110,105,116,105,97,108,55,49,52,32,116,109,112,55,48,54,55,49,53,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,19),40,105,110,118,97,114,103,45,101,114,114,32,109,115,103,56,48,52,41,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,8),40,102,95,51,52,50,55,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,97,114,103,115,55,57,57,41,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,104,97,115,104,45,116,97,98,108,101,32,46,32,97,114,103,117,109,101,110,116,115,48,55,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,20),40,104,97,115,104,45,116,97,98,108,101,63,32,111,98,106,56,53,49,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,23),40,104,97,115,104,45,116,97,98,108,101,45,115,105,122,101,32,104,116,56,53,51,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,39),40,104,97,115,104,45,116,97,98,108,101,45,101,113,117,105,118,97,108,101,110,99,101,45,102,117,110,99,116,105,111,110,32,104,116,56,53,54,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,32),40,104,97,115,104,45,116,97,98,108,101,45,104,97,115,104,45,102,117,110,99,116,105,111,110,32,104,116,56,53,57,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,27),40,104,97,115,104,45,116,97,98,108,101,45,109,105,110,45,108,111,97,100,32,104,116,56,54,50,41,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,27),40,104,97,115,104,45,116,97,98,108,101,45,109,97,120,45,108,111,97,100,32,104,116,56,54,53,41,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,28),40,104,97,115,104,45,116,97,98,108,101,45,119,101,97,107,45,107,101,121,115,32,104,116,56,54,56,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,30),40,104,97,115,104,45,116,97,98,108,101,45,119,101,97,107,45,118,97,108,117,101,115,32,104,116,56,55,49,41,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,31),40,104,97,115,104,45,116,97,98,108,101,45,104,97,115,45,105,110,105,116,105,97,108,63,32,104,116,56,55,52,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,105,110,105,116,105,97,108,32,104,116,56,55,57,41,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,56,57,55,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,56,57,49,32,105,56,57,53,41};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,40),40,104,97,115,104,45,116,97,98,108,101,45,114,101,115,105,122,101,33,32,104,116,57,48,57,32,118,101,99,57,49,48,32,108,101,110,57,49,49,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,21),40,99,111,112,121,45,108,111,111,112,32,98,117,99,107,101,116,57,51,48,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,57,50,52,32,105,57,50,56,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,24),40,42,104,97,115,104,45,116,97,98,108,101,45,99,111,112,121,32,104,116,57,49,57,41};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,23),40,104,97,115,104,45,116,97,98,108,101,45,99,111,112,121,32,104,116,57,51,54,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,57,56,55,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,57,57,54,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,26),40,98,111,100,121,57,53,51,32,102,117,110,99,57,54,50,32,116,104,117,110,107,57,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,8),40,102,95,52,49,53,49,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,116,104,117,110,107,57,53,54,32,37,102,117,110,99,57,53,49,49,48,48,57,41,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,13),40,97,52,49,54,49,32,120,49,48,49,55,41,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,102,117,110,99,57,53,53,41,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,45),40,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,32,104,116,57,52,53,32,107,101,121,57,52,54,32,46,32,116,109,112,57,52,52,57,52,55,41,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,61),40,42,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,47,100,101,102,97,117,108,116,32,104,116,49,48,50,51,32,107,101,121,49,48,50,52,32,102,117,110,99,49,48,50,53,32,100,101,102,49,48,50,54,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,60),40,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,47,100,101,102,97,117,108,116,32,104,116,49,48,54,57,32,107,101,121,49,48,55,48,32,102,117,110,99,49,48,55,49,32,100,101,102,49,48,55,50,41,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,40),40,104,97,115,104,45,116,97,98,108,101,45,115,101,116,33,32,104,116,49,48,55,54,32,107,101,121,49,48,55,55,32,118,97,108,49,48,55,56,41};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,47),40,104,97,115,104,45,116,97,98,108,101,45,114,101,102,47,100,101,102,97,117,108,116,32,104,116,49,49,52,53,32,107,101,121,49,49,52,54,32,100,101,102,49,49,52,55,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,101,120,105,115,116,115,63,32,104,116,49,49,54,51,32,107,101,121,49,49,54,52,41,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,50,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,112,114,101,118,49,50,49,53,32,98,117,99,107,101,116,49,50,49,54,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,100,101,108,101,116,101,33,32,104,116,49,49,57,52,32,107,101,121,49,49,57,53,41,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,112,114,101,118,49,50,51,56,32,98,117,99,107,101,116,49,50,51,57,41,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,50,51,50,32,105,49,50,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,36),40,104,97,115,104,45,116,97,98,108,101,45,114,101,109,111,118,101,33,32,104,116,49,50,50,54,32,102,117,110,99,49,50,50,55,41,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,99,108,101,97,114,33,32,104,116,49,50,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,13),40,97,53,49,53,48,32,120,49,50,55,50,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,20),40,100,111,108,111,111,112,49,50,54,54,32,108,115,116,49,50,55,48,41,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,50,54,49,32,105,49,50,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,36),40,42,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,33,32,104,116,49,49,50,53,54,32,104,116,50,49,50,53,55,41,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,33,32,104,116,49,49,50,55,56,32,104,116,50,49,50,55,57,41,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,34),40,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,32,104,116,49,49,50,56,51,32,104,116,50,49,50,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,50,57,54,32,108,115,116,49,50,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,50,57,51,32,108,115,116,49,50,57,52,41,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,62,97,108,105,115,116,32,104,116,49,50,56,56,41,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,13),40,97,53,50,57,49,32,120,49,51,49,56,41,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,13),40,103,49,51,49,53,32,120,49,51,49,55,41,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,51,48,56,32,103,49,51,49,50,49,51,49,52,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,40),40,97,108,105,115,116,45,62,104,97,115,104,45,116,97,98,108,101,32,97,108,105,115,116,49,51,48,51,32,46,32,114,101,115,116,49,51,48,52,41};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,51,51,51,32,108,115,116,49,51,51,52,41,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,51,51,48,32,108,115,116,49,51,51,49,41,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,24),40,104,97,115,104,45,116,97,98,108,101,45,107,101,121,115,32,104,116,49,51,50,53,41};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,51,52,56,32,108,115,116,49,51,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,51,52,53,32,108,115,116,49,51,52,54,41,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,118,97,108,117,101,115,32,104,116,49,51,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,18),40,103,49,51,55,52,32,98,117,99,107,101,116,49,51,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,51,54,55,32,103,49,51,55,49,49,51,55,51,41,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,51,54,48,32,105,49,51,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,38),40,42,104,97,115,104,45,116,97,98,108,101,45,102,111,114,45,101,97,99,104,32,104,116,49,51,53,53,32,112,114,111,99,49,51,53,54,41,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,26),40,102,111,108,100,50,32,98,117,99,107,101,116,49,51,57,50,32,97,99,99,49,51,57,51,41,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,51,56,57,32,97,99,99,49,51,57,48,41,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,43),40,42,104,97,115,104,45,116,97,98,108,101,45,102,111,108,100,32,104,116,49,51,56,50,32,102,117,110,99,49,51,56,51,32,105,110,105,116,49,51,56,52,41,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,42),40,104,97,115,104,45,116,97,98,108,101,45,102,111,108,100,32,104,116,49,51,57,56,32,102,117,110,99,49,51,57,57,32,105,110,105,116,49,52,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,37),40,104,97,115,104,45,116,97,98,108,101,45,102,111,114,45,101,97,99,104,32,104,116,49,52,48,52,32,112,114,111,99,49,52,48,53,41,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,33),40,104,97,115,104,45,116,97,98,108,101,45,119,97,108,107,32,104,116,49,52,48,57,32,112,114,111,99,49,52,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,25),40,97,53,54,50,55,32,107,49,52,49,54,32,118,49,52,49,55,32,97,49,52,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,32),40,104,97,115,104,45,116,97,98,108,101,45,109,97,112,32,104,116,49,52,49,52,32,102,117,110,99,49,52,49,53,41};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,23),40,97,53,54,52,48,32,104,116,49,52,50,49,32,112,111,114,116,49,52,50,50,41,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,8),40,102,95,53,55,55,55,41};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,36),40,97,53,54,53,54,32,104,116,49,49,50,49,32,107,101,121,49,49,50,50,32,46,32,116,109,112,49,49,50,48,49,49,50,51,41,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_srfi_69_toplevel)
C_externexport void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5657)
static void C_ccall f_5657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5657)
static void C_ccall f_5657r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5777)
static void C_ccall f_5777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5661)
static void C_ccall f_5661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5667)
static void C_ccall f_5667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5679)
static void C_ccall f_5679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5736)
static void C_fcall f_5736(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5755)
static void C_ccall f_5755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5694)
static void C_fcall f_5694(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5648)
static void C_ccall f_5648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5639)
static void C_ccall f_5639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5616)
static void C_ccall f_5616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5636)
static void C_ccall f_5636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5592)
static void C_ccall f_5592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5580)
static void C_ccall f_5580(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5587)
static void C_ccall f_5587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5514)
static void C_fcall f_5514(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5526)
static void C_fcall f_5526(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5542)
static void C_fcall f_5542(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5570)
static void C_ccall f_5570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5443)
static void C_fcall f_5443(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5455)
static void C_fcall f_5455(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5478)
static void C_fcall f_5478(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5501)
static void C_ccall f_5501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5486)
static void C_fcall f_5486(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5465)
static void C_ccall f_5465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5378)
static void C_ccall f_5378(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5393)
static void C_fcall f_5393(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5409)
static void C_fcall f_5409(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5313)
static void C_ccall f_5313(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5328)
static void C_fcall f_5328(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5344)
static void C_fcall f_5344(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5259)
static void C_ccall f_5259(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5259)
static void C_ccall f_5259r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5266)
static void C_ccall f_5266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5271)
static void C_fcall f_5271(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5300)
static void C_ccall f_5300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5279)
static void C_fcall f_5279(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5292)
static void C_ccall f_5292(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5269)
static void C_ccall f_5269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5201)
static void C_fcall f_5201(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5217)
static void C_fcall f_5217(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5170)
static void C_ccall f_5170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5184)
static void C_ccall f_5184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5090)
static void C_fcall f_5090(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5102)
static void C_fcall f_5102(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5125)
static void C_fcall f_5125(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5151)
static void C_ccall f_5151(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_ccall f_5112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5081)
static void C_ccall f_5081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_fcall f_4999(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5025)
static void C_fcall f_5025(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4930)
static void C_fcall f_4930(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4883)
static C_word C_fcall f_4883(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_fcall f_4810(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4823)
static void C_ccall f_4823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4770)
static C_word C_fcall f_4770(C_word t0,C_word t1);
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4703)
static void C_fcall f_4703(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4719)
static void C_ccall f_4719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4664)
static C_word C_fcall f_4664(C_word t0,C_word t1);
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4491)
static void C_ccall f_4491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_fcall f_4464(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4498)
static void C_ccall f_4498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4513)
static void C_ccall f_4513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4579)
static void C_fcall f_4579(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4609)
static void C_ccall f_4609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4530)
static void C_fcall f_4530(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4207)
static void C_fcall f_4207(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4237)
static void C_fcall f_4237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4286)
static void C_ccall f_4286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4359)
static void C_fcall f_4359(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4300)
static void C_fcall f_4300(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4156)
static void C_fcall f_4156(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4162)
static void C_ccall f_4162(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4139)
static void C_fcall f_4139(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3911)
static void C_fcall f_3911(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3918)
static void C_ccall f_3918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3950)
static void C_fcall f_3950(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3999)
static void C_ccall f_3999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4076)
static void C_fcall f_4076(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4116)
static void C_ccall f_4116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_fcall f_4013(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3788)
static void C_fcall f_3788(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_fcall f_3803(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3865)
static void C_fcall f_3865(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3766)
static void C_ccall f_3766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3772)
static void C_ccall f_3772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3695)
static void C_fcall f_3695(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3718)
static void C_fcall f_3718(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3705)
static void C_ccall f_3705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3647)
static void C_ccall f_3647(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3638)
static void C_ccall f_3638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3620)
static void C_ccall f_3620(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3611)
static void C_ccall f_3611(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3602)
static void C_ccall f_3602(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3587)
static void C_ccall f_3587(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3580)
static void C_ccall f_3580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3302)
static void C_fcall f_3302(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3305)
static void C_fcall f_3305(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3525)
static void C_ccall f_3525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3535)
static void C_ccall f_3535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3308)
static void C_fcall f_3308(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3343)
static void C_fcall f_3343(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3462)
static void C_ccall f_3462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3475)
static void C_ccall f_3475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static void C_ccall f_3444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3440)
static void C_ccall f_3440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3413)
static void C_ccall f_3413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3396)
static void C_ccall f_3396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3386)
static void C_ccall f_3386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3354)
static void C_fcall f_3354(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3226)
static C_word C_fcall f_3226(C_word t0);
C_noret_decl(f_3193)
static void C_fcall f_3193(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_3197)
static void C_ccall f_3197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3163)
static void C_fcall f_3163(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3169)
static C_word C_fcall f_3169(C_word t0,C_word t1);
C_noret_decl(f_3020)
static void C_ccall f_3020(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3020)
static void C_ccall f_3020r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3101)
static void C_fcall f_3101(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3092)
static void C_fcall f_3092(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3073)
static void C_fcall f_3073(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2960)
static void C_fcall f_2960(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_fcall f_2951(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2932)
static void C_fcall f_2932(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_fcall f_2353(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2472)
static void C_fcall f_2472(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2807)
static void C_fcall f_2807(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2795)
static void C_fcall f_2795(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2728)
static void C_fcall f_2728(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2740)
static void C_ccall f_2740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2702)
static void C_fcall f_2702(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_fcall f_2421(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2455)
static void C_fcall f_2455(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_fcall f_2458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2356)
static void C_fcall f_2356(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2373)
static void C_fcall f_2373(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2294)
static void C_ccall f_2294(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2294)
static void C_ccall f_2294r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1767)
static void C_ccall f_1767(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1767)
static void C_ccall f_1767r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1703)
static void C_ccall f_1703(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1703)
static void C_ccall f_1703r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1507)
static void C_ccall f_1507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1676)
static void C_fcall f_1676(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1494)
static void C_ccall f_1494(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_5736)
static void C_fcall trf_5736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5736(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5736(t0,t1,t2);}

C_noret_decl(trf_5694)
static void C_fcall trf_5694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5694(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5694(t0,t1,t2);}

C_noret_decl(trf_5514)
static void C_fcall trf_5514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5514(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5514(t0,t1,t2,t3);}

C_noret_decl(trf_5526)
static void C_fcall trf_5526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5526(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5526(t0,t1,t2,t3);}

C_noret_decl(trf_5542)
static void C_fcall trf_5542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5542(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5542(t0,t1,t2,t3);}

C_noret_decl(trf_5443)
static void C_fcall trf_5443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5443(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5443(t0,t1,t2);}

C_noret_decl(trf_5455)
static void C_fcall trf_5455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5455(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5455(t0,t1,t2);}

C_noret_decl(trf_5478)
static void C_fcall trf_5478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5478(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5478(t0,t1,t2);}

C_noret_decl(trf_5486)
static void C_fcall trf_5486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5486(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5486(t0,t1,t2);}

C_noret_decl(trf_5393)
static void C_fcall trf_5393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5393(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5393(t0,t1,t2,t3);}

C_noret_decl(trf_5409)
static void C_fcall trf_5409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5409(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5409(t0,t1,t2,t3);}

C_noret_decl(trf_5328)
static void C_fcall trf_5328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5328(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5328(t0,t1,t2,t3);}

C_noret_decl(trf_5344)
static void C_fcall trf_5344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5344(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5344(t0,t1,t2,t3);}

C_noret_decl(trf_5271)
static void C_fcall trf_5271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5271(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5271(t0,t1,t2);}

C_noret_decl(trf_5279)
static void C_fcall trf_5279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5279(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5279(t0,t1,t2);}

C_noret_decl(trf_5201)
static void C_fcall trf_5201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5201(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5201(t0,t1,t2,t3);}

C_noret_decl(trf_5217)
static void C_fcall trf_5217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5217(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5217(t0,t1,t2,t3);}

C_noret_decl(trf_5090)
static void C_fcall trf_5090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5090(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5090(t0,t1,t2);}

C_noret_decl(trf_5102)
static void C_fcall trf_5102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5102(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5102(t0,t1,t2);}

C_noret_decl(trf_5125)
static void C_fcall trf_5125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5125(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5125(t0,t1,t2);}

C_noret_decl(trf_4999)
static void C_fcall trf_4999(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4999(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4999(t0,t1,t2);}

C_noret_decl(trf_5025)
static void C_fcall trf_5025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5025(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5025(t0,t1,t2,t3);}

C_noret_decl(trf_4930)
static void C_fcall trf_4930(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4930(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4930(t0,t1,t2,t3);}

C_noret_decl(trf_4810)
static void C_fcall trf_4810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4810(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4810(t0,t1,t2);}

C_noret_decl(trf_4703)
static void C_fcall trf_4703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4703(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4703(t0,t1,t2);}

C_noret_decl(trf_4464)
static void C_fcall trf_4464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4464(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4464(t0,t1);}

C_noret_decl(trf_4579)
static void C_fcall trf_4579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4579(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4579(t0,t1,t2);}

C_noret_decl(trf_4530)
static void C_fcall trf_4530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4530(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4530(t0,t1,t2);}

C_noret_decl(trf_4207)
static void C_fcall trf_4207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4207(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4207(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4237)
static void C_fcall trf_4237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4237(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4237(t0,t1);}

C_noret_decl(trf_4359)
static void C_fcall trf_4359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4359(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4359(t0,t1,t2);}

C_noret_decl(trf_4300)
static void C_fcall trf_4300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4300(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4300(t0,t1,t2);}

C_noret_decl(trf_4156)
static void C_fcall trf_4156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4156(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4156(t0,t1);}

C_noret_decl(trf_4139)
static void C_fcall trf_4139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4139(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4139(t0,t1,t2);}

C_noret_decl(trf_3911)
static void C_fcall trf_3911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3911(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3911(t0,t1,t2,t3);}

C_noret_decl(trf_3950)
static void C_fcall trf_3950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3950(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3950(t0,t1);}

C_noret_decl(trf_4076)
static void C_fcall trf_4076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4076(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4076(t0,t1,t2);}

C_noret_decl(trf_4013)
static void C_fcall trf_4013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4013(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4013(t0,t1,t2);}

C_noret_decl(trf_3788)
static void C_fcall trf_3788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3788(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3788(t0,t1,t2);}

C_noret_decl(trf_3803)
static void C_fcall trf_3803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3803(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3803(t0,t1,t2);}

C_noret_decl(trf_3865)
static void C_fcall trf_3865(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3865(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3865(t0,t1,t2);}

C_noret_decl(trf_3695)
static void C_fcall trf_3695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3695(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3695(t0,t1,t2);}

C_noret_decl(trf_3718)
static void C_fcall trf_3718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3718(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3718(t0,t1,t2);}

C_noret_decl(trf_3302)
static void C_fcall trf_3302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3302(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3302(t0,t1);}

C_noret_decl(trf_3305)
static void C_fcall trf_3305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3305(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3305(t0,t1);}

C_noret_decl(trf_3308)
static void C_fcall trf_3308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3308(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3308(t0,t1);}

C_noret_decl(trf_3343)
static void C_fcall trf_3343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3343(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3343(t0,t1,t2);}

C_noret_decl(trf_3354)
static void C_fcall trf_3354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3354(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3354(t0,t1,t2);}

C_noret_decl(trf_3193)
static void C_fcall trf_3193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3193(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_3193(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_3163)
static void C_fcall trf_3163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3163(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3163(t0,t1,t2);}

C_noret_decl(trf_3101)
static void C_fcall trf_3101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3101(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3101(t0,t1);}

C_noret_decl(trf_3092)
static void C_fcall trf_3092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3092(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3092(t0,t1,t2);}

C_noret_decl(trf_3073)
static void C_fcall trf_3073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3073(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3073(t0,t1,t2,t3);}

C_noret_decl(trf_2960)
static void C_fcall trf_2960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2960(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2960(t0,t1);}

C_noret_decl(trf_2951)
static void C_fcall trf_2951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2951(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2951(t0,t1,t2);}

C_noret_decl(trf_2932)
static void C_fcall trf_2932(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2932(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2932(t0,t1,t2,t3);}

C_noret_decl(trf_2353)
static void C_fcall trf_2353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2353(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2353(t0,t1);}

C_noret_decl(trf_2472)
static void C_fcall trf_2472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2472(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2472(t0,t1,t2,t3);}

C_noret_decl(trf_2807)
static void C_fcall trf_2807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2807(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2807(t0,t1,t2);}

C_noret_decl(trf_2795)
static void C_fcall trf_2795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2795(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2795(t0,t1,t2);}

C_noret_decl(trf_2728)
static void C_fcall trf_2728(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2728(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2728(t0,t1,t2);}

C_noret_decl(trf_2702)
static void C_fcall trf_2702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2702(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2702(t0,t1,t2);}

C_noret_decl(trf_2421)
static void C_fcall trf_2421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2421(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2421(t0,t1,t2,t3);}

C_noret_decl(trf_2455)
static void C_fcall trf_2455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2455(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2455(t0,t1);}

C_noret_decl(trf_2458)
static void C_fcall trf_2458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2458(t0,t1);}

C_noret_decl(trf_2356)
static void C_fcall trf_2356(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2356(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2356(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2373)
static void C_fcall trf_2373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2373(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2373(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1676)
static void C_fcall trf_1676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1676(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1676(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_69_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(963)){
C_save(t1);
C_rereclaim2(963*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,120);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],20,"\003sysnumber-hash-hook");
lf[4]=C_h_intern(&lf[4],11,"number-hash");
lf[5]=C_h_intern(&lf[5],5,"fxmod");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_h_intern(&lf[7],5,"\000type");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid number");
lf[9]=C_h_intern(&lf[9],9,"\003syserror");
lf[10]=C_h_intern(&lf[10],15,"object-uid-hash");
lf[11]=C_h_intern(&lf[11],11,"symbol-hash");
lf[12]=C_h_intern(&lf[12],17,"\003syscheck-keyword");
lf[13]=C_h_intern(&lf[13],11,"\000type-error");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a keyword");
lf[15]=C_h_intern(&lf[15],8,"keyword\077");
lf[16]=C_h_intern(&lf[16],12,"keyword-hash");
lf[17]=C_h_intern(&lf[17],8,"eq\077-hash");
lf[18]=C_h_intern(&lf[18],16,"hash-by-identity");
lf[19]=C_h_intern(&lf[19],9,"eqv\077-hash");
lf[20]=C_h_intern(&lf[20],5,"fxmin");
lf[21]=C_h_intern(&lf[21],11,"input-port\077");
lf[22]=C_h_intern(&lf[22],11,"equal\077-hash");
lf[23]=C_h_intern(&lf[23],4,"hash");
lf[24]=C_h_intern(&lf[24],11,"string-hash");
lf[25]=C_h_intern(&lf[25],13,"\003syssubstring");
lf[26]=C_h_intern(&lf[26],15,"\003syscheck-range");
lf[27]=C_h_intern(&lf[27],14,"string-ci-hash");
lf[28]=C_h_intern(&lf[28],14,"string-hash-ci");
lf[30]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\0013\376\003\000\000\002\376\377\001\000\000\002i\376\003\000\000\002\376\377\001\000\000\004\325\376\003\000\000\002\376\377\001\000\000\011\255\376\003\000\000\002\376\377\001\000\000\023]\376\003\000\000\002\376\377\001\000\000&\303\376\003\000\000\002\376\377\001"
"\000\000M\215\376\003\000\000\002\376\377\001\000\000\233\035\376\003\000\000\002\376\377\001\000\0016\077\376\003\000\000\002\376\377\001\000\002l\201\376\003\000\000\002\376\377\001\000\004\331\005\376\003\000\000\002\376\377\001\000\011\262\025\376\003\000\000\002\376\377\001\000\023dA\376\003\000\000"
"\002\376\377\001\000&\310\205\376\003\000\000\002\376\377\001\000M\221\037\376\003\000\000\002\376\377\001\000\233\042I\376\003\000\000\002\376\377\001\0016D\277\376\003\000\000\002\376\377\001\002l\211\207\376\003\000\000\002\376\377\001\004\331\023\027\376\003\000\000\002\376\377\001\011\262&1"
"\376\003\000\000\002\376\377\001\023dLq\376\003\000\000\002\376\377\001&\310\230\373\376\003\000\000\002\376\377\001\077\377\377\377\376\377\016");
lf[32]=C_h_intern(&lf[32],11,"make-vector");
lf[34]=C_h_intern(&lf[34],10,"hash-table");
lf[35]=C_h_intern(&lf[35],3,"eq\077");
lf[36]=C_h_intern(&lf[36],4,"eqv\077");
lf[37]=C_h_intern(&lf[37],6,"equal\077");
lf[38]=C_h_intern(&lf[38],8,"string=\077");
lf[39]=C_h_intern(&lf[39],11,"string-ci=\077");
lf[40]=C_h_intern(&lf[40],1,"=");
lf[41]=C_h_intern(&lf[41],15,"make-hash-table");
lf[42]=C_decode_literal(C_heaptop,"\376U0.5\000");
lf[43]=C_decode_literal(C_heaptop,"\376U0.8\000");
lf[44]=C_h_intern(&lf[44],7,"warning");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\033user test without user hash");
lf[46]=C_h_intern(&lf[46],5,"error");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\036min-load greater than max-load");
lf[48]=C_h_intern(&lf[48],3,"fp<");
lf[49]=C_h_intern(&lf[49],5,"\000test");
lf[50]=C_h_intern(&lf[50],17,"\003syscheck-closure");
lf[51]=C_h_intern(&lf[51],5,"\000hash");
lf[52]=C_h_intern(&lf[52],5,"\000size");
lf[53]=C_h_intern(&lf[53],19,"hash-table-max-size");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[55]=C_h_intern(&lf[55],8,"\000initial");
lf[56]=C_h_intern(&lf[56],9,"\000min-load");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid min-load");
lf[58]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[59]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[60]=C_h_intern(&lf[60],17,"\003syscheck-inexact");
lf[61]=C_h_intern(&lf[61],9,"\000max-load");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid max-load");
lf[63]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[64]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[65]=C_h_intern(&lf[65],10,"\000weak-keys");
lf[66]=C_h_intern(&lf[66],12,"\000weak-values");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\017unknown keyword");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\025missing keyword value");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[71]=C_h_intern(&lf[71],11,"hash-table\077");
lf[72]=C_h_intern(&lf[72],15,"hash-table-size");
lf[73]=C_h_intern(&lf[73],31,"hash-table-equivalence-function");
lf[74]=C_h_intern(&lf[74],24,"hash-table-hash-function");
lf[75]=C_h_intern(&lf[75],19,"hash-table-min-load");
lf[76]=C_h_intern(&lf[76],19,"hash-table-max-load");
lf[77]=C_h_intern(&lf[77],20,"hash-table-weak-keys");
lf[78]=C_h_intern(&lf[78],22,"hash-table-weak-values");
lf[79]=C_h_intern(&lf[79],23,"hash-table-has-initial\077");
lf[80]=C_h_intern(&lf[80],18,"hash-table-initial");
lf[81]=C_h_intern(&lf[81],18,"hash-table-resize!");
lf[83]=C_h_intern(&lf[83],15,"hash-table-copy");
lf[84]=C_h_intern(&lf[84],18,"hash-table-update!");
lf[85]=C_h_intern(&lf[85],5,"floor");
lf[86]=C_h_intern(&lf[86],13,"\000access-error");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[89]=C_h_intern(&lf[89],26,"hash-table-update!/default");
lf[90]=C_h_intern(&lf[90],15,"hash-table-set!");
lf[91]=C_h_intern(&lf[91],19,"\003sysundefined-value");
lf[92]=C_h_intern(&lf[92],14,"hash-table-ref");
lf[93]=C_h_intern(&lf[93],22,"hash-table-ref/default");
lf[94]=C_h_intern(&lf[94],18,"hash-table-exists\077");
lf[95]=C_h_intern(&lf[95],18,"hash-table-delete!");
lf[96]=C_h_intern(&lf[96],18,"hash-table-remove!");
lf[97]=C_h_intern(&lf[97],17,"hash-table-clear!");
lf[98]=C_h_intern(&lf[98],12,"vector-fill!");
lf[100]=C_h_intern(&lf[100],17,"hash-table-merge!");
lf[101]=C_h_intern(&lf[101],16,"hash-table-merge");
lf[102]=C_h_intern(&lf[102],17,"hash-table->alist");
lf[103]=C_h_intern(&lf[103],17,"alist->hash-table");
lf[104]=C_h_intern(&lf[104],15,"hash-table-keys");
lf[105]=C_h_intern(&lf[105],17,"hash-table-values");
lf[108]=C_h_intern(&lf[108],15,"hash-table-fold");
lf[109]=C_h_intern(&lf[109],19,"hash-table-for-each");
lf[110]=C_h_intern(&lf[110],15,"hash-table-walk");
lf[111]=C_h_intern(&lf[111],14,"hash-table-map");
lf[112]=C_h_intern(&lf[112],9,"\003sysprint");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\002)>");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\016#<hash-table (");
lf[115]=C_h_intern(&lf[115],27,"\003sysregister-record-printer");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[117]=C_h_intern(&lf[117],18,"getter-with-setter");
lf[118]=C_h_intern(&lf[118],17,"register-feature!");
lf[119]=C_h_intern(&lf[119],7,"srfi-69");
C_register_lf2(lf,120,create_ptable());
t2=C_mutate(&lf[0] /* (set! c77 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1492,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 62   register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[118]+1)))(3,*((C_word*)lf[118]+1),t3,lf[119]);}

/* k1490 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word ab[114],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1492,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! ##sys#number-hash-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1494,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[4]+1 /* (set! number-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1500,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[10]+1 /* (set! object-uid-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1703,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[11]+1 /* (set! symbol-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1767,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[12]+1 /* (set! ##sys#check-keyword ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1840,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[16]+1 /* (set! keyword-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1866,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[17]+1 /* (set! eq?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2020,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[18]+1 /* (set! hash-by-identity ...) */,*((C_word*)lf[17]+1));
t10=C_mutate((C_word*)lf[19]+1 /* (set! eqv?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2294,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[3] /* (set! *equal?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2353,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[22]+1 /* (set! equal?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2819,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[23]+1 /* (set! hash ...) */,*((C_word*)lf[22]+1));
t14=C_mutate((C_word*)lf[24]+1 /* (set! string-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2879,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[27]+1 /* (set! string-ci-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3020,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[28]+1 /* (set! string-hash-ci ...) */,*((C_word*)lf[27]+1));
t17=C_mutate(&lf[29] /* (set! constant686 ...) */,lf[30]);
t18=C_mutate(&lf[31] /* (set! hash-table-canonical-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3163,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t19=*((C_word*)lf[32]+1);
t20=C_mutate(&lf[33] /* (set! *make-hash-table ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3193,a[2]=t19,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp));
t21=*((C_word*)lf[35]+1);
t22=*((C_word*)lf[36]+1);
t23=*((C_word*)lf[37]+1);
t24=*((C_word*)lf[38]+1);
t25=*((C_word*)lf[39]+1);
t26=*((C_word*)lf[40]+1);
t27=C_mutate((C_word*)lf[41]+1 /* (set! make-hash-table ...) */,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3224,a[2]=t26,a[3]=t25,a[4]=t24,a[5]=t23,a[6]=t22,a[7]=t21,a[8]=((C_word)li32),tmp=(C_word)a,a+=9,tmp));
t28=C_mutate((C_word*)lf[71]+1 /* (set! hash-table? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3587,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[72]+1 /* (set! hash-table-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3593,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[73]+1 /* (set! hash-table-equivalence-function ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3602,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[74]+1 /* (set! hash-table-hash-function ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3611,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[75]+1 /* (set! hash-table-min-load ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3620,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[76]+1 /* (set! hash-table-max-load ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3629,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[77]+1 /* (set! hash-table-weak-keys ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3638,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[78]+1 /* (set! hash-table-weak-values ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3647,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[79]+1 /* (set! hash-table-has-initial? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3656,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[80]+1 /* (set! hash-table-initial ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3668,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[81]+1 /* (set! hash-table-resize! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3762,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t39=*((C_word*)lf[32]+1);
t40=C_mutate(&lf[82] /* (set! *hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3788,a[2]=t39,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp));
t41=C_mutate((C_word*)lf[83]+1 /* (set! hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3900,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t42=*((C_word*)lf[35]+1);
t43=C_mutate((C_word*)lf[84]+1 /* (set! hash-table-update! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3909,a[2]=t42,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp));
t44=*((C_word*)lf[35]+1);
t45=C_mutate(&lf[88] /* (set! *hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4207,a[2]=t44,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp));
t46=C_mutate((C_word*)lf[89]+1 /* (set! hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4419,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t47=*((C_word*)lf[35]+1);
t48=C_mutate((C_word*)lf[90]+1 /* (set! hash-table-set! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4431,a[2]=t47,a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp));
t49=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4631,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t50=*((C_word*)lf[35]+1);
t51=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5657,a[2]=t50,a[3]=((C_word)li113),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 806  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t49,t51,*((C_word*)lf[90]+1));}

/* a5656 in k1490 */
static void C_ccall f_5657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_5657r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5657r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5657r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(11);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5661,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_5661(2,t6,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5777,a[2]=t2,a[3]=t3,a[4]=((C_word)li112),tmp=(C_word)a,a+=5,tmp));}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_5661(2,t7,C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* f_5777 in a5656 in k1490 */
static void C_ccall f_5777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5777,2,t0,t1);}
/* srfi-69.scm: 809  ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[86],lf[92],lf[116],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5659 in a5656 in k1490 */
static void C_ccall f_5661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5661,2,t0,t1);}
t2=C_i_check_structure_2(((C_word*)t0)[5],lf[34],lf[92]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 813  ##sys#check-closure */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[92]);}

/* k5665 in k5659 in a5656 in k1490 */
static void C_ccall f_5667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5667,2,t0,t1);}
t2=C_slot(((C_word*)t0)[6],C_fix(1));
t3=C_slot(((C_word*)t0)[6],C_fix(3));
t4=C_slot(((C_word*)t0)[6],C_fix(4));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=C_block_size(t2);
/* srfi-69.scm: 817  hash */
t7=t4;
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[3],t6);}

/* k5677 in k5665 in k5659 in a5656 in k1490 */
static void C_ccall f_5679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5679,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5694,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li110),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5694(t7,((C_word*)t0)[2],t3);}
else{
t3=C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5736,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word)li111),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_5736(t7,((C_word*)t0)[2],t3);}}

/* loop in k5677 in k5665 in k5659 in a5656 in k1490 */
static void C_fcall f_5736(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5736,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
/* srfi-69.scm: 830  def */
t3=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5755,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_slot(t3,C_fix(0));
/* srfi-69.scm: 832  test */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k5753 in loop in k5677 in k5665 in k5659 in a5656 in k1490 */
static void C_ccall f_5755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 834  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5736(t3,((C_word*)t0)[5],t2);}}

/* loop in k5677 in k5665 in k5659 in a5656 in k1490 */
static void C_fcall f_5694(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5694,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
/* srfi-69.scm: 822  def */
t3=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_slot(t3,C_fix(1)));}
else{
t6=C_slot(t2,C_fix(1));
/* srfi-69.scm: 826  loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* k4629 in k1490 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[64],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4631,2,t0,t1);}
t2=C_mutate((C_word*)lf[92]+1 /* (set! hash-table-ref ...) */,t1);
t3=*((C_word*)lf[35]+1);
t4=C_mutate((C_word*)lf[93]+1 /* (set! hash-table-ref/default ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4633,a[2]=t3,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp));
t5=*((C_word*)lf[35]+1);
t6=C_mutate((C_word*)lf[94]+1 /* (set! hash-table-exists? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4739,a[2]=t5,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[35]+1);
t8=C_mutate((C_word*)lf[95]+1 /* (set! hash-table-delete! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4847,a[2]=t7,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate((C_word*)lf[96]+1 /* (set! hash-table-remove! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4978,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[97]+1 /* (set! hash-table-clear! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5074,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[99] /* (set! *hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5090,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[100]+1 /* (set! hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5158,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[101]+1 /* (set! hash-table-merge ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5170,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[102]+1 /* (set! hash-table->alist ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5186,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[41]+1);
t16=C_mutate((C_word*)lf[103]+1 /* (set! alist->hash-table ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5259,a[2]=t15,a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp));
t17=C_mutate((C_word*)lf[104]+1 /* (set! hash-table-keys ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5313,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[105]+1 /* (set! hash-table-values ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5378,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[106] /* (set! *hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5443,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[107] /* (set! *hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5514,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[108]+1 /* (set! hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5580,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[109]+1 /* (set! hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5592,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[110]+1 /* (set! hash-table-walk ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5604,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[111]+1 /* (set! hash-table-map ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5616,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp));
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5639,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5641,a[2]=((C_word)li109),tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 1092 ##sys#register-record-printer */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t25,lf[34],t26);}

/* a5640 in k4629 in k1490 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5641,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5645,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1095 ##sys#print */
t5=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[114],C_SCHEME_FALSE,t3);}

/* k5643 in a5640 in k4629 in k1490 */
static void C_ccall f_5645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5648,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(2));
/* srfi-69.scm: 1096 ##sys#print */
t4=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k5646 in k5643 in a5640 in k4629 in k1490 */
static void C_ccall f_5648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1097 ##sys#print */
t2=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[113],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5637 in k4629 in k1490 */
static void C_ccall f_5639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* hash-table-map in k4629 in k1490 */
static void C_ccall f_5616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5616,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[34],lf[111]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5623,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1086 ##sys#check-closure */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[111]);}

/* k5621 in hash-table-map in k4629 in k1490 */
static void C_ccall f_5623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5628,a[2]=((C_word*)t0)[4],a[3]=((C_word)li107),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 1087 *hash-table-fold */
f_5514(((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* a5627 in k5621 in hash-table-map in k4629 in k1490 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5628,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5636,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 1087 func */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k5634 in a5627 in k5621 in hash-table-map in k4629 in k1490 */
static void C_ccall f_5636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5636,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* hash-table-walk in k4629 in k1490 */
static void C_ccall f_5604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5604,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[34],lf[110]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5611,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1081 ##sys#check-closure */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[110]);}

/* k5609 in hash-table-walk in k4629 in k1490 */
static void C_ccall f_5611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1082 *hash-table-for-each */
f_5443(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-for-each in k4629 in k1490 */
static void C_ccall f_5592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5592,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[34],lf[109]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5599,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1076 ##sys#check-closure */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[109]);}

/* k5597 in hash-table-for-each in k4629 in k1490 */
static void C_ccall f_5599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1077 *hash-table-for-each */
f_5443(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-fold in k4629 in k1490 */
static void C_ccall f_5580(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5580,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[34],lf[108]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5587,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 1071 ##sys#check-closure */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[108]);}

/* k5585 in hash-table-fold in k4629 in k1490 */
static void C_ccall f_5587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1072 *hash-table-fold */
f_5514(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* *hash-table-fold in k4629 in k1490 */
static void C_fcall f_5514(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5514,NULL,4,t1,t2,t3,t4);}
t5=C_slot(t2,C_fix(1));
t6=C_block_size(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5526,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t6,a[6]=((C_word)li102),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_5526(t10,t1,C_fix(0),t4);}

/* loop in *hash-table-fold in k4629 in k1490 */
static void C_fcall f_5526(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5526,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5542,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word)li101),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5542(t8,t1,t4,t3);}}

/* fold2 in loop in *hash-table-fold in k4629 in k1490 */
static void C_fcall f_5542(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5542,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 1064 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5526(t5,t1,t4,t3);}
else{
t4=C_slot(t2,C_fix(0));
t5=C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5570,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t4,C_fix(0));
t8=C_slot(t4,C_fix(1));
/* srfi-69.scm: 1067 func */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t6,t7,t8,t3);}}

/* k5568 in fold2 in loop in *hash-table-fold in k4629 in k1490 */
static void C_ccall f_5570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1066 fold2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5542(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* *hash-table-for-each in k4629 in k1490 */
static void C_fcall f_5443(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5443,NULL,3,t1,t2,t3);}
t4=C_slot(t2,C_fix(1));
t5=C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5455,a[2]=t3,a[3]=t4,a[4]=t7,a[5]=t5,a[6]=((C_word)li99),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_5455(t9,t1,C_fix(0));}

/* doloop1360 in *hash-table-for-each in k4629 in k1490 */
static void C_fcall f_5455(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5455,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5465,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5478,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word)li98),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5478(t8,t3,t4);}}

/* loop1367 in doloop1360 in *hash-table-for-each in k4629 in k1490 */
static void C_fcall f_5478(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5478,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5486,a[2]=((C_word*)t0)[3],a[3]=((C_word)li97),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5501,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g13741375 */
t6=t3;
f_5486(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5499 in loop1367 in doloop1360 in *hash-table-for-each in k4629 in k1490 */
static void C_ccall f_5501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5478(t3,((C_word*)t0)[2],t2);}

/* g1374 in loop1367 in doloop1360 in *hash-table-for-each in k4629 in k1490 */
static void C_fcall f_5486(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5486,NULL,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(0));
t4=C_slot(t2,C_fix(1));
/* srfi-69.scm: 1052 proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* k5463 in doloop1360 in *hash-table-for-each in k4629 in k1490 */
static void C_ccall f_5465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5455(t3,((C_word*)t0)[2],t2);}

/* hash-table-values in k4629 in k1490 */
static void C_ccall f_5378(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5378,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[105]);
t4=C_slot(t2,C_fix(1));
t5=C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5393,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li95),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5393(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-values in k4629 in k1490 */
static void C_fcall f_5393(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5393,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5409,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li94),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5409(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-values in k4629 in k1490 */
static void C_fcall f_5409(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5409,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 1034 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5393(t5,t1,t4,t3);}
else{
t4=C_slot(t2,C_fix(1));
t5=C_slot(t2,C_fix(0));
t6=C_slot(t5,C_fix(1));
t7=C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 1035 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* hash-table-keys in k4629 in k1490 */
static void C_ccall f_5313(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5313,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[104]);
t4=C_slot(t2,C_fix(1));
t5=C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5328,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li92),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5328(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-keys in k4629 in k1490 */
static void C_fcall f_5328(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5328,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5344,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li91),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5344(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-keys in k4629 in k1490 */
static void C_fcall f_5344(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5344,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 1019 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5328(t5,t1,t4,t3);}
else{
t4=C_slot(t2,C_fix(1));
t5=C_slot(t2,C_fix(0));
t6=C_slot(t5,C_fix(0));
t7=C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 1020 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* alist->hash-table in k4629 in k1490 */
static void C_ccall f_5259(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5259r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5259r(t0,t1,t2,t3);}}

static void C_ccall f_5259r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=C_i_check_list_2(t2,lf[103]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5266,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t5,((C_word*)t0)[2],t3);}

/* k5264 in alist->hash-table in k4629 in k1490 */
static void C_ccall f_5266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5269,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5271,a[2]=t4,a[3]=t1,a[4]=((C_word)li89),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5271(t6,t2,((C_word*)t0)[2]);}

/* loop1308 in k5264 in alist->hash-table in k4629 in k1490 */
static void C_fcall f_5271(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5271,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5279,a[2]=((C_word*)t0)[3],a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5300,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g13151316 */
t6=t3;
f_5279(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5298 in loop1308 in k5264 in alist->hash-table in k4629 in k1490 */
static void C_ccall f_5300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5271(t3,((C_word*)t0)[2],t2);}

/* g1315 in loop1308 in k5264 in alist->hash-table in k4629 in k1490 */
static void C_fcall f_5279(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5279,NULL,3,t0,t1,t2);}
t3=C_i_check_pair_2(t2,lf[103]);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5292,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
t6=C_slot(t2,C_fix(1));
/* srfi-69.scm: 1003 *hash-table-update!/default */
t7=lf[88];
f_4207(t7,t1,((C_word*)t0)[2],t4,t5,t6);}

/* a5291 in g1315 in loop1308 in k5264 in alist->hash-table in k4629 in k1490 */
static void C_ccall f_5292(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5292,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5267 in k5264 in alist->hash-table in k4629 in k1490 */
static void C_ccall f_5269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table->alist in k4629 in k1490 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5186,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[102]);
t4=C_slot(t2,C_fix(1));
t5=C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5201,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li85),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5201(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table->alist in k4629 in k1490 */
static void C_fcall f_5201(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5201,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5217,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li84),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5217(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table->alist in k4629 in k1490 */
static void C_fcall f_5217(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5217,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 990  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5201(t5,t1,t4,t3);}
else{
t4=C_slot(t2,C_fix(1));
t5=C_slot(t2,C_fix(0));
t6=C_slot(t5,C_fix(0));
t7=C_slot(t5,C_fix(1));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,t3);
/* srfi-69.scm: 991  loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* hash-table-merge in k4629 in k1490 */
static void C_ccall f_5170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5170,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[34],lf[101]);
t5=C_i_check_structure_2(t3,lf[34],lf[101]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5184,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 976  *hash-table-copy */
t7=lf[82];
f_3788(t7,t6,t2);}

/* k5182 in hash-table-merge in k4629 in k1490 */
static void C_ccall f_5184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 976  *hash-table-merge! */
f_5090(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* hash-table-merge! in k4629 in k1490 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5158,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[34],lf[100]);
t5=C_i_check_structure_2(t3,lf[34],lf[100]);
/* srfi-69.scm: 971  *hash-table-merge! */
f_5090(t1,t2,t3);}

/* *hash-table-merge! in k4629 in k1490 */
static void C_fcall f_5090(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5090,NULL,3,t1,t2,t3);}
t4=C_slot(t3,C_fix(1));
t5=C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5102,a[2]=t4,a[3]=t7,a[4]=t2,a[5]=t5,a[6]=((C_word)li80),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_5102(t9,t1,C_fix(0));}

/* doloop1261 in *hash-table-merge! in k4629 in k1490 */
static void C_fcall f_5102(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5102,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=((C_word*)t0)[4];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5112,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5125,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word)li79),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5125(t8,t3,t4);}}

/* doloop1266 in doloop1261 in *hash-table-merge! in k4629 in k1490 */
static void C_fcall f_5125(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5125,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5138,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t3,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5151,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp);
t7=C_slot(t3,C_fix(1));
/* srfi-69.scm: 966  *hash-table-update!/default */
t8=lf[88];
f_4207(t8,t4,((C_word*)t0)[2],t5,t6,t7);}}

/* a5150 in doloop1266 in doloop1261 in *hash-table-merge! in k4629 in k1490 */
static void C_ccall f_5151(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5151,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5136 in doloop1266 in doloop1261 in *hash-table-merge! in k4629 in k1490 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5125(t3,((C_word*)t0)[2],t2);}

/* k5110 in doloop1261 in *hash-table-merge! in k4629 in k1490 */
static void C_ccall f_5112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5102(t3,((C_word*)t0)[2],t2);}

/* hash-table-clear! in k4629 in k1490 */
static void C_ccall f_5074(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5074,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[97]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5081,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_slot(t2,C_fix(1));
/* srfi-69.scm: 953  vector-fill! */
t6=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k5079 in hash-table-clear! in k4629 in k1490 */
static void C_ccall f_5081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_fix(0)));}

/* hash-table-remove! in k4629 in k1490 */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4978,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[34],lf[96]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4985,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 930  ##sys#check-closure */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[96]);}

/* k4983 in hash-table-remove! in k4629 in k1490 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4985,2,t0,t1);}
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=C_block_size(t2);
t4=C_slot(((C_word*)t0)[4],C_fix(2));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4999,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word)li75),tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_4999(t10,((C_word*)t0)[2],C_fix(0));}

/* doloop1232 in k4983 in hash-table-remove! in k4629 in k1490 */
static void C_fcall f_4999(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4999,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)((C_word*)t0)[5])[1]));}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5012,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5025,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word)li74),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_5025(t8,t3,C_SCHEME_FALSE,t4);}}

/* loop in doloop1232 in k4983 in hash-table-remove! in k4629 in k1490 */
static void C_fcall f_5025(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5025,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=C_slot(t3,C_fix(0));
t5=C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5044,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t5,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=C_slot(t4,C_fix(0));
t8=C_slot(t4,C_fix(1));
/* srfi-69.scm: 940  func */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t6,t7,t8);}}

/* k5042 in loop in doloop1232 in k4983 in hash-table-remove! in k4629 in k1490 */
static void C_ccall f_5044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[9])?C_i_setslot(((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8]):C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[8]));
t3=C_fixnum_difference(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 947  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5025(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k5010 in doloop1232 in k4983 in hash-table-remove! in k4629 in k1490 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4999(t3,((C_word*)t0)[2],t2);}

/* hash-table-delete! in k4629 in k1490 */
static void C_ccall f_4847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4847,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[34],lf[95]);
t5=C_slot(t2,C_fix(1));
t6=C_block_size(t5);
t7=C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4863,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 894  hash */
t9=t7;
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t3,t6);}

/* k4861 in hash-table-delete! in k4629 in k1490 */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4863,2,t0,t1);}
t2=C_slot(((C_word*)t0)[6],C_fix(3));
t3=C_slot(((C_word*)t0)[6],C_fix(2));
t4=C_fixnum_difference(t3,C_fix(1));
t5=C_slot(((C_word*)t0)[5],t1);
t6=C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4883,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li71),tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,f_4883(t7,C_SCHEME_FALSE,t5));}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4930,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word)li72),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_4930(t10,((C_word*)t0)[2],C_SCHEME_FALSE,t5);}}

/* loop in k4861 in hash-table-delete! in k4629 in k1490 */
static void C_fcall f_4930(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4930,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=C_slot(t3,C_fix(0));
t5=C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4949,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t5,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t7=C_slot(t4,C_fix(0));
/* srfi-69.scm: 917  test */
t8=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k4947 in loop in k4861 in hash-table-delete! in k4629 in k1490 */
static void C_ccall f_4949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[10])?C_i_setslot(((C_word*)t0)[10],C_fix(1),((C_word*)t0)[9]):C_i_setslot(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]));
t3=C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 924  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4930(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[9]);}}

/* loop in k4861 in hash-table-delete! in k4629 in k1490 */
static C_word C_fcall f_4883(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep(C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t2,C_fix(1));
t5=C_slot(t3,C_fix(0));
t6=C_eqp(((C_word*)t0)[6],t5);
if(C_truep(t6)){
t7=(C_truep(t1)?C_i_setslot(t1,C_fix(1),t4):C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t4));
t8=C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]);
return(C_SCHEME_TRUE);}
else{
t10=t2;
t11=t4;
t1=t10;
t2=t11;
goto loop;}}}

/* hash-table-exists? in k4629 in k1490 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4739,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[34],lf[94]);
t5=C_slot(t2,C_fix(1));
t6=C_slot(t2,C_fix(3));
t7=C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4755,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t6,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=C_block_size(t5);
/* srfi-69.scm: 870  hash */
t10=t7;
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t3,t9);}

/* k4753 in hash-table-exists? in k4629 in k1490 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4755,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep(t2)){
t3=C_slot(((C_word*)t0)[4],t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4770,a[2]=((C_word*)t0)[3],a[3]=((C_word)li68),tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4770(t4,t3));}
else{
t3=C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word)li69),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4810(t7,((C_word*)t0)[2],t3);}}

/* loop in k4753 in hash-table-exists? in k4629 in k1490 */
static void C_fcall f_4810(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4810,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4823,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t3,C_fix(0));
/* srfi-69.scm: 882  test */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4821 in loop in k4753 in hash-table-exists? in k4629 in k1490 */
static void C_ccall f_4823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 883  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4810(t3,((C_word*)t0)[4],t2);}}

/* loop in k4753 in hash-table-exists? in k4629 in k1490 */
static C_word C_fcall f_4770(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep(C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t2=C_slot(t1,C_fix(0));
t3=C_slot(t2,C_fix(0));
t4=C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t4);}
else{
t5=C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* hash-table-ref/default in k4629 in k1490 */
static void C_ccall f_4633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4633,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[34],lf[93]);
t6=C_slot(t2,C_fix(1));
t7=C_slot(t2,C_fix(3));
t8=C_slot(t2,C_fix(4));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4649,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t6,a[6]=t7,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t10=C_block_size(t6);
/* srfi-69.scm: 844  hash */
t11=t8;
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t3,t10);}

/* k4647 in hash-table-ref/default in k4629 in k1490 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4649,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=C_slot(((C_word*)t0)[5],t1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4664,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4664(t4,t3));}
else{
t3=C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4703,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word)li66),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_4703(t7,((C_word*)t0)[2],t3);}}

/* loop in k4647 in hash-table-ref/default in k4629 in k1490 */
static void C_fcall f_4703(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4703,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=((C_word*)t0)[5];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4719,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_slot(t3,C_fix(0));
/* srfi-69.scm: 859  test */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4717 in loop in k4647 in hash-table-ref/default in k4629 in k1490 */
static void C_ccall f_4719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 861  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4703(t3,((C_word*)t0)[5],t2);}}

/* loop in k4647 in hash-table-ref/default in k4629 in k1490 */
static C_word C_fcall f_4664(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[3];
return(t2);}
else{
t2=C_slot(t1,C_fix(0));
t3=C_slot(t2,C_fix(0));
t4=C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(C_slot(t2,C_fix(1)));}
else{
t5=C_slot(t1,C_fix(1));
t8=t5;
t1=t8;
goto loop;}}}

/* hash-table-set! in k1490 */
static void C_ccall f_4431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[20],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4431,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[34],lf[90]);
t6=C_slot(t2,C_fix(2));
t7=C_fixnum_plus(t6,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4498,a[2]=t7,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t9=t2;
t10=C_slot(t9,C_fix(1));
t11=C_slot(t9,C_fix(5));
t12=C_slot(t9,C_fix(6));
t13=C_block_size(t10);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4491,a[2]=t12,a[3]=t7,a[4]=t13,a[5]=t10,a[6]=t9,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t15=C_a_i_times(&a,2,t13,t11);
/* srfi-69.scm: 634  floor */
t16=*((C_word*)lf[85]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t14,t15);}

/* k4489 in hash-table-set! in k1490 */
static void C_ccall f_4491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4491,2,t0,t1);}
t2=C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4483,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_a_i_times(&a,2,((C_word*)t0)[4],((C_word*)t0)[2]);
/* srfi-69.scm: 635  floor */
t5=*((C_word*)lf[85]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4481 in k4489 in hash-table-set! in k1490 */
static void C_ccall f_4483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4483,2,t0,t1);}
t2=C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4464,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[4],C_fix(1073741823)))){
t4=C_fixnum_less_or_equal_p(((C_word*)t0)[3],((C_word*)t0)[2]);
t5=t3;
f_4464(t5,(C_truep(t4)?C_fixnum_less_or_equal_p(((C_word*)t0)[2],t2):C_SCHEME_FALSE));}
else{
t4=t3;
f_4464(t4,C_SCHEME_FALSE);}}

/* k4462 in k4481 in k4489 in hash-table-set! in k1490 */
static void C_fcall f_4464(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 638  hash-table-resize! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[81]+1)))(5,*((C_word*)lf[81]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_4498(2,t3,t2);}}

/* k4496 in hash-table-set! in k1490 */
static void C_ccall f_4498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4498,2,t0,t1);}
t2=C_slot(((C_word*)t0)[7],C_fix(4));
t3=C_slot(((C_word*)t0)[7],C_fix(3));
t4=C_slot(((C_word*)t0)[7],C_fix(1));
t5=C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm: 778  hash */
t7=t2;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[4],t5);}

/* k4511 in k4496 in hash-table-set! in k1490 */
static void C_ccall f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4513,2,t0,t1);}
t2=C_slot(((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4519,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t4=C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4530,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word)li62),tmp=(C_word)a,a+=11,tmp));
t8=((C_word*)t6)[1];
f_4530(t8,t3,t2);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4579,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word)li63),tmp=(C_word)a,a+=12,tmp));
t8=((C_word*)t6)[1];
f_4579(t8,t3,t2);}}

/* loop in k4511 in k4496 in hash-table-set! in k1490 */
static void C_fcall f_4579(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4579,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
t5=C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_set_i_slot(((C_word*)t0)[5],C_fix(2),((C_word*)t0)[4]));}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4609,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[9],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t3,C_fix(0));
/* srfi-69.scm: 798  test */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[10],t5);}}

/* k4607 in loop in k4511 in k4496 in hash-table-set! in k1490 */
static void C_ccall f_4609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4]));}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 800  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4579(t3,((C_word*)t0)[6],t2);}}

/* loop in k4511 in k4496 in hash-table-set! in k1490 */
static void C_fcall f_4530(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4530,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[7]);
t5=C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]));}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=C_eqp(((C_word*)t0)[9],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_setslot(t3,C_fix(1),((C_word*)t0)[8]));}
else{
t6=C_slot(t2,C_fix(1));
/* srfi-69.scm: 790  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k4517 in k4511 in k4496 in hash-table-set! in k1490 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[91]+1));}

/* hash-table-update!/default in k1490 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4419,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_check_structure_2(t2,lf[34],lf[89]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4426,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 765  ##sys#check-closure */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t4,lf[89]);}

/* k4424 in hash-table-update!/default in k1490 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 766  *hash-table-update!/default */
t2=lf[88];
f_4207(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* *hash-table-update!/default in k1490 */
static void C_fcall f_4207(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4207,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_slot(t2,C_fix(2));
t7=C_fixnum_plus(t6,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4271,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t7,a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t9=t2;
t10=C_slot(t9,C_fix(1));
t11=C_slot(t9,C_fix(5));
t12=C_slot(t9,C_fix(6));
t13=C_block_size(t10);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4264,a[2]=t12,a[3]=t7,a[4]=t13,a[5]=t10,a[6]=t9,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t15=C_a_i_times(&a,2,t13,t11);
/* srfi-69.scm: 634  floor */
t16=*((C_word*)lf[85]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t14,t15);}

/* k4262 in *hash-table-update!/default in k1490 */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4264,2,t0,t1);}
t2=C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4256,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_a_i_times(&a,2,((C_word*)t0)[4],((C_word*)t0)[2]);
/* srfi-69.scm: 635  floor */
t5=*((C_word*)lf[85]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4254 in k4262 in *hash-table-update!/default in k1490 */
static void C_ccall f_4256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4256,2,t0,t1);}
t2=C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4237,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[4],C_fix(1073741823)))){
t4=C_fixnum_less_or_equal_p(((C_word*)t0)[3],((C_word*)t0)[2]);
t5=t3;
f_4237(t5,(C_truep(t4)?C_fixnum_less_or_equal_p(((C_word*)t0)[2],t2):C_SCHEME_FALSE));}
else{
t4=t3;
f_4237(t4,C_SCHEME_FALSE);}}

/* k4235 in k4254 in k4262 in *hash-table-update!/default in k1490 */
static void C_fcall f_4237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 638  hash-table-resize! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[81]+1)))(5,*((C_word*)lf[81]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_4271(2,t3,t2);}}

/* k4269 in *hash-table-update!/default in k1490 */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4271,2,t0,t1);}
t2=C_slot(((C_word*)t0)[8],C_fix(4));
t3=C_slot(((C_word*)t0)[8],C_fix(3));
t4=C_slot(((C_word*)t0)[8],C_fix(1));
t5=C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm: 733  hash */
t7=t2;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k4284 in k4269 in *hash-table-update!/default in k1490 */
static void C_ccall f_4286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4286,2,t0,t1);}
t2=C_slot(((C_word*)t0)[10],t1);
t3=C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4300,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word)li58),tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_4300(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4359,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],a[12]=((C_word)li59),tmp=(C_word)a,a+=13,tmp));
t7=((C_word*)t5)[1];
f_4359(t7,((C_word*)t0)[2],t2);}}

/* loop in k4284 in k4269 in *hash-table-update!/default in k1490 */
static void C_fcall f_4359(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4359,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4369,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 752  func */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4392,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t3,C_fix(0));
/* srfi-69.scm: 757  test */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k4390 in loop in k4284 in k4269 in *hash-table-update!/default in k1490 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4392,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4395,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 758  func */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 761  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4359(t3,((C_word*)t0)[5],t2);}}

/* k4393 in k4390 in loop in k4284 in k4269 in *hash-table-update!/default in k1490 */
static void C_ccall f_4395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4367 in loop in k4284 in k4269 in *hash-table-update!/default in k1490 */
static void C_ccall f_4369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4369,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* loop in k4284 in k4269 in *hash-table-update!/default in k1490 */
static void C_fcall f_4300(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4300,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4310,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 739  func */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4336,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=C_slot(t3,C_fix(1));
/* srfi-69.scm: 745  func */
t8=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t6=C_slot(t2,C_fix(1));
/* srfi-69.scm: 748  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k4334 in loop in k4284 in k4269 in *hash-table-update!/default in k1490 */
static void C_ccall f_4336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4308 in loop in k4284 in k4269 in *hash-table-update!/default in k1490 */
static void C_ccall f_4310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4310,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* hash-table-update! in k1490 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4r,(void*)f_3909r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3909r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3909r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(16);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3911,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li52),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4139,a[2]=t3,a[3]=t5,a[4]=t2,a[5]=((C_word)li54),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4156,a[2]=t6,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
/* def-func9551016 */
t8=t7;
f_4156(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
/* def-thunk9561008 */
t10=t6;
f_4139(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* body953961 */
t12=t5;
f_3911(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-func955 in hash-table-update! in k1490 */
static void C_fcall f_4156(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4156,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4162,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
/* def-thunk9561008 */
t3=((C_word*)t0)[2];
f_4139(t3,t1,t2);}

/* a4161 in def-func955 in hash-table-update! in k1490 */
static void C_ccall f_4162(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4162,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* def-thunk956 in hash-table-update! in k1490 */
static void C_fcall f_4139(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4139,NULL,3,t0,t1,t2);}
t3=C_slot(((C_word*)t0)[4],C_fix(9));
if(C_truep(t3)){
/* body953961 */
t4=((C_word*)t0)[3];
f_3911(t4,t1,t2,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4151,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp);
/* body953961 */
t5=((C_word*)t0)[3];
f_3911(t5,t1,t2,t4);}}

/* f_4151 in def-thunk956 in hash-table-update! in k1490 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4151,2,t0,t1);}
/* srfi-69.scm: 682  ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[86],lf[84],lf[87],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* body953 in hash-table-update! in k1490 */
static void C_fcall f_3911(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3911,NULL,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(((C_word*)t0)[4],lf[34],lf[84]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3918,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 686  ##sys#check-closure */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[84]);}

/* k3916 in body953 in hash-table-update! in k1490 */
static void C_ccall f_3918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 687  ##sys#check-closure */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[84]);}

/* k3919 in k3916 in body953 in hash-table-update! in k1490 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3921,2,t0,t1);}
t2=C_slot(((C_word*)t0)[7],C_fix(2));
t3=C_fixnum_plus(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[7];
t6=C_slot(t5,C_fix(1));
t7=C_slot(t5,C_fix(5));
t8=C_slot(t5,C_fix(6));
t9=C_block_size(t6);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3977,a[2]=t8,a[3]=t3,a[4]=t9,a[5]=t6,a[6]=t5,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
t11=C_a_i_times(&a,2,t9,t7);
/* srfi-69.scm: 634  floor */
t12=*((C_word*)lf[85]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}

/* k3975 in k3919 in k3916 in body953 in hash-table-update! in k1490 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3977,2,t0,t1);}
t2=C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_a_i_times(&a,2,((C_word*)t0)[4],((C_word*)t0)[2]);
/* srfi-69.scm: 635  floor */
t5=*((C_word*)lf[85]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3967 in k3975 in k3919 in k3916 in body953 in hash-table-update! in k1490 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3969,2,t0,t1);}
t2=C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3950,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[4],C_fix(1073741823)))){
t4=C_fixnum_less_or_equal_p(((C_word*)t0)[3],((C_word*)t0)[2]);
t5=t3;
f_3950(t5,(C_truep(t4)?C_fixnum_less_or_equal_p(((C_word*)t0)[2],t2):C_SCHEME_FALSE));}
else{
t4=t3;
f_3950(t4,C_SCHEME_FALSE);}}

/* k3948 in k3967 in k3975 in k3919 in k3916 in body953 in hash-table-update! in k1490 */
static void C_fcall f_3950(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 638  hash-table-resize! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[81]+1)))(5,*((C_word*)lf[81]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_3984(2,t3,t2);}}

/* k3982 in k3919 in k3916 in body953 in hash-table-update! in k1490 */
static void C_ccall f_3984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3984,2,t0,t1);}
t2=C_slot(((C_word*)t0)[8],C_fix(4));
t3=C_slot(((C_word*)t0)[8],C_fix(3));
t4=C_slot(((C_word*)t0)[8],C_fix(1));
t5=C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm: 694  hash */
t7=t2;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k3997 in k3982 in k3919 in k3916 in body953 in hash-table-update! in k1490 */
static void C_ccall f_3999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3999,2,t0,t1);}
t2=C_slot(((C_word*)t0)[10],t1);
t3=C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4013,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word)li50),tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_4013(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],a[12]=((C_word)li51),tmp=(C_word)a,a+=13,tmp));
t7=((C_word*)t5)[1];
f_4076(t7,((C_word*)t0)[2],t2);}}

/* loop in k3997 in k3982 in k3919 in k3916 in body953 in hash-table-update! in k1490 */
static void C_fcall f_4076(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4076,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4086,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4104,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 713  thunk */
t5=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4113,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t3,C_fix(0));
/* srfi-69.scm: 718  test */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k4111 in loop in k3997 in k3982 in k3919 in k3916 in body953 in hash-table-update! in k1490 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4113,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4116,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 719  func */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 722  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4076(t3,((C_word*)t0)[5],t2);}}

/* k4114 in k4111 in loop in k3997 in k3982 in k3919 in k3916 in body953 in hash-table-update! in k1490 */
static void C_ccall f_4116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4102 in loop in k3997 in k3982 in k3919 in k3916 in body953 in hash-table-update! in k1490 */
static void C_ccall f_4104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 713  func */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4084 in loop in k3997 in k3982 in k3919 in k3916 in body953 in hash-table-update! in k1490 */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4086,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* loop in k3997 in k3982 in k3919 in k3916 in body953 in hash-table-update! in k1490 */
static void C_fcall f_4013(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4013,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4023,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4041,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 700  thunk */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4053,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=C_slot(t3,C_fix(1));
/* srfi-69.scm: 706  func */
t8=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t6=C_slot(t2,C_fix(1));
/* srfi-69.scm: 709  loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}}}

/* k4051 in loop in k3997 in k3982 in k3919 in k3916 in body953 in hash-table-update! in k1490 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4039 in loop in k3997 in k3982 in k3919 in k3916 in body953 in hash-table-update! in k1490 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 700  func */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4021 in loop in k3997 in k3982 in k3919 in k3916 in body953 in hash-table-update! in k1490 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4023,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* hash-table-copy in k1490 */
static void C_ccall f_3900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3900,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[83]);
/* srfi-69.scm: 667  *hash-table-copy */
t4=lf[82];
f_3788(t4,t1,t2);}

/* *hash-table-copy in k1490 */
static void C_fcall f_3788(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3788,NULL,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(1));
t4=C_block_size(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3798,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 647  make-vector */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,C_SCHEME_END_OF_LIST);}

/* k3796 in *hash-table-copy in k1490 */
static void C_ccall f_3798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3798,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3803,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li47),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3803(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop924 in k3796 in *hash-table-copy in k1490 */
static void C_fcall f_3803(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3803,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=C_slot(((C_word*)t0)[5],C_fix(3));
t4=C_slot(((C_word*)t0)[5],C_fix(4));
t5=C_slot(((C_word*)t0)[5],C_fix(2));
t6=C_slot(((C_word*)t0)[5],C_fix(5));
t7=C_slot(((C_word*)t0)[5],C_fix(6));
t8=C_slot(((C_word*)t0)[5],C_fix(7));
t9=C_slot(((C_word*)t0)[5],C_fix(8));
t10=C_slot(((C_word*)t0)[5],C_fix(9));
/* srfi-69.scm: 650  *make-hash-table */
t11=lf[33];
f_3193(t11,t1,t3,t4,t5,t6,t7,t10,C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3859,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3865,a[2]=t6,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3865(t8,t3,t4);}}

/* copy-loop in doloop924 in k3796 in *hash-table-copy in k1490 */
static void C_fcall f_3865(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3865,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=C_slot(t3,C_fix(1));
t6=C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3886,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=C_slot(t2,C_fix(1));
/* srfi-69.scm: 663  copy-loop */
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k3884 in copy-loop in doloop924 in k3796 in *hash-table-copy in k1490 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3886,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3857 in doloop924 in k3796 in *hash-table-copy in k1490 */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3803(t4,((C_word*)t0)[2],t3);}

/* hash-table-resize! in k1490 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3762,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3766,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_fixnum_times(t4,C_fix(2));
/* srfi-69.scm: 621  fxmin */
t7=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,C_fix(1073741823),t6);}

/* k3764 in hash-table-resize! in k1490 */
static void C_ccall f_3766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 622  hash-table-canonical-length */
f_3163(t2,lf[29],t1);}

/* k3767 in k3764 in hash-table-resize! in k1490 */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 623  make-vector */
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_SCHEME_END_OF_LIST);}

/* k3770 in k3767 in k3764 in hash-table-resize! in k1490 */
static void C_ccall f_3772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3775,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[3],C_fix(4));
t4=((C_word*)t0)[2];
t5=t1;
t6=C_block_size(t4);
t7=C_block_size(t5);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3695,a[2]=t7,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t9,a[7]=t6,a[8]=((C_word)li44),tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_3695(t11,t2,C_fix(0));}

/* doloop891 in k3770 in k3767 in k3764 in hash-table-resize! in k1490 */
static void C_fcall f_3695(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3695,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3705,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=((C_word)li43),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3718(t8,t3,t4);}}

/* loop in doloop891 in k3770 in k3767 in k3764 in hash-table-resize! in k1490 */
static void C_fcall f_3718(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3718,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3734,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 613  hash */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,((C_word*)t0)[2]);}}

/* k3732 in loop in doloop891 in k3770 in k3767 in k3764 in hash-table-resize! in k1490 */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3734,2,t0,t1);}
t2=C_slot(((C_word*)t0)[7],C_fix(1));
t3=C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=C_slot(((C_word*)t0)[5],t1);
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_i_setslot(((C_word*)t0)[5],t1,t5);
t7=C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 616  loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3718(t8,((C_word*)t0)[2],t7);}

/* k3703 in doloop891 in k3770 in k3767 in k3764 in hash-table-resize! in k1490 */
static void C_ccall f_3705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3695(t3,((C_word*)t0)[2],t2);}

/* k3773 in k3770 in k3767 in k3764 in hash-table-resize! in k1490 */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]));}

/* hash-table-initial in k1490 */
static void C_ccall f_3668(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3668,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[80]);
t4=C_slot(t2,C_fix(9));
if(C_truep(t4)){
/* srfi-69.scm: 600  thunk */
t5=t4;
((C_proc2)C_retrieve_proc(t5))(2,t5,t1);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* hash-table-has-initial? in k1490 */
static void C_ccall f_3656(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3656,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[79]);
t4=C_slot(t2,C_fix(9));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* hash-table-weak-values in k1490 */
static void C_ccall f_3647(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3647,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[78]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(8)));}

/* hash-table-weak-keys in k1490 */
static void C_ccall f_3638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3638,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[77]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(7)));}

/* hash-table-max-load in k1490 */
static void C_ccall f_3629(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3629,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[76]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(6)));}

/* hash-table-min-load in k1490 */
static void C_ccall f_3620(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3620,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[75]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(5)));}

/* hash-table-hash-function in k1490 */
static void C_ccall f_3611(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3611,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[74]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(4)));}

/* hash-table-equivalence-function in k1490 */
static void C_ccall f_3602(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3602,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[73]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(3)));}

/* hash-table-size in k1490 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3593,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[72]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(2)));}

/* hash-table? in k1490 */
static void C_ccall f_3587(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3587,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[34]));}

/* make-hash-table in k1490 */
static void C_ccall f_3224(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+41)){
C_save_and_reclaim((void*)tr2r,(void*)f_3224r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3224r(t0,t1,t2);}}

static void C_ccall f_3224r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(41);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[37]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(307);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=lf[42];
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=lf[43];
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3226,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3302,a[2]=t4,a[3]=t2,a[4]=t17,a[5]=t12,a[6]=t16,a[7]=t14,a[8]=t6,a[9]=t1,a[10]=t8,a[11]=t10,tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_nullp(((C_word*)t4)[1]))){
t19=t18;
f_3302(t19,C_SCHEME_UNDEFINED);}
else{
t19=C_i_car(((C_word*)t4)[1]);
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3577,a[2]=t4,a[3]=t19,a[4]=t6,a[5]=t18,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 479  keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t20,t19);}}

/* k3575 in make-hash-table in k1490 */
static void C_ccall f_3577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3577,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_3302(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3580,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 480  ##sys#check-closure */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[41]);}}

/* k3578 in k3575 in make-hash-table in k1490 */
static void C_ccall f_3580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3302(t5,t4);}

/* k3300 in make-hash-table in k1490 */
static void C_fcall f_3302(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3302,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_3305(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3557,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 485  keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t4,t3);}}

/* k3555 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3557,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_3305(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3560,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 486  ##sys#check-closure */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[41]);}}

/* k3558 in k3555 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3305(t5,t4);}

/* k3303 in k3300 in make-hash-table in k1490 */
static void C_fcall f_3305(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3305,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_3308(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 491  keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t4,t3);}}

/* k3523 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3525,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_3308(t3,t2);}
else{
t2=C_i_check_exact_2(((C_word*)t0)[4],lf[41]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(C_fix(0),((C_word*)t0)[4]))){
t4=t3;
f_3531(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 494  error */
t4=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[41],lf[70],((C_word*)t0)[4]);}}}

/* k3529 in k3523 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3535,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 495  fxmin */
t3=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[53]+1),((C_word*)t0)[2]);}

/* k3533 in k3529 in k3523 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3308(t5,t4);}

/* k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_fcall f_3308(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3308,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3343,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[8],a[8]=t4,a[9]=((C_word*)t0)[3],a[10]=((C_word)li31),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_3343(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_fcall f_3343(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3343,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3354,a[2]=((C_word*)t0)[9],a[3]=t3,a[4]=((C_word)li29),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3364,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* srfi-69.scm: 504  keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t5,t3);}}

/* k3362 in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3364,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t3;
f_3370(2,t4,C_i_car(t2));}
else{
/* srfi-69.scm: 508  invarg-err */
t4=((C_word*)t0)[2];
f_3354(t4,t3,lf[68]);}}
else{
/* srfi-69.scm: 540  invarg-err */
t2=((C_word*)t0)[2];
f_3354(t2,((C_word*)t0)[10],lf[69]);}}

/* k3368 in k3362 in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3373,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
t3=C_eqp(((C_word*)t0)[9],lf[49]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3386,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t1,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 511  ##sys#check-closure */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t1,lf[41]);}
else{
t4=C_eqp(((C_word*)t0)[9],lf[51]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3396,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 514  ##sys#check-closure */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t1,lf[41]);}
else{
t5=C_eqp(((C_word*)t0)[9],lf[52]);
if(C_truep(t5)){
t6=C_i_check_exact_2(t1,lf[41]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3409,a[2]=t1,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_fixnum_lessp(C_fix(0),t1))){
t8=t7;
f_3409(2,t8,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 519  error */
t8=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[41],lf[54],t1);}}
else{
t6=C_eqp(((C_word*)t0)[9],lf[55]);
if(C_truep(t6)){
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3427,a[2]=t1,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp));
t8=C_i_cdr(((C_word*)t0)[12]);
/* srfi-69.scm: 539  loop */
t9=((C_word*)((C_word*)t0)[11])[1];
f_3343(t9,((C_word*)t0)[10],t8);}
else{
t7=C_eqp(((C_word*)t0)[9],lf[56]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3437,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 524  ##sys#check-inexact */
((C_proc4)C_retrieve_proc(*((C_word*)lf[60]+1)))(4,*((C_word*)lf[60]+1),t8,t1,lf[41]);}
else{
t8=C_eqp(((C_word*)t0)[9],lf[61]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3462,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 529  ##sys#check-inexact */
((C_proc4)C_retrieve_proc(*((C_word*)lf[60]+1)))(4,*((C_word*)lf[60]+1),t9,t1,lf[41]);}
else{
t9=C_eqp(((C_word*)t0)[9],lf[65]);
if(C_truep(t9)){
if(C_truep(t1)){
t10=C_i_cdr(((C_word*)t0)[12]);
/* srfi-69.scm: 539  loop */
t11=((C_word*)((C_word*)t0)[11])[1];
f_3343(t11,((C_word*)t0)[10],t10);}
else{
t10=C_i_cdr(((C_word*)t0)[12]);
/* srfi-69.scm: 539  loop */
t11=((C_word*)((C_word*)t0)[11])[1];
f_3343(t11,((C_word*)t0)[10],t10);}}
else{
t10=C_eqp(((C_word*)t0)[9],lf[66]);
if(C_truep(t10)){
if(C_truep(t1)){
t11=C_i_cdr(((C_word*)t0)[12]);
/* srfi-69.scm: 539  loop */
t12=((C_word*)((C_word*)t0)[11])[1];
f_3343(t12,((C_word*)t0)[10],t11);}
else{
t11=C_i_cdr(((C_word*)t0)[12]);
/* srfi-69.scm: 539  loop */
t12=((C_word*)((C_word*)t0)[11])[1];
f_3343(t12,((C_word*)t0)[10],t11);}}
else{
/* srfi-69.scm: 538  invarg-err */
t11=((C_word*)t0)[2];
f_3354(t11,t2,lf[67]);}}}}}}}}}

/* k3460 in k3368 in k3362 in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3469,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3475,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 530  fp< */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[64],((C_word*)t0)[5]);}

/* k3473 in k3460 in k3368 in k3362 in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 530  fp< */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[63]);}
else{
t2=((C_word*)t0)[3];
f_3469(2,t2,C_SCHEME_FALSE);}}

/* k3467 in k3460 in k3368 in k3362 in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_i_cdr(((C_word*)t0)[5]);
/* srfi-69.scm: 539  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3343(t4,((C_word*)t0)[3],t3);}
else{
/* srfi-69.scm: 531  error */
t2=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[41],lf[62],((C_word*)t0)[6]);}}

/* k3463 in k3460 in k3368 in k3362 in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 539  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3343(t4,((C_word*)t0)[2],t3);}

/* k3435 in k3368 in k3362 in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3444,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3450,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 525  fp< */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[59],((C_word*)t0)[5]);}

/* k3448 in k3435 in k3368 in k3362 in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 525  fp< */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[58]);}
else{
t2=((C_word*)t0)[3];
f_3444(2,t2,C_SCHEME_FALSE);}}

/* k3442 in k3435 in k3368 in k3362 in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_i_cdr(((C_word*)t0)[5]);
/* srfi-69.scm: 539  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3343(t4,((C_word*)t0)[3],t3);}
else{
/* srfi-69.scm: 526  error */
t2=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[41],lf[57],((C_word*)t0)[6]);}}

/* k3438 in k3435 in k3368 in k3362 in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 539  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3343(t4,((C_word*)t0)[2],t3);}

/* f_3427 in k3368 in k3362 in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3427,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3407 in k3368 in k3362 in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3413,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 520  fxmin */
t3=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[53]+1),((C_word*)t0)[2]);}

/* k3411 in k3407 in k3368 in k3362 in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 539  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3343(t4,((C_word*)t0)[2],t3);}

/* k3394 in k3368 in k3362 in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 539  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3343(t4,((C_word*)t0)[2],t3);}

/* k3384 in k3368 in k3362 in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 539  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3343(t4,((C_word*)t0)[2],t3);}

/* k3371 in k3368 in k3362 in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 539  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3343(t3,((C_word*)t0)[2],t2);}

/* invarg-err in loop in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_fcall f_3354(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3354,NULL,3,t0,t1,t2);}
/* srfi-69.scm: 503  error */
t3=*((C_word*)lf[46]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[41],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3309 in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3338,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 542  fp< */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[5])[1]);}

/* k3336 in k3309 in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 543  error */
t2=*((C_word*)lf[46]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[41],lf[47],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[4];
f_3314(2,t2,C_SCHEME_UNDEFINED);}}

/* k3312 in k3309 in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm: 545  hash-table-canonical-length */
f_3163(t2,lf[29],((C_word*)((C_word*)t0)[9])[1]);}

/* k3316 in k3312 in k3309 in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3318,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
/* srfi-69.scm: 555  *make-hash-table */
t3=lf[33];
f_3193(t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST);}
else{
t3=f_3226(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=C_mutate(((C_word *)((C_word*)t0)[8])+1,t3);
/* srfi-69.scm: 555  *make-hash-table */
t5=lf[33];
f_3193(t5,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 552  warning */
((C_proc4)C_retrieve_proc(*((C_word*)lf[44]+1)))(4,*((C_word*)lf[44]+1),t4,lf[41],lf[45]);}}}

/* k3332 in k3316 in k3312 in k3309 in k3306 in k3303 in k3300 in make-hash-table in k1490 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[22]+1));
/* srfi-69.scm: 555  *make-hash-table */
t3=lf[33];
f_3193(t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* hash-for-test in make-hash-table in k1490 */
static C_word C_fcall f_3226(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_stack_check;
t1=C_eqp(((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t2=(C_truep(t1)?t1:C_eqp(*((C_word*)lf[35]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t2)){
t3=*((C_word*)lf[17]+1);
return(t3);}
else{
t3=C_eqp(((C_word*)t0)[6],((C_word*)((C_word*)t0)[7])[1]);
t4=(C_truep(t3)?t3:C_eqp(*((C_word*)lf[36]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t4)){
return(*((C_word*)lf[19]+1));}
else{
t5=C_eqp(((C_word*)t0)[5],((C_word*)((C_word*)t0)[7])[1]);
t6=(C_truep(t5)?t5:C_eqp(*((C_word*)lf[37]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t6)){
t7=*((C_word*)lf[22]+1);
return(t7);}
else{
t7=C_eqp(((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1]);
t8=(C_truep(t7)?t7:C_eqp(*((C_word*)lf[38]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t8)){
return(*((C_word*)lf[24]+1));}
else{
t9=C_eqp(((C_word*)t0)[3],((C_word*)((C_word*)t0)[7])[1]);
t10=(C_truep(t9)?t9:C_eqp(*((C_word*)lf[39]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t10)){
t11=*((C_word*)lf[28]+1);
return(t11);}
else{
t11=C_eqp(((C_word*)t0)[2],((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t11)){
return((C_truep(t11)?*((C_word*)lf[4]+1):C_SCHEME_FALSE));}
else{
t12=C_eqp(*((C_word*)lf[40]+1),((C_word*)((C_word*)t0)[7])[1]);
return((C_truep(t12)?*((C_word*)lf[4]+1):C_SCHEME_FALSE));}}}}}}}

/* *make-hash-table in k1490 */
static void C_fcall f_3193(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3193,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3197,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_nullp(t8))){
/* srfi-69.scm: 427  make-vector */
t10=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t4,C_SCHEME_END_OF_LIST);}
else{
t10=C_i_cdr(t8);
if(C_truep(C_i_nullp(t10))){
t11=t9;
f_3197(2,t11,C_i_car(t8));}
else{
/* ##sys#error */
t11=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[0],t8);}}}

/* k3195 in *make-hash-table in k1490 */
static void C_ccall f_3197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3197,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_record(&a,10,lf[34],t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]));}

/* hash-table-canonical-length in k1490 */
static void C_fcall f_3163(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3163,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3169,a[2]=t3,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3169(t4,t2));}

/* loop in hash-table-canonical-length in k1490 */
static C_word C_fcall f_3169(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=C_slot(t1,C_fix(0));
t3=C_slot(t1,C_fix(1));
t4=C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
if(C_truep(t4)){
return(t2);}
else{
t6=t3;
t1=t6;
goto loop;}}
else{
if(C_truep(C_i_nullp(t3))){
return(t2);}
else{
t6=t3;
t1=t6;
goto loop;}}}

/* string-ci-hash in k1490 */
static void C_ccall f_3020(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_3020r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3020r(t0,t1,t2,t3);}}

static void C_ccall f_3020r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(17);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t8=C_i_check_string_2(t2,lf[27]);
t9=C_i_check_exact_2(t5,lf[27]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3036,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t7))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3073,a[2]=t2,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3092,a[2]=t11,a[3]=t2,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3101,a[2]=t12,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t7))){
/* def-start642655 */
t14=t13;
f_3101(t14,t10);}
else{
t14=C_i_car(t7);
t15=C_i_cdr(t7);
if(C_truep(C_i_nullp(t15))){
/* def-end643653 */
t16=t12;
f_3092(t16,t10,t14);}
else{
t16=C_i_car(t15);
t17=C_i_cdr(t15);
if(C_truep(C_i_nullp(t17))){
/* body640648 */
t18=t11;
f_3073(t18,t10,t14,t16);}
else{
/* ##sys#error */
t18=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t10,lf[0],t17);}}}}
else{
t11=t10;
f_3036(2,t11,t2);}}

/* def-start642 in string-ci-hash in k1490 */
static void C_fcall f_3101(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3101,NULL,2,t0,t1);}
/* def-end643653 */
t2=((C_word*)t0)[2];
f_3092(t2,t1,C_fix(0));}

/* def-end643 in string-ci-hash in k1490 */
static void C_fcall f_3092(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3092,NULL,3,t0,t1,t2);}
t3=C_block_size(((C_word*)t0)[3]);
/* body640648 */
t4=((C_word*)t0)[2];
f_3073(t4,t1,t2,t3);}

/* body640 in string-ci-hash in k1490 */
static void C_fcall f_3073(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3073,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3077,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_block_size(((C_word*)t0)[2]);
/* srfi-69.scm: 375  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[26]+1)))(6,*((C_word*)lf[26]+1),t4,t2,C_fix(0),t5,lf[28]);}

/* k3075 in body640 in string-ci-hash in k1490 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3080,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_block_size(((C_word*)t0)[4]);
/* srfi-69.scm: 376  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[26]+1)))(6,*((C_word*)lf[26]+1),t2,((C_word*)t0)[2],C_fix(0),t3,lf[28]);}

/* k3078 in k3075 in body640 in string-ci-hash in k1490 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 377  ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[25]+1)))(5,*((C_word*)lf[25]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3034 in string-ci-hash in k1490 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_hash_string_ci(t1);
t3=((C_word*)t0)[3];
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
t4=C_fixnum_negate(t2);
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm: 135  fxmod */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[2]);}
else{
t4=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t2);
/* srfi-69.scm: 135  fxmod */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}}

/* string-hash in k1490 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_2879r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2879r(t0,t1,t2,t3);}}

static void C_ccall f_2879r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(17);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t8=C_i_check_string_2(t2,lf[24]);
t9=C_i_check_exact_2(t5,lf[24]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2895,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t7))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2932,a[2]=t2,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2951,a[2]=t11,a[3]=t2,a[4]=((C_word)li19),tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2960,a[2]=t12,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t7))){
/* def-start583596 */
t14=t13;
f_2960(t14,t10);}
else{
t14=C_i_car(t7);
t15=C_i_cdr(t7);
if(C_truep(C_i_nullp(t15))){
/* def-end584594 */
t16=t12;
f_2951(t16,t10,t14);}
else{
t16=C_i_car(t15);
t17=C_i_cdr(t15);
if(C_truep(C_i_nullp(t17))){
/* body581589 */
t18=t11;
f_2932(t18,t10,t14,t16);}
else{
/* ##sys#error */
t18=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t10,lf[0],t17);}}}}
else{
t11=t10;
f_2895(2,t11,t2);}}

/* def-start583 in string-hash in k1490 */
static void C_fcall f_2960(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2960,NULL,2,t0,t1);}
/* def-end584594 */
t2=((C_word*)t0)[2];
f_2951(t2,t1,C_fix(0));}

/* def-end584 in string-hash in k1490 */
static void C_fcall f_2951(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2951,NULL,3,t0,t1,t2);}
t3=C_block_size(((C_word*)t0)[3]);
/* body581589 */
t4=((C_word*)t0)[2];
f_2932(t4,t1,t2,t3);}

/* body581 in string-hash in k1490 */
static void C_fcall f_2932(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2932,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2936,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_block_size(((C_word*)t0)[2]);
/* srfi-69.scm: 363  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[26]+1)))(6,*((C_word*)lf[26]+1),t4,t2,C_fix(0),t5,lf[24]);}

/* k2934 in body581 in string-hash in k1490 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_block_size(((C_word*)t0)[4]);
/* srfi-69.scm: 364  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[26]+1)))(6,*((C_word*)lf[26]+1),t2,((C_word*)t0)[2],C_fix(0),t3,lf[24]);}

/* k2937 in k2934 in body581 in string-hash in k1490 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 365  ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[25]+1)))(5,*((C_word*)lf[25]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2893 in string-hash in k1490 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_hash_string(t1);
t3=((C_word*)t0)[3];
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
t4=C_fixnum_negate(t2);
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm: 135  fxmod */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[2]);}
else{
t4=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t2);
/* srfi-69.scm: 135  fxmod */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}}

/* equal?-hash in k1490 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2819r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2819r(t0,t1,t2,t3);}}

static void C_ccall f_2819r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2823,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_2823(2,t5,C_fix(536870912));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_2823(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2821 in equal?-hash in k1490 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2823,2,t0,t1);}
t2=C_i_check_exact_2(t1,lf[23]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2857,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 351  *equal?-hash */
f_2353(t3,((C_word*)t0)[2]);}

/* k2855 in k2821 in equal?-hash in k1490 */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
t4=C_fixnum_negate(t1);
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm: 135  fxmod */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,t5,t3);}
else{
t4=t1;
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm: 135  fxmod */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,t5,t3);}}

/* *equal?-hash in k1490 */
static void C_fcall f_2353(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2353,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2356,a[2]=t8,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2421,a[2]=t8,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2472,a[2]=t4,a[3]=t6,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp));
/* srfi-69.scm: 347  recursive-hash */
t12=((C_word*)t8)[1];
f_2472(t12,t1,t2,C_fix(0));}

/* recursive-hash in *equal?-hash in k1490 */
static void C_fcall f_2472(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2472,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t3,C_fix(4)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(99));}
else{
if(C_truep(C_fixnump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep(C_charp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(256));
case C_SCHEME_FALSE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(257));
default:
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(258));}
else{
if(C_truep(C_eofp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(259));}
else{
if(C_truep(C_i_symbolp(t2))){
t4=t1;
t5=t2;
t6=C_slot(t5,C_fix(1));
t7=t4;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_hash_string(t6));}
else{
if(C_truep(C_i_numberp(t2))){
t4=t1;
t5=t2;
if(C_truep(C_i_flonump(t5))){
t6=C_subbyte(t5,C_fix(7));
t7=C_subbyte(t5,C_fix(6));
t8=C_subbyte(t5,C_fix(5));
t9=C_subbyte(t5,C_fix(4));
t10=C_subbyte(t5,C_fix(3));
t11=C_subbyte(t5,C_fix(2));
t12=C_subbyte(t5,C_fix(1));
t13=C_subbyte(t5,C_fix(0));
t14=C_fixnum_shift_left(t13,C_fix(1));
t15=C_fixnum_plus(t12,t14);
t16=C_fixnum_shift_left(t15,C_fix(1));
t17=C_fixnum_plus(t11,t16);
t18=C_fixnum_shift_left(t17,C_fix(1));
t19=C_fixnum_plus(t10,t18);
t20=C_fixnum_shift_left(t19,C_fix(1));
t21=C_fixnum_plus(t9,t20);
t22=C_fixnum_shift_left(t21,C_fix(1));
t23=C_fixnum_plus(t8,t22);
t24=C_fixnum_shift_left(t23,C_fix(1));
t25=C_fixnum_plus(t7,t24);
t26=C_fixnum_shift_left(t25,C_fix(1));
t27=C_fixnum_plus(t6,t26);
t28=t4;
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,C_fixnum_times(C_fix(331804471),t27));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2668,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 163  ##sys#number-hash-hook */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t6,t5);}}
else{
t4=t2;
if(C_truep(C_blockp(t4))){
t5=t2;
if(C_truep(C_byteblockp(t5))){
t6=t1;
t7=t2;
t8=t6;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_hash_string(t7));}
else{
if(C_truep(C_i_listp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2702,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp);
/* g508509 */
t7=t6;
f_2702(t7,t1,t2);}
else{
if(C_truep(C_i_pairp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2728,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* g511512 */
t7=t6;
f_2728(t7,t1,t2);}
else{
t6=t2;
if(C_truep(C_portp(t6))){
t7=t1;
t8=t2;
t9=C_peek_fixnum(t8,C_fix(0));
t10=C_fixnum_shift_left(t9,C_fix(4));
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2779,a[2]=t10,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 291  input-port? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[21]+1)))(3,*((C_word*)lf[21]+1),t11,t8);}
else{
t7=t2;
if(C_truep(C_specialp(t7))){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2795,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
/* g523524 */
t9=t8;
f_2795(t9,t1,t2);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2807,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* g526527 */
t9=t8;
f_2807(t9,t1,t2);}}}}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(262));}}}}}}}}}}

/* g526 in recursive-hash in *equal?-hash in k1490 */
static void C_fcall f_2807(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2807,NULL,3,t0,t1,t2);}
/* srfi-69.scm: 299  vector-hash */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2356(t3,t1,t2,C_fix(0),((C_word*)t0)[2],C_fix(0));}

/* g523 in recursive-hash in *equal?-hash in k1490 */
static void C_fcall f_2795(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2795,NULL,3,t0,t1,t2);}
t3=C_peek_fixnum(t2,C_fix(0));
/* srfi-69.scm: 296  vector-hash */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2356(t4,t1,t2,t3,((C_word*)t0)[2],C_fix(1));}

/* k2777 in recursive-hash in *equal?-hash in k1490 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_fixnum_plus(((C_word*)t0)[2],C_fix(260)):C_fixnum_plus(((C_word*)t0)[2],C_fix(261))));}

/* g511 in recursive-hash in *equal?-hash in k1490 */
static void C_fcall f_2728(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2728,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* srfi-69.scm: 286  recursive-atomic-hash */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2421(t5,t3,t4,((C_word*)t0)[2]);}

/* k2746 in g511 in recursive-hash in *equal?-hash in k1490 */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2748,2,t0,t1);}
t2=C_fixnum_shift_left(t1,C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2740,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 287  recursive-atomic-hash */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2421(t5,t3,t4,((C_word*)t0)[2]);}

/* k2738 in k2746 in g511 in recursive-hash in *equal?-hash in k1490 */
static void C_ccall f_2740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fixnum_plus(((C_word*)t0)[2],t1));}

/* g508 in recursive-hash in *equal?-hash in k1490 */
static void C_fcall f_2702(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2702,NULL,3,t0,t1,t2);}
t3=C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2714,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_slot(t2,C_fix(0));
/* srfi-69.scm: 283  recursive-atomic-hash */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2421(t6,t4,t5,((C_word*)t0)[2]);}

/* k2712 in g508 in recursive-hash in *equal?-hash in k1490 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k2666 in recursive-hash in *equal?-hash in k1490 */
static void C_ccall f_2668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(t1));}

/* recursive-atomic-hash in *equal?-hash in k1490 */
static void C_fcall f_2421(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2421,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2455,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=t2;
t6=C_i_not(C_blockp(t5));
if(C_truep(t6)){
t7=t4;
f_2455(t7,(C_truep(t6)?t6:C_i_numberp(t5)));}
else{
t7=C_i_symbolp(t5);
t8=t4;
f_2455(t8,(C_truep(t7)?t7:C_i_numberp(t5)));}}

/* k2453 in recursive-atomic-hash in *equal?-hash in k1490 */
static void C_fcall f_2455(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2455,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_2458(t3,t1);}
else{
t3=((C_word*)t0)[2];
t4=t2;
f_2458(t4,C_byteblockp(t3));}}

/* k2456 in k2453 in recursive-atomic-hash in *equal?-hash in k1490 */
static void C_fcall f_2458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 321  recursive-hash */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2472(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(99));}}

/* vector-hash in *equal?-hash in k1490 */
static void C_fcall f_2356(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2356,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_block_size(t2);
t7=C_fixnum_plus(t6,t3);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2419,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t2,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 308  fxmin */
t9=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,C_fix(4),t6);}

/* k2417 in vector-hash in *equal?-hash in k1490 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2419,2,t0,t1);}
t2=C_fixnum_difference(t1,((C_word*)t0)[7]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2373,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=((C_word)li8),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2373(t6,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2);}

/* loop in k2417 in vector-hash in *equal?-hash in k1490 */
static void C_fcall f_2373(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2373,NULL,5,t0,t1,t2,t3,t4);}
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=C_fixnum_shift_left(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2407,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=C_slot(((C_word*)t0)[4],t3);
t9=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 313  recursive-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_2472(t10,t7,t8,t9);}}

/* k2405 in loop in k2417 in vector-hash in *equal?-hash in k1490 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[7],t1);
t3=C_fixnum_plus(((C_word*)t0)[6],t2);
t4=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 311  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2373(t6,((C_word*)t0)[2],t3,t4,t5);}

/* eqv?-hash in k1490 */
static void C_ccall f_2294(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2294r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2294r(t0,t1,t2,t3);}}

static void C_ccall f_2294r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2298,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_2298(2,t5,C_fix(536870912));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_2298(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2296 in eqv?-hash in k1490 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2298,2,t0,t1);}
t2=C_i_check_exact_2(t1,lf[19]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2332,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep(C_fixnump(t4))){
t5=t3;
f_2332(2,t5,t4);}
else{
if(C_truep(C_charp(t4))){
t5=t3;
f_2332(2,t5,C_fix(C_character_code(t4)));}
else{
switch(t4){
case C_SCHEME_TRUE:
t5=t3;
f_2332(2,t5,C_fix(256));
case C_SCHEME_FALSE:
t5=t3;
f_2332(2,t5,C_fix(257));
default:
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_2332(2,t5,C_fix(258));}
else{
if(C_truep(C_eofp(t4))){
t5=t3;
f_2332(2,t5,C_fix(259));}
else{
if(C_truep(C_i_symbolp(t4))){
t5=C_slot(t4,C_fix(1));
t6=t3;
f_2332(2,t6,C_hash_string(t5));}
else{
if(C_truep(C_i_numberp(t4))){
if(C_truep(C_i_flonump(t4))){
t5=C_subbyte(t4,C_fix(7));
t6=C_subbyte(t4,C_fix(6));
t7=C_subbyte(t4,C_fix(5));
t8=C_subbyte(t4,C_fix(4));
t9=C_subbyte(t4,C_fix(3));
t10=C_subbyte(t4,C_fix(2));
t11=C_subbyte(t4,C_fix(1));
t12=C_subbyte(t4,C_fix(0));
t13=C_fixnum_shift_left(t12,C_fix(1));
t14=C_fixnum_plus(t11,t13);
t15=C_fixnum_shift_left(t14,C_fix(1));
t16=C_fixnum_plus(t10,t15);
t17=C_fixnum_shift_left(t16,C_fix(1));
t18=C_fixnum_plus(t9,t17);
t19=C_fixnum_shift_left(t18,C_fix(1));
t20=C_fixnum_plus(t8,t19);
t21=C_fixnum_shift_left(t20,C_fix(1));
t22=C_fixnum_plus(t7,t21);
t23=C_fixnum_shift_left(t22,C_fix(1));
t24=C_fixnum_plus(t6,t23);
t25=C_fixnum_shift_left(t24,C_fix(1));
t26=C_fixnum_plus(t5,t25);
t27=t3;
f_2332(2,t27,C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2270,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 163  ##sys#number-hash-hook */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t5,t4);}}
else{
if(C_truep(C_blockp(t4))){
/* srfi-69.scm: 182  *equal?-hash */
f_2353(t3,t4);}
else{
t5=t3;
f_2332(2,t5,C_fix(262));}}}}}}}}}

/* k2268 in k2296 in eqv?-hash in k1490 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2332(2,t2,C_fix(t1));}

/* k2330 in k2296 in eqv?-hash in k1490 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
t4=C_fixnum_negate(t1);
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm: 135  fxmod */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,t5,t3);}
else{
t4=t1;
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm: 135  fxmod */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,t5,t3);}}

/* eq?-hash in k1490 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2020r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2020r(t0,t1,t2,t3);}}

static void C_ccall f_2020r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2024,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_2024(2,t5,C_fix(536870912));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_2024(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2022 in eq?-hash in k1490 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2024,2,t0,t1);}
t2=C_i_check_exact_2(t1,lf[17]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2058,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep(C_fixnump(t4))){
t5=t3;
f_2058(2,t5,t4);}
else{
if(C_truep(C_charp(t4))){
t5=t3;
f_2058(2,t5,C_fix(C_character_code(t4)));}
else{
switch(t4){
case C_SCHEME_TRUE:
t5=t3;
f_2058(2,t5,C_fix(256));
case C_SCHEME_FALSE:
t5=t3;
f_2058(2,t5,C_fix(257));
default:
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_2058(2,t5,C_fix(258));}
else{
if(C_truep(C_eofp(t4))){
t5=t3;
f_2058(2,t5,C_fix(259));}
else{
if(C_truep(C_i_symbolp(t4))){
t5=C_slot(t4,C_fix(1));
t6=t3;
f_2058(2,t6,C_hash_string(t5));}
else{
if(C_truep(C_blockp(t4))){
/* srfi-69.scm: 182  *equal?-hash */
f_2353(t3,t4);}
else{
t5=t3;
f_2058(2,t5,C_fix(262));}}}}}}}}

/* k2056 in k2022 in eq?-hash in k1490 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
t4=C_fixnum_negate(t1);
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm: 135  fxmod */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,t5,t3);}
else{
t4=t1;
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm: 135  fxmod */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,t5,t3);}}

/* keyword-hash in k1490 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1866r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1866r(t0,t1,t2,t3);}}

static void C_ccall f_1866r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1870,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_1870(2,t5,C_fix(536870912));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_1870(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1868 in keyword-hash in k1490 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 218  ##sys#check-keyword */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t2,((C_word*)t0)[3],lf[16]);}

/* k1871 in k1868 in keyword-hash in k1490 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=C_i_check_exact_2(((C_word*)t0)[4],lf[16]);
t3=((C_word*)t0)[3];
t4=C_slot(t3,C_fix(1));
t5=C_hash_string(t4);
t6=((C_word*)t0)[2];
t7=((C_word*)t0)[4];
if(C_truep(C_fixnum_lessp(t5,C_fix(0)))){
t8=C_fixnum_negate(t5);
t9=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t8);
/* srfi-69.scm: 135  fxmod */
t10=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t6,t9,t7);}
else{
t8=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t5);
/* srfi-69.scm: 135  fxmod */
t9=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t8,t7);}}

/* ##sys#check-keyword in k1490 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1840r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1840r(t0,t1,t2,t3);}}

static void C_ccall f_1840r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1847,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 205  keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t4,t2);}

/* k1845 in ##sys#check-keyword in k1490 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[3]))){
/* srfi-69.scm: 206  ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[13],C_SCHEME_FALSE,lf[14],((C_word*)t0)[2]);}
else{
t2=C_i_car(((C_word*)t0)[3]);
/* srfi-69.scm: 206  ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[13],t2,lf[14],((C_word*)t0)[2]);}}}

/* symbol-hash in k1490 */
static void C_ccall f_1767(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1767r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1767r(t0,t1,t2,t3);}}

static void C_ccall f_1767r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1771,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_1771(2,t5,C_fix(536870912));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_1771(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1769 in symbol-hash in k1490 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=C_i_check_symbol_2(((C_word*)t0)[3],lf[11]);
t3=C_i_check_exact_2(t1,lf[11]);
t4=((C_word*)t0)[3];
t5=C_slot(t4,C_fix(1));
t6=C_hash_string(t5);
t7=((C_word*)t0)[2];
t8=t1;
if(C_truep(C_fixnum_lessp(t6,C_fix(0)))){
t9=C_fixnum_negate(t6);
t10=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t9);
/* srfi-69.scm: 135  fxmod */
t11=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t7,t10,t8);}
else{
t9=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t6);
/* srfi-69.scm: 135  fxmod */
t10=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t9,t8);}}

/* object-uid-hash in k1490 */
static void C_ccall f_1703(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1703r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1703r(t0,t1,t2,t3);}}

static void C_ccall f_1703r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1707,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_1707(2,t5,C_fix(536870912));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_1707(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1705 in object-uid-hash in k1490 */
static void C_ccall f_1707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1707,2,t0,t1);}
t2=C_i_check_exact_2(t1,lf[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1746,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
/* srfi-69.scm: 182  *equal?-hash */
f_2353(t3,t4);}

/* k1744 in k1705 in object-uid-hash in k1490 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
t4=C_fixnum_negate(t1);
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm: 135  fxmod */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,t5,t3);}
else{
t4=t1;
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm: 135  fxmod */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,t5,t3);}}

/* number-hash in k1490 */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1500r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1500r(t0,t1,t2,t3);}}

static void C_ccall f_1500r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1504,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_1504(2,t5,C_fix(536870912));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_1504(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1502 in number-hash in k1490 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_numberp(((C_word*)t0)[2]))){
t3=t2;
f_1507(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 171  ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[7],lf[4],lf[8],((C_word*)t0)[2]);}}

/* k1505 in k1502 in number-hash in k1490 */
static void C_ccall f_1507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1507,2,t0,t1);}
t2=C_i_check_exact_2(((C_word*)t0)[4],lf[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1676,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep(C_fixnump(t4))){
t5=t3;
f_1676(t5,t4);}
else{
if(C_truep(C_i_flonump(t4))){
t5=C_subbyte(t4,C_fix(7));
t6=C_subbyte(t4,C_fix(6));
t7=C_subbyte(t4,C_fix(5));
t8=C_subbyte(t4,C_fix(4));
t9=C_subbyte(t4,C_fix(3));
t10=C_subbyte(t4,C_fix(2));
t11=C_subbyte(t4,C_fix(1));
t12=C_subbyte(t4,C_fix(0));
t13=C_fixnum_shift_left(t12,C_fix(1));
t14=C_fixnum_plus(t11,t13);
t15=C_fixnum_shift_left(t14,C_fix(1));
t16=C_fixnum_plus(t10,t15);
t17=C_fixnum_shift_left(t16,C_fix(1));
t18=C_fixnum_plus(t9,t17);
t19=C_fixnum_shift_left(t18,C_fix(1));
t20=C_fixnum_plus(t8,t19);
t21=C_fixnum_shift_left(t20,C_fix(1));
t22=C_fixnum_plus(t7,t21);
t23=C_fixnum_shift_left(t22,C_fix(1));
t24=C_fixnum_plus(t6,t23);
t25=C_fixnum_shift_left(t24,C_fix(1));
t26=C_fixnum_plus(t5,t25);
t27=t3;
f_1676(t27,C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1670,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 163  ##sys#number-hash-hook */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t5,t4);}}}

/* k1668 in k1505 in k1502 in number-hash in k1490 */
static void C_ccall f_1670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1676(t2,C_fix(t1));}

/* k1674 in k1505 in k1502 in number-hash in k1490 */
static void C_fcall f_1676(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
t4=C_fixnum_negate(t1);
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm: 135  fxmod */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,t5,t3);}
else{
t4=t1;
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm: 135  fxmod */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,t5,t3);}}

/* ##sys#number-hash-hook in k1490 */
static void C_ccall f_1494(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1494,3,t0,t1,t2);}
/* srfi-69.scm: 159  *equal?-hash */
f_2353(t1,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[254] = {
{"toplevel:srfi_69_scm",(void*)C_srfi_69_toplevel},
{"f_1492:srfi_69_scm",(void*)f_1492},
{"f_5657:srfi_69_scm",(void*)f_5657},
{"f_5777:srfi_69_scm",(void*)f_5777},
{"f_5661:srfi_69_scm",(void*)f_5661},
{"f_5667:srfi_69_scm",(void*)f_5667},
{"f_5679:srfi_69_scm",(void*)f_5679},
{"f_5736:srfi_69_scm",(void*)f_5736},
{"f_5755:srfi_69_scm",(void*)f_5755},
{"f_5694:srfi_69_scm",(void*)f_5694},
{"f_4631:srfi_69_scm",(void*)f_4631},
{"f_5641:srfi_69_scm",(void*)f_5641},
{"f_5645:srfi_69_scm",(void*)f_5645},
{"f_5648:srfi_69_scm",(void*)f_5648},
{"f_5639:srfi_69_scm",(void*)f_5639},
{"f_5616:srfi_69_scm",(void*)f_5616},
{"f_5623:srfi_69_scm",(void*)f_5623},
{"f_5628:srfi_69_scm",(void*)f_5628},
{"f_5636:srfi_69_scm",(void*)f_5636},
{"f_5604:srfi_69_scm",(void*)f_5604},
{"f_5611:srfi_69_scm",(void*)f_5611},
{"f_5592:srfi_69_scm",(void*)f_5592},
{"f_5599:srfi_69_scm",(void*)f_5599},
{"f_5580:srfi_69_scm",(void*)f_5580},
{"f_5587:srfi_69_scm",(void*)f_5587},
{"f_5514:srfi_69_scm",(void*)f_5514},
{"f_5526:srfi_69_scm",(void*)f_5526},
{"f_5542:srfi_69_scm",(void*)f_5542},
{"f_5570:srfi_69_scm",(void*)f_5570},
{"f_5443:srfi_69_scm",(void*)f_5443},
{"f_5455:srfi_69_scm",(void*)f_5455},
{"f_5478:srfi_69_scm",(void*)f_5478},
{"f_5501:srfi_69_scm",(void*)f_5501},
{"f_5486:srfi_69_scm",(void*)f_5486},
{"f_5465:srfi_69_scm",(void*)f_5465},
{"f_5378:srfi_69_scm",(void*)f_5378},
{"f_5393:srfi_69_scm",(void*)f_5393},
{"f_5409:srfi_69_scm",(void*)f_5409},
{"f_5313:srfi_69_scm",(void*)f_5313},
{"f_5328:srfi_69_scm",(void*)f_5328},
{"f_5344:srfi_69_scm",(void*)f_5344},
{"f_5259:srfi_69_scm",(void*)f_5259},
{"f_5266:srfi_69_scm",(void*)f_5266},
{"f_5271:srfi_69_scm",(void*)f_5271},
{"f_5300:srfi_69_scm",(void*)f_5300},
{"f_5279:srfi_69_scm",(void*)f_5279},
{"f_5292:srfi_69_scm",(void*)f_5292},
{"f_5269:srfi_69_scm",(void*)f_5269},
{"f_5186:srfi_69_scm",(void*)f_5186},
{"f_5201:srfi_69_scm",(void*)f_5201},
{"f_5217:srfi_69_scm",(void*)f_5217},
{"f_5170:srfi_69_scm",(void*)f_5170},
{"f_5184:srfi_69_scm",(void*)f_5184},
{"f_5158:srfi_69_scm",(void*)f_5158},
{"f_5090:srfi_69_scm",(void*)f_5090},
{"f_5102:srfi_69_scm",(void*)f_5102},
{"f_5125:srfi_69_scm",(void*)f_5125},
{"f_5151:srfi_69_scm",(void*)f_5151},
{"f_5138:srfi_69_scm",(void*)f_5138},
{"f_5112:srfi_69_scm",(void*)f_5112},
{"f_5074:srfi_69_scm",(void*)f_5074},
{"f_5081:srfi_69_scm",(void*)f_5081},
{"f_4978:srfi_69_scm",(void*)f_4978},
{"f_4985:srfi_69_scm",(void*)f_4985},
{"f_4999:srfi_69_scm",(void*)f_4999},
{"f_5025:srfi_69_scm",(void*)f_5025},
{"f_5044:srfi_69_scm",(void*)f_5044},
{"f_5012:srfi_69_scm",(void*)f_5012},
{"f_4847:srfi_69_scm",(void*)f_4847},
{"f_4863:srfi_69_scm",(void*)f_4863},
{"f_4930:srfi_69_scm",(void*)f_4930},
{"f_4949:srfi_69_scm",(void*)f_4949},
{"f_4883:srfi_69_scm",(void*)f_4883},
{"f_4739:srfi_69_scm",(void*)f_4739},
{"f_4755:srfi_69_scm",(void*)f_4755},
{"f_4810:srfi_69_scm",(void*)f_4810},
{"f_4823:srfi_69_scm",(void*)f_4823},
{"f_4770:srfi_69_scm",(void*)f_4770},
{"f_4633:srfi_69_scm",(void*)f_4633},
{"f_4649:srfi_69_scm",(void*)f_4649},
{"f_4703:srfi_69_scm",(void*)f_4703},
{"f_4719:srfi_69_scm",(void*)f_4719},
{"f_4664:srfi_69_scm",(void*)f_4664},
{"f_4431:srfi_69_scm",(void*)f_4431},
{"f_4491:srfi_69_scm",(void*)f_4491},
{"f_4483:srfi_69_scm",(void*)f_4483},
{"f_4464:srfi_69_scm",(void*)f_4464},
{"f_4498:srfi_69_scm",(void*)f_4498},
{"f_4513:srfi_69_scm",(void*)f_4513},
{"f_4579:srfi_69_scm",(void*)f_4579},
{"f_4609:srfi_69_scm",(void*)f_4609},
{"f_4530:srfi_69_scm",(void*)f_4530},
{"f_4519:srfi_69_scm",(void*)f_4519},
{"f_4419:srfi_69_scm",(void*)f_4419},
{"f_4426:srfi_69_scm",(void*)f_4426},
{"f_4207:srfi_69_scm",(void*)f_4207},
{"f_4264:srfi_69_scm",(void*)f_4264},
{"f_4256:srfi_69_scm",(void*)f_4256},
{"f_4237:srfi_69_scm",(void*)f_4237},
{"f_4271:srfi_69_scm",(void*)f_4271},
{"f_4286:srfi_69_scm",(void*)f_4286},
{"f_4359:srfi_69_scm",(void*)f_4359},
{"f_4392:srfi_69_scm",(void*)f_4392},
{"f_4395:srfi_69_scm",(void*)f_4395},
{"f_4369:srfi_69_scm",(void*)f_4369},
{"f_4300:srfi_69_scm",(void*)f_4300},
{"f_4336:srfi_69_scm",(void*)f_4336},
{"f_4310:srfi_69_scm",(void*)f_4310},
{"f_3909:srfi_69_scm",(void*)f_3909},
{"f_4156:srfi_69_scm",(void*)f_4156},
{"f_4162:srfi_69_scm",(void*)f_4162},
{"f_4139:srfi_69_scm",(void*)f_4139},
{"f_4151:srfi_69_scm",(void*)f_4151},
{"f_3911:srfi_69_scm",(void*)f_3911},
{"f_3918:srfi_69_scm",(void*)f_3918},
{"f_3921:srfi_69_scm",(void*)f_3921},
{"f_3977:srfi_69_scm",(void*)f_3977},
{"f_3969:srfi_69_scm",(void*)f_3969},
{"f_3950:srfi_69_scm",(void*)f_3950},
{"f_3984:srfi_69_scm",(void*)f_3984},
{"f_3999:srfi_69_scm",(void*)f_3999},
{"f_4076:srfi_69_scm",(void*)f_4076},
{"f_4113:srfi_69_scm",(void*)f_4113},
{"f_4116:srfi_69_scm",(void*)f_4116},
{"f_4104:srfi_69_scm",(void*)f_4104},
{"f_4086:srfi_69_scm",(void*)f_4086},
{"f_4013:srfi_69_scm",(void*)f_4013},
{"f_4053:srfi_69_scm",(void*)f_4053},
{"f_4041:srfi_69_scm",(void*)f_4041},
{"f_4023:srfi_69_scm",(void*)f_4023},
{"f_3900:srfi_69_scm",(void*)f_3900},
{"f_3788:srfi_69_scm",(void*)f_3788},
{"f_3798:srfi_69_scm",(void*)f_3798},
{"f_3803:srfi_69_scm",(void*)f_3803},
{"f_3865:srfi_69_scm",(void*)f_3865},
{"f_3886:srfi_69_scm",(void*)f_3886},
{"f_3859:srfi_69_scm",(void*)f_3859},
{"f_3762:srfi_69_scm",(void*)f_3762},
{"f_3766:srfi_69_scm",(void*)f_3766},
{"f_3769:srfi_69_scm",(void*)f_3769},
{"f_3772:srfi_69_scm",(void*)f_3772},
{"f_3695:srfi_69_scm",(void*)f_3695},
{"f_3718:srfi_69_scm",(void*)f_3718},
{"f_3734:srfi_69_scm",(void*)f_3734},
{"f_3705:srfi_69_scm",(void*)f_3705},
{"f_3775:srfi_69_scm",(void*)f_3775},
{"f_3668:srfi_69_scm",(void*)f_3668},
{"f_3656:srfi_69_scm",(void*)f_3656},
{"f_3647:srfi_69_scm",(void*)f_3647},
{"f_3638:srfi_69_scm",(void*)f_3638},
{"f_3629:srfi_69_scm",(void*)f_3629},
{"f_3620:srfi_69_scm",(void*)f_3620},
{"f_3611:srfi_69_scm",(void*)f_3611},
{"f_3602:srfi_69_scm",(void*)f_3602},
{"f_3593:srfi_69_scm",(void*)f_3593},
{"f_3587:srfi_69_scm",(void*)f_3587},
{"f_3224:srfi_69_scm",(void*)f_3224},
{"f_3577:srfi_69_scm",(void*)f_3577},
{"f_3580:srfi_69_scm",(void*)f_3580},
{"f_3302:srfi_69_scm",(void*)f_3302},
{"f_3557:srfi_69_scm",(void*)f_3557},
{"f_3560:srfi_69_scm",(void*)f_3560},
{"f_3305:srfi_69_scm",(void*)f_3305},
{"f_3525:srfi_69_scm",(void*)f_3525},
{"f_3531:srfi_69_scm",(void*)f_3531},
{"f_3535:srfi_69_scm",(void*)f_3535},
{"f_3308:srfi_69_scm",(void*)f_3308},
{"f_3343:srfi_69_scm",(void*)f_3343},
{"f_3364:srfi_69_scm",(void*)f_3364},
{"f_3370:srfi_69_scm",(void*)f_3370},
{"f_3462:srfi_69_scm",(void*)f_3462},
{"f_3475:srfi_69_scm",(void*)f_3475},
{"f_3469:srfi_69_scm",(void*)f_3469},
{"f_3465:srfi_69_scm",(void*)f_3465},
{"f_3437:srfi_69_scm",(void*)f_3437},
{"f_3450:srfi_69_scm",(void*)f_3450},
{"f_3444:srfi_69_scm",(void*)f_3444},
{"f_3440:srfi_69_scm",(void*)f_3440},
{"f_3427:srfi_69_scm",(void*)f_3427},
{"f_3409:srfi_69_scm",(void*)f_3409},
{"f_3413:srfi_69_scm",(void*)f_3413},
{"f_3396:srfi_69_scm",(void*)f_3396},
{"f_3386:srfi_69_scm",(void*)f_3386},
{"f_3373:srfi_69_scm",(void*)f_3373},
{"f_3354:srfi_69_scm",(void*)f_3354},
{"f_3311:srfi_69_scm",(void*)f_3311},
{"f_3338:srfi_69_scm",(void*)f_3338},
{"f_3314:srfi_69_scm",(void*)f_3314},
{"f_3318:srfi_69_scm",(void*)f_3318},
{"f_3334:srfi_69_scm",(void*)f_3334},
{"f_3226:srfi_69_scm",(void*)f_3226},
{"f_3193:srfi_69_scm",(void*)f_3193},
{"f_3197:srfi_69_scm",(void*)f_3197},
{"f_3163:srfi_69_scm",(void*)f_3163},
{"f_3169:srfi_69_scm",(void*)f_3169},
{"f_3020:srfi_69_scm",(void*)f_3020},
{"f_3101:srfi_69_scm",(void*)f_3101},
{"f_3092:srfi_69_scm",(void*)f_3092},
{"f_3073:srfi_69_scm",(void*)f_3073},
{"f_3077:srfi_69_scm",(void*)f_3077},
{"f_3080:srfi_69_scm",(void*)f_3080},
{"f_3036:srfi_69_scm",(void*)f_3036},
{"f_2879:srfi_69_scm",(void*)f_2879},
{"f_2960:srfi_69_scm",(void*)f_2960},
{"f_2951:srfi_69_scm",(void*)f_2951},
{"f_2932:srfi_69_scm",(void*)f_2932},
{"f_2936:srfi_69_scm",(void*)f_2936},
{"f_2939:srfi_69_scm",(void*)f_2939},
{"f_2895:srfi_69_scm",(void*)f_2895},
{"f_2819:srfi_69_scm",(void*)f_2819},
{"f_2823:srfi_69_scm",(void*)f_2823},
{"f_2857:srfi_69_scm",(void*)f_2857},
{"f_2353:srfi_69_scm",(void*)f_2353},
{"f_2472:srfi_69_scm",(void*)f_2472},
{"f_2807:srfi_69_scm",(void*)f_2807},
{"f_2795:srfi_69_scm",(void*)f_2795},
{"f_2779:srfi_69_scm",(void*)f_2779},
{"f_2728:srfi_69_scm",(void*)f_2728},
{"f_2748:srfi_69_scm",(void*)f_2748},
{"f_2740:srfi_69_scm",(void*)f_2740},
{"f_2702:srfi_69_scm",(void*)f_2702},
{"f_2714:srfi_69_scm",(void*)f_2714},
{"f_2668:srfi_69_scm",(void*)f_2668},
{"f_2421:srfi_69_scm",(void*)f_2421},
{"f_2455:srfi_69_scm",(void*)f_2455},
{"f_2458:srfi_69_scm",(void*)f_2458},
{"f_2356:srfi_69_scm",(void*)f_2356},
{"f_2419:srfi_69_scm",(void*)f_2419},
{"f_2373:srfi_69_scm",(void*)f_2373},
{"f_2407:srfi_69_scm",(void*)f_2407},
{"f_2294:srfi_69_scm",(void*)f_2294},
{"f_2298:srfi_69_scm",(void*)f_2298},
{"f_2270:srfi_69_scm",(void*)f_2270},
{"f_2332:srfi_69_scm",(void*)f_2332},
{"f_2020:srfi_69_scm",(void*)f_2020},
{"f_2024:srfi_69_scm",(void*)f_2024},
{"f_2058:srfi_69_scm",(void*)f_2058},
{"f_1866:srfi_69_scm",(void*)f_1866},
{"f_1870:srfi_69_scm",(void*)f_1870},
{"f_1873:srfi_69_scm",(void*)f_1873},
{"f_1840:srfi_69_scm",(void*)f_1840},
{"f_1847:srfi_69_scm",(void*)f_1847},
{"f_1767:srfi_69_scm",(void*)f_1767},
{"f_1771:srfi_69_scm",(void*)f_1771},
{"f_1703:srfi_69_scm",(void*)f_1703},
{"f_1707:srfi_69_scm",(void*)f_1707},
{"f_1746:srfi_69_scm",(void*)f_1746},
{"f_1500:srfi_69_scm",(void*)f_1500},
{"f_1504:srfi_69_scm",(void*)f_1504},
{"f_1507:srfi_69_scm",(void*)f_1507},
{"f_1670:srfi_69_scm",(void*)f_1670},
{"f_1676:srfi_69_scm",(void*)f_1676},
{"f_1494:srfi_69_scm",(void*)f_1494},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
