/* Generated from lolevel.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:51
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: lolevel.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -output-file lolevel.c
   unit: lolevel
*/

#include "chicken.h"

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
# include <sys/types.h>
#endif
#ifndef C_NONUNIX
# include <sys/mman.h>
#endif

#define C_w2b(x)                   C_fix(C_wordstobytes(C_unfix(x)))
#define C_memmove_o(to, from, n, toff, foff) C_memmove((char *)(to) + (toff), (char *)(from) + (foff), (n))

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[130];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,99,104,101,99,107,45,98,108,111,99,107,32,120,49,53,32,108,111,99,49,54,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,99,104,101,99,107,45,103,101,110,101,114,105,99,45,115,116,114,117,99,116,117,114,101,32,120,52,54,32,108,111,99,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,99,104,101,99,107,45,112,111,105,110,116,101,114,32,120,55,53,32,46,32,108,111,99,55,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,10),40,110,111,115,105,122,101,114,114,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,16),40,115,105,122,101,114,114,32,97,114,103,115,49,57,49,41};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,29),40,99,104,101,99,107,110,49,32,110,49,57,50,32,110,109,97,120,49,57,51,32,111,102,102,49,57,52,41,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,47),40,99,104,101,99,107,110,50,32,110,49,57,53,32,110,109,97,120,49,57,54,32,110,109,97,120,50,49,57,55,32,111,102,102,49,49,57,56,32,111,102,102,50,49,57,57,41,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,20),40,109,111,118,101,32,102,114,111,109,50,48,55,32,116,111,50,48,56,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,36),40,98,111,100,121,49,55,52,32,110,49,56,52,32,102,111,102,102,115,101,116,49,56,53,32,116,111,102,102,115,101,116,49,56,54,41,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,40),40,100,101,102,45,116,111,102,102,115,101,116,49,55,56,32,37,110,49,55,49,51,48,54,32,37,102,111,102,102,115,101,116,49,55,50,51,48,55,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,102,111,102,102,115,101,116,49,55,55,32,37,110,49,55,49,51,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,110,49,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,40),40,109,111,118,101,45,109,101,109,111,114,121,33,32,102,114,111,109,49,54,53,32,116,111,49,54,54,32,46,32,116,109,112,49,54,52,49,54,55,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,51,51,57,32,105,51,52,51,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,51,50,49,41,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,99,111,112,121,32,120,51,49,57,41,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,18),40,97,108,108,111,99,97,116,101,32,97,51,52,56,51,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,14),40,102,114,101,101,32,97,51,53,51,51,53,55,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,15),40,112,111,105,110,116,101,114,63,32,120,51,54,48,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,20),40,112,111,105,110,116,101,114,45,108,105,107,101,63,32,120,51,54,53,41,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,26),40,97,100,100,114,101,115,115,45,62,112,111,105,110,116,101,114,32,97,100,100,114,51,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,25),40,112,111,105,110,116,101,114,45,62,97,100,100,114,101,115,115,32,112,116,114,51,55,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,22),40,110,117,108,108,45,112,111,105,110,116,101,114,63,32,112,116,114,51,55,56,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,62,112,111,105,110,116,101,114,32,120,51,56,49,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,24),40,112,111,105,110,116,101,114,45,62,111,98,106,101,99,116,32,112,116,114,51,57,50,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,23),40,112,111,105,110,116,101,114,61,63,32,112,49,51,57,53,32,112,50,51,57,54,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,26),40,112,111,105,110,116,101,114,43,32,97,52,48,48,52,48,52,32,97,51,57,57,52,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,20),40,97,108,105,103,110,45,116,111,45,119,111,114,100,32,120,52,49,52,41,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,27),40,116,97,103,45,112,111,105,110,116,101,114,32,112,116,114,52,50,55,32,116,97,103,52,50,56,41,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,34),40,116,97,103,103,101,100,45,112,111,105,110,116,101,114,63,32,120,52,52,53,32,46,32,116,109,112,52,52,52,52,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,18),40,112,111,105,110,116,101,114,45,116,97,103,32,120,52,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,108,111,99,97,116,105,118,101,32,111,98,106,52,55,51,32,46,32,105,110,100,101,120,52,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,38),40,109,97,107,101,45,119,101,97,107,45,108,111,99,97,116,105,118,101,32,111,98,106,52,56,48,32,46,32,105,110,100,101,120,52,56,49,41,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,25),40,108,111,99,97,116,105,118,101,45,115,101,116,33,32,120,52,56,55,32,121,52,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,23),40,108,111,99,97,116,105,118,101,45,62,111,98,106,101,99,116,32,120,52,57,48,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,16),40,108,111,99,97,116,105,118,101,63,32,120,52,57,50,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,27),40,112,111,105,110,116,101,114,45,117,56,45,115,101,116,33,32,112,52,57,54,32,110,52,57,55,41,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,27),40,112,111,105,110,116,101,114,45,115,56,45,115,101,116,33,32,112,52,57,57,32,110,53,48,48,41,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,117,49,54,45,115,101,116,33,32,112,53,48,50,32,110,53,48,51,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,115,49,54,45,115,101,116,33,32,112,53,48,53,32,110,53,48,54,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,117,51,50,45,115,101,116,33,32,112,53,48,56,32,110,53,48,57,41,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,115,51,50,45,115,101,116,33,32,112,53,49,49,32,110,53,49,50,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,102,51,50,45,115,101,116,33,32,112,53,49,52,32,110,53,49,53,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,102,54,52,45,115,101,116,33,32,112,53,49,55,32,110,53,49,56,41,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,12),40,97,50,48,54,54,32,120,53,51,48,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,17),40,97,50,48,56,50,32,120,53,51,51,32,105,53,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,34),40,101,120,116,101,110,100,45,112,114,111,99,101,100,117,114,101,32,112,114,111,99,53,50,56,32,100,97,116,97,53,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,12),40,97,50,49,48,57,32,120,53,52,57,41,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,26),40,101,120,116,101,110,100,101,100,45,112,114,111,99,101,100,117,114,101,63,32,120,53,51,57,41,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,12),40,97,50,49,52,50,32,120,53,54,53,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,21),40,112,114,111,99,101,100,117,114,101,45,100,97,116,97,32,120,53,53,51,41,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,34),40,115,101,116,45,112,114,111,99,101,100,117,114,101,45,100,97,116,97,33,32,112,114,111,99,53,54,57,32,120,53,55,48,41,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,115,108,111,116,115,32,120,53,55,51,41,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,98,121,116,101,115,32,120,53,55,54,41,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,40),40,109,97,107,101,45,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,32,116,121,112,101,53,56,52,32,46,32,97,114,103,115,53,56,53,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,35),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,63,32,120,53,57,52,32,46,32,116,109,112,53,57,51,53,57,53,41,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,27),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,116,121,112,101,32,120,54,49,52,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,29),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,108,101,110,103,116,104,32,120,54,49,55,41,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,42),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,115,108,111,116,45,115,101,116,33,32,120,54,50,48,32,105,54,50,49,32,121,54,50,50,41,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,54,51,52,41,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,21),40,114,101,99,111,114,100,45,62,118,101,99,116,111,114,32,120,54,51,48,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,101,118,105,99,116,101,100,63,32,120,54,52,51,41,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,16),40,102,95,50,52,55,57,32,97,54,52,57,54,53,50,41};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,54,55,53,32,105,54,55,57,41};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,54,53,53,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,34),40,111,98,106,101,99,116,45,101,118,105,99,116,32,120,54,52,53,32,46,32,97,108,108,111,99,97,116,111,114,54,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,55,51,49,32,105,55,51,53,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,55,48,54,41,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,49),40,111,98,106,101,99,116,45,101,118,105,99,116,45,116,111,45,108,111,99,97,116,105,111,110,32,120,54,57,51,32,112,116,114,54,57,52,32,46,32,108,105,109,105,116,54,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,16),40,102,95,50,55,51,50,32,97,55,53,53,55,53,57,41};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,55,55,50,32,105,55,55,54,41};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,14),40,114,101,108,101,97,115,101,32,120,55,54,50,41,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,35),40,111,98,106,101,99,116,45,114,101,108,101,97,115,101,32,120,55,53,49,32,46,32,114,101,108,101,97,115,101,114,55,53,50,41,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,55,57,56,32,105,56,48,50,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,55,56,54,41,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,115,105,122,101,32,120,55,56,51,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,56,52,56,32,105,56,53,50,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,56,50,57,41,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,33),40,111,98,106,101,99,116,45,117,110,101,118,105,99,116,32,120,56,50,48,32,46,32,116,109,112,56,49,57,56,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,108,115,116,50,55,41,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,24),40,111,98,106,101,99,116,45,98,101,99,111,109,101,33,32,97,108,115,116,56,53,57,41};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,33),40,109,117,116,97,116,101,45,112,114,111,99,101,100,117,114,101,32,111,108,100,56,54,50,32,112,114,111,99,56,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,19),40,103,108,111,98,97,108,45,114,101,102,32,115,121,109,56,55,50,41,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,25),40,103,108,111,98,97,108,45,115,101,116,33,32,115,121,109,56,55,53,32,120,56,55,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,22),40,103,108,111,98,97,108,45,98,111,117,110,100,63,32,115,121,109,56,55,57,41,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,29),40,103,108,111,98,97,108,45,109,97,107,101,45,117,110,98,111,117,110,100,33,32,115,121,109,56,56,50,41,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,17),40,97,51,48,51,49,32,120,54,50,53,32,105,54,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,12),40,97,51,48,53,53,32,112,53,50,54,41,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,12),40,97,51,48,53,56,32,112,53,50,53,41,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,12),40,97,51,48,54,49,32,112,53,50,52,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,12),40,97,51,48,54,52,32,112,53,50,51,41,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,12),40,97,51,48,54,55,32,112,53,50,50,41,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,12),40,97,51,48,55,48,32,112,53,50,49,41,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,12),40,97,51,48,55,51,32,112,53,50,48,41,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,12),40,97,51,48,55,54,32,112,53,49,57,41,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,14),67,95,108,111,99,97,116,105,118,101,95,114,101,102,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k2735 */
static C_word C_fcall stub756(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub756(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k2482 */
static C_word C_fcall stub650(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub650(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k1797 */
static C_word C_fcall stub410(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub410(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_int_to_num(&C_a,C_align(t0));
return C_r;}

#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub401(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub401(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * ptr=(void * )C_c_pointer_or_null(C_a0);
int off=(int )C_num_to_int(C_a1);
return((unsigned char *)ptr + off);
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub387(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub387(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word x=(C_word )(C_a0);
return((void *)x);
C_ret:
#undef return

return C_r;}

/* from k1702 */
static C_word C_fcall stub354(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub354(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k1695 */
static C_word C_fcall stub349(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub349(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k1234 */
static C_word C_fcall stub145(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub145(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1206 */
static C_word C_fcall stub129(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub129(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1178 */
static C_word C_fcall stub113(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub113(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1150 */
static C_word C_fcall stub97(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub97(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

C_noret_decl(C_lolevel_toplevel)
C_externexport void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_968)
static void C_ccall f_968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_971)
static void C_ccall f_971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3071)
static void C_ccall f_3071(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3010)
static void C_ccall f_3010(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2955)
static void C_ccall f_2955(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1001)
static void C_fcall f_1001(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1023)
static void C_ccall f_1023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_ccall f_2833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_fcall f_2838(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2897)
static void C_ccall f_2897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2909)
static void C_fcall f_2909(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2867)
static void C_ccall f_2867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2751)
static void C_fcall f_2751(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2770)
static void C_fcall f_2770(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2783)
static void C_fcall f_2783(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2785)
static void C_fcall f_2785(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2659)
static void C_fcall f_2659(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2704)
static void C_fcall f_2704(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f3393)
static void C_ccall f3393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2695)
static void C_ccall f_2695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2490)
static void C_ccall f_2490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_fcall f_2493(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2507)
static void C_fcall f_2507(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2526)
static void C_fcall f_2526(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2620)
static void C_ccall f_2620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_fcall f_2532(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2548)
static void C_fcall f_2548(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_fcall f_2550(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_fcall f_2383(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2393)
static void C_ccall f_2393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2409)
static void C_fcall f_2409(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_fcall f_2422(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_fcall f_2424(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2365)
static void C_ccall f_2365(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2327)
static void C_ccall f_2327(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2342)
static C_word C_fcall f_2342(C_word t0,C_word t1);
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_fcall f_2243(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1092)
static void C_fcall f_1092(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1998)
static void C_ccall f_1998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1924)
static void C_ccall f_1924(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1924)
static void C_ccall f_1924r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1913)
static void C_fcall f_1913(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_fcall f_1852(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1821)
static void C_fcall f_1821(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1770)
static void C_ccall f_1770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1777)
static void C_ccall f_1777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1709)
static void C_ccall f_1709(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1699)
static void C_ccall f_1699(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1617)
static void C_fcall f_1617(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1647)
static void C_ccall f_1647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1662)
static void C_fcall f_1662(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1248)
static void C_ccall f_1248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1248)
static void C_ccall f_1248r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1548)
static void C_fcall f_1548(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_fcall f_1543(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1538)
static void C_fcall f_1538(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1250)
static void C_fcall f_1250(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1308)
static void C_ccall f_1308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1322)
static void C_fcall f_1322(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1391)
static void C_fcall f_1391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1478)
static void C_fcall f_1478(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1407)
static void C_fcall f_1407(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1414)
static void C_ccall f_1414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1281)
static void C_fcall f_1281(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1288)
static void C_fcall f_1288(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1265)
static void C_fcall f_1265(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1259)
static void C_fcall f_1259(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1253)
static void C_fcall f_1253(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1107)
static void C_ccall f_1107(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1107)
static void C_ccall f_1107r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1046)
static void C_fcall f_1046(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1058)
static void C_fcall f_1058(C_word t0,C_word t1) C_noret;
C_noret_decl(f_973)
static void C_fcall f_973(C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_1001)
static void C_fcall trf_1001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1001(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1001(t0,t1,t2);}

C_noret_decl(trf_2838)
static void C_fcall trf_2838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2838(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2838(t0,t1,t2);}

C_noret_decl(trf_2909)
static void C_fcall trf_2909(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2909(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2909(t0,t1,t2);}

C_noret_decl(trf_2751)
static void C_fcall trf_2751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2751(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2751(t0,t1,t2);}

C_noret_decl(trf_2770)
static void C_fcall trf_2770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2770(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2770(t0,t1);}

C_noret_decl(trf_2783)
static void C_fcall trf_2783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2783(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2783(t0,t1);}

C_noret_decl(trf_2785)
static void C_fcall trf_2785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2785(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2785(t0,t1,t2);}

C_noret_decl(trf_2659)
static void C_fcall trf_2659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2659(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2659(t0,t1,t2);}

C_noret_decl(trf_2704)
static void C_fcall trf_2704(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2704(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2704(t0,t1,t2);}

C_noret_decl(trf_2493)
static void C_fcall trf_2493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2493(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2493(t0,t1);}

C_noret_decl(trf_2507)
static void C_fcall trf_2507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2507(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2507(t0,t1,t2);}

C_noret_decl(trf_2526)
static void C_fcall trf_2526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2526(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2526(t0,t1);}

C_noret_decl(trf_2532)
static void C_fcall trf_2532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2532(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2532(t0,t1);}

C_noret_decl(trf_2548)
static void C_fcall trf_2548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2548(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2548(t0,t1);}

C_noret_decl(trf_2550)
static void C_fcall trf_2550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2550(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2550(t0,t1,t2);}

C_noret_decl(trf_2383)
static void C_fcall trf_2383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2383(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2383(t0,t1,t2);}

C_noret_decl(trf_2409)
static void C_fcall trf_2409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2409(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2409(t0,t1);}

C_noret_decl(trf_2422)
static void C_fcall trf_2422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2422(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2422(t0,t1);}

C_noret_decl(trf_2424)
static void C_fcall trf_2424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2424(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2424(t0,t1,t2);}

C_noret_decl(trf_2243)
static void C_fcall trf_2243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2243(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2243(t0,t1);}

C_noret_decl(trf_1092)
static void C_fcall trf_1092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1092(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1092(t0,t1);}

C_noret_decl(trf_1913)
static void C_fcall trf_1913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1913(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1913(t0,t1);}

C_noret_decl(trf_1852)
static void C_fcall trf_1852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1852(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1852(t0,t1);}

C_noret_decl(trf_1821)
static void C_fcall trf_1821(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1821(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1821(t0,t1);}

C_noret_decl(trf_1617)
static void C_fcall trf_1617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1617(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1617(t0,t1,t2);}

C_noret_decl(trf_1662)
static void C_fcall trf_1662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1662(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1662(t0,t1,t2);}

C_noret_decl(trf_1548)
static void C_fcall trf_1548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1548(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1548(t0,t1);}

C_noret_decl(trf_1543)
static void C_fcall trf_1543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1543(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1543(t0,t1,t2);}

C_noret_decl(trf_1538)
static void C_fcall trf_1538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1538(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1538(t0,t1,t2,t3);}

C_noret_decl(trf_1250)
static void C_fcall trf_1250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1250(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1250(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1322)
static void C_fcall trf_1322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1322(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1322(t0,t1,t2,t3);}

C_noret_decl(trf_1391)
static void C_fcall trf_1391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1391(t0,t1);}

C_noret_decl(trf_1478)
static void C_fcall trf_1478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1478(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1478(t0,t1);}

C_noret_decl(trf_1407)
static void C_fcall trf_1407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1407(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1407(t0,t1);}

C_noret_decl(trf_1281)
static void C_fcall trf_1281(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1281(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1281(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1288)
static void C_fcall trf_1288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1288(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1288(t0,t1);}

C_noret_decl(trf_1265)
static void C_fcall trf_1265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1265(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1265(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1259)
static void C_fcall trf_1259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1259(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1259(t0,t1,t2);}

C_noret_decl(trf_1253)
static void C_fcall trf_1253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1253(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1253(t0,t1);}

C_noret_decl(trf_1046)
static void C_fcall trf_1046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1046(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1046(t0,t1,t2);}

C_noret_decl(trf_1058)
static void C_fcall trf_1058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1058(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1058(t0,t1);}

C_noret_decl(trf_973)
static void C_fcall trf_973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_973(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_973(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_lolevel_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("lolevel_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1237)){
C_save(t1);
C_rereclaim2(1237*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,130);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_h_intern(&lf[3],14,"\003syserror-hook");
lf[5]=C_h_intern(&lf[5],15,"\003syssignal-hook");
lf[6]=C_h_intern(&lf[6],11,"\000type-error");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a structure");
lf[8]=C_h_intern(&lf[8],17,"\003syscheck-pointer");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[10]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004mmap\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\010"
"s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64ve"
"ctor\376\377\016");
lf[11]=C_h_intern(&lf[11],12,"move-memory!");
lf[12]=C_h_intern(&lf[12],9,"\003syserror");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\034need number of bytes to move");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[15]=C_h_intern(&lf[15],15,"\003sysbytevector\077");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\033negative destination offset");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\026negative source offset");
lf[18]=C_h_intern(&lf[18],11,"object-copy");
lf[19]=C_h_intern(&lf[19],15,"\003sysmake-vector");
lf[20]=C_h_intern(&lf[20],8,"allocate");
lf[21]=C_h_intern(&lf[21],4,"free");
lf[22]=C_h_intern(&lf[22],8,"pointer\077");
lf[23]=C_h_intern(&lf[23],13,"pointer-like\077");
lf[24]=C_h_intern(&lf[24],16,"address->pointer");
lf[25]=C_h_intern(&lf[25],20,"\003sysaddress->pointer");
lf[26]=C_h_intern(&lf[26],17,"\003syscheck-integer");
lf[27]=C_h_intern(&lf[27],16,"pointer->address");
lf[28]=C_h_intern(&lf[28],20,"\003syspointer->address");
lf[29]=C_h_intern(&lf[29],17,"\003syscheck-special");
lf[30]=C_h_intern(&lf[30],12,"null-pointer");
lf[31]=C_h_intern(&lf[31],16,"\003sysnull-pointer");
lf[32]=C_h_intern(&lf[32],13,"null-pointer\077");
lf[33]=C_h_intern(&lf[33],15,"object->pointer");
lf[34]=C_h_intern(&lf[34],15,"pointer->object");
lf[35]=C_h_intern(&lf[35],9,"pointer=\077");
lf[36]=C_h_intern(&lf[36],8,"pointer+");
lf[37]=C_h_intern(&lf[37],14,"pointer-offset");
lf[38]=C_h_intern(&lf[38],13,"align-to-word");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a pointer or integer");
lf[40]=C_h_intern(&lf[40],11,"tag-pointer");
lf[41]=C_h_intern(&lf[41],23,"\003sysmake-tagged-pointer");
lf[42]=C_h_intern(&lf[42],15,"tagged-pointer\077");
lf[43]=C_h_intern(&lf[43],11,"pointer-tag");
lf[44]=C_h_intern(&lf[44],13,"make-locative");
lf[45]=C_h_intern(&lf[45],17,"\003sysmake-locative");
lf[46]=C_h_intern(&lf[46],18,"make-weak-locative");
lf[47]=C_h_intern(&lf[47],13,"locative-set!");
lf[48]=C_h_intern(&lf[48],12,"locative-ref");
lf[49]=C_h_intern(&lf[49],16,"locative->object");
lf[50]=C_h_intern(&lf[50],9,"locative\077");
lf[51]=C_h_intern(&lf[51],15,"pointer-u8-set!");
lf[52]=C_h_intern(&lf[52],15,"pointer-s8-set!");
lf[53]=C_h_intern(&lf[53],16,"pointer-u16-set!");
lf[54]=C_h_intern(&lf[54],16,"pointer-s16-set!");
lf[55]=C_h_intern(&lf[55],16,"pointer-u32-set!");
lf[56]=C_h_intern(&lf[56],16,"pointer-s32-set!");
lf[57]=C_h_intern(&lf[57],16,"pointer-f32-set!");
lf[58]=C_h_intern(&lf[58],16,"pointer-f64-set!");
lf[59]=C_h_intern(&lf[59],14,"pointer-u8-ref");
lf[60]=C_h_intern(&lf[60],14,"pointer-s8-ref");
lf[61]=C_h_intern(&lf[61],15,"pointer-u16-ref");
lf[62]=C_h_intern(&lf[62],15,"pointer-s16-ref");
lf[63]=C_h_intern(&lf[63],15,"pointer-u32-ref");
lf[64]=C_h_intern(&lf[64],15,"pointer-s32-ref");
lf[65]=C_h_intern(&lf[65],15,"pointer-f32-ref");
lf[66]=C_h_intern(&lf[66],15,"pointer-f64-ref");
lf[67]=C_h_intern(&lf[67],8,"extended");
lf[69]=C_h_intern(&lf[69],16,"extend-procedure");
lf[70]=C_h_intern(&lf[70],19,"\003sysdecorate-lambda");
lf[71]=C_h_intern(&lf[71],17,"\003syscheck-closure");
lf[72]=C_h_intern(&lf[72],19,"extended-procedure\077");
lf[73]=C_h_intern(&lf[73],21,"\003syslambda-decoration");
lf[74]=C_h_intern(&lf[74],14,"procedure-data");
lf[75]=C_h_intern(&lf[75],19,"set-procedure-data!");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000-bad argument type - not an extended procedure");
lf[77]=C_h_intern(&lf[77],10,"block-set!");
lf[78]=C_h_intern(&lf[78],14,"\003sysblock-set!");
lf[79]=C_h_intern(&lf[79],9,"block-ref");
lf[80]=C_h_intern(&lf[80],15,"number-of-slots");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a vector-like object");
lf[82]=C_h_intern(&lf[82],15,"number-of-bytes");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\0002cannot compute number of bytes of immediate object");
lf[84]=C_h_intern(&lf[84],20,"make-record-instance");
lf[85]=C_h_intern(&lf[85],18,"\003sysmake-structure");
lf[86]=C_h_intern(&lf[86],16,"record-instance\077");
lf[87]=C_h_intern(&lf[87],20,"record-instance-type");
lf[88]=C_h_intern(&lf[88],22,"record-instance-length");
lf[89]=C_h_intern(&lf[89],25,"record-instance-slot-set!");
lf[90]=C_h_intern(&lf[90],15,"\003syscheck-range");
lf[91]=C_h_intern(&lf[91],20,"record-instance-slot");
lf[92]=C_h_intern(&lf[92],14,"record->vector");
lf[93]=C_h_intern(&lf[93],15,"object-evicted\077");
lf[94]=C_h_intern(&lf[94],12,"object-evict");
lf[95]=C_h_intern(&lf[95],15,"hash-table-set!");
lf[96]=C_h_intern(&lf[96],19,"\003sysundefined-value");
lf[97]=C_h_intern(&lf[97],22,"hash-table-ref/default");
lf[98]=C_h_intern(&lf[98],15,"make-hash-table");
lf[99]=C_h_intern(&lf[99],3,"eq\077");
lf[100]=C_h_intern(&lf[100],24,"object-evict-to-location");
lf[101]=C_h_intern(&lf[101],24,"\003sysset-pointer-address!");
lf[102]=C_h_intern(&lf[102],6,"signal");
lf[103]=C_h_intern(&lf[103],24,"make-composite-condition");
lf[104]=C_h_intern(&lf[104],23,"make-property-condition");
lf[105]=C_h_intern(&lf[105],5,"evict");
lf[106]=C_h_intern(&lf[106],5,"limit");
lf[107]=C_h_intern(&lf[107],3,"exn");
lf[108]=C_h_intern(&lf[108],8,"location");
lf[109]=C_h_intern(&lf[109],7,"message");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000$cannot evict object - limit exceeded");
lf[111]=C_h_intern(&lf[111],9,"arguments");
lf[112]=C_h_intern(&lf[112],14,"object-release");
lf[113]=C_h_intern(&lf[113],11,"object-size");
lf[114]=C_h_intern(&lf[114],14,"object-unevict");
lf[115]=C_h_intern(&lf[115],15,"\003sysmake-string");
lf[116]=C_h_intern(&lf[116],14,"object-become!");
lf[117]=C_h_intern(&lf[117],11,"\003sysbecome!");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000:bad argument type - not an a-list of non-immediate objects");
lf[119]=C_h_intern(&lf[119],16,"mutate-procedure");
lf[120]=C_h_intern(&lf[120],10,"global-ref");
lf[121]=C_h_intern(&lf[121],11,"global-set!");
lf[122]=C_h_intern(&lf[122],13,"global-bound\077");
lf[123]=C_h_intern(&lf[123],32,"\003syssymbol-has-toplevel-binding\077");
lf[124]=C_h_intern(&lf[124],20,"global-make-unbound!");
lf[125]=C_h_intern(&lf[125],28,"\003sysarbitrary-unbound-symbol");
lf[126]=C_h_intern(&lf[126],18,"getter-with-setter");
lf[127]=C_h_intern(&lf[127],13,"\003sysblock-ref");
lf[128]=C_h_intern(&lf[128],17,"register-feature!");
lf[129]=C_h_intern(&lf[129],7,"lolevel");
C_register_lf2(lf,130,create_ptable());
t2=C_mutate(&lf[0] /* (set! c317 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_968,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k966 */
static void C_ccall f_968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_971,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 74   register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[128]+1)))(3,*((C_word*)lf[128]+1),t2,lf[129]);}

/* k969 in k966 */
static void C_ccall f_971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[76],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_971,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! ##sys#check-block ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_973,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[4] /* (set! ##sys#check-generic-structure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1046,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* (set! ##sys#check-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1107,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=lf[10];
t6=C_mutate((C_word*)lf[11]+1 /* (set! move-memory! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1248,a[2]=t5,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[18]+1 /* (set! object-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1611,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[20]+1 /* (set! allocate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1692,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[21]+1 /* (set! free ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1699,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[22]+1 /* (set! pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1709,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[23]+1 /* (set! pointer-like? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1717,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[24]+1 /* (set! address->pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1728,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[27]+1 /* (set! pointer->address ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1737,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[30]+1 /* (set! null-pointer ...) */,*((C_word*)lf[31]+1));
t15=C_mutate((C_word*)lf[32]+1 /* (set! null-pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1747,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[33]+1 /* (set! object->pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1753,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[34]+1 /* (set! pointer->object ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1764,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[35]+1 /* (set! pointer=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1770,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[36]+1 /* (set! pointer+ ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1779,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[37]+1 /* (set! pointer-offset ...) */,*((C_word*)lf[36]+1));
t21=C_mutate((C_word*)lf[38]+1 /* (set! align-to-word ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1800,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[40]+1 /* (set! tag-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1837,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[42]+1 /* (set! tagged-pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1857,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[43]+1 /* (set! pointer-tag ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1901,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[44]+1 /* (set! make-locative ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1924,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[46]+1 /* (set! make-weak-locative ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1953,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[47]+1 /* (set! locative-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1982,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)C_locative_ref,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 331  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[126]+1)))(4,*((C_word*)lf[126]+1),t28,t29,*((C_word*)lf[47]+1));}

/* k1985 in k969 in k966 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1987,2,t0,t1);}
t2=C_mutate((C_word*)lf[48]+1 /* (set! locative-ref ...) */,t1);
t3=C_mutate((C_word*)lf[49]+1 /* (set! locative->object ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1989,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[50]+1 /* (set! locative? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1992,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[51]+1 /* (set! pointer-u8-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1998,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[52]+1 /* (set! pointer-s8-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2001,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[53]+1 /* (set! pointer-u16-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2004,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[54]+1 /* (set! pointer-s16-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2007,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[55]+1 /* (set! pointer-u32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2010,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[56]+1 /* (set! pointer-s32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2013,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[57]+1 /* (set! pointer-f32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2016,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[58]+1 /* (set! pointer-f64-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2019,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2024,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3077,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 348  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[126]+1)))(4,*((C_word*)lf[126]+1),t13,t14,*((C_word*)lf[51]+1));}

/* a3076 in k1985 in k969 in k966 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3077,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_pointer_u8_ref(t2));}

/* k2022 in k1985 in k969 in k966 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2024,2,t0,t1);}
t2=C_mutate((C_word*)lf[59]+1 /* (set! pointer-u8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2028,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3074,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 353  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[126]+1)))(4,*((C_word*)lf[126]+1),t3,t4,*((C_word*)lf[52]+1));}

/* a3073 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3074,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_pointer_s8_ref(t2));}

/* k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2028,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1 /* (set! pointer-s8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2032,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3071,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 358  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[126]+1)))(4,*((C_word*)lf[126]+1),t3,t4,*((C_word*)lf[53]+1));}

/* a3070 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_3071(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3071,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_pointer_u16_ref(t2));}

/* k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2032,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! pointer-u16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2036,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3068,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 363  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[126]+1)))(4,*((C_word*)lf[126]+1),t3,t4,*((C_word*)lf[54]+1));}

/* a3067 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3068,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_pointer_s16_ref(t2));}

/* k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2036,2,t0,t1);}
t2=C_mutate((C_word*)lf[62]+1 /* (set! pointer-s16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2040,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3065,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 368  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[126]+1)))(4,*((C_word*)lf[126]+1),t3,t4,*((C_word*)lf[55]+1));}

/* a3064 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3065,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_u_i_pointer_u32_ref(&a,1,t2));}

/* k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2040,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1 /* (set! pointer-u32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3062,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 373  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[126]+1)))(4,*((C_word*)lf[126]+1),t3,t4,*((C_word*)lf[56]+1));}

/* a3061 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3062,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_u_i_pointer_s32_ref(&a,1,t2));}

/* k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2044,2,t0,t1);}
t2=C_mutate((C_word*)lf[64]+1 /* (set! pointer-s32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2048,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3059,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 378  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[126]+1)))(4,*((C_word*)lf[126]+1),t3,t4,*((C_word*)lf[57]+1));}

/* a3058 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3059,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_u_i_pointer_f32_ref(&a,1,t2));}

/* k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2048,2,t0,t1);}
t2=C_mutate((C_word*)lf[65]+1 /* (set! pointer-f32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2052,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3056,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 383  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[126]+1)))(4,*((C_word*)lf[126]+1),t3,t4,*((C_word*)lf[58]+1));}

/* a3055 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3056,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_u_i_pointer_f64_ref(&a,1,t2));}

/* k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2052,2,t0,t1);}
t2=C_mutate((C_word*)lf[66]+1 /* (set! pointer-f64-ref ...) */,t1);
t3=C_a_i_vector(&a,1,lf[67]);
t4=C_mutate(&lf[68] /* (set! xproc-tag ...) */,t3);
t5=C_mutate((C_word*)lf[69]+1 /* (set! extend-procedure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2058,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[72]+1 /* (set! extended-procedure? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2093,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[74]+1 /* (set! procedure-data ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2129,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[69]+1);
t9=C_mutate((C_word*)lf[75]+1 /* (set! set-procedure-data! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2168,a[2]=t8,a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[77]+1 /* (set! block-set! ...) */,*((C_word*)lf[78]+1));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2186,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 427  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[126]+1)))(4,*((C_word*)lf[126]+1),t11,*((C_word*)lf[127]+1),*((C_word*)lf[78]+1));}

/* k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2186,2,t0,t1);}
t2=C_mutate((C_word*)lf[79]+1 /* (set! block-ref ...) */,t1);
t3=C_mutate((C_word*)lf[80]+1 /* (set! number-of-slots ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2188,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[82]+1 /* (set! number-of-bytes ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2197,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[84]+1 /* (set! make-record-instance ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2219,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[86]+1 /* (set! record-instance? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2228,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[87]+1 /* (set! record-instance-type ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2277,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[88]+1 /* (set! record-instance-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2286,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[89]+1 /* (set! record-instance-slot-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2299,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2325,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3032,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 474  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[126]+1)))(4,*((C_word*)lf[126]+1),t10,t11,*((C_word*)lf[89]+1));}

/* a3031 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3032,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3036,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 476  ##sys#check-generic-structure */
f_1046(t4,t2,C_a_i_list(&a,1,lf[91]));}

/* k3034 in a3031 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_block_size(((C_word*)t0)[2]);
t4=C_fixnum_difference(t3,C_fix(1));
/* lolevel.scm: 477  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[90]+1)))(6,*((C_word*)lf[90]+1),t2,((C_word*)t0)[4],C_fix(0),t4,lf[91]);}

/* k3037 in k3034 in a3031 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_3039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(((C_word*)t0)[2],t2));}

/* k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2325,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1 /* (set! record-instance-slot ...) */,t1);
t3=C_mutate((C_word*)lf[92]+1 /* (set! record->vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2327,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[93]+1 /* (set! object-evicted? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2365,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[94]+1 /* (set! object-evict ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2368,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[100]+1 /* (set! object-evict-to-location ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2486,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[112]+1 /* (set! object-release ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2650,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[113]+1 /* (set! object-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2742,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[114]+1 /* (set! object-unevict ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2826,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[116]+1 /* (set! object-become! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2955,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[119]+1 /* (set! mutate-procedure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2964,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[120]+1 /* (set! global-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2995,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[121]+1 /* (set! global-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3001,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[122]+1 /* (set! global-bound? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3010,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[124]+1 /* (set! global-make-unbound! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3019,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t16=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}

/* global-make-unbound! in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3019,3,t0,t1,t2);}
t3=C_i_check_symbol_2(t2,lf[124]);
t4=C_slot(lf[125],C_fix(0));
t5=C_i_setslot(t2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* global-bound? in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_3010(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3010,3,t0,t1,t2);}
t3=C_i_check_symbol_2(t2,lf[122]);
/* lolevel.scm: 645  ##sys#symbol-has-toplevel-binding? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[123]+1)))(3,*((C_word*)lf[123]+1),t1,t2);}

/* global-set! in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3001,4,t0,t1,t2,t3);}
t4=C_i_check_symbol_2(t2,lf[121]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_setslot(t2,C_fix(0),t3));}

/* global-ref in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2995,3,t0,t1,t2);}
t3=C_i_check_symbol_2(t2,lf[120]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(t2));}

/* mutate-procedure in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2964,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2968,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 624  ##sys#check-closure */
t5=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[119]);}

/* k2966 in mutate-procedure in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 625  ##sys#check-closure */
t3=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[119]);}

/* k2969 in k2966 in mutate-procedure in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2971,2,t0,t1);}
t2=C_block_size(((C_word*)t0)[4]);
t3=C_words(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 628  ##sys#make-vector */
t5=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k2976 in k2969 in k2966 in mutate-procedure in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2978,2,t0,t1);}
t2=C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2981,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2993,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 629  proc */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k2991 in k2976 in k2969 in k2966 in mutate-procedure in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2993,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=C_a_i_list(&a,1,t2);
/* lolevel.scm: 629  ##sys#become! */
t4=*((C_word*)lf[117]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k2979 in k2976 in k2969 in k2966 in mutate-procedure in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-become! in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2955(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2955,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2959,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_i_check_list_2(t4,lf[116]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1001,a[2]=t4,a[3]=t7,a[4]=((C_word)li79),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_1001(t9,t3,t4);}

/* loop in object-become! in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_1001(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1001,NULL,3,t0,t1,t2);}
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=C_i_check_pair_2(t4,lf[116]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1023,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=C_i_car(t4);
/* lolevel.scm: 115  ##sys#check-block */
f_973(t6,t7,C_a_i_list(&a,1,lf[116]));}
else{
/* lolevel.scm: 119  ##sys#signal-hook */
t4=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[6],lf[116],lf[118],((C_word*)t0)[2]);}}}

/* k1021 in loop in object-become! in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_1023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1026,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* lolevel.scm: 116  ##sys#check-block */
f_973(t2,t3,C_a_i_list(&a,1,lf[116]));}

/* k1024 in k1021 in loop in object-become! in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_1026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[4]);
/* lolevel.scm: 117  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1001(t3,((C_word*)t0)[2],t2);}

/* k2957 in object-become! in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 621  ##sys#become! */
t2=*((C_word*)lf[117]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* object-unevict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2826r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2826r(t0,t1,t2,t3);}}

static void C_ccall f_2826r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2830,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_2830(2,t5,C_SCHEME_FALSE);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_2830(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2828 in object-unevict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2833,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 592  make-hash-table */
t3=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[99]+1));}

/* k2831 in k2828 in object-unevict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2833,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2838,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li77),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2838(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* copy in k2831 in k2828 in object-unevict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2838(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2838,NULL,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
if(C_truep(C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 596  hash-table-ref/default */
t4=*((C_word*)lf[97]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2852 in copy in k2831 in k2828 in object-unevict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2854,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(C_byteblockp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 599  ##sys#make-string */
t4=*((C_word*)lf[115]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2883,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
/* lolevel.scm: 604  ##sys#intern-symbol */
C_string_to_symbol(3,0,t2,t3);}
else{
t2=C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2897,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 609  ##sys#make-vector */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}}}

/* k2895 in k2852 in copy in k2831 in k2828 in object-unevict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2897,2,t0,t1);}
t2=C_copy_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2900,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 610  hash-table-set! */
t4=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k2898 in k2895 in k2852 in copy in k2831 in k2828 in object-unevict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2903,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(C_specialp(((C_word*)t0)[4]))?C_fix(1):C_fix(0));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2909,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word)li76),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2909(t7,t2,t3);}

/* doloop848 in k2898 in k2895 in k2852 in copy in k2831 in k2828 in object-unevict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2909(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2909,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2930,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 613  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2838(t5,t3,t4);}}

/* k2928 in doloop848 in k2898 in k2895 in k2852 in copy in k2831 in k2828 in object-unevict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2909(t4,((C_word*)t0)[2],t3);}

/* k2901 in k2898 in k2895 in k2852 in copy in k2831 in k2828 in object-unevict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2881 in k2852 in copy in k2831 in k2828 in object-unevict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 605  hash-table-set! */
t3=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2884 in k2881 in k2852 in copy in k2831 in k2828 in object-unevict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2865 in k2852 in copy in k2831 in k2828 in object-unevict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2867,2,t0,t1);}
t2=C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2870,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 600  hash-table-set! */
t4=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k2868 in k2865 in k2852 in copy in k2831 in k2828 in object-unevict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-size in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2742,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2746,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 575  make-hash-table */
t4=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[99]+1));}

/* k2744 in object-size in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2746,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2751,a[2]=t1,a[3]=t3,a[4]=((C_word)li74),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2751(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2744 in object-size in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2751(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2751,NULL,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 578  hash-table-ref/default */
t4=*((C_word*)lf[97]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}}

/* k2762 in evict in k2744 in object-size in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2764,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2821,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[4]))){
/* lolevel.scm: 582  align-to-word */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t4,t2);}
else{
t5=C_bytes(t2);
t6=t3;
f_2770(t6,C_fixnum_plus(t5,C_bytes(C_fix(1))));}}}

/* k2819 in k2762 in evict in k2744 in object-size in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2770(t2,C_fixnum_plus(t1,C_bytes(C_fix(1))));}

/* k2768 in k2762 in evict in k2744 in object-size in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2770(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2770,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2773,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 584  hash-table-set! */
t5=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k2771 in k2768 in k2762 in evict in k2744 in object-size in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2776,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)((C_word*)t0)[5])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2783,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=C_specialp(((C_word*)t0)[4]);
if(C_truep(t4)){
t5=t3;
f_2783(t5,(C_truep(t4)?C_fix(1):C_fix(0)));}
else{
t5=C_i_symbolp(((C_word*)t0)[4]);
t6=t3;
f_2783(t6,(C_truep(t5)?C_fix(1):C_fix(0)));}}}

/* k2781 in k2771 in k2768 in k2762 in evict in k2744 in object-size in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2783(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2783,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2785,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li73),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2785(t5,((C_word*)t0)[2],t1);}

/* doloop798 in k2781 in k2771 in k2768 in k2762 in evict in k2744 in object-size in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2785(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2785,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2807,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 588  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2751(t5,t3,t4);}}

/* k2805 in doloop798 in k2781 in k2771 in k2768 in k2762 in evict in k2744 in object-size in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_fixnum_plus(t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2785(t5,((C_word*)t0)[2],t4);}

/* k2774 in k2771 in k2768 in k2762 in evict in k2744 in object-size in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* object-release in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_2650r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2650r(t0,t1,t2,t3);}}

static void C_ccall f_2650r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=C_i_pairp(t3);
t5=(C_truep(t4)?C_i_car(t3):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2732,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2659,a[2]=t9,a[3]=t5,a[4]=t7,a[5]=((C_word)li71),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2659(t11,t1,t2);}

/* release in object-release in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2659(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2659,NULL,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
if(C_truep(C_permanentp(t2))){
if(C_truep(C_i_memq(t2,((C_word*)((C_word*)t0)[4])[1]))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_block_size(t2);
t4=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2688,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_byteblockp(t2))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f3393,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 572  ##sys#address->pointer */
t8=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,C_block_address(&a,1,t2));}
else{
t7=(C_truep(C_specialp(t2))?C_fix(1):C_fix(0));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2704,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t9,a[5]=t3,a[6]=((C_word)li70),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_2704(t11,t6,t7);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* doloop772 in release in object-release in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2704(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2704,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2714,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 571  release */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2659(t5,t3,t4);}}

/* k2712 in doloop772 in release in object-release in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2704(t3,((C_word*)t0)[2],t2);}

/* f3393 in release in object-release in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f3393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 572  free */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2686 in release in object-release in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2695,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 572  ##sys#address->pointer */
t3=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_block_address(&a,1,((C_word*)t0)[2]));}

/* k2693 in k2686 in release in object-release in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 572  free */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_2732 in object-release in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2732,3,t0,t1,t2);}
if(C_truep(t2)){
t3=C_i_foreign_pointer_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub756(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,stub756(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2486r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2486r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2486r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2490,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 519  ##sys#check-special */
t6=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[100]);}

/* k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2493,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=C_i_car(((C_word*)t0)[2]);
t4=C_i_check_exact_2(t3,lf[100]);
t5=t2;
f_2493(t5,t3);}
else{
t3=t2;
f_2493(t3,C_SCHEME_FALSE);}}

/* k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2493(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2493,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2496,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2639,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 524  ##sys#pointer->address */
t6=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2637 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 524  ##sys#address->pointer */
t2=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 525  make-hash-table */
t3=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[99]+1));}

/* k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2502,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2507,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word)li67),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2507(t6,t2,((C_word*)t0)[2]);}

/* evict in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2507(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2507,NULL,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 529  hash-table-ref/default */
t4=*((C_word*)lf[97]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2515 in evict in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2517,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2632,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[6]))){
/* lolevel.scm: 533  align-to-word */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t4,t2);}
else{
t5=C_bytes(t2);
t6=t3;
f_2526(t6,C_fixnum_plus(t5,C_bytes(C_fix(1))));}}}

/* k2630 in k2515 in evict in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2526(t2,C_fixnum_plus(t1,C_bytes(C_fix(1))));}

/* k2524 in k2515 in evict in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2526(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2526,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2529,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],t1);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
if(C_truep(C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2616,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2620,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[2])[1]);
/* lolevel.scm: 540  make-property-condition */
t8=*((C_word*)lf[104]+1);
((C_proc9)(void*)(*((C_word*)t8+1)))(9,t8,t6,lf[107],lf[108],lf[100],lf[109],lf[110],lf[111],t7);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t2;
f_2529(2,t6,t5);}}
else{
t3=t2;
f_2529(2,t3,C_SCHEME_UNDEFINED);}}

/* k2618 in k2524 in k2515 in evict in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2624,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 544  make-property-condition */
t3=*((C_word*)lf[104]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[105],lf[106],((C_word*)((C_word*)t0)[2])[1]);}

/* k2622 in k2618 in k2524 in k2515 in evict in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 539  make-composite-condition */
t2=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2614 in k2524 in k2515 in evict in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 538  signal */
t2=*((C_word*)lf[102]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2527 in k2524 in k2515 in evict in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2529,2,t0,t1);}
t2=C_evict_block(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2532,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[8]))){
t4=*((C_word*)lf[96]+1);
t5=t3;
f_2532(t5,C_i_set_i_slot(t2,C_fix(0),t4));}
else{
t4=t3;
f_2532(t4,C_SCHEME_UNDEFINED);}}

/* k2530 in k2527 in k2524 in k2515 in evict in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2532(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2532,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2589,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 547  ##sys#pointer->address */
t4=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2587 in k2530 in k2527 in k2524 in k2515 in evict in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2589,2,t0,t1);}
t2=C_a_i_plus(&a,2,t1,((C_word*)t0)[4]);
/* lolevel.scm: 547  ##sys#set-pointer-address! */
t3=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2533 in k2530 in k2527 in k2524 in k2515 in evict in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2538,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 548  hash-table-set! */
t3=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2536 in k2533 in k2530 in k2527 in k2524 in k2515 in evict in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2541,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2548,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=C_specialp(((C_word*)t0)[4]);
if(C_truep(t4)){
t5=t3;
f_2548(t5,(C_truep(t4)?C_fix(1):C_fix(0)));}
else{
t5=C_i_symbolp(((C_word*)t0)[4]);
t6=t3;
f_2548(t6,(C_truep(t5)?C_fix(1):C_fix(0)));}}}

/* k2546 in k2536 in k2533 in k2530 in k2527 in k2524 in k2515 in evict in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2548(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2548,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li66),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2550(t5,((C_word*)t0)[2],t1);}

/* doloop731 in k2546 in k2536 in k2533 in k2530 in k2527 in k2524 in k2515 in evict in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2550(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2550,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2571,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 552  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2507(t5,t3,t4);}}

/* k2569 in doloop731 in k2546 in k2536 in k2533 in k2530 in k2527 in k2524 in k2515 in evict in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2550(t4,((C_word*)t0)[2],t3);}

/* k2539 in k2536 in k2533 in k2530 in k2527 in k2524 in k2515 in evict in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2500 in k2497 in k2494 in k2491 in k2488 in object-evict-to-location in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 554  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* object-evict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2368r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2368r(t0,t1,t2,t3);}}

static void C_ccall f_2368r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t4=C_i_pairp(t3);
t5=(C_truep(t4)?C_i_car(t3):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2479,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2375,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 500  make-hash-table */
t7=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,*((C_word*)lf[99]+1));}

/* k2373 in object-evict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 501  ##sys#check-closure */
t3=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[94]);}

/* k2376 in k2373 in object-evict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2378,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2383,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word)li64),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2383(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2376 in k2373 in object-evict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2383(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2383,NULL,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 504  hash-table-ref/default */
t4=*((C_word*)lf[97]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2391 in evict in k2376 in k2373 in object-evict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2393,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[5]))){
/* lolevel.scm: 507  align-to-word */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t3,t2);}
else{
t4=t3;
f_2402(2,t4,C_bytes(t2));}}}

/* k2400 in k2391 in evict in k2376 in k2373 in object-evict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2406,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_fixnum_plus(t1,C_bytes(C_fix(1)));
/* lolevel.scm: 508  allocator */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2404 in k2400 in k2391 in evict in k2376 in k2373 in object-evict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2406,2,t0,t1);}
t2=C_evict_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[6]))){
t4=*((C_word*)lf[96]+1);
t5=t3;
f_2409(t5,C_i_set_i_slot(t2,C_fix(0),t4));}
else{
t4=t3;
f_2409(t4,C_SCHEME_UNDEFINED);}}

/* k2407 in k2404 in k2400 in k2391 in evict in k2376 in k2373 in object-evict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2409,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2412,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 510  hash-table-set! */
t3=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2410 in k2407 in k2404 in k2400 in k2391 in evict in k2376 in k2373 in object-evict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2415,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2422,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=C_specialp(((C_word*)t0)[4]);
if(C_truep(t4)){
t5=t3;
f_2422(t5,(C_truep(t4)?C_fix(1):C_fix(0)));}
else{
t5=C_i_symbolp(((C_word*)t0)[4]);
t6=t3;
f_2422(t6,(C_truep(t5)?C_fix(1):C_fix(0)));}}}

/* k2420 in k2410 in k2407 in k2404 in k2400 in k2391 in evict in k2376 in k2373 in object-evict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2422(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2422,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2424,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li63),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2424(t5,((C_word*)t0)[2],t1);}

/* doloop675 in k2420 in k2410 in k2407 in k2404 in k2400 in k2391 in evict in k2376 in k2373 in object-evict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2424(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2424,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2445,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 515  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2383(t5,t3,t4);}}

/* k2443 in doloop675 in k2420 in k2410 in k2407 in k2404 in k2400 in k2391 in evict in k2376 in k2373 in object-evict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2424(t4,((C_word*)t0)[2],t3);}

/* k2413 in k2410 in k2407 in k2404 in k2400 in k2391 in evict in k2376 in k2373 in object-evict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2479 in object-evict in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2479,3,t0,t1,t2);}
t3=C_a_i_bytevector(&a,1,C_fix(3));
t4=C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,stub650(t3,t4));}

/* object-evicted? in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2365(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2365,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_permanentp(t2));}

/* record->vector in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2327(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2327,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2331,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 482  ##sys#check-generic-structure */
f_1046(t3,t2,C_a_i_list(&a,1,lf[92]));}

/* k2329 in record->vector in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2331,2,t0,t1);}
t2=C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 484  ##sys#make-vector */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2335 in k2329 in record->vector in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2342,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li59),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2342(t2,C_fix(0)));}

/* doloop634 in k2335 in k2329 in record->vector in k2323 in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static C_word C_fcall f_2342(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
return(t2);}
else{
t2=C_slot(((C_word*)t0)[2],t1);
t3=C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=C_fixnum_plus(t1,C_fix(1));
t7=t4;
t1=t7;
goto loop;}}

/* record-instance-slot-set! in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2299,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2303,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 469  ##sys#check-generic-structure */
f_1046(t5,t2,C_a_i_list(&a,1,lf[89]));}

/* k2301 in record-instance-slot-set! in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_block_size(((C_word*)t0)[3]);
t4=C_fixnum_difference(t3,C_fix(1));
/* lolevel.scm: 470  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[90]+1)))(6,*((C_word*)lf[90]+1),t2,((C_word*)t0)[5],C_fix(0),t4,lf[89]);}

/* k2304 in k2301 in record-instance-slot-set! in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_setslot(((C_word*)t0)[3],t2,((C_word*)t0)[2]));}

/* record-instance-length in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2286,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2290,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 465  ##sys#check-generic-structure */
f_1046(t3,t2,C_a_i_list(&a,1,lf[88]));}

/* k2288 in record-instance-length in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_block_size(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fixnum_difference(t2,C_fix(1)));}

/* record-instance-type in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2277,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2281,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 461  ##sys#check-generic-structure */
f_1046(t3,t2,C_a_i_list(&a,1,lf[87]));}

/* k2279 in record-instance-type in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_slot(((C_word*)t0)[2],C_fix(0)));}

/* record-instance? in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2228r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2228r(t0,t1,t2,t3);}}

static void C_ccall f_2228r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2232,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_2232(2,t5,C_SCHEME_FALSE);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_2232(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2230 in record-instance? in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_blockp(t3))){
t4=C_structurep(t3);
t5=t2;
f_2243(t5,t4);}
else{
t4=t2;
f_2243(t4,C_SCHEME_FALSE);}}

/* k2241 in k2230 in record-instance? in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_2243(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_i_not(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=C_slot(((C_word*)t0)[2],C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_eqp(((C_word*)t0)[4],t3));}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* make-record-instance in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2219(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_2219r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2219r(t0,t1,t2,t3);}}

static void C_ccall f_2219r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=C_i_check_symbol_2(t2,lf[84]);
C_apply(5,0,t1,*((C_word*)lf[85]+1),t2,t3);}

/* number-of-bytes in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2197,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
if(C_truep(C_byteblockp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_block_size(t2));}
else{
t3=C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_w2b(t3));}}
else{
/* lolevel.scm: 435  ##sys#signal-hook */
t3=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[6],lf[82],lf[83],t2);}}

/* number-of-slots in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2188,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2192,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_a_i_list(&a,1,lf[80]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1092,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_blockp(t4))){
t7=C_specialp(t4);
if(C_truep(t7)){
t8=t6;
f_1092(t8,C_i_not(t7));}
else{
t8=C_byteblockp(t4);
t9=t6;
f_1092(t9,C_i_not(t8));}}
else{
t7=t6;
f_1092(t7,C_SCHEME_FALSE);}}

/* k1090 in number-of-slots in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_fcall f_1092(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_block_size(((C_word*)t0)[5]));}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=C_i_car(((C_word*)t0)[4]);
/* lolevel.scm: 133  ##sys#signal-hook */
t3=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[6],t2,lf[81],((C_word*)t0)[2]);}
else{
/* lolevel.scm: 133  ##sys#signal-hook */
t2=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[6],C_SCHEME_FALSE,lf[81],((C_word*)t0)[2]);}}}

/* k2190 in number-of-slots in k2184 in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_block_size(((C_word*)t0)[2]));}

/* set-procedure-data! in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2168,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2172,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 416  extend-procedure */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k2170 in set-procedure-data! in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_eqp(t1,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* lolevel.scm: 419  ##sys#signal-hook */
t3=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],lf[6],lf[75],lf[76],((C_word*)t0)[3]);}}

/* procedure-data in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2129(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2129,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
if(C_truep(C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2160,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2143,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 401  ##sys#lambda-decoration */
t6=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2142 in procedure-data in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2143,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_eqp(lf[68],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2158 in procedure-data in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_slot(t1,C_fix(1)):C_SCHEME_FALSE));}

/* extended-procedure? in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2093,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
if(C_truep(C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2127,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2110,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 401  ##sys#lambda-decoration */
t6=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2109 in extended-procedure? in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2110(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2110,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_eqp(lf[68],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2125 in extended-procedure? in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* extend-procedure in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2058,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2062,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 394  ##sys#check-closure */
t5=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[69]);}

/* k2060 in extend-procedure in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2067,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2083,a[2]=((C_word*)t0)[4],a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 395  ##sys#decorate-lambda */
t4=*((C_word*)lf[70]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a2082 in k2060 in extend-procedure in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2083,4,t0,t1,t2,t3);}
t4=C_a_i_cons(&a,2,lf[68],((C_word*)t0)[2]);
t5=C_i_setslot(t2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* a2066 in k2060 in extend-procedure in k2050 in k2046 in k2042 in k2038 in k2034 in k2030 in k2026 in k2022 in k1985 in k969 in k966 */
static void C_ccall f_2067(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2067,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_eqp(lf[68],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer-f64-set! in k1985 in k969 in k966 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2019,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_pointer_f64_set(t2,t3));}

/* pointer-f32-set! in k1985 in k969 in k966 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2016,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_pointer_f32_set(t2,t3));}

/* pointer-s32-set! in k1985 in k969 in k966 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2013,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_pointer_s32_set(t2,t3));}

/* pointer-u32-set! in k1985 in k969 in k966 */
static void C_ccall f_2010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2010,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_pointer_u32_set(t2,t3));}

/* pointer-s16-set! in k1985 in k969 in k966 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2007,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_pointer_s16_set(t2,t3));}

/* pointer-u16-set! in k1985 in k969 in k966 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2004,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_pointer_u16_set(t2,t3));}

/* pointer-s8-set! in k1985 in k969 in k966 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2001,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_pointer_s8_set(t2,t3));}

/* pointer-u8-set! in k1985 in k969 in k966 */
static void C_ccall f_1998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1998,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_pointer_u8_set(t2,t3));}

/* locative? in k1985 in k969 in k966 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1992,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
t3=C_locativep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* locative->object in k1985 in k969 in k966 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1989,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_locative_to_object(t2));}

/* locative-set! in k969 in k966 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1982,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_locative_set(t2,t3));}

/* make-weak-locative in k969 in k966 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1953r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1953r(t0,t1,t2,t3);}}

static void C_ccall f_1953r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1961,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* lolevel.scm: 328  ##sys#make-locative */
t5=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,t2,C_fix(0),C_SCHEME_TRUE,lf[46]);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=C_i_car(t3);
/* lolevel.scm: 328  ##sys#make-locative */
t7=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t6,C_SCHEME_TRUE,lf[46]);}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1959 in make-weak-locative in k969 in k966 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 328  ##sys#make-locative */
t2=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE,lf[46]);}

/* make-locative in k969 in k966 */
static void C_ccall f_1924(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1924r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1924r(t0,t1,t2,t3);}}

static void C_ccall f_1924r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1932,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* lolevel.scm: 325  ##sys#make-locative */
t5=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,t2,C_fix(0),C_SCHEME_FALSE,lf[44]);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=C_i_car(t3);
/* lolevel.scm: 325  ##sys#make-locative */
t7=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t6,C_SCHEME_FALSE,lf[44]);}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1930 in make-locative in k969 in k966 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 325  ##sys#make-locative */
t2=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,lf[44]);}

/* pointer-tag in k969 in k966 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1901,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1913,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
if(C_truep(C_blockp(t4))){
t5=C_specialp(t4);
t6=t3;
f_1913(t6,t5);}
else{
t5=t3;
f_1913(t5,C_SCHEME_FALSE);}}

/* k1911 in pointer-tag in k969 in k966 */
static void C_fcall f_1913(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_taggedpointerp(((C_word*)t0)[2]))?C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE));}
else{
/* lolevel.scm: 302  ##sys#error-hook */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),lf[43],((C_word*)t0)[2]);}}

/* tagged-pointer? in k969 in k966 */
static void C_ccall f_1857(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1857r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1857r(t0,t1,t2,t3);}}

static void C_ccall f_1857r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1861,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_1861(2,t5,C_SCHEME_FALSE);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_1861(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1859 in tagged-pointer? in k969 in k966 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(C_blockp(((C_word*)t0)[3]))){
if(C_truep(C_taggedpointerp(((C_word*)t0)[3]))){
t2=C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_equalp(t1,t3));}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* tag-pointer in k969 in k966 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1837,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1841,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 287  ##sys#make-tagged-pointer */
t5=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k1839 in tag-pointer in k969 in k966 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1844,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1852,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
if(C_truep(C_blockp(t4))){
t5=C_specialp(t4);
t6=t3;
f_1852(t6,t5);}
else{
t5=t3;
f_1852(t5,C_SCHEME_FALSE);}}

/* k1850 in k1839 in tag-pointer in k969 in k966 */
static void C_fcall f_1852(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_copy_pointer(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
/* lolevel.scm: 290  ##sys#error-hook */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),lf[40],((C_word*)t0)[5]);}}

/* k1842 in k1839 in tag-pointer in k969 in k966 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* align-to-word in k969 in k966 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1800,3,t0,t1,t2);}
if(C_truep(C_i_integerp(t2))){
t3=t1;
t4=t2;
t5=C_a_i_bytevector(&a,1,C_fix(4));
t6=C_i_foreign_integer_argumentp(t4);
t7=t3;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,stub410(t5,t6));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1821,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
if(C_truep(C_blockp(t4))){
t5=C_specialp(t4);
t6=t3;
f_1821(t6,t5);}
else{
t5=t3;
f_1821(t5,C_SCHEME_FALSE);}}}

/* k1819 in align-to-word in k969 in k966 */
static void C_fcall f_1821(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1821,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1832,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 277  ##sys#pointer->address */
t3=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
/* lolevel.scm: 279  ##sys#signal-hook */
t2=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[6],lf[38],lf[39],((C_word*)t0)[2]);}}

/* k1830 in k1819 in align-to-word in k969 in k966 */
static void C_ccall f_1832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1832,2,t0,t1);}
t2=C_a_i_bytevector(&a,1,C_fix(4));
t3=C_i_foreign_integer_argumentp(t1);
t4=stub410(t2,t3);
/* lolevel.scm: 277  ##sys#address->pointer */
t5=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,((C_word*)t0)[2],t4);}

/* pointer+ in k969 in k966 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1779,4,t0,t1,t2,t3);}
t4=C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_truep(t2)?C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=C_i_foreign_integer_argumentp(t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,stub401(t4,t5,t6));}

/* pointer=? in k969 in k966 */
static void C_ccall f_1770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1770,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1774,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 261  ##sys#check-special */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[35]);}

/* k1772 in pointer=? in k969 in k966 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 262  ##sys#check-special */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[35]);}

/* k1775 in k1772 in pointer=? in k969 in k966 */
static void C_ccall f_1777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_pointer_eqp(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* pointer->object in k969 in k966 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1764,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1768,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 257  ##sys#check-pointer */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[34]);}

/* k1766 in pointer->object in k969 in k966 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_pointer_to_object(((C_word*)t0)[2]));}

/* object->pointer in k969 in k966 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1753,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
t3=t1;
t4=t2;
t5=C_a_i_bytevector(&a,1,C_fix(3));
t6=t3;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,stub387(t5,t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* null-pointer? in k969 in k966 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1747,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1751,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 249  ##sys#check-special */
t4=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[32]);}

/* k1749 in null-pointer? in k969 in k966 */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_null_pointerp(((C_word*)t0)[2]));}

/* pointer->address in k969 in k966 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1737,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1741,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 243  ##sys#check-special */
t4=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[27]);}

/* k1739 in pointer->address in k969 in k966 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 244  ##sys#pointer->address */
t2=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* address->pointer in k969 in k966 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1728,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1732,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 239  ##sys#check-integer */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[24]);}

/* k1730 in address->pointer in k969 in k966 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 240  ##sys#address->pointer */
t2=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pointer-like? in k969 in k966 */
static void C_ccall f_1717(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1717,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
t3=C_specialp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer? in k969 in k966 */
static void C_ccall f_1709(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1709,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_safe_pointerp(t2));}

/* free in k969 in k966 */
static void C_ccall f_1699(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1699,3,t0,t1,t2);}
if(C_truep(t2)){
t3=C_i_foreign_pointer_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub354(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,stub354(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* allocate in k969 in k966 */
static void C_ccall f_1692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1692,3,t0,t1,t2);}
t3=C_a_i_bytevector(&a,1,C_fix(3));
t4=C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,stub349(t3,t4));}

/* object-copy in k969 in k966 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1611,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1617,a[2]=t4,a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1617(t6,t1,t2);}

/* copy in object-copy in k969 in k966 */
static void C_fcall f_1617(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1617,NULL,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
if(C_truep(C_i_symbolp(t2))){
t3=C_slot(t2,C_fix(1));
/* lolevel.scm: 217  ##sys#intern-symbol */
C_string_to_symbol(3,0,t1,t3);}
else{
t3=C_block_size(t2);
t4=(C_truep(C_byteblockp(t2))?C_words(t3):t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1647,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 221  ##sys#make-vector */
t6=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1645 in copy in object-copy in k969 in k966 */
static void C_ccall f_1647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1647,2,t0,t1);}
t2=C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1650,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_byteblockp(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:C_i_symbolp(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_truep(C_specialp(((C_word*)t0)[5]))?C_fix(1):C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1662,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word)li13),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_1662(t10,t3,t6);}}

/* doloop339 in k1645 in copy in object-copy in k969 in k966 */
static void C_fcall f_1662(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1662,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1683,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 225  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1617(t5,t3,t4);}}

/* k1681 in doloop339 in k1645 in copy in object-copy in k969 in k966 */
static void C_ccall f_1683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1662(t4,((C_word*)t0)[2],t3);}

/* k1648 in k1645 in copy in object-copy in k969 in k966 */
static void C_ccall f_1650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* move-memory! in k969 in k966 */
static void C_ccall f_1248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_1248r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1248r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1248r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1250,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word)li8),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1538,a[2]=t5,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1543,a[2]=t6,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1548,a[2]=t7,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
/* def-n176310 */
t9=t8;
f_1548(t9,t1);}
else{
t9=C_i_car(t4);
t10=C_i_cdr(t4);
if(C_truep(C_i_nullp(t10))){
/* def-foffset177308 */
t11=t7;
f_1543(t11,t1,t9);}
else{
t11=C_i_car(t10);
t12=C_i_cdr(t10);
if(C_truep(C_i_nullp(t12))){
/* def-toffset178305 */
t13=t6;
f_1538(t13,t1,t9,t11);}
else{
t13=C_i_car(t12);
t14=C_i_cdr(t12);
if(C_truep(C_i_nullp(t14))){
/* body174183 */
t15=t5;
f_1250(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-n176 in move-memory! in k969 in k966 */
static void C_fcall f_1548(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1548,NULL,2,t0,t1);}
/* def-foffset177308 */
t2=((C_word*)t0)[2];
f_1543(t2,t1,C_SCHEME_FALSE);}

/* def-foffset177 in move-memory! in k969 in k966 */
static void C_fcall f_1543(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1543,NULL,3,t0,t1,t2);}
/* def-toffset178305 */
t3=((C_word*)t0)[2];
f_1538(t3,t1,t2,C_fix(0));}

/* def-toffset178 in move-memory! in k969 in k966 */
static void C_fcall f_1538(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1538,NULL,4,t0,t1,t2,t3);}
/* body174183 */
t4=((C_word*)t0)[2];
f_1250(t4,t1,t2,t3,C_fix(0));}

/* body174 in move-memory! in k969 in k966 */
static void C_fcall f_1250(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[41],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1250,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1253,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li3),tmp=(C_word)a,a+=5,tmp));
t14=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1259,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp));
t15=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1265,a[2]=t8,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp));
t16=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1281,a[2]=t8,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t17=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1308,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t12,a[6]=t10,a[7]=t6,a[8]=t3,a[9]=t4,a[10]=t2,a[11]=((C_word*)t0)[2],tmp=(C_word)a,a+=12,tmp);
/* lolevel.scm: 177  ##sys#check-block */
f_973(t17,((C_word*)t0)[4],C_a_i_list(&a,1,lf[11]));}

/* k1306 in body174 in move-memory! in k969 in k966 */
static void C_ccall f_1308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* lolevel.scm: 178  ##sys#check-block */
f_973(t2,((C_word*)t0)[2],C_a_i_list(&a,1,lf[11]));}

/* k1309 in k1306 in body174 in move-memory! in k969 in k966 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[8],C_fix(0)))){
/* lolevel.scm: 180  ##sys#error */
t3=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[11],lf[17],((C_word*)t0)[8]);}
else{
t3=t2;
f_1314(2,t3,C_SCHEME_UNDEFINED);}}

/* k1312 in k1309 in k1306 in body174 in move-memory! in k969 in k966 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[9],C_fix(0)))){
/* lolevel.scm: 182  ##sys#error */
t3=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[11],lf[16],((C_word*)t0)[9]);}
else{
t3=t2;
f_1317(2,t3,C_SCHEME_UNDEFINED);}}

/* k1315 in k1312 in k1309 in k1306 in body174 in move-memory! in k969 in k966 */
static void C_ccall f_1317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1317,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1322,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t3,a[9]=((C_word*)t0)[11],a[10]=((C_word)li7),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_1322(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* move in k1315 in k1312 in k1309 in k1306 in body174 in move-memory! in k969 in k966 */
static void C_fcall f_1322(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1322,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_structurep(t2))){
t4=C_slot(t2,C_fix(0));
if(C_truep(C_i_memq(t4,((C_word*)t0)[9]))){
t5=C_slot(t2,C_fix(1));
/* lolevel.scm: 186  move */
t17=t1;
t18=t5;
t19=t3;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t5=t1;
t6=t2;
/* lolevel.scm: 153  ##sys#error-hook */
t7=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[11],t6);}}
else{
if(C_truep(C_structurep(t3))){
t4=C_slot(t3,C_fix(0));
if(C_truep(C_i_memq(t4,((C_word*)t0)[9]))){
t5=C_slot(t3,C_fix(1));
/* lolevel.scm: 190  move */
t17=t1;
t18=t2;
t19=t5;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t5=t1;
t6=t3;
/* lolevel.scm: 153  ##sys#error-hook */
t7=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[11],t6);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t3,a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t5=t2;
t6=C_i_safe_pointerp(t5);
if(C_truep(t6)){
t7=t4;
f_1391(t7,t6);}
else{
t7=C_locativep(t5);
t8=t4;
f_1391(t8,t7);}}}}

/* k1389 in move in k1315 in k1312 in k1309 in k1306 in body174 in move-memory! in k969 in k966 */
static void C_fcall f_1391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1391,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[8];
t4=C_i_safe_pointerp(t3);
if(C_truep(t4)){
t5=t2;
f_1407(t5,t4);}
else{
t5=C_locativep(t3);
t6=t2;
f_1407(t6,t5);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm: 199  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,((C_word*)t0)[7]);}}

/* k1454 in k1389 in move in k1315 in k1312 in k1309 in k1306 in body174 in move-memory! in k969 in k966 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1456,2,t0,t1);}
t2=(C_truep(t1)?t1:C_i_stringp(((C_word*)t0)[9]));
if(C_truep(t2)){
t3=C_block_size(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1478,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=((C_word*)t0)[7];
t6=C_i_safe_pointerp(t5);
if(C_truep(t6)){
t7=t4;
f_1478(t7,t6);}
else{
t7=C_locativep(t5);
t8=t4;
f_1478(t8,t7);}}
else{
t3=((C_word*)t0)[8];
t4=((C_word*)t0)[9];
/* lolevel.scm: 153  ##sys#error-hook */
t5=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[11],t4);}}

/* k1476 in k1454 in k1389 in move in k1315 in k1312 in k1309 in k1306 in body174 in move-memory! in k969 in k966 */
static void C_fcall f_1478(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1478,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1485,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[5];
if(C_truep(t3)){
/* lolevel.scm: 202  checkn1 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1265(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[6]);}
else{
/* lolevel.scm: 202  checkn1 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1265(t4,t2,((C_word*)t0)[3],((C_word*)t0)[3],((C_word*)t0)[6]);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm: 203  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,((C_word*)t0)[9]);}}

/* k1493 in k1476 in k1454 in k1389 in move in k1315 in k1312 in k1309 in k1306 in body174 in move-memory! in k969 in k966 */
static void C_ccall f_1495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1495,2,t0,t1);}
t2=(C_truep(t1)?t1:C_i_stringp(((C_word*)t0)[9]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[4];
t5=(C_truep(t4)?t4:((C_word*)t0)[3]);
t6=C_block_size(((C_word*)t0)[9]);
/* lolevel.scm: 204  checkn2 */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1281(t7,t3,t5,((C_word*)t0)[3],t6,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[8];
t4=((C_word*)t0)[9];
/* lolevel.scm: 153  ##sys#error-hook */
t5=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[11],t4);}}

/* k1503 in k1493 in k1476 in k1454 in k1389 in move in k1315 in k1312 in k1309 in k1306 in body174 in move-memory! in k969 in k966 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=C_i_foreign_fixnum_argumentp(t1);
t10=C_i_foreign_fixnum_argumentp(t5);
t11=C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,stub145(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1483 in k1476 in k1454 in k1389 in move in k1315 in k1312 in k1309 in k1306 in body174 in move-memory! in k969 in k966 */
static void C_ccall f_1485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=C_i_foreign_fixnum_argumentp(t1);
t10=C_i_foreign_fixnum_argumentp(t5);
t11=C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,stub113(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1405 in k1389 in move in k1315 in k1312 in k1309 in k1306 in body174 in move-memory! in k969 in k966 */
static void C_fcall f_1407(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1407,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1414,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_1414(2,t4,t2);}
else{
/* lolevel.scm: 194  nosizerr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1253(t4,t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1423,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm: 195  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,((C_word*)t0)[7]);}}

/* k1421 in k1405 in k1389 in move in k1315 in k1312 in k1309 in k1306 in body174 in move-memory! in k969 in k966 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1423,2,t0,t1);}
t2=(C_truep(t1)?t1:C_i_stringp(((C_word*)t0)[9]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1433,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1437,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=C_block_size(((C_word*)t0)[9]);
/* lolevel.scm: 196  checkn1 */
t7=((C_word*)((C_word*)t0)[3])[1];
f_1265(t7,t3,t4,t6,((C_word*)t0)[6]);}
else{
/* lolevel.scm: 196  nosizerr */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1253(t6,t5);}}
else{
t3=((C_word*)t0)[8];
t4=((C_word*)t0)[9];
/* lolevel.scm: 153  ##sys#error-hook */
t5=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[11],t4);}}

/* k1435 in k1421 in k1405 in k1389 in move in k1315 in k1312 in k1309 in k1306 in body174 in move-memory! in k969 in k966 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 196  checkn1 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1265(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k1431 in k1421 in k1405 in k1389 in move in k1315 in k1312 in k1309 in k1306 in body174 in move-memory! in k969 in k966 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=C_i_foreign_fixnum_argumentp(t1);
t10=C_i_foreign_fixnum_argumentp(t5);
t11=C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,stub129(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1412 in k1405 in k1389 in move in k1315 in k1312 in k1309 in k1306 in body174 in move-memory! in k969 in k966 */
static void C_ccall f_1414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=C_i_foreign_fixnum_argumentp(t1);
t10=C_i_foreign_fixnum_argumentp(t5);
t11=C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,stub97(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* checkn2 in body174 in move-memory! in k969 in k966 */
static void C_fcall f_1281(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1281,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1288,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t8=C_fixnum_difference(t3,t5);
if(C_truep(C_fixnum_less_or_equal_p(t2,t8))){
t9=C_fixnum_difference(t4,t6);
t10=t7;
f_1288(t10,C_fixnum_less_or_equal_p(t2,t9));}
else{
t9=t7;
f_1288(t9,C_SCHEME_FALSE);}}

/* k1286 in checkn2 in body174 in move-memory! in k969 in k966 */
static void C_fcall f_1288(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1288,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* lolevel.scm: 175  sizerr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1259(t2,((C_word*)t0)[5],C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]));}}

/* checkn1 in body174 in move-memory! in k969 in k966 */
static void C_fcall f_1265(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1265,NULL,5,t0,t1,t2,t3,t4);}
t5=C_fixnum_difference(t3,t4);
if(C_truep(C_fixnum_less_or_equal_p(t2,t5))){
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* lolevel.scm: 170  sizerr */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1259(t6,t1,C_a_i_list(&a,2,t2,t3));}}

/* sizerr in body174 in move-memory! in k969 in k966 */
static void C_fcall f_1259(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1259,NULL,3,t0,t1,t2);}
C_apply(8,0,t1,*((C_word*)lf[12]+1),lf[11],lf[14],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* nosizerr in body174 in move-memory! in k969 in k966 */
static void C_fcall f_1253(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1253,NULL,2,t0,t1);}
/* lolevel.scm: 162  ##sys#error */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[11],lf[13],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#check-pointer in k969 in k966 */
static void C_ccall f_1107(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_1107r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1107r(t0,t1,t2,t3);}}

static void C_ccall f_1107r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t4=t2;
if(C_truep(C_i_safe_pointerp(t4))){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep(C_i_pairp(t3))){
t5=C_i_car(t3);
/* lolevel.scm: 139  ##sys#error-hook */
t6=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),t5,lf[9],t2);}
else{
/* lolevel.scm: 139  ##sys#error-hook */
t5=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),C_SCHEME_FALSE,lf[9],t2);}}}

/* ##sys#check-generic-structure in k969 in k966 */
static void C_fcall f_1046(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1046,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1058,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=t2;
if(C_truep(C_blockp(t5))){
t6=C_structurep(t5);
t7=t4;
f_1058(t7,t6);}
else{
t6=t4;
f_1058(t6,C_SCHEME_FALSE);}}

/* k1056 in ##sys#check-generic-structure in k969 in k966 */
static void C_fcall f_1058(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=C_i_car(((C_word*)t0)[3]);
/* lolevel.scm: 125  ##sys#signal-hook */
t3=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[6],t2,lf[7],((C_word*)t0)[2]);}
else{
/* lolevel.scm: 125  ##sys#signal-hook */
t2=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[6],C_SCHEME_FALSE,lf[7],((C_word*)t0)[2]);}}}

/* ##sys#check-block in k969 in k966 */
static void C_fcall f_973(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_973,NULL,3,t1,t2,t3);}
if(C_truep(C_blockp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep(C_i_pairp(t3))){
t4=C_i_car(t3);
/* lolevel.scm: 104  ##sys#error-hook */
t5=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_BLOCK_ERROR),t4,t2);}
else{
/* lolevel.scm: 104  ##sys#error-hook */
t4=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_BLOCK_ERROR),C_SCHEME_FALSE,t2);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[222] = {
{"toplevel:lolevel_scm",(void*)C_lolevel_toplevel},
{"f_968:lolevel_scm",(void*)f_968},
{"f_971:lolevel_scm",(void*)f_971},
{"f_1987:lolevel_scm",(void*)f_1987},
{"f_3077:lolevel_scm",(void*)f_3077},
{"f_2024:lolevel_scm",(void*)f_2024},
{"f_3074:lolevel_scm",(void*)f_3074},
{"f_2028:lolevel_scm",(void*)f_2028},
{"f_3071:lolevel_scm",(void*)f_3071},
{"f_2032:lolevel_scm",(void*)f_2032},
{"f_3068:lolevel_scm",(void*)f_3068},
{"f_2036:lolevel_scm",(void*)f_2036},
{"f_3065:lolevel_scm",(void*)f_3065},
{"f_2040:lolevel_scm",(void*)f_2040},
{"f_3062:lolevel_scm",(void*)f_3062},
{"f_2044:lolevel_scm",(void*)f_2044},
{"f_3059:lolevel_scm",(void*)f_3059},
{"f_2048:lolevel_scm",(void*)f_2048},
{"f_3056:lolevel_scm",(void*)f_3056},
{"f_2052:lolevel_scm",(void*)f_2052},
{"f_2186:lolevel_scm",(void*)f_2186},
{"f_3032:lolevel_scm",(void*)f_3032},
{"f_3036:lolevel_scm",(void*)f_3036},
{"f_3039:lolevel_scm",(void*)f_3039},
{"f_2325:lolevel_scm",(void*)f_2325},
{"f_3019:lolevel_scm",(void*)f_3019},
{"f_3010:lolevel_scm",(void*)f_3010},
{"f_3001:lolevel_scm",(void*)f_3001},
{"f_2995:lolevel_scm",(void*)f_2995},
{"f_2964:lolevel_scm",(void*)f_2964},
{"f_2968:lolevel_scm",(void*)f_2968},
{"f_2971:lolevel_scm",(void*)f_2971},
{"f_2978:lolevel_scm",(void*)f_2978},
{"f_2993:lolevel_scm",(void*)f_2993},
{"f_2981:lolevel_scm",(void*)f_2981},
{"f_2955:lolevel_scm",(void*)f_2955},
{"f_1001:lolevel_scm",(void*)f_1001},
{"f_1023:lolevel_scm",(void*)f_1023},
{"f_1026:lolevel_scm",(void*)f_1026},
{"f_2959:lolevel_scm",(void*)f_2959},
{"f_2826:lolevel_scm",(void*)f_2826},
{"f_2830:lolevel_scm",(void*)f_2830},
{"f_2833:lolevel_scm",(void*)f_2833},
{"f_2838:lolevel_scm",(void*)f_2838},
{"f_2854:lolevel_scm",(void*)f_2854},
{"f_2897:lolevel_scm",(void*)f_2897},
{"f_2900:lolevel_scm",(void*)f_2900},
{"f_2909:lolevel_scm",(void*)f_2909},
{"f_2930:lolevel_scm",(void*)f_2930},
{"f_2903:lolevel_scm",(void*)f_2903},
{"f_2883:lolevel_scm",(void*)f_2883},
{"f_2886:lolevel_scm",(void*)f_2886},
{"f_2867:lolevel_scm",(void*)f_2867},
{"f_2870:lolevel_scm",(void*)f_2870},
{"f_2742:lolevel_scm",(void*)f_2742},
{"f_2746:lolevel_scm",(void*)f_2746},
{"f_2751:lolevel_scm",(void*)f_2751},
{"f_2764:lolevel_scm",(void*)f_2764},
{"f_2821:lolevel_scm",(void*)f_2821},
{"f_2770:lolevel_scm",(void*)f_2770},
{"f_2773:lolevel_scm",(void*)f_2773},
{"f_2783:lolevel_scm",(void*)f_2783},
{"f_2785:lolevel_scm",(void*)f_2785},
{"f_2807:lolevel_scm",(void*)f_2807},
{"f_2776:lolevel_scm",(void*)f_2776},
{"f_2650:lolevel_scm",(void*)f_2650},
{"f_2659:lolevel_scm",(void*)f_2659},
{"f_2704:lolevel_scm",(void*)f_2704},
{"f_2714:lolevel_scm",(void*)f_2714},
{"f3393:lolevel_scm",(void*)f3393},
{"f_2688:lolevel_scm",(void*)f_2688},
{"f_2695:lolevel_scm",(void*)f_2695},
{"f_2732:lolevel_scm",(void*)f_2732},
{"f_2486:lolevel_scm",(void*)f_2486},
{"f_2490:lolevel_scm",(void*)f_2490},
{"f_2493:lolevel_scm",(void*)f_2493},
{"f_2639:lolevel_scm",(void*)f_2639},
{"f_2496:lolevel_scm",(void*)f_2496},
{"f_2499:lolevel_scm",(void*)f_2499},
{"f_2507:lolevel_scm",(void*)f_2507},
{"f_2517:lolevel_scm",(void*)f_2517},
{"f_2632:lolevel_scm",(void*)f_2632},
{"f_2526:lolevel_scm",(void*)f_2526},
{"f_2620:lolevel_scm",(void*)f_2620},
{"f_2624:lolevel_scm",(void*)f_2624},
{"f_2616:lolevel_scm",(void*)f_2616},
{"f_2529:lolevel_scm",(void*)f_2529},
{"f_2532:lolevel_scm",(void*)f_2532},
{"f_2589:lolevel_scm",(void*)f_2589},
{"f_2535:lolevel_scm",(void*)f_2535},
{"f_2538:lolevel_scm",(void*)f_2538},
{"f_2548:lolevel_scm",(void*)f_2548},
{"f_2550:lolevel_scm",(void*)f_2550},
{"f_2571:lolevel_scm",(void*)f_2571},
{"f_2541:lolevel_scm",(void*)f_2541},
{"f_2502:lolevel_scm",(void*)f_2502},
{"f_2368:lolevel_scm",(void*)f_2368},
{"f_2375:lolevel_scm",(void*)f_2375},
{"f_2378:lolevel_scm",(void*)f_2378},
{"f_2383:lolevel_scm",(void*)f_2383},
{"f_2393:lolevel_scm",(void*)f_2393},
{"f_2402:lolevel_scm",(void*)f_2402},
{"f_2406:lolevel_scm",(void*)f_2406},
{"f_2409:lolevel_scm",(void*)f_2409},
{"f_2412:lolevel_scm",(void*)f_2412},
{"f_2422:lolevel_scm",(void*)f_2422},
{"f_2424:lolevel_scm",(void*)f_2424},
{"f_2445:lolevel_scm",(void*)f_2445},
{"f_2415:lolevel_scm",(void*)f_2415},
{"f_2479:lolevel_scm",(void*)f_2479},
{"f_2365:lolevel_scm",(void*)f_2365},
{"f_2327:lolevel_scm",(void*)f_2327},
{"f_2331:lolevel_scm",(void*)f_2331},
{"f_2337:lolevel_scm",(void*)f_2337},
{"f_2342:lolevel_scm",(void*)f_2342},
{"f_2299:lolevel_scm",(void*)f_2299},
{"f_2303:lolevel_scm",(void*)f_2303},
{"f_2306:lolevel_scm",(void*)f_2306},
{"f_2286:lolevel_scm",(void*)f_2286},
{"f_2290:lolevel_scm",(void*)f_2290},
{"f_2277:lolevel_scm",(void*)f_2277},
{"f_2281:lolevel_scm",(void*)f_2281},
{"f_2228:lolevel_scm",(void*)f_2228},
{"f_2232:lolevel_scm",(void*)f_2232},
{"f_2243:lolevel_scm",(void*)f_2243},
{"f_2219:lolevel_scm",(void*)f_2219},
{"f_2197:lolevel_scm",(void*)f_2197},
{"f_2188:lolevel_scm",(void*)f_2188},
{"f_1092:lolevel_scm",(void*)f_1092},
{"f_2192:lolevel_scm",(void*)f_2192},
{"f_2168:lolevel_scm",(void*)f_2168},
{"f_2172:lolevel_scm",(void*)f_2172},
{"f_2129:lolevel_scm",(void*)f_2129},
{"f_2143:lolevel_scm",(void*)f_2143},
{"f_2160:lolevel_scm",(void*)f_2160},
{"f_2093:lolevel_scm",(void*)f_2093},
{"f_2110:lolevel_scm",(void*)f_2110},
{"f_2127:lolevel_scm",(void*)f_2127},
{"f_2058:lolevel_scm",(void*)f_2058},
{"f_2062:lolevel_scm",(void*)f_2062},
{"f_2083:lolevel_scm",(void*)f_2083},
{"f_2067:lolevel_scm",(void*)f_2067},
{"f_2019:lolevel_scm",(void*)f_2019},
{"f_2016:lolevel_scm",(void*)f_2016},
{"f_2013:lolevel_scm",(void*)f_2013},
{"f_2010:lolevel_scm",(void*)f_2010},
{"f_2007:lolevel_scm",(void*)f_2007},
{"f_2004:lolevel_scm",(void*)f_2004},
{"f_2001:lolevel_scm",(void*)f_2001},
{"f_1998:lolevel_scm",(void*)f_1998},
{"f_1992:lolevel_scm",(void*)f_1992},
{"f_1989:lolevel_scm",(void*)f_1989},
{"f_1982:lolevel_scm",(void*)f_1982},
{"f_1953:lolevel_scm",(void*)f_1953},
{"f_1961:lolevel_scm",(void*)f_1961},
{"f_1924:lolevel_scm",(void*)f_1924},
{"f_1932:lolevel_scm",(void*)f_1932},
{"f_1901:lolevel_scm",(void*)f_1901},
{"f_1913:lolevel_scm",(void*)f_1913},
{"f_1857:lolevel_scm",(void*)f_1857},
{"f_1861:lolevel_scm",(void*)f_1861},
{"f_1837:lolevel_scm",(void*)f_1837},
{"f_1841:lolevel_scm",(void*)f_1841},
{"f_1852:lolevel_scm",(void*)f_1852},
{"f_1844:lolevel_scm",(void*)f_1844},
{"f_1800:lolevel_scm",(void*)f_1800},
{"f_1821:lolevel_scm",(void*)f_1821},
{"f_1832:lolevel_scm",(void*)f_1832},
{"f_1779:lolevel_scm",(void*)f_1779},
{"f_1770:lolevel_scm",(void*)f_1770},
{"f_1774:lolevel_scm",(void*)f_1774},
{"f_1777:lolevel_scm",(void*)f_1777},
{"f_1764:lolevel_scm",(void*)f_1764},
{"f_1768:lolevel_scm",(void*)f_1768},
{"f_1753:lolevel_scm",(void*)f_1753},
{"f_1747:lolevel_scm",(void*)f_1747},
{"f_1751:lolevel_scm",(void*)f_1751},
{"f_1737:lolevel_scm",(void*)f_1737},
{"f_1741:lolevel_scm",(void*)f_1741},
{"f_1728:lolevel_scm",(void*)f_1728},
{"f_1732:lolevel_scm",(void*)f_1732},
{"f_1717:lolevel_scm",(void*)f_1717},
{"f_1709:lolevel_scm",(void*)f_1709},
{"f_1699:lolevel_scm",(void*)f_1699},
{"f_1692:lolevel_scm",(void*)f_1692},
{"f_1611:lolevel_scm",(void*)f_1611},
{"f_1617:lolevel_scm",(void*)f_1617},
{"f_1647:lolevel_scm",(void*)f_1647},
{"f_1662:lolevel_scm",(void*)f_1662},
{"f_1683:lolevel_scm",(void*)f_1683},
{"f_1650:lolevel_scm",(void*)f_1650},
{"f_1248:lolevel_scm",(void*)f_1248},
{"f_1548:lolevel_scm",(void*)f_1548},
{"f_1543:lolevel_scm",(void*)f_1543},
{"f_1538:lolevel_scm",(void*)f_1538},
{"f_1250:lolevel_scm",(void*)f_1250},
{"f_1308:lolevel_scm",(void*)f_1308},
{"f_1311:lolevel_scm",(void*)f_1311},
{"f_1314:lolevel_scm",(void*)f_1314},
{"f_1317:lolevel_scm",(void*)f_1317},
{"f_1322:lolevel_scm",(void*)f_1322},
{"f_1391:lolevel_scm",(void*)f_1391},
{"f_1456:lolevel_scm",(void*)f_1456},
{"f_1478:lolevel_scm",(void*)f_1478},
{"f_1495:lolevel_scm",(void*)f_1495},
{"f_1505:lolevel_scm",(void*)f_1505},
{"f_1485:lolevel_scm",(void*)f_1485},
{"f_1407:lolevel_scm",(void*)f_1407},
{"f_1423:lolevel_scm",(void*)f_1423},
{"f_1437:lolevel_scm",(void*)f_1437},
{"f_1433:lolevel_scm",(void*)f_1433},
{"f_1414:lolevel_scm",(void*)f_1414},
{"f_1281:lolevel_scm",(void*)f_1281},
{"f_1288:lolevel_scm",(void*)f_1288},
{"f_1265:lolevel_scm",(void*)f_1265},
{"f_1259:lolevel_scm",(void*)f_1259},
{"f_1253:lolevel_scm",(void*)f_1253},
{"f_1107:lolevel_scm",(void*)f_1107},
{"f_1046:lolevel_scm",(void*)f_1046},
{"f_1058:lolevel_scm",(void*)f_1058},
{"f_973:lolevel_scm",(void*)f_973},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
