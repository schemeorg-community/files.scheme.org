/* Generated from setup-api.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:54
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: setup-api.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature chicken-compile-shared -dynamic -emit-import-library setup-api -ignore-repository -output-file setup-api.c
   used units: library eval srfi_1 regex utils posix srfi_13 extras ports data_structures files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[362];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,27),40,115,101,116,117,112,45,97,112,105,35,115,104,101,108,108,112,97,116,104,32,115,116,114,54,49,41,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,25),40,115,101,116,117,112,45,97,112,105,35,99,114,111,115,115,45,99,104,105,99,107,101,110,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,45,97,112,105,35,117,115,101,114,45,105,110,115,116,97,108,108,45,115,101,116,117,112,41,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,115,117,100,111,45,105,110,115,116,97,108,108,32,46,32,97,114,103,115,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,7),40,97,50,49,49,48,41,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,41),40,115,101,116,117,112,45,97,112,105,35,121,101,115,45,111,114,45,110,111,63,32,115,116,114,49,48,55,32,46,32,116,109,112,49,48,54,49,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,7),40,97,50,49,52,53,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,7),40,97,50,49,51,53,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,41),40,115,101,116,117,112,45,97,112,105,35,112,97,116,99,104,32,119,104,105,99,104,49,53,50,32,114,120,49,53,51,32,115,117,98,115,116,49,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,48),40,115,101,116,117,112,45,97,112,105,35,114,101,103,105,115,116,101,114,45,112,114,111,103,114,97,109,32,110,97,109,101,49,56,57,32,46,32,116,109,112,49,56,56,49,57,48,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,32),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,112,114,111,103,114,97,109,32,110,97,109,101,49,57,56,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,22),40,114,101,103,32,110,97,109,101,50,48,51,32,114,110,97,109,101,50,48,52,41,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,102,105,120,109,97,107,101,116,97,114,103,101,116,32,102,105,108,101,50,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,50,51,56,32,103,50,52,50,50,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,50,52,56,32,103,50,53,56,50,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,50,56,55,32,103,50,57,55,51,48,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,45,97,112,105,35,101,120,101,99,117,116,101,32,101,120,112,108,105,115,116,50,51,53,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,37),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,102,111,114,109,45,101,114,114,111,114,32,115,51,56,56,32,112,51,56,57,41,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,108,105,110,101,45,101,114,114,111,114,32,115,51,57,57,32,112,52,48,48,32,110,52,48,49,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,97,50,57,51,57,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,14),40,97,50,57,51,51,32,101,120,110,53,57,50,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,7),40,97,50,57,56,48,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,7),40,97,50,57,57,53,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,20),40,97,50,57,56,57,32,46,32,97,114,103,115,53,56,55,54,48,51,41,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,7),40,97,50,57,55,52,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,15),40,97,50,57,50,55,32,107,53,56,54,53,57,49,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,14),40,97,51,48,54,57,32,100,101,112,53,51,57,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,12),40,97,51,49,49,51,32,100,53,51,50,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,13),40,109,97,116,99,104,63,32,115,51,55,52,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,105,110,101,115,51,55,54,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,23),40,102,95,50,56,55,51,32,115,53,48,49,32,105,110,100,101,110,116,53,48,50,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,54,52,49,32,103,54,52,53,54,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,11),40,103,54,51,50,32,102,54,51,52,41,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,54,50,53,32,103,54,50,57,54,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,14),40,97,50,55,54,54,32,100,101,112,52,54,51,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,15),40,97,50,54,57,55,32,108,105,110,101,52,50,56,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,49),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,109,97,107,101,47,112,114,111,99,47,104,101,108,112,101,114,32,115,112,101,99,52,57,51,32,97,114,103,118,52,57,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,47,112,114,111,99,32,103,54,54,54,54,54,55,54,55,53,32,46,32,114,118,97,114,54,54,56,54,55,54,41,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,31),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,97,116,105,111,110,45,112,114,101,102,105,120,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,13),40,118,101,114,98,32,100,105,114,55,54,50,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,15),40,102,95,53,56,56,55,32,100,105,114,55,55,49,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,15),40,102,95,53,56,57,53,32,100,105,114,55,55,51,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,7),40,97,51,52,54,55,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,51,52,55,54,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,119,114,105,116,101,45,105,110,102,111,32,105,100,55,56,51,32,102,105,108,101,115,55,56,52,32,105,110,102,111,55,56,53,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,19),40,98,111,100,121,56,53,53,32,112,114,101,102,105,120,56,54,53,41,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,112,114,101,102,105,120,56,53,56,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,114,114,56,53,55,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,47),40,115,101,116,117,112,45,97,112,105,35,99,111,112,121,45,102,105,108,101,32,102,114,111,109,56,52,55,32,116,111,56,52,56,32,46,32,116,109,112,56,52,54,56,52,57,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,35),40,115,101,116,117,112,45,97,112,105,35,109,111,118,101,45,102,105,108,101,32,102,114,111,109,56,56,56,32,116,111,56,56,57,41,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,31),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,102,105,108,101,42,32,100,105,114,57,48,48,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,45,100,101,115,116,45,112,97,116,104,110,97,109,101,32,112,97,116,104,57,48,56,32,102,105,108,101,57,48,57,41,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,57,49,52,32,103,57,50,52,57,50,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,35),40,115,101,116,117,112,45,97,112,105,35,99,104,101,99,107,45,102,105,108,101,108,105,115,116,32,102,108,105,115,116,57,49,49,41,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,7),40,97,52,48,56,56,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,52,48,57,49,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,61),40,115,101,116,117,112,45,97,112,105,35,115,116,97,110,100,97,114,100,45,101,120,116,101,110,115,105,111,110,32,110,97,109,101,57,55,57,32,118,101,114,115,105,111,110,57,56,48,32,46,32,116,109,112,57,55,56,57,56,49,41,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,13),40,103,49,48,54,54,32,102,49,48,54,56,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,48,53,48,32,103,49,48,54,48,49,48,54,52,41,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,60),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,101,120,116,101,110,115,105,111,110,32,105,100,49,48,51,51,32,102,105,108,101,115,49,48,51,52,32,46,32,116,109,112,49,48,51,50,49,48,51,53,41,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,13),40,101,120,105,102,121,32,102,49,49,51,48,41,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,13),40,103,49,49,55,57,32,102,49,49,56,49,41,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,49,54,51,32,103,49,49,55,51,49,49,55,55,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,13),40,103,49,49,53,52,32,102,49,49,53,54,41,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,49,51,56,32,103,49,49,52,56,49,49,53,50,41,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,112,114,111,103,114,97,109,32,105,100,49,49,49,57,32,102,105,108,101,115,49,49,50,48,32,46,32,116,109,112,49,49,49,56,49,49,50,49,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,13),40,103,49,50,51,56,32,102,49,50,52,48,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,50,50,50,32,103,49,50,51,50,49,50,51,54,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,57),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,115,99,114,105,112,116,32,105,100,49,50,48,53,32,102,105,108,101,115,49,50,48,54,32,46,32,116,109,112,49,50,48,52,49,50,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,114,101,112,111,45,112,97,116,104,32,116,109,112,49,50,55,49,49,50,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,37),40,115,101,116,117,112,45,97,112,105,35,101,110,115,117,114,101,45,100,105,114,101,99,116,111,114,121,32,112,97,116,104,49,50,56,57,41,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,7),40,97,52,57,50,54,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,7),40,97,52,57,51,50,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,7),40,97,52,57,51,53,41,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,7),40,97,52,57,52,49,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,7),40,97,52,57,52,52,41,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,7),40,97,52,57,52,55,41,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,97,112,105,35,116,114,121,45,99,111,109,112,105,108,101,32,99,111,100,101,49,51,49,51,32,46,32,116,109,112,49,51,49,50,49,51,49,52,41,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,114,101,113,117,105,114,101,100,45,99,104,105,99,107,101,110,45,118,101,114,115,105,111,110,32,118,49,51,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,55),40,115,101,116,117,112,45,97,112,105,35,117,112,103,114,97,100,101,45,109,101,115,115,97,103,101,32,101,120,116,49,51,54,56,32,109,115,103,49,51,54,57,32,116,109,112,49,51,54,55,49,51,55,48,41,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,97,114,103,115,49,51,57,55,41,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,49),40,115,101,116,117,112,45,97,112,105,35,114,101,113,117,105,114,101,100,45,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,32,46,32,97,114,103,115,49,51,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,108,105,98,114,97,114,121,32,110,97,109,101,49,52,51,50,32,112,114,111,99,49,52,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,32),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,104,101,97,100,101,114,32,110,97,109,101,49,52,53,52,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,52,55,48,32,103,49,52,56,48,49,52,56,52,41,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,21),40,118,101,114,115,105,111,110,45,62,108,105,115,116,32,118,49,52,54,55,41,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,112,49,49,52,57,56,32,112,50,49,52,57,57,41,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,36),40,115,101,116,117,112,45,97,112,105,35,118,101,114,115,105,111,110,62,61,63,32,118,49,49,52,54,52,32,118,50,49,52,54,53,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,26),40,115,101,116,117,112,45,97,112,105,35,101,120,116,101,110,115,105,111,110,45,110,97,109,101,41,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,43),40,115,101,116,117,112,45,97,112,105,35,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,32,46,32,116,109,112,49,53,54,53,49,53,54,54,41,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,29),40,115,101,116,117,112,45,97,112,105,35,114,101,97,100,45,105,110,102,111,32,101,103,103,49,53,55,54,41,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,38),40,115,101,116,117,112,45,97,112,105,35,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,13),40,103,49,54,52,53,32,102,49,54,52,55,41,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,54,51,56,32,103,49,54,52,50,49,54,52,52,41,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,14),40,119,97,108,107,32,100,105,114,49,54,51,52,41,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,50),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,100,105,114,101,99,116,111,114,121,32,100,105,114,49,54,49,51,32,46,32,116,109,112,49,54,49,50,49,54,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,54,54,56,32,103,49,54,55,50,49,54,55,52,41,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,36),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,101,120,116,101,110,115,105,111,110,32,101,103,103,49,54,54,49,41,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,27),40,115,101,116,117,112,45,97,112,105,35,36,115,121,115,116,101,109,32,115,116,114,49,54,56,49,41,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,21),40,101,110,115,117,114,101,45,115,116,114,105,110,103,32,120,49,53,53,49,41,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,13),40,97,53,56,49,54,32,120,49,53,51,52,41,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,7),40,97,53,57,53,49,41,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1809)
static void C_ccall f_1809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1835)
static void C_ccall f_1835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5975)
static void C_ccall f_5975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5952)
static void C_ccall f_5952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5950)
static void C_ccall f_5950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5946)
static void C_ccall f_5946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5942)
static void C_ccall f_5942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5938)
static void C_ccall f_5938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5934)
static void C_ccall f_5934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5930)
static void C_ccall f_5930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5926)
static void C_ccall f_5926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5817)
static void C_ccall f_5817(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5833)
static void C_fcall f_5833(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5870)
static void C_ccall f_5870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5867)
static void C_ccall f_5867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5840)
static void C_fcall f_5840(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5468)
static void C_ccall f_5468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5815)
static void C_ccall f_5815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5776)
static void C_fcall f_5776(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5793)
static void C_ccall f_5793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5780)
static void C_ccall f_5780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5812)
static void C_ccall f_5812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5722)
static void C_ccall f_5722(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5774)
static void C_ccall f_5774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5749)
static void C_fcall f_5749(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5729)
static void C_ccall f_5729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5740)
static void C_ccall f_5740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5736)
static void C_ccall f_5736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5591)
static void C_ccall f_5591(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5591)
static void C_ccall f_5591r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5595)
static void C_ccall f_5595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5701)
static void C_ccall f_5701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5635)
static void C_fcall f_5635(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5639)
static void C_ccall f_5639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5647)
static void C_fcall f_5647(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5655)
static void C_fcall f_5655(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5674)
static void C_ccall f_5674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5642)
static void C_ccall f_5642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5620)
static void C_ccall f_5620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5630)
static void C_ccall f_5630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5580)
static void C_ccall f_5580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5586)
static void C_ccall f_5586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5545)
static void C_fcall f_5545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5550)
static void C_fcall f_5550(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5577)
static void C_ccall f_5577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5563)
static void C_ccall f_5563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5569)
static void C_ccall f_5569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5524)
static void C_ccall f_5524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5536)
static void C_ccall f_5536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5532)
static void C_ccall f_5532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5503)
static void C_ccall f_5503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5478)
static void C_ccall f_5478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5269)
static void C_ccall f_5269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5334)
static void C_ccall f_5334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5340)
static void C_fcall f_5340(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5272)
static void C_fcall f_5272(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5280)
static void C_ccall f_5280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5282)
static void C_fcall f_5282(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5313)
static void C_ccall f_5313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5292)
static void C_fcall f_5292(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5196)
static void C_ccall f_5196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5199)
static void C_ccall f_5199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5208)
static void C_ccall f_5208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5211)
static void C_ccall f_5211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5217)
static void C_ccall f_5217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5220)
static void C_ccall f_5220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5223)
static void C_ccall f_5223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5232)
static void C_ccall f_5232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5235)
static void C_ccall f_5235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5238)
static void C_ccall f_5238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5241)
static void C_ccall f_5241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5245)
static void C_ccall f_5245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5067)
static void C_ccall f_5067(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5067)
static void C_ccall f_5067r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5073)
static void C_fcall f_5073(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5086)
static void C_fcall f_5086(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5104)
static void C_fcall f_5104(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5155)
static void C_ccall f_5155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5159)
static void C_ccall f_5159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_fcall f_5119(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5129)
static void C_ccall f_5129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5135)
static void C_ccall f_5135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4986)
static void C_fcall f_4986(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4990)
static void C_ccall f_4990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4997)
static void C_ccall f_4997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5006)
static void C_ccall f_5006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5015)
static void C_ccall f_5015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5043)
static void C_ccall f_5043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5033)
static void C_ccall f_5033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5036)
static void C_ccall f_5036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4984)
static void C_ccall f_4984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4968)
static void C_ccall f_4968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4977)
static void C_ccall f_4977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4980)
static void C_ccall f_4980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4837)
static void C_ccall f_4837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4945)
static void C_ccall f_4945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4843)
static void C_ccall f_4843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4933)
static void C_ccall f_4933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4855)
static void C_ccall f_4855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4927)
static void C_ccall f_4927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4880)
static void C_ccall f_4880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4890)
static void C_ccall f_4890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_fcall f_4777(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4790)
static void C_ccall f_4790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4802)
static void C_ccall f_4802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4828)
static void C_ccall f_4828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4796)
static void C_ccall f_4796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4705)
static void C_fcall f_4705(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4709)
static void C_ccall f_4709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4737)
static void C_ccall f_4737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_ccall f_4740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4746)
static void C_ccall f_4746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4545)
static void C_ccall f_4545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4551)
static void C_ccall f_4551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4554)
static void C_ccall f_4554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4594)
static void C_fcall f_4594(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4621)
static void C_fcall f_4621(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4342)
static void C_ccall f_4342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4348)
static void C_ccall f_4348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4510)
static void C_ccall f_4510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4351)
static void C_ccall f_4351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_fcall f_4443(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4470)
static void C_fcall f_4470(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4484)
static void C_ccall f_4484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4488)
static void C_ccall f_4488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4362)
static void C_fcall f_4362(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4389)
static void C_fcall f_4389(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4396)
static void C_ccall f_4396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4425)
static void C_ccall f_4425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4402)
static void C_ccall f_4402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4328)
static void C_fcall f_4328(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3863)
static void C_ccall f_3863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4108)
static void C_ccall f_4108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4111)
static void C_ccall f_4111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_fcall f_4122(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4149)
static void C_fcall f_4149(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4249)
static void C_fcall f_4249(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4268)
static void C_ccall f_4268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4162)
static void C_ccall f_4162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_fcall f_4180(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3905)
static void C_ccall f_3905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3905)
static void C_ccall f_3905r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3918)
static void C_ccall f_3918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3930)
static void C_ccall f_3930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3988)
static void C_ccall f_3988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3953)
static void C_ccall f_3953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3768)
static void C_fcall f_3768(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3774)
static void C_fcall f_3774(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3814)
static void C_ccall f_3814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3817)
static void C_fcall f_3817(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3846)
static void C_ccall f_3846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3784)
static void C_fcall f_3784(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3743)
static void C_fcall f_3743(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3763)
static void C_ccall f_3763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3666)
static void C_ccall f_3666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3695)
static void C_ccall f_3695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3604)
static void C_fcall f_3604(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3595)
static void C_fcall f_3595(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3522)
static void C_fcall f_3522(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3529)
static void C_ccall f_3529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3660)
static void C_ccall f_3660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3535)
static void C_ccall f_3535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3554)
static void C_ccall f_3554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3391)
static void C_fcall f_3391(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3518)
static void C_ccall f_3518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3497)
static void C_ccall f_3497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3500)
static void C_ccall f_3500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3503)
static void C_ccall f_3503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3398)
static void C_ccall f_3398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3407)
static void C_ccall f_3407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5895)
static void C_ccall f_5895(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5922)
static void C_ccall f_5922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5887)
static void C_ccall f_5887(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5891)
static void C_ccall f_5891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3367)
static void C_fcall f_3367(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3305)
static void C_ccall f_3305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2852)
static void C_fcall f_2852(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2856)
static void C_fcall f_2856(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2720)
static void C_ccall f_2720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2859)
static void C_ccall f_2859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2844)
static void C_ccall f_2844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2867)
static void C_ccall f_2867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_fcall f_3238(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3246)
static void C_fcall f_3246(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3173)
static void C_ccall f_3173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3182)
static void C_fcall f_3182(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3194)
static void C_ccall f_3194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3197)
static void C_ccall f_3197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3203)
static void C_ccall f_3203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2579)
static void C_fcall f_2579(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2592)
static void C_fcall f_2592(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3134)
static void C_ccall f_3134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3140)
static void C_ccall f_3140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3097)
static void C_ccall f_3097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3018)
static void C_ccall f_3018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_fcall f_2646(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2663)
static void C_ccall f_2663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2624)
static void C_fcall f_2624(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2417)
static void C_ccall f_2417(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2533)
static void C_fcall f_2533(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2445)
static void C_fcall f_2445(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_fcall f_2348(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2369)
static void C_ccall f_2369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_fcall f_2487(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2391)
static void C_fcall f_2391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_fcall f_2398(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2295)
static void C_fcall f_2295(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2207)
static void C_ccall f_2207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2152)
static void C_fcall f_2152(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2031)
static void C_fcall f_2031(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2035)
static void C_ccall f_2035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2041)
static void C_ccall f_2041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2103)
static void C_ccall f_2103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2053)
static void C_fcall f_2053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1968)
static void C_fcall f_1968(C_word t0) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_5833)
static void C_fcall trf_5833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5833(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5833(t0,t1);}

C_noret_decl(trf_5840)
static void C_fcall trf_5840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5840(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5840(t0,t1);}

C_noret_decl(trf_5776)
static void C_fcall trf_5776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5776(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5776(t0,t1);}

C_noret_decl(trf_5749)
static void C_fcall trf_5749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5749(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5749(t0,t1,t2);}

C_noret_decl(trf_5635)
static void C_fcall trf_5635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5635(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5635(t0,t1,t2);}

C_noret_decl(trf_5647)
static void C_fcall trf_5647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5647(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5647(t0,t1,t2);}

C_noret_decl(trf_5655)
static void C_fcall trf_5655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5655(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5655(t0,t1,t2);}

C_noret_decl(trf_5545)
static void C_fcall trf_5545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5545(t0,t1);}

C_noret_decl(trf_5550)
static void C_fcall trf_5550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5550(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5550(t0,t1);}

C_noret_decl(trf_5340)
static void C_fcall trf_5340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5340(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5340(t0,t1,t2,t3);}

C_noret_decl(trf_5272)
static void C_fcall trf_5272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5272(t0,t1);}

C_noret_decl(trf_5282)
static void C_fcall trf_5282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5282(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5282(t0,t1,t2);}

C_noret_decl(trf_5292)
static void C_fcall trf_5292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5292(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5292(t0,t1);}

C_noret_decl(trf_5073)
static void C_fcall trf_5073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5073(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5073(t0,t1,t2);}

C_noret_decl(trf_5086)
static void C_fcall trf_5086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5086(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5086(t0,t1);}

C_noret_decl(trf_5104)
static void C_fcall trf_5104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5104(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5104(t0,t1);}

C_noret_decl(trf_5119)
static void C_fcall trf_5119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5119(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5119(t0,t1);}

C_noret_decl(trf_4986)
static void C_fcall trf_4986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4986(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4986(t0,t1,t2,t3);}

C_noret_decl(trf_4777)
static void C_fcall trf_4777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4777(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4777(t0,t1);}

C_noret_decl(trf_4705)
static void C_fcall trf_4705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4705(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4705(t0,t1);}

C_noret_decl(trf_4594)
static void C_fcall trf_4594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4594(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4594(t0,t1,t2);}

C_noret_decl(trf_4621)
static void C_fcall trf_4621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4621(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4621(t0,t1,t2);}

C_noret_decl(trf_4443)
static void C_fcall trf_4443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4443(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4443(t0,t1,t2);}

C_noret_decl(trf_4470)
static void C_fcall trf_4470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4470(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4470(t0,t1,t2);}

C_noret_decl(trf_4362)
static void C_fcall trf_4362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4362(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4362(t0,t1,t2);}

C_noret_decl(trf_4389)
static void C_fcall trf_4389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4389(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4389(t0,t1,t2);}

C_noret_decl(trf_4328)
static void C_fcall trf_4328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4328(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4328(t0,t1);}

C_noret_decl(trf_4122)
static void C_fcall trf_4122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4122(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4122(t0,t1,t2);}

C_noret_decl(trf_4149)
static void C_fcall trf_4149(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4149(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4149(t0,t1,t2);}

C_noret_decl(trf_4249)
static void C_fcall trf_4249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4249(t0,t1);}

C_noret_decl(trf_4180)
static void C_fcall trf_4180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4180(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4180(t0,t1);}

C_noret_decl(trf_3768)
static void C_fcall trf_3768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3768(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3768(t0,t1);}

C_noret_decl(trf_3774)
static void C_fcall trf_3774(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3774(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3774(t0,t1,t2);}

C_noret_decl(trf_3817)
static void C_fcall trf_3817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3817(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3817(t0,t1);}

C_noret_decl(trf_3784)
static void C_fcall trf_3784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3784(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3784(t0,t1);}

C_noret_decl(trf_3743)
static void C_fcall trf_3743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3743(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3743(t0,t1,t2);}

C_noret_decl(trf_3604)
static void C_fcall trf_3604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3604(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3604(t0,t1);}

C_noret_decl(trf_3595)
static void C_fcall trf_3595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3595(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3595(t0,t1);}

C_noret_decl(trf_3522)
static void C_fcall trf_3522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3522(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3522(t0,t1,t2);}

C_noret_decl(trf_3391)
static void C_fcall trf_3391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3391(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3391(t0,t1,t2,t3);}

C_noret_decl(trf_3367)
static void C_fcall trf_3367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3367(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3367(t0,t1);}

C_noret_decl(trf_2852)
static void C_fcall trf_2852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2852(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2852(t0,t1,t2);}

C_noret_decl(trf_2856)
static void C_fcall trf_2856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2856(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2856(t0,t1);}

C_noret_decl(trf_3238)
static void C_fcall trf_3238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3238(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3238(t0,t1,t2);}

C_noret_decl(trf_3246)
static void C_fcall trf_3246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3246(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3246(t0,t1,t2);}

C_noret_decl(trf_3182)
static void C_fcall trf_3182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3182(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3182(t0,t1,t2);}

C_noret_decl(trf_2579)
static void C_fcall trf_2579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2579(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2579(t0,t1,t2);}

C_noret_decl(trf_2592)
static void C_fcall trf_2592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2592(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2592(t0,t1);}

C_noret_decl(trf_2646)
static void C_fcall trf_2646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2646(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2646(t0,t1,t2,t3);}

C_noret_decl(trf_2624)
static void C_fcall trf_2624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2624(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2624(t0,t1,t2);}

C_noret_decl(trf_2533)
static void C_fcall trf_2533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2533(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2533(t0,t1,t2);}

C_noret_decl(trf_2445)
static void C_fcall trf_2445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2445(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2445(t0,t1,t2);}

C_noret_decl(trf_2348)
static void C_fcall trf_2348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2348(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2348(t0,t1);}

C_noret_decl(trf_2487)
static void C_fcall trf_2487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2487(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2487(t0,t1,t2);}

C_noret_decl(trf_2391)
static void C_fcall trf_2391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2391(t0,t1);}

C_noret_decl(trf_2398)
static void C_fcall trf_2398(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2398(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2398(t0,t1);}

C_noret_decl(trf_2295)
static void C_fcall trf_2295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2295(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2295(t0,t1,t2);}

C_noret_decl(trf_2152)
static void C_fcall trf_2152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2152(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2152(t0,t1);}

C_noret_decl(trf_2031)
static void C_fcall trf_2031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2031(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2031(t0,t1);}

C_noret_decl(trf_2053)
static void C_fcall trf_2053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2053(t0,t1);}

C_noret_decl(trf_1968)
static void C_fcall trf_1968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1968(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_1968(t0);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1542)){
C_save(t1);
C_rereclaim2(1542*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,362);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[11]=C_h_intern(&lf[11],24,"setup-api#host-extension");
lf[13]=C_h_intern(&lf[13],24,"setup-api#chicken-prefix");
lf[14]=C_h_intern(&lf[14],19,"setup-api#shellpath");
lf[15]=C_h_intern(&lf[15],2,"qs");
lf[16]=C_h_intern(&lf[16],18,"normalize-pathname");
lf[17]=C_h_intern(&lf[17],23,"setup-api#cross-chicken");
lf[19]=C_h_intern(&lf[19],30,"setup-api#setup-root-directory");
lf[20]=C_h_intern(&lf[20],28,"setup-api#setup-verbose-mode");
lf[21]=C_h_intern(&lf[21],28,"setup-api#setup-install-mode");
lf[22]=C_h_intern(&lf[22],25,"setup-api#deployment-mode");
lf[23]=C_h_intern(&lf[23],22,"setup-api#program-path");
lf[24]=C_h_intern(&lf[24],28,"setup-api#keep-intermediates");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\004copy");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\011del /Q /S");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\004move");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\005chmod");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\006ranlib");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\006rm -fr");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\002mv");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\005chmod");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\006ranlib");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\005mkdir");
lf[43]=C_h_intern(&lf[43],22,"setup-api#sudo-install");
lf[44]=C_h_intern(&lf[44],5,"print");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\0001Warning: cannot install as superuser with Windows");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo cp -r");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\013sudo rm -fr");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\007sudo mv");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo chmod");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\013sudo ranlib");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo mkdir");
lf[52]=C_h_intern(&lf[52],21,"setup-api#abort-setup");
lf[53]=C_h_intern(&lf[53],20,"setup-api#yes-or-no\077");
lf[54]=C_h_intern(&lf[54],19,"\003sysstandard-output");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\003yes");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[58]=C_h_intern(&lf[58],19,"\003syswrite-char/port");
lf[59]=C_h_intern(&lf[59],7,"display");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000$Please enter \042yes\042, \042no\042 or \042abort\042.");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[63]=C_h_intern(&lf[63],9,"read-line");
lf[64]=C_h_intern(&lf[64],12,"flush-output");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\002] ");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\020 (yes/no/abort) ");
lf[67]=C_h_intern(&lf[67],15,"\003sysget-keyword");
lf[68]=C_h_intern(&lf[68],6,"\000abort");
lf[69]=C_h_intern(&lf[69],8,"\000default");
lf[70]=C_h_intern(&lf[70],15,"setup-api#patch");
lf[71]=C_h_intern(&lf[71],10,"write-line");
lf[72]=C_h_intern(&lf[72],17,"string-substitute");
lf[73]=C_h_intern(&lf[73],20,"with-input-from-file");
lf[74]=C_h_intern(&lf[74],19,"with-output-to-file");
lf[76]=C_h_intern(&lf[76],17,"get-output-string");
lf[77]=C_h_intern(&lf[77],18,"open-output-string");
lf[78]=C_h_intern(&lf[78],21,"create-temporary-file");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\011patching ");
lf[81]=C_h_intern(&lf[81],21,"setup-api#run-verbose");
lf[82]=C_h_intern(&lf[82],26,"setup-api#register-program");
lf[83]=C_h_intern(&lf[83],10,"alist-cons");
lf[84]=C_h_intern(&lf[84],8,"->string");
lf[85]=C_h_intern(&lf[85],13,"make-pathname");
lf[86]=C_h_intern(&lf[86],9,"\003syserror");
lf[87]=C_h_intern(&lf[87],22,"setup-api#find-program");
lf[89]=C_h_intern(&lf[89],26,"pathname-replace-extension");
lf[90]=C_h_intern(&lf[90],26,"\003sysload-dynamic-extension");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[93]=C_h_intern(&lf[93],18,"pathname-extension");
lf[94]=C_h_intern(&lf[94],17,"setup-api#execute");
lf[95]=C_h_intern(&lf[95],16,"\003sysflush-output");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[97]=C_h_intern(&lf[97],18,"string-intersperse");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[105]=C_h_intern(&lf[105],5,"cons*");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\023compiling-extension");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\011-deployed");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\013-setup-mode");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[112]=C_h_intern(&lf[112],8,"feature\077");
lf[113]=C_h_intern(&lf[113],14,"\000cross-chicken");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[116]=C_h_intern(&lf[116],5,"error");
lf[117]=C_h_intern(&lf[117],5,"write");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\013 for line: ");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[123]=C_h_intern(&lf[123],6,"signal");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\025make: Failed to make ");
lf[126]=C_h_intern(&lf[126],22,"with-exception-handler");
lf[127]=C_h_intern(&lf[127],30,"call-with-current-continuation");
lf[128]=C_h_intern(&lf[128],13,"string-append");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\011 because ");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\010 changed");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\007 date: ");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\027 just because (reason: ");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\011 because ");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\017 does not exist");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\007making ");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\006make: ");
lf[137]=C_h_intern(&lf[137],22,"file-modification-time");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\015 was not made");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\013dependancy ");
lf[140]=C_h_intern(&lf[140],12,"file-exists\077");
lf[141]=C_h_intern(&lf[141],3,"any");
lf[142]=C_h_intern(&lf[142],12,"\003sysfor-each");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\027don\047t know how to make ");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\011checking ");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\006make: ");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\013make: made ");
lf[148]=C_h_intern(&lf[148],7,"reverse");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[151]=C_h_intern(&lf[151],4,"caar");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[153]=C_h_intern(&lf[153],27,"condition-property-accessor");
lf[154]=C_h_intern(&lf[154],3,"exn");
lf[155]=C_h_intern(&lf[155],7,"message");
lf[156]=C_h_intern(&lf[156],19,"condition-predicate");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\047argument is not a string or string list");
lf[158]=C_h_intern(&lf[158],5,"every");
lf[159]=C_h_intern(&lf[159],7,"string\077");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000#command part of line is not a thunk");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\037dependency item is not a string");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000!second part of line is not a list");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\0004line does not start with a string or list of strings");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000$list is not a list with 2 or 3 parts");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\036specification is an empty list");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\033specification is not a list");
lf[167]=C_h_intern(&lf[167],12,"vector->list");
lf[168]=C_h_intern(&lf[168],19,"setup-api#make/proc");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\0000no matching clause in call to \047case-lambda\047 form");
lf[170]=C_h_intern(&lf[170],28,"setup-api#destination-prefix");
lf[171]=C_h_intern(&lf[171],29,"setup-api#installation-prefix");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\010  mkdir ");
lf[173]=C_h_intern(&lf[173],16,"create-directory");
lf[174]=C_h_intern(&lf[174],2,"-p");
lf[175]=C_h_intern(&lf[175],34,"setup-api#create-directory/parents");
lf[177]=C_h_intern(&lf[177],5,"files");
lf[178]=C_h_intern(&lf[178],3,"a+r");
lf[179]=C_h_intern(&lf[179],2,"pp");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[181]=C_h_intern(&lf[181],15,"repository-path");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\015writing info ");
lf[186]=C_h_intern(&lf[186],10,"\003sysappend");
lf[187]=C_h_intern(&lf[187],19,"setup-api#copy-file");
lf[189]=C_h_intern(&lf[189],18,"absolute-pathname\077");
lf[190]=C_h_intern(&lf[190],14,"string-prefix\077");
lf[191]=C_h_intern(&lf[191],19,"setup-api#move-file");
lf[192]=C_h_intern(&lf[192],22,"setup-api#remove-file*");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid file-specification");
lf[196]=C_h_intern(&lf[196],28,"setup-api#standard-extension");
lf[197]=C_h_intern(&lf[197],7,"version");
lf[198]=C_h_intern(&lf[198],27,"setup-api#install-extension");
lf[199]=C_h_intern(&lf[199],6,"static");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[204]=C_h_intern(&lf[204],3,"-d0");
lf[205]=C_h_intern(&lf[205],3,"-O3");
lf[206]=C_h_intern(&lf[206],2,"-s");
lf[207]=C_h_intern(&lf[207],3,"csc");
lf[208]=C_h_intern(&lf[208],5,"-unit");
lf[209]=C_h_intern(&lf[209],2,"-j");
lf[210]=C_h_intern(&lf[210],3,"-d1");
lf[211]=C_h_intern(&lf[211],2,"-c");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\012import.scm");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\003scm");
lf[214]=C_h_intern(&lf[214],5,"\000info");
lf[215]=C_h_intern(&lf[215],7,"\000static");
lf[216]=C_h_intern(&lf[216],6,"macosx");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[218]=C_h_intern(&lf[218],16,"software-version");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[220]=C_h_intern(&lf[220],25,"setup-api#install-program");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[227]=C_h_intern(&lf[227],24,"setup-api#install-script");
lf[228]=C_h_intern(&lf[228],4,"a+rx");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\014lib/chicken/");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000Acannot create directory: a file with the same name already exists");
lf[233]=C_h_intern(&lf[233],10,"directory\077");
lf[234]=C_h_intern(&lf[234],3,"a+x");
lf[235]=C_h_intern(&lf[235],18,"pathname-directory");
lf[236]=C_h_intern(&lf[236],21,"setup-api#try-compile");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\012succeeded.");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\007failed.");
lf[239]=C_h_intern(&lf[239],6,"system");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\0042>&1");
lf[245]=C_h_intern(&lf[245],4,"conc");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\014 >/dev/null ");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[258]=C_h_intern(&lf[258],13,"\000compile-only");
lf[259]=C_h_intern(&lf[259],5,"\000verb");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[261]=C_h_intern(&lf[261],8,"\000ldflags");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[263]=C_h_intern(&lf[263],7,"\000cflags");
lf[264]=C_h_intern(&lf[264],3,"\000cc");
lf[265]=C_h_intern(&lf[265],4,"\000c++");
lf[266]=C_h_intern(&lf[266],34,"setup-api#required-chicken-version");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\026 or higher is required");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\020CHICKEN version ");
lf[269]=C_h_intern(&lf[269],20,"setup-api#version>=\077");
lf[270]=C_h_intern(&lf[270],15,"chicken-version");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000.and repeat the current installation operation.");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\022  chicken-install ");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\015 - please run");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\002\047 ");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\030the required extension `");
lf[279]=C_h_intern(&lf[279],36,"setup-api#required-extension-version");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\047, which is what this extension requires");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\016is older than ");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000%has no associated version information");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\020is not installed");
lf[284]=C_h_intern(&lf[284],21,"extension-information");
lf[285]=C_h_intern(&lf[285],30,"required-extension-information");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\023bad argument format");
lf[287]=C_h_intern(&lf[287],22,"setup-api#test-compile");
lf[288]=C_h_intern(&lf[288],22,"setup-api#find-library");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\017(); return 0; }");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\015int main() { ");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\003();");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\005char ");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\012extern \042C\042");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\022#ifdef __cplusplus");
lf[297]=C_h_intern(&lf[297],21,"setup-api#find-header");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\033>\012int main() { return 0; }\012");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\012#include <");
lf[300]=C_h_intern(&lf[300],19,"string-split-fields");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\006[-\134._]");
lf[302]=C_h_intern(&lf[302],6,"\000infix");
lf[303]=C_h_intern(&lf[303],8,"string>\077");
lf[304]=C_h_intern(&lf[304],36,"setup-api#extension-name-and-version");
lf[305]=C_h_intern(&lf[305],24,"setup-api#extension-name");
lf[306]=C_h_intern(&lf[306],27,"setup-api#extension-version");
lf[307]=C_h_intern(&lf[307],12,"string-null\077");
lf[308]=C_h_intern(&lf[308],19,"setup-api#read-info");
lf[309]=C_h_intern(&lf[309],4,"read");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\013.setup-info");
lf[311]=C_h_intern(&lf[311],36,"setup-api#create-temporary-directory");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\003tmp");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-install-");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\004/tmp");
lf[315]=C_h_intern(&lf[315],24,"get-environment-variable");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\003TMP");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\004TEMP");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\006TMPDIR");
lf[319]=C_h_intern(&lf[319],26,"setup-api#remove-directory");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\014sudo rm -fr ");
lf[321]=C_h_intern(&lf[321],16,"delete-directory");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[324]=C_h_intern(&lf[324],11,"delete-file");
lf[325]=C_h_intern(&lf[325],9,"directory");
lf[326]=C_h_intern(&lf[326],16,"remove-directory");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000#cannot remove - directory not found");
lf[328]=C_h_intern(&lf[328],26,"setup-api#remove-extension");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[330]=C_h_intern(&lf[330],5,"reset");
lf[331]=C_h_intern(&lf[331],7,"fprintf");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\006~%~\077~%");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\0009shell command failed with nonzero exit status ~a:~%~%  ~a");
lf[334]=C_h_intern(&lf[334],18,"current-error-port");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[337]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[339]=C_h_intern(&lf[339],7,"warning");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid extension-name-and-version");
lf[341]=C_h_intern(&lf[341],14,"make-parameter");
lf[342]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\026CHICKEN_INSTALL_PREFIX");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\013chicken-bug");
lf[345]=C_h_intern(&lf[345],17,"\003syspeek-c-string");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\016chicken-status");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\021chicken-uninstall");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\017chicken-install");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\003csi");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[352]=C_h_intern(&lf[352],4,"exit");
lf[353]=C_h_intern(&lf[353],17,"current-directory");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[357]=C_h_intern(&lf[357],17,"register-feature!");
lf[358]=C_h_intern(&lf[358],13,"chicken-setup");
lf[359]=C_h_intern(&lf[359],7,"windows");
lf[360]=C_h_intern(&lf[360],14,"build-platform");
lf[361]=C_h_intern(&lf[361],13,"software-type");
C_register_lf2(lf,362,create_ptable());
t2=C_mutate(&lf[0] /* (set! c196 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1800,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1798 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1803,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1801 in k1798 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1806,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1804 in k1801 in k1798 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1812,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1815,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1818,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1821,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1824,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1827,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1830,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1835,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[345]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}

/* k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1835,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! setup-api#*cc* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1839,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[345]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}

/* k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1839,2,t0,t1);}
t2=C_mutate(&lf[3] /* (set! setup-api#*cxx* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[345]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}

/* k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=C_mutate(&lf[4] /* (set! setup-api#*target-cflags* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1847,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[345]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}

/* k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1847,2,t0,t1);}
t2=C_mutate(&lf[5] /* (set! setup-api#*target-libs* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1851,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[345]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}

/* k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1851,2,t0,t1);}
t2=C_mutate(&lf[6] /* (set! setup-api#*target-lib-home* ...) */,t1);
t3=lf[7] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
t4=C_mutate(&lf[8] /* (set! setup-api#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t5=lf[9] /* setup-api#*registered-programs* */ =C_SCHEME_END_OF_LIST;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5975,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 86   software-type");
((C_proc2)C_retrieve_symbol_proc(lf[361]))(2,*((C_word*)lf[361]+1),t7);}

/* k5973 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_eqp(t1,lf[359]);
if(C_truep(t2)){
C_trace("setup-api.scm: 87   build-platform");
((C_proc2)C_retrieve_symbol_proc(lf[360]))(2,*((C_word*)lf[360]+1),((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[2];
f_1858(2,t3,C_SCHEME_FALSE);}}

/* k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=C_mutate(&lf[10] /* (set! setup-api#*windows* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 89   register-feature!");
((C_proc3)C_retrieve_symbol_proc(lf[357]))(3,*((C_word*)lf[357]+1),t3,lf[358]);}

/* k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1865,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 91   make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[341]))(3,*((C_word*)lf[341]+1),t2,C_SCHEME_FALSE);}

/* k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1865,2,t0,t1);}
t2=C_mutate((C_word*)lf[11]+1 /* (set! setup-api#host-extension ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1869,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 94   get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[315]))(3,*((C_word*)lf[315]+1),t3,lf[356]);}

/* k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1872,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
C_trace("setup-api.scm: 95   make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),t2,t1,lf[355]);}
else{
t3=t2;
f_1872(2,t3,C_SCHEME_FALSE);}}

/* k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1875,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1875(2,t3,t1);}
else{
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[345]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}}

/* k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1875,2,t0,t1);}
t2=C_mutate(&lf[12] /* (set! setup-api#*chicken-bin-path* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1879,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 99   get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[315]))(3,*((C_word*)lf[315]+1),t3,lf[354]);}

/* k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1882(2,t3,t1);}
else{
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[345]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_PREFIX),C_fix(0));}}

/* k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1882,2,t0,t1);}
t2=C_mutate((C_word*)lf[13]+1 /* (set! setup-api#chicken-prefix ...) */,t1);
t3=C_mutate((C_word*)lf[14]+1 /* (set! setup-api#shellpath ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1884,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[17]+1 /* (set! setup-api#cross-chicken ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1894,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1903,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 108  current-directory");
((C_proc2)C_retrieve_symbol_proc(lf[353]))(2,*((C_word*)lf[353]+1),t5);}

/* k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1903,2,t0,t1);}
t2=C_mutate(&lf[18] /* (set! setup-api#*base-directory* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1907,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 110  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[341]))(3,*((C_word*)lf[341]+1),t3,C_retrieve2(lf[18],"setup-api#*base-directory*"));}

/* k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1907,2,t0,t1);}
t2=C_mutate((C_word*)lf[19]+1 /* (set! setup-api#setup-root-directory ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 111  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[341]))(3,*((C_word*)lf[341]+1),t3,C_SCHEME_FALSE);}

/* k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1911,2,t0,t1);}
t2=C_mutate((C_word*)lf[20]+1 /* (set! setup-api#setup-verbose-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1915,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 112  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[341]))(3,*((C_word*)lf[341]+1),t3,C_SCHEME_TRUE);}

/* k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1915,2,t0,t1);}
t2=C_mutate((C_word*)lf[21]+1 /* (set! setup-api#setup-install-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1919,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 113  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[341]))(3,*((C_word*)lf[341]+1),t3,C_SCHEME_FALSE);}

/* k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1919,2,t0,t1);}
t2=C_mutate((C_word*)lf[22]+1 /* (set! setup-api#deployment-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 114  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[341]))(3,*((C_word*)lf[341]+1),t3,C_retrieve2(lf[12],"setup-api#*chicken-bin-path*"));}

/* k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
t2=C_mutate((C_word*)lf[23]+1 /* (set! setup-api#program-path ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1927,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 115  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[341]))(3,*((C_word*)lf[341]+1),t3,C_SCHEME_FALSE);}

/* k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1927,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1 /* (set! setup-api#keep-intermediates ...) */,t1);
t3=lf[25] /* setup-api#*copy-command* */ =C_SCHEME_UNDEFINED;;
t4=lf[26] /* setup-api#*remove-command* */ =C_SCHEME_UNDEFINED;;
t5=lf[27] /* setup-api#*move-command* */ =C_SCHEME_UNDEFINED;;
t6=lf[28] /* setup-api#*chmod-command* */ =C_SCHEME_UNDEFINED;;
t7=lf[29] /* setup-api#*ranlib-command* */ =C_SCHEME_UNDEFINED;;
t8=lf[30] /* setup-api#*mkdir-command* */ =C_SCHEME_UNDEFINED;;
t9=C_mutate(&lf[31] /* (set! setup-api#user-install-setup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1968,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[43]+1 /* (set! setup-api#sudo-install ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1994,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2017,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5952,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 170  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[341]))(3,*((C_word*)lf[341]+1),t11,t12);}

/* a5951 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5952,2,t0,t1);}
t2=C_retrieve(lf[352]);
C_trace("g9899");
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,C_fix(1));}

/* k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2017,2,t0,t1);}
t2=C_mutate((C_word*)lf[52]+1 /* (set! setup-api#abort-setup ...) */,t1);
t3=C_mutate((C_word*)lf[53]+1 /* (set! setup-api#yes-or-no? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2019,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[70]+1 /* (set! setup-api#patch ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2117,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2234,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 205  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[341]))(3,*((C_word*)lf[341]+1),t5,C_SCHEME_TRUE);}

/* k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2234,2,t0,t1);}
t2=C_mutate((C_word*)lf[81]+1 /* (set! setup-api#run-verbose ...) */,t1);
t3=C_mutate((C_word*)lf[82]+1 /* (set! setup-api#register-program ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2236,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[87]+1 /* (set! setup-api#find-program ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2276,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2295,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2306,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5950,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t8=*((C_word*)lf[345]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k5948 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 222  reg");
f_2295(((C_word*)t0)[2],lf[351],t1);}

/* k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5946,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[345]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSI_PROGRAM),C_fix(0));}

/* k5944 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 223  reg");
f_2295(((C_word*)t0)[2],lf[350],t1);}

/* k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5942,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[345]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k5940 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 224  reg");
f_2295(((C_word*)t0)[2],lf[349],t1);}

/* k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5938,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[345]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CHICKEN_INSTALL_PROGRAM),C_fix(0));}

/* k5936 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 225  reg");
f_2295(((C_word*)t0)[2],lf[348],t1);}

/* k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5934,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[345]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CHICKEN_UNINSTALL_PROGRAM),C_fix(0));}

/* k5932 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 226  reg");
f_2295(((C_word*)t0)[2],lf[347],t1);}

/* k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5930,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[345]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CHICKEN_STATUS_PROGRAM),C_fix(0));}

/* k5928 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 227  reg");
f_2295(((C_word*)t0)[2],lf[346],t1);}

/* k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2324,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5926,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[345]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CHICKEN_BUG_PROGRAM),C_fix(0));}

/* k5924 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 228  reg");
f_2295(((C_word*)t0)[2],lf[344],t1);}

/* k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2324,2,t0,t1);}
t2=C_mutate(&lf[88] /* (set! setup-api#fixmaketarget ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2391,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[94]+1 /* (set! setup-api#execute ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2417,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[115] /* (set! setup-api#make:form-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2624,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[119] /* (set! setup-api#make:line-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2646,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[122] /* (set! setup-api#make:make/proc/helper ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2852,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[168]+1 /* (set! setup-api#make/proc ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3273,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3349,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 430  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[341]))(3,*((C_word*)lf[341]+1),t8,C_SCHEME_FALSE);}

/* k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3349,2,t0,t1);}
t2=C_mutate((C_word*)lf[170]+1 /* (set! setup-api#destination-prefix ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3353,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 433  get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[315]))(3,*((C_word*)lf[315]+1),t3,lf[343]);}

/* k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[74],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3353,2,t0,t1);}
t2=C_mutate((C_word*)lf[171]+1 /* (set! setup-api#installation-prefix ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3354,a[2]=t1,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3367,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[10],"setup-api#*windows*"))?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5887,a[2]=t3,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5895,a[2]=t3,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[175]+1 /* (set! setup-api#create-directory/parents ...) */,t4);
t6=C_mutate(&lf[176] /* (set! setup-api#write-info ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3391,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[187]+1 /* (set! setup-api#copy-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3520,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[191]+1 /* (set! setup-api#move-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3666,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[192]+1 /* (set! setup-api#remove-file* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3721,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[193] /* (set! setup-api#make-dest-pathname ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3743,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[194] /* (set! setup-api#check-filelist ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3768,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[196]+1 /* (set! setup-api#standard-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3905,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[198]+1 /* (set! setup-api#install-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4095,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[220]+1 /* (set! setup-api#install-program ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4322,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[227]+1 /* (set! setup-api#install-script ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4541,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[182] /* (set! setup-api#repo-path ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4705,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[188] /* (set! setup-api#ensure-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4777,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[236]+1 /* (set! setup-api#try-compile ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4830,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[266]+1 /* (set! setup-api#required-chicken-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4954,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[271] /* (set! setup-api#upgrade-message ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4986,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[279]+1 /* (set! setup-api#required-extension-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5067,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[287]+1 /* (set! setup-api#test-compile ...) */,C_retrieve(lf[236]));
t23=C_mutate((C_word*)lf[288]+1 /* (set! setup-api#find-library ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5188,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[297]+1 /* (set! setup-api#find-header ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5247,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[269]+1 /* (set! setup-api#version>=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5269,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5468,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5817,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 719  make-parameter");
((C_proc4)C_retrieve_symbol_proc(lf[341]))(4,*((C_word*)lf[341]+1),t26,lf[342],t27);}

/* a5816 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5817(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5817,3,t0,t1,t2);}
t3=C_i_not(t2);
t4=(C_truep(t3)?t3:C_i_nullp(t2));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[337]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5833,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_listp(t2))){
t6=C_i_length(t2);
t7=t5;
f_5833(t7,C_i_nequalp(C_fix(2),t6));}
else{
t6=t5;
f_5833(t6,C_SCHEME_FALSE);}}}

/* k5831 in a5816 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5833(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5833,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[3]);
t3=C_i_cadr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5840,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5863,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 727  ensure-string");
f_5840(t5,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5870,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 729  warning");
((C_proc4)C_retrieve_symbol_proc(lf[339]))(4,*((C_word*)lf[339]+1),t2,lf[340],((C_word*)t0)[3]);}}

/* k5868 in k5831 in a5816 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 730  extension-name-and-version");
((C_proc2)C_retrieve_symbol_proc(lf[304]))(2,*((C_word*)lf[304]+1),((C_word*)t0)[2]);}

/* k5861 in k5831 in a5816 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5867,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 727  ensure-string");
f_5840(t2,((C_word*)t0)[2]);}

/* k5865 in k5861 in k5831 in a5816 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5867,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* ensure-string in k5831 in a5816 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5840(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5840,NULL,2,t1,t2);}
t3=C_i_not(t2);
if(C_truep(t3)){
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[338]);}
else{
C_trace("setup-api.scm: 726  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),t1,t2);}}
else{
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[338]);}
else{
C_trace("setup-api.scm: 726  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),t1,t2);}}}

/* k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5468,2,t0,t1);}
t2=C_mutate((C_word*)lf[304]+1 /* (set! setup-api#extension-name-and-version ...) */,t1);
t3=C_mutate((C_word*)lf[305]+1 /* (set! setup-api#extension-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5470,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[306]+1 /* (set! setup-api#extension-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5480,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[308]+1 /* (set! setup-api#read-info ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5524,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[311]+1 /* (set! setup-api#create-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5538,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[319]+1 /* (set! setup-api#remove-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5591,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[328]+1 /* (set! setup-api#remove-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5722,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[75] /* (set! setup-api#$system ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5776,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5815,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 798  user-install-setup");
f_1968(t10);}

/* k5813 in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* setup-api#$system in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5776(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5776,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5780,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5793,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[8],"setup-api#*windows-shell*"))){
C_trace("setup-api.scm: 785  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[128]+1)))(5,*((C_word*)lf[128]+1),t4,lf[335],t2,lf[336]);}
else{
t5=t2;
C_trace("setup-api.scm: 783  system");
((C_proc3)C_retrieve_symbol_proc(lf[239]))(3,*((C_word*)lf[239]+1),t3,t5);}}

/* k5791 in setup-api#$system in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 783  system");
((C_proc3)C_retrieve_symbol_proc(lf[239]))(3,*((C_word*)lf[239]+1),((C_word*)t0)[2],t1);}

/* k5778 in setup-api#$system in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5780,2,t0,t1);}
if(C_truep(C_i_zerop(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
t3=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5802,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 791  flush-output");
((C_proc2)C_retrieve_proc(*((C_word*)lf[64]+1)))(2,*((C_word*)lf[64]+1),t4);}}

/* k5800 in k5778 in setup-api#$system in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5805,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5812,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 792  current-error-port");
((C_proc2)C_retrieve_symbol_proc(lf[334]))(2,*((C_word*)lf[334]+1),t3);}

/* k5810 in k5800 in k5778 in setup-api#$system in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 792  fprintf");
((C_proc6)C_retrieve_symbol_proc(lf[331]))(6,*((C_word*)lf[331]+1),((C_word*)t0)[3],t1,lf[332],lf[333],((C_word*)t0)[2]);}

/* k5803 in k5800 in k5778 in setup-api#$system in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 793  reset");
((C_proc2)C_retrieve_symbol_proc(lf[330]))(2,*((C_word*)lf[330]+1),((C_word*)t0)[2]);}

/* setup-api#remove-extension in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5722(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5722,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5774,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 778  read-info");
((C_proc3)C_retrieve_symbol_proc(lf[308]))(3,*((C_word*)lf[308]+1),t3,t2);}

/* k5772 in setup-api#remove-extension in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5774,2,t0,t1);}
t2=C_i_assq(lf[177],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=C_i_cdr(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5749,a[2]=t6,a[3]=((C_word)li99),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5749(t8,t3,t4);}
else{
t4=t3;
f_5729(2,t4,C_SCHEME_FALSE);}}

/* loop1668 in k5772 in setup-api#remove-extension in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5749(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5749,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[192]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5759,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
C_trace("g16751676");
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5757 in loop1668 in k5772 in setup-api#remove-extension in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5749(t3,((C_word*)t0)[2],t2);}

/* k5727 in k5772 in setup-api#remove-extension in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5736,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5740,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 780  repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[181]))(2,*((C_word*)lf[181]+1),t3);}

/* k5738 in k5727 in k5772 in setup-api#remove-extension in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 780  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[85]))(5,*((C_word*)lf[85]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[329]);}

/* k5734 in k5727 in k5772 in setup-api#remove-extension in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 780  remove-file*");
((C_proc3)C_retrieve_symbol_proc(lf[192]))(3,*((C_word*)lf[192]+1),((C_word*)t0)[2],t1);}

/* setup-api#remove-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5591(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5591r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5591r(t0,t1,t2,t3);}}

static void C_ccall f_5591r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5595,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_5595(2,t5,C_SCHEME_TRUE);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_5595(2,t6,C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5593 in setup-api#remove-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5701,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 758  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[140]))(3,*((C_word*)lf[140]+1),t2,((C_word*)t0)[2]);}

/* k5699 in k5593 in setup-api#remove-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5701,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve2(lf[7],"setup-api#*sudo*"))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5617,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[77]))(2,*((C_word*)lf[77]+1),t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5635,a[2]=t3,a[3]=((C_word)li97),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5635(t5,((C_word*)t0)[4],((C_word*)t0)[3]);}}
else{
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-api.scm: 760  error");
((C_proc5)C_retrieve_proc(*((C_word*)lf[116]+1)))(5,*((C_word*)lf[116]+1),((C_word*)t0)[4],lf[326],lf[327],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* walk in k5699 in k5593 in setup-api#remove-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5635(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5635,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5639,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 766  directory");
((C_proc4)C_retrieve_symbol_proc(lf[325]))(4,*((C_word*)lf[325]+1),t3,t2,C_SCHEME_TRUE);}

/* k5637 in walk in k5699 in k5593 in setup-api#remove-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5642,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5647,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word)li96),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5647(t6,t2,t1);}

/* loop1638 in k5637 in walk in k5699 in k5593 in setup-api#remove-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5647(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5647,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5655,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li95),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5686,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
C_trace("g16451646");
t6=t3;
f_5655(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5684 in loop1638 in k5637 in walk in k5699 in k5593 in setup-api#remove-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5647(t3,((C_word*)t0)[2],t2);}

/* g1645 in loop1638 in k5637 in walk in k5699 in k5593 in setup-api#remove-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5655(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5655,NULL,3,t0,t1,t2);}
t3=C_i_string_equal_p(lf[322],t2);
t4=(C_truep(t3)?t3:C_i_string_equal_p(lf[323],t2));
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5668,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 770  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),t5,((C_word*)t0)[2],t2);}}

/* k5666 in g1645 in loop1638 in k5637 in walk in k5699 in k5593 in setup-api#remove-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5674,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 771  directory?");
((C_proc3)C_retrieve_symbol_proc(lf[233]))(3,*((C_word*)lf[233]+1),t2,t1);}

/* k5672 in k5666 in g1645 in loop1638 in k5637 in walk in k5699 in k5593 in setup-api#remove-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-api.scm: 772  walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_5635(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_trace("setup-api.scm: 773  delete-file");
((C_proc3)C_retrieve_symbol_proc(lf[324]))(3,*((C_word*)lf[324]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5640 in k5637 in walk in k5699 in k5593 in setup-api#remove-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 775  delete-directory");
((C_proc3)C_retrieve_symbol_proc(lf[321]))(3,*((C_word*)lf[321]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5615 in k5699 in k5593 in setup-api#remove-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5620,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[320],t1);}

/* k5618 in k5615 in k5699 in k5593 in setup-api#remove-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5623,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5630,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 763  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t3,((C_word*)t0)[2]);}

/* k5628 in k5618 in k5615 in k5699 in k5593 in setup-api#remove-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5621 in k5618 in k5615 in k5699 in k5593 in setup-api#remove-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5626,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,((C_word*)t0)[2]);}

/* k5624 in k5621 in k5618 in k5615 in k5699 in k5593 in setup-api#remove-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 763  $system");
f_5776(((C_word*)t0)[2],t1);}

/* setup-api#create-temporary-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5542,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 747  get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[315]))(3,*((C_word*)lf[315]+1),t2,lf[318]);}

/* k5540 in setup-api#create-temporary-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5545,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_5545(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5580,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 748  get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[315]))(3,*((C_word*)lf[315]+1),t3,lf[317]);}}

/* k5578 in k5540 in setup-api#create-temporary-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5580,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_5545(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5586,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 749  get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[315]))(3,*((C_word*)lf[315]+1),t2,lf[316]);}}

/* k5584 in k5578 in k5540 in setup-api#create-temporary-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5545(t2,(C_truep(t1)?t1:lf[314]));}

/* k5543 in k5540 in setup-api#create-temporary-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5545,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5550,a[2]=t1,a[3]=t3,a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5550(t5,((C_word*)t0)[2]);}

/* loop in k5543 in k5540 in setup-api#create-temporary-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5550(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5550,NULL,2,t0,t1);}
t2=C_fudge(C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5557,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5573,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5577,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 753  number->string");
C_number_to_string(4,0,t5,t2,C_fix(16));}

/* k5575 in loop in k5543 in k5540 in setup-api#create-temporary-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 753  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[128]+1)))(4,*((C_word*)lf[128]+1),((C_word*)t0)[2],lf[313],t1);}

/* k5571 in loop in k5543 in k5540 in setup-api#create-temporary-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 753  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[85]))(5,*((C_word*)lf[85]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[312]);}

/* k5555 in loop in k5543 in k5540 in setup-api#create-temporary-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5563,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 754  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[140]))(3,*((C_word*)lf[140]+1),t2,t1);}

/* k5561 in k5555 in loop in k5543 in k5540 in setup-api#create-temporary-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5563,2,t0,t1);}
if(C_truep(t1)){
C_trace("setup-api.scm: 754  loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_5550(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5569,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 755  create-directory");
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2]);}}

/* k5567 in k5561 in k5555 in loop in k5543 in k5540 in setup-api#create-temporary-directory in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* setup-api#read-info in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5524,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5532,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5536,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 743  repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[181]))(2,*((C_word*)lf[181]+1),t4);}

/* k5534 in setup-api#read-info in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 743  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[85]))(5,*((C_word*)lf[85]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[310]);}

/* k5530 in setup-api#read-info in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 742  with-input-from-file");
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),((C_word*)t0)[2],t1,*((C_word*)lf[309]+1));}

/* setup-api#extension-version in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5480(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_5480r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5480r(t0,t1,t2);}}

static void C_ccall f_5480r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5484,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t2))){
t4=t3;
f_5484(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_5484(2,t5,C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k5482 in setup-api#extension-version in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5503,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 736  extension-name-and-version");
((C_proc2)C_retrieve_symbol_proc(lf[304]))(2,*((C_word*)lf[304]+1),t2);}

/* k5501 in k5482 in setup-api#extension-version in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5503,2,t0,t1);}
t2=C_i_cadr(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5493,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 737  string-null?");
((C_proc3)C_retrieve_symbol_proc(lf[307]))(3,*((C_word*)lf[307]+1),t3,t2);}

/* k5491 in k5501 in k5482 in setup-api#extension-version in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[4])){
C_trace("setup-api.scm: 738  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* setup-api#extension-name in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5478,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 733  extension-name-and-version");
((C_proc2)C_retrieve_symbol_proc(lf[304]))(2,*((C_word*)lf[304]+1),t2);}

/* k5476 in setup-api#extension-name in k5466 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_car(t1));}

/* setup-api#version>=? in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5269,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5272,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5334,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 703  version->list");
f_5272(t5,t2);}

/* k5332 in setup-api#version>=? in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5338,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 704  version->list");
f_5272(t2,((C_word*)t0)[2]);}

/* k5336 in k5332 in setup-api#version>=? in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5338,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5340,a[2]=t3,a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5340(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k5336 in k5332 in setup-api#version>=? in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5340(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5340,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_nullp(t3));}
else{
t4=C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_i_car(t2);
if(C_truep(C_i_numberp(t5))){
t6=C_i_car(t3);
if(C_truep(C_i_numberp(t6))){
t7=C_i_car(t2);
t8=C_i_car(t3);
t9=C_i_greaterp(t7,t8);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t10=C_i_car(t2);
t11=C_i_car(t3);
if(C_truep(C_i_nequalp(t10,t11))){
t12=C_i_cdr(t2);
t13=C_i_cdr(t3);
C_trace("setup-api.scm: 711  loop");
t20=t1;
t21=t12;
t22=t13;
t1=t20;
t2=t21;
t3=t22;
goto loop;}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=C_i_car(t3);
t7=C_i_numberp(t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5420,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=C_i_car(t2);
t10=C_i_car(t3);
C_trace("setup-api.scm: 713  string>?");
((C_proc4)C_retrieve_proc(*((C_word*)lf[303]+1)))(4,*((C_word*)lf[303]+1),t8,t9,t10);}}}}}

/* k5418 in loop in k5336 in k5332 in setup-api#version>=? in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_i_car(((C_word*)t0)[4]);
t3=C_i_car(((C_word*)t0)[3]);
if(C_truep(C_i_string_equal_p(t2,t3))){
t4=C_i_cdr(((C_word*)t0)[4]);
t5=C_i_cdr(((C_word*)t0)[3]);
C_trace("setup-api.scm: 716  loop");
t6=((C_word*)((C_word*)t0)[2])[1];
f_5340(t6,((C_word*)t0)[5],t4,t5);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* version->list in setup-api#version>=? in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5272(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5272,NULL,2,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5280,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5327,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 702  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),t8,t2);}

/* k5325 in version->list in setup-api#version>=? in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 702  string-split-fields");
((C_proc5)C_retrieve_symbol_proc(lf[300]))(5,*((C_word*)lf[300]+1),((C_word*)t0)[2],lf[301],t1,lf[302]);}

/* k5278 in version->list in setup-api#version>=? in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5280,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5282,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li86),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5282(t5,((C_word*)t0)[2],t1);}

/* loop1470 in k5278 in version->list in setup-api#version>=? in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5282(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5282,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5292,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5313,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 701  string->number");
C_string_to_number(3,0,t5,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5311 in loop1470 in k5278 in version->list in setup-api#version>=? in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5313,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_5292(t3,C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}
else{
t2=((C_word*)t0)[3];
f_5292(t2,C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}}

/* k5290 in loop1470 in k5278 in version->list in setup-api#version>=? in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5292(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop14701483");
t5=((C_word*)((C_word*)t0)[4])[1];
f_5282(t5,((C_word*)t0)[3],t4);}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop14701483");
t5=((C_word*)((C_word*)t0)[4])[1];
f_5282(t5,((C_word*)t0)[3],t4);}}

/* setup-api#find-header in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5247,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5255,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[77]))(2,*((C_word*)lf[77]+1),t3);}

/* k5253 in setup-api#find-header in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5258,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[299],t1);}

/* k5256 in k5253 in setup-api#find-header in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5261,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5259 in k5256 in k5253 in setup-api#find-header in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[298],((C_word*)t0)[2]);}

/* k5262 in k5259 in k5256 in k5253 in setup-api#find-header in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5267,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,((C_word*)t0)[2]);}

/* k5265 in k5262 in k5259 in k5256 in k5253 in setup-api#find-header in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 695  test-compile");
((C_proc5)C_retrieve_symbol_proc(lf[287]))(5,*((C_word*)lf[287]+1),((C_word*)t0)[2],t1,lf[258],C_SCHEME_TRUE);}

/* setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5188,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5196,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[77]))(2,*((C_word*)lf[77]+1),t4);}

/* k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5199,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[296],t1);}

/* k5197 in k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k5200 in k5197 in k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[295],((C_word*)t0)[3]);}

/* k5203 in k5200 in k5197 in k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k5206 in k5203 in k5200 in k5197 in k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[294],((C_word*)t0)[3]);}

/* k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[293],((C_word*)t0)[3]);}

/* k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5218 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[292],((C_word*)t0)[3]);}

/* k5221 in k5218 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5226,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k5224 in k5221 in k5218 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[291],((C_word*)t0)[3]);}

/* k5227 in k5224 in k5221 in k5218 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5232,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5230 in k5227 in k5224 in k5221 in k5218 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[290],((C_word*)t0)[2]);}

/* k5233 in k5230 in k5227 in k5224 in k5221 in k5218 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k5236 in k5233 in k5230 in k5227 in k5224 in k5221 in k5218 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,((C_word*)t0)[2]);}

/* k5239 in k5236 in k5233 in k5230 in k5227 in k5224 in k5221 in k5218 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5245,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 692  conc");
((C_proc4)C_retrieve_symbol_proc(lf[245]))(4,*((C_word*)lf[245]+1),t2,lf[289],((C_word*)t0)[2]);}

/* k5243 in k5239 in k5236 in k5233 in k5230 in k5227 in k5224 in k5221 in k5218 in k5215 in k5212 in k5209 in k5206 in k5203 in k5200 in k5197 in k5194 in setup-api#find-library in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 690  test-compile");
((C_proc5)C_retrieve_symbol_proc(lf[287]))(5,*((C_word*)lf[287]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[261],t1);}

/* setup-api#required-extension-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5067(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_5067r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5067r(t0,t1,t2);}}

static void C_ccall f_5067r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5073,a[2]=t4,a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5073(t6,t1,t2);}

/* loop in setup-api#required-extension-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5073(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5073,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5086,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(t2))){
t4=C_i_length(t2);
t5=t3;
f_5086(t5,C_i_greater_or_equalp(t4,C_fix(2)));}
else{
t4=t3;
f_5086(t4,C_SCHEME_FALSE);}}}

/* k5084 in loop in setup-api#required-extension-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5086(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5086,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[4]);
t3=C_i_cadr(((C_word*)t0)[4]);
t4=C_i_cddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5098,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 672  extension-information");
((C_proc3)C_retrieve_symbol_proc(lf[284]))(3,*((C_word*)lf[284]+1),t5,t2);}
else{
C_trace("setup-api.scm: 685  error");
((C_proc5)C_retrieve_proc(*((C_word*)lf[116]+1)))(5,*((C_word*)lf[116]+1),((C_word*)t0)[3],lf[285],lf[286],((C_word*)t0)[4]);}}

/* k5096 in k5084 in loop in setup-api#required-extension-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5098,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_assq(lf[197],t1))){
t3=C_i_assq(lf[197],t1);
t4=t2;
f_5104(t4,C_i_cadr(t3));}
else{
t3=t2;
f_5104(t3,C_SCHEME_FALSE);}}
else{
C_trace("setup-api.scm: 683  upgrade-message");
f_4986(((C_word*)t0)[6],((C_word*)t0)[5],lf[283],C_SCHEME_END_OF_LIST);}}

/* k5102 in k5096 in k5084 in loop in setup-api#required-extension-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5104(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5104,NULL,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5144,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 676  version>=?");
((C_proc4)C_retrieve_symbol_proc(lf[269]))(4,*((C_word*)lf[269]+1),t4,((C_word*)t0)[4],t1);}
else{
C_trace("setup-api.scm: 675  upgrade-message");
f_4986(((C_word*)t0)[6],((C_word*)t0)[5],lf[282],C_SCHEME_END_OF_LIST);}}

/* k5142 in k5102 in k5096 in k5084 in loop in setup-api#required-extension-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5144,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5155,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 676  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_5119(t2,C_SCHEME_FALSE);}}

/* k5153 in k5142 in k5102 in k5096 in k5084 in loop in setup-api#required-extension-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5159,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 676  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),t2,((C_word*)t0)[2]);}

/* k5157 in k5153 in k5142 in k5102 in k5096 in k5084 in loop in setup-api#required-extension-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_string_equal_p(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_5119(t3,C_i_not(t2));}

/* k5117 in k5102 in k5096 in k5084 in loop in setup-api#required-extension-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_5119(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5119,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5126,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[77]))(2,*((C_word*)lf[77]+1),t2);}
else{
C_trace("setup-api.scm: 682  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_5073(t2,((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k5124 in k5117 in k5102 in k5096 in k5084 in loop in setup-api#required-extension-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5129,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[281],t1);}

/* k5127 in k5124 in k5117 in k5102 in k5096 in k5084 in loop in setup-api#required-extension-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5130 in k5127 in k5124 in k5117 in k5102 in k5096 in k5084 in loop in setup-api#required-extension-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5135,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[280],((C_word*)t0)[2]);}

/* k5133 in k5130 in k5127 in k5124 in k5117 in k5102 in k5096 in k5084 in loop in setup-api#required-extension-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5138,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,((C_word*)t0)[2]);}

/* k5136 in k5133 in k5130 in k5127 in k5124 in k5117 in k5102 in k5096 in k5084 in loop in setup-api#required-extension-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5138,2,t0,t1);}
C_trace("setup-api.scm: 677  upgrade-message");
f_4986(((C_word*)t0)[4],((C_word*)t0)[3],t1,C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_4986(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4986,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4990,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_4990(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_4990(2,t7,C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[77]))(2,*((C_word*)lf[77]+1),t2);}

/* k4995 in k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[278],t1);}

/* k4998 in k4995 in k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,((C_word*)t0)[3],((C_word*)t0)[5]);}

/* k5001 in k4998 in k4995 in k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[277],((C_word*)t0)[5]);}

/* k5004 in k5001 in k4998 in k4995 in k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5009,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k5007 in k5004 in k5001 in k4998 in k4995 in k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[276],((C_word*)t0)[4]);}

/* k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[275],((C_word*)t0)[4]);}

/* k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5024,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5043,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-api.scm: 663  conc");
((C_proc4)C_retrieve_symbol_proc(lf[245]))(4,*((C_word*)lf[245]+1),t3,lf[273],((C_word*)t0)[2]);}
else{
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[274],((C_word*)t0)[3]);}}

/* k5041 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5036,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[272],((C_word*)t0)[2]);}

/* k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5039,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,((C_word*)t0)[2]);}

/* k5037 in k5034 in k5031 in k5028 in k5025 in k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4988 in setup-api#upgrade-message in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 660  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],t1);}

/* setup-api#required-chicken-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4954,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4961,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4984,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 656  chicken-version");
((C_proc2)C_retrieve_symbol_proc(lf[270]))(2,*((C_word*)lf[270]+1),t4);}

/* k4982 in setup-api#required-chicken-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 656  version>=?");
((C_proc4)C_retrieve_symbol_proc(lf[269]))(4,*((C_word*)lf[269]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4959 in setup-api#required-chicken-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4961,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[77]))(2,*((C_word*)lf[77]+1),t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4966 in k4959 in setup-api#required-chicken-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4971,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[268],t1);}

/* k4969 in k4966 in k4959 in setup-api#required-chicken-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4974,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4972 in k4969 in k4966 in k4959 in setup-api#required-chicken-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[267],((C_word*)t0)[2]);}

/* k4975 in k4972 in k4969 in k4966 in k4959 in setup-api#required-chicken-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4980,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,((C_word*)t0)[2]);}

/* k4978 in k4975 in k4972 in k4969 in k4966 in k4959 in setup-api#required-chicken-version in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 657  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],t1);}

/* setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4830r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4830r(t0,t1,t2,t3);}}

static void C_ccall f_4830r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4834,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[67]))(4,*((C_word*)lf[67]+1),t4,lf[265],t3);}

/* k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4948,a[2]=t1,a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),t2,lf[264],((C_word*)t0)[2],t3);}

/* a4947 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4948,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=C_retrieve2(lf[3],"setup-api#*cxx*");
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve2(lf[3],"setup-api#*cxx*"));}
else{
t2=C_retrieve2(lf[2],"setup-api#*cc*");
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve2(lf[2],"setup-api#*cc*"));}}

/* k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4945,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),t2,lf[263],((C_word*)t0)[2],t3);}

/* a4944 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4945,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[262]);}

/* k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4942,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),t2,lf[261],((C_word*)t0)[2],t3);}

/* a4941 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4942,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[260]);}

/* k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4936,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),t2,lf[259],((C_word*)t0)[2],t3);}

/* a4935 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4936,2,t0,t1);}
C_trace("setup-api.scm: 633  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t1);}

/* k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4849,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4933,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),t2,lf[258],((C_word*)t0)[2],t3);}

/* a4932 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4933,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm: 634  create-temporary-file");
((C_proc3)C_retrieve_symbol_proc(lf[78]))(3,*((C_word*)lf[78]+1),t2,lf[257]);}

/* k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("setup-api.scm: 635  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[89]))(4,*((C_word*)lf[89]+1),t2,t1,lf[256]);}

/* k4853 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4927,a[2]=((C_word*)t0)[2],a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 637  with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),t2,((C_word*)t0)[8],t3);}

/* a4926 in k4853 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4927,2,t0,t1);}
t2=*((C_word*)lf[59]+1);
C_trace("g13301331");
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[2]);}

/* k4856 in k4853 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4861,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4904,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(((C_word*)t0)[5])?lf[241]:lf[242]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4918,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=t5;
f_4918(2,t6,lf[252]);}
else{
C_trace("setup-api.scm: 646  conc");
((C_proc8)C_retrieve_symbol_proc(lf[245]))(8,*((C_word*)lf[245]+1),t5,lf[253],C_retrieve2(lf[6],"setup-api#*target-lib-home*"),lf[254],((C_word*)t0)[2],lf[255],C_retrieve2(lf[5],"setup-api#*target-libs*"));}}

/* k4916 in k4856 in k4853 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?lf[243]:lf[244]);
C_trace("setup-api.scm: 639  conc");
((C_proc15)C_retrieve_symbol_proc(lf[245]))(15,*((C_word*)lf[245]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[246],((C_word*)t0)[4],lf[247],((C_word*)t0)[3],lf[248],C_retrieve2(lf[4],"setup-api#*target-cflags*"),lf[249],((C_word*)t0)[2],lf[250],t1,lf[251],t2);}

/* k4902 in k4856 in k4853 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4907,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-api.scm: 649  print");
((C_proc4)C_retrieve_proc(*((C_word*)lf[44]+1)))(4,*((C_word*)lf[44]+1),t2,t1,lf[240]);}
else{
t3=t1;
C_trace("setup-api.scm: 638  system");
((C_proc3)C_retrieve_symbol_proc(lf[239]))(3,*((C_word*)lf[239]+1),((C_word*)t0)[3],t3);}}

/* k4905 in k4902 in k4856 in k4853 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 638  system");
((C_proc3)C_retrieve_symbol_proc(lf[239]))(3,*((C_word*)lf[239]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4859 in k4856 in k4853 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4864,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(C_i_zerop(t1))){
C_trace("setup-api.scm: 651  print");
((C_proc3)C_retrieve_proc(*((C_word*)lf[44]+1)))(3,*((C_word*)lf[44]+1),t2,lf[237]);}
else{
C_trace("setup-api.scm: 651  print");
((C_proc3)C_retrieve_proc(*((C_word*)lf[44]+1)))(3,*((C_word*)lf[44]+1),t2,lf[238]);}}
else{
t3=t2;
f_4864(2,t3,C_SCHEME_UNDEFINED);}}

/* k4862 in k4859 in k4856 in k4853 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4874,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[77]))(2,*((C_word*)lf[77]+1),t3);}

/* k4872 in k4862 in k4859 in k4856 in k4853 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4877,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,C_retrieve2(lf[26],"setup-api#*remove-command*"),t1);}

/* k4875 in k4872 in k4862 in k4859 in k4856 in k4853 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k4878 in k4875 in k4872 in k4862 in k4859 in k4856 in k4853 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4883,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4890,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 652  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t3,((C_word*)t0)[2]);}

/* k4888 in k4878 in k4875 in k4872 in k4862 in k4859 in k4856 in k4853 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4881 in k4878 in k4875 in k4872 in k4862 in k4859 in k4856 in k4853 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4886,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,((C_word*)t0)[2]);}

/* k4884 in k4881 in k4878 in k4875 in k4872 in k4862 in k4859 in k4856 in k4853 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 652  $system");
f_5776(((C_word*)t0)[2],t1);}

/* k4865 in k4862 in k4859 in k4856 in k4853 in k4850 in k4847 in k4844 in k4841 in k4838 in k4835 in k4832 in setup-api#try-compile in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_zerop(((C_word*)t0)[2]));}

/* setup-api#ensure-directory in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_4777(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4777,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4781,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 622  pathname-directory");
((C_proc3)C_retrieve_symbol_proc(lf[235]))(3,*((C_word*)lf[235]+1),t3,t2);}

/* k4779 in setup-api#ensure-directory in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4790,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 623  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[140]))(3,*((C_word*)lf[140]+1),t3,t1);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* k4788 in k4779 in setup-api#ensure-directory in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4790,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4796,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 624  directory?");
((C_proc3)C_retrieve_symbol_proc(lf[233]))(3,*((C_word*)lf[233]+1),t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 627  create-directory/parents");
((C_proc3)C_retrieve_symbol_proc(lf[175]))(3,*((C_word*)lf[175]+1),t2,((C_word*)t0)[2]);}}

/* k4800 in k4788 in k4779 in setup-api#ensure-directory in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4802,2,t0,t1);}
if(C_truep(C_retrieve2(lf[8],"setup-api#*windows-shell*"))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4828,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 629  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t2,((C_word*)t0)[2]);}}

/* k4826 in k4800 in k4788 in k4779 in setup-api#ensure-directory in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4828,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[234],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[28],"setup-api#*chmod-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* k4794 in k4788 in k4779 in setup-api#ensure-directory in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
C_trace("setup-api.scm: 625  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],lf[232]);}}

/* k4782 in k4779 in setup-api#ensure-directory in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#repo-path in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_4705(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4705,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4709,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t2))){
t4=t3;
f_4709(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_4709(2,t5,C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4707 in setup-api#repo-path in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4721,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 609  deployment-mode");
((C_proc2)C_retrieve_symbol_proc(lf[22]))(2,*((C_word*)lf[22]+1),t3);}
else{
C_trace("setup-api.scm: 617  repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[181]))(2,*((C_word*)lf[181]+1),t2);}}

/* k4719 in k4707 in setup-api#repo-path in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4721,2,t0,t1);}
if(C_truep(t1)){
C_trace("setup-api.scm: 610  installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[171]))(2,*((C_word*)lf[171]+1),((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4727,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 611  destination-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[170]))(2,*((C_word*)lf[170]+1),t2);}}

/* k4725 in k4719 in k4707 in setup-api#repo-path in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4727,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4737,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[77]))(2,*((C_word*)lf[77]+1),t2);}
else{
C_trace("setup-api.scm: 616  repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[181]))(2,*((C_word*)lf[181]+1),((C_word*)t0)[2]);}}

/* k4735 in k4725 in k4719 in k4707 in setup-api#repo-path in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4740,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[231],t1);}

/* k4738 in k4735 in k4725 in k4719 in k4707 in setup-api#repo-path in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_fudge(C_fix(42));
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,t3,((C_word*)t0)[2]);}

/* k4741 in k4738 in k4735 in k4725 in k4719 in k4707 in setup-api#repo-path in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4746,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,((C_word*)t0)[2]);}

/* k4744 in k4741 in k4738 in k4735 in k4725 in k4719 in k4707 in setup-api#repo-path in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 613  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4710 in k4707 in setup-api#repo-path in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4715,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 618  ensure-directory");
f_4777(t2,t1);}

/* k4713 in k4710 in k4707 in setup-api#repo-path in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4541r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4541r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4541r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4545,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_4545(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_4545(2,t7,C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k4543 in setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4551,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 588  setup-install-mode");
((C_proc2)C_retrieve_symbol_proc(lf[21]))(2,*((C_word*)lf[21]+1),t2);}

/* k4549 in k4543 in setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4551,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4554,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[2];
C_trace("setup-api.scm: 589  check-filelist");
f_3768(t2,t3);}
else{
t3=C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("setup-api.scm: 589  check-filelist");
f_3768(t2,t3);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4552 in k4549 in k4543 in setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4557,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 590  installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[171]))(2,*((C_word*)lf[171]+1),t2);}

/* k4555 in k4552 in k4549 in k4543 in setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4674,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 591  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),t3,t1,lf[230]);}

/* k4672 in k4555 in k4552 in k4549 in k4543 in setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 591  ensure-directory");
f_4777(((C_word*)t0)[2],t1);}

/* k4558 in k4555 in k4552 in k4549 in k4543 in setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4560,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4563,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4594,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=((C_word)li69),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_4594(t10,t6,((C_word*)t0)[2]);}

/* loop1222 in k4558 in k4555 in k4552 in k4549 in k4543 in setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_4594(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4594,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4621,a[2]=((C_word*)t0)[5],a[3]=((C_word)li68),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4666,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
C_trace("g12381239");
t6=t3;
f_4621(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4664 in loop1222 in k4558 in k4555 in k4552 in k4549 in k4543 in setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4666,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop12221235");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4594(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop12221235");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4594(t6,((C_word*)t0)[3],t5);}}

/* g1238 in loop1222 in k4558 in k4555 in k4552 in k4549 in k4543 in setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_4621(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4621,NULL,3,t0,t1,t2);}
t3=C_i_pairp(t2);
t4=(C_truep(t3)?C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4628,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 594  make-dest-pathname");
f_3743(t5,((C_word*)t0)[2],t2);}

/* k4626 in g1238 in loop1222 in k4558 in k4555 in k4552 in k4549 in k4543 in setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4631,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 595  copy-file");
((C_proc4)C_retrieve_symbol_proc(lf[187]))(4,*((C_word*)lf[187]+1),t2,((C_word*)t0)[2],t1);}

/* k4629 in k4626 in g1238 in loop1222 in k4558 in k4555 in k4552 in k4549 in k4543 in setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[8],"setup-api#*windows-shell*"))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4657,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 597  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t3,((C_word*)t0)[2]);}}

/* k4655 in k4629 in k4626 in g1238 in loop1222 in k4558 in k4555 in k4552 in k4549 in k4543 in setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4657,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[178],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[28],"setup-api#*chmod-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* k4632 in k4629 in k4626 in g1238 in loop1222 in k4558 in k4555 in k4552 in k4549 in k4543 in setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4561 in k4558 in k4555 in k4552 in k4549 in k4543 in setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4566,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[8],"setup-api#*windows-shell*"))){
C_trace("setup-api.scm: 602  write-info");
f_3391(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4592,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 601  string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[97]))(4,*((C_word*)lf[97]+1),t3,t1,lf[229]);}}

/* k4590 in k4561 in k4558 in k4555 in k4552 in k4549 in k4543 in setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4592,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[228],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[28],"setup-api#*chmod-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* k4564 in k4561 in k4558 in k4555 in k4552 in k4549 in k4543 in setup-api#install-script in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 602  write-info");
f_3391(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4322r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4322r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4322r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4326,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_4326(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_4326(2,t7,C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4328,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4342,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 566  setup-install-mode");
((C_proc2)C_retrieve_symbol_proc(lf[21]))(2,*((C_word*)lf[21]+1),t3);}

/* k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4342,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4345,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[2];
C_trace("setup-api.scm: 567  check-filelist");
f_3768(t2,t3);}
else{
t3=C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("setup-api.scm: 567  check-filelist");
f_3768(t2,t3);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4348,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 568  installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[171]))(2,*((C_word*)lf[171]+1),t2);}

/* k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4510,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 569  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),t3,t1,lf[226]);}

/* k4508 in k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 569  ensure-directory");
f_4777(((C_word*)t0)[2],t1);}

/* k4349 in k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4354,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[10],"setup-api#*windows*"))){
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4443,a[2]=t4,a[3]=t8,a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=((C_word)li66),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_4443(t10,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_4354(2,t3,((C_word*)t0)[2]);}}

/* loop1138 in k4349 in k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_4443(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4443,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4470,a[2]=((C_word*)t0)[5],a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4502,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
C_trace("g11541155");
t6=t3;
f_4470(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4500 in loop1138 in k4349 in k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4502,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop11381151");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4443(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop11381151");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4443(t6,((C_word*)t0)[3],t5);}}

/* g1154 in loop1138 in k4349 in k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_4470(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4470,NULL,3,t0,t1,t2);}
if(C_truep(C_i_listp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4484,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
C_trace("setup-api.scm: 573  exify");
f_4328(t3,t4);}
else{
C_trace("setup-api.scm: 574  exify");
f_4328(t1,t2);}}

/* k4482 in g1154 in loop1138 in k4349 in k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4488,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
C_trace("setup-api.scm: 573  exify");
f_4328(t2,t3);}

/* k4486 in k4482 in g1154 in loop1138 in k4349 in k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4488,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k4352 in k4349 in k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4354,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4357,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4362,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li64),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_4362(t10,t6,t1);}

/* loop1163 in k4352 in k4349 in k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_4362(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4362,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4389,a[2]=((C_word*)t0)[5],a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4434,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
C_trace("g11791180");
t6=t3;
f_4389(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4432 in loop1163 in k4352 in k4349 in k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4434,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop11631176");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4362(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop11631176");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4362(t6,((C_word*)t0)[3],t5);}}

/* g1179 in loop1163 in k4352 in k4349 in k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_4389(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4389,NULL,3,t0,t1,t2);}
t3=C_i_pairp(t2);
t4=(C_truep(t3)?C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4396,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 579  make-dest-pathname");
f_3743(t5,((C_word*)t0)[2],t2);}

/* k4394 in g1179 in loop1163 in k4352 in k4349 in k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4399,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 580  copy-file");
((C_proc4)C_retrieve_symbol_proc(lf[187]))(4,*((C_word*)lf[187]+1),t2,((C_word*)t0)[2],t1);}

/* k4397 in k4394 in g1179 in loop1163 in k4352 in k4349 in k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[8],"setup-api#*windows-shell*"))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4425,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 582  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t3,((C_word*)t0)[2]);}}

/* k4423 in k4397 in k4394 in g1179 in loop1163 in k4352 in k4349 in k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4425,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[178],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[28],"setup-api#*chmod-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* k4400 in k4397 in k4394 in g1179 in loop1163 in k4352 in k4349 in k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 585  write-info");
f_3391(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* exify in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_4328(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4328,NULL,2,t1,t2);}
t3=(C_truep(C_retrieve2(lf[8],"setup-api#*windows-shell*"))?lf[221]:C_SCHEME_FALSE);
t4=C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3856,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_3856(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_3856(2,t7,C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3854 in exify in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3863,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 509  pathname-extension");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t2,((C_word*)t0)[2]);}

/* k3861 in k3854 in exify in k4324 in setup-api#install-program in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=t1;
if(C_truep(t2)){
if(C_truep(C_i_equalp(lf[222],t1))){
t3=C_retrieve(lf[90]);
C_trace("setup-api.scm: 508  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[89]))(4,*((C_word*)lf[89]+1),((C_word*)t0)[4],((C_word*)t0)[3],t3);}
else{
if(C_truep(C_i_equalp(lf[223],t1))){
if(C_truep(C_retrieve2(lf[8],"setup-api#*windows-shell*"))){
C_trace("setup-api.scm: 508  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[89]))(4,*((C_word*)lf[89]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[224]);}
else{
C_trace("setup-api.scm: 508  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[89]))(4,*((C_word*)lf[89]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[225]);}}
else{
t3=t1;
C_trace("setup-api.scm: 508  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[89]))(4,*((C_word*)lf[89]+1),((C_word*)t0)[4],((C_word*)t0)[3],t3);}}}
else{
t3=((C_word*)t0)[2];
C_trace("setup-api.scm: 508  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[89]))(4,*((C_word*)lf[89]+1),((C_word*)t0)[4],((C_word*)t0)[3],t3);}}

/* setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4095r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4095r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4095r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4099,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_4099(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_4099(2,t7,C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4105,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 539  setup-install-mode");
((C_proc2)C_retrieve_symbol_proc(lf[21]))(2,*((C_word*)lf[21]+1),t2);}

/* k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4105,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4108,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[2];
C_trace("setup-api.scm: 540  check-filelist");
f_3768(t2,t3);}
else{
t3=C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("setup-api.scm: 540  check-filelist");
f_3768(t2,t3);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4111,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 541  repo-path");
f_4705(t2,C_SCHEME_END_OF_LIST);}

/* k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4114,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 542  repo-path");
f_4705(t2,C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4114,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4117,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4122,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word)li60),tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_4122(t10,t6,((C_word*)t0)[2]);}

/* loop1050 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_4122(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4122,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4149,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word)li59),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4287,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
C_trace("g10661067");
t6=t3;
f_4149(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4285 in loop1050 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4287,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop10501063");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4122(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop10501063");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4122(t6,((C_word*)t0)[3],t5);}}

/* g1066 in loop1050 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_4149(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4149,NULL,3,t0,t1,t2);}
t3=C_i_pairp(t2);
t4=(C_truep(t3)?C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4156,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 545  make-dest-pathname");
f_3743(t5,((C_word*)t0)[2],t2);}

/* k4154 in g1066 in loop1050 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4159,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4249,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve2(lf[10],"setup-api#*windows*");
if(C_truep(C_retrieve2(lf[10],"setup-api#*windows*"))){
t5=t3;
f_4249(t5,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4278,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 547  pathname-extension");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t5,t1);}}

/* k4276 in k4154 in g1066 in loop1050 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4249(t2,C_i_equalp(lf[219],t1));}

/* k4247 in k4154 in g1066 in loop1050 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_4249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4249,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 548  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_4159(2,t2,C_SCHEME_UNDEFINED);}}

/* k4266 in k4247 in k4154 in g1066 in loop1050 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4268,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,C_retrieve2(lf[26],"setup-api#*remove-command*"),t2);
t4=C_a_i_list(&a,1,t3);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t4);}

/* k4157 in k4154 in g1066 in loop1050 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4162,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-api.scm: 549  copy-file");
((C_proc4)C_retrieve_symbol_proc(lf[187]))(4,*((C_word*)lf[187]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4160 in k4157 in k4154 in g1066 in loop1050 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve2(lf[8],"setup-api#*windows-shell*"))){
t3=t2;
f_4165(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4246,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 551  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t3,((C_word*)t0)[3]);}}

/* k4244 in k4160 in k4157 in k4154 in g1066 in loop1050 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4246,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[178],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[28],"setup-api#*chmod-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* k4163 in k4160 in k4157 in k4154 in g1066 in loop1050 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4165,2,t0,t1);}
t2=C_i_assq(lf[199],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4171,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4180,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4223,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 553  software-version");
((C_proc2)C_retrieve_symbol_proc(lf[218]))(2,*((C_word*)lf[218]+1),t5);}
else{
C_trace("setup-api.scm: 557  make-dest-pathname");
f_3743(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k4221 in k4163 in k4160 in k4157 in k4154 in g1066 in loop1050 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4223,2,t0,t1);}
t2=C_eqp(t1,lf[216]);
if(C_truep(t2)){
t3=C_i_cadr(((C_word*)t0)[5]);
if(C_truep(C_i_equalp(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4215,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 555  pathname-extension");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
f_4180(t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_4180(t3,C_SCHEME_FALSE);}}

/* k4213 in k4221 in k4163 in k4160 in k4157 in k4154 in g1066 in loop1050 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4180(t2,C_i_equalp(t1,lf[217]));}

/* k4178 in k4163 in k4160 in k4157 in k4154 in g1066 in loop1050 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_4180(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4180,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4199,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 556  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t2,((C_word*)t0)[5]);}
else{
C_trace("setup-api.scm: 557  make-dest-pathname");
f_3743(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4197 in k4178 in k4163 in k4160 in k4157 in k4154 in g1066 in loop1050 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4199,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,C_retrieve2(lf[29],"setup-api#*ranlib-command*"),t2);
t4=C_a_i_list(&a,1,t3);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t4);}

/* k4169 in k4163 in k4160 in k4157 in k4154 in g1066 in loop1050 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 557  make-dest-pathname");
f_3743(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4115 in k4112 in k4109 in k4106 in k4103 in k4097 in setup-api#install-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 559  write-info");
f_3391(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_3905r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3905r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3905r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3909,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4092,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),t5,lf[215],t4,t6);}

/* a4091 in setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4092,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k3907 in setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3912,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4089,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),t2,lf[214],((C_word*)t0)[2],t3);}

/* a4088 in k3907 in setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4089,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* k3910 in k3907 in setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 519  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),t2,((C_word*)t0)[3]);}

/* k3913 in k3910 in k3907 in setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3918,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-api.scm: 520  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[85]))(5,*((C_word*)lf[85]+1),t2,C_SCHEME_FALSE,t1,lf[213]);}

/* k3916 in k3913 in k3910 in k3907 in setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3921,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm: 521  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[85]))(5,*((C_word*)lf[85]+1),t2,C_SCHEME_FALSE,((C_word*)t0)[2],lf[212]);}

/* k3919 in k3916 in k3913 in k3910 in k3907 in setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3924,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[209],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=C_a_i_cons(&a,2,lf[210],t5);
t7=C_a_i_cons(&a,2,lf[205],t6);
t8=C_a_i_cons(&a,2,lf[206],t7);
t9=C_a_i_cons(&a,2,lf[207],t8);
t10=C_a_i_list(&a,1,t9);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),t2,t10);}

/* k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[40],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[208],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=C_a_i_cons(&a,2,lf[209],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=C_a_i_cons(&a,2,lf[210],t7);
t9=C_a_i_cons(&a,2,lf[205],t8);
t10=C_a_i_cons(&a,2,lf[211],t9);
t11=C_a_i_cons(&a,2,lf[207],t10);
t12=C_a_i_list(&a,1,t11);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),t2,t12);}
else{
t3=t2;
f_3927(2,t3,C_SCHEME_UNDEFINED);}}

/* k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[204],t3);
t5=C_a_i_cons(&a,2,lf[205],t4);
t6=C_a_i_cons(&a,2,lf[206],t5);
t7=C_a_i_cons(&a,2,lf[207],t6);
t8=C_a_i_list(&a,1,t7);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),t2,t8);}

/* k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("setup-api.scm: 528  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[89]))(4,*((C_word*)lf[89]+1),t2,((C_word*)t0)[4],lf[203]);}

/* k3978 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3984,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
C_trace("setup-api.scm: 529  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[89]))(4,*((C_word*)lf[89]+1),t2,((C_word*)t0)[2],lf[202]);}

/* k3982 in k3978 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("setup-api.scm: 530  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[85]))(5,*((C_word*)lf[85]+1),t2,C_SCHEME_FALSE,((C_word*)t0)[2],lf[201]);}

/* k3986 in k3982 in k3978 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3988,2,t0,t1);}
t2=C_a_i_list(&a,3,((C_word*)t0)[9],((C_word*)t0)[8],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[197],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3949,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3953,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3972,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 533  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[85]))(5,*((C_word*)lf[85]+1),t7,C_SCHEME_FALSE,((C_word*)t0)[2],lf[200]);}
else{
C_trace("##sys#append");
t7=*((C_word*)lf[186]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* k3970 in k3986 in k3982 in k3978 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[199],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
C_trace("##sys#append");
t5=*((C_word*)lf[186]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t4,C_SCHEME_END_OF_LIST);}

/* k3951 in k3986 in k3982 in k3978 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[186]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3947 in k3986 in k3982 in k3978 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in setup-api#standard-extension in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3949,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
C_trace("setup-api.scm: 526  install-extension");
((C_proc5)C_retrieve_symbol_proc(lf[198]))(5,*((C_word*)lf[198]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* setup-api#check-filelist in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_3768(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3768,NULL,2,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3774,a[2]=t4,a[3]=t8,a[4]=t6,a[5]=((C_word)li54),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3774(t10,t1,t2);}

/* loop914 in setup-api#check-filelist in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_3774(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3774,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3784,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3846,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_slot(t2,C_fix(0));
if(C_truep(C_i_stringp(t5))){
t6=t3;
f_3784(t6,C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST));}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3814,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(t5))){
C_trace("setup-api.scm: 502  every");
((C_proc4)C_retrieve_symbol_proc(lf[158]))(4,*((C_word*)lf[158]+1),t6,*((C_word*)lf[159]+1),t5);}
else{
t7=t6;
f_3814(2,t7,C_SCHEME_FALSE);}}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3812 in loop914 in setup-api#check-filelist in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3814,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3784(t2,C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3817,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t3=C_i_car(((C_word*)t0)[3]);
t4=C_i_cdr(((C_word*)t0)[3]);
t5=t2;
f_3817(t5,C_a_i_list(&a,2,t3,t4));}
else{
t3=t2;
f_3817(t3,C_SCHEME_FALSE);}}}

/* k3815 in k3812 in loop914 in setup-api#check-filelist in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_3817(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3817,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[4];
f_3784(t3,C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}
else{
C_trace("setup-api.scm: 504  error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[116]+1)))(4,*((C_word*)lf[116]+1),((C_word*)t0)[3],lf[195],((C_word*)t0)[2]);}}

/* k3844 in loop914 in setup-api#check-filelist in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3846,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3784(t2,C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST));}

/* k3782 in loop914 in setup-api#check-filelist in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_3784(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop914927");
t5=((C_word*)((C_word*)t0)[4])[1];
f_3774(t5,((C_word*)t0)[3],t4);}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop914927");
t5=((C_word*)((C_word*)t0)[4])[1];
f_3774(t5,((C_word*)t0)[3],t4);}}

/* setup-api#make-dest-pathname in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_3743(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3743,NULL,3,t1,t2,t3);}
if(C_truep(C_i_listp(t3))){
t4=C_i_cadr(t3);
C_trace("setup-api.scm: 494  make-dest-pathname");
t7=t1;
t8=t2;
t9=t4;
t1=t7;
t2=t8;
t3=t9;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3763,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 495  absolute-pathname?");
((C_proc3)C_retrieve_symbol_proc(lf[189]))(3,*((C_word*)lf[189]+1),t4,t3);}}

/* k3761 in setup-api#make-dest-pathname in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
C_trace("setup-api.scm: 497  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* setup-api#remove-file* in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3721,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3741,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 490  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t3,t2);}

/* k3739 in setup-api#remove-file* in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3741,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,C_retrieve2(lf[26],"setup-api#*remove-command*"),t2);
t4=C_a_i_list(&a,1,t3);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t4);}

/* setup-api#move-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3666,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_car(t2):t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3673,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t2))){
t7=C_i_cadr(t2);
C_trace("setup-api.scm: 485  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),t6,t3,t7);}
else{
t7=t6;
f_3673(2,t7,t3);}}

/* k3671 in setup-api#move-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3676,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 486  ensure-directory");
f_4777(t2,t1);}

/* k3674 in k3671 in setup-api#move-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3695,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 487  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t2,((C_word*)t0)[2]);}

/* k3693 in k3674 in k3671 in setup-api#move-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3703,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 487  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t2,((C_word*)t0)[2]);}

/* k3701 in k3693 in k3674 in k3671 in setup-api#move-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3703,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[27],"setup-api#*move-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* setup-api#copy-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_3520r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3520r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3520r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3522,a[2]=t3,a[3]=t2,a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3595,a[2]=t5,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3604,a[2]=t6,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
C_trace("def-err857879");
t8=t7;
f_3604(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
C_trace("def-prefix858877");
t10=t6;
f_3595(t10,t1);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
C_trace("body855863");
t12=t5;
f_3522(t12,t1,t10);}
else{
C_trace("##sys#error");
t12=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-err857 in setup-api#copy-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_3604(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3604,NULL,2,t0,t1);}
C_trace("def-prefix858877");
t2=((C_word*)t0)[2];
f_3595(t2,t1);}

/* def-prefix858 in setup-api#copy-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_3595(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3595,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3603,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 465  installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[171]))(2,*((C_word*)lf[171]+1),t2);}

/* k3601 in def-prefix858 in setup-api#copy-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("body855863");
t2=((C_word*)t0)[3];
f_3522(t2,((C_word*)t0)[2],t1);}

/* body855 in setup-api#copy-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_3522(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3522,NULL,3,t0,t1,t2);}
t3=C_i_pairp(((C_word*)t0)[3]);
t4=(C_truep(t3)?C_i_car(((C_word*)t0)[3]):((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3529,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t6=C_i_cadr(((C_word*)t0)[3]);
C_trace("setup-api.scm: 468  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),t5,((C_word*)t0)[2],t6);}
else{
t6=t5;
f_3529(2,t6,((C_word*)t0)[2]);}}

/* k3527 in body855 in setup-api#copy-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3578,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
t5=t1;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3660,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 480  normalize-pathname");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t6,t4);}

/* k3658 in k3527 in body855 in setup-api#copy-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3664,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 481  normalize-pathname");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t2,((C_word*)t0)[2]);}

/* k3662 in k3658 in k3527 in body855 in setup-api#copy-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 479  string-prefix?");
((C_proc4)C_retrieve_symbol_proc(lf[190]))(4,*((C_word*)lf[190]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3576 in k3527 in body855 in setup-api#copy-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3578,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3532(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 470  absolute-pathname?");
((C_proc3)C_retrieve_symbol_proc(lf[189]))(3,*((C_word*)lf[189]+1),t2,((C_word*)t0)[3]);}}

/* k3569 in k3576 in k3527 in body855 in setup-api#copy-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
f_3532(2,t3,t2);}
else{
C_trace("setup-api.scm: 472  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k3530 in k3527 in body855 in setup-api#copy-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3535,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 474  ensure-directory");
f_4777(t2,t1);}

/* k3533 in k3530 in k3527 in body855 in setup-api#copy-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3538,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3554,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 475  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t3,((C_word*)t0)[2]);}

/* k3552 in k3533 in k3530 in k3527 in body855 in setup-api#copy-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3562,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 475  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t2,((C_word*)t0)[2]);}

/* k3560 in k3552 in k3533 in k3530 in k3527 in body855 in setup-api#copy-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3562,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[25],"setup-api#*copy-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* k3536 in k3533 in k3530 in k3527 in body855 in setup-api#copy-file in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_3391(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3391,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3518,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t6=*((C_word*)lf[186]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,C_SCHEME_END_OF_LIST);}

/* k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3518,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[177],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3514,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t4=*((C_word*)lf[186]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3514,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3398,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3488,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 455  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t4);}

/* k3486 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3488,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[54]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t3,lf[185],t2);}
else{
t2=((C_word*)t0)[4];
f_3398(2,t2,C_SCHEME_UNDEFINED);}}

/* k3489 in k3486 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3494,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k3492 in k3489 in k3486 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3497,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[184],((C_word*)t0)[3]);}

/* k3495 in k3492 in k3489 in k3486 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3500,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3498 in k3495 in k3492 in k3489 in k3486 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[183],((C_word*)t0)[2]);}

/* k3501 in k3498 in k3495 in k3492 in k3489 in k3486 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k3396 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3401,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 456  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),t2,((C_word*)t0)[2]);}

/* k3399 in k3396 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3485,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 457  repo-path");
f_4705(t3,C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k3483 in k3399 in k3396 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3485,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=C_a_i_list(&a,1,t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3320,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
C_trace("setup-api.scm: 427  repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[181]))(2,*((C_word*)lf[181]+1),t4);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=C_i_car(t3);
C_trace("setup-api.scm: 428  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[85]))(5,*((C_word*)lf[85]+1),((C_word*)t0)[2],t6,t2,lf[180]);}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3318 in k3483 in k3399 in k3396 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 428  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[85]))(5,*((C_word*)lf[85]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[180]);}

/* k3402 in k3399 in k3396 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3407,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"setup-api#*sudo*"))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3436,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 459  create-temporary-file");
((C_proc2)C_retrieve_symbol_proc(lf[78]))(2,*((C_word*)lf[78]+1),t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3477,a[2]=((C_word*)t0)[2],a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 462  with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),t2,t1,t3);}}

/* a3476 in k3402 in k3399 in k3396 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3477,2,t0,t1);}
t2=C_retrieve(lf[179]);
C_trace("g828829");
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[2]);}

/* k3434 in k3402 in k3399 in k3396 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3439,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3468,a[2]=((C_word*)t0)[2],a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 460  with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),t2,t1,t3);}

/* a3467 in k3434 in k3402 in k3399 in k3396 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3468,2,t0,t1);}
t2=C_retrieve(lf[179]);
C_trace("g815816");
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[2]);}

/* k3437 in k3434 in k3402 in k3399 in k3396 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3458,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 461  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t2,((C_word*)t0)[2]);}

/* k3456 in k3437 in k3434 in k3402 in k3399 in k3396 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3466,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 461  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t2,((C_word*)t0)[2]);}

/* k3464 in k3456 in k3437 in k3434 in k3402 in k3399 in k3396 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3466,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[27],"setup-api#*move-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* k3405 in k3402 in k3399 in k3396 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3407,2,t0,t1);}
if(C_truep(C_retrieve2(lf[8],"setup-api#*windows-shell*"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3433,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 463  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t2,((C_word*)t0)[2]);}}

/* k3431 in k3405 in k3402 in k3399 in k3396 in k3512 in k3516 in setup-api#write-info in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3433,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[178],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[28],"setup-api#*chmod-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* f_5895 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5895(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5895,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5899,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 449  verb");
f_3367(t3,t2);}

/* k5897 */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5922,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 450  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t2,((C_word*)t0)[2]);}

/* k5920 in k5897 */
static void C_ccall f_5922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5922,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[174],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[30],"setup-api#*mkdir-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* f_5887 in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_5887(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5887,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5891,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 446  verb");
f_3367(t3,t2);}

/* k5889 */
static void C_ccall f_5891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 447  create-directory");
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* verb in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_3367(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3367,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3374,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 442  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t3);}

/* k3372 in verb in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3374,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[54]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3377,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t3,lf[172],t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3375 in k3372 in verb in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3380,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3378 in k3375 in k3372 in verb in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k3381 in k3378 in k3375 in k3372 in verb in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#flush-output");
((C_proc3)C_retrieve_symbol_proc(lf[95]))(3,*((C_word*)lf[95]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#installation-prefix in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3358,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 435  destination-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[170]))(2,*((C_word*)lf[170]+1),t2);}

/* k3356 in setup-api#installation-prefix in k3351 in k3347 in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[2])?((C_word*)t0)[2]:C_retrieve(lf[13])));}}

/* setup-api#make/proc in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3273(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3273r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3273r(t0,t1,t2,t3);}}

static void C_ccall f_3273r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(4);
t4=C_i_length(t3);
switch(t4){
case C_fix(0):
t5=t2;
C_trace("setup-api.scm: 386  make:make/proc/helper");
f_2852(t1,t5,C_SCHEME_END_OF_LIST);
case C_fix(1):
t5=t2;
t6=C_i_car(t3);
t7=C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3305,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_vectorp(t6))){
C_trace("setup-api.scm: 391  vector->list");
((C_proc3)C_retrieve_proc(*((C_word*)lf[167]+1)))(3,*((C_word*)lf[167]+1),t8,t6);}
else{
C_trace("setup-api.scm: 388  make:make/proc/helper");
f_2852(t1,t5,t6);}
default:
C_trace("##sys#error");
t5=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[169]);}}

/* k3303 in setup-api#make/proc in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 388  make:make/proc/helper");
f_2852(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_2852(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2852,NULL,3,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2856,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_vectorp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3271,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 320  vector->list");
((C_proc3)C_retrieve_proc(*((C_word*)lf[167]+1)))(3,*((C_word*)lf[167]+1),t6,((C_word*)t4)[1]);}
else{
t6=t5;
f_2856(t6,C_SCHEME_UNDEFINED);}}

/* k3269 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2856(t3,t2);}

/* k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_2856(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2856,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=C_i_listp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2684,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_2684(2,t6,t4);}
else{
C_trace("setup-api.scm: 292  make:form-error");
f_2624(t5,lf[166],t3);}}

/* k2682 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2684,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_pairp(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2693,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_2693(2,t4,t2);}
else{
C_trace("setup-api.scm: 293  make:form-error");
f_2624(t3,lf[165],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[2];
f_2859(2,t2,C_SCHEME_FALSE);}}

/* k2691 in k2682 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2693,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2698,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 294  every");
((C_proc4)C_retrieve_symbol_proc(lf[158]))(4,*((C_word*)lf[158]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2859(2,t2,C_SCHEME_FALSE);}}

/* a2697 in k2691 in k2682 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2698,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2705,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_listp(t2))){
t4=C_i_length(t2);
C_trace("setup-api.scm: 296  <=");
C_less_or_equal_p(5,0,t3,C_fix(2),t4,C_fix(3));}
else{
t4=t3;
f_2705(2,t4,C_SCHEME_FALSE);}}

/* k2703 in a2697 in k2691 in k2682 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2708(2,t3,t1);}
else{
C_trace("setup-api.scm: 297  make:form-error");
f_2624(t2,lf[164],((C_word*)t0)[3]);}}

/* k2706 in k2703 in a2697 in k2691 in k2682 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2708,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[3]);
t3=C_i_stringp(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2717(2,t5,t3);}
else{
t5=C_i_car(((C_word*)t0)[3]);
if(C_truep(C_i_listp(t5))){
t6=C_i_car(((C_word*)t0)[3]);
C_trace("setup-api.scm: 300  every");
((C_proc4)C_retrieve_symbol_proc(lf[158]))(4,*((C_word*)lf[158]+1),t4,*((C_word*)lf[159]+1),t6);}
else{
t6=t4;
f_2717(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2715 in k2706 in k2703 in a2697 in k2691 in k2682 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2720(2,t3,t1);}
else{
C_trace("setup-api.scm: 301  make:form-error");
f_2624(t2,lf[163],((C_word*)t0)[3]);}}

/* k2718 in k2715 in k2706 in k2703 in a2697 in k2691 in k2682 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2720,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[3]);
t3=C_i_cadr(((C_word*)t0)[3]);
t4=C_i_listp(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2729,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_2729(2,t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2759,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cadr(((C_word*)t0)[3]);
C_trace("setup-api.scm: 304  make:line-error");
f_2646(t6,lf[162],t7,t2);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2757 in k2718 in k2715 in k2706 in k2703 in a2697 in k2691 in k2682 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2759,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_2729(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2767,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
C_trace("setup-api.scm: 305  every");
((C_proc4)C_retrieve_symbol_proc(lf[158]))(4,*((C_word*)lf[158]+1),((C_word*)t0)[3],t2,t3);}}

/* a2766 in k2757 in k2718 in k2715 in k2706 in k2703 in a2697 in k2691 in k2682 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2767,3,t0,t1,t2);}
t3=C_i_stringp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
C_trace("setup-api.scm: 307  make:form-error");
f_2624(t1,lf[161],t2);}}

/* k2727 in k2718 in k2715 in k2706 in k2703 in a2697 in k2691 in k2682 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_i_cddr(((C_word*)t0)[4]);
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_i_caddr(((C_word*)t0)[4]);
t5=C_i_closurep(t4);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_i_caddr(((C_word*)t0)[4]);
C_trace("setup-api.scm: 311  make:line-error");
f_2646(((C_word*)t0)[3],lf[160],t6,((C_word*)t0)[2]);}}}

/* k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
t4=C_i_stringp(t3);
if(C_truep(t4)){
t5=t2;
f_2862(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2844,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 316  every");
((C_proc4)C_retrieve_symbol_proc(lf[158]))(4,*((C_word*)lf[158]+1),t5,*((C_word*)lf[159]+1),t3);}}

/* k2842 in k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2862(2,t2,t1);}
else{
C_trace("setup-api.scm: 317  error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[116]+1)))(4,*((C_word*)lf[116]+1),((C_word*)t0)[3],lf[157],((C_word*)t0)[2]);}}

/* k2860 in k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2862,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t9,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm: 324  condition-predicate");
((C_proc3)C_retrieve_symbol_proc(lf[156]))(3,*((C_word*)lf[156]+1),t11,lf[154]);}

/* k2865 in k2860 in k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2867,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm: 325  condition-property-accessor");
((C_proc4)C_retrieve_symbol_proc(lf[153]))(4,*((C_word*)lf[153]+1),t3,lf[154],lf[155]);}

/* k2869 in k2865 in k2860 in k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2871,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2873,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word)li32),tmp=(C_word)a,a+=8,tmp));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3167,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_stringp(((C_word*)((C_word*)t0)[2])[1]))){
C_trace("setup-api.scm: 376  make-file");
t5=((C_word*)((C_word*)t0)[7])[1];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)((C_word*)t0)[2])[1],lf[149]);}
else{
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3233,a[2]=t4,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 377  caar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[151]+1)))(3,*((C_word*)lf[151]+1),t5,((C_word*)t0)[4]);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3238,a[2]=t6,a[3]=((C_word*)t0)[7],a[4]=((C_word)li35),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3238(t8,t4,((C_word*)((C_word*)t0)[2])[1]);}}}

/* loop625 in k2869 in k2865 in k2860 in k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_3238(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3238,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3246,a[2]=((C_word*)t0)[3],a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3253,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
C_trace("g632633");
t6=t3;
f_3246(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3251 in loop625 in k2869 in k2865 in k2860 in k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3238(t3,((C_word*)t0)[2],t2);}

/* g632 in loop625 in k2869 in k2865 in k2860 in k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_3246(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3246,NULL,3,t0,t1,t2);}
C_trace("setup-api.scm: 378  make-file");
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[152]);}

/* k3231 in k2869 in k2865 in k2860 in k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 377  make-file");
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[150]);}

/* k3165 in k2869 in k2865 in k2860 in k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 379  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t2);}

/* k3171 in k3165 in k2869 in k2865 in k2860 in k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3173,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3180,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 382  reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[148]+1)))(3,*((C_word*)lf[148]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3178 in k3171 in k3165 in k2869 in k2865 in k2860 in k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3180,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3182,a[2]=t3,a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3182(t5,((C_word*)t0)[2],t1);}

/* loop641 in k3178 in k3171 in k3165 in k2869 in k2865 in k2860 in k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_3182(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3182,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3203,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[54]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3194,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t6,lf[147],t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3192 in loop641 in k3178 in k3171 in k3165 in k2869 in k2865 in k2860 in k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3197,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3195 in k3192 in loop641 in k3178 in k3171 in k3165 in k2869 in k2865 in k2860 in k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k3201 in loop641 in k3178 in k3171 in k3165 in k2869 in k2865 in k2860 in k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_3203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3182(t3,((C_word*)t0)[2],t2);}

/* f_2873 in k2869 in k2865 in k2860 in k2857 in k2854 in setup-api#make:make/proc/helper in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2873,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2877,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=t2;
t6=((C_word*)t0)[2];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2570,a[2]=t5,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2579,a[2]=t7,a[3]=t9,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2579(t11,t4,t6);}

/* loop */
static void C_fcall f_2579(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2579,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=C_i_car(t3);
if(C_truep(C_i_stringp(t5))){
t6=C_i_car(t3);
t7=t4;
f_2592(t7,C_a_i_list(&a,1,t6));}
else{
t6=t4;
f_2592(t6,C_i_car(t3));}}}

/* k2590 in loop */
static void C_fcall f_2592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2592,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 284  any");
((C_proc4)C_retrieve_symbol_proc(lf[141]))(4,*((C_word*)lf[141]+1),t2,((C_word*)t0)[2],t1);}

/* k2596 in k2590 in loop */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
C_trace("setup-api.scm: 286  loop");
t3=((C_word*)((C_word*)t0)[2])[1];
f_2579(t3,((C_word*)t0)[5],t2);}}

/* match? */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2570,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_string_equal_p(t2,((C_word*)t0)[2]));}

/* k2875 */
static void C_ccall f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
C_trace("setup-api.scm: 329  fixmaketarget");
f_2391(t2,((C_word*)t0)[7]);}

/* k2878 in k2875 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3161,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 330  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[140]))(3,*((C_word*)lf[140]+1),t3,t1);}

/* k3159 in k2878 in k2875 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-api.scm: 331  file-modification-time");
((C_proc3)C_retrieve_symbol_proc(lf[137]))(3,*((C_word*)lf[137]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2883(2,t2,C_SCHEME_FALSE);}}

/* k2881 in k2878 in k2875 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3143,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 332  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t3);}

/* k3141 in k2881 in k2878 in k2875 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3143,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[54]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t3,lf[146],t2);}
else{
t2=((C_word*)t0)[4];
f_2886(2,t2,C_SCHEME_UNDEFINED);}}

/* k3144 in k3141 in k2881 in k2878 in k2875 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3149,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k3147 in k3144 in k3141 in k2881 in k2878 in k2875 */
static void C_ccall f_3149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[145],((C_word*)t0)[3]);}

/* k3150 in k3147 in k3144 in k3141 in k2881 in k2878 in k2875 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3155,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3153 in k3150 in k3147 in k3144 in k3141 in k2881 in k2878 in k2875 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2886,2,t0,t1);}
if(C_truep(((C_word*)t0)[11])){
t2=C_i_cadr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2895,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3116,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 336  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[128]+1)))(4,*((C_word*)lf[128]+1),t4,lf[143],((C_word*)t0)[3]);}
else{
if(C_truep(((C_word*)t0)[10])){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3131,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[77]))(2,*((C_word*)lf[77]+1),t2);}}}

/* k3129 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3134,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[144],t1);}

/* k3132 in k3129 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3137,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3135 in k3132 in k3129 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3140,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,((C_word*)t0)[2]);}

/* k3138 in k3135 in k3132 in k3129 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 374  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],t1);}

/* k3114 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3117,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li29),tmp=(C_word)a,a+=5,tmp);
C_trace("for-each");
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a3113 in k3114 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3117,3,t0,t1,t2);}
C_trace("setup-api.scm: 337  make-file");
t3=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2895,2,t0,t1);}
t2=C_i_not(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2901,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_2901(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3070,a[2]=((C_word*)t0)[11],a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 341  any");
((C_proc4)C_retrieve_symbol_proc(lf[141]))(4,*((C_word*)lf[141]+1),t3,t4,((C_word*)t0)[2]);}}

/* a3069 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3070,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3074,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 342  fixmaketarget");
f_2391(t3,t2);}

/* k3072 in a3069 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3077,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3090,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 343  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[140]))(3,*((C_word*)lf[140]+1),t3,t1);}

/* k3088 in k3072 in a3069 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3090,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_3077(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3097,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[77]))(2,*((C_word*)lf[77]+1),t2);}}

/* k3095 in k3088 in k3072 in a3069 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3100,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[139],t1);}

/* k3098 in k3095 in k3088 in k3072 in a3069 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3103,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3101 in k3098 in k3095 in k3088 in k3072 in a3069 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[138],((C_word*)t0)[2]);}

/* k3104 in k3101 in k3098 in k3095 in k3088 in k3072 in a3069 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k3107 in k3104 in k3101 in k3098 in k3095 in k3088 in k3072 in a3069 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3112,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,((C_word*)t0)[2]);}

/* k3110 in k3107 in k3104 in k3101 in k3098 in k3095 in k3088 in k3072 in a3069 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 344  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],t1);}

/* k3075 in k3072 in a3069 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 345  file-modification-time");
((C_proc3)C_retrieve_symbol_proc(lf[137]))(3,*((C_word*)lf[137]+1),t2,((C_word*)t0)[3]);}

/* k3085 in k3075 in k3072 in a3069 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_greaterp(t1,((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2901,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cddr(((C_word*)t0)[10]);
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2920,a[2]=t2,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 352  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t6);}}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3001 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3003,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[54]+1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t3,lf[136],t2);}
else{
t2=((C_word*)t0)[6];
f_2920(2,t2,C_SCHEME_UNDEFINED);}}

/* k3004 in k3001 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k3007 in k3004 in k3001 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[135],((C_word*)t0)[5]);}

/* k3010 in k3007 in k3004 in k3001 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k3013 in k3010 in k3007 in k3004 in k3001 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3018,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3025,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
if(C_truep(t4)){
if(C_truep(C_i_stringp(((C_word*)t0)[3]))){
C_trace("setup-api.scm: 360  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[128]+1)))(5,*((C_word*)lf[128]+1),t3,lf[129],((C_word*)t0)[3],lf[130]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3047,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[77]))(2,*((C_word*)lf[77]+1),t5);}}
else{
C_trace("setup-api.scm: 358  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[128]+1)))(5,*((C_word*)lf[128]+1),t3,lf[133],((C_word*)t0)[2],lf[134]);}}

/* k3045 in k3013 in k3010 in k3007 in k3004 in k3001 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[132],t1);}

/* k3048 in k3045 in k3013 in k3010 in k3007 in k3004 in k3001 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3053,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k3051 in k3048 in k3045 in k3013 in k3010 in k3007 in k3004 in k3001 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[131],((C_word*)t0)[3]);}

/* k3054 in k3051 in k3048 in k3045 in k3013 in k3010 in k3007 in k3004 in k3001 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3057 in k3054 in k3051 in k3048 in k3045 in k3013 in k3010 in k3007 in k3004 in k3001 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(41),((C_word*)t0)[2]);}

/* k3060 in k3057 in k3054 in k3051 in k3048 in k3045 in k3013 in k3010 in k3007 in k3004 in k3001 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3065,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,((C_word*)t0)[2]);}

/* k3063 in k3060 in k3057 in k3054 in k3051 in k3048 in k3045 in k3013 in k3010 in k3007 in k3004 in k3001 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 362  string-append");
((C_proc3)C_retrieve_proc(*((C_word*)lf[128]+1)))(3,*((C_word*)lf[128]+1),((C_word*)t0)[2],t1);}

/* k3023 in k3013 in k3010 in k3007 in k3004 in k3001 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3016 in k3013 in k3010 in k3007 in k3004 in k3001 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_3018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k2918 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2923,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li27),tmp=(C_word)a,a+=7,tmp);
C_trace("call-with-current-continuation");
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t2,t3);}

/* a2927 in k2918 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2928,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2934,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li22),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2975,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li26),tmp=(C_word)a,a+=5,tmp);
C_trace("with-exception-handler");
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),t1,t3,t4);}

/* a2974 in a2927 in k2918 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2981,a[2]=((C_word*)t0)[3],a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2990,a[2]=((C_word*)t0)[2],a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a2989 in a2974 in a2927 in k2918 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2990r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2990r(t0,t1,t2);}}

static void C_ccall f_2990r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2996,a[2]=t2,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
C_trace("k586591");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2995 in a2989 in a2974 in a2927 in k2918 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2996,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2980 in a2974 in a2927 in k2918 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2981,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
C_trace("g601602");
t3=t2;
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* a2933 in a2927 in k2918 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2934,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2940,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li21),tmp=(C_word)a,a+=7,tmp);
C_trace("k586591");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2939 in a2933 in a2927 in k2918 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2940,2,t0,t1);}
t2=*((C_word*)lf[54]+1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t3,lf[125],t2);}

/* k2942 in a2939 in a2933 in a2927 in k2918 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[2]);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,t3,((C_word*)t0)[5]);}

/* k2945 in k2942 in a2939 in a2933 in a2927 in k2918 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[124],((C_word*)t0)[4]);}

/* k2948 in k2945 in k2942 in a2939 in a2933 in a2927 in k2918 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2953,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2963,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2966,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 368  exn?");
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}

/* k2964 in k2948 in k2945 in k2942 in a2939 in a2933 in a2927 in k2918 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
C_trace("setup-api.scm: 369  exn-message");
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[4];
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* k2961 in k2948 in k2945 in k2942 in a2939 in a2933 in a2927 in k2918 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2951 in k2948 in k2945 in k2942 in a2939 in a2933 in a2927 in k2918 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k2954 in k2951 in k2948 in k2945 in k2942 in a2939 in a2933 in a2927 in k2918 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 371  signal");
((C_proc3)C_retrieve_symbol_proc(lf[123]))(3,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2921 in k2918 in k2899 in k2893 in k2884 in k2881 in k2878 in k2875 */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("g589590");
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* setup-api#make:line-error in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_2646(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2646,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2654,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[77]))(2,*((C_word*)lf[77]+1),t5);}

/* k2652 in setup-api#make:line-error in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],t1);}

/* k2655 in k2652 in setup-api#make:line-error in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[121],((C_word*)t0)[4]);}

/* k2658 in k2655 in k2652 in setup-api#make:line-error in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2663,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2661 in k2658 in k2655 in k2652 in setup-api#make:line-error in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[120],((C_word*)t0)[3]);}

/* k2664 in k2661 in k2658 in k2655 in k2652 in setup-api#make:line-error in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2669,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2667 in k2664 in k2661 in k2658 in k2655 in k2652 in setup-api#make:line-error in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,((C_word*)t0)[2]);}

/* k2670 in k2667 in k2664 in k2661 in k2658 in k2655 in k2652 in setup-api#make:line-error in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 289  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],t1);}

/* setup-api#make:form-error in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_2624(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2624,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2632,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[77]))(2,*((C_word*)lf[77]+1),t4);}

/* k2630 in setup-api#make:form-error in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2635,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],t1);}

/* k2633 in k2630 in setup-api#make:form-error in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[118],((C_word*)t0)[3]);}

/* k2636 in k2633 in k2630 in setup-api#make:form-error in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2639 in k2636 in k2633 in k2630 in setup-api#make:form-error in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2644,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,((C_word*)t0)[2]);}

/* k2642 in k2639 in k2636 in k2633 in k2630 in setup-api#make:form-error in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 288  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],t1);}

/* setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2417(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2417,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2485,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2533,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word)li17),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2533(t11,t7,t2);}

/* loop287 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_2533(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2533,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2562,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2424,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2445,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_2445(t13,t9,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* loop248 in loop287 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_2445(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2445,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[84]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2474,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
C_trace("g264265");
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2472 in loop248 in loop287 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2474,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop248261");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2445(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop248261");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2445(t6,((C_word*)t0)[3],t5);}}

/* k2422 in loop287 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2435,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(t1);
if(C_truep(C_i_string_equal_p(t3,lf[99]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2340,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2344,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2386,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 234  find-program");
((C_proc3)C_retrieve_symbol_proc(lf[87]))(3,*((C_word*)lf[87]+1),t6,lf[114]);}
else{
C_trace("setup-api.scm: 244  find-program");
((C_proc3)C_retrieve_symbol_proc(lf[87]))(3,*((C_word*)lf[87]+1),t2,t3);}}

/* k2384 in k2422 in loop287 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 234  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],t1);}

/* k2342 in k2422 in loop287 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2348,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2375,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 236  feature?");
((C_proc3)C_retrieve_symbol_proc(lf[112]))(3,*((C_word*)lf[112]+1),t3,lf[113]);}

/* k2373 in k2342 in k2422 in loop287 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2375,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2382,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 237  host-extension");
((C_proc2)C_retrieve_symbol_proc(lf[11]))(2,*((C_word*)lf[11]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_2348(t2,lf[110]);}}

/* k2380 in k2373 in k2342 in k2422 in loop287 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2348(t2,(C_truep(t1)?lf[110]:lf[111]));}

/* k2346 in k2342 in k2422 in loop287 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_2348(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2348,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2369,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 239  keep-intermediates");
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t2);}

/* k2367 in k2346 in k2342 in k2422 in loop287 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2369,2,t0,t1);}
t2=(C_truep(t1)?lf[101]:lf[102]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2366,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 240  host-extension");
((C_proc2)C_retrieve_symbol_proc(lf[11]))(2,*((C_word*)lf[11]+1),t3);}

/* k2364 in k2367 in k2346 in k2342 in k2422 in loop287 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2366,2,t0,t1);}
t2=(C_truep(t1)?lf[103]:lf[104]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2363,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 241  deployment-mode");
((C_proc2)C_retrieve_symbol_proc(lf[22]))(2,*((C_word*)lf[22]+1),t3);}

/* k2361 in k2364 in k2367 in k2346 in k2342 in k2422 in loop287 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-api.scm: 233  cons*");
((C_proc10)C_retrieve_symbol_proc(lf[105]))(10,*((C_word*)lf[105]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[106],lf[107],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[108],C_SCHEME_END_OF_LIST);}
else{
C_trace("setup-api.scm: 233  cons*");
((C_proc10)C_retrieve_symbol_proc(lf[105]))(10,*((C_word*)lf[105]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[106],lf[107],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[109],C_SCHEME_END_OF_LIST);}}

/* k2338 in k2422 in loop287 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 232  string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[97]))(4,*((C_word*)lf[97]+1),((C_word*)t0)[2],t1,lf[100]);}

/* k2433 in k2422 in loop287 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2435,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t1,t2);
C_trace("setup-api.scm: 255  string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[97]))(4,*((C_word*)lf[97]+1),((C_word*)t0)[2],t3,lf[98]);}

/* k2560 in loop287 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2562,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop287300");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2533(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop287300");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2533(t6,((C_word*)t0)[3],t5);}}

/* k2483 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2485,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2487,a[2]=t3,a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2487(t5,((C_word*)t0)[2],t1);}

/* loop238 in k2483 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_2487(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2487,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2520,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2499,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2505,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 258  run-verbose");
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),t6);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2503 in loop238 in k2483 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2505,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[54]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2508,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t3,lf[96],t2);}
else{
C_trace("setup-api.scm: 259  $system");
f_5776(((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k2506 in k2503 in loop238 in k2483 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2511,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2509 in k2506 in k2503 in loop238 in k2483 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k2512 in k2509 in k2506 in k2503 in loop238 in k2483 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#flush-output");
((C_proc3)C_retrieve_symbol_proc(lf[95]))(3,*((C_word*)lf[95]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2497 in loop238 in k2483 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 259  $system");
f_5776(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2518 in loop238 in k2483 in setup-api#execute in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2487(t3,((C_word*)t0)[2],t2);}

/* setup-api#fixmaketarget in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_2391(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2391,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2398,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2415,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 247  pathname-extension");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t4,t2);}

/* k2413 in setup-api#fixmaketarget in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_equalp(lf[91],t1))){
t2=C_i_string_equal_p(lf[92],C_retrieve(lf[90]));
t3=((C_word*)t0)[2];
f_2398(t3,C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_2398(t2,C_SCHEME_FALSE);}}

/* k2396 in setup-api#fixmaketarget in k2322 in k2319 in k2316 in k2313 in k2310 in k2307 in k2304 in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_2398(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
C_trace("setup-api.scm: 249  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[89]))(4,*((C_word*)lf[89]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_retrieve(lf[90]));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* reg in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_2295(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2295,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2303,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 221  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),t4,C_retrieve2(lf[12],"setup-api#*chicken-bin-path*"),t3);}

/* k2301 in reg in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 221  register-program");
((C_proc4)C_retrieve_symbol_proc(lf[82]))(4,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#find-program in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2276,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2280,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 213  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),t3,t2);}

/* k2278 in setup-api#find-program in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_assoc(t1,C_retrieve2(lf[9],"setup-api#*registered-programs*"));
if(C_truep(t2)){
t3=C_i_cdr(t2);
C_trace("setup-api.scm: 216  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],t3);}
else{
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* setup-api#register-program in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2236r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2236r(t0,t1,t2,t3);}}

static void C_ccall f_2236r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2240,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2258,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 208  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),t5,t2);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_2240(2,t6,C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2256 in setup-api#register-program in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 208  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),((C_word*)t0)[2],C_retrieve2(lf[12],"setup-api#*chicken-bin-path*"),t1);}

/* k2238 in setup-api#register-program in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2244,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2248,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 210  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),t3,((C_word*)t0)[2]);}

/* k2246 in k2238 in setup-api#register-program in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 210  alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[83]))(5,*((C_word*)lf[83]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],C_retrieve2(lf[9],"setup-api#*registered-programs*"));}

/* k2242 in k2238 in setup-api#register-program in k2232 in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[9] /* (set! setup-api#*registered-programs* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2117,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2121,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2218,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 188  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t6);}

/* k2216 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2218,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[54]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2221,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t3,lf[80],t2);}
else{
t2=((C_word*)t0)[3];
f_2121(2,t2,C_SCHEME_UNDEFINED);}}

/* k2219 in k2216 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2224,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2222 in k2219 in k2216 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[79],((C_word*)t0)[2]);}

/* k2225 in k2222 in k2219 in k2216 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
if(C_truep(C_i_listp(((C_word*)t0)[5]))){
t2=C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2136,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li9),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 190  with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),((C_word*)t0)[2],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2175,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 199  create-temporary-file");
((C_proc2)C_retrieve_symbol_proc(lf[78]))(2,*((C_word*)lf[78]+1),t2);}}

/* k2173 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2178,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list(&a,2,t1,t1);
C_trace("setup-api.scm: 200  patch");
((C_proc5)C_retrieve_symbol_proc(lf[70]))(5,*((C_word*)lf[70]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2176 in k2173 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[77]))(2,*((C_word*)lf[77]+1),t2);}

/* k2183 in k2176 in k2173 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,C_retrieve2(lf[27],"setup-api#*move-command*"),t1);}

/* k2186 in k2183 in k2176 in k2173 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k2189 in k2186 in k2183 in k2176 in k2173 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2194,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2211,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 202  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t3,((C_word*)t0)[2]);}

/* k2209 in k2189 in k2186 in k2183 in k2176 in k2173 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2192 in k2189 in k2186 in k2183 in k2176 in k2173 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k2195 in k2192 in k2189 in k2186 in k2183 in k2176 in k2173 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2200,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2207,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 203  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t3,((C_word*)t0)[2]);}

/* k2205 in k2195 in k2192 in k2189 in k2186 in k2183 in k2176 in k2173 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2198 in k2195 in k2192 in k2189 in k2186 in k2183 in k2176 in k2173 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2203,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,((C_word*)t0)[2]);}

/* k2201 in k2198 in k2195 in k2192 in k2189 in k2186 in k2183 in k2176 in k2173 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 201  $system");
f_5776(((C_word*)t0)[2],t1);}

/* a2135 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2136,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 192  with-input-from-file");
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t1,t2,t3);}

/* a2145 in a2135 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2146,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li7),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2152(t5,t1);}

/* loop in a2145 in a2135 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_2152(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2152,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2156,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 195  read-line");
((C_proc2)C_retrieve_symbol_proc(lf[63]))(2,*((C_word*)lf[63]+1),t2);}

/* k2154 in loop in a2145 in a2135 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2156,2,t0,t1);}
if(C_truep(C_eofp(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2165,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2172,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 197  string-substitute");
((C_proc6)C_retrieve_symbol_proc(lf[72]))(6,*((C_word*)lf[72]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE);}}

/* k2170 in k2154 in loop in a2145 in a2135 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 197  write-line");
((C_proc3)C_retrieve_symbol_proc(lf[71]))(3,*((C_word*)lf[71]+1),((C_word*)t0)[2],t1);}

/* k2163 in k2154 in loop in a2145 in a2135 in k2119 in setup-api#patch in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 198  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_2152(t2,((C_word*)t0)[2]);}

/* setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2019r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2019r(t0,t1,t2,t3);}}

static void C_ccall f_2019r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2023,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[67]))(4,*((C_word*)lf[67]+1),t4,lf[69],t3);}

/* k2021 in setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2026,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2111,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),t2,lf[68],((C_word*)t0)[2],t3);}

/* a2110 in k2021 in setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2111,2,t0,t1);}
C_trace("setup-api.scm: 172  abort-setup");
((C_proc2)C_retrieve_symbol_proc(lf[52]))(2,*((C_word*)lf[52]+1),t1);}

/* k2024 in k2021 in setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2026,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2031,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word)li4),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2031(t5,((C_word*)t0)[2]);}

/* loop in k2024 in k2021 in setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_2031(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2031,NULL,2,t0,t1);}
t2=*((C_word*)lf[54]+1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2035,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("write-char/port");
t4=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(10),t2);}

/* k2033 in loop in k2024 in k2021 in setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2038,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2036 in k2033 in loop in k2024 in k2021 in setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2041,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[66],((C_word*)t0)[2]);}

/* k2039 in k2036 in k2033 in loop in k2024 in k2021 in setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=*((C_word*)lf[54]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2103,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t5=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(91),t3);}
else{
t3=t2;
f_2044(2,t3,C_SCHEME_UNDEFINED);}}

/* k2101 in k2039 in k2036 in k2033 in loop in k2024 in k2021 in setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2106,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2104 in k2101 in k2039 in k2036 in k2033 in loop in k2024 in k2021 in setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),((C_word*)t0)[3],lf[65],((C_word*)t0)[2]);}

/* k2042 in k2039 in k2036 in k2033 in loop in k2024 in k2021 in setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 176  flush-output");
((C_proc2)C_retrieve_proc(*((C_word*)lf[64]+1)))(2,*((C_word*)lf[64]+1),t2);}

/* k2045 in k2042 in k2039 in k2036 in k2033 in loop in k2024 in k2021 in setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 177  read-line");
((C_proc2)C_retrieve_symbol_proc(lf[63]))(2,*((C_word*)lf[63]+1),t2);}

/* k2048 in k2045 in k2042 in k2039 in k2036 in k2033 in loop in k2024 in k2021 in setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2050,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2053,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_eofp(((C_word*)t3)[1]))){
t5=C_set_block_item(t3,0,lf[61]);
t6=t4;
f_2053(t6,t5);}
else{
if(C_truep(((C_word*)t0)[2])){
if(C_truep(C_i_string_equal_p(lf[62],((C_word*)t3)[1]))){
t5=C_set_block_item(t3,0,((C_word*)t0)[2]);
t6=t4;
f_2053(t6,t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t4;
f_2053(t6,t5);}}
else{
t5=C_SCHEME_UNDEFINED;
t6=t4;
f_2053(t6,t5);}}}

/* k2051 in k2048 in k2045 in k2042 in k2039 in k2036 in k2033 in loop in k2024 in k2021 in setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_2053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2053,NULL,2,t0,t1);}
if(C_truep(C_i_string_ci_equal_p(lf[55],((C_word*)((C_word*)t0)[5])[1]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
if(C_truep(C_i_string_ci_equal_p(lf[56],((C_word*)((C_word*)t0)[5])[1]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_string_ci_equal_p(lf[57],((C_word*)((C_word*)t0)[5])[1]))){
C_trace("setup-api.scm: 182  abort");
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[4]);}
else{
t2=*((C_word*)lf[54]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2077,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t4=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(10),t2);}}}}

/* k2075 in k2051 in k2048 in k2045 in k2042 in k2039 in k2036 in k2033 in loop in k2024 in k2021 in setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2080,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t2,lf[60],((C_word*)t0)[2]);}

/* k2078 in k2075 in k2051 in k2048 in k2045 in k2042 in k2039 in k2036 in k2033 in loop in k2024 in k2021 in setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2083,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k2081 in k2078 in k2075 in k2051 in k2048 in k2045 in k2042 in k2039 in k2036 in k2033 in loop in k2024 in k2021 in setup-api#yes-or-no? in k2015 in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 185  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_2031(t2,((C_word*)t0)[2]);}

/* setup-api#sudo-install in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1994(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_1994r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1994r(t0,t1,t2);}}

static void C_ccall f_1994r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
if(C_truep(C_i_nullp(t2))){
t3=C_retrieve2(lf[7],"setup-api#*sudo*");
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_car(t2))){
t3=t1;
t4=lf[7] /* setup-api#*sudo* */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[8],"setup-api#*windows-shell*"))){
t5=lf[7] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
C_trace("setup-api.scm: 143  print");
((C_proc3)C_retrieve_proc(*((C_word*)lf[44]+1)))(3,*((C_word*)lf[44]+1),t3,lf[45]);}
else{
t5=C_mutate(&lf[25] /* (set! setup-api#*copy-command* ...) */,lf[46]);
t6=C_mutate(&lf[26] /* (set! setup-api#*remove-command* ...) */,lf[47]);
t7=C_mutate(&lf[27] /* (set! setup-api#*move-command* ...) */,lf[48]);
t8=C_mutate(&lf[28] /* (set! setup-api#*chmod-command* ...) */,lf[49]);
t9=C_mutate(&lf[29] /* (set! setup-api#*ranlib-command* ...) */,lf[50]);
t10=C_mutate(&lf[30] /* (set! setup-api#*mkdir-command* ...) */,lf[51]);
t11=t3;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}}
else{
C_trace("setup-api.scm: 168  user-install-setup");
f_1968(t1);}}}

/* setup-api#user-install-setup in k1925 in k1921 in k1917 in k1913 in k1909 in k1905 in k1901 in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_fcall f_1968(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1968,NULL,1,t1);}
t2=lf[7] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
if(C_truep(C_retrieve2(lf[8],"setup-api#*windows-shell*"))){
t3=t1;
t4=C_mutate(&lf[25] /* (set! setup-api#*copy-command* ...) */,lf[32]);
t5=C_mutate(&lf[26] /* (set! setup-api#*remove-command* ...) */,lf[33]);
t6=C_mutate(&lf[27] /* (set! setup-api#*move-command* ...) */,lf[34]);
t7=C_mutate(&lf[28] /* (set! setup-api#*chmod-command* ...) */,lf[35]);
t8=C_mutate(&lf[29] /* (set! setup-api#*ranlib-command* ...) */,lf[36]);
t9=t3;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t3=t1;
t4=C_mutate(&lf[25] /* (set! setup-api#*copy-command* ...) */,lf[37]);
t5=C_mutate(&lf[26] /* (set! setup-api#*remove-command* ...) */,lf[38]);
t6=C_mutate(&lf[27] /* (set! setup-api#*move-command* ...) */,lf[39]);
t7=C_mutate(&lf[28] /* (set! setup-api#*chmod-command* ...) */,lf[40]);
t8=C_mutate(&lf[29] /* (set! setup-api#*ranlib-command* ...) */,lf[41]);
t9=C_mutate(&lf[30] /* (set! setup-api#*mkdir-command* ...) */,lf[42]);
t10=t3;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* setup-api#cross-chicken in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fudge(C_fix(39)));}

/* setup-api#shellpath in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1884,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1892,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 103  normalize-pathname");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t3,t2);}

/* k1890 in setup-api#shellpath in k1880 in k1877 in k1873 in k1870 in k1867 in k1863 in k1859 in k1856 in k1849 in k1845 in k1841 in k1837 in k1833 in k1828 in k1825 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 103  qs");
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[565] = {
{"toplevel:setup_api_scm",(void*)C_toplevel},
{"f_1800:setup_api_scm",(void*)f_1800},
{"f_1803:setup_api_scm",(void*)f_1803},
{"f_1806:setup_api_scm",(void*)f_1806},
{"f_1809:setup_api_scm",(void*)f_1809},
{"f_1812:setup_api_scm",(void*)f_1812},
{"f_1815:setup_api_scm",(void*)f_1815},
{"f_1818:setup_api_scm",(void*)f_1818},
{"f_1821:setup_api_scm",(void*)f_1821},
{"f_1824:setup_api_scm",(void*)f_1824},
{"f_1827:setup_api_scm",(void*)f_1827},
{"f_1830:setup_api_scm",(void*)f_1830},
{"f_1835:setup_api_scm",(void*)f_1835},
{"f_1839:setup_api_scm",(void*)f_1839},
{"f_1843:setup_api_scm",(void*)f_1843},
{"f_1847:setup_api_scm",(void*)f_1847},
{"f_1851:setup_api_scm",(void*)f_1851},
{"f_5975:setup_api_scm",(void*)f_5975},
{"f_1858:setup_api_scm",(void*)f_1858},
{"f_1861:setup_api_scm",(void*)f_1861},
{"f_1865:setup_api_scm",(void*)f_1865},
{"f_1869:setup_api_scm",(void*)f_1869},
{"f_1872:setup_api_scm",(void*)f_1872},
{"f_1875:setup_api_scm",(void*)f_1875},
{"f_1879:setup_api_scm",(void*)f_1879},
{"f_1882:setup_api_scm",(void*)f_1882},
{"f_1903:setup_api_scm",(void*)f_1903},
{"f_1907:setup_api_scm",(void*)f_1907},
{"f_1911:setup_api_scm",(void*)f_1911},
{"f_1915:setup_api_scm",(void*)f_1915},
{"f_1919:setup_api_scm",(void*)f_1919},
{"f_1923:setup_api_scm",(void*)f_1923},
{"f_1927:setup_api_scm",(void*)f_1927},
{"f_5952:setup_api_scm",(void*)f_5952},
{"f_2017:setup_api_scm",(void*)f_2017},
{"f_2234:setup_api_scm",(void*)f_2234},
{"f_5950:setup_api_scm",(void*)f_5950},
{"f_2306:setup_api_scm",(void*)f_2306},
{"f_5946:setup_api_scm",(void*)f_5946},
{"f_2309:setup_api_scm",(void*)f_2309},
{"f_5942:setup_api_scm",(void*)f_5942},
{"f_2312:setup_api_scm",(void*)f_2312},
{"f_5938:setup_api_scm",(void*)f_5938},
{"f_2315:setup_api_scm",(void*)f_2315},
{"f_5934:setup_api_scm",(void*)f_5934},
{"f_2318:setup_api_scm",(void*)f_2318},
{"f_5930:setup_api_scm",(void*)f_5930},
{"f_2321:setup_api_scm",(void*)f_2321},
{"f_5926:setup_api_scm",(void*)f_5926},
{"f_2324:setup_api_scm",(void*)f_2324},
{"f_3349:setup_api_scm",(void*)f_3349},
{"f_3353:setup_api_scm",(void*)f_3353},
{"f_5817:setup_api_scm",(void*)f_5817},
{"f_5833:setup_api_scm",(void*)f_5833},
{"f_5870:setup_api_scm",(void*)f_5870},
{"f_5863:setup_api_scm",(void*)f_5863},
{"f_5867:setup_api_scm",(void*)f_5867},
{"f_5840:setup_api_scm",(void*)f_5840},
{"f_5468:setup_api_scm",(void*)f_5468},
{"f_5815:setup_api_scm",(void*)f_5815},
{"f_5776:setup_api_scm",(void*)f_5776},
{"f_5793:setup_api_scm",(void*)f_5793},
{"f_5780:setup_api_scm",(void*)f_5780},
{"f_5802:setup_api_scm",(void*)f_5802},
{"f_5812:setup_api_scm",(void*)f_5812},
{"f_5805:setup_api_scm",(void*)f_5805},
{"f_5722:setup_api_scm",(void*)f_5722},
{"f_5774:setup_api_scm",(void*)f_5774},
{"f_5749:setup_api_scm",(void*)f_5749},
{"f_5759:setup_api_scm",(void*)f_5759},
{"f_5729:setup_api_scm",(void*)f_5729},
{"f_5740:setup_api_scm",(void*)f_5740},
{"f_5736:setup_api_scm",(void*)f_5736},
{"f_5591:setup_api_scm",(void*)f_5591},
{"f_5595:setup_api_scm",(void*)f_5595},
{"f_5701:setup_api_scm",(void*)f_5701},
{"f_5635:setup_api_scm",(void*)f_5635},
{"f_5639:setup_api_scm",(void*)f_5639},
{"f_5647:setup_api_scm",(void*)f_5647},
{"f_5686:setup_api_scm",(void*)f_5686},
{"f_5655:setup_api_scm",(void*)f_5655},
{"f_5668:setup_api_scm",(void*)f_5668},
{"f_5674:setup_api_scm",(void*)f_5674},
{"f_5642:setup_api_scm",(void*)f_5642},
{"f_5617:setup_api_scm",(void*)f_5617},
{"f_5620:setup_api_scm",(void*)f_5620},
{"f_5630:setup_api_scm",(void*)f_5630},
{"f_5623:setup_api_scm",(void*)f_5623},
{"f_5626:setup_api_scm",(void*)f_5626},
{"f_5538:setup_api_scm",(void*)f_5538},
{"f_5542:setup_api_scm",(void*)f_5542},
{"f_5580:setup_api_scm",(void*)f_5580},
{"f_5586:setup_api_scm",(void*)f_5586},
{"f_5545:setup_api_scm",(void*)f_5545},
{"f_5550:setup_api_scm",(void*)f_5550},
{"f_5577:setup_api_scm",(void*)f_5577},
{"f_5573:setup_api_scm",(void*)f_5573},
{"f_5557:setup_api_scm",(void*)f_5557},
{"f_5563:setup_api_scm",(void*)f_5563},
{"f_5569:setup_api_scm",(void*)f_5569},
{"f_5524:setup_api_scm",(void*)f_5524},
{"f_5536:setup_api_scm",(void*)f_5536},
{"f_5532:setup_api_scm",(void*)f_5532},
{"f_5480:setup_api_scm",(void*)f_5480},
{"f_5484:setup_api_scm",(void*)f_5484},
{"f_5503:setup_api_scm",(void*)f_5503},
{"f_5493:setup_api_scm",(void*)f_5493},
{"f_5470:setup_api_scm",(void*)f_5470},
{"f_5478:setup_api_scm",(void*)f_5478},
{"f_5269:setup_api_scm",(void*)f_5269},
{"f_5334:setup_api_scm",(void*)f_5334},
{"f_5338:setup_api_scm",(void*)f_5338},
{"f_5340:setup_api_scm",(void*)f_5340},
{"f_5420:setup_api_scm",(void*)f_5420},
{"f_5272:setup_api_scm",(void*)f_5272},
{"f_5327:setup_api_scm",(void*)f_5327},
{"f_5280:setup_api_scm",(void*)f_5280},
{"f_5282:setup_api_scm",(void*)f_5282},
{"f_5313:setup_api_scm",(void*)f_5313},
{"f_5292:setup_api_scm",(void*)f_5292},
{"f_5247:setup_api_scm",(void*)f_5247},
{"f_5255:setup_api_scm",(void*)f_5255},
{"f_5258:setup_api_scm",(void*)f_5258},
{"f_5261:setup_api_scm",(void*)f_5261},
{"f_5264:setup_api_scm",(void*)f_5264},
{"f_5267:setup_api_scm",(void*)f_5267},
{"f_5188:setup_api_scm",(void*)f_5188},
{"f_5196:setup_api_scm",(void*)f_5196},
{"f_5199:setup_api_scm",(void*)f_5199},
{"f_5202:setup_api_scm",(void*)f_5202},
{"f_5205:setup_api_scm",(void*)f_5205},
{"f_5208:setup_api_scm",(void*)f_5208},
{"f_5211:setup_api_scm",(void*)f_5211},
{"f_5214:setup_api_scm",(void*)f_5214},
{"f_5217:setup_api_scm",(void*)f_5217},
{"f_5220:setup_api_scm",(void*)f_5220},
{"f_5223:setup_api_scm",(void*)f_5223},
{"f_5226:setup_api_scm",(void*)f_5226},
{"f_5229:setup_api_scm",(void*)f_5229},
{"f_5232:setup_api_scm",(void*)f_5232},
{"f_5235:setup_api_scm",(void*)f_5235},
{"f_5238:setup_api_scm",(void*)f_5238},
{"f_5241:setup_api_scm",(void*)f_5241},
{"f_5245:setup_api_scm",(void*)f_5245},
{"f_5067:setup_api_scm",(void*)f_5067},
{"f_5073:setup_api_scm",(void*)f_5073},
{"f_5086:setup_api_scm",(void*)f_5086},
{"f_5098:setup_api_scm",(void*)f_5098},
{"f_5104:setup_api_scm",(void*)f_5104},
{"f_5144:setup_api_scm",(void*)f_5144},
{"f_5155:setup_api_scm",(void*)f_5155},
{"f_5159:setup_api_scm",(void*)f_5159},
{"f_5119:setup_api_scm",(void*)f_5119},
{"f_5126:setup_api_scm",(void*)f_5126},
{"f_5129:setup_api_scm",(void*)f_5129},
{"f_5132:setup_api_scm",(void*)f_5132},
{"f_5135:setup_api_scm",(void*)f_5135},
{"f_5138:setup_api_scm",(void*)f_5138},
{"f_4986:setup_api_scm",(void*)f_4986},
{"f_4990:setup_api_scm",(void*)f_4990},
{"f_4997:setup_api_scm",(void*)f_4997},
{"f_5000:setup_api_scm",(void*)f_5000},
{"f_5003:setup_api_scm",(void*)f_5003},
{"f_5006:setup_api_scm",(void*)f_5006},
{"f_5009:setup_api_scm",(void*)f_5009},
{"f_5012:setup_api_scm",(void*)f_5012},
{"f_5015:setup_api_scm",(void*)f_5015},
{"f_5018:setup_api_scm",(void*)f_5018},
{"f_5021:setup_api_scm",(void*)f_5021},
{"f_5024:setup_api_scm",(void*)f_5024},
{"f_5043:setup_api_scm",(void*)f_5043},
{"f_5027:setup_api_scm",(void*)f_5027},
{"f_5030:setup_api_scm",(void*)f_5030},
{"f_5033:setup_api_scm",(void*)f_5033},
{"f_5036:setup_api_scm",(void*)f_5036},
{"f_5039:setup_api_scm",(void*)f_5039},
{"f_4954:setup_api_scm",(void*)f_4954},
{"f_4984:setup_api_scm",(void*)f_4984},
{"f_4961:setup_api_scm",(void*)f_4961},
{"f_4968:setup_api_scm",(void*)f_4968},
{"f_4971:setup_api_scm",(void*)f_4971},
{"f_4974:setup_api_scm",(void*)f_4974},
{"f_4977:setup_api_scm",(void*)f_4977},
{"f_4980:setup_api_scm",(void*)f_4980},
{"f_4830:setup_api_scm",(void*)f_4830},
{"f_4834:setup_api_scm",(void*)f_4834},
{"f_4948:setup_api_scm",(void*)f_4948},
{"f_4837:setup_api_scm",(void*)f_4837},
{"f_4945:setup_api_scm",(void*)f_4945},
{"f_4840:setup_api_scm",(void*)f_4840},
{"f_4942:setup_api_scm",(void*)f_4942},
{"f_4843:setup_api_scm",(void*)f_4843},
{"f_4936:setup_api_scm",(void*)f_4936},
{"f_4846:setup_api_scm",(void*)f_4846},
{"f_4933:setup_api_scm",(void*)f_4933},
{"f_4849:setup_api_scm",(void*)f_4849},
{"f_4852:setup_api_scm",(void*)f_4852},
{"f_4855:setup_api_scm",(void*)f_4855},
{"f_4927:setup_api_scm",(void*)f_4927},
{"f_4858:setup_api_scm",(void*)f_4858},
{"f_4918:setup_api_scm",(void*)f_4918},
{"f_4904:setup_api_scm",(void*)f_4904},
{"f_4907:setup_api_scm",(void*)f_4907},
{"f_4861:setup_api_scm",(void*)f_4861},
{"f_4864:setup_api_scm",(void*)f_4864},
{"f_4874:setup_api_scm",(void*)f_4874},
{"f_4877:setup_api_scm",(void*)f_4877},
{"f_4880:setup_api_scm",(void*)f_4880},
{"f_4890:setup_api_scm",(void*)f_4890},
{"f_4883:setup_api_scm",(void*)f_4883},
{"f_4886:setup_api_scm",(void*)f_4886},
{"f_4867:setup_api_scm",(void*)f_4867},
{"f_4777:setup_api_scm",(void*)f_4777},
{"f_4781:setup_api_scm",(void*)f_4781},
{"f_4790:setup_api_scm",(void*)f_4790},
{"f_4802:setup_api_scm",(void*)f_4802},
{"f_4828:setup_api_scm",(void*)f_4828},
{"f_4796:setup_api_scm",(void*)f_4796},
{"f_4784:setup_api_scm",(void*)f_4784},
{"f_4705:setup_api_scm",(void*)f_4705},
{"f_4709:setup_api_scm",(void*)f_4709},
{"f_4721:setup_api_scm",(void*)f_4721},
{"f_4727:setup_api_scm",(void*)f_4727},
{"f_4737:setup_api_scm",(void*)f_4737},
{"f_4740:setup_api_scm",(void*)f_4740},
{"f_4743:setup_api_scm",(void*)f_4743},
{"f_4746:setup_api_scm",(void*)f_4746},
{"f_4712:setup_api_scm",(void*)f_4712},
{"f_4715:setup_api_scm",(void*)f_4715},
{"f_4541:setup_api_scm",(void*)f_4541},
{"f_4545:setup_api_scm",(void*)f_4545},
{"f_4551:setup_api_scm",(void*)f_4551},
{"f_4554:setup_api_scm",(void*)f_4554},
{"f_4557:setup_api_scm",(void*)f_4557},
{"f_4674:setup_api_scm",(void*)f_4674},
{"f_4560:setup_api_scm",(void*)f_4560},
{"f_4594:setup_api_scm",(void*)f_4594},
{"f_4666:setup_api_scm",(void*)f_4666},
{"f_4621:setup_api_scm",(void*)f_4621},
{"f_4628:setup_api_scm",(void*)f_4628},
{"f_4631:setup_api_scm",(void*)f_4631},
{"f_4657:setup_api_scm",(void*)f_4657},
{"f_4634:setup_api_scm",(void*)f_4634},
{"f_4563:setup_api_scm",(void*)f_4563},
{"f_4592:setup_api_scm",(void*)f_4592},
{"f_4566:setup_api_scm",(void*)f_4566},
{"f_4322:setup_api_scm",(void*)f_4322},
{"f_4326:setup_api_scm",(void*)f_4326},
{"f_4342:setup_api_scm",(void*)f_4342},
{"f_4345:setup_api_scm",(void*)f_4345},
{"f_4348:setup_api_scm",(void*)f_4348},
{"f_4510:setup_api_scm",(void*)f_4510},
{"f_4351:setup_api_scm",(void*)f_4351},
{"f_4443:setup_api_scm",(void*)f_4443},
{"f_4502:setup_api_scm",(void*)f_4502},
{"f_4470:setup_api_scm",(void*)f_4470},
{"f_4484:setup_api_scm",(void*)f_4484},
{"f_4488:setup_api_scm",(void*)f_4488},
{"f_4354:setup_api_scm",(void*)f_4354},
{"f_4362:setup_api_scm",(void*)f_4362},
{"f_4434:setup_api_scm",(void*)f_4434},
{"f_4389:setup_api_scm",(void*)f_4389},
{"f_4396:setup_api_scm",(void*)f_4396},
{"f_4399:setup_api_scm",(void*)f_4399},
{"f_4425:setup_api_scm",(void*)f_4425},
{"f_4402:setup_api_scm",(void*)f_4402},
{"f_4357:setup_api_scm",(void*)f_4357},
{"f_4328:setup_api_scm",(void*)f_4328},
{"f_3856:setup_api_scm",(void*)f_3856},
{"f_3863:setup_api_scm",(void*)f_3863},
{"f_4095:setup_api_scm",(void*)f_4095},
{"f_4099:setup_api_scm",(void*)f_4099},
{"f_4105:setup_api_scm",(void*)f_4105},
{"f_4108:setup_api_scm",(void*)f_4108},
{"f_4111:setup_api_scm",(void*)f_4111},
{"f_4114:setup_api_scm",(void*)f_4114},
{"f_4122:setup_api_scm",(void*)f_4122},
{"f_4287:setup_api_scm",(void*)f_4287},
{"f_4149:setup_api_scm",(void*)f_4149},
{"f_4156:setup_api_scm",(void*)f_4156},
{"f_4278:setup_api_scm",(void*)f_4278},
{"f_4249:setup_api_scm",(void*)f_4249},
{"f_4268:setup_api_scm",(void*)f_4268},
{"f_4159:setup_api_scm",(void*)f_4159},
{"f_4162:setup_api_scm",(void*)f_4162},
{"f_4246:setup_api_scm",(void*)f_4246},
{"f_4165:setup_api_scm",(void*)f_4165},
{"f_4223:setup_api_scm",(void*)f_4223},
{"f_4215:setup_api_scm",(void*)f_4215},
{"f_4180:setup_api_scm",(void*)f_4180},
{"f_4199:setup_api_scm",(void*)f_4199},
{"f_4171:setup_api_scm",(void*)f_4171},
{"f_4117:setup_api_scm",(void*)f_4117},
{"f_3905:setup_api_scm",(void*)f_3905},
{"f_4092:setup_api_scm",(void*)f_4092},
{"f_3909:setup_api_scm",(void*)f_3909},
{"f_4089:setup_api_scm",(void*)f_4089},
{"f_3912:setup_api_scm",(void*)f_3912},
{"f_3915:setup_api_scm",(void*)f_3915},
{"f_3918:setup_api_scm",(void*)f_3918},
{"f_3921:setup_api_scm",(void*)f_3921},
{"f_3924:setup_api_scm",(void*)f_3924},
{"f_3927:setup_api_scm",(void*)f_3927},
{"f_3930:setup_api_scm",(void*)f_3930},
{"f_3980:setup_api_scm",(void*)f_3980},
{"f_3984:setup_api_scm",(void*)f_3984},
{"f_3988:setup_api_scm",(void*)f_3988},
{"f_3972:setup_api_scm",(void*)f_3972},
{"f_3953:setup_api_scm",(void*)f_3953},
{"f_3949:setup_api_scm",(void*)f_3949},
{"f_3768:setup_api_scm",(void*)f_3768},
{"f_3774:setup_api_scm",(void*)f_3774},
{"f_3814:setup_api_scm",(void*)f_3814},
{"f_3817:setup_api_scm",(void*)f_3817},
{"f_3846:setup_api_scm",(void*)f_3846},
{"f_3784:setup_api_scm",(void*)f_3784},
{"f_3743:setup_api_scm",(void*)f_3743},
{"f_3763:setup_api_scm",(void*)f_3763},
{"f_3721:setup_api_scm",(void*)f_3721},
{"f_3741:setup_api_scm",(void*)f_3741},
{"f_3666:setup_api_scm",(void*)f_3666},
{"f_3673:setup_api_scm",(void*)f_3673},
{"f_3676:setup_api_scm",(void*)f_3676},
{"f_3695:setup_api_scm",(void*)f_3695},
{"f_3703:setup_api_scm",(void*)f_3703},
{"f_3520:setup_api_scm",(void*)f_3520},
{"f_3604:setup_api_scm",(void*)f_3604},
{"f_3595:setup_api_scm",(void*)f_3595},
{"f_3603:setup_api_scm",(void*)f_3603},
{"f_3522:setup_api_scm",(void*)f_3522},
{"f_3529:setup_api_scm",(void*)f_3529},
{"f_3660:setup_api_scm",(void*)f_3660},
{"f_3664:setup_api_scm",(void*)f_3664},
{"f_3578:setup_api_scm",(void*)f_3578},
{"f_3571:setup_api_scm",(void*)f_3571},
{"f_3532:setup_api_scm",(void*)f_3532},
{"f_3535:setup_api_scm",(void*)f_3535},
{"f_3554:setup_api_scm",(void*)f_3554},
{"f_3562:setup_api_scm",(void*)f_3562},
{"f_3538:setup_api_scm",(void*)f_3538},
{"f_3391:setup_api_scm",(void*)f_3391},
{"f_3518:setup_api_scm",(void*)f_3518},
{"f_3514:setup_api_scm",(void*)f_3514},
{"f_3488:setup_api_scm",(void*)f_3488},
{"f_3491:setup_api_scm",(void*)f_3491},
{"f_3494:setup_api_scm",(void*)f_3494},
{"f_3497:setup_api_scm",(void*)f_3497},
{"f_3500:setup_api_scm",(void*)f_3500},
{"f_3503:setup_api_scm",(void*)f_3503},
{"f_3398:setup_api_scm",(void*)f_3398},
{"f_3401:setup_api_scm",(void*)f_3401},
{"f_3485:setup_api_scm",(void*)f_3485},
{"f_3320:setup_api_scm",(void*)f_3320},
{"f_3404:setup_api_scm",(void*)f_3404},
{"f_3477:setup_api_scm",(void*)f_3477},
{"f_3436:setup_api_scm",(void*)f_3436},
{"f_3468:setup_api_scm",(void*)f_3468},
{"f_3439:setup_api_scm",(void*)f_3439},
{"f_3458:setup_api_scm",(void*)f_3458},
{"f_3466:setup_api_scm",(void*)f_3466},
{"f_3407:setup_api_scm",(void*)f_3407},
{"f_3433:setup_api_scm",(void*)f_3433},
{"f_5895:setup_api_scm",(void*)f_5895},
{"f_5899:setup_api_scm",(void*)f_5899},
{"f_5922:setup_api_scm",(void*)f_5922},
{"f_5887:setup_api_scm",(void*)f_5887},
{"f_5891:setup_api_scm",(void*)f_5891},
{"f_3367:setup_api_scm",(void*)f_3367},
{"f_3374:setup_api_scm",(void*)f_3374},
{"f_3377:setup_api_scm",(void*)f_3377},
{"f_3380:setup_api_scm",(void*)f_3380},
{"f_3383:setup_api_scm",(void*)f_3383},
{"f_3354:setup_api_scm",(void*)f_3354},
{"f_3358:setup_api_scm",(void*)f_3358},
{"f_3273:setup_api_scm",(void*)f_3273},
{"f_3305:setup_api_scm",(void*)f_3305},
{"f_2852:setup_api_scm",(void*)f_2852},
{"f_3271:setup_api_scm",(void*)f_3271},
{"f_2856:setup_api_scm",(void*)f_2856},
{"f_2684:setup_api_scm",(void*)f_2684},
{"f_2693:setup_api_scm",(void*)f_2693},
{"f_2698:setup_api_scm",(void*)f_2698},
{"f_2705:setup_api_scm",(void*)f_2705},
{"f_2708:setup_api_scm",(void*)f_2708},
{"f_2717:setup_api_scm",(void*)f_2717},
{"f_2720:setup_api_scm",(void*)f_2720},
{"f_2759:setup_api_scm",(void*)f_2759},
{"f_2767:setup_api_scm",(void*)f_2767},
{"f_2729:setup_api_scm",(void*)f_2729},
{"f_2859:setup_api_scm",(void*)f_2859},
{"f_2844:setup_api_scm",(void*)f_2844},
{"f_2862:setup_api_scm",(void*)f_2862},
{"f_2867:setup_api_scm",(void*)f_2867},
{"f_2871:setup_api_scm",(void*)f_2871},
{"f_3238:setup_api_scm",(void*)f_3238},
{"f_3253:setup_api_scm",(void*)f_3253},
{"f_3246:setup_api_scm",(void*)f_3246},
{"f_3233:setup_api_scm",(void*)f_3233},
{"f_3167:setup_api_scm",(void*)f_3167},
{"f_3173:setup_api_scm",(void*)f_3173},
{"f_3180:setup_api_scm",(void*)f_3180},
{"f_3182:setup_api_scm",(void*)f_3182},
{"f_3194:setup_api_scm",(void*)f_3194},
{"f_3197:setup_api_scm",(void*)f_3197},
{"f_3203:setup_api_scm",(void*)f_3203},
{"f_2873:setup_api_scm",(void*)f_2873},
{"f_2579:setup_api_scm",(void*)f_2579},
{"f_2592:setup_api_scm",(void*)f_2592},
{"f_2598:setup_api_scm",(void*)f_2598},
{"f_2570:setup_api_scm",(void*)f_2570},
{"f_2877:setup_api_scm",(void*)f_2877},
{"f_2880:setup_api_scm",(void*)f_2880},
{"f_3161:setup_api_scm",(void*)f_3161},
{"f_2883:setup_api_scm",(void*)f_2883},
{"f_3143:setup_api_scm",(void*)f_3143},
{"f_3146:setup_api_scm",(void*)f_3146},
{"f_3149:setup_api_scm",(void*)f_3149},
{"f_3152:setup_api_scm",(void*)f_3152},
{"f_3155:setup_api_scm",(void*)f_3155},
{"f_2886:setup_api_scm",(void*)f_2886},
{"f_3131:setup_api_scm",(void*)f_3131},
{"f_3134:setup_api_scm",(void*)f_3134},
{"f_3137:setup_api_scm",(void*)f_3137},
{"f_3140:setup_api_scm",(void*)f_3140},
{"f_3116:setup_api_scm",(void*)f_3116},
{"f_3117:setup_api_scm",(void*)f_3117},
{"f_2895:setup_api_scm",(void*)f_2895},
{"f_3070:setup_api_scm",(void*)f_3070},
{"f_3074:setup_api_scm",(void*)f_3074},
{"f_3090:setup_api_scm",(void*)f_3090},
{"f_3097:setup_api_scm",(void*)f_3097},
{"f_3100:setup_api_scm",(void*)f_3100},
{"f_3103:setup_api_scm",(void*)f_3103},
{"f_3106:setup_api_scm",(void*)f_3106},
{"f_3109:setup_api_scm",(void*)f_3109},
{"f_3112:setup_api_scm",(void*)f_3112},
{"f_3077:setup_api_scm",(void*)f_3077},
{"f_3087:setup_api_scm",(void*)f_3087},
{"f_2901:setup_api_scm",(void*)f_2901},
{"f_3003:setup_api_scm",(void*)f_3003},
{"f_3006:setup_api_scm",(void*)f_3006},
{"f_3009:setup_api_scm",(void*)f_3009},
{"f_3012:setup_api_scm",(void*)f_3012},
{"f_3015:setup_api_scm",(void*)f_3015},
{"f_3047:setup_api_scm",(void*)f_3047},
{"f_3050:setup_api_scm",(void*)f_3050},
{"f_3053:setup_api_scm",(void*)f_3053},
{"f_3056:setup_api_scm",(void*)f_3056},
{"f_3059:setup_api_scm",(void*)f_3059},
{"f_3062:setup_api_scm",(void*)f_3062},
{"f_3065:setup_api_scm",(void*)f_3065},
{"f_3025:setup_api_scm",(void*)f_3025},
{"f_3018:setup_api_scm",(void*)f_3018},
{"f_2920:setup_api_scm",(void*)f_2920},
{"f_2928:setup_api_scm",(void*)f_2928},
{"f_2975:setup_api_scm",(void*)f_2975},
{"f_2990:setup_api_scm",(void*)f_2990},
{"f_2996:setup_api_scm",(void*)f_2996},
{"f_2981:setup_api_scm",(void*)f_2981},
{"f_2934:setup_api_scm",(void*)f_2934},
{"f_2940:setup_api_scm",(void*)f_2940},
{"f_2944:setup_api_scm",(void*)f_2944},
{"f_2947:setup_api_scm",(void*)f_2947},
{"f_2950:setup_api_scm",(void*)f_2950},
{"f_2966:setup_api_scm",(void*)f_2966},
{"f_2963:setup_api_scm",(void*)f_2963},
{"f_2953:setup_api_scm",(void*)f_2953},
{"f_2956:setup_api_scm",(void*)f_2956},
{"f_2923:setup_api_scm",(void*)f_2923},
{"f_2646:setup_api_scm",(void*)f_2646},
{"f_2654:setup_api_scm",(void*)f_2654},
{"f_2657:setup_api_scm",(void*)f_2657},
{"f_2660:setup_api_scm",(void*)f_2660},
{"f_2663:setup_api_scm",(void*)f_2663},
{"f_2666:setup_api_scm",(void*)f_2666},
{"f_2669:setup_api_scm",(void*)f_2669},
{"f_2672:setup_api_scm",(void*)f_2672},
{"f_2624:setup_api_scm",(void*)f_2624},
{"f_2632:setup_api_scm",(void*)f_2632},
{"f_2635:setup_api_scm",(void*)f_2635},
{"f_2638:setup_api_scm",(void*)f_2638},
{"f_2641:setup_api_scm",(void*)f_2641},
{"f_2644:setup_api_scm",(void*)f_2644},
{"f_2417:setup_api_scm",(void*)f_2417},
{"f_2533:setup_api_scm",(void*)f_2533},
{"f_2445:setup_api_scm",(void*)f_2445},
{"f_2474:setup_api_scm",(void*)f_2474},
{"f_2424:setup_api_scm",(void*)f_2424},
{"f_2386:setup_api_scm",(void*)f_2386},
{"f_2344:setup_api_scm",(void*)f_2344},
{"f_2375:setup_api_scm",(void*)f_2375},
{"f_2382:setup_api_scm",(void*)f_2382},
{"f_2348:setup_api_scm",(void*)f_2348},
{"f_2369:setup_api_scm",(void*)f_2369},
{"f_2366:setup_api_scm",(void*)f_2366},
{"f_2363:setup_api_scm",(void*)f_2363},
{"f_2340:setup_api_scm",(void*)f_2340},
{"f_2435:setup_api_scm",(void*)f_2435},
{"f_2562:setup_api_scm",(void*)f_2562},
{"f_2485:setup_api_scm",(void*)f_2485},
{"f_2487:setup_api_scm",(void*)f_2487},
{"f_2505:setup_api_scm",(void*)f_2505},
{"f_2508:setup_api_scm",(void*)f_2508},
{"f_2511:setup_api_scm",(void*)f_2511},
{"f_2514:setup_api_scm",(void*)f_2514},
{"f_2499:setup_api_scm",(void*)f_2499},
{"f_2520:setup_api_scm",(void*)f_2520},
{"f_2391:setup_api_scm",(void*)f_2391},
{"f_2415:setup_api_scm",(void*)f_2415},
{"f_2398:setup_api_scm",(void*)f_2398},
{"f_2295:setup_api_scm",(void*)f_2295},
{"f_2303:setup_api_scm",(void*)f_2303},
{"f_2276:setup_api_scm",(void*)f_2276},
{"f_2280:setup_api_scm",(void*)f_2280},
{"f_2236:setup_api_scm",(void*)f_2236},
{"f_2258:setup_api_scm",(void*)f_2258},
{"f_2240:setup_api_scm",(void*)f_2240},
{"f_2248:setup_api_scm",(void*)f_2248},
{"f_2244:setup_api_scm",(void*)f_2244},
{"f_2117:setup_api_scm",(void*)f_2117},
{"f_2218:setup_api_scm",(void*)f_2218},
{"f_2221:setup_api_scm",(void*)f_2221},
{"f_2224:setup_api_scm",(void*)f_2224},
{"f_2227:setup_api_scm",(void*)f_2227},
{"f_2121:setup_api_scm",(void*)f_2121},
{"f_2175:setup_api_scm",(void*)f_2175},
{"f_2178:setup_api_scm",(void*)f_2178},
{"f_2185:setup_api_scm",(void*)f_2185},
{"f_2188:setup_api_scm",(void*)f_2188},
{"f_2191:setup_api_scm",(void*)f_2191},
{"f_2211:setup_api_scm",(void*)f_2211},
{"f_2194:setup_api_scm",(void*)f_2194},
{"f_2197:setup_api_scm",(void*)f_2197},
{"f_2207:setup_api_scm",(void*)f_2207},
{"f_2200:setup_api_scm",(void*)f_2200},
{"f_2203:setup_api_scm",(void*)f_2203},
{"f_2136:setup_api_scm",(void*)f_2136},
{"f_2146:setup_api_scm",(void*)f_2146},
{"f_2152:setup_api_scm",(void*)f_2152},
{"f_2156:setup_api_scm",(void*)f_2156},
{"f_2172:setup_api_scm",(void*)f_2172},
{"f_2165:setup_api_scm",(void*)f_2165},
{"f_2019:setup_api_scm",(void*)f_2019},
{"f_2023:setup_api_scm",(void*)f_2023},
{"f_2111:setup_api_scm",(void*)f_2111},
{"f_2026:setup_api_scm",(void*)f_2026},
{"f_2031:setup_api_scm",(void*)f_2031},
{"f_2035:setup_api_scm",(void*)f_2035},
{"f_2038:setup_api_scm",(void*)f_2038},
{"f_2041:setup_api_scm",(void*)f_2041},
{"f_2103:setup_api_scm",(void*)f_2103},
{"f_2106:setup_api_scm",(void*)f_2106},
{"f_2044:setup_api_scm",(void*)f_2044},
{"f_2047:setup_api_scm",(void*)f_2047},
{"f_2050:setup_api_scm",(void*)f_2050},
{"f_2053:setup_api_scm",(void*)f_2053},
{"f_2077:setup_api_scm",(void*)f_2077},
{"f_2080:setup_api_scm",(void*)f_2080},
{"f_2083:setup_api_scm",(void*)f_2083},
{"f_1994:setup_api_scm",(void*)f_1994},
{"f_1968:setup_api_scm",(void*)f_1968},
{"f_1894:setup_api_scm",(void*)f_1894},
{"f_1884:setup_api_scm",(void*)f_1884},
{"f_1892:setup_api_scm",(void*)f_1892},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
