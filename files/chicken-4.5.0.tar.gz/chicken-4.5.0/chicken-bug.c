/* Generated from chicken-bug.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:54
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: chicken-bug.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -output-file chicken-bug.c
   used units: library eval srfi_13 posix tcp data_structures utils extras
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[149];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_332)
static void C_ccall f_332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_335)
static void C_ccall f_335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_338)
static void C_ccall f_338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_341)
static void C_ccall f_341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_344)
static void C_ccall f_344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_347)
static void C_ccall f_347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_350)
static void C_ccall f_350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_353)
static void C_ccall f_353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1413)
static void C_ccall f_1413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1416)
static void C_ccall f_1416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1299)
static void C_ccall f_1299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1305)
static void C_ccall f_1305(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1311)
static void C_fcall f_1311(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1410)
static void C_ccall f_1410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1355)
static void C_ccall f_1355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1402)
static void C_ccall f_1402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1358)
static void C_ccall f_1358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1398)
static void C_ccall f_1398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1361)
static void C_ccall f_1361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1394)
static void C_ccall f_1394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1364)
static void C_ccall f_1364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1367)
static void C_ccall f_1367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1370)
static void C_ccall f_1370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1324)
static void C_ccall f_1324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1278)
static void C_ccall f_1278(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1209)
static void C_ccall f_1209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1254)
static void C_ccall f_1254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1260)
static void C_ccall f_1260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1243)
static void C_ccall f_1243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1246)
static void C_ccall f_1246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1213)
static void C_ccall f_1213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1216)
static void C_ccall f_1216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1155)
static void C_ccall f_1155(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1191)
static void C_ccall f_1191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1167)
static void C_ccall f_1167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1174)
static void C_ccall f_1174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1177)
static void C_ccall f_1177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1127)
static void C_ccall f_1127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1130)
static void C_ccall f_1130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1105)
static void C_ccall f_1105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1113)
static void C_ccall f_1113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_917)
static void C_ccall f_917(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_928)
static void C_fcall f_928(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1060)
static void C_ccall f_1060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_932)
static void C_ccall f_932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_fcall f_939(C_word t0,C_word t1) C_noret;
C_noret_decl(f_943)
static void C_ccall f_943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_947)
static void C_ccall f_947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_967)
static void C_ccall f_967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_876)
static void C_ccall f_876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_901)
static void C_ccall f_901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_894)
static void C_ccall f_894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_886)
static void C_ccall f_886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_730)
static void C_ccall f_730(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_811)
static void C_fcall f_811(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_863)
static void C_ccall f_863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_819)
static void C_fcall f_819(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_860)
static void C_ccall f_860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_856)
static void C_ccall f_856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f1515)
static void C_ccall f1515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_835)
static void C_ccall f_835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_831)
static void C_ccall f_831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_734)
static void C_ccall f_734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_809)
static void C_ccall f_809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_805)
static void C_ccall f_805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_737)
static void C_fcall f_737(C_word t0,C_word t1) C_noret;
C_noret_decl(f_740)
static void C_ccall f_740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_801)
static void C_ccall f_801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_743)
static void C_ccall f_743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_793)
static void C_ccall f_793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_768)
static void C_ccall f_768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_772)
static void C_ccall f_772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_778)
static void C_ccall f_778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_782)
static void C_ccall f_782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_776)
static void C_ccall f_776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_758)
static void C_ccall f_758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_711)
static void C_ccall f_711(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_715)
static void C_ccall f_715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_664)
static void C_ccall f_664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_709)
static void C_ccall f_709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_702)
static void C_ccall f_702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_668)
static void C_ccall f_668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_673)
static void C_fcall f_673(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_677)
static void C_ccall f_677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_655)
static void C_ccall f_655(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_659)
static void C_ccall f_659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_369)
static void C_ccall f_369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_373)
static void C_ccall f_373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_376)
static void C_ccall f_376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_653)
static void C_ccall f_653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_649)
static void C_ccall f_649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_379)
static void C_ccall f_379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_382)
static void C_ccall f_382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f1508)
static void C_ccall f1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_645)
static void C_ccall f_645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_385)
static void C_ccall f_385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_388)
static void C_ccall f_388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_391)
static void C_ccall f_391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_394)
static void C_ccall f_394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_641)
static void C_ccall f_641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_397)
static void C_ccall f_397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_637)
static void C_ccall f_637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_400)
static void C_ccall f_400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_633)
static void C_ccall f_633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_403)
static void C_ccall f_403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_629)
static void C_ccall f_629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_406)
static void C_ccall f_406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_625)
static void C_ccall f_625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_409)
static void C_ccall f_409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_621)
static void C_ccall f_621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_412)
static void C_ccall f_412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_415)
static void C_ccall f_415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_418)
static void C_ccall f_418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_421)
static void C_ccall f_421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_424)
static void C_ccall f_424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_427)
static void C_ccall f_427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_584)
static void C_fcall f_584(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_613)
static void C_ccall f_613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_582)
static void C_ccall f_582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_578)
static void C_ccall f_578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_496)
static void C_ccall f_496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_498)
static void C_fcall f_498(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_510)
static void C_ccall f_510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_515)
static void C_fcall f_515(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_527)
static void C_ccall f_527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_538)
static void C_ccall f_538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_534)
static void C_ccall f_534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_549)
static void C_ccall f_549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_563)
static void C_ccall f_563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_430)
static void C_ccall f_430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_433)
static void C_ccall f_433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_492)
static void C_ccall f_492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_478)
static void C_ccall f_478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_480)
static void C_ccall f_480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_488)
static void C_ccall f_488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_436)
static void C_ccall f_436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_439)
static void C_ccall f_439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_474)
static void C_ccall f_474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_448)
static void C_ccall f_448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_451)
static void C_ccall f_451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_456)
static void C_ccall f_456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_464)
static void C_ccall f_464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_442)
static void C_ccall f_442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_359)
static void C_ccall f_359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_367)
static void C_ccall f_367(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1311)
static void C_fcall trf_1311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1311(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1311(t0,t1,t2);}

C_noret_decl(trf_928)
static void C_fcall trf_928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_928(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_928(t0,t1);}

C_noret_decl(trf_939)
static void C_fcall trf_939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_939(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_939(t0,t1);}

C_noret_decl(trf_811)
static void C_fcall trf_811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_811(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_811(t0,t1,t2);}

C_noret_decl(trf_819)
static void C_fcall trf_819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_819(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_819(t0,t1,t2);}

C_noret_decl(trf_737)
static void C_fcall trf_737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_737(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_737(t0,t1);}

C_noret_decl(trf_673)
static void C_fcall trf_673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_673(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_673(t0,t1,t2);}

C_noret_decl(trf_584)
static void C_fcall trf_584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_584(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_584(t0,t1,t2);}

C_noret_decl(trf_498)
static void C_fcall trf_498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_498(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_498(t0,t1,t2);}

C_noret_decl(trf_515)
static void C_fcall trf_515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_515(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_515(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(670)){
C_save(t1);
C_rereclaim2(670*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,149);
lf[0]=C_h_intern(&lf[0],7,"user-id");
lf[1]=C_h_intern(&lf[1],16,"user-information");
lf[2]=C_h_intern(&lf[2],15,"current-user-id");
lf[3]=C_h_intern(&lf[3],12,"collect-info");
lf[4]=C_h_intern(&lf[4],19,"\003sysstandard-output");
lf[5]=C_h_intern(&lf[5],7,"newline");
lf[6]=C_h_intern(&lf[6],7,"display");
lf[7]=C_h_intern(&lf[7],8,"read-all");
lf[8]=C_h_intern(&lf[8],20,"with-input-from-pipe");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\013gcc -v 2>&1");
lf[10]=C_h_intern(&lf[10],5,"print");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\0000CC seems to be gcc, trying to obtain version...\012");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\003gcc");
lf[13]=C_h_intern(&lf[13],8,"feature\077");
lf[14]=C_h_intern(&lf[14],4,"unix");
lf[15]=C_h_intern(&lf[15],17,"\003syspeek-c-string");
lf[16]=C_h_intern(&lf[16],20,"with-input-from-file");
lf[17]=C_h_intern(&lf[17],13,"make-pathname");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-config.h");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\024\012\012chicken-config.h:\012");
lf[20]=C_h_intern(&lf[20],11,"make-string");
lf[21]=C_h_intern(&lf[21],5,"fxmax");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[23]=C_h_intern(&lf[23],4,"chop");
lf[24]=C_h_intern(&lf[24],4,"sort");
lf[25]=C_h_intern(&lf[25],8,"string<\077");
lf[26]=C_h_intern(&lf[26],15,"keyword->string");
lf[27]=C_h_intern(&lf[27],12,"\003sysfeatures");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[29]=C_h_intern(&lf[29],19,"\003syswrite-char/port");
lf[30]=C_h_intern(&lf[30],5,"write");
lf[31]=C_h_intern(&lf[31],21,"\003sysinclude-pathnames");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\016Include path:\011");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\020Home directory:\011");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[35]=C_h_intern(&lf[35],12,"chicken-home");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN version is:\012");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[38]=C_h_intern(&lf[38],15,"chicken-version");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\021\011build platform:\011");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[41]=C_h_intern(&lf[41],14,"build-platform");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\023\011software version:\011");
lf[43]=C_h_intern(&lf[43],16,"software-version");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\020\011software type:\011");
lf[45]=C_h_intern(&lf[45],13,"software-type");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\017\011machine type:\011");
lf[47]=C_h_intern(&lf[47],12,"machine-type");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\022Host information:\012");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\022User information:\011");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\006Date:\011");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[52]=C_h_intern(&lf[52],15,"seconds->string");
lf[53]=C_h_intern(&lf[53],15,"current-seconds");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\0002This is a bug report generated by chicken-bug(1).\012");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\0004\012--------------------------------------------------\012");
lf[56]=C_h_intern(&lf[56],5,"usage");
lf[57]=C_h_intern(&lf[57],4,"exit");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\0017usage: chicken-bug [FILENAME ...]\012\012  -help  -h            show this message"
"\012  -to-stdout           write bug report to standard output\012  -                 "
"   read description from standard input\012\012Generates a bug report file from user i"
"nput or alternatively\012from the contents of files given on the command line.\012");
lf[59]=C_h_intern(&lf[59],10,"user-input");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[61]=C_h_intern(&lf[61],26,"string-concatenate-reverse");
lf[62]=C_h_intern(&lf[62],9,"read-line");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\001jThis is the CHICKEN bug report generator. Please enter a detailed\012descripti"
"on of the problem you have encountered and enter CTRL-D (EOF)\012or a line consisti"
"ng only of \042.\042 to finish. Press CTRL-C to abort the program. You can\012also pass t"
"he description from a file (just abort now and re-invoke\012\042chicken-bug\042 with one "
"or more input files given on the command-line)\012");
lf[64]=C_h_intern(&lf[64],13,"\003systty-port\077");
lf[65]=C_h_intern(&lf[65],18,"current-input-port");
lf[66]=C_h_intern(&lf[66],7,"justify");
lf[67]=C_h_intern(&lf[67],13,"string-append");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[69]=C_h_intern(&lf[69],4,"main");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[71]=C_h_intern(&lf[71],8,"try-mail");
lf[72]=C_h_intern(&lf[72],21,"with-output-to-string");
lf[73]=C_h_intern(&lf[73],12,"mail-headers");
lf[74]=C_h_intern(&lf[74],7,"sprintf");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\033chicken-bug-report.~a-~a-~a");
lf[76]=C_h_intern(&lf[76],19,"seconds->local-time");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\017\012\012User input:\012\012");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\012-to-stdout");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\016\012\012File added: ");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000!one of the following addresses:\012\012");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000Ochicken-janitors@nongnu.org\012chicken-hackers@nongnu.org\012chicken-users@nongnu"
".org");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000#\012A bug report has been written to `");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\025\047.  Please send it to");
lf[90]=C_h_intern(&lf[90],19,"with-output-to-file");
lf[91]=C_h_intern(&lf[91],9,"send-mail");
lf[92]=C_h_intern(&lf[92],13,"mail-date-str");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\006 +0000");
lf[97]=C_h_intern(&lf[97],10,"string-pad");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jan ");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\005 Feb ");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\005 Mar ");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\005 Apr ");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\005 May ");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jun ");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jul ");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\005 Aug ");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\005 Sep ");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\005 Oct ");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\005 Nov ");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\005 Dec ");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\005Sun, ");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\005Mon, ");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\005Tue, ");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\005Wed, ");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\005Thu, ");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\005Fri, ");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\005Sat, ");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\006Date: ");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000;From: \042chicken-bug user\042 <chicken-bug-command@callcc.org>\015\012");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\0006To: \042Chicken Janitors\042 <chicken-janitors@nongnu.org>\015\012");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000)Subject: Automated chicken-bug output -- ");
lf[122]=C_h_intern(&lf[122],17,"seconds->utc-time");
lf[123]=C_h_intern(&lf[123],9,"mail-read");
lf[124]=C_h_intern(&lf[124],9,"substring");
lf[125]=C_h_intern(&lf[125],9,"condition");
lf[126]=C_h_intern(&lf[126],17,"close-output-port");
lf[127]=C_h_intern(&lf[127],16,"close-input-port");
lf[128]=C_h_intern(&lf[128],22,"with-exception-handler");
lf[129]=C_h_intern(&lf[129],30,"call-with-current-continuation");
lf[130]=C_h_intern(&lf[130],10,"mail-write");
lf[131]=C_h_intern(&lf[131],10,"mail-check");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\010 failed.");
lf[133]=C_h_intern(&lf[133],11,"tcp-connect");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000Vok.\012\012Bug report successfully mailed to the Chicken maintainers.\012Thank you v"
"ery much!\012\012");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\004QUIT");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\004\015\012\015\012");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\005\015\012.\015\012");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\006DATA\015\012");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\047RCPT TO:<chicken-janitors@nongnu.org>\015\012");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000,MAIL FROM:<chicken-bug-command@callcc.org>\015\012");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\021HELO callcc.org\015\012");
lf[142]=C_h_intern(&lf[142],6,"print*");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\016connecting to ");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\007, try #");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[146]=C_h_intern(&lf[146],7,"call/cc");
lf[147]=C_h_intern(&lf[147],25,"\003sysimplicit-exit-handler");
lf[148]=C_h_intern(&lf[148],22,"command-line-arguments");
C_register_lf2(lf,149,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_332,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k330 */
static void C_ccall f_332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k333 in k330 */
static void C_ccall f_335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_338,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k336 in k333 in k330 */
static void C_ccall f_338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_341,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k339 in k336 in k333 in k330 */
static void C_ccall f_341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_344,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_350,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_353,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_353,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! user-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_359,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! collect-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_369,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[56]+1 /* (set! usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_655,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[59]+1 /* (set! user-input ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_664,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[66]+1 /* (set! justify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_711,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[69]+1 /* (set! main ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_730,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[71]+1 /* (set! try-mail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_876,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[92]+1 /* (set! mail-date-str ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_917,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[73]+1 /* (set! mail-headers ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1105,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[123]+1 /* (set! mail-read ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1123,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[130]+1 /* (set! mail-write ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1209,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[131]+1 /* (set! mail-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1278,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[91]+1 /* (set! send-mail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1299,tmp=(C_word)a,a+=2,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1413,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1423,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 271  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[148]))(2,*((C_word*)lf[148]+1),t16);}

/* k1421 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 271  main */
((C_proc3)C_retrieve_proc(*((C_word*)lf[69]+1)))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],t1);}

/* k1411 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1416,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1419,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[147]))(2,*((C_word*)lf[147]+1),t3);}

/* k1417 in k1411 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1414 in k1411 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1299,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1305,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 249  call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[146]+1)))(3,*((C_word*)lf[146]+1),t1,t6);}

/* a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1305(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1305,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_1311(t6,t1,C_fix(1));}

/* doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_fcall f_1311(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1311,NULL,3,t0,t1,t2);}
if(C_truep(C_i_greaterp(t2,C_fix(3)))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* chicken-bug.scm: 253  print* */
((C_proc7)C_retrieve_proc(*((C_word*)lf[142]+1)))(7,*((C_word*)lf[142]+1),t3,lf[143],((C_word*)t0)[6],lf[144],t2,lf[145]);}}

/* k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1324,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1336,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1342,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-bug.scm: 256  call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[129]+1)))(3,*((C_word*)lf[129]+1),t1,t4);}

/* a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1348(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1348,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1410,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 258  mail-read */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k1408 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 258  mail-check */
((C_proc7)C_retrieve_proc(*((C_word*)lf[131]+1)))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(220),((C_word*)t0)[2]);}

/* k1350 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1406,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 259  mail-write */
((C_proc5)C_retrieve_proc(*((C_word*)lf[130]+1)))(5,*((C_word*)lf[130]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[141]);}

/* k1404 in k1350 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 259  mail-check */
((C_proc7)C_retrieve_proc(*((C_word*)lf[131]+1)))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1353 in k1350 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1402,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 260  mail-write */
((C_proc5)C_retrieve_proc(*((C_word*)lf[130]+1)))(5,*((C_word*)lf[130]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[140]);}

/* k1400 in k1353 in k1350 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 260  mail-check */
((C_proc7)C_retrieve_proc(*((C_word*)lf[131]+1)))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1356 in k1353 in k1350 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1398,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 261  mail-write */
((C_proc5)C_retrieve_proc(*((C_word*)lf[130]+1)))(5,*((C_word*)lf[130]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[139]);}

/* k1396 in k1356 in k1353 in k1350 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 261  mail-check */
((C_proc7)C_retrieve_proc(*((C_word*)lf[131]+1)))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1359 in k1356 in k1353 in k1350 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1394,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 262  mail-write */
((C_proc5)C_retrieve_proc(*((C_word*)lf[130]+1)))(5,*((C_word*)lf[130]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[138]);}

/* k1392 in k1359 in k1356 in k1353 in k1350 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 262  mail-check */
((C_proc7)C_retrieve_proc(*((C_word*)lf[131]+1)))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(354),((C_word*)t0)[2]);}

/* k1362 in k1359 in k1356 in k1353 in k1350 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1367,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1386,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1390,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 263  string-append */
((C_proc7)C_retrieve_proc(*((C_word*)lf[67]+1)))(7,*((C_word*)lf[67]+1),t4,((C_word*)t0)[4],((C_word*)t0)[3],lf[136],((C_word*)t0)[2],lf[137]);}

/* k1388 in k1362 in k1359 in k1356 in k1353 in k1350 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 263  mail-write */
((C_proc5)C_retrieve_proc(*((C_word*)lf[130]+1)))(5,*((C_word*)lf[130]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1384 in k1362 in k1359 in k1356 in k1353 in k1350 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 263  mail-check */
((C_proc7)C_retrieve_proc(*((C_word*)lf[131]+1)))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 264  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t2,lf[135],((C_word*)t0)[3]);}

/* k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1373,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 265  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t2,((C_word*)t0)[2]);}

/* k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1376,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 266  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t2,((C_word*)t0)[2]);}

/* k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 267  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[134]);}

/* k1377 in k1374 in k1371 in k1368 in k1365 in k1362 in k1359 in k1356 in k1353 in k1350 in a1347 in a1341 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 268  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* a1335 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1336,2,t0,t1);}
/* chicken-bug.scm: 255  tcp-connect */
((C_proc4)C_retrieve_symbol_proc(lf[133]))(4,*((C_word*)lf[133]+1),t1,((C_word*)t0)[2],C_fix(25));}

/* k1322 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 269  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[132]);}

/* k1325 in k1322 in k1319 in doloop276 in a1304 in send-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1327,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1311(t3,((C_word*)t0)[2],t2);}

/* mail-check in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1278(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_1278,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t4)?C_i_nequalp(t4,t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1288,a[2]=t3,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 244  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t8,t2);}}

/* k1286 in mail-check in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1291,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 245  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t2,((C_word*)t0)[2]);}

/* k1289 in k1286 in mail-check in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 246  k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* mail-write in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1209,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1213,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1224,a[2]=t4,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[129]+1)))(3,*((C_word*)lf[129]+1),t5,t6);}

/* a1223 in mail-write in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1224,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1230,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1254,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t1,t3,t4);}

/* a1253 in a1223 in mail-write in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1260,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1266,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1265 in a1253 in a1223 in mail-write in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1266(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1266r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1266r(t0,t1,t2);}}

static void C_ccall f_1266r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1272,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k240245 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1271 in a1265 in a1253 in a1223 in mail-write in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1272,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1259 in a1253 in a1223 in mail-write in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1260,2,t0,t1);}
/* chicken-bug.scm: 234  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1229 in a1223 in mail-write in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1230,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1236,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* k240245 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1235 in a1229 in a1223 in mail-write in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1236,2,t0,t1);}
t2=C_i_structurep(((C_word*)t0)[4],lf[125]);
t3=(C_truep(t2)?C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1243,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 235  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t4,((C_word*)t0)[2]);}

/* k1241 in a1235 in a1229 in a1223 in mail-write in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1246,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 235  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t2,((C_word*)t0)[2]);}

/* k1244 in k1241 in a1235 in a1229 in a1223 in mail-write in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k1211 in mail-write in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g243244 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1214 in k1211 in mail-write in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-bug.scm: 237  mail-read */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* mail-read in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1123,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1127,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1155,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[129]+1)))(3,*((C_word*)lf[129]+1),t4,t5);}

/* a1154 in mail-read in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1155(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1155,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1161,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1185,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t1,t3,t4);}

/* a1184 in a1154 in mail-read in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1191,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1197,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1196 in a1184 in a1154 in mail-read in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1197r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1197r(t0,t1,t2);}}

static void C_ccall f_1197r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1203,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k208213 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1202 in a1196 in a1184 in a1154 in mail-read in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1203,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1190 in a1184 in a1154 in mail-read in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1191,2,t0,t1);}
/* chicken-bug.scm: 225  read-line */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t1,((C_word*)t0)[2]);}

/* a1160 in a1154 in mail-read in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1161,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1167,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* k208213 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1166 in a1160 in a1154 in mail-read in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1167,2,t0,t1);}
t2=C_i_structurep(((C_word*)t0)[4],lf[125]);
t3=(C_truep(t2)?C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1174,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 226  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t4,((C_word*)t0)[2]);}

/* k1172 in a1166 in a1160 in a1154 in mail-read in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1177,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 226  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t2,((C_word*)t0)[2]);}

/* k1175 in k1172 in a1166 in a1160 in a1154 in mail-read in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k1125 in mail-read in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g211212 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1128 in k1125 in mail-read in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1130,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_string_ref(t1,C_fix(0));
if(C_truep(C_u_i_char_numericp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1146,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 229  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[124]+1)))(5,*((C_word*)lf[124]+1),t3,t1,C_fix(0),C_fix(3));}
else{
/* chicken-bug.scm: 230  mail-read */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1144 in k1128 in k1125 in mail-read in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 229  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* mail-headers in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1113,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1117,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1121,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 219  current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[53]))(2,*((C_word*)lf[53]+1),t4);}

/* k1119 in mail-headers in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 219  seconds->utc-time */
((C_proc3)C_retrieve_symbol_proc(lf[122]))(3,*((C_word*)lf[122]+1),((C_word*)t0)[2],t1);}

/* k1115 in mail-headers in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 219  mail-date-str */
((C_proc3)C_retrieve_proc(*((C_word*)lf[92]+1)))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t1);}

/* k1111 in mail-headers in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 218  string-append */
((C_proc8)C_retrieve_proc(*((C_word*)lf[67]+1)))(8,*((C_word*)lf[67]+1),((C_word*)t0)[2],lf[117],t1,lf[118],lf[119],lf[120],lf[121]);}

/* mail-date-str in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_917(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_917,3,t0,t1,t2);}
t3=C_i_vector_ref(t2,C_fix(6));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_928,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_928(t5,lf[110]);
case C_fix(1):
t5=t4;
f_928(t5,lf[111]);
case C_fix(2):
t5=t4;
f_928(t5,lf[112]);
case C_fix(3):
t5=t4;
f_928(t5,lf[113]);
case C_fix(4):
t5=t4;
f_928(t5,lf[114]);
case C_fix(5):
t5=t4;
f_928(t5,lf[115]);
default:
t5=C_eqp(t3,C_fix(6));
t6=t4;
f_928(t6,(C_truep(t5)?lf[116]:C_SCHEME_UNDEFINED));}}

/* k926 in mail-date-str in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_fcall f_928(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_928,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_932,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1060,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_vector_ref(((C_word*)t0)[3],C_fix(3));
/* chicken-bug.scm: 194  number->string */
C_number_to_string(3,0,t3,t4);}

/* k1058 in k926 in mail-date-str in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_1060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 194  string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[97]))(5,*((C_word*)lf[97]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k930 in k926 in mail-date-str in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_932,2,t0,t1);}
t2=C_i_vector_ref(((C_word*)t0)[4],C_fix(4));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
switch(t2){
case C_fix(0):
t4=t3;
f_939(t4,lf[98]);
case C_fix(1):
t4=t3;
f_939(t4,lf[99]);
case C_fix(2):
t4=t3;
f_939(t4,lf[100]);
case C_fix(3):
t4=t3;
f_939(t4,lf[101]);
case C_fix(4):
t4=t3;
f_939(t4,lf[102]);
case C_fix(5):
t4=t3;
f_939(t4,lf[103]);
case C_fix(6):
t4=t3;
f_939(t4,lf[104]);
case C_fix(7):
t4=t3;
f_939(t4,lf[105]);
case C_fix(8):
t4=t3;
f_939(t4,lf[106]);
case C_fix(9):
t4=t3;
f_939(t4,lf[107]);
case C_fix(10):
t4=t3;
f_939(t4,lf[108]);
case C_fix(11):
t4=t3;
f_939(t4,lf[109]);
default:
t4=C_SCHEME_UNDEFINED;
t5=t3;
f_939(t5,t4);}}

/* k937 in k930 in k926 in mail-date-str in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_fcall f_939(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_939,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_943,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=C_i_vector_ref(((C_word*)t0)[2],C_fix(5));
t4=C_a_i_plus(&a,2,C_fix(1900),t3);
/* chicken-bug.scm: 208  number->string */
C_number_to_string(3,0,t2,t4);}

/* k941 in k937 in k930 in k926 in mail-date-str in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_947,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_975,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_vector_ref(((C_word*)t0)[2],C_fix(2));
/* chicken-bug.scm: 210  number->string */
C_number_to_string(3,0,t3,t4);}

/* k973 in k941 in k937 in k930 in k926 in mail-date-str in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 210  string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[97]))(5,*((C_word*)lf[97]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k945 in k941 in k937 in k930 in k926 in mail-date-str in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_951,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_967,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_vector_ref(((C_word*)t0)[2],C_fix(1));
/* chicken-bug.scm: 212  number->string */
C_number_to_string(3,0,t3,t4);}

/* k965 in k945 in k941 in k937 in k930 in k926 in mail-date-str in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 212  string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[97]))(5,*((C_word*)lf[97]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k949 in k945 in k941 in k937 in k930 in k926 in mail-date-str in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_955,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_959,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* chicken-bug.scm: 214  number->string */
C_number_to_string(3,0,t3,t4);}

/* k957 in k949 in k945 in k941 in k937 in k930 in k926 in mail-date-str in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 214  string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[97]))(5,*((C_word*)lf[97]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k953 in k949 in k945 in k941 in k937 in k930 in k926 in mail-date-str in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 185  string-append */
((C_proc13)C_retrieve_proc(*((C_word*)lf[67]+1)))(13,*((C_word*)lf[67]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[93],((C_word*)t0)[3],lf[94],((C_word*)t0)[2],lf[95],t1,lf[96]);}

/* try-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_876,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_886,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_894,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 175  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[90]))(4,*((C_word*)lf[90]+1),t6,t3,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_901,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=C_i_car(t2);
/* chicken-bug.scm: 181  send-mail */
((C_proc6)C_retrieve_proc(*((C_word*)lf[91]+1)))(6,*((C_word*)lf[91]+1),t6,t7,t5,t4,t3);}}

/* k899 in try-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_i_cdr(((C_word*)t0)[5]);
/* chicken-bug.scm: 182  try-mail */
((C_proc6)C_retrieve_proc(*((C_word*)lf[71]+1)))(6,*((C_word*)lf[71]+1),((C_word*)t0)[6],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a893 in try-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_894,2,t0,t1);}
/* chicken-bug.scm: 176  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t1,((C_word*)t0)[2]);}

/* k884 in try-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_889,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 179  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),t2,lf[88],((C_word*)t0)[2],lf[89]);}

/* k887 in k884 in try-mail in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 180  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[86],lf[87]);}

/* main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_730(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_730,3,t0,t1,t2);}
t3=lf[70];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_734,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_811,a[2]=t11,a[3]=t8,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_811(t13,t9,t2);}

/* loop139 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_fcall f_811(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_811,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_819,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_863,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g146147 */
t6=t3;
f_819(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k861 in loop139 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_811(t3,((C_word*)t0)[2],t2);}

/* g146 in loop139 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_fcall f_819(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_819,NULL,3,t0,t1,t2);}
if(C_truep(C_i_string_equal_p(lf[78],t2))){
t3=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_831,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_835,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 129  user-input */
((C_proc2)C_retrieve_proc(*((C_word*)lf[59]+1)))(2,*((C_word*)lf[59]+1),t5);}
else{
t3=t2;
if(C_truep((C_truep(C_i_equalp(t3,lf[80]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[81]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[82]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t4=t1;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f1515,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 84   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t5,lf[58]);}
else{
if(C_truep(C_i_string_equal_p(lf[83],t2))){
t4=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_856,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_860,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 140  read-all */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t6,t2);}}}}

/* k858 in g146 in loop139 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 137  string-append */
((C_proc7)C_retrieve_proc(*((C_word*)lf[67]+1)))(7,*((C_word*)lf[67]+1),((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],lf[84],((C_word*)t0)[2],lf[85],t1);}

/* k854 in g146 in loop139 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f1515 in g146 in loop139 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 96   exit */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),((C_word*)t0)[2],C_fix(0));}

/* k833 in g146 in loop139 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 129  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[67]+1)))(5,*((C_word*)lf[67]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[79],t1);}

/* k829 in g146 in loop139 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k732 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_737,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=t2;
f_737(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_805,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_809,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 143  user-input */
((C_proc2)C_retrieve_proc(*((C_word*)lf[59]+1)))(2,*((C_word*)lf[59]+1),t4);}}

/* k807 in k732 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 143  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[67]+1)))(5,*((C_word*)lf[67]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[77],t1);}

/* k803 in k732 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_737(t3,t2);}

/* k735 in k732 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_fcall f_737(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_737,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 144  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t2);}

/* k738 in k735 in k732 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_801,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 145  current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[53]))(2,*((C_word*)lf[53]+1),t3);}

/* k799 in k738 in k735 in k732 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 145  seconds->local-time */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k741 in k738 in k735 in k732 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_743,2,t0,t1);}
t2=C_i_vector_ref(t1,C_fix(3));
t3=C_i_vector_ref(t1,C_fix(4));
t4=C_i_vector_ref(t1,C_fix(5));
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_758,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 151  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t5,((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=C_a_i_plus(&a,2,C_fix(1900),t4);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_793,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 155  justify */
((C_proc3)C_retrieve_proc(*((C_word*)lf[66]+1)))(3,*((C_word*)lf[66]+1),t7,t3);}}

/* k791 in k741 in k738 in k735 in k732 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_797,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 155  justify */
((C_proc3)C_retrieve_proc(*((C_word*)lf[66]+1)))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k795 in k791 in k741 in k738 in k735 in k732 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 155  sprintf */
((C_proc6)C_retrieve_proc(*((C_word*)lf[74]+1)))(6,*((C_word*)lf[74]+1),((C_word*)t0)[4],lf[75],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k766 in k741 in k738 in k735 in k732 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_772,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 156  mail-headers */
((C_proc2)C_retrieve_proc(*((C_word*)lf[73]+1)))(2,*((C_word*)lf[73]+1),t2);}

/* k770 in k766 in k741 in k738 in k735 in k732 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_776,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_778,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 157  with-output-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),t2,t3);}

/* a777 in k770 in k766 in k741 in k738 in k735 in k732 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_782,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 159  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k780 in a777 in k770 in k766 in k741 in k738 in k735 in k732 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 160  collect-info */
((C_proc2)C_retrieve_proc(*((C_word*)lf[3]+1)))(2,*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* k774 in k770 in k766 in k741 in k738 in k735 in k732 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 153  try-mail */
((C_proc6)C_retrieve_proc(*((C_word*)lf[71]+1)))(6,*((C_word*)lf[71]+1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k756 in k741 in k738 in k735 in k732 in main in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 152  collect-info */
((C_proc2)C_retrieve_proc(*((C_word*)lf[3]+1)))(2,*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* justify in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_711(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_711,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_715,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 116  number->string */
C_number_to_string(3,0,t3,t2);}

/* k713 in justify in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_string_length(t1);
if(C_truep(C_i_greaterp(t2,C_fix(1)))){
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* chicken-bug.scm: 119  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[2],lf[68],t1);}}

/* user-input in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_668,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_702,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_709,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 99   current-input-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[65]+1)))(2,*((C_word*)lf[65]+1),t4);}

/* k707 in user-input in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 99   ##sys#tty-port? */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),((C_word*)t0)[2],t1);}

/* k700 in user-input in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-bug.scm: 100  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[63]);}
else{
t2=((C_word*)t0)[2];
f_668(2,t2,C_SCHEME_UNDEFINED);}}

/* k666 in user-input in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_668,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_673,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_673(t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k666 in user-input in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_fcall f_673(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_673,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_677,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 110  read-line */
((C_proc2)C_retrieve_symbol_proc(lf[62]))(2,*((C_word*)lf[62]+1),t3);}

/* k675 in loop in k666 in user-input in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_677,2,t0,t1);}
t2=C_eofp(t1);
t3=(C_truep(t2)?t2:C_i_string_equal_p(lf[60],t1));
if(C_truep(t3)){
/* chicken-bug.scm: 112  string-concatenate-reverse */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* chicken-bug.scm: 113  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_673(t5,((C_word*)t0)[4],t4);}}

/* usage in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_655(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_655,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_659,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 84   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t3,lf[58]);}

/* k657 in usage in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 96   exit */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_373,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 50   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[55]);}

/* k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 51   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[54]);}

/* k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_649,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_653,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 52   current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[53]))(2,*((C_word*)lf[53]+1),t4);}

/* k651 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 52   seconds->string */
((C_proc3)C_retrieve_symbol_proc(lf[52]))(3,*((C_word*)lf[52]+1),((C_word*)t0)[2],t1);}

/* k647 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 52   print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[50],t1,lf[51]);}

/* k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_379,2,t0,t1);}
t2=*((C_word*)lf[4]+1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_382,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t3,lf[49],t2);}

/* k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_645,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f1508,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 47   current-user-id */
((C_proc2)C_retrieve_symbol_proc(lf[2]))(2,*((C_word*)lf[2]+1),t4);}

/* f1508 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 47   user-information */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

/* k643 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[30]+1)))(4,*((C_word*)lf[30]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[29]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_391,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[29]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_394,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 54   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[48]);}

/* k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_641,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 55   machine-type */
((C_proc2)C_retrieve_symbol_proc(lf[47]))(2,*((C_word*)lf[47]+1),t3);}

/* k639 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 55   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[46],t1);}

/* k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_400,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_637,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 56   software-type */
((C_proc2)C_retrieve_symbol_proc(lf[45]))(2,*((C_word*)lf[45]+1),t3);}

/* k635 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 56   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[44],t1);}

/* k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_403,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_633,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 57   software-version */
((C_proc2)C_retrieve_symbol_proc(lf[43]))(2,*((C_word*)lf[43]+1),t3);}

/* k631 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 57   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[42],t1);}

/* k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_406,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_629,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 58   build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[41]))(2,*((C_word*)lf[41]+1),t3);}

/* k627 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 58   print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[39],t1,lf[40]);}

/* k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_409,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_625,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 59   chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t3,C_SCHEME_TRUE);}

/* k623 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 59   print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[36],t1,lf[37]);}

/* k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_412,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_621,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 60   chicken-home */
((C_proc2)C_retrieve_symbol_proc(lf[35]))(2,*((C_word*)lf[35]+1),t3);}

/* k619 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 60   print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[33],t1,lf[34]);}

/* k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_412,2,t0,t1);}
t2=*((C_word*)lf[4]+1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_415,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t3,lf[32],t2);}

/* k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[30]+1)))(4,*((C_word*)lf[30]+1),t2,C_retrieve(lf[31]),((C_word*)t0)[2]);}

/* k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[29]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_424,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[29]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_427,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 62   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[28]);}

/* k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_430,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_496,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_578,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_582,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_584,a[2]=t6,a[3]=t11,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_584(t13,t9,C_retrieve(lf[27]));}

/* loop63 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_fcall f_584(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_584,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[26]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_613,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g7980 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k611 in loop63 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_613,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop6376 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_584(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop6376 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_584(t6,((C_word*)t0)[3],t5);}}

/* k580 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 70   sort */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),((C_word*)t0)[2],t1,*((C_word*)lf[25]+1));}

/* k576 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 70   chop */
((C_proc4)C_retrieve_symbol_proc(lf[23]))(4,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1,C_fix(5));}

/* k494 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_496,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_498,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_498(t5,((C_word*)t0)[2],t1);}

/* loop30 in k494 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_fcall f_498(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_498,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_563,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_510,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 65   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t5,lf[22]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k508 in loop30 in k494 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_510,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_515,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_515(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop42 in k508 in loop30 in k494 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_fcall f_515(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_515,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_549,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[4]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_527,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k525 in loop42 in k508 in loop30 in k494 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_534,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_538,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_string_length(((C_word*)t0)[2]);
t5=C_fixnum_difference(C_fix(16),t4);
/* chicken-bug.scm: 68   fxmax */
((C_proc4)C_retrieve_proc(*((C_word*)lf[21]+1)))(4,*((C_word*)lf[21]+1),t3,C_fix(1),t5);}

/* k536 in k525 in loop42 in k508 in loop30 in k494 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 68   make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[20]+1)))(4,*((C_word*)lf[20]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k532 in k525 in loop42 in k508 in loop30 in k494 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k547 in loop42 in k508 in loop30 in k494 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_515(t3,((C_word*)t0)[2],t2);}

/* k561 in loop30 in k494 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_498(t3,((C_word*)t0)[2],t2);}

/* k428 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_433,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 71   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[19]);}

/* k431 in k428 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_436,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_478,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_492,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}

/* k490 in k431 in k428 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 72   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[17]))(4,*((C_word*)lf[17]+1),((C_word*)t0)[2],t1,lf[18]);}

/* k476 in k431 in k428 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_480,tmp=(C_word)a,a+=2,tmp);
/* chicken-bug.scm: 72   with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[16]))(4,*((C_word*)lf[16]+1),((C_word*)t0)[2],t1,t2);}

/* a479 in k476 in k431 in k428 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_488,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 74   read-all */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}

/* k486 in a479 in k476 in k431 in k428 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 74   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1);}

/* k434 in k431 in k428 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_439,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 75   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t2);}

/* k437 in k434 in k431 in k428 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_448,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_474,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}

/* k472 in k437 in k434 in k431 in k428 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_string_equal_p(t1,lf[12]))){
/* chicken-bug.scm: 76   feature? */
((C_proc3)C_retrieve_symbol_proc(lf[13]))(3,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[14]);}
else{
t2=((C_word*)t0)[2];
f_448(2,t2,C_SCHEME_FALSE);}}

/* k446 in k437 in k434 in k431 in k428 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_448,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_451,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 77   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[11]);}
else{
/* chicken-bug.scm: 81   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),((C_word*)t0)[2]);}}

/* k449 in k446 in k437 in k434 in k431 in k428 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_456,tmp=(C_word)a,a+=2,tmp);
/* chicken-bug.scm: 78   with-input-from-pipe */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[9],t2);}

/* a455 in k449 in k446 in k437 in k434 in k431 in k428 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_464,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 80   read-all */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}

/* k462 in a455 in k449 in k446 in k437 in k434 in k431 in k428 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 80   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1);}

/* k440 in k437 in k434 in k431 in k428 in k425 in k422 in k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in collect-info in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 81   newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),((C_word*)t0)[2]);}

/* user-id in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_367,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 47   current-user-id */
((C_proc2)C_retrieve_symbol_proc(lf[2]))(2,*((C_word*)lf[2]+1),t2);}

/* k365 in user-id in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 */
static void C_ccall f_367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 47   user-information */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[182] = {
{"toplevel:chicken_bug_scm",(void*)C_toplevel},
{"f_332:chicken_bug_scm",(void*)f_332},
{"f_335:chicken_bug_scm",(void*)f_335},
{"f_338:chicken_bug_scm",(void*)f_338},
{"f_341:chicken_bug_scm",(void*)f_341},
{"f_344:chicken_bug_scm",(void*)f_344},
{"f_347:chicken_bug_scm",(void*)f_347},
{"f_350:chicken_bug_scm",(void*)f_350},
{"f_353:chicken_bug_scm",(void*)f_353},
{"f_1423:chicken_bug_scm",(void*)f_1423},
{"f_1413:chicken_bug_scm",(void*)f_1413},
{"f_1419:chicken_bug_scm",(void*)f_1419},
{"f_1416:chicken_bug_scm",(void*)f_1416},
{"f_1299:chicken_bug_scm",(void*)f_1299},
{"f_1305:chicken_bug_scm",(void*)f_1305},
{"f_1311:chicken_bug_scm",(void*)f_1311},
{"f_1321:chicken_bug_scm",(void*)f_1321},
{"f_1342:chicken_bug_scm",(void*)f_1342},
{"f_1348:chicken_bug_scm",(void*)f_1348},
{"f_1410:chicken_bug_scm",(void*)f_1410},
{"f_1352:chicken_bug_scm",(void*)f_1352},
{"f_1406:chicken_bug_scm",(void*)f_1406},
{"f_1355:chicken_bug_scm",(void*)f_1355},
{"f_1402:chicken_bug_scm",(void*)f_1402},
{"f_1358:chicken_bug_scm",(void*)f_1358},
{"f_1398:chicken_bug_scm",(void*)f_1398},
{"f_1361:chicken_bug_scm",(void*)f_1361},
{"f_1394:chicken_bug_scm",(void*)f_1394},
{"f_1364:chicken_bug_scm",(void*)f_1364},
{"f_1390:chicken_bug_scm",(void*)f_1390},
{"f_1386:chicken_bug_scm",(void*)f_1386},
{"f_1367:chicken_bug_scm",(void*)f_1367},
{"f_1370:chicken_bug_scm",(void*)f_1370},
{"f_1373:chicken_bug_scm",(void*)f_1373},
{"f_1376:chicken_bug_scm",(void*)f_1376},
{"f_1379:chicken_bug_scm",(void*)f_1379},
{"f_1336:chicken_bug_scm",(void*)f_1336},
{"f_1324:chicken_bug_scm",(void*)f_1324},
{"f_1327:chicken_bug_scm",(void*)f_1327},
{"f_1278:chicken_bug_scm",(void*)f_1278},
{"f_1288:chicken_bug_scm",(void*)f_1288},
{"f_1291:chicken_bug_scm",(void*)f_1291},
{"f_1209:chicken_bug_scm",(void*)f_1209},
{"f_1224:chicken_bug_scm",(void*)f_1224},
{"f_1254:chicken_bug_scm",(void*)f_1254},
{"f_1266:chicken_bug_scm",(void*)f_1266},
{"f_1272:chicken_bug_scm",(void*)f_1272},
{"f_1260:chicken_bug_scm",(void*)f_1260},
{"f_1230:chicken_bug_scm",(void*)f_1230},
{"f_1236:chicken_bug_scm",(void*)f_1236},
{"f_1243:chicken_bug_scm",(void*)f_1243},
{"f_1246:chicken_bug_scm",(void*)f_1246},
{"f_1213:chicken_bug_scm",(void*)f_1213},
{"f_1216:chicken_bug_scm",(void*)f_1216},
{"f_1123:chicken_bug_scm",(void*)f_1123},
{"f_1155:chicken_bug_scm",(void*)f_1155},
{"f_1185:chicken_bug_scm",(void*)f_1185},
{"f_1197:chicken_bug_scm",(void*)f_1197},
{"f_1203:chicken_bug_scm",(void*)f_1203},
{"f_1191:chicken_bug_scm",(void*)f_1191},
{"f_1161:chicken_bug_scm",(void*)f_1161},
{"f_1167:chicken_bug_scm",(void*)f_1167},
{"f_1174:chicken_bug_scm",(void*)f_1174},
{"f_1177:chicken_bug_scm",(void*)f_1177},
{"f_1127:chicken_bug_scm",(void*)f_1127},
{"f_1130:chicken_bug_scm",(void*)f_1130},
{"f_1146:chicken_bug_scm",(void*)f_1146},
{"f_1105:chicken_bug_scm",(void*)f_1105},
{"f_1121:chicken_bug_scm",(void*)f_1121},
{"f_1117:chicken_bug_scm",(void*)f_1117},
{"f_1113:chicken_bug_scm",(void*)f_1113},
{"f_917:chicken_bug_scm",(void*)f_917},
{"f_928:chicken_bug_scm",(void*)f_928},
{"f_1060:chicken_bug_scm",(void*)f_1060},
{"f_932:chicken_bug_scm",(void*)f_932},
{"f_939:chicken_bug_scm",(void*)f_939},
{"f_943:chicken_bug_scm",(void*)f_943},
{"f_975:chicken_bug_scm",(void*)f_975},
{"f_947:chicken_bug_scm",(void*)f_947},
{"f_967:chicken_bug_scm",(void*)f_967},
{"f_951:chicken_bug_scm",(void*)f_951},
{"f_959:chicken_bug_scm",(void*)f_959},
{"f_955:chicken_bug_scm",(void*)f_955},
{"f_876:chicken_bug_scm",(void*)f_876},
{"f_901:chicken_bug_scm",(void*)f_901},
{"f_894:chicken_bug_scm",(void*)f_894},
{"f_886:chicken_bug_scm",(void*)f_886},
{"f_889:chicken_bug_scm",(void*)f_889},
{"f_730:chicken_bug_scm",(void*)f_730},
{"f_811:chicken_bug_scm",(void*)f_811},
{"f_863:chicken_bug_scm",(void*)f_863},
{"f_819:chicken_bug_scm",(void*)f_819},
{"f_860:chicken_bug_scm",(void*)f_860},
{"f_856:chicken_bug_scm",(void*)f_856},
{"f1515:chicken_bug_scm",(void*)f1515},
{"f_835:chicken_bug_scm",(void*)f_835},
{"f_831:chicken_bug_scm",(void*)f_831},
{"f_734:chicken_bug_scm",(void*)f_734},
{"f_809:chicken_bug_scm",(void*)f_809},
{"f_805:chicken_bug_scm",(void*)f_805},
{"f_737:chicken_bug_scm",(void*)f_737},
{"f_740:chicken_bug_scm",(void*)f_740},
{"f_801:chicken_bug_scm",(void*)f_801},
{"f_743:chicken_bug_scm",(void*)f_743},
{"f_793:chicken_bug_scm",(void*)f_793},
{"f_797:chicken_bug_scm",(void*)f_797},
{"f_768:chicken_bug_scm",(void*)f_768},
{"f_772:chicken_bug_scm",(void*)f_772},
{"f_778:chicken_bug_scm",(void*)f_778},
{"f_782:chicken_bug_scm",(void*)f_782},
{"f_776:chicken_bug_scm",(void*)f_776},
{"f_758:chicken_bug_scm",(void*)f_758},
{"f_711:chicken_bug_scm",(void*)f_711},
{"f_715:chicken_bug_scm",(void*)f_715},
{"f_664:chicken_bug_scm",(void*)f_664},
{"f_709:chicken_bug_scm",(void*)f_709},
{"f_702:chicken_bug_scm",(void*)f_702},
{"f_668:chicken_bug_scm",(void*)f_668},
{"f_673:chicken_bug_scm",(void*)f_673},
{"f_677:chicken_bug_scm",(void*)f_677},
{"f_655:chicken_bug_scm",(void*)f_655},
{"f_659:chicken_bug_scm",(void*)f_659},
{"f_369:chicken_bug_scm",(void*)f_369},
{"f_373:chicken_bug_scm",(void*)f_373},
{"f_376:chicken_bug_scm",(void*)f_376},
{"f_653:chicken_bug_scm",(void*)f_653},
{"f_649:chicken_bug_scm",(void*)f_649},
{"f_379:chicken_bug_scm",(void*)f_379},
{"f_382:chicken_bug_scm",(void*)f_382},
{"f1508:chicken_bug_scm",(void*)f1508},
{"f_645:chicken_bug_scm",(void*)f_645},
{"f_385:chicken_bug_scm",(void*)f_385},
{"f_388:chicken_bug_scm",(void*)f_388},
{"f_391:chicken_bug_scm",(void*)f_391},
{"f_394:chicken_bug_scm",(void*)f_394},
{"f_641:chicken_bug_scm",(void*)f_641},
{"f_397:chicken_bug_scm",(void*)f_397},
{"f_637:chicken_bug_scm",(void*)f_637},
{"f_400:chicken_bug_scm",(void*)f_400},
{"f_633:chicken_bug_scm",(void*)f_633},
{"f_403:chicken_bug_scm",(void*)f_403},
{"f_629:chicken_bug_scm",(void*)f_629},
{"f_406:chicken_bug_scm",(void*)f_406},
{"f_625:chicken_bug_scm",(void*)f_625},
{"f_409:chicken_bug_scm",(void*)f_409},
{"f_621:chicken_bug_scm",(void*)f_621},
{"f_412:chicken_bug_scm",(void*)f_412},
{"f_415:chicken_bug_scm",(void*)f_415},
{"f_418:chicken_bug_scm",(void*)f_418},
{"f_421:chicken_bug_scm",(void*)f_421},
{"f_424:chicken_bug_scm",(void*)f_424},
{"f_427:chicken_bug_scm",(void*)f_427},
{"f_584:chicken_bug_scm",(void*)f_584},
{"f_613:chicken_bug_scm",(void*)f_613},
{"f_582:chicken_bug_scm",(void*)f_582},
{"f_578:chicken_bug_scm",(void*)f_578},
{"f_496:chicken_bug_scm",(void*)f_496},
{"f_498:chicken_bug_scm",(void*)f_498},
{"f_510:chicken_bug_scm",(void*)f_510},
{"f_515:chicken_bug_scm",(void*)f_515},
{"f_527:chicken_bug_scm",(void*)f_527},
{"f_538:chicken_bug_scm",(void*)f_538},
{"f_534:chicken_bug_scm",(void*)f_534},
{"f_549:chicken_bug_scm",(void*)f_549},
{"f_563:chicken_bug_scm",(void*)f_563},
{"f_430:chicken_bug_scm",(void*)f_430},
{"f_433:chicken_bug_scm",(void*)f_433},
{"f_492:chicken_bug_scm",(void*)f_492},
{"f_478:chicken_bug_scm",(void*)f_478},
{"f_480:chicken_bug_scm",(void*)f_480},
{"f_488:chicken_bug_scm",(void*)f_488},
{"f_436:chicken_bug_scm",(void*)f_436},
{"f_439:chicken_bug_scm",(void*)f_439},
{"f_474:chicken_bug_scm",(void*)f_474},
{"f_448:chicken_bug_scm",(void*)f_448},
{"f_451:chicken_bug_scm",(void*)f_451},
{"f_456:chicken_bug_scm",(void*)f_456},
{"f_464:chicken_bug_scm",(void*)f_464},
{"f_442:chicken_bug_scm",(void*)f_442},
{"f_359:chicken_bug_scm",(void*)f_359},
{"f_367:chicken_bug_scm",(void*)f_367},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
