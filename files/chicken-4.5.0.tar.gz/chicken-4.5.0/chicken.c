/* Generated from chicken.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:53
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: chicken.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file chicken.c
   used units: library eval chicken_syntax srfi_1 srfi_4 utils files extras data_structures support compiler optimizer unboxing compiler_syntax scrutinizer driver platform backend srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_4_toplevel)
C_externimport void C_ccall C_srfi_4_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_unboxing_toplevel)
C_externimport void C_ccall C_unboxing_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_syntax_toplevel)
C_externimport void C_ccall C_compiler_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_scrutinizer_toplevel)
C_externimport void C_ccall C_scrutinizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_driver_toplevel)
C_externimport void C_ccall C_driver_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_platform_toplevel)
C_externimport void C_ccall C_platform_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_backend_toplevel)
C_externimport void C_ccall C_backend_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[109];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_404)
static void C_ccall f_404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_407)
static void C_ccall f_407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_410)
static void C_ccall f_410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_413)
static void C_ccall f_413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_416)
static void C_ccall f_416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_419)
static void C_ccall f_419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_422)
static void C_ccall f_422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_425)
static void C_ccall f_425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_428)
static void C_ccall f_428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_431)
static void C_ccall f_431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_434)
static void C_ccall f_434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_437)
static void C_ccall f_437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_440)
static void C_ccall f_440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_443)
static void C_ccall f_443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_446)
static void C_ccall f_446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_449)
static void C_ccall f_449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_452)
static void C_ccall f_452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_455)
static void C_ccall f_455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_458)
static void C_ccall f_458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_462)
static void C_ccall f_462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1514)
static void C_ccall f_1514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1521)
static void C_fcall f_1521(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_fcall f_1524(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_fcall f_1766(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1718)
static void C_fcall f_1718(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1702)
static void C_ccall f_1702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1706)
static void C_ccall f_1706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1540)
static void C_ccall f_1540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1560)
static void C_ccall f_1560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_465)
static void C_ccall f_465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1497)
static void C_ccall f_1497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1491)
static void C_ccall f_1491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_468)
static void C_ccall f_468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1360)
static void C_ccall f_1360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1364)
static void C_ccall f_1364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1464)
static void C_ccall f_1464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1358)
static void C_ccall f_1358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_471)
static void C_ccall f_471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1179)
static void C_ccall f_1179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_fcall f_1312(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1339)
static void C_fcall f_1339(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1192)
static void C_ccall f_1192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1286)
static void C_ccall f_1286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1213)
static void C_ccall f_1213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1211)
static void C_ccall f_1211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1177)
static void C_ccall f_1177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_474)
static void C_ccall f_474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1097)
static void C_ccall f_1097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1101)
static void C_ccall f_1101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1104)
static void C_ccall f_1104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1150)
static void C_ccall f_1150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1153)
static void C_ccall f_1153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1156)
static void C_ccall f_1156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1169)
static void C_ccall f_1169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1159)
static void C_ccall f_1159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1162)
static void C_ccall f_1162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1165)
static void C_ccall f_1165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1095)
static void C_ccall f_1095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_477)
static void C_ccall f_477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1035)
static void C_ccall f_1035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1038)
static void C_ccall f_1038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1076)
static void C_ccall f_1076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1072)
static void C_fcall f_1072(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1029)
static void C_ccall f_1029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_480)
static void C_ccall f_480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1021)
static void C_ccall f_1021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_483)
static void C_ccall f_483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_984)
static void C_ccall f_984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_992)
static void C_ccall f_992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_982)
static void C_ccall f_982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_486)
static void C_ccall f_486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_966)
static void C_ccall f_966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_974)
static void C_ccall f_974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_964)
static void C_ccall f_964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_489)
static void C_ccall f_489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_948)
static void C_ccall f_948(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_956)
static void C_ccall f_956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_946)
static void C_ccall f_946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_492)
static void C_ccall f_492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_930)
static void C_ccall f_930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_938)
static void C_ccall f_938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_928)
static void C_ccall f_928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_495)
static void C_ccall f_495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_912)
static void C_ccall f_912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_920)
static void C_ccall f_920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_910)
static void C_ccall f_910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_498)
static void C_ccall f_498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_894)
static void C_ccall f_894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_892)
static void C_ccall f_892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_501)
static void C_ccall f_501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_876)
static void C_ccall f_876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_884)
static void C_ccall f_884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_874)
static void C_ccall f_874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_504)
static void C_ccall f_504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_507)
static void C_ccall f_507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_867)
static void C_ccall f_867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_863)
static void C_ccall f_863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_855)
static void C_ccall f_855(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_845)
static void C_ccall f_845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_853)
static void C_ccall f_853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_511)
static void C_ccall f_511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_640)
static void C_ccall f_640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_652)
static void C_fcall f_652(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_835)
static void C_ccall f_835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_828)
static void C_ccall f_828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_750)
static void C_ccall f_750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_767)
static void C_ccall f_767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_753)
static void C_ccall f_753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_674)
static void C_ccall f_674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_737)
static void C_ccall f_737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_727)
static void C_ccall f_727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_717)
static void C_ccall f_717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_707)
static void C_ccall f_707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_644)
static void C_ccall f_644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_647)
static void C_ccall f_647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_628)
static void C_ccall f_628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_632)
static void C_ccall f_632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_620)
static void C_ccall f_620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_626)
static void C_ccall f_626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_623)
static void C_ccall f_623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_513)
static void C_ccall f_513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_519)
static void C_fcall f_519(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_554)
static void C_fcall f_554(C_word t0,C_word t1) C_noret;
C_noret_decl(f_580)
static void C_ccall f_580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_576)
static void C_ccall f_576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_533)
static void C_ccall f_533(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1521)
static void C_fcall trf_1521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1521(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1521(t0,t1);}

C_noret_decl(trf_1524)
static void C_fcall trf_1524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1524(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1524(t0,t1);}

C_noret_decl(trf_1766)
static void C_fcall trf_1766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1766(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1766(t0,t1,t2);}

C_noret_decl(trf_1718)
static void C_fcall trf_1718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1718(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1718(t0,t1,t2);}

C_noret_decl(trf_1312)
static void C_fcall trf_1312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1312(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1312(t0,t1,t2);}

C_noret_decl(trf_1339)
static void C_fcall trf_1339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1339(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1339(t0,t1);}

C_noret_decl(trf_1072)
static void C_fcall trf_1072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1072(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1072(t0,t1);}

C_noret_decl(trf_652)
static void C_fcall trf_652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_652(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_652(t0,t1,t2);}

C_noret_decl(trf_519)
static void C_fcall trf_519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_519(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_519(t0,t1,t2,t3,t4);}

C_noret_decl(trf_554)
static void C_fcall trf_554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_554(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_554(t0,t1);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1294)){
C_save(t1);
C_rereclaim2(1294*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,109);
lf[0]=C_h_intern(&lf[0],33,"\003syschicken-ffi-macro-environment");
lf[1]=C_h_intern(&lf[1],27,"\010compilercompiler-arguments");
lf[2]=C_h_intern(&lf[2],29,"\010compilerprocess-command-line");
lf[3]=C_h_intern(&lf[3],7,"reverse");
lf[4]=C_h_intern(&lf[4],14,"string->symbol");
lf[5]=C_h_intern(&lf[5],9,"substring");
lf[6]=C_h_intern(&lf[6],25,"\003sysimplicit-exit-handler");
lf[7]=C_h_intern(&lf[7],17,"user-options-pass");
lf[8]=C_h_intern(&lf[8],4,"exit");
lf[9]=C_h_intern(&lf[9],19,"compile-source-file");
lf[10]=C_h_intern(&lf[10],14,"optimize-level");
lf[11]=C_h_intern(&lf[11],22,"optimize-leaf-routines");
lf[12]=C_h_intern(&lf[12],5,"cons*");
lf[13]=C_h_intern(&lf[13],6,"inline");
lf[14]=C_h_intern(&lf[14],5,"local");
lf[15]=C_h_intern(&lf[15],8,"unboxing");
lf[16]=C_h_intern(&lf[16],6,"unsafe");
lf[17]=C_h_intern(&lf[17],18,"disable-interrupts");
lf[18]=C_h_intern(&lf[18],8,"no-trace");
lf[19]=C_h_intern(&lf[19],5,"block");
lf[20]=C_h_intern(&lf[20],11,"lambda-lift");
lf[21]=C_h_intern(&lf[21],14,"no-lambda-info");
lf[22]=C_h_intern(&lf[22],11,"debug-level");
lf[23]=C_h_intern(&lf[23],25,"\010compilercompiler-warning");
lf[24]=C_h_intern(&lf[24],5,"usage");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000 invalid debug level ~S - ignored");
lf[26]=C_h_intern(&lf[26],31,"\010compilervalid-compiler-options");
lf[27]=C_h_intern(&lf[27],45,"\010compilervalid-compiler-options-with-argument");
lf[28]=C_h_intern(&lf[28],4,"quit");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~s\047 option");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000&invalid compiler option `~a\047 - ignored");
lf[31]=C_h_intern(&lf[31],4,"conc");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[33]=C_h_intern(&lf[33],6,"append");
lf[34]=C_h_intern(&lf[34],4,"argv");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[36]=C_h_intern(&lf[36],6,"remove");
lf[37]=C_h_intern(&lf[37],12,"string-split");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[39]=C_h_intern(&lf[39],24,"get-environment-variable");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN_OPTIONS");
lf[41]=C_h_intern(&lf[41],16,"\003sysmacro-subset");
lf[42]=C_h_intern(&lf[42],28,"\003sysextend-macro-environment");
lf[43]=C_h_intern(&lf[43],20,"foreign-safe-lambda*");
lf[44]=C_h_intern(&lf[44],25,"\004coreforeign-safe-lambda*");
lf[45]=C_h_intern(&lf[45],10,"\003sysappend");
lf[46]=C_h_intern(&lf[46],18,"\003syser-transformer");
lf[47]=C_h_intern(&lf[47],19,"foreign-safe-lambda");
lf[48]=C_h_intern(&lf[48],24,"\004coreforeign-safe-lambda");
lf[49]=C_h_intern(&lf[49],15,"foreign-lambda*");
lf[50]=C_h_intern(&lf[50],20,"\004coreforeign-lambda*");
lf[51]=C_h_intern(&lf[51],14,"foreign-lambda");
lf[52]=C_h_intern(&lf[52],19,"\004coreforeign-lambda");
lf[53]=C_h_intern(&lf[53],17,"foreign-primitive");
lf[54]=C_h_intern(&lf[54],22,"\004coreforeign-primitive");
lf[55]=C_h_intern(&lf[55],23,"define-foreign-variable");
lf[56]=C_h_intern(&lf[56],28,"\004coredefine-foreign-variable");
lf[57]=C_h_intern(&lf[57],19,"define-foreign-type");
lf[58]=C_h_intern(&lf[58],24,"\004coredefine-foreign-type");
lf[59]=C_h_intern(&lf[59],15,"foreign-declare");
lf[60]=C_h_intern(&lf[60],12,"\004coredeclare");
lf[61]=C_h_intern(&lf[61],16,"\003syscheck-syntax");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[63]=C_h_intern(&lf[63],13,"foreign-value");
lf[64]=C_h_intern(&lf[64],10,"\004corebegin");
lf[65]=C_h_intern(&lf[65],14,"symbol->string");
lf[66]=C_h_intern(&lf[66],12,"syntax-error");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a string or symbol");
lf[68]=C_h_intern(&lf[68],6,"gensym");
lf[69]=C_h_intern(&lf[69],5,"code_");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[71]=C_h_intern(&lf[71],12,"foreign-code");
lf[72]=C_h_intern(&lf[72],11,"\004coreinline");
lf[73]=C_h_intern(&lf[73],17,"get-output-string");
lf[74]=C_h_intern(&lf[74],7,"display");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000 \012; return C_SCHEME_UNDEFINED; }\012");
lf[76]=C_h_intern(&lf[76],18,"string-intersperse");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\005() { ");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\016static C_word ");
lf[80]=C_h_intern(&lf[80],18,"open-output-string");
lf[81]=C_h_intern(&lf[81],7,"declare");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[83]=C_h_intern(&lf[83],12,"let-location");
lf[84]=C_h_intern(&lf[84],8,"\004corelet");
lf[85]=C_h_intern(&lf[85],17,"\004corelet-location");
lf[86]=C_h_intern(&lf[86],10,"fold-right");
lf[87]=C_h_intern(&lf[87],10,"append-map");
lf[88]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\000\376\001\000\000\001_");
lf[89]=C_h_intern(&lf[89],15,"define-location");
lf[90]=C_h_intern(&lf[90],29,"\004coredefine-external-variable");
lf[91]=C_h_intern(&lf[91],9,"\004coreset!");
lf[92]=C_h_intern(&lf[92],5,"begin");
lf[93]=C_h_intern(&lf[93],9,"\003syserror");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[95]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[96]=C_h_intern(&lf[96],8,"location");
lf[97]=C_h_intern(&lf[97],13,"\004corelocation");
lf[98]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010location\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[99]=C_h_intern(&lf[99],15,"define-external");
lf[100]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[101]=C_h_intern(&lf[101],5,"quote");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[103]=C_h_intern(&lf[103],29,"\004coreforeign-callback-wrapper");
lf[104]=C_h_intern(&lf[104],6,"lambda");
lf[105]=C_h_intern(&lf[105],6,"define");
lf[106]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376"
"\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[107]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[108]=C_h_intern(&lf[108],21,"\003sysmacro-environment");
C_register_lf2(lf,109,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_404,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k402 */
static void C_ccall f_404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_407,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k405 in k402 */
static void C_ccall f_407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_410,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k408 in k405 in k402 */
static void C_ccall f_410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_413,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k411 in k408 in k405 in k402 */
static void C_ccall f_413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_416,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_419,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_422,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_425,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_428,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_431,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_support_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_434,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_437,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_440,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_unboxing_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_443,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_446,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scrutinizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_449,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_driver_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_452,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_platform_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_455,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_backend_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_458,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_462,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[108]))(2,*((C_word*)lf[108]+1),t2);}

/* k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_465,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1512,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1514,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t4);}

/* a1513 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1514,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1521,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t5))){
t7=C_i_car(t5);
t8=t6;
f_1521(t8,C_i_stringp(t7));}
else{
t7=t6;
f_1521(t7,C_SCHEME_FALSE);}}

/* k1519 in a1513 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_fcall f_1521(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1521,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1524,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=t1;
if(C_truep(t3)){
t4=t2;
f_1524(t4,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t4=C_i_car(((C_word*)t0)[4]);
t5=t2;
f_1524(t5,C_i_symbolp(t4));}
else{
t4=t2;
f_1524(t4,C_SCHEME_FALSE);}}}

/* k1522 in k1519 in a1513 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_fcall f_1524(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1524,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1530,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[61]))(5,*((C_word*)lf[61]+1),t2,lf[99],((C_word*)t0)[5],lf[100]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1621,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[61]))(5,*((C_word*)lf[61]+1),t2,lf[99],((C_word*)t0)[5],lf[106]);}
else{
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[61]))(5,*((C_word*)lf[61]+1),t2,lf[99],((C_word*)t0)[5],lf[107]);}}}

/* k1619 in k1522 in k1519 in a1513 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1621,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[5])?C_i_cadr(((C_word*)t0)[4]):C_i_car(((C_word*)t0)[4]));
t3=C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1634,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* r37 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[105]);}

/* k1632 in k1619 in k1522 in k1519 in a1513 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1634,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[7]);
t3=C_i_car(((C_word*)t0)[7]);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[101],t4);
t6=(C_truep(((C_word*)t0)[6])?C_i_car(((C_word*)t0)[5]):lf[102]);
t7=(C_truep(((C_word*)t0)[6])?C_i_caddr(((C_word*)t0)[5]):C_i_cadr(((C_word*)t0)[5]));
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,lf[101],t8);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t5,a[10]=t6,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1766,a[2]=t11,a[3]=t16,a[4]=t13,tmp=(C_word)a,a+=5,tmp));
t18=((C_word*)t16)[1];
f_1766(t18,t14,((C_word*)t0)[3]);}

/* loop74 in k1632 in k1619 in k1522 in k1519 in a1513 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_fcall f_1766(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1766,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop7487 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop7487 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1762 in k1632 in k1619 in k1522 in k1519 in a1513 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1764,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[101],t2);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1694,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
/* r37 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[104]);}

/* k1692 in k1762 in k1632 in k1619 in k1522 in k1519 in a1513 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1694,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1702,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1718,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_1718(t10,t6,((C_word*)t0)[2]);}

/* loop98 in k1692 in k1762 in k1632 in k1619 in k1522 in k1519 in a1513 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_fcall f_1718(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1718,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop98111 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop98111 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1700 in k1692 in k1762 in k1632 in k1619 in k1522 in k1519 in a1513 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1706,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(C_truep(((C_word*)t0)[3])?C_i_cdddr(((C_word*)t0)[2]):C_i_cddr(((C_word*)t0)[2]));
/* ##sys#append */
t4=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k1704 in k1700 in k1692 in k1762 in k1632 in k1619 in k1522 in k1519 in a1513 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1706,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=C_a_i_cons(&a,2,lf[103],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,((C_word*)t0)[4],t10);
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_a_i_cons(&a,2,((C_word*)t0)[2],t11));}

/* k1528 in k1522 in k1519 in a1513 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1530,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1540,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* r37 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[92]);}

/* k1538 in k1528 in k1522 in k1519 in a1513 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1540,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=C_a_i_cons(&a,2,lf[56],t4);
t6=C_i_cadr(((C_word*)t0)[4]);
t7=C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=C_a_i_cons(&a,2,lf[90],t9);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1560,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=C_i_cddr(((C_word*)t0)[4]);
if(C_truep(C_i_pairp(t12))){
t13=C_i_caddr(((C_word*)t0)[4]);
t14=C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,((C_word*)t0)[3],t14);
t16=C_a_i_cons(&a,2,lf[91],t15);
t17=C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t18=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t11,t17,C_SCHEME_END_OF_LIST);}
else{
/* ##sys#append */
t13=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* k1558 in k1538 in k1528 in k1522 in k1519 in a1513 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1560,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1510 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[99],C_SCHEME_END_OF_LIST,t1);}

/* k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1491,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1493,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t4);}

/* a1492 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1493,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1497,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[61]))(5,*((C_word*)lf[61]+1),t5,lf[96],t2,lf[98]);}

/* k1495 in a1492 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1497,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[97],t3));}

/* k1489 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[96],C_SCHEME_END_OF_LIST,t1);}

/* k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1358,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1360,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t4);}

/* a1359 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1360,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1364,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[61]))(5,*((C_word*)lf[61]+1),t5,lf[89],t2,lf[95]);}

/* k1362 in a1359 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1364,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_caddr(((C_word*)t0)[4]);
t4=C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_1376(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_1376(2,t7,C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[94],t4);}}}

/* k1374 in k1362 in a1359 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1379,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1468,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
((C_proc2)C_retrieve_symbol_proc(lf[68]))(2,*((C_word*)lf[68]+1),t3);}

/* k1466 in k1374 in k1362 in a1359 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r130 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1377 in k1374 in k1362 in a1359 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1386,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* r130 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[92]);}

/* k1384 in k1377 in k1374 in k1362 in a1359 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1464,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[65]+1)))(3,*((C_word*)lf[65]+1),t2,((C_word*)t0)[4]);}

/* k1462 in k1384 in k1377 in k1374 in k1362 in a1359 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1464,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=C_a_i_cons(&a,2,lf[56],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,C_SCHEME_FALSE,t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=C_a_i_cons(&a,2,lf[90],t9);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1406,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t10,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t12=C_i_car(((C_word*)t0)[2]);
t13=C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=C_a_i_cons(&a,2,((C_word*)t0)[6],t13);
t15=C_a_i_cons(&a,2,lf[91],t14);
t16=C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t17=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t11,t16,C_SCHEME_END_OF_LIST);}
else{
/* ##sys#append */
t12=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* k1404 in k1462 in k1384 in k1377 in k1374 in k1362 in a1359 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1406,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1356 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[89],C_SCHEME_END_OF_LIST,t1);}

/* k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1177,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1179,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t4);}

/* a1178 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1179,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1183,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[61]))(5,*((C_word*)lf[61]+1),t5,lf[83],t2,lf[88]);}

/* k1181 in a1178 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1183,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_cddr(((C_word*)t0)[4]);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1192,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1312,a[2]=t5,a[3]=t10,a[4]=t7,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_1312(t12,t8,t2);}

/* loop159 in k1181 in a1178 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_fcall f_1312(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1312,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1339,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1350,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g175176 */
t6=t3;
f_1339(t6,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1348 in loop159 in k1181 in a1178 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1350,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop159172 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1312(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop159172 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1312(t6,((C_word*)t0)[3],t5);}}

/* g175 in loop159 in k1181 in a1178 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_fcall f_1339(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1339,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1347,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* gensym */
((C_proc2)C_retrieve_symbol_proc(lf[68]))(2,*((C_word*)lf[68]+1),t2);}

/* k1345 in g175 in loop159 in k1181 in a1178 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* r151 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1190 in k1181 in a1178 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1203,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1288,tmp=(C_word)a,a+=2,tmp);
/* append-map */
((C_proc5)C_retrieve_symbol_proc(lf[87]))(5,*((C_word*)lf[87]+1),t2,t3,((C_word*)t0)[3],t1);}

/* a1287 in k1190 in k1181 in a1178 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1288,4,t0,t1,t2,t3);}
t4=C_i_cddr(t2);
if(C_truep(C_i_pairp(t4))){
t5=C_i_cddr(t2);
t6=C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,1,t6));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k1201 in k1190 in k1181 in a1178 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1211,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1213,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1286,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t5=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1284 in k1201 in k1190 in k1181 in a1178 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1286,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[84],t2);
/* fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[86]))(6,*((C_word*)lf[86]+1),((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1212 in k1201 in k1190 in k1181 in a1178 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1213,5,t0,t1,t2,t3,t4);}
t5=C_i_length(t2);
t6=C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=C_i_car(t2);
t8=C_i_cadr(t2);
t9=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,t3,t9);
t11=C_a_i_cons(&a,2,t8,t10);
t12=C_a_i_cons(&a,2,t7,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_cons(&a,2,lf[85],t12));}
else{
t7=C_i_car(t2);
t8=C_i_cadr(t2);
t9=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,t8,t9);
t11=C_a_i_cons(&a,2,t7,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_a_i_cons(&a,2,lf[85],t11));}}

/* k1209 in k1201 in k1190 in k1181 in a1178 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1211,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[84],t3));}

/* k1175 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[83],C_SCHEME_END_OF_LIST,t1);}

/* k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1095,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1097,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t4);}

/* a1096 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1097,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1101,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[61]))(5,*((C_word*)lf[61]+1),t5,lf[71],t2,lf[82]);}

/* k1099 in a1096 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* gensym */
((C_proc3)C_retrieve_symbol_proc(lf[68]))(3,*((C_word*)lf[68]+1),t2,lf[69]);}

/* k1102 in k1099 in a1096 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1131,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* r204 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[81]);}

/* k1129 in k1102 in k1099 in a1096 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t2);}

/* k1145 in k1129 in k1102 in k1099 in a1096 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1150,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[74]+1)))(4,*((C_word*)lf[74]+1),t2,lf[79],t1);}

/* k1148 in k1145 in k1129 in k1102 in k1099 in a1096 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[74]+1)))(4,*((C_word*)lf[74]+1),t2,((C_word*)t0)[5],((C_word*)t0)[3]);}

/* k1151 in k1148 in k1145 in k1129 in k1102 in k1099 in a1096 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1156,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[74]+1)))(4,*((C_word*)lf[74]+1),t2,lf[78],((C_word*)t0)[3]);}

/* k1154 in k1151 in k1148 in k1145 in k1129 in k1102 in k1099 in a1096 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1159,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1169,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[2]);
/* string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[76]))(4,*((C_word*)lf[76]+1),t3,t4,lf[77]);}

/* k1167 in k1154 in k1151 in k1148 in k1145 in k1129 in k1102 in k1099 in a1096 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[74]+1)))(4,*((C_word*)lf[74]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1157 in k1154 in k1151 in k1148 in k1145 in k1129 in k1102 in k1099 in a1096 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1162,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[74]+1)))(4,*((C_word*)lf[74]+1),t2,lf[75],((C_word*)t0)[2]);}

/* k1160 in k1157 in k1154 in k1151 in k1148 in k1145 in k1129 in k1102 in k1099 in a1096 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1165,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[73]))(3,*((C_word*)lf[73]+1),t2,((C_word*)t0)[2]);}

/* k1163 in k1160 in k1157 in k1154 in k1151 in k1148 in k1145 in k1129 in k1102 in k1099 in a1096 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1165,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[59],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[72],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t5,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,lf[64],t9));}

/* k1093 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[71],C_SCHEME_END_OF_LIST,t1);}

/* k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1029,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1031,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t4);}

/* a1030 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1031,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1035,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[61]))(5,*((C_word*)lf[61]+1),t5,lf[63],t2,lf[70]);}

/* k1033 in a1030 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1038,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* gensym */
((C_proc3)C_retrieve_symbol_proc(lf[68]))(3,*((C_word*)lf[68]+1),t2,lf[69]);}

/* k1036 in k1033 in a1030 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1038,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=C_i_caddr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1072,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1076,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_stringp(t2))){
t6=t4;
f_1072(t6,C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}
else{
if(C_truep(C_i_symbolp(t2))){
/* symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[65]+1)))(3,*((C_word*)lf[65]+1),t5,t2);}
else{
/* syntax-error */
((C_proc5)C_retrieve_symbol_proc(lf[66]))(5,*((C_word*)lf[66]+1),t5,lf[63],lf[67],t2);}}}

/* k1074 in k1036 in k1033 in a1030 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1076,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1072(t2,C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST));}

/* k1070 in k1036 in k1033 in a1030 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_fcall f_1072(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1072,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,lf[56],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t4,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_cons(&a,2,lf[64],t6));}

/* k1027 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[63],C_SCHEME_END_OF_LIST,t1);}

/* k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1000,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1002,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t4);}

/* a1001 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1002,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1006,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[61]))(5,*((C_word*)lf[61]+1),t5,lf[59],t2,lf[62]);}

/* k1004 in a1001 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1021,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k1019 in k1004 in a1001 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1021,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[59],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[60],t3));}

/* k998 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[59],C_SCHEME_END_OF_LIST,t1);}

/* k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_982,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_984,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t4);}

/* a983 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_984,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_992,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_i_cdr(t2);
/* ##sys#append */
t7=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k990 in a983 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_992,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[58],t1));}

/* k980 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[57],C_SCHEME_END_OF_LIST,t1);}

/* k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_964,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_966,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t4);}

/* a965 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_966,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_974,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_i_cdr(t2);
/* ##sys#append */
t7=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k972 in a965 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_974,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[56],t1));}

/* k962 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[55],C_SCHEME_END_OF_LIST,t1);}

/* k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_946,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_948,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t4);}

/* a947 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_948(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_948,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_956,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_i_cdr(t2);
/* ##sys#append */
t7=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k954 in a947 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_956,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[54],t1));}

/* k944 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[53],C_SCHEME_END_OF_LIST,t1);}

/* k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_928,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_930,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t4);}

/* a929 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_930(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_930,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_938,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_i_cdr(t2);
/* ##sys#append */
t7=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k936 in a929 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_938,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[52],t1));}

/* k926 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[51],C_SCHEME_END_OF_LIST,t1);}

/* k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_910,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_912,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t4);}

/* a911 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_912,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_920,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_i_cdr(t2);
/* ##sys#append */
t7=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k918 in a911 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_920,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[50],t1));}

/* k908 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[49],C_SCHEME_END_OF_LIST,t1);}

/* k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_892,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_894,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t4);}

/* a893 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_894,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_902,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_i_cdr(t2);
/* ##sys#append */
t7=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k900 in a893 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_902,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[48],t1));}

/* k890 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[47],C_SCHEME_END_OF_LIST,t1);}

/* k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_874,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_876,tmp=(C_word)a,a+=2,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,t4);}

/* a875 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_876,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_884,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_i_cdr(t2);
/* ##sys#append */
t7=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k882 in a875 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_884,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[44],t1));}

/* k872 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[43],C_SCHEME_END_OF_LIST,t1);}

/* k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_507,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#macro-subset */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t2,((C_word*)t0)[2]);}

/* k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_507,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! ##sys#chicken-ffi-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_511,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_845,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_855,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_863,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_867,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 48   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t7,lf[40]);}

/* k865 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* chicken.scm: 48   string-split */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],t2);}
else{
/* chicken.scm: 48   string-split */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],lf[38]);}}

/* k861 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 46   remove */
((C_proc4)C_retrieve_symbol_proc(lf[36]))(4,*((C_word*)lf[36]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a854 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_855(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_855,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_string_equal_p(t2,lf[35]));}

/* k843 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_853,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 49   argv */
((C_proc2)C_retrieve_symbol_proc(lf[34]))(2,*((C_word*)lf[34]+1),t2);}

/* k851 in k843 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(t1);
/* chicken.scm: 45   append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_511,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1 /* (set! ##compiler#compiler-arguments ...) */,t1);
t3=C_mutate((C_word*)lf[2]+1 /* (set! ##compiler#process-command-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_513,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_620,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_628,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_640,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a639 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_640,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_644,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_652,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_652(t9,t5,((C_word*)t4)[1]);}

/* loop in a639 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_fcall f_652(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_652,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_i_car(t2);
t4=C_i_cdr(t2);
t5=C_eqp(lf[10],t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_674,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=C_i_car(t4);
/* chicken.scm: 82   string->number */
C_string_to_number(3,0,t6,t7);}
else{
t6=C_eqp(lf[22],t3);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_750,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=C_i_car(t4);
/* chicken.scm: 106  string->number */
C_string_to_number(3,0,t7,t8);}
else{
if(C_truep(C_i_memq(t3,C_retrieve(lf[26])))){
/* chicken.scm: 113  loop */
t16=t1;
t17=t4;
t1=t16;
t2=t17;
goto loop;}
else{
if(C_truep(C_i_memq(t3,C_retrieve(lf[27])))){
if(C_truep(C_i_pairp(t4))){
t7=C_i_cdr(t4);
/* chicken.scm: 116  loop */
t16=t1;
t17=t7;
t1=t16;
t2=t17;
goto loop;}
else{
/* chicken.scm: 117  quit */
((C_proc4)C_retrieve_symbol_proc(lf[28]))(4,*((C_word*)lf[28]+1),t1,lf[29],t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_828,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_835,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_stringp(t3))){
/* chicken.scm: 119  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[23]))(5,*((C_word*)lf[23]+1),t7,lf[24],lf[30],t3);}
else{
/* chicken.scm: 121  conc */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t8,lf[32],t3);}}}}}}}

/* k833 in loop in a639 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 119  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[23]))(5,*((C_word*)lf[23]+1),((C_word*)t0)[2],lf[24],lf[30],t1);}

/* k826 in loop in a639 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 122  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_652(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k748 in loop in a639 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_767,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 108  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[12]))(5,*((C_word*)lf[12]+1),t3,lf[21],lf[18],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(1):
t3=C_a_i_cons(&a,2,lf[18],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=C_i_cdr(((C_word*)t0)[5]);
/* chicken.scm: 112  loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_652(t6,((C_word*)t0)[3],t5);
case C_fix(2):
t3=C_i_cdr(((C_word*)t0)[5]);
/* chicken.scm: 112  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_652(t4,((C_word*)t0)[3],t3);
default:
t3=C_i_car(((C_word*)t0)[5]);
/* chicken.scm: 111  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[23]))(5,*((C_word*)lf[23]+1),t2,lf[24],lf[25],t3);}}

/* k765 in k748 in loop in a639 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 112  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_652(t4,((C_word*)t0)[2],t3);}

/* k751 in k748 in loop in a639 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 112  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_652(t3,((C_word*)t0)[2],t2);}

/* k672 in loop in a639 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_674,2,t0,t1);}
switch(t1){
case C_fix(0):
t2=C_i_cdr(((C_word*)t0)[5]);
/* chicken.scm: 104  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_652(t3,((C_word*)t0)[3],t2);
case C_fix(1):
t2=C_a_i_cons(&a,2,lf[11],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_i_cdr(((C_word*)t0)[5]);
/* chicken.scm: 104  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_652(t5,((C_word*)t0)[3],t4);
case C_fix(2):
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_707,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 89   cons* */
((C_proc5)C_retrieve_symbol_proc(lf[12]))(5,*((C_word*)lf[12]+1),t2,lf[11],lf[13],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(3):
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_717,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 92   cons* */
((C_proc6)C_retrieve_symbol_proc(lf[12]))(6,*((C_word*)lf[12]+1),t2,lf[11],lf[13],lf[14],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(4):
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_727,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 95   cons* */
((C_proc8)C_retrieve_symbol_proc(lf[12]))(8,*((C_word*)lf[12]+1),t2,lf[11],lf[13],lf[14],lf[15],lf[16],((C_word*)((C_word*)t0)[2])[1]);
default:
t2=t1;
if(C_truep(C_fixnum_greater_or_equal_p(t2,C_fix(5)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_737,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm: 100  cons* */
((C_proc12)C_retrieve_symbol_proc(lf[12]))(12,*((C_word*)lf[12]+1),t3,lf[17],lf[18],lf[16],lf[19],lf[11],lf[20],lf[21],lf[13],lf[15],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=C_i_cdr(((C_word*)t0)[5]);
/* chicken.scm: 104  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_652(t4,((C_word*)t0)[3],t3);}}}

/* k735 in k672 in loop in a639 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 104  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_652(t4,((C_word*)t0)[2],t3);}

/* k725 in k672 in loop in a639 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 104  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_652(t4,((C_word*)t0)[2],t3);}

/* k715 in k672 in loop in a639 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 104  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_652(t4,((C_word*)t0)[2],t3);}

/* k705 in k672 in loop in a639 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm: 104  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_652(t4,((C_word*)t0)[2],t3);}

/* k642 in a639 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_647,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t2,C_retrieve(lf[9]),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k645 in k642 in a639 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 124  exit */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),((C_word*)t0)[2]);}

/* a627 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_632,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 76   user-options-pass */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}

/* k630 in a627 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* g332333 */
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_retrieve(lf[1]));}
else{
t2=C_retrieve(lf[2]);
/* g332333 */
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_retrieve(lf[1]));}}

/* k618 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_623,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_626,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[6]))(2,*((C_word*)lf[6]+1),t3);}

/* k624 in k618 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k621 in k618 in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##compiler#process-command-line in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_513,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_519,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_519(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in ##compiler#process-command-line in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_fcall f_519(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_519,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_533,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm: 61   reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),t5,t3);}
else{
t5=C_i_car(t2);
t6=C_i_string_length(t5);
t7=C_i_string_ref(t5,C_fix(0));
t8=C_eqp(C_make_character(45),t7);
t9=(C_truep(t8)?C_fixnum_greaterp(t6,C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_554,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_fixnum_greaterp(t6,C_fix(1)))){
t11=C_i_string_ref(t5,C_fix(1));
t12=t10;
f_554(t12,C_eqp(C_make_character(58),t11));}
else{
t11=t10;
f_554(t11,C_SCHEME_FALSE);}}
else{
if(C_truep(t4)){
t10=C_i_cdr(t2);
t11=C_a_i_cons(&a,2,t5,t3);
/* chicken.scm: 70   loop */
t17=t1;
t18=t10;
t19=t11;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t10=C_i_cdr(t2);
/* chicken.scm: 71   loop */
t17=t1;
t18=t10;
t19=t3;
t20=t5;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}}

/* k552 in loop in ##compiler#process-command-line in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_fcall f_554(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_554,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[8]);
/* chicken.scm: 67   loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_519(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_576,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_580,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm: 68   substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),t4,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}}

/* k578 in k552 in loop in ##compiler#process-command-line in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 68   string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),((C_word*)t0)[2],t1);}

/* k574 in k552 in loop in ##compiler#process-command-line in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_576,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken.scm: 68   loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_519(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k531 in loop in ##compiler#process-command-line in k509 in k505 in k502 in k499 in k496 in k493 in k490 in k487 in k484 in k481 in k478 in k475 in k472 in k469 in k466 in k463 in k460 in k456 in k453 in k450 in k447 in k444 in k441 in k438 in k435 in k432 in k429 in k426 in k423 in k420 in k417 in k414 in k411 in k408 in k405 in k402 */
static void C_ccall f_533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm: 61   values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[152] = {
{"toplevel:chicken_scm",(void*)C_toplevel},
{"f_404:chicken_scm",(void*)f_404},
{"f_407:chicken_scm",(void*)f_407},
{"f_410:chicken_scm",(void*)f_410},
{"f_413:chicken_scm",(void*)f_413},
{"f_416:chicken_scm",(void*)f_416},
{"f_419:chicken_scm",(void*)f_419},
{"f_422:chicken_scm",(void*)f_422},
{"f_425:chicken_scm",(void*)f_425},
{"f_428:chicken_scm",(void*)f_428},
{"f_431:chicken_scm",(void*)f_431},
{"f_434:chicken_scm",(void*)f_434},
{"f_437:chicken_scm",(void*)f_437},
{"f_440:chicken_scm",(void*)f_440},
{"f_443:chicken_scm",(void*)f_443},
{"f_446:chicken_scm",(void*)f_446},
{"f_449:chicken_scm",(void*)f_449},
{"f_452:chicken_scm",(void*)f_452},
{"f_455:chicken_scm",(void*)f_455},
{"f_458:chicken_scm",(void*)f_458},
{"f_462:chicken_scm",(void*)f_462},
{"f_1514:chicken_scm",(void*)f_1514},
{"f_1521:chicken_scm",(void*)f_1521},
{"f_1524:chicken_scm",(void*)f_1524},
{"f_1621:chicken_scm",(void*)f_1621},
{"f_1634:chicken_scm",(void*)f_1634},
{"f_1766:chicken_scm",(void*)f_1766},
{"f_1764:chicken_scm",(void*)f_1764},
{"f_1694:chicken_scm",(void*)f_1694},
{"f_1718:chicken_scm",(void*)f_1718},
{"f_1702:chicken_scm",(void*)f_1702},
{"f_1706:chicken_scm",(void*)f_1706},
{"f_1530:chicken_scm",(void*)f_1530},
{"f_1540:chicken_scm",(void*)f_1540},
{"f_1560:chicken_scm",(void*)f_1560},
{"f_1512:chicken_scm",(void*)f_1512},
{"f_465:chicken_scm",(void*)f_465},
{"f_1493:chicken_scm",(void*)f_1493},
{"f_1497:chicken_scm",(void*)f_1497},
{"f_1491:chicken_scm",(void*)f_1491},
{"f_468:chicken_scm",(void*)f_468},
{"f_1360:chicken_scm",(void*)f_1360},
{"f_1364:chicken_scm",(void*)f_1364},
{"f_1376:chicken_scm",(void*)f_1376},
{"f_1468:chicken_scm",(void*)f_1468},
{"f_1379:chicken_scm",(void*)f_1379},
{"f_1386:chicken_scm",(void*)f_1386},
{"f_1464:chicken_scm",(void*)f_1464},
{"f_1406:chicken_scm",(void*)f_1406},
{"f_1358:chicken_scm",(void*)f_1358},
{"f_471:chicken_scm",(void*)f_471},
{"f_1179:chicken_scm",(void*)f_1179},
{"f_1183:chicken_scm",(void*)f_1183},
{"f_1312:chicken_scm",(void*)f_1312},
{"f_1350:chicken_scm",(void*)f_1350},
{"f_1339:chicken_scm",(void*)f_1339},
{"f_1347:chicken_scm",(void*)f_1347},
{"f_1192:chicken_scm",(void*)f_1192},
{"f_1288:chicken_scm",(void*)f_1288},
{"f_1203:chicken_scm",(void*)f_1203},
{"f_1286:chicken_scm",(void*)f_1286},
{"f_1213:chicken_scm",(void*)f_1213},
{"f_1211:chicken_scm",(void*)f_1211},
{"f_1177:chicken_scm",(void*)f_1177},
{"f_474:chicken_scm",(void*)f_474},
{"f_1097:chicken_scm",(void*)f_1097},
{"f_1101:chicken_scm",(void*)f_1101},
{"f_1104:chicken_scm",(void*)f_1104},
{"f_1131:chicken_scm",(void*)f_1131},
{"f_1147:chicken_scm",(void*)f_1147},
{"f_1150:chicken_scm",(void*)f_1150},
{"f_1153:chicken_scm",(void*)f_1153},
{"f_1156:chicken_scm",(void*)f_1156},
{"f_1169:chicken_scm",(void*)f_1169},
{"f_1159:chicken_scm",(void*)f_1159},
{"f_1162:chicken_scm",(void*)f_1162},
{"f_1165:chicken_scm",(void*)f_1165},
{"f_1095:chicken_scm",(void*)f_1095},
{"f_477:chicken_scm",(void*)f_477},
{"f_1031:chicken_scm",(void*)f_1031},
{"f_1035:chicken_scm",(void*)f_1035},
{"f_1038:chicken_scm",(void*)f_1038},
{"f_1076:chicken_scm",(void*)f_1076},
{"f_1072:chicken_scm",(void*)f_1072},
{"f_1029:chicken_scm",(void*)f_1029},
{"f_480:chicken_scm",(void*)f_480},
{"f_1002:chicken_scm",(void*)f_1002},
{"f_1006:chicken_scm",(void*)f_1006},
{"f_1021:chicken_scm",(void*)f_1021},
{"f_1000:chicken_scm",(void*)f_1000},
{"f_483:chicken_scm",(void*)f_483},
{"f_984:chicken_scm",(void*)f_984},
{"f_992:chicken_scm",(void*)f_992},
{"f_982:chicken_scm",(void*)f_982},
{"f_486:chicken_scm",(void*)f_486},
{"f_966:chicken_scm",(void*)f_966},
{"f_974:chicken_scm",(void*)f_974},
{"f_964:chicken_scm",(void*)f_964},
{"f_489:chicken_scm",(void*)f_489},
{"f_948:chicken_scm",(void*)f_948},
{"f_956:chicken_scm",(void*)f_956},
{"f_946:chicken_scm",(void*)f_946},
{"f_492:chicken_scm",(void*)f_492},
{"f_930:chicken_scm",(void*)f_930},
{"f_938:chicken_scm",(void*)f_938},
{"f_928:chicken_scm",(void*)f_928},
{"f_495:chicken_scm",(void*)f_495},
{"f_912:chicken_scm",(void*)f_912},
{"f_920:chicken_scm",(void*)f_920},
{"f_910:chicken_scm",(void*)f_910},
{"f_498:chicken_scm",(void*)f_498},
{"f_894:chicken_scm",(void*)f_894},
{"f_902:chicken_scm",(void*)f_902},
{"f_892:chicken_scm",(void*)f_892},
{"f_501:chicken_scm",(void*)f_501},
{"f_876:chicken_scm",(void*)f_876},
{"f_884:chicken_scm",(void*)f_884},
{"f_874:chicken_scm",(void*)f_874},
{"f_504:chicken_scm",(void*)f_504},
{"f_507:chicken_scm",(void*)f_507},
{"f_867:chicken_scm",(void*)f_867},
{"f_863:chicken_scm",(void*)f_863},
{"f_855:chicken_scm",(void*)f_855},
{"f_845:chicken_scm",(void*)f_845},
{"f_853:chicken_scm",(void*)f_853},
{"f_511:chicken_scm",(void*)f_511},
{"f_640:chicken_scm",(void*)f_640},
{"f_652:chicken_scm",(void*)f_652},
{"f_835:chicken_scm",(void*)f_835},
{"f_828:chicken_scm",(void*)f_828},
{"f_750:chicken_scm",(void*)f_750},
{"f_767:chicken_scm",(void*)f_767},
{"f_753:chicken_scm",(void*)f_753},
{"f_674:chicken_scm",(void*)f_674},
{"f_737:chicken_scm",(void*)f_737},
{"f_727:chicken_scm",(void*)f_727},
{"f_717:chicken_scm",(void*)f_717},
{"f_707:chicken_scm",(void*)f_707},
{"f_644:chicken_scm",(void*)f_644},
{"f_647:chicken_scm",(void*)f_647},
{"f_628:chicken_scm",(void*)f_628},
{"f_632:chicken_scm",(void*)f_632},
{"f_620:chicken_scm",(void*)f_620},
{"f_626:chicken_scm",(void*)f_626},
{"f_623:chicken_scm",(void*)f_623},
{"f_513:chicken_scm",(void*)f_513},
{"f_519:chicken_scm",(void*)f_519},
{"f_554:chicken_scm",(void*)f_554},
{"f_580:chicken_scm",(void*)f_580},
{"f_576:chicken_scm",(void*)f_576},
{"f_533:chicken_scm",(void*)f_533},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
