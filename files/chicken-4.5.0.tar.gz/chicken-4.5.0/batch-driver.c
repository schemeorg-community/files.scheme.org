/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:53
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: batch-driver.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[403];
static double C_possibly_force_alignment;


C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_ccall f_1497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1513)
static void C_ccall f_1513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4759)
static void C_ccall f_4759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_fcall f_4715(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4719)
static void C_ccall f_4719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static void C_ccall f_1567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4711)
static void C_ccall f_4711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4672)
static void C_ccall f_4672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_fcall f_4674(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1570)
static void C_ccall f_1570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_fcall f_1576(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_fcall f_1987(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1990)
static void C_fcall f_1990(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4630)
static void C_ccall f_4630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_fcall f_4584(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4622)
static void C_ccall f_4622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4526)
static void C_fcall f_4526(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4561)
static void C_ccall f_4561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_fcall f_2008(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_fcall f_2011(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_fcall f_2014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_fcall f_2020(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2026)
static void C_fcall f_2026(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_fcall f_2029(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_fcall f_2032(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2035)
static void C_fcall f_2035(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2038)
static void C_fcall f_2038(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4427)
static void C_ccall f_4427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4429)
static void C_fcall f_4429(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2045)
static void C_fcall f_2045(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4418)
static void C_ccall f_4418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2048)
static void C_fcall f_2048(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_fcall f_2051(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_fcall f_2054(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_fcall f_2057(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2060)
static void C_fcall f_2060(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2063)
static void C_fcall f_2063(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2066)
static void C_fcall f_2066(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_fcall f_2069(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2072)
static void C_fcall f_2072(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4380)
static void C_ccall f_4380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2078)
static void C_fcall f_2078(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4365)
static void C_ccall f_4365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4371)
static void C_ccall f_4371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_fcall f_2084(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4355)
static void C_ccall f_4355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4358)
static void C_ccall f_4358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2087)
static void C_ccall f_2087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4313)
static void C_ccall f_4313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4307)
static void C_ccall f_4307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4280)
static void C_ccall f_4280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4286)
static void C_ccall f_4286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4241)
static void C_fcall f_4241(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4235)
static void C_ccall f_4235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4186)
static void C_fcall f_4186(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2118)
static void C_fcall f_2118(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_fcall f_2121(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2124)
static void C_fcall f_2124(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2127)
static void C_fcall f_2127(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4081)
static void C_fcall f_4081(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4120)
static void C_ccall f_4120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4125)
static void C_ccall f_4125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_fcall f_3996(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4035)
static void C_ccall f_4035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_fcall f_3954(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3964)
static void C_ccall f_3964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_fcall f_3915(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3880)
static void C_fcall f_3880(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_fcall f_3841(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3835)
static void C_ccall f_3835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3779)
static void C_ccall f_3779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3781)
static void C_fcall f_3781(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_fcall f_2179(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2187)
static void C_ccall f_2187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3740)
static void C_ccall f_3740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_fcall f_2213(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3672)
static void C_ccall f_3672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_fcall f_2243(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2304)
static void C_ccall f_2304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3648)
static void C_ccall f_3648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3489)
static void C_fcall f_3489(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3633)
static void C_ccall f_3633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3611)
static void C_fcall f_3611(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3615)
static void C_ccall f_3615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3591)
static void C_ccall f_3591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_fcall f_3549(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3504)
static void C_ccall f_3504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3514)
static void C_fcall f_3514(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3500)
static void C_ccall f_3500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3438)
static void C_ccall f_3438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static void C_fcall f_3444(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_fcall f_2319(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2328)
static void C_fcall f_2328(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_fcall f_3375(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_fcall f_3307(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3113)
static void C_ccall f_3113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_fcall f_3263(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_fcall f_3121(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3140)
static void C_fcall f_3140(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3057)
static void C_fcall f_3057(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3072)
static void C_ccall f_3072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3075)
static void C_ccall f_3075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3078)
static void C_ccall f_3078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2349)
static void C_ccall f_2349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3031)
static void C_ccall f_3031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_fcall f_2976(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2369)
static void C_ccall f_2369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2961)
static void C_ccall f_2961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2380)
static void C_ccall f_2380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2917)
static void C_ccall f_2917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2929)
static void C_ccall f_2929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_fcall f_2386(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2897)
static void C_ccall f_2897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2885)
static void C_ccall f_2885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2389)
static void C_fcall f_2389(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2863)
static void C_ccall f_2863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2827)
static void C_fcall f_2827(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_fcall f_2772(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_fcall f_2780(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2793)
static void C_ccall f_2793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2734)
static void C_fcall f_2734(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2752)
static void C_ccall f_2752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2742)
static void C_fcall f_2742(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_fcall f_2427(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2687)
static void C_ccall f_2687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_ccall f_2564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2581)
static void C_ccall f_2581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5070)
static void C_ccall f5070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2575)
static void C_ccall f_2575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_fcall f_1908(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1938)
static void C_fcall f_1938(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_fcall f_1933(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1910)
static void C_fcall f_1910(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_fcall f_1879(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1869)
static C_word C_fcall f_1869(C_word t0);
C_noret_decl(f_1834)
static void C_fcall f_1834(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1840)
static void C_fcall f_1840(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1848)
static void C_fcall f_1848(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1860)
static void C_ccall f_1860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1754)
static void C_fcall f_1754(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_fcall f_1711(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_fcall f_1723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1687)
static void C_fcall f_1687(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1697)
static void C_ccall f_1697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1703)
static void C_ccall f_1703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1706)
static void C_ccall f_1706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1665)
static void C_fcall f_1665(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1641)
static void C_fcall f_1641(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1663)
static void C_ccall f_1663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1626)
static void C_fcall f_1626(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1633)
static void C_ccall f_1633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1518)
static void C_fcall f_1518(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_4715)
static void C_fcall trf_4715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4715(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4715(t0,t1,t2);}

C_noret_decl(trf_4674)
static void C_fcall trf_4674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4674(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4674(t0,t1,t2);}

C_noret_decl(trf_1576)
static void C_fcall trf_1576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1576(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1576(t0,t1);}

C_noret_decl(trf_1987)
static void C_fcall trf_1987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1987(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1987(t0,t1);}

C_noret_decl(trf_1990)
static void C_fcall trf_1990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1990(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1990(t0,t1);}

C_noret_decl(trf_4584)
static void C_fcall trf_4584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4584(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4584(t0,t1,t2);}

C_noret_decl(trf_4526)
static void C_fcall trf_4526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4526(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4526(t0,t1,t2);}

C_noret_decl(trf_2008)
static void C_fcall trf_2008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2008(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2008(t0,t1);}

C_noret_decl(trf_2011)
static void C_fcall trf_2011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2011(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2011(t0,t1);}

C_noret_decl(trf_2014)
static void C_fcall trf_2014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2014(t0,t1);}

C_noret_decl(trf_2020)
static void C_fcall trf_2020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2020(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2020(t0,t1);}

C_noret_decl(trf_2026)
static void C_fcall trf_2026(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2026(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2026(t0,t1);}

C_noret_decl(trf_2029)
static void C_fcall trf_2029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2029(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2029(t0,t1);}

C_noret_decl(trf_2032)
static void C_fcall trf_2032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2032(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2032(t0,t1);}

C_noret_decl(trf_2035)
static void C_fcall trf_2035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2035(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2035(t0,t1);}

C_noret_decl(trf_2038)
static void C_fcall trf_2038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2038(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2038(t0,t1);}

C_noret_decl(trf_4429)
static void C_fcall trf_4429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4429(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4429(t0,t1,t2);}

C_noret_decl(trf_2045)
static void C_fcall trf_2045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2045(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2045(t0,t1);}

C_noret_decl(trf_2048)
static void C_fcall trf_2048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2048(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2048(t0,t1);}

C_noret_decl(trf_2051)
static void C_fcall trf_2051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2051(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2051(t0,t1);}

C_noret_decl(trf_2054)
static void C_fcall trf_2054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2054(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2054(t0,t1);}

C_noret_decl(trf_2057)
static void C_fcall trf_2057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2057(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2057(t0,t1);}

C_noret_decl(trf_2060)
static void C_fcall trf_2060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2060(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2060(t0,t1);}

C_noret_decl(trf_2063)
static void C_fcall trf_2063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2063(t0,t1);}

C_noret_decl(trf_2066)
static void C_fcall trf_2066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2066(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2066(t0,t1);}

C_noret_decl(trf_2069)
static void C_fcall trf_2069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2069(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2069(t0,t1);}

C_noret_decl(trf_2072)
static void C_fcall trf_2072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2072(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2072(t0,t1);}

C_noret_decl(trf_2078)
static void C_fcall trf_2078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2078(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2078(t0,t1);}

C_noret_decl(trf_2084)
static void C_fcall trf_2084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2084(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2084(t0,t1);}

C_noret_decl(trf_4241)
static void C_fcall trf_4241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4241(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4241(t0,t1,t2);}

C_noret_decl(trf_4186)
static void C_fcall trf_4186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4186(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4186(t0,t1,t2);}

C_noret_decl(trf_2118)
static void C_fcall trf_2118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2118(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2118(t0,t1);}

C_noret_decl(trf_2121)
static void C_fcall trf_2121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2121(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2121(t0,t1);}

C_noret_decl(trf_2124)
static void C_fcall trf_2124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2124(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2124(t0,t1);}

C_noret_decl(trf_2127)
static void C_fcall trf_2127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2127(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2127(t0,t1);}

C_noret_decl(trf_4081)
static void C_fcall trf_4081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4081(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4081(t0,t1,t2);}

C_noret_decl(trf_3996)
static void C_fcall trf_3996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3996(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3996(t0,t1,t2);}

C_noret_decl(trf_3954)
static void C_fcall trf_3954(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3954(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3954(t0,t1,t2);}

C_noret_decl(trf_3915)
static void C_fcall trf_3915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3915(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3915(t0,t1,t2);}

C_noret_decl(trf_3880)
static void C_fcall trf_3880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3880(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3880(t0,t1,t2);}

C_noret_decl(trf_3841)
static void C_fcall trf_3841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3841(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3841(t0,t1,t2);}

C_noret_decl(trf_3781)
static void C_fcall trf_3781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3781(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3781(t0,t1,t2);}

C_noret_decl(trf_2179)
static void C_fcall trf_2179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2179(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2179(t0,t1);}

C_noret_decl(trf_2213)
static void C_fcall trf_2213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2213(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2213(t0,t1);}

C_noret_decl(trf_2243)
static void C_fcall trf_2243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2243(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2243(t0,t1);}

C_noret_decl(trf_3489)
static void C_fcall trf_3489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3489(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3489(t0,t1,t2);}

C_noret_decl(trf_3611)
static void C_fcall trf_3611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3611(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3611(t0,t1);}

C_noret_decl(trf_3549)
static void C_fcall trf_3549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3549(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3549(t0,t1,t2);}

C_noret_decl(trf_3514)
static void C_fcall trf_3514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3514(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3514(t0,t1,t2);}

C_noret_decl(trf_3444)
static void C_fcall trf_3444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3444(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3444(t0,t1,t2);}

C_noret_decl(trf_2319)
static void C_fcall trf_2319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2319(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2319(t0,t1);}

C_noret_decl(trf_2328)
static void C_fcall trf_2328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2328(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2328(t0,t1);}

C_noret_decl(trf_3375)
static void C_fcall trf_3375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3375(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3375(t0,t1,t2);}

C_noret_decl(trf_3307)
static void C_fcall trf_3307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3307(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3307(t0,t1,t2);}

C_noret_decl(trf_3263)
static void C_fcall trf_3263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3263(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3263(t0,t1,t2);}

C_noret_decl(trf_3121)
static void C_fcall trf_3121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3121(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3121(t0,t1);}

C_noret_decl(trf_3140)
static void C_fcall trf_3140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3140(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3140(t0,t1,t2);}

C_noret_decl(trf_3057)
static void C_fcall trf_3057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3057(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3057(t0,t1,t2);}

C_noret_decl(trf_2976)
static void C_fcall trf_2976(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2976(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2976(t0,t1,t2);}

C_noret_decl(trf_2386)
static void C_fcall trf_2386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2386(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2386(t0,t1);}

C_noret_decl(trf_2389)
static void C_fcall trf_2389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2389(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2389(t0,t1);}

C_noret_decl(trf_2827)
static void C_fcall trf_2827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2827(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2827(t0,t1,t2);}

C_noret_decl(trf_2772)
static void C_fcall trf_2772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2772(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2772(t0,t1,t2);}

C_noret_decl(trf_2780)
static void C_fcall trf_2780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2780(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2780(t0,t1,t2);}

C_noret_decl(trf_2734)
static void C_fcall trf_2734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2734(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2734(t0,t1,t2);}

C_noret_decl(trf_2742)
static void C_fcall trf_2742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2742(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2742(t0,t1,t2);}

C_noret_decl(trf_2427)
static void C_fcall trf_2427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2427(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2427(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1908)
static void C_fcall trf_1908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1908(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1908(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1938)
static void C_fcall trf_1938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1938(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1938(t0,t1);}

C_noret_decl(trf_1933)
static void C_fcall trf_1933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1933(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1933(t0,t1,t2);}

C_noret_decl(trf_1910)
static void C_fcall trf_1910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1910(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1910(t0,t1,t2,t3);}

C_noret_decl(trf_1879)
static void C_fcall trf_1879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1879(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1879(t0,t1,t2);}

C_noret_decl(trf_1834)
static void C_fcall trf_1834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1834(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1834(t0,t1,t2);}

C_noret_decl(trf_1840)
static void C_fcall trf_1840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1840(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1840(t0,t1,t2);}

C_noret_decl(trf_1848)
static void C_fcall trf_1848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1848(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1848(t0,t1,t2);}

C_noret_decl(trf_1754)
static void C_fcall trf_1754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1754(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1754(t0,t1);}

C_noret_decl(trf_1711)
static void C_fcall trf_1711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1711(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1711(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1723)
static void C_fcall trf_1723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1723(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1723(t0,t1,t2);}

C_noret_decl(trf_1687)
static void C_fcall trf_1687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1687(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1687(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1665)
static void C_fcall trf_1665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1665(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1665(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1641)
static void C_fcall trf_1641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1641(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1641(t0,t1,t2,t3);}

C_noret_decl(trf_1626)
static void C_fcall trf_1626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1626(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1626(t0,t1,t2,t3);}

C_noret_decl(trf_1518)
static void C_fcall trf_1518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1518(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1518(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3115)){
C_save(t1);
C_rereclaim2(3115*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,403);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],17,"user-options-pass");
lf[3]=C_h_intern(&lf[3],14,"user-read-pass");
lf[4]=C_h_intern(&lf[4],22,"user-preprocessor-pass");
lf[5]=C_h_intern(&lf[5],9,"user-pass");
lf[6]=C_h_intern(&lf[6],23,"user-post-analysis-pass");
lf[7]=C_h_intern(&lf[7],19,"compile-source-file");
lf[8]=C_h_intern(&lf[8],4,"quit");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[11]=C_h_intern(&lf[11],12,"explicit-use");
lf[12]=C_h_intern(&lf[12],26,"\010compilerexplicit-use-flag");
lf[13]=C_h_intern(&lf[13],12,"\004coredeclare");
lf[14]=C_h_intern(&lf[14],7,"verbose");
lf[15]=C_h_intern(&lf[15],11,"output-file");
lf[16]=C_h_intern(&lf[16],36,"\010compilerdefault-optimization-passes");
lf[17]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[18]=C_h_intern(&lf[18],7,"profile");
lf[19]=C_h_intern(&lf[19],12,"profile-name");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\007PROFILE");
lf[21]=C_h_intern(&lf[21],9,"heap-size");
lf[22]=C_h_intern(&lf[22],17,"heap-initial-size");
lf[23]=C_h_intern(&lf[23],11,"heap-growth");
lf[24]=C_h_intern(&lf[24],14,"heap-shrinkage");
lf[25]=C_h_intern(&lf[25],13,"keyword-style");
lf[26]=C_h_intern(&lf[26],4,"unit");
lf[27]=C_h_intern(&lf[27],12,"analyze-only");
lf[28]=C_h_intern(&lf[28],7,"dynamic");
lf[29]=C_h_intern(&lf[29],8,"unboxing");
lf[30]=C_h_intern(&lf[30],7,"nursery");
lf[31]=C_h_intern(&lf[31],10,"stack-size");
lf[32]=C_h_intern(&lf[32],19,"\003sysstandard-output");
lf[33]=C_h_intern(&lf[33],16,"\003sysflush-output");
lf[34]=C_h_intern(&lf[34],19,"\003syswrite-char/port");
lf[35]=C_h_intern(&lf[35],7,"fprintf");
lf[36]=C_h_intern(&lf[36],26,"\010compilerdebugging-chicken");
lf[37]=C_h_intern(&lf[37],7,"display");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\010pass: ~a");
lf[39]=C_h_intern(&lf[39],19,"\010compilerdump-nodes");
lf[40]=C_h_intern(&lf[40],12,"pretty-print");
lf[41]=C_h_intern(&lf[41],30,"\010compilerbuild-expression-tree");
lf[42]=C_h_intern(&lf[42],34,"\010compilerdisplay-analysis-database");
lf[43]=C_h_intern(&lf[43],5,"write");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\013(iteration ");
lf[45]=C_h_intern(&lf[45],7,"newline");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[47]=C_h_intern(&lf[47],9,"substring");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\003: \011");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\030milliseconds needed for ");
lf[50]=C_h_intern(&lf[50],12,"\010compilerget");
lf[51]=C_h_intern(&lf[51],13,"\010compilerput!");
lf[52]=C_h_intern(&lf[52],27,"\010compileranalyze-expression");
lf[53]=C_h_intern(&lf[53],9,"\003syserror");
lf[54]=C_h_intern(&lf[54],1,"D");
lf[55]=C_h_intern(&lf[55],25,"\010compilerimport-libraries");
lf[56]=C_h_intern(&lf[56],26,"\010compilerdisabled-warnings");
lf[57]=C_h_intern(&lf[57],16,"emit-inline-file");
lf[58]=C_h_intern(&lf[58],12,"inline-limit");
lf[59]=C_h_intern(&lf[59],21,"\010compilerverbose-mode");
lf[60]=C_h_intern(&lf[60],31,"\003sysread-error-with-line-number");
lf[61]=C_h_intern(&lf[61],21,"\003sysinclude-pathnames");
lf[62]=C_h_intern(&lf[62],19,"\000compiler-extension");
lf[63]=C_h_intern(&lf[63],12,"\003sysfeatures");
lf[64]=C_h_intern(&lf[64],10,"\000compiling");
lf[65]=C_h_intern(&lf[65],28,"\003sysexplicit-library-modules");
lf[66]=C_h_intern(&lf[66],25,"\010compilertarget-heap-size");
lf[67]=C_h_intern(&lf[67],33,"\010compilertarget-initial-heap-size");
lf[68]=C_h_intern(&lf[68],27,"\010compilertarget-heap-growth");
lf[69]=C_h_intern(&lf[69],30,"\010compilertarget-heap-shrinkage");
lf[70]=C_h_intern(&lf[70],26,"\010compilertarget-stack-size");
lf[71]=C_h_intern(&lf[71],8,"no-trace");
lf[72]=C_h_intern(&lf[72],24,"\010compileremit-trace-info");
lf[73]=C_h_intern(&lf[73],29,"disable-stack-overflow-checks");
lf[74]=C_h_intern(&lf[74],40,"\010compilerdisable-stack-overflow-checking");
lf[75]=C_h_intern(&lf[75],7,"version");
lf[76]=C_h_intern(&lf[76],22,"\010compilerprint-version");
lf[77]=C_h_intern(&lf[77],4,"help");
lf[78]=C_h_intern(&lf[78],20,"\010compilerprint-usage");
lf[79]=C_h_intern(&lf[79],7,"release");
lf[80]=C_h_intern(&lf[80],15,"chicken-version");
lf[81]=C_h_intern(&lf[81],24,"\010compilersource-filename");
lf[82]=C_h_intern(&lf[82],24,"\003sysline-number-database");
lf[83]=C_h_intern(&lf[83],28,"\010compilerprofile-lambda-list");
lf[84]=C_h_intern(&lf[84],31,"\010compilerline-number-database-2");
lf[85]=C_h_intern(&lf[85],4,"node");
lf[86]=C_h_intern(&lf[86],6,"lambda");
lf[87]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[88]=C_h_intern(&lf[88],23,"\010compilerconstant-table");
lf[89]=C_h_intern(&lf[89],21,"\010compilerinline-table");
lf[90]=C_h_intern(&lf[90],23,"\010compilerfirst-analysis");
lf[91]=C_h_intern(&lf[91],41,"\010compilerperform-high-level-optimizations");
lf[92]=C_h_intern(&lf[92],37,"\010compilerinline-substitutions-enabled");
lf[93]=C_h_intern(&lf[93],22,"optimize-leaf-routines");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[95]=C_h_intern(&lf[95],34,"\010compilertransform-direct-lambdas!");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[97]=C_h_intern(&lf[97],4,"leaf");
lf[98]=C_h_intern(&lf[98],18,"\010compilerdebugging");
lf[99]=C_h_intern(&lf[99],1,"p");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\025rewritings enabled...");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[102]=C_h_intern(&lf[102],1,"5");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[105]=C_h_intern(&lf[105],36,"\010compilerprepare-for-code-generation");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\025compilation finished.");
lf[107]=C_h_intern(&lf[107],30,"\010compilercompiler-cleanup-hook");
lf[108]=C_h_intern(&lf[108],1,"t");
lf[109]=C_h_intern(&lf[109],17,"\003sysdisplay-times");
lf[110]=C_h_intern(&lf[110],14,"\003sysstop-timer");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[112]=C_h_intern(&lf[112],17,"close-output-port");
lf[113]=C_h_intern(&lf[113],22,"\010compilergenerate-code");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\023generating `~A\047 ...");
lf[115]=C_h_intern(&lf[115],16,"open-output-file");
lf[116]=C_h_intern(&lf[116],19,"current-output-port");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[118]=C_h_intern(&lf[118],4,"exit");
lf[119]=C_h_intern(&lf[119],6,"unsafe");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\010unboxing");
lf[121]=C_h_intern(&lf[121],1,"U");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\010unboxing");
lf[123]=C_h_intern(&lf[123],26,"\010compilerperform-unboxing!");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\023performing unboxing");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[126]=C_h_intern(&lf[126],1,"9");
lf[127]=C_h_intern(&lf[127],20,"\003syswarnings-enabled");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000#(don\047t worry - still compiling...)\012");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[130]=C_h_intern(&lf[130],1,"8");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[132]=C_h_intern(&lf[132],35,"\010compilerperform-closure-conversion");
lf[133]=C_h_intern(&lf[133],27,"\010compilerinline-output-file");
lf[134]=C_h_intern(&lf[134],32,"\010compileremit-global-inline-file");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000&Generating global inline file `~a\047 ...");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[137]=C_h_intern(&lf[137],1,"7");
lf[138]=C_h_intern(&lf[138],1,"s");
lf[139]=C_h_intern(&lf[139],33,"\010compilerprint-program-statistics");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[141]=C_h_intern(&lf[141],1,"4");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[143]=C_h_intern(&lf[143],1,"v");
lf[144]=C_h_intern(&lf[144],25,"\010compilerdump-global-refs");
lf[145]=C_h_intern(&lf[145],1,"d");
lf[146]=C_h_intern(&lf[146],29,"\010compilerdump-defined-globals");
lf[147]=C_h_intern(&lf[147],1,"u");
lf[148]=C_h_intern(&lf[148],31,"\010compilerdump-undefined-globals");
lf[149]=C_h_intern(&lf[149],3,"opt");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[151]=C_h_intern(&lf[151],1,"3");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[153]=C_h_intern(&lf[153],31,"\010compilerperform-cps-conversion");
lf[154]=C_h_intern(&lf[154],34,"\010compilerscan-toplevel-assignments");
lf[155]=C_h_intern(&lf[155],24,"\010compilerinline-globally");
lf[156]=C_h_intern(&lf[156],23,"\010compilerinline-locally");
lf[157]=C_h_intern(&lf[157],25,"\010compilerload-inline-file");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[159]=C_h_intern(&lf[159],19,"consult-inline-file");
lf[160]=C_h_intern(&lf[160],28,"\010compilerenable-inline-files");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[162]=C_h_intern(&lf[162],12,"file-exists\077");
lf[163]=C_h_intern(&lf[163],28,"\003sysresolve-include-filename");
lf[164]=C_h_intern(&lf[164],13,"make-pathname");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\006inline");
lf[166]=C_h_intern(&lf[166],14,"symbol->string");
lf[167]=C_h_intern(&lf[167],11,"concatenate");
lf[168]=C_h_intern(&lf[168],3,"cdr");
lf[169]=C_h_intern(&lf[169],2,"pp");
lf[170]=C_h_intern(&lf[170],1,"M");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[172]=C_h_intern(&lf[172],12,"vector->list");
lf[173]=C_h_intern(&lf[173],26,"\010compilerfile-requirements");
lf[174]=C_h_intern(&lf[174],26,"\010compilerdo-lambda-lifting");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\015lambda lifted");
lf[176]=C_h_intern(&lf[176],1,"L");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\016lambda lifting");
lf[178]=C_h_intern(&lf[178],32,"\010compilerperform-lambda-lifting!");
lf[179]=C_h_intern(&lf[179],22,"\010compilerdo-scrutinize");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\032pre-analysis (lambda-lift)");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[182]=C_h_intern(&lf[182],1,"0");
lf[183]=C_h_intern(&lf[183],4,"lift");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\010scrutiny");
lf[185]=C_h_intern(&lf[185],19,"\010compilerscrutinize");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\023performing scrutiny");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\014pre-analysis");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[189]=C_h_intern(&lf[189],8,"scrutiny");
lf[190]=C_h_intern(&lf[190],27,"\010compilerload-type-database");
lf[191]=C_h_intern(&lf[191],12,"\003sysfor-each");
lf[192]=C_h_intern(&lf[192],5,"types");
lf[193]=C_h_intern(&lf[193],17,"ignore-repository");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\010types.db");
lf[195]=C_h_intern(&lf[195],37,"\010compilerinitialize-analysis-database");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\021initial node tree");
lf[197]=C_h_intern(&lf[197],1,"T");
lf[198]=C_h_intern(&lf[198],25,"\010compilerbuild-node-graph");
lf[199]=C_h_intern(&lf[199],32,"\010compilercanonicalize-begin-body");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\014User pass...");
lf[202]=C_h_intern(&lf[202],12,"check-syntax");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[204]=C_h_intern(&lf[204],1,"2");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[206]=C_h_intern(&lf[206],18,"\010compilerunit-name");
lf[207]=C_h_intern(&lf[207],10,"\003sysnotice");
lf[208]=C_h_intern(&lf[208],17,"get-output-string");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\032\047 compiled in dynamic mode");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\016library unit `");
lf[211]=C_h_intern(&lf[211],18,"open-output-string");
lf[212]=C_h_intern(&lf[212],37,"\010compilerdisplay-line-number-database");
lf[213]=C_h_intern(&lf[213],1,"n");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[215]=C_h_intern(&lf[215],32,"\010compilerdisplay-real-name-table");
lf[216]=C_h_intern(&lf[216],1,"N");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\002\011\011");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[220]=C_h_intern(&lf[220],35,"\010compilercompiler-syntax-statistics");
lf[221]=C_h_intern(&lf[221],1,"S");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\030applied compiler syntax:");
lf[223]=C_h_intern(&lf[223],6,"append");
lf[224]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[225]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[226]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[227]=C_h_intern(&lf[227],5,"quote");
lf[228]=C_h_intern(&lf[228],33,"\010compilerprofile-info-vector-name");
lf[229]=C_h_intern(&lf[229],28,"\003sysset-profile-info-vector!");
lf[230]=C_h_intern(&lf[230],21,"\010compileremit-profile");
lf[231]=C_h_intern(&lf[231],25,"\003sysregister-profile-info");
lf[232]=C_h_intern(&lf[232],4,"set!");
lf[233]=C_h_intern(&lf[233],13,"\004corecallunit");
lf[234]=C_h_intern(&lf[234],19,"\010compilerused-units");
lf[235]=C_h_intern(&lf[235],28,"\010compilerimmutable-constants");
lf[236]=C_h_intern(&lf[236],6,"gensym");
lf[237]=C_h_intern(&lf[237],32,"\010compilercanonicalize-expression");
lf[238]=C_h_intern(&lf[238],4,"uses");
lf[239]=C_h_intern(&lf[239],7,"declare");
lf[240]=C_h_intern(&lf[240],10,"\003sysappend");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[242]=C_h_intern(&lf[242],1,"1");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\032User preprocessing pass...");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\021User read pass...");
lf[245]=C_h_intern(&lf[245],21,"\010compilerstring->expr");
lf[246]=C_h_intern(&lf[246],7,"reverse");
lf[247]=C_h_intern(&lf[247],27,"\003syscurrent-source-filename");
lf[248]=C_h_intern(&lf[248],33,"\010compilerclose-checked-input-file");
lf[249]=C_h_intern(&lf[249],25,"\010compilerread/source-info");
lf[250]=C_h_intern(&lf[250],16,"\003sysdynamic-wind");
lf[251]=C_h_intern(&lf[251],34,"\010compilercheck-and-open-input-file");
lf[252]=C_h_intern(&lf[252],8,"epilogue");
lf[253]=C_h_intern(&lf[253],8,"prologue");
lf[254]=C_h_intern(&lf[254],8,"postlude");
lf[255]=C_h_intern(&lf[255],7,"prelude");
lf[256]=C_h_intern(&lf[256],11,"make-vector");
lf[257]=C_h_intern(&lf[257],34,"\010compilerline-number-database-size");
lf[258]=C_h_intern(&lf[258],1,"r");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\022compiling `~a\047 ...");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\0009\012Enter \042chicken -help\042 for information on how to use it.\012");
lf[265]=C_h_intern(&lf[265],5,"-help");
lf[266]=C_h_intern(&lf[266],1,"h");
lf[267]=C_h_intern(&lf[267],2,"-h");
lf[268]=C_h_intern(&lf[268],33,"\010compilerload-identifier-database");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[270]=C_h_intern(&lf[270],18,"accumulate-profile");
lf[271]=C_h_intern(&lf[271],28,"\010compilerprofiled-procedures");
lf[272]=C_h_intern(&lf[272],3,"all");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\024Generating ~aprofile");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\014accumulated ");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[276]=C_h_intern(&lf[276],39,"\010compilerdefault-profiling-declarations");
lf[277]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\022debugging info: ~A");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\011calltrace");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[281]=C_h_intern(&lf[281],21,"no-usual-integrations");
lf[282]=C_h_intern(&lf[282],17,"standard-bindings");
lf[283]=C_h_intern(&lf[283],34,"\010compilerdefault-standard-bindings");
lf[284]=C_h_intern(&lf[284],17,"extended-bindings");
lf[285]=C_h_intern(&lf[285],34,"\010compilerdefault-extended-bindings");
lf[286]=C_h_intern(&lf[286],1,"m");
lf[287]=C_h_intern(&lf[287],14,"set-gc-report!");
lf[288]=C_h_intern(&lf[288],42,"\010compilerdefault-default-target-stack-size");
lf[289]=C_h_intern(&lf[289],41,"\010compilerdefault-default-target-heap-size");
lf[290]=C_h_intern(&lf[290],14,"compile-syntax");
lf[291]=C_h_intern(&lf[291],25,"\003sysenable-runtime-macros");
lf[292]=C_h_intern(&lf[292],22,"\004corerequire-extension");
lf[293]=C_h_intern(&lf[293],14,"string->symbol");
lf[294]=C_h_intern(&lf[294],17,"require-extension");
lf[295]=C_h_intern(&lf[295],16,"static-extension");
lf[296]=C_h_intern(&lf[296],28,"\010compilerpostponed-initforms");
lf[297]=C_h_intern(&lf[297],6,"delete");
lf[298]=C_h_intern(&lf[298],3,"eq\077");
lf[299]=C_h_intern(&lf[299],4,"load");
lf[300]=C_h_intern(&lf[300],12,"load-verbose");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\036Loading compiler extensions...");
lf[302]=C_h_intern(&lf[302],6,"extend");
lf[303]=C_h_intern(&lf[303],17,"register-feature!");
lf[304]=C_h_intern(&lf[304],12,"string-split");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[306]=C_h_intern(&lf[306],10,"append-map");
lf[307]=C_h_intern(&lf[307],7,"feature");
lf[308]=C_h_intern(&lf[308],38,"no-procedure-checks-for-usual-bindings");
lf[309]=C_h_intern(&lf[309],8,"\003sysput!");
lf[310]=C_h_intern(&lf[310],21,"\010compileralways-bound");
lf[311]=C_h_intern(&lf[311],34,"\010compileralways-bound-to-procedure");
lf[312]=C_h_intern(&lf[312],19,"no-procedure-checks");
lf[313]=C_h_intern(&lf[313],28,"\010compilerno-procedure-checks");
lf[314]=C_h_intern(&lf[314],15,"no-bound-checks");
lf[315]=C_h_intern(&lf[315],24,"\010compilerno-bound-checks");
lf[316]=C_h_intern(&lf[316],14,"no-argc-checks");
lf[317]=C_h_intern(&lf[317],23,"\010compilerno-argc-checks");
lf[318]=C_h_intern(&lf[318],20,"keep-shadowed-macros");
lf[319]=C_h_intern(&lf[319],33,"\010compilerundefine-shadowed-macros");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[321]=C_h_intern(&lf[321],23,"\010compilerchop-separator");
lf[322]=C_h_intern(&lf[322],12,"include-path");
lf[323]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016");
lf[324]=C_h_intern(&lf[324],13,"symbol-escape");
lf[325]=C_h_intern(&lf[325],20,"parentheses-synonyms");
lf[326]=C_h_intern(&lf[326],5,"\000none");
lf[327]=C_h_intern(&lf[327],14,"case-sensitive");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000.Disabled the Chicken extensions to R5RS syntax");
lf[329]=C_h_intern(&lf[329],16,"no-symbol-escape");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000$Disabled support for escaped symbols");
lf[331]=C_h_intern(&lf[331],23,"no-parenthesis-synonyms");
lf[332]=C_h_intern(&lf[332],20,"parenthesis-synonyms");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000)Disabled support for parenthesis synonyms");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[335]=C_h_intern(&lf[335],7,"\000prefix");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[338]=C_h_intern(&lf[338],7,"\000suffix");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[340]=C_h_intern(&lf[340],17,"compress-literals");
lf[341]=C_h_intern(&lf[341],25,"\010compilercompiler-warning");
lf[342]=C_h_intern(&lf[342],5,"usage");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000+`the -compress-literals\047 option is obsolete");
lf[344]=C_h_intern(&lf[344],16,"case-insensitive");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000,Identifiers and symbols are case insensitive");
lf[346]=C_h_intern(&lf[346],24,"\010compilerinline-max-size");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[348]=C_h_intern(&lf[348],26,"\010compilerlocal-definitions");
lf[349]=C_h_intern(&lf[349],6,"inline");
lf[350]=C_h_intern(&lf[350],30,"emit-external-prototypes-first");
lf[351]=C_h_intern(&lf[351],30,"\010compilerexternal-protos-first");
lf[352]=C_h_intern(&lf[352],5,"block");
lf[353]=C_h_intern(&lf[353],26,"\010compilerblock-compilation");
lf[354]=C_h_intern(&lf[354],17,"fixnum-arithmetic");
lf[355]=C_h_intern(&lf[355],11,"number-type");
lf[356]=C_h_intern(&lf[356],6,"fixnum");
lf[357]=C_h_intern(&lf[357],18,"disable-interrupts");
lf[358]=C_h_intern(&lf[358],28,"\010compilerinsert-timer-checks");
lf[359]=C_h_intern(&lf[359],10,"setup-mode");
lf[360]=C_h_intern(&lf[360],14,"\003syssetup-mode");
lf[361]=C_h_intern(&lf[361],11,"no-warnings");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\025Warnings are disabled");
lf[363]=C_h_intern(&lf[363],19,"\003sysnotices-enabled");
lf[364]=C_h_intern(&lf[364],15,"disable-warning");
lf[365]=C_h_intern(&lf[365],13,"inline-global");
lf[366]=C_h_intern(&lf[366],5,"local");
lf[367]=C_h_intern(&lf[367],18,"no-compiler-syntax");
lf[368]=C_h_intern(&lf[368],32,"\010compilercompiler-syntax-enabled");
lf[369]=C_h_intern(&lf[369],14,"no-lambda-info");
lf[370]=C_h_intern(&lf[370],26,"\010compileremit-closure-info");
lf[371]=C_h_intern(&lf[371],3,"raw");
lf[372]=C_h_intern(&lf[372],12,"emit-exports");
lf[373]=C_h_intern(&lf[373],7,"warning");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000(deprecated compiler option: emit-exports");
lf[375]=C_h_intern(&lf[375],1,"b");
lf[376]=C_h_intern(&lf[376],15,"\003sysstart-timer");
lf[377]=C_h_intern(&lf[377],10,"scrutinize");
lf[378]=C_h_intern(&lf[378],11,"lambda-lift");
lf[379]=C_h_intern(&lf[379],25,"emit-all-import-libraries");
lf[380]=C_h_intern(&lf[380],29,"\010compilerall-import-libraries");
lf[381]=C_h_intern(&lf[381],13,"string-append");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\013.import.scm");
lf[383]=C_h_intern(&lf[383],19,"emit-import-library");
lf[384]=C_h_intern(&lf[384],16,"\003sysstring->list");
lf[385]=C_h_intern(&lf[385],5,"debug");
lf[386]=C_h_intern(&lf[386],18,"\003sysdload-disabled");
lf[387]=C_h_intern(&lf[387],15,"repository-path");
lf[388]=C_h_intern(&lf[388],30,"\010compilerstandalone-executable");
lf[389]=C_h_intern(&lf[389],29,"\010compilerstring->c-identifier");
lf[390]=C_h_intern(&lf[390],18,"\010compilerstringify");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[393]=C_h_intern(&lf[393],24,"get-environment-variable");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[395]=C_h_intern(&lf[395],9,"to-stdout");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[397]=C_h_intern(&lf[397],13,"pathname-file");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[399]=C_h_intern(&lf[399],29,"\010compilerdefault-declarations");
lf[400]=C_h_intern(&lf[400],30,"\010compilerunits-used-by-default");
lf[401]=C_h_intern(&lf[401],28,"\010compilerinitialize-compiler");
lf[402]=C_h_intern(&lf[402],14,"make-parameter");
C_register_lf2(lf,403,create_ptable());
t2=C_mutate(&lf[0] /* (set! c314 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1489,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1487 */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1492,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1490 in k1487 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1497,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 38   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[402]))(3,*((C_word*)lf[402]+1),t2,C_SCHEME_FALSE);}

/* k1495 in k1490 in k1487 */
static void C_ccall f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1497,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! user-options-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1501,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 39   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[402]))(3,*((C_word*)lf[402]+1),t3,C_SCHEME_FALSE);}

/* k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1501,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1 /* (set! user-read-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 40   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[402]))(3,*((C_word*)lf[402]+1),t3,C_SCHEME_FALSE);}

/* k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1 /* (set! user-preprocessor-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1509,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 41   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[402]))(3,*((C_word*)lf[402]+1),t3,C_SCHEME_FALSE);}

/* k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1509,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1 /* (set! user-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1513,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 42   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[402]))(3,*((C_word*)lf[402]+1),t3,C_SCHEME_FALSE);}

/* k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1513,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1 /* (set! user-post-analysis-pass ...) */,t1);
t3=C_mutate((C_word*)lf[7]+1 /* (set! compile-source-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1515,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_1515r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1515r(t0,t1,t2,t3);}}

static void C_ccall f_1515r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1518,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1551,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 55   initialize-compiler */
((C_proc2)C_retrieve_symbol_proc(lf[401]))(2,*((C_word*)lf[401]+1),t5);}

/* k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1551,2,t0,t1);}
t2=C_i_memq(lf[11],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[12]+1 /* (set! ##compiler#explicit-use-flag ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4759,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[12]))){
/* batch-driver.scm: 58   append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[223]+1)))(4,*((C_word*)lf[223]+1),t5,C_retrieve(lf[399]),C_SCHEME_END_OF_LIST);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4774,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t7=*((C_word*)lf[240]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_retrieve(lf[400]),C_SCHEME_END_OF_LIST);}}

/* k4772 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4774,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[238],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 58   append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[223]+1)))(4,*((C_word*)lf[223]+1),((C_word*)t0)[2],C_retrieve(lf[399]),t3);}

/* k4757 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[240]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4755,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[13],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_i_memq(lf[14],((C_word*)t0)[5]);
t7=C_i_memq(lf[15],((C_word*)t0)[5]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4715,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* g7879 */
t10=t9;
f_4715(t10,t8,t7);}
else{
if(C_truep(C_i_memq(lf[395],((C_word*)t0)[5]))){
t9=t8;
f_1567(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4744,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 71   pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[397]))(3,*((C_word*)lf[397]+1),t9,((C_word*)t0)[2]);}
else{
/* batch-driver.scm: 71   make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[164]))(5,*((C_word*)lf[164]+1),t8,C_SCHEME_FALSE,lf[398],lf[396]);}}}}

/* k4742 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 71   make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[164]))(5,*((C_word*)lf[164]+1),((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[396]);}

/* g78 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_4715(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4715,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4719,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 66   option-arg */
f_1518(t3,t2);}

/* k4717 in g78 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_symbolp(t1))){
/* batch-driver.scm: 68   symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[166]+1)))(3,*((C_word*)lf[166]+1),((C_word*)t0)[2],t1);}
else{
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1567,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1570,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4672,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4711,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 72   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[393]))(3,*((C_word*)lf[393]+1),t8,lf[394]);}

/* k4709 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* batch-driver.scm: 72   string-split */
((C_proc4)C_retrieve_symbol_proc(lf[304]))(4,*((C_word*)lf[304]+1),((C_word*)t0)[2],t2,lf[391]);}
else{
/* batch-driver.scm: 72   string-split */
((C_proc4)C_retrieve_symbol_proc(lf[304]))(4,*((C_word*)lf[304]+1),((C_word*)t0)[2],lf[392],lf[391]);}}

/* k4670 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4672,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4674,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4674(t5,((C_word*)t0)[2],t1);}

/* loop84 in k4670 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_4674(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4674,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[321]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4703,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g100101 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4701 in loop84 in k4670 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4703,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop8497 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4674(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop8497 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4674(t6,((C_word*)t0)[3],t5);}}

/* k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1570,2,t0,t1);}
t2=C_retrieve(lf[16]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[17];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_i_memq(lf[18],((C_word*)t0)[8]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1576,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=t6,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_1576(t13,t11);}
else{
t13=C_i_memq(lf[270],((C_word*)t0)[8]);
t14=t12;
f_1576(t14,(C_truep(t13)?t13:C_i_memq(lf[19],((C_word*)t0)[8])));}}

/* k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1576(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word ab[107],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1576,NULL,2,t0,t1);}
t2=C_i_memq(lf[19],((C_word*)t0)[13]);
t3=(C_truep(t2)?C_i_cadr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:lf[20]);
t5=C_i_memq(lf[21],((C_word*)t0)[13]);
t6=C_i_memq(lf[22],((C_word*)t0)[13]);
t7=C_i_memq(lf[23],((C_word*)t0)[13]);
t8=C_i_memq(lf[24],((C_word*)t0)[13]);
t9=C_i_memq(lf[25],((C_word*)t0)[13]);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_i_memq(lf[26],((C_word*)t0)[13]);
t13=C_i_memq(lf[27],((C_word*)t0)[13]);
t14=C_i_memq(lf[28],((C_word*)t0)[13]);
t15=C_i_memq(lf[29],((C_word*)t0)[13]);
t16=C_SCHEME_FALSE;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_i_memq(lf[30],((C_word*)t0)[13]);
t23=(C_truep(t22)?t22:C_i_memq(lf[31],((C_word*)t0)[13]));
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_SCHEME_UNDEFINED;
t35=(*a=C_VECTOR_TYPE|1,a[1]=t34,tmp=(C_word)a,a+=2,tmp);
t36=C_SCHEME_UNDEFINED;
t37=(*a=C_VECTOR_TYPE|1,a[1]=t36,tmp=(C_word)a,a+=2,tmp);
t38=C_SCHEME_UNDEFINED;
t39=(*a=C_VECTOR_TYPE|1,a[1]=t38,tmp=(C_word)a,a+=2,tmp);
t40=C_SCHEME_UNDEFINED;
t41=(*a=C_VECTOR_TYPE|1,a[1]=t40,tmp=(C_word)a,a+=2,tmp);
t42=C_SCHEME_UNDEFINED;
t43=(*a=C_VECTOR_TYPE|1,a[1]=t42,tmp=(C_word)a,a+=2,tmp);
t44=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1626,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp));
t45=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1641,a[2]=t25,tmp=(C_word)a,a+=3,tmp));
t46=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1665,a[2]=t27,a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t47=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1687,a[2]=t27,tmp=(C_word)a,a+=3,tmp));
t48=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1711,a[2]=t27,tmp=(C_word)a,a+=3,tmp));
t49=C_set_block_item(t35,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1754,tmp=(C_word)a,a+=2,tmp));
t50=C_set_block_item(t37,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp));
t51=C_set_block_item(t39,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1869,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp));
t52=C_set_block_item(t41,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1879,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp));
t53=C_set_block_item(t43,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1908,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t54=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[10],a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=((C_word*)t0)[11],a[10]=t35,a[11]=t23,a[12]=t1,a[13]=((C_word*)t0)[3],a[14]=t4,a[15]=((C_word*)t0)[4],a[16]=t33,a[17]=t37,a[18]=t31,a[19]=t15,a[20]=t13,a[21]=t14,a[22]=((C_word*)t0)[5],a[23]=t25,a[24]=t29,a[25]=t43,a[26]=t41,a[27]=t39,a[28]=t19,a[29]=((C_word*)t0)[6],a[30]=((C_word*)t0)[7],a[31]=((C_word*)t0)[8],a[32]=t21,a[33]=t11,a[34]=((C_word*)t0)[12],a[35]=((C_word*)t0)[13],a[36]=t17,tmp=(C_word)a,a+=37,tmp);
if(C_truep(t12)){
t55=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4645,a[2]=t54,tmp=(C_word)a,a+=3,tmp);
t56=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4649,a[2]=t55,tmp=(C_word)a,a+=3,tmp);
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4653,a[2]=t56,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 160  option-arg */
f_1518(t57,t12);}
else{
t55=t54;
f_1987(t55,C_SCHEME_UNDEFINED);}}

/* k4651 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 160  stringify */
((C_proc3)C_retrieve_symbol_proc(lf[390]))(3,*((C_word*)lf[390]+1),((C_word*)t0)[2],t1);}

/* k4647 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 160  string->c-identifier */
((C_proc3)C_retrieve_symbol_proc(lf[389]))(3,*((C_word*)lf[389]+1),((C_word*)t0)[2],t1);}

/* k4643 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[206]+1 /* (set! ##compiler#unit-name ...) */,t1);
t3=((C_word*)t0)[2];
f_1987(t3,t2);}

/* k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1987(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1987,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=C_retrieve(lf[206]);
if(C_truep(t3)){
if(C_truep(t3)){
t4=C_set_block_item(lf[388] /* standalone-executable */,0,C_SCHEME_FALSE);
t5=t2;
f_1990(t5,t4);}
else{
t4=t2;
f_1990(t4,C_SCHEME_UNDEFINED);}}
else{
if(C_truep(((C_word*)t0)[21])){
t4=C_set_block_item(lf[388] /* standalone-executable */,0,C_SCHEME_FALSE);
t5=t2;
f_1990(t5,t4);}
else{
t4=t2;
f_1990(t4,C_SCHEME_UNDEFINED);}}}

/* k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1990(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1990,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep(C_i_memq(lf[193],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[386] /* dload-disabled */,0,C_SCHEME_TRUE);
/* batch-driver.scm: 165  repository-path */
((C_proc3)C_retrieve_symbol_proc(lf[387]))(3,*((C_word*)lf[387]+1),t2,C_SCHEME_FALSE);}
else{
t3=t2;
f_1993(2,t3,C_SCHEME_UNDEFINED);}}

/* k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4574,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4630,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 171  collect-options */
t5=((C_word*)((C_word*)t0)[17])[1];
f_1834(t5,t4,lf[385]);}

/* k4628 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 167  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[306]))(4,*((C_word*)lf[306]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4573 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4574,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4582,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* string->list */
t8=C_retrieve(lf[384]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k4580 in a4573 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4582,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4584,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4584(t5,((C_word*)t0)[2],t1);}

/* loop328 in k4580 in a4573 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_4584(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4584,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4622,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_string(&a,1,t4);
/* batch-driver.scm: 169  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[293]+1)))(3,*((C_word*)lf[293]+1),t3,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4620 in loop328 in k4580 in a4573 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4622,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop328341 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4584(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop328341 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4584(t6,((C_word*)t0)[3],t5);}}

/* k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1997,2,t0,t1);}
t2=C_mutate((C_word*)lf[36]+1 /* (set! ##compiler#debugging-chicken ...) */,t1);
t3=C_i_memq(lf[54],C_retrieve(lf[36]));
t4=C_mutate(((C_word *)((C_word*)t0)[36])+1,t3);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4524,a[2]=t9,a[3]=t6,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 177  collect-options */
t11=((C_word*)((C_word*)t0)[17])[1];
f_1834(t11,t10,lf[383]);}

/* k4522 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4524,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4526,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4526(t5,((C_word*)t0)[2],t1);}

/* loop352 in k4522 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_4526(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4526,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4561,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 175  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[293]+1)))(3,*((C_word*)lf[293]+1),t4,t3);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4559 in loop352 in k4522 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4565,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 176  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[381]+1)))(4,*((C_word*)lf[381]+1),t2,((C_word*)t0)[2],lf[382]);}

/* k4563 in k4559 in loop352 in k4522 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4565,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t4=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t6=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop352365 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_4526(t7,((C_word*)t0)[3],t6);}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t6=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop352365 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_4526(t7,((C_word*)t0)[3],t6);}}

/* k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
t2=C_mutate((C_word*)lf[55]+1 /* (set! ##compiler#import-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(C_i_memq(lf[379],((C_word*)t0)[35]))){
if(C_truep(((C_word*)t0)[20])){
t4=t3;
f_2008(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_set_block_item(lf[380] /* all-import-libraries */,0,C_SCHEME_TRUE);
t5=t3;
f_2008(t5,t4);}}
else{
t4=t3;
f_2008(t4,C_SCHEME_UNDEFINED);}}

/* k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2008(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2008,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(C_i_memq(lf[378],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[174] /* do-lambda-lifting */,0,C_SCHEME_TRUE);
t4=t2;
f_2011(t4,t3);}
else{
t3=t2;
f_2011(t3,C_SCHEME_UNDEFINED);}}

/* k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2011(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2011,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(C_i_memq(lf[377],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[179] /* do-scrutinize */,0,C_SCHEME_TRUE);
t4=t2;
f_2014(t4,t3);}
else{
t3=t2;
f_2014(t3,C_SCHEME_UNDEFINED);}}

/* k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2014,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_2017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(C_i_memq(lf[108],C_retrieve(lf[36])))){
/* batch-driver.scm: 183  ##sys#start-timer */
t3=*((C_word*)lf[376]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_2017(2,t3,C_SCHEME_UNDEFINED);}}

/* k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[375],C_retrieve(lf[36])))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_2020(t4,t3);}
else{
t3=t2;
f_2020(t3,C_SCHEME_UNDEFINED);}}

/* k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2020(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2020,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2023,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[372],((C_word*)t0)[34]))){
/* batch-driver.scm: 186  warning */
((C_proc3)C_retrieve_symbol_proc(lf[373]))(3,*((C_word*)lf[373]+1),t2,lf[374]);}
else{
t3=t2;
f_2023(2,t3,C_SCHEME_UNDEFINED);}}

/* k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[371],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[12] /* explicit-use-flag */,0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[14],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[30],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_2026(t6,t5);}
else{
t3=t2;
f_2026(t3,C_SCHEME_UNDEFINED);}}

/* k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2026(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2026,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[369],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[370] /* emit-closure-info */,0,C_SCHEME_FALSE);
t4=t2;
f_2029(t4,t3);}
else{
t3=t2;
f_2029(t3,C_SCHEME_UNDEFINED);}}

/* k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2029(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2029,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[367],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[368] /* compiler-syntax-enabled */,0,C_SCHEME_FALSE);
t4=t2;
f_2032(t4,t3);}
else{
t3=t2;
f_2032(t3,C_SCHEME_UNDEFINED);}}

/* k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2032(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2032,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2035,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[366],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[348] /* local-definitions */,0,C_SCHEME_TRUE);
t4=t2;
f_2035(t4,t3);}
else{
t3=t2;
f_2035(t3,C_SCHEME_UNDEFINED);}}

/* k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2035(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2035,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2038,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[365],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[160] /* enable-inline-files */,0,C_SCHEME_TRUE);
t4=C_set_block_item(lf[156] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[155] /* inline-globally */,0,C_SCHEME_TRUE);
t6=t2;
f_2038(t6,t5);}
else{
t3=t2;
f_2038(t3,C_SCHEME_UNDEFINED);}}

/* k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2038(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2038,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2042,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4427,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 201  collect-options */
t8=((C_word*)((C_word*)t0)[16])[1];
f_1834(t8,t7,lf[364]);}

/* k4425 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4427,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4429,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4429(t5,((C_word*)t0)[2],t1);}

/* loop404 in k4425 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_4429(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4429,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[293]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4458,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g420421 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4456 in loop404 in k4425 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4458,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop404417 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4429(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop404417 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4429(t6,((C_word*)t0)[3],t5);}}

/* k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2042,2,t0,t1);}
t2=C_mutate((C_word*)lf[56]+1 /* (set! ##compiler#disabled-warnings ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[33])){
if(C_truep(((C_word*)t0)[33])){
t4=C_set_block_item(lf[363] /* notices-enabled */,0,C_SCHEME_TRUE);
t5=t3;
f_2045(t5,t4);}
else{
t4=t3;
f_2045(t4,C_SCHEME_UNDEFINED);}}
else{
t4=C_retrieve(lf[179]);
if(C_truep(t4)){
t5=C_set_block_item(lf[363] /* notices-enabled */,0,C_SCHEME_TRUE);
t6=t3;
f_2045(t6,t5);}
else{
t5=t3;
f_2045(t5,C_SCHEME_UNDEFINED);}}}

/* k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2045(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2045,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[361],((C_word*)t0)[34]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4418,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 205  dribble */
t4=((C_word*)((C_word*)t0)[22])[1];
f_1626(t4,t3,lf[362],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_2048(t3,C_SCHEME_UNDEFINED);}}

/* k4416 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[127] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_2048(t3,t2);}

/* k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2048(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2048,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2051,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[93],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[93] /* optimize-leaf-routines */,0,C_SCHEME_TRUE);
t4=t2;
f_2051(t4,t3);}
else{
t3=t2;
f_2051(t3,C_SCHEME_UNDEFINED);}}

/* k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2051(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2051,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[119],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[119] /* unsafe */,0,C_SCHEME_TRUE);
t4=t2;
f_2054(t4,t3);}
else{
t3=t2;
f_2054(t3,C_SCHEME_UNDEFINED);}}

/* k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2054(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2054,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[359],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[360] /* setup-mode */,0,C_SCHEME_TRUE);
t4=t2;
f_2057(t4,t3);}
else{
t3=t2;
f_2057(t3,C_SCHEME_UNDEFINED);}}

/* k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2057(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2057,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[357],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[358] /* insert-timer-checks */,0,C_SCHEME_FALSE);
t4=t2;
f_2060(t4,t3);}
else{
t3=t2;
f_2060(t3,C_SCHEME_UNDEFINED);}}

/* k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2060(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2060,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[354],((C_word*)t0)[34]))){
t3=C_mutate((C_word*)lf[355]+1 /* (set! number-type ...) */,lf[356]);
t4=t2;
f_2063(t4,t3);}
else{
t3=t2;
f_2063(t3,C_SCHEME_UNDEFINED);}}

/* k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2063(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2063,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[352],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[353] /* block-compilation */,0,C_SCHEME_TRUE);
t4=t2;
f_2066(t4,t3);}
else{
t3=t2;
f_2066(t3,C_SCHEME_UNDEFINED);}}

/* k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2066(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2066,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[350],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[351] /* external-protos-first */,0,C_SCHEME_TRUE);
t4=t2;
f_2069(t4,t3);}
else{
t3=t2;
f_2069(t3,C_SCHEME_UNDEFINED);}}

/* k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2069(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2069,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[349],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[156] /* inline-locally */,0,C_SCHEME_TRUE);
t4=t2;
f_2072(t4,t3);}
else{
t3=t2;
f_2072(t3,C_SCHEME_UNDEFINED);}}

/* k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2072(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2072,NULL,2,t0,t1);}
t2=C_i_memq(lf[57],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=C_set_block_item(lf[156] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[348] /* local-definitions */,0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4380,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 221  option-arg */
f_1518(t6,t2);}
else{
t4=t3;
f_2078(t4,C_SCHEME_FALSE);}}

/* k4378 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[133]+1 /* (set! ##compiler#inline-output-file ...) */,t1);
t3=((C_word*)t0)[2];
f_2078(t3,t2);}

/* k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2078(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2078,NULL,2,t0,t1);}
t2=C_i_memq(lf[58],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[34],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4365,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 224  option-arg */
f_1518(t4,t2);}
else{
t4=t3;
f_2084(t4,C_SCHEME_FALSE);}}

/* k4363 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4368,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 225  string->number */
C_string_to_number(3,0,t2,t1);}

/* k4366 in k4363 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4371,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t1;
t4=C_mutate((C_word*)lf[346]+1 /* (set! ##compiler#inline-max-size ...) */,t3);
t5=((C_word*)t0)[3];
f_2084(t5,t4);}
else{
/* batch-driver.scm: 226  quit */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t2,lf[347],((C_word*)t0)[2]);}}

/* k4369 in k4366 in k4363 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[346]+1 /* (set! ##compiler#inline-max-size ...) */,t1);
t3=((C_word*)t0)[2];
f_2084(t3,t2);}

/* k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2084(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2084,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[344],((C_word*)t0)[30]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4355,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 228  dribble */
t4=((C_word*)((C_word*)t0)[22])[1];
f_1626(t4,t3,lf[345],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_2087(2,t3,C_SCHEME_UNDEFINED);}}

/* k4353 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4358,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 229  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[303]))(3,*((C_word*)lf[303]+1),t2,lf[344]);}

/* k4356 in k4353 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 230  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[327]))(3,*((C_word*)lf[327]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_2090,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(C_i_memq(lf[340],((C_word*)t0)[30]))){
/* batch-driver.scm: 232  compiler-warning */
((C_proc4)C_retrieve_symbol_proc(lf[341]))(4,*((C_word*)lf[341]+1),t2,lf[342],lf[343]);}
else{
t3=t2;
f_2090(2,t3,C_SCHEME_UNDEFINED);}}

/* k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4313,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 234  option-arg */
f_1518(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_2093(2,t3,C_SCHEME_UNDEFINED);}}

/* k4311 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_string_equal_p(lf[334],t1))){
/* batch-driver.scm: 235  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[335]);}
else{
if(C_truep(C_i_string_equal_p(lf[336],t1))){
/* batch-driver.scm: 236  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[326]);}
else{
if(C_truep(C_i_string_equal_p(lf[337],t1))){
/* batch-driver.scm: 237  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[338]);}
else{
/* batch-driver.scm: 238  quit */
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[339]);}}}}

/* k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_2096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep(C_i_memq(lf[331],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4307,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 240  dribble */
t4=((C_word*)((C_word*)t0)[21])[1];
f_1626(t4,t3,lf[333],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_2096(2,t3,C_SCHEME_UNDEFINED);}}

/* k4305 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 241  parenthesis-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_2099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep(C_i_memq(lf[329],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4298,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 243  dribble */
t4=((C_word*)((C_word*)t0)[21])[1];
f_1626(t4,t3,lf[330],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_2099(2,t3,C_SCHEME_UNDEFINED);}}

/* k4296 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 244  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[324]))(3,*((C_word*)lf[324]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_2102,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep(C_i_memq(lf[323],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4280,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 246  dribble */
t4=((C_word*)((C_word*)t0)[21])[1];
f_1626(t4,t3,lf[328],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_2102(2,t3,C_SCHEME_UNDEFINED);}}

/* k4278 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4283,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 247  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[327]))(3,*((C_word*)lf[327]+1),t2,C_SCHEME_FALSE);}

/* k4281 in k4278 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4286,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 248  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t2,lf[326]);}

/* k4284 in k4281 in k4278 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4289,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 249  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[325]))(3,*((C_word*)lf[325]+1),t2,C_SCHEME_FALSE);}

/* k4287 in k4284 in k4281 in k4278 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 250  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[324]))(3,*((C_word*)lf[324]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2102,2,t0,t1);}
t2=C_mutate((C_word*)lf[59]+1 /* (set! ##compiler#verbose-mode ...) */,((C_word*)t0)[33]);
t3=C_set_block_item(lf[60] /* read-error-with-line-number */,0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2108,a[2]=((C_word*)t0)[33],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4235,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4239,a[2]=t9,a[3]=t6,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 254  collect-options */
t11=((C_word*)((C_word*)t0)[15])[1];
f_1834(t11,t10,lf[322]);}

/* k4237 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4239,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4241,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4241(t5,((C_word*)t0)[2],t1);}

/* loop496 in k4237 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_4241(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4241,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[321]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4270,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g512513 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4268 in loop496 in k4237 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4270,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop496509 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4241(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop496509 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4241(t6,((C_word*)t0)[3],t5);}}

/* k4233 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 254  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[223]+1)))(5,*((C_word*)lf[223]+1),((C_word*)t0)[3],t1,C_retrieve(lf[61]),((C_word*)t0)[2]);}

/* k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2108,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! ##sys#include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(((C_word*)t0)[20])){
if(C_truep(((C_word*)t0)[27])){
if(C_truep(C_i_string_equal_p(((C_word*)t0)[20],((C_word*)t0)[27]))){
/* batch-driver.scm: 258  quit */
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),t3,lf[320]);}
else{
t4=t3;
f_2111(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2111(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2111(2,t4,C_SCHEME_UNDEFINED);}}

/* k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2111,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4184,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 259  collect-options */
t8=((C_word*)((C_word*)t0)[15])[1];
f_1834(t8,t7,lf[238]);}

/* k4182 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4184,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4186,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4186(t5,((C_word*)t0)[2],t1);}

/* loop525 in k4182 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_4186(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4186,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[293]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4215,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g541542 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4213 in loop525 in k4182 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4215,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop525538 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4186(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop525538 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4186(t6,((C_word*)t0)[3],t5);}}

/* k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2115,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2118,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[32],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep(C_i_memq(lf[318],((C_word*)t0)[29]))){
t4=C_set_block_item(lf[319] /* undefine-shadowed-macros */,0,C_SCHEME_FALSE);
t5=t3;
f_2118(t5,t4);}
else{
t4=t3;
f_2118(t4,C_SCHEME_UNDEFINED);}}

/* k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2118,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(C_i_memq(lf[316],((C_word*)t0)[30]))){
t3=C_set_block_item(lf[317] /* no-argc-checks */,0,C_SCHEME_TRUE);
t4=t2;
f_2121(t4,t3);}
else{
t3=t2;
f_2121(t3,C_SCHEME_UNDEFINED);}}

/* k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2121(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2121,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2124,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(C_i_memq(lf[314],((C_word*)t0)[30]))){
t3=C_set_block_item(lf[315] /* no-bound-checks */,0,C_SCHEME_TRUE);
t4=t2;
f_2124(t4,t3);}
else{
t3=t2;
f_2124(t3,C_SCHEME_UNDEFINED);}}

/* k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2124,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2127,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(C_i_memq(lf[312],((C_word*)t0)[30]))){
t3=C_set_block_item(lf[313] /* no-procedure-checks */,0,C_SCHEME_TRUE);
t4=t2;
f_2127(t4,t3);}
else{
t3=t2;
f_2127(t3,C_SCHEME_UNDEFINED);}}

/* k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2127(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2127,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(C_i_memq(lf[308],((C_word*)t0)[30]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3991,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4081,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4081(t7,t3,C_retrieve(lf[283]));}
else{
t3=t2;
f_2130(2,t3,C_SCHEME_UNDEFINED);}}

/* loop558 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_4081(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4081,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4153,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4120,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4095,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t6))){
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[309]))(5,*((C_word*)lf[309]+1),t5,t4,lf[311],C_SCHEME_TRUE);}
else{
t8=C_i_cdr(t6);
if(C_truep(C_i_nullp(t8))){
t9=C_i_car(t6);
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[309]))(5,*((C_word*)lf[309]+1),t5,t4,lf[311],t9);}
else{
/* ##sys#error */
t9=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,lf[0],t6);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4093 in loop558 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[309]))(5,*((C_word*)lf[309]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[311],t1);}

/* k4118 in loop558 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4120,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t2))){
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[309]))(5,*((C_word*)lf[309]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[310],C_SCHEME_TRUE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=C_i_car(t2);
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[309]))(5,*((C_word*)lf[309]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[310],t5);}
else{
/* ##sys#error */
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4123 in k4118 in loop558 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[309]))(5,*((C_word*)lf[309]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[310],t1);}

/* k4151 in loop558 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4081(t3,((C_word*)t0)[2],t2);}

/* k3989 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3991,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3996,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3996(t5,((C_word*)t0)[2],C_retrieve(lf[285]));}

/* loop605 in k3989 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3996(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3996,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4068,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4035,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4010,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t6))){
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[309]))(5,*((C_word*)lf[309]+1),t5,t4,lf[311],C_SCHEME_TRUE);}
else{
t8=C_i_cdr(t6);
if(C_truep(C_i_nullp(t8))){
t9=C_i_car(t6);
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[309]))(5,*((C_word*)lf[309]+1),t5,t4,lf[311],t9);}
else{
/* ##sys#error */
t9=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,lf[0],t6);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4008 in loop605 in k3989 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[309]))(5,*((C_word*)lf[309]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[311],t1);}

/* k4033 in loop605 in k3989 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4035,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t2))){
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[309]))(5,*((C_word*)lf[309]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[310],C_SCHEME_TRUE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=C_i_car(t2);
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[309]))(5,*((C_word*)lf[309]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[310],t5);}
else{
/* ##sys#error */
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4038 in k4033 in loop605 in k3989 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[309]))(5,*((C_word*)lf[309]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[310],t1);}

/* k4066 in loop605 in k3989 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3996(t3,((C_word*)t0)[2],t2);}

/* k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3952,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3977,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3985,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 283  collect-options */
t6=((C_word*)((C_word*)t0)[16])[1];
f_1834(t6,t5,lf[307]);}

/* k3983 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 283  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[306]))(4,*((C_word*)lf[306]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3976 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3977,3,t0,t1,t2);}
t3=C_retrieve(lf[304]);
/* g671672 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[305]);}

/* k3950 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3952,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3954,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3954(t5,((C_word*)t0)[2],t1);}

/* loop653 in k3950 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3954(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3954,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[303]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3964,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g660661 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3962 in loop653 in k3950 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3954(t3,((C_word*)t0)[2],t2);}

/* k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2133,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[62],C_retrieve(lf[63]));
t3=C_mutate((C_word*)lf[63]+1 /* (set! ##sys#features ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 287  collect-options */
t5=((C_word*)((C_word*)t0)[16])[1];
f_1834(t5,t4,lf[302]);}

/* k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_2143,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 288  dribble */
t3=((C_word*)((C_word*)t0)[22])[1];
f_1626(t3,t2,lf[301],C_SCHEME_END_OF_LIST);}

/* k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_2146,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 289  load-verbose */
((C_proc3)C_retrieve_symbol_proc(lf[300]))(3,*((C_word*)lf[300]+1),t2,C_SCHEME_TRUE);}
else{
t3=t2;
f_2146(2,t3,C_SCHEME_UNDEFINED);}}

/* k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3915,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3915(t6,t2,((C_word*)t0)[2]);}

/* loop678 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3915(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3915,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3934,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3931,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 291  ##sys#resolve-include-filename */
((C_proc5)C_retrieve_symbol_proc(lf[163]))(5,*((C_word*)lf[163]+1),t5,t4,C_SCHEME_FALSE,C_SCHEME_TRUE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3929 in loop678 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 291  load */
((C_proc3)C_retrieve_symbol_proc(lf[299]))(3,*((C_word*)lf[299]+1),((C_word*)t0)[2],t1);}

/* k3932 in loop678 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3915(t3,((C_word*)t0)[2],t2);}

/* k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_2153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm: 293  delete */
((C_proc5)C_retrieve_symbol_proc(lf[297]))(5,*((C_word*)lf[297]+1),t2,lf[62],C_retrieve(lf[63]),*((C_word*)lf[298]+1));}

/* k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2153,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1 /* (set! ##sys#features ...) */,t1);
t3=C_a_i_cons(&a,2,lf[64],C_retrieve(lf[63]));
t4=C_mutate((C_word*)lf[63]+1 /* (set! ##sys#features ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_2161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm: 296  user-post-analysis-pass */
((C_proc2)C_retrieve_symbol_proc(lf[6]))(2,*((C_word*)lf[6]+1),t5);}

/* k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2161,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_2165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
/* batch-driver.scm: 299  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[223]+1)))(4,*((C_word*)lf[223]+1),t3,((C_word*)((C_word*)t0)[30])[1],C_retrieve(lf[296]));}

/* k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2165,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[30])+1,t1);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_2168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3878,a[2]=t7,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 301  collect-options */
t9=((C_word*)((C_word*)t0)[15])[1];
f_1834(t9,t8,lf[295]);}

/* k3876 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3878,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3880,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3880(t5,((C_word*)t0)[2],t1);}

/* loop695 in k3876 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3880(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3880,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[293]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3909,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g711712 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3907 in loop695 in k3876 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3909,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop695708 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3880(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop695708 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3880(t6,((C_word*)t0)[3],t5);}}

/* k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_2172,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],tmp=(C_word)a,a+=32,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3775,a[2]=((C_word*)t0)[30],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3779,a[2]=t7,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3835,a[2]=t1,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3839,a[2]=t13,a[3]=t10,a[4]=t12,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 307  collect-options */
t15=((C_word*)((C_word*)t0)[15])[1];
f_1834(t15,t14,lf[294]);}

/* k3837 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3839,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3841,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3841(t5,((C_word*)t0)[2],t1);}

/* loop746 in k3837 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3841(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3841,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[293]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3870,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g762763 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3868 in loop746 in k3837 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3870,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop746759 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3841(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop746759 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3841(t6,((C_word*)t0)[3],t5);}}

/* k3833 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 307  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[223]+1)))(4,*((C_word*)lf[223]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3777 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3779,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3781,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3781(t5,((C_word*)t0)[2],t1);}

/* loop718 in k3777 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3781(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3781,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,lf[292],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t9=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t8);
t10=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t11=C_slot(t2,C_fix(1));
/* loop718731 */
t17=t1;
t18=t11;
t1=t17;
t2=t18;
goto loop;}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[2])+1,t8);
t10=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t11=C_slot(t2,C_fix(1));
/* loop718731 */
t17=t1;
t18=t11;
t1=t17;
t2=t18;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3773 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 304  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[223]+1)))(4,*((C_word*)lf[223]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2172,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_2176,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[31],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
/* batch-driver.scm: 311  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[223]+1)))(4,*((C_word*)lf[223]+1),t3,C_retrieve(lf[65]),((C_word*)t0)[2]);}

/* k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2176,2,t0,t1);}
t2=C_mutate((C_word*)lf[65]+1 /* (set! ##sys#explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_2179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
if(C_truep(C_i_memq(lf[290],((C_word*)t0)[30]))){
t4=C_set_block_item(lf[291] /* enable-runtime-macros */,0,C_SCHEME_TRUE);
t5=t3;
f_2179(t5,t4);}
else{
t4=t3;
f_2179(t4,C_SCHEME_UNDEFINED);}}

/* k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2179(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2179,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_2183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3754,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 317  option-arg */
f_1518(t3,((C_word*)t0)[2]);}
else{
t3=C_retrieve(lf[289]);
if(C_truep(t3)){
t4=C_eqp(t3,C_fix(0));
t5=t2;
f_2183(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_2183(2,t4,C_SCHEME_FALSE);}}}

/* k3752 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 317  arg-val */
f_1754(((C_word*)t0)[2],t1);}

/* k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2183,2,t0,t1);}
t2=C_mutate((C_word*)lf[66]+1 /* (set! ##compiler#target-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_2187,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3747,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 321  option-arg */
f_1518(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_2187(2,t4,C_SCHEME_FALSE);}}

/* k3745 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 321  arg-val */
f_1754(((C_word*)t0)[2],t1);}

/* k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2187,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1 /* (set! ##compiler#target-initial-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_2191,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],tmp=(C_word)a,a+=28,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3740,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 322  option-arg */
f_1518(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_2191(2,t4,C_SCHEME_FALSE);}}

/* k3738 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 322  arg-val */
f_1754(((C_word*)t0)[2],t1);}

/* k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2191,2,t0,t1);}
t2=C_mutate((C_word*)lf[68]+1 /* (set! ##compiler#target-heap-growth ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],tmp=(C_word)a,a+=27,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3733,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 323  option-arg */
f_1518(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_2195(2,t4,C_SCHEME_FALSE);}}

/* k3731 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 323  arg-val */
f_1754(((C_word*)t0)[2],t1);}

/* k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2195,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1 /* (set! ##compiler#target-heap-shrinkage ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_2199,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3713,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 326  option-arg */
f_1518(t4,((C_word*)t0)[4]);}
else{
t4=C_retrieve(lf[288]);
if(C_truep(t4)){
t5=C_eqp(t4,C_fix(0));
t6=t3;
f_2199(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_2199(2,t5,C_SCHEME_FALSE);}}}

/* k3711 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 326  arg-val */
f_1754(((C_word*)t0)[2],t1);}

/* k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2199,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1 /* (set! ##compiler#target-stack-size ...) */,t1);
t3=C_i_memq(lf[71],((C_word*)t0)[23]);
t4=C_i_not(t3);
t5=C_mutate((C_word*)lf[72]+1 /* (set! ##compiler#emit-trace-info ...) */,t4);
t6=C_i_memq(lf[73],((C_word*)t0)[23]);
t7=C_mutate((C_word*)lf[74]+1 /* (set! ##compiler#disable-stack-overflow-checking ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_2210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(C_i_memq(lf[286],C_retrieve(lf[36])))){
/* batch-driver.scm: 332  set-gc-report! */
((C_proc3)C_retrieve_symbol_proc(lf[287]))(3,*((C_word*)lf[287]+1),t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_2210(2,t9,C_SCHEME_UNDEFINED);}}

/* k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_2213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(C_i_memq(lf[281],((C_word*)t0)[23]))){
t3=t2;
f_2213(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[282]+1 /* (set! standard-bindings ...) */,C_retrieve(lf[283]));
t4=C_mutate((C_word*)lf[284]+1 /* (set! extended-bindings ...) */,C_retrieve(lf[285]));
t5=t2;
f_2213(t5,t4);}}

/* k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2213(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2213,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_2216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(C_retrieve(lf[72]))){
/* batch-driver.scm: 336  dribble */
t3=((C_word*)((C_word*)t0)[15])[1];
f_1626(t3,t2,lf[278],C_a_i_list(&a,1,lf[279]));}
else{
/* batch-driver.scm: 336  dribble */
t3=((C_word*)((C_word*)t0)[15])[1];
f_1626(t3,t2,lf[278],C_a_i_list(&a,1,lf[280]));}}

/* k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2219,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_i_car(((C_word*)t0)[2]);
t4=C_eqp(lf[270],t3);
t5=C_set_block_item(lf[230] /* emit-profile */,0,C_SCHEME_TRUE);
t6=C_mutate((C_word*)lf[271]+1 /* (set! ##compiler#profiled-procedures ...) */,lf[272]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3672,a[2]=t2,a[3]=((C_word*)t0)[15],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
/* batch-driver.scm: 345  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[223]+1)))(5,*((C_word*)lf[223]+1),t7,((C_word*)((C_word*)t0)[5])[1],C_retrieve(lf[276]),lf[277]);}
else{
/* batch-driver.scm: 345  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[223]+1)))(5,*((C_word*)lf[223]+1),t7,((C_word*)((C_word*)t0)[5])[1],C_retrieve(lf[276]),C_SCHEME_END_OF_LIST);}}
else{
t3=t2;
f_2219(2,t3,C_SCHEME_UNDEFINED);}}

/* k3670 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3672,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
/* batch-driver.scm: 351  dribble */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1626(t3,((C_word*)t0)[2],lf[273],C_a_i_list(&a,1,lf[274]));}
else{
/* batch-driver.scm: 351  dribble */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1626(t3,((C_word*)t0)[2],lf[273],C_a_i_list(&a,1,lf[275]));}}

/* k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 354  load-identifier-database */
((C_proc3)C_retrieve_symbol_proc(lf[268]))(3,*((C_word*)lf[268]+1),t2,lf[269]);}

/* k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2222,2,t0,t1);}
if(C_truep(C_i_memq(lf[75],((C_word*)t0)[22]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2231,a[2]=((C_word*)t0)[21],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 357  print-version */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t2,C_SCHEME_TRUE);}
else{
t2=C_i_memq(lf[77],((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t2)){
t4=t3;
f_2243(t4,t2);}
else{
t4=C_i_memq(lf[265],((C_word*)t0)[22]);
if(C_truep(t4)){
t5=t3;
f_2243(t5,t4);}
else{
t5=C_i_memq(lf[266],((C_word*)t0)[22]);
t6=t3;
f_2243(t6,(C_truep(t5)?t5:C_i_memq(lf[267],((C_word*)t0)[22])));}}}}

/* k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2243(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2243,NULL,2,t0,t1);}
if(C_truep(t1)){
/* batch-driver.scm: 360  print-usage */
((C_proc2)C_retrieve_symbol_proc(lf[78]))(2,*((C_word*)lf[78]+1),((C_word*)t0)[22]);}
else{
if(C_truep(C_i_memq(lf[79],((C_word*)t0)[21]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2255,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2262,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 362  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t3);}
else{
t2=((C_word*)t0)[20];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[21],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[22],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 370  dribble */
t4=((C_word*)((C_word*)t0)[14])[1];
f_1626(t4,t3,lf[263],C_a_i_list(&a,1,((C_word*)t0)[20]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2271,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 365  print-version */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t3,C_SCHEME_TRUE);}}}}

/* k2269 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 366  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[37]+1)))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],lf[264]);}

/* k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2277,2,t0,t1);}
t2=C_mutate((C_word*)lf[81]+1 /* (set! ##compiler#source-filename ...) */,((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[22],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 372  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[98]))(5,*((C_word*)lf[98]+1),t3,lf[258],lf[262],((C_word*)t0)[8]);}

/* k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 373  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[98]))(5,*((C_word*)lf[98]+1),t2,lf[258],lf[261],C_retrieve(lf[36]));}

/* k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2287,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 374  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[98]))(5,*((C_word*)lf[98]+1),t2,lf[258],lf[260],C_retrieve(lf[66]));}

/* k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 375  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[98]))(5,*((C_word*)lf[98]+1),t2,lf[258],lf[259],C_retrieve(lf[70]));}

/* k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2290,2,t0,t1);}
t2=C_fudge(C_fix(6));
t3=C_mutate(((C_word *)((C_word*)t0)[22])+1,t2);
t4=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[22],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 379  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[256]+1)))(4,*((C_word*)lf[256]+1),t4,C_retrieve(lf[257]),C_SCHEME_END_OF_LIST);}

/* k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2298,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1 /* (set! ##sys#line-number-database ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 380  collect-options */
t4=((C_word*)((C_word*)t0)[9])[1];
f_1834(t4,t3,lf[255]);}

/* k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_2304,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 381  collect-options */
t3=((C_word*)((C_word*)t0)[9])[1];
f_1834(t3,t2,lf[254]);}

/* k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_2307,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3640,a[2]=((C_word*)t0)[10],a[3]=t2,a[4]=((C_word*)t0)[17],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 383  collect-options */
t4=((C_word*)((C_word*)t0)[10])[1];
f_1834(t4,t3,lf[253]);}

/* k3638 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3640,2,t0,t1);}
t2=C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3648,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 385  collect-options */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1834(t4,t3,lf[252]);}

/* k3646 in k3638 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 382  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[223]+1)))(5,*((C_word*)lf[223]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_2310,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],tmp=(C_word)a,a+=26,tmp);
/* batch-driver.scm: 387  user-read-pass */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t2);}

/* k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2313,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 389  dribble */
t4=((C_word*)((C_word*)t0)[21])[1];
f_1626(t4,t3,lf[244],C_SCHEME_END_OF_LIST);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3489,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3489(t6,t2,((C_word*)t0)[3]);}}

/* doloop830 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3489(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3489,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3500,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3504,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3549,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_3549(t12,t8,((C_word*)t0)[3]);}
else{
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3588,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 399  check-and-open-input-file */
((C_proc3)C_retrieve_symbol_proc(lf[251]))(3,*((C_word*)lf[251]+1),t4,t3);}}

/* k3586 in doloop830 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3588,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3591,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3600,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3605,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3633,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[250]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a3632 in k3586 in doloop830 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3633,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[247]));
t3=C_mutate((C_word*)lf[247]+1 /* (set! ##sys#current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a3604 in k3586 in doloop830 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3605,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3611,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_3611(t5,t1);}

/* loop in a3604 in k3586 in doloop830 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3611(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3611,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3615,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 402  read/source-info */
((C_proc3)C_retrieve_symbol_proc(lf[249]))(3,*((C_word*)lf[249]+1),t2,((C_word*)t0)[5]);}

/* k3613 in loop in a3604 in k3586 in doloop830 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3615,2,t0,t1);}
if(C_truep(C_eofp(t1))){
/* batch-driver.scm: 404  close-checked-input-file */
((C_proc4)C_retrieve_symbol_proc(lf[248]))(4,*((C_word*)lf[248]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
/* batch-driver.scm: 407  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3611(t4,((C_word*)t0)[6]);}}

/* a3599 in k3586 in doloop830 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3600,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[247]));
t3=C_mutate((C_word*)lf[247]+1 /* (set! ##sys#current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k3589 in k3586 in doloop830 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_3489(t3,((C_word*)t0)[2],t2);}

/* loop837 in doloop830 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3549(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3549,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[245]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3578,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g853854 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3576 in loop837 in doloop830 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3578,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop837850 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3549(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop837850 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3549(t6,((C_word*)t0)[3],t5);}}

/* k3502 in doloop830 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 396  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[246]+1)))(3,*((C_word*)lf[246]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3506 in k3502 in doloop830 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3508,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3512,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3514,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_3514(t10,t6,((C_word*)t0)[2]);}

/* loop860 in k3506 in k3502 in doloop830 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3514(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3514,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[245]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3543,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g876877 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3541 in loop860 in k3506 in k3502 in doloop830 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3543,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop860873 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3514(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop860873 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3514(t6,((C_word*)t0)[3],t5);}}

/* k3510 in k3506 in k3502 in doloop830 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 395  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[223]+1)))(5,*((C_word*)lf[223]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3498 in doloop830 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3478 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3484,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 390  proc */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3482 in k3478 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2313(2,t3,t2);}

/* k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 410  user-preprocessor-pass */
((C_proc2)C_retrieve_symbol_proc(lf[4]))(2,*((C_word*)lf[4]+1),t2);}

/* k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3438,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 412  dribble */
t4=((C_word*)((C_word*)t0)[18])[1];
f_1626(t4,t3,lf[243],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_2319(t3,C_SCHEME_UNDEFINED);}}

/* k3436 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3438,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3444,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3444(t10,t6,((C_word*)((C_word*)t0)[4])[1]);}

/* loop913 in k3436 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3444(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3444,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3473,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g929930 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3471 in loop913 in k3436 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3473,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop913926 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3444(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop913926 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3444(t6,((C_word*)t0)[3],t5);}}

/* k3440 in k3436 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2319(t3,t2);}

/* k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2319(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2319,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_2322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 415  print-expr */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1711(t3,t2,lf[241],lf[242],((C_word*)((C_word*)t0)[3])[1]);}

/* k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2322,2,t0,t1);}
t2=f_1869(((C_word*)((C_word*)t0)[22])[1]);
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2328,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t4=t3;
f_2328(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3415,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 419  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[223]+1)))(4,*((C_word*)lf[223]+1),t4,C_retrieve(lf[65]),((C_word*)((C_word*)t0)[2])[1]);}}

/* k3413 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3415,2,t0,t1);}
t2=C_mutate((C_word*)lf[65]+1 /* (set! ##sys#explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3435,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[240]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* k3433 in k3413 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3435,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[238],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[239],t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_2328(t7,t6);}

/* k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2328(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2328,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_2331,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],tmp=(C_word)a,a+=20,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3373,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 421  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[223]+1)))(4,*((C_word*)lf[223]+1),t7,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k3371 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3373,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3375,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3375(t5,((C_word*)t0)[2],t1);}

/* loop946 in k3371 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3375(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3375,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[237]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3404,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g962963 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3402 in loop946 in k3371 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3404,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop946959 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3375(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop946959 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3375(t6,((C_word*)t0)[3],t5);}}

/* k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_2334,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 422  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[236]))(2,*((C_word*)lf[236]+1),t2);}

/* k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2334,2,t0,t1);}
t2=C_i_length(C_retrieve(lf[83]));
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2340,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],tmp=(C_word)a,a+=18,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3113,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3307,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_3307(t12,t8,C_retrieve(lf[235]));}

/* loop972 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3307(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3307,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_i_car(t3);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[227],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t4,t8);
t10=C_a_i_cons(&a,2,lf[232],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t12=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t11);
t13=C_mutate(((C_word *)((C_word*)t0)[4])+1,t11);
t14=C_slot(t2,C_fix(1));
/* loop972985 */
t20=t1;
t21=t14;
t1=t20;
t2=t21;
goto loop;}
else{
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=C_mutate(((C_word *)((C_word*)t0)[4])+1,t11);
t14=C_slot(t2,C_fix(1));
/* loop972985 */
t20=t1;
t21=t14;
t1=t20;
t2=t21;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3111 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3113,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3263,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_3263(t10,t6,C_retrieve(lf[234]));}

/* loop1000 in k3111 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3263(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3263,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[233],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop10001013 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop10001013 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3115 in k3111 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3121,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[230]))){
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[227],t3);
t5=(C_truep(C_retrieve(lf[206]))?C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST):C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST));
t6=C_a_i_cons(&a,2,lf[227],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,t4,t7);
t9=C_a_i_cons(&a,2,lf[231],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,C_retrieve(lf[228]),t10);
t12=C_a_i_cons(&a,2,lf[232],t11);
t13=t2;
f_3121(t13,C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST));}
else{
t3=t2;
f_3121(t3,C_SCHEME_END_OF_LIST);}}

/* k3119 in k3115 in k3111 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3121(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3121,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3140,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_3140(t10,t6,C_retrieve(lf[83]));}

/* loop1032 in k3119 in k3115 in k3111 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3140(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
loop:
a=C_alloc(27);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3140,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[227],t5);
t7=C_i_cdr(t3);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,lf[227],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t6,t10);
t12=C_a_i_cons(&a,2,C_retrieve(lf[228]),t11);
t13=C_a_i_cons(&a,2,lf[229],t12);
t14=C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t15=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t14);
t16=C_mutate(((C_word *)((C_word*)t0)[4])+1,t14);
t17=C_slot(t2,C_fix(1));
/* loop10321045 */
t23=t1;
t24=t17;
t1=t23;
t2=t24;
goto loop;}
else{
t15=C_mutate(((C_word *)((C_word*)t0)[2])+1,t14);
t16=C_mutate(((C_word *)((C_word*)t0)[4])+1,t14);
t17=C_slot(t2,C_fix(1));
/* loop10321045 */
t23=t1;
t24=t17;
t1=t23;
t2=t24;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3123 in k3119 in k3115 in k3111 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_retrieve(lf[206]);
if(C_truep(t2)){
/* batch-driver.scm: 424  append */
((C_proc9)C_retrieve_proc(*((C_word*)lf[223]+1)))(9,*((C_word*)lf[223]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_END_OF_LIST,lf[224]);}
else{
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 424  append */
((C_proc9)C_retrieve_proc(*((C_word*)lf[223]+1)))(9,*((C_word*)lf[223]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_END_OF_LIST,lf[225]);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
/* batch-driver.scm: 424  append */
((C_proc9)C_retrieve_proc(*((C_word*)lf[223]+1)))(9,*((C_word*)lf[223]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,lf[226]);}}}

/* k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2340,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2343,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3052,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(C_retrieve(lf[220])))){
/* batch-driver.scm: 446  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),t5,lf[221],lf[222]);}
else{
t6=t5;
f_3052(2,t6,C_SCHEME_FALSE);}}

/* k3050 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3052,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3057,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3057(t5,((C_word*)t0)[2],C_retrieve(lf[220]));}
else{
t2=((C_word*)t0)[2];
f_2343(2,t2,C_SCHEME_UNDEFINED);}}

/* loop1066 in k3050 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_3057(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3057,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3092,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[32]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3069,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t6,lf[219],t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3067 in loop1066 in k3050 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t2,t3,((C_word*)t0)[3]);}

/* k3070 in k3067 in loop1066 in k3050 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t2,lf[218],((C_word*)t0)[3]);}

/* k3073 in k3070 in k3067 in loop1066 in k3050 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3078,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t2,t3,((C_word*)t0)[3]);}

/* k3076 in k3073 in k3070 in k3067 in loop1066 in k3050 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[34]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k3090 in loop1066 in k3050 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3057(t3,((C_word*)t0)[2],t2);}

/* k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3046,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 450  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),t3,lf[216],lf[217]);}

/* k3044 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 451  display-real-name-table */
((C_proc2)C_retrieve_symbol_proc(lf[215]))(2,*((C_word*)lf[215]+1),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_2346(2,t2,C_SCHEME_UNDEFINED);}}

/* k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3040,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 452  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),t3,lf[213],lf[214]);}

/* k3038 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 453  display-line-number-database */
((C_proc2)C_retrieve_symbol_proc(lf[212]))(2,*((C_word*)lf[212]+1),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_2349(2,t2,C_SCHEME_UNDEFINED);}}

/* k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(C_truep(C_retrieve(lf[206]))?((C_word*)t0)[11]:C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[211]))(2,*((C_word*)lf[211]+1),t4);}
else{
t4=t2;
f_2352(2,t4,C_SCHEME_UNDEFINED);}}

/* k3023 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3028,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t2,lf[210],t1);}

/* k3026 in k3023 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t2,C_retrieve(lf[206]),((C_word*)t0)[2]);}

/* k3029 in k3026 in k3023 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t2,lf[209],((C_word*)t0)[2]);}

/* k3032 in k3029 in k3026 in k3023 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3037,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[208]))(3,*((C_word*)lf[208]+1),t2,((C_word*)t0)[2]);}

/* k3035 in k3032 in k3029 in k3026 in k3023 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 456  ##sys#notice */
((C_proc3)C_retrieve_symbol_proc(lf[207]))(3,*((C_word*)lf[207]+1),((C_word*)t0)[2],t1);}

/* k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2352,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1 /* (set! ##sys#line-number-database ...) */,C_retrieve(lf[84]));
t3=C_set_block_item(lf[84] /* line-number-database-2 */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 462  end-time */
t5=((C_word*)((C_word*)t0)[17])[1];
f_1879(t5,t4,lf[205]);}

/* k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2360,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 463  print-expr */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1711(t3,t2,lf[203],lf[204],((C_word*)((C_word*)t0)[3])[1]);}

/* k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(C_i_memq(lf[202],((C_word*)t0)[3]))){
/* batch-driver.scm: 465  exit */
((C_proc2)C_retrieve_symbol_proc(lf[118]))(2,*((C_word*)lf[118]+1),t2);}
else{
t3=t2;
f_2363(2,t3,C_SCHEME_UNDEFINED);}}

/* k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 467  user-pass */
((C_proc2)C_retrieve_symbol_proc(lf[5]))(2,*((C_word*)lf[5]+1),t2);}

/* k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2964,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[17],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 469  dribble */
t4=((C_word*)((C_word*)t0)[13])[1];
f_1626(t4,t3,lf[201],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_2369(2,t3,C_SCHEME_UNDEFINED);}}

/* k2962 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2964,2,t0,t1);}
t2=f_1869(((C_word*)((C_word*)t0)[6])[1]);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t9,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2976(t11,t7,((C_word*)((C_word*)t0)[5])[1]);}

/* loop1108 in k2962 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2976(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2976,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3005,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g11241125 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3003 in loop1108 in k2962 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3005,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop11081121 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2976(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop11081121 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2976(t6,((C_word*)t0)[3],t5);}}

/* k2969 in k2962 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* batch-driver.scm: 472  end-time */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1879(t3,((C_word*)t0)[2],lf[200]);}

/* k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2961,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 477  canonicalize-begin-body */
((C_proc3)C_retrieve_symbol_proc(lf[199]))(3,*((C_word*)lf[199]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2959 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 476  build-node-graph */
((C_proc3)C_retrieve_symbol_proc(lf[198]))(3,*((C_word*)lf[198]+1),((C_word*)t0)[2],t1);}

/* k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2957,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=C_a_i_record(&a,4,lf[85],lf[86],lf[87],t2);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2380,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 480  print-node */
t7=((C_word*)((C_word*)t0)[13])[1];
f_1665(t7,t6,lf[196],lf[197],t3);}

/* k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 481  initialize-analysis-database */
((C_proc2)C_retrieve_symbol_proc(lf[195]))(2,*((C_word*)lf[195]+1),t2);}

/* k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2386,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
if(C_truep(C_retrieve(lf[179]))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2903,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[17],a[7]=t2,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[18],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_i_memq(lf[193],((C_word*)t0)[2]))){
t4=t3;
f_2903(2,t4,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 486  load-type-database */
((C_proc3)C_retrieve_symbol_proc(lf[190]))(3,*((C_word*)lf[190]+1),t3,lf[194]);}}
else{
t3=t2;
f_2386(t3,C_SCHEME_UNDEFINED);}}

/* k2901 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2906,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2935,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2943,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 487  collect-options */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1834(t5,t4,lf[192]);}

/* k2941 in k2901 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[191]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2934 in k2901 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2935,3,t0,t1,t2);}
t3=C_retrieve(lf[190]);
/* g11561157 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* k2904 in k2901 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2906,2,t0,t1);}
t2=f_1869(((C_word*)((C_word*)t0)[8])[1]);
t3=C_set_block_item(lf[90] /* first-analysis */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2914,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 490  analyze */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1908(t5,t4,lf[189],((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* k2912 in k2904 in k2901 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2914,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2917,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 491  print-db */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1687(t4,t3,lf[188],lf[182],((C_word*)((C_word*)t0)[7])[1],C_fix(0));}

/* k2915 in k2912 in k2904 in k2901 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 492  end-time */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1879(t3,t2,lf[187]);}

/* k2918 in k2915 in k2912 in k2904 in k2901 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2920,2,t0,t1);}
t2=f_1869(((C_word*)((C_word*)t0)[6])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 494  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),t3,lf[99],lf[186]);}

/* k2924 in k2918 in k2915 in k2912 in k2904 in k2901 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2929,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 495  scrutinize */
((C_proc4)C_retrieve_symbol_proc(lf[185]))(4,*((C_word*)lf[185]+1),t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2927 in k2924 in k2918 in k2915 in k2912 in k2904 in k2901 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2932,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 496  end-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1879(t3,t2,lf[184]);}

/* k2930 in k2927 in k2924 in k2918 in k2915 in k2912 in k2904 in k2901 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[90] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_2386(t3,t2);}

/* k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2386(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2386,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2389,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[174]))){
t3=f_1869(((C_word*)((C_word*)t0)[17])[1]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[14],a[6]=t2,a[7]=((C_word*)t0)[17],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[179]))){
t5=t4;
f_2876(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=C_set_block_item(lf[90] /* first-analysis */,0,C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2894,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 503  analyze */
t7=((C_word*)((C_word*)t0)[15])[1];
f_1908(t7,t6,lf[183],((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}}
else{
t3=t2;
f_2389(t3,C_SCHEME_UNDEFINED);}}

/* k2892 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2894,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2897,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 504  print-db */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1687(t4,t3,lf[181],lf[182],((C_word*)((C_word*)t0)[5])[1],C_fix(0));}

/* k2895 in k2892 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 505  end-time */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1879(t2,((C_word*)t0)[2],lf[180]);}

/* k2874 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2876,2,t0,t1);}
t2=f_1869(((C_word*)((C_word*)t0)[7])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2882,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 507  perform-lambda-lifting! */
((C_proc4)C_retrieve_symbol_proc(lf[178]))(4,*((C_word*)lf[178]+1),t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2880 in k2874 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2885,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 508  end-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1879(t3,t2,lf[177]);}

/* k2883 in k2880 in k2874 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 509  print-node */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1665(t3,t2,lf[175],lf[176],((C_word*)t0)[2]);}

/* k2886 in k2883 in k2880 in k2874 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[90] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_2389(t3,t2);}

/* k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2389(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2389,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2870,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 512  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[172]+1)))(3,*((C_word*)lf[172]+1),t3,C_retrieve(lf[173]));}

/* k2868 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 512  concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[167]))(3,*((C_word*)lf[167]+1),((C_word*)t0)[2],t1);}

/* k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2395,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2863,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 513  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),t3,lf[170],lf[171]);}

/* k2861 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 514  pp */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2395(2,t2,C_SCHEME_UNDEFINED);}}

/* k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2398,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[160]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2770,a[2]=t2,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2825,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2827,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_2827(t12,t8,((C_word*)t0)[2]);}
else{
t3=t2;
f_2398(2,t3,C_SCHEME_UNDEFINED);}}

/* loop1208 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2827(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2827,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[168]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2856,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g12241225 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2854 in loop1208 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2856,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12081221 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2827(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12081221 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2827(t6,((C_word*)t0)[3],t5);}}

/* k2823 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 524  concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[167]))(3,*((C_word*)lf[167]+1),((C_word*)t0)[2],t1);}

/* k2768 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2770,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2772,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2772(t5,((C_word*)t0)[2],t1);}

/* loop1189 in k2768 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2772(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2772,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2780,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2810,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g11961197 */
t6=t3;
f_2780(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2808 in loop1189 in k2768 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2772(t3,((C_word*)t0)[2],t2);}

/* g1196 in loop1189 in k2768 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2780(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2780,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2803,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2807,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 519  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[166]+1)))(3,*((C_word*)lf[166]+1),t5,t2);}

/* k2805 in g1196 in loop1189 in k2768 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 519  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[164]))(5,*((C_word*)lf[164]+1),((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[165]);}

/* k2801 in g1196 in loop1189 in k2768 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 518  ##sys#resolve-include-filename */
((C_proc5)C_retrieve_symbol_proc(lf[163]))(5,*((C_word*)lf[163]+1),((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2782 in g1196 in loop1189 in k2768 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2784,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 521  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[162]))(3,*((C_word*)lf[162]+1),t2,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2791 in k2782 in g1196 in loop1189 in k2768 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2793,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 522  dribble */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1626(t3,t2,lf[161],C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2794 in k2791 in k2782 in g1196 in loop1189 in k2768 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 523  load-inline-file */
((C_proc3)C_retrieve_symbol_proc(lf[157]))(3,*((C_word*)lf[157]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2401,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 525  collect-options */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1834(t3,t2,lf[159]);}

/* k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_i_nullp(t1))){
t3=t2;
f_2404(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(lf[155] /* inline-globally */,0,C_SCHEME_TRUE);
t4=C_set_block_item(lf[156] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2734,a[2]=t6,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_2734(t8,t2,t1);}}

/* loop1234 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2734(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2734,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2742,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2752,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g12411242 */
t6=t3;
f_2742(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2750 in loop1234 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2734(t3,((C_word*)t0)[2],t2);}

/* g1241 in loop1234 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2742(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2742,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2746,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 531  dribble */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1626(t4,t3,lf[158],C_a_i_list(&a,1,t2));}

/* k2744 in g1241 in loop1234 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 532  load-inline-file */
((C_proc3)C_retrieve_symbol_proc(lf[157]))(3,*((C_word*)lf[157]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2404,2,t0,t1);}
t2=C_set_block_item(lf[82] /* line-number-database */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[88] /* constant-table */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[89] /* inline-table */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[119]))){
t6=t5;
f_2410(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=C_slot(((C_word*)t0)[2],C_fix(3));
t7=C_i_car(t6);
/* batch-driver.scm: 539  scan-toplevel-assignments */
((C_proc3)C_retrieve_symbol_proc(lf[154]))(3,*((C_word*)lf[154]+1),t5,t7);}}

/* k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2410,2,t0,t1);}
t2=f_1869(((C_word*)((C_word*)t0)[15])[1]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2416,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 542  perform-cps-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[153]))(3,*((C_word*)lf[153]+1),t3,((C_word*)t0)[2]);}

/* k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2419,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 543  end-time */
t3=((C_word*)((C_word*)t0)[13])[1];
f_1879(t3,t2,lf[152]);}

/* k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 544  print-node */
t3=((C_word*)((C_word*)t0)[12])[1];
f_1665(t3,t2,lf[150],lf[151],((C_word*)t0)[2]);}

/* k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2422,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2427,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=t3,a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp));
t5=((C_word*)t3)[1];
f_2427(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_2427(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2427,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t6=f_1869(((C_word*)((C_word*)t0)[14])[1]);
t7=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=t2,a[16]=t5,a[17]=((C_word*)t0)[14],a[18]=t4,tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 550  analyze */
t8=((C_word*)((C_word*)t0)[11])[1];
f_1908(t8,t7,lf[149],((C_word*)t5)[1],C_a_i_list(&a,2,t2,t4));}

/* k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_2437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
if(C_truep(C_retrieve(lf[90]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2684,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_memq(lf[147],C_retrieve(lf[36])))){
/* batch-driver.scm: 553  dump-undefined-globals */
((C_proc3)C_retrieve_symbol_proc(lf[148]))(3,*((C_word*)lf[148]+1),t3,t1);}
else{
t4=t3;
f_2684(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_2437(2,t3,C_SCHEME_UNDEFINED);}}

/* k2682 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_memq(lf[145],C_retrieve(lf[36])))){
/* batch-driver.scm: 555  dump-defined-globals */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2687(2,t3,C_SCHEME_UNDEFINED);}}

/* k2685 in k2682 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_memq(lf[143],C_retrieve(lf[36])))){
/* batch-driver.scm: 557  dump-global-refs */
((C_proc3)C_retrieve_symbol_proc(lf[144]))(3,*((C_word*)lf[144]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
f_2437(2,t3,t2);}}

/* k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2437,2,t0,t1);}
t2=C_set_block_item(lf[90] /* first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_2441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm: 559  end-time */
t4=((C_word*)((C_word*)t0)[13])[1];
f_1879(t4,t3,lf[142]);}

/* k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_2444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm: 560  print-db */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1687(t3,t2,lf[140],lf[141],((C_word*)t0)[16],((C_word*)t0)[15]);}

/* k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_2447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
if(C_truep(C_i_memq(lf[138],C_retrieve(lf[36])))){
/* batch-driver.scm: 562  print-program-statistics */
((C_proc3)C_retrieve_symbol_proc(lf[139]))(3,*((C_word*)lf[139]+1),t2,((C_word*)t0)[16]);}
else{
t3=t2;
f_2447(2,t3,C_SCHEME_UNDEFINED);}}

/* k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2447,2,t0,t1);}
if(C_truep(((C_word*)t0)[19])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2453,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[17],a[10]=((C_word*)t0)[18],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 565  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[98]))(5,*((C_word*)lf[98]+1),t2,lf[99],lf[104],((C_word*)t0)[15]);}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2539,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 587  print-node */
t3=((C_word*)((C_word*)t0)[11])[1];
f_1665(t3,t2,lf[136],lf[137],((C_word*)((C_word*)t0)[17])[1]);}}

/* k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[133]))){
t3=C_retrieve(lf[133]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[14],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 590  dribble */
t5=((C_word*)((C_word*)t0)[13])[1];
f_1626(t5,t4,lf[135],C_a_i_list(&a,1,t3));}
else{
t3=t2;
f_2542(2,t3,C_SCHEME_UNDEFINED);}}

/* k2670 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 591  emit-global-inline-file */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2542,2,t0,t1);}
t2=f_1869(((C_word*)((C_word*)t0)[16])[1]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 593  perform-closure-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[132]))(4,*((C_word*)lf[132]+1),t3,((C_word*)((C_word*)t0)[15])[1],((C_word*)t0)[14]);}

/* k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2549,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[16])+1,t1);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 594  end-time */
t4=((C_word*)((C_word*)t0)[12])[1];
f_1879(t4,t3,lf[131]);}

/* k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2555,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 595  print-db */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1687(t3,t2,lf[129],lf[130],((C_word*)t0)[14],((C_word*)t0)[2]);}

/* k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_retrieve(lf[127]))){
t3=C_fudge(C_fix(6));
t4=C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(C_fixnum_greaterp(t4,C_fix(60000)))){
/* batch-driver.scm: 598  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[37]+1)))(3,*((C_word*)lf[37]+1),t2,lf[128]);}
else{
t5=t2;
f_2558(2,t5,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_2558(2,t3,C_SCHEME_UNDEFINED);}}

/* k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 599  print-node */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1665(t3,t2,lf[125],lf[126],((C_word*)((C_word*)t0)[12])[1]);}

/* k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2564,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(C_truep(((C_word*)t0)[3])?C_retrieve(lf[119]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2640,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[12],a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 601  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),t4,lf[99],lf[124]);}
else{
t4=t2;
f_2564(2,t4,C_SCHEME_UNDEFINED);}}

/* k2638 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2640,2,t0,t1);}
t2=f_1869(((C_word*)((C_word*)t0)[6])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 603  perform-unboxing! */
((C_proc3)C_retrieve_symbol_proc(lf[123]))(3,*((C_word*)lf[123]+1),t3,((C_word*)((C_word*)t0)[3])[1]);}

/* k2644 in k2638 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2649,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 604  end-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1879(t3,t2,lf[122]);}

/* k2647 in k2644 in k2638 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 605  print-node */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1665(t2,((C_word*)t0)[3],lf[120],lf[121],((C_word*)((C_word*)t0)[2])[1]);}

/* k2562 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2567,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 606  exit */
((C_proc3)C_retrieve_symbol_proc(lf[118]))(3,*((C_word*)lf[118]+1),t2,C_fix(0));}
else{
t3=t2;
f_2567(2,t3,C_SCHEME_UNDEFINED);}}

/* k2565 in k2562 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2567,2,t0,t1);}
t2=f_1869(((C_word*)((C_word*)t0)[10])[1]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2575,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2581,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a2580 in k2565 in k2562 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2581,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm: 611  end-time */
t7=((C_word*)((C_word*)t0)[6])[1];
f_1879(t7,t6,lf[117]);}

/* k2583 in a2580 in k2565 in k2562 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2585,2,t0,t1);}
t2=f_1869(((C_word*)((C_word*)t0)[12])[1]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[8])){
/* batch-driver.scm: 613  open-output-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),t3,((C_word*)t0)[8]);}
else{
/* batch-driver.scm: 613  current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[116]+1)))(2,*((C_word*)lf[116]+1),t3);}}

/* k2589 in k2583 in a2580 in k2565 in k2562 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm: 614  dribble */
t3=((C_word*)((C_word*)t0)[11])[1];
f_1626(t3,t2,lf[114],C_a_i_list(&a,1,((C_word*)t0)[8]));}

/* k2592 in k2589 in k2583 in a2580 in k2565 in k2562 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2597,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 615  generate-code */
((C_proc9)C_retrieve_symbol_proc(lf[113]))(9,*((C_word*)lf[113]+1),t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2595 in k2592 in k2589 in k2583 in a2580 in k2565 in k2562 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2600,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 616  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2600(2,t3,C_SCHEME_UNDEFINED);}}

/* k2598 in k2595 in k2592 in k2589 in k2583 in a2580 in k2565 in k2562 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2603,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 617  end-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1879(t3,t2,lf[111]);}

/* k2601 in k2598 in k2595 in k2592 in k2589 in k2583 in a2580 in k2565 in k2562 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_memq(lf[108],C_retrieve(lf[36])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2622,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 619  ##sys#stop-timer */
t4=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f5070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 620  compiler-cleanup-hook */
((C_proc2)C_retrieve_symbol_proc(lf[107]))(2,*((C_word*)lf[107]+1),t3);}}

/* f5070 in k2601 in k2598 in k2595 in k2592 in k2589 in k2583 in a2580 in k2565 in k2562 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f5070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 621  dribble */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1626(t2,((C_word*)t0)[2],lf[106],C_SCHEME_END_OF_LIST);}

/* k2620 in k2601 in k2598 in k2595 in k2592 in k2589 in k2583 in a2580 in k2565 in k2562 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 619  ##sys#display-times */
((C_proc3)C_retrieve_symbol_proc(lf[109]))(3,*((C_word*)lf[109]+1),((C_word*)t0)[2],t1);}

/* k2604 in k2601 in k2598 in k2595 in k2592 in k2589 in k2583 in a2580 in k2565 in k2562 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 620  compiler-cleanup-hook */
((C_proc2)C_retrieve_symbol_proc(lf[107]))(2,*((C_word*)lf[107]+1),t2);}

/* k2607 in k2604 in k2601 in k2598 in k2595 in k2592 in k2589 in k2583 in a2580 in k2565 in k2562 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 621  dribble */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1626(t2,((C_word*)t0)[2],lf[106],C_SCHEME_END_OF_LIST);}

/* a2574 in k2565 in k2562 in k2559 in k2556 in k2553 in k2550 in k2547 in k2540 in k2537 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2575,2,t0,t1);}
/* batch-driver.scm: 610  prepare-for-code-generation */
((C_proc4)C_retrieve_symbol_proc(lf[105]))(4,*((C_word*)lf[105]+1),t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k2451 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2453,2,t0,t1);}
t2=f_1869(((C_word*)((C_word*)t0)[10])[1]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2461,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2467,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a2466 in k2451 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2467,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 569  end-time */
t5=((C_word*)((C_word*)t0)[4])[1];
f_1879(t5,t4,lf[103]);}

/* k2469 in a2466 in k2451 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2474,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 570  print-node */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1665(t3,t2,lf[101],lf[102],((C_word*)t0)[6]);}

/* k2472 in k2469 in a2466 in k2451 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2474,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 571  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2427(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t2=C_retrieve(lf[92]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[93]))){
t3=f_1869(((C_word*)((C_word*)t0)[4])[1]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 578  analyze */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1908(t5,t4,lf[97],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}
else{
t3=C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 584  loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_2427(t4,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2493,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 573  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),t3,lf[99],lf[100]);}}}

/* k2491 in k2472 in k2469 in a2466 in k2451 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[92] /* inline-substitutions-enabled */,0,C_SCHEME_TRUE);
t3=C_fixnum_increase(((C_word*)t0)[5]);
/* batch-driver.scm: 575  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2427(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2508 in k2472 in k2469 in a2466 in k2451 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2513,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 579  end-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1879(t3,t2,lf[96]);}

/* k2511 in k2508 in k2472 in k2469 in a2466 in k2451 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2513,2,t0,t1);}
t2=f_1869(((C_word*)((C_word*)t0)[8])[1]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 581  transform-direct-lambdas! */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2517 in k2511 in k2508 in k2472 in k2469 in a2466 in k2451 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2522,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 582  end-time */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1879(t3,t2,lf[94]);}

/* k2520 in k2517 in k2511 in k2508 in k2472 in k2469 in a2466 in k2451 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_increase(((C_word*)t0)[6]);
/* batch-driver.scm: 583  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2427(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2460 in k2451 in k2445 in k2442 in k2439 in k2435 in k2432 in loop in k2420 in k2417 in k2414 in k2408 in k2402 in k2399 in k2396 in k2393 in k2390 in k2387 in k2384 in k2381 in k2378 in k2955 in k2367 in k2364 in k2361 in k2358 in k2355 in k2350 in k2347 in k2344 in k2341 in k2338 in k2332 in k2329 in k2326 in k2320 in k2317 in k2314 in k2311 in k2308 in k2305 in k2302 in k2299 in k2296 in k2288 in k2285 in k2282 in k2279 in k2275 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2461,2,t0,t1);}
/* batch-driver.scm: 568  perform-high-level-optimizations */
((C_proc4)C_retrieve_symbol_proc(lf[91]))(4,*((C_word*)lf[91]+1),t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k2260 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 362  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[37]+1)))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],t1);}

/* k2253 in k2241 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 363  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[45]+1)))(2,*((C_word*)lf[45]+1),((C_word*)t0)[2]);}

/* k2229 in k2220 in k2217 in k2214 in k2211 in k2208 in k2197 in k2193 in k2189 in k2185 in k2181 in k2177 in k2174 in k2170 in k2166 in k2163 in k2159 in k2151 in k2147 in k2144 in k2141 in k2138 in k2131 in k2128 in k2125 in k2122 in k2119 in k2116 in k2113 in k2109 in k2106 in k2100 in k2097 in k2094 in k2091 in k2088 in k2085 in k2082 in k2076 in k2070 in k2067 in k2064 in k2061 in k2058 in k2055 in k2052 in k2049 in k2046 in k2043 in k2040 in k2036 in k2033 in k2030 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k1995 in k1991 in k1988 in k1985 in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 358  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[45]+1)))(2,*((C_word*)lf[45]+1),((C_word*)t0)[2]);}

/* analyze in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1908(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1908,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1910,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1933,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1938,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t4))){
/* def-no267309 */
t8=t7;
f_1938(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
/* def-contf268307 */
t10=t6;
f_1933(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* body265273 */
t12=t5;
f_1910(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-no267 in analyze in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1938(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1938,NULL,2,t0,t1);}
/* def-contf268307 */
t2=((C_word*)t0)[2];
f_1933(t2,t1,C_fix(0));}

/* def-contf268 in analyze in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1933(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1933,NULL,3,t0,t1,t2);}
/* body265273 */
t3=((C_word*)t0)[2];
f_1910(t3,t1,t2,C_SCHEME_TRUE);}

/* body265 in analyze in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1910(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1910,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1914,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 151  analyze-expression */
((C_proc3)C_retrieve_symbol_proc(lf[52]))(3,*((C_word*)lf[52]+1),t4,((C_word*)t0)[2]);}

/* k1912 in body265 in analyze in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1917,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1922,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1928,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 153  upap */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc9)C_retrieve_proc(t5))(9,t5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* a1927 in k1912 in body265 in analyze in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1928,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[51]);
/* g304305 */
t6=t5;
((C_proc6)C_retrieve_proc(t6))(6,t6,t1,((C_word*)t0)[2],t2,t3,t4);}

/* a1921 in k1912 in body265 in analyze in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1922,4,t0,t1,t2,t3);}
t4=C_retrieve(lf[50]);
/* g289290 */
t5=t4;
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* k1915 in k1912 in body265 in analyze in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* end-time in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1879(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1879,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=*((C_word*)lf[32]+1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1886,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t4,lf[49],t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1884 in end-time in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k1887 in k1884 in end-time in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t2,lf[48],((C_word*)t0)[3]);}

/* k1890 in k1887 in k1884 in end-time in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1895,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_fudge(C_fix(6));
t4=C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[43]+1)))(4,*((C_word*)lf[43]+1),t2,t4,((C_word*)t0)[3]);}

/* k1893 in k1890 in k1887 in k1884 in end-time in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[34]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* begin-time in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static C_word C_fcall f_1869(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t1=C_fudge(C_fix(6));
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
return(t2);}
else{
t1=C_SCHEME_UNDEFINED;
return(t1);}}

/* collect-options in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1834(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1834,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1840,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1840(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1840(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1840,NULL,3,t0,t1,t2);}
t3=C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* g241242 */
t5=t4;
f_1848(t5,t1,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* g241 in loop in collect-options in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1848(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1848,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1856,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 139  option-arg */
f_1518(t3,t2);}

/* k1854 in g241 in loop in collect-options in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1860,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm: 139  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1840(t4,t2,t3);}

/* k1858 in k1854 in g241 in loop in collect-options in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1860,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1754(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1754,NULL,2,t1,t2);}
t3=C_i_string_length(t2);
t4=C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1764,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnum_lessp(t3,C_fix(2)))){
/* batch-driver.scm: 130  string->number */
C_string_to_number(3,0,t5,t2);}
else{
t6=C_i_string_ref(t2,t4);
t7=C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1795,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1803,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 132  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[47]+1)))(5,*((C_word*)lf[47]+1),t10,t2,C_fix(0),t4);}
else{
t9=C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1819,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1823,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 133  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[47]+1)))(5,*((C_word*)lf[47]+1),t12,t2,C_fix(0),t4);}
else{
/* batch-driver.scm: 134  string->number */
C_string_to_number(3,0,t5,t2);}}}}

/* k1821 in arg-val in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 133  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1817 in arg-val in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_times(t1,C_fix(1024));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* batch-driver.scm: 135  quit */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[46],((C_word*)t0)[2]);}}

/* k1801 in arg-val in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 132  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1793 in arg-val in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_times(t1,C_fix(1048576));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* batch-driver.scm: 135  quit */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[46],((C_word*)t0)[2]);}}

/* k1762 in arg-val in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* batch-driver.scm: 135  quit */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[46],((C_word*)t0)[2]);}}

/* print-expr in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1711(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1711,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1718,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 119  print-header */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1641(t6,t5,t2,t3);}

/* k1716 in print-expr in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1718,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1723,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1723(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* loop193 in k1716 in print-expr in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1723,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1741,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1735,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 122  pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),t5,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1733 in loop193 in k1716 in print-expr in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 123  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[45]+1)))(2,*((C_word*)lf[45]+1),((C_word*)t0)[2]);}

/* k1739 in loop193 in k1716 in print-expr in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1723(t3,((C_word*)t0)[2],t2);}

/* print-db in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1687(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1687,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1694,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 114  print-header */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1641(t7,t6,t2,t3);}

/* k1692 in print-db in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1694,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[32]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1697,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t3,lf[44],t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1695 in k1692 in print-db in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1700,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[43]+1)))(4,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1698 in k1695 in k1692 in print-db in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[34]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(41),((C_word*)t0)[2]);}

/* k1701 in k1698 in k1695 in k1692 in print-db in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1706,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[34]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k1704 in k1701 in k1698 in k1695 in k1692 in print-db in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 116  display-analysis-database */
((C_proc3)C_retrieve_symbol_proc(lf[42]))(3,*((C_word*)lf[42]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1665(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1665,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1672,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 108  print-header */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1641(t6,t5,t2,t3);}

/* k1670 in print-node in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
/* batch-driver.scm: 110  dump-nodes */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1685,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 111  build-expression-tree */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t2,((C_word*)t0)[2]);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1683 in k1670 in print-node in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 111  pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),((C_word*)t0)[2],t1);}

/* print-header in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1641(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1641,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1645,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 101  dribble */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1626(t5,t4,lf[38],C_a_i_list(&a,1,t2));}

/* k1643 in print-header in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1645,2,t0,t1);}
if(C_truep(C_i_memq(((C_word*)t0)[4],C_retrieve(lf[36])))){
t2=*((C_word*)lf[32]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1654,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=C_retrieve(lf[34]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(91),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1652 in k1643 in print-header in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1655 in k1652 in k1643 in print-header in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[34]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(93),((C_word*)t0)[2]);}

/* k1658 in k1655 in k1652 in k1643 in print-header in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1663,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[34]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k1661 in k1658 in k1655 in k1652 in k1643 in print-header in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* dribble in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1626(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1626,NULL,4,t0,t1,t2,t3);}
if(C_truep(((C_word*)t0)[2])){
t4=*((C_word*)lf[32]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1633,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t5,C_retrieve(lf[35]),t4,t2,t3);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1631 in dribble in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[34]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k1634 in k1631 in dribble in k1574 in k1568 in k1565 in k4753 in k1549 in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#flush-output */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* option-arg in compile-source-file in k1511 in k1507 in k1503 in k1499 in k1495 in k1490 in k1487 */
static void C_fcall f_1518(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1518,NULL,2,t1,t2);}
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
t4=C_i_car(t2);
/* batch-driver.scm: 50   quit */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t1,lf[9],t4);}
else{
t4=C_i_cadr(t2);
if(C_truep(C_i_symbolp(t4))){
/* batch-driver.scm: 53   quit */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t1,lf[10],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[387] = {
{"toplevel:batch_driver_scm",(void*)C_driver_toplevel},
{"f_1489:batch_driver_scm",(void*)f_1489},
{"f_1492:batch_driver_scm",(void*)f_1492},
{"f_1497:batch_driver_scm",(void*)f_1497},
{"f_1501:batch_driver_scm",(void*)f_1501},
{"f_1505:batch_driver_scm",(void*)f_1505},
{"f_1509:batch_driver_scm",(void*)f_1509},
{"f_1513:batch_driver_scm",(void*)f_1513},
{"f_1515:batch_driver_scm",(void*)f_1515},
{"f_1551:batch_driver_scm",(void*)f_1551},
{"f_4774:batch_driver_scm",(void*)f_4774},
{"f_4759:batch_driver_scm",(void*)f_4759},
{"f_4755:batch_driver_scm",(void*)f_4755},
{"f_4744:batch_driver_scm",(void*)f_4744},
{"f_4715:batch_driver_scm",(void*)f_4715},
{"f_4719:batch_driver_scm",(void*)f_4719},
{"f_1567:batch_driver_scm",(void*)f_1567},
{"f_4711:batch_driver_scm",(void*)f_4711},
{"f_4672:batch_driver_scm",(void*)f_4672},
{"f_4674:batch_driver_scm",(void*)f_4674},
{"f_4703:batch_driver_scm",(void*)f_4703},
{"f_1570:batch_driver_scm",(void*)f_1570},
{"f_1576:batch_driver_scm",(void*)f_1576},
{"f_4653:batch_driver_scm",(void*)f_4653},
{"f_4649:batch_driver_scm",(void*)f_4649},
{"f_4645:batch_driver_scm",(void*)f_4645},
{"f_1987:batch_driver_scm",(void*)f_1987},
{"f_1990:batch_driver_scm",(void*)f_1990},
{"f_1993:batch_driver_scm",(void*)f_1993},
{"f_4630:batch_driver_scm",(void*)f_4630},
{"f_4574:batch_driver_scm",(void*)f_4574},
{"f_4582:batch_driver_scm",(void*)f_4582},
{"f_4584:batch_driver_scm",(void*)f_4584},
{"f_4622:batch_driver_scm",(void*)f_4622},
{"f_1997:batch_driver_scm",(void*)f_1997},
{"f_4524:batch_driver_scm",(void*)f_4524},
{"f_4526:batch_driver_scm",(void*)f_4526},
{"f_4561:batch_driver_scm",(void*)f_4561},
{"f_4565:batch_driver_scm",(void*)f_4565},
{"f_2005:batch_driver_scm",(void*)f_2005},
{"f_2008:batch_driver_scm",(void*)f_2008},
{"f_2011:batch_driver_scm",(void*)f_2011},
{"f_2014:batch_driver_scm",(void*)f_2014},
{"f_2017:batch_driver_scm",(void*)f_2017},
{"f_2020:batch_driver_scm",(void*)f_2020},
{"f_2023:batch_driver_scm",(void*)f_2023},
{"f_2026:batch_driver_scm",(void*)f_2026},
{"f_2029:batch_driver_scm",(void*)f_2029},
{"f_2032:batch_driver_scm",(void*)f_2032},
{"f_2035:batch_driver_scm",(void*)f_2035},
{"f_2038:batch_driver_scm",(void*)f_2038},
{"f_4427:batch_driver_scm",(void*)f_4427},
{"f_4429:batch_driver_scm",(void*)f_4429},
{"f_4458:batch_driver_scm",(void*)f_4458},
{"f_2042:batch_driver_scm",(void*)f_2042},
{"f_2045:batch_driver_scm",(void*)f_2045},
{"f_4418:batch_driver_scm",(void*)f_4418},
{"f_2048:batch_driver_scm",(void*)f_2048},
{"f_2051:batch_driver_scm",(void*)f_2051},
{"f_2054:batch_driver_scm",(void*)f_2054},
{"f_2057:batch_driver_scm",(void*)f_2057},
{"f_2060:batch_driver_scm",(void*)f_2060},
{"f_2063:batch_driver_scm",(void*)f_2063},
{"f_2066:batch_driver_scm",(void*)f_2066},
{"f_2069:batch_driver_scm",(void*)f_2069},
{"f_2072:batch_driver_scm",(void*)f_2072},
{"f_4380:batch_driver_scm",(void*)f_4380},
{"f_2078:batch_driver_scm",(void*)f_2078},
{"f_4365:batch_driver_scm",(void*)f_4365},
{"f_4368:batch_driver_scm",(void*)f_4368},
{"f_4371:batch_driver_scm",(void*)f_4371},
{"f_2084:batch_driver_scm",(void*)f_2084},
{"f_4355:batch_driver_scm",(void*)f_4355},
{"f_4358:batch_driver_scm",(void*)f_4358},
{"f_2087:batch_driver_scm",(void*)f_2087},
{"f_2090:batch_driver_scm",(void*)f_2090},
{"f_4313:batch_driver_scm",(void*)f_4313},
{"f_2093:batch_driver_scm",(void*)f_2093},
{"f_4307:batch_driver_scm",(void*)f_4307},
{"f_2096:batch_driver_scm",(void*)f_2096},
{"f_4298:batch_driver_scm",(void*)f_4298},
{"f_2099:batch_driver_scm",(void*)f_2099},
{"f_4280:batch_driver_scm",(void*)f_4280},
{"f_4283:batch_driver_scm",(void*)f_4283},
{"f_4286:batch_driver_scm",(void*)f_4286},
{"f_4289:batch_driver_scm",(void*)f_4289},
{"f_2102:batch_driver_scm",(void*)f_2102},
{"f_4239:batch_driver_scm",(void*)f_4239},
{"f_4241:batch_driver_scm",(void*)f_4241},
{"f_4270:batch_driver_scm",(void*)f_4270},
{"f_4235:batch_driver_scm",(void*)f_4235},
{"f_2108:batch_driver_scm",(void*)f_2108},
{"f_2111:batch_driver_scm",(void*)f_2111},
{"f_4184:batch_driver_scm",(void*)f_4184},
{"f_4186:batch_driver_scm",(void*)f_4186},
{"f_4215:batch_driver_scm",(void*)f_4215},
{"f_2115:batch_driver_scm",(void*)f_2115},
{"f_2118:batch_driver_scm",(void*)f_2118},
{"f_2121:batch_driver_scm",(void*)f_2121},
{"f_2124:batch_driver_scm",(void*)f_2124},
{"f_2127:batch_driver_scm",(void*)f_2127},
{"f_4081:batch_driver_scm",(void*)f_4081},
{"f_4095:batch_driver_scm",(void*)f_4095},
{"f_4120:batch_driver_scm",(void*)f_4120},
{"f_4125:batch_driver_scm",(void*)f_4125},
{"f_4153:batch_driver_scm",(void*)f_4153},
{"f_3991:batch_driver_scm",(void*)f_3991},
{"f_3996:batch_driver_scm",(void*)f_3996},
{"f_4010:batch_driver_scm",(void*)f_4010},
{"f_4035:batch_driver_scm",(void*)f_4035},
{"f_4040:batch_driver_scm",(void*)f_4040},
{"f_4068:batch_driver_scm",(void*)f_4068},
{"f_2130:batch_driver_scm",(void*)f_2130},
{"f_3985:batch_driver_scm",(void*)f_3985},
{"f_3977:batch_driver_scm",(void*)f_3977},
{"f_3952:batch_driver_scm",(void*)f_3952},
{"f_3954:batch_driver_scm",(void*)f_3954},
{"f_3964:batch_driver_scm",(void*)f_3964},
{"f_2133:batch_driver_scm",(void*)f_2133},
{"f_2140:batch_driver_scm",(void*)f_2140},
{"f_2143:batch_driver_scm",(void*)f_2143},
{"f_2146:batch_driver_scm",(void*)f_2146},
{"f_3915:batch_driver_scm",(void*)f_3915},
{"f_3931:batch_driver_scm",(void*)f_3931},
{"f_3934:batch_driver_scm",(void*)f_3934},
{"f_2149:batch_driver_scm",(void*)f_2149},
{"f_2153:batch_driver_scm",(void*)f_2153},
{"f_2161:batch_driver_scm",(void*)f_2161},
{"f_2165:batch_driver_scm",(void*)f_2165},
{"f_3878:batch_driver_scm",(void*)f_3878},
{"f_3880:batch_driver_scm",(void*)f_3880},
{"f_3909:batch_driver_scm",(void*)f_3909},
{"f_2168:batch_driver_scm",(void*)f_2168},
{"f_3839:batch_driver_scm",(void*)f_3839},
{"f_3841:batch_driver_scm",(void*)f_3841},
{"f_3870:batch_driver_scm",(void*)f_3870},
{"f_3835:batch_driver_scm",(void*)f_3835},
{"f_3779:batch_driver_scm",(void*)f_3779},
{"f_3781:batch_driver_scm",(void*)f_3781},
{"f_3775:batch_driver_scm",(void*)f_3775},
{"f_2172:batch_driver_scm",(void*)f_2172},
{"f_2176:batch_driver_scm",(void*)f_2176},
{"f_2179:batch_driver_scm",(void*)f_2179},
{"f_3754:batch_driver_scm",(void*)f_3754},
{"f_2183:batch_driver_scm",(void*)f_2183},
{"f_3747:batch_driver_scm",(void*)f_3747},
{"f_2187:batch_driver_scm",(void*)f_2187},
{"f_3740:batch_driver_scm",(void*)f_3740},
{"f_2191:batch_driver_scm",(void*)f_2191},
{"f_3733:batch_driver_scm",(void*)f_3733},
{"f_2195:batch_driver_scm",(void*)f_2195},
{"f_3713:batch_driver_scm",(void*)f_3713},
{"f_2199:batch_driver_scm",(void*)f_2199},
{"f_2210:batch_driver_scm",(void*)f_2210},
{"f_2213:batch_driver_scm",(void*)f_2213},
{"f_2216:batch_driver_scm",(void*)f_2216},
{"f_3672:batch_driver_scm",(void*)f_3672},
{"f_2219:batch_driver_scm",(void*)f_2219},
{"f_2222:batch_driver_scm",(void*)f_2222},
{"f_2243:batch_driver_scm",(void*)f_2243},
{"f_2271:batch_driver_scm",(void*)f_2271},
{"f_2277:batch_driver_scm",(void*)f_2277},
{"f_2281:batch_driver_scm",(void*)f_2281},
{"f_2284:batch_driver_scm",(void*)f_2284},
{"f_2287:batch_driver_scm",(void*)f_2287},
{"f_2290:batch_driver_scm",(void*)f_2290},
{"f_2298:batch_driver_scm",(void*)f_2298},
{"f_2301:batch_driver_scm",(void*)f_2301},
{"f_2304:batch_driver_scm",(void*)f_2304},
{"f_3640:batch_driver_scm",(void*)f_3640},
{"f_3648:batch_driver_scm",(void*)f_3648},
{"f_2307:batch_driver_scm",(void*)f_2307},
{"f_2310:batch_driver_scm",(void*)f_2310},
{"f_3489:batch_driver_scm",(void*)f_3489},
{"f_3588:batch_driver_scm",(void*)f_3588},
{"f_3633:batch_driver_scm",(void*)f_3633},
{"f_3605:batch_driver_scm",(void*)f_3605},
{"f_3611:batch_driver_scm",(void*)f_3611},
{"f_3615:batch_driver_scm",(void*)f_3615},
{"f_3600:batch_driver_scm",(void*)f_3600},
{"f_3591:batch_driver_scm",(void*)f_3591},
{"f_3549:batch_driver_scm",(void*)f_3549},
{"f_3578:batch_driver_scm",(void*)f_3578},
{"f_3504:batch_driver_scm",(void*)f_3504},
{"f_3508:batch_driver_scm",(void*)f_3508},
{"f_3514:batch_driver_scm",(void*)f_3514},
{"f_3543:batch_driver_scm",(void*)f_3543},
{"f_3512:batch_driver_scm",(void*)f_3512},
{"f_3500:batch_driver_scm",(void*)f_3500},
{"f_3480:batch_driver_scm",(void*)f_3480},
{"f_3484:batch_driver_scm",(void*)f_3484},
{"f_2313:batch_driver_scm",(void*)f_2313},
{"f_2316:batch_driver_scm",(void*)f_2316},
{"f_3438:batch_driver_scm",(void*)f_3438},
{"f_3444:batch_driver_scm",(void*)f_3444},
{"f_3473:batch_driver_scm",(void*)f_3473},
{"f_3442:batch_driver_scm",(void*)f_3442},
{"f_2319:batch_driver_scm",(void*)f_2319},
{"f_2322:batch_driver_scm",(void*)f_2322},
{"f_3415:batch_driver_scm",(void*)f_3415},
{"f_3435:batch_driver_scm",(void*)f_3435},
{"f_2328:batch_driver_scm",(void*)f_2328},
{"f_3373:batch_driver_scm",(void*)f_3373},
{"f_3375:batch_driver_scm",(void*)f_3375},
{"f_3404:batch_driver_scm",(void*)f_3404},
{"f_2331:batch_driver_scm",(void*)f_2331},
{"f_2334:batch_driver_scm",(void*)f_2334},
{"f_3307:batch_driver_scm",(void*)f_3307},
{"f_3113:batch_driver_scm",(void*)f_3113},
{"f_3263:batch_driver_scm",(void*)f_3263},
{"f_3117:batch_driver_scm",(void*)f_3117},
{"f_3121:batch_driver_scm",(void*)f_3121},
{"f_3140:batch_driver_scm",(void*)f_3140},
{"f_3125:batch_driver_scm",(void*)f_3125},
{"f_2340:batch_driver_scm",(void*)f_2340},
{"f_3052:batch_driver_scm",(void*)f_3052},
{"f_3057:batch_driver_scm",(void*)f_3057},
{"f_3069:batch_driver_scm",(void*)f_3069},
{"f_3072:batch_driver_scm",(void*)f_3072},
{"f_3075:batch_driver_scm",(void*)f_3075},
{"f_3078:batch_driver_scm",(void*)f_3078},
{"f_3092:batch_driver_scm",(void*)f_3092},
{"f_2343:batch_driver_scm",(void*)f_2343},
{"f_3046:batch_driver_scm",(void*)f_3046},
{"f_2346:batch_driver_scm",(void*)f_2346},
{"f_3040:batch_driver_scm",(void*)f_3040},
{"f_2349:batch_driver_scm",(void*)f_2349},
{"f_3025:batch_driver_scm",(void*)f_3025},
{"f_3028:batch_driver_scm",(void*)f_3028},
{"f_3031:batch_driver_scm",(void*)f_3031},
{"f_3034:batch_driver_scm",(void*)f_3034},
{"f_3037:batch_driver_scm",(void*)f_3037},
{"f_2352:batch_driver_scm",(void*)f_2352},
{"f_2357:batch_driver_scm",(void*)f_2357},
{"f_2360:batch_driver_scm",(void*)f_2360},
{"f_2363:batch_driver_scm",(void*)f_2363},
{"f_2366:batch_driver_scm",(void*)f_2366},
{"f_2964:batch_driver_scm",(void*)f_2964},
{"f_2976:batch_driver_scm",(void*)f_2976},
{"f_3005:batch_driver_scm",(void*)f_3005},
{"f_2971:batch_driver_scm",(void*)f_2971},
{"f_2369:batch_driver_scm",(void*)f_2369},
{"f_2961:batch_driver_scm",(void*)f_2961},
{"f_2957:batch_driver_scm",(void*)f_2957},
{"f_2380:batch_driver_scm",(void*)f_2380},
{"f_2383:batch_driver_scm",(void*)f_2383},
{"f_2903:batch_driver_scm",(void*)f_2903},
{"f_2943:batch_driver_scm",(void*)f_2943},
{"f_2935:batch_driver_scm",(void*)f_2935},
{"f_2906:batch_driver_scm",(void*)f_2906},
{"f_2914:batch_driver_scm",(void*)f_2914},
{"f_2917:batch_driver_scm",(void*)f_2917},
{"f_2920:batch_driver_scm",(void*)f_2920},
{"f_2926:batch_driver_scm",(void*)f_2926},
{"f_2929:batch_driver_scm",(void*)f_2929},
{"f_2932:batch_driver_scm",(void*)f_2932},
{"f_2386:batch_driver_scm",(void*)f_2386},
{"f_2894:batch_driver_scm",(void*)f_2894},
{"f_2897:batch_driver_scm",(void*)f_2897},
{"f_2876:batch_driver_scm",(void*)f_2876},
{"f_2882:batch_driver_scm",(void*)f_2882},
{"f_2885:batch_driver_scm",(void*)f_2885},
{"f_2888:batch_driver_scm",(void*)f_2888},
{"f_2389:batch_driver_scm",(void*)f_2389},
{"f_2870:batch_driver_scm",(void*)f_2870},
{"f_2392:batch_driver_scm",(void*)f_2392},
{"f_2863:batch_driver_scm",(void*)f_2863},
{"f_2395:batch_driver_scm",(void*)f_2395},
{"f_2827:batch_driver_scm",(void*)f_2827},
{"f_2856:batch_driver_scm",(void*)f_2856},
{"f_2825:batch_driver_scm",(void*)f_2825},
{"f_2770:batch_driver_scm",(void*)f_2770},
{"f_2772:batch_driver_scm",(void*)f_2772},
{"f_2810:batch_driver_scm",(void*)f_2810},
{"f_2780:batch_driver_scm",(void*)f_2780},
{"f_2807:batch_driver_scm",(void*)f_2807},
{"f_2803:batch_driver_scm",(void*)f_2803},
{"f_2784:batch_driver_scm",(void*)f_2784},
{"f_2793:batch_driver_scm",(void*)f_2793},
{"f_2796:batch_driver_scm",(void*)f_2796},
{"f_2398:batch_driver_scm",(void*)f_2398},
{"f_2401:batch_driver_scm",(void*)f_2401},
{"f_2734:batch_driver_scm",(void*)f_2734},
{"f_2752:batch_driver_scm",(void*)f_2752},
{"f_2742:batch_driver_scm",(void*)f_2742},
{"f_2746:batch_driver_scm",(void*)f_2746},
{"f_2404:batch_driver_scm",(void*)f_2404},
{"f_2410:batch_driver_scm",(void*)f_2410},
{"f_2416:batch_driver_scm",(void*)f_2416},
{"f_2419:batch_driver_scm",(void*)f_2419},
{"f_2422:batch_driver_scm",(void*)f_2422},
{"f_2427:batch_driver_scm",(void*)f_2427},
{"f_2434:batch_driver_scm",(void*)f_2434},
{"f_2684:batch_driver_scm",(void*)f_2684},
{"f_2687:batch_driver_scm",(void*)f_2687},
{"f_2437:batch_driver_scm",(void*)f_2437},
{"f_2441:batch_driver_scm",(void*)f_2441},
{"f_2444:batch_driver_scm",(void*)f_2444},
{"f_2447:batch_driver_scm",(void*)f_2447},
{"f_2539:batch_driver_scm",(void*)f_2539},
{"f_2672:batch_driver_scm",(void*)f_2672},
{"f_2542:batch_driver_scm",(void*)f_2542},
{"f_2549:batch_driver_scm",(void*)f_2549},
{"f_2552:batch_driver_scm",(void*)f_2552},
{"f_2555:batch_driver_scm",(void*)f_2555},
{"f_2558:batch_driver_scm",(void*)f_2558},
{"f_2561:batch_driver_scm",(void*)f_2561},
{"f_2640:batch_driver_scm",(void*)f_2640},
{"f_2646:batch_driver_scm",(void*)f_2646},
{"f_2649:batch_driver_scm",(void*)f_2649},
{"f_2564:batch_driver_scm",(void*)f_2564},
{"f_2567:batch_driver_scm",(void*)f_2567},
{"f_2581:batch_driver_scm",(void*)f_2581},
{"f_2585:batch_driver_scm",(void*)f_2585},
{"f_2591:batch_driver_scm",(void*)f_2591},
{"f_2594:batch_driver_scm",(void*)f_2594},
{"f_2597:batch_driver_scm",(void*)f_2597},
{"f_2600:batch_driver_scm",(void*)f_2600},
{"f_2603:batch_driver_scm",(void*)f_2603},
{"f5070:batch_driver_scm",(void*)f5070},
{"f_2622:batch_driver_scm",(void*)f_2622},
{"f_2606:batch_driver_scm",(void*)f_2606},
{"f_2609:batch_driver_scm",(void*)f_2609},
{"f_2575:batch_driver_scm",(void*)f_2575},
{"f_2453:batch_driver_scm",(void*)f_2453},
{"f_2467:batch_driver_scm",(void*)f_2467},
{"f_2471:batch_driver_scm",(void*)f_2471},
{"f_2474:batch_driver_scm",(void*)f_2474},
{"f_2493:batch_driver_scm",(void*)f_2493},
{"f_2510:batch_driver_scm",(void*)f_2510},
{"f_2513:batch_driver_scm",(void*)f_2513},
{"f_2519:batch_driver_scm",(void*)f_2519},
{"f_2522:batch_driver_scm",(void*)f_2522},
{"f_2461:batch_driver_scm",(void*)f_2461},
{"f_2262:batch_driver_scm",(void*)f_2262},
{"f_2255:batch_driver_scm",(void*)f_2255},
{"f_2231:batch_driver_scm",(void*)f_2231},
{"f_1908:batch_driver_scm",(void*)f_1908},
{"f_1938:batch_driver_scm",(void*)f_1938},
{"f_1933:batch_driver_scm",(void*)f_1933},
{"f_1910:batch_driver_scm",(void*)f_1910},
{"f_1914:batch_driver_scm",(void*)f_1914},
{"f_1928:batch_driver_scm",(void*)f_1928},
{"f_1922:batch_driver_scm",(void*)f_1922},
{"f_1917:batch_driver_scm",(void*)f_1917},
{"f_1879:batch_driver_scm",(void*)f_1879},
{"f_1886:batch_driver_scm",(void*)f_1886},
{"f_1889:batch_driver_scm",(void*)f_1889},
{"f_1892:batch_driver_scm",(void*)f_1892},
{"f_1895:batch_driver_scm",(void*)f_1895},
{"f_1869:batch_driver_scm",(void*)f_1869},
{"f_1834:batch_driver_scm",(void*)f_1834},
{"f_1840:batch_driver_scm",(void*)f_1840},
{"f_1848:batch_driver_scm",(void*)f_1848},
{"f_1856:batch_driver_scm",(void*)f_1856},
{"f_1860:batch_driver_scm",(void*)f_1860},
{"f_1754:batch_driver_scm",(void*)f_1754},
{"f_1823:batch_driver_scm",(void*)f_1823},
{"f_1819:batch_driver_scm",(void*)f_1819},
{"f_1803:batch_driver_scm",(void*)f_1803},
{"f_1795:batch_driver_scm",(void*)f_1795},
{"f_1764:batch_driver_scm",(void*)f_1764},
{"f_1711:batch_driver_scm",(void*)f_1711},
{"f_1718:batch_driver_scm",(void*)f_1718},
{"f_1723:batch_driver_scm",(void*)f_1723},
{"f_1735:batch_driver_scm",(void*)f_1735},
{"f_1741:batch_driver_scm",(void*)f_1741},
{"f_1687:batch_driver_scm",(void*)f_1687},
{"f_1694:batch_driver_scm",(void*)f_1694},
{"f_1697:batch_driver_scm",(void*)f_1697},
{"f_1700:batch_driver_scm",(void*)f_1700},
{"f_1703:batch_driver_scm",(void*)f_1703},
{"f_1706:batch_driver_scm",(void*)f_1706},
{"f_1665:batch_driver_scm",(void*)f_1665},
{"f_1672:batch_driver_scm",(void*)f_1672},
{"f_1685:batch_driver_scm",(void*)f_1685},
{"f_1641:batch_driver_scm",(void*)f_1641},
{"f_1645:batch_driver_scm",(void*)f_1645},
{"f_1654:batch_driver_scm",(void*)f_1654},
{"f_1657:batch_driver_scm",(void*)f_1657},
{"f_1660:batch_driver_scm",(void*)f_1660},
{"f_1663:batch_driver_scm",(void*)f_1663},
{"f_1626:batch_driver_scm",(void*)f_1626},
{"f_1633:batch_driver_scm",(void*)f_1633},
{"f_1636:batch_driver_scm",(void*)f_1636},
{"f_1518:batch_driver_scm",(void*)f_1518},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
